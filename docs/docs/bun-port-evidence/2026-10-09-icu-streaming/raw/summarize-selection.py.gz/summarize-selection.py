from pathlib import Path
import json,sys
source=Path(__file__).resolve().parent/sys.argv[1]
summary=json.loads((source/'summary.json').read_text());totals={key:0 for key in ['passed','failed','skipped','todo']};pending=[];process_checks=0
for index,record in enumerate(summary['records'],1):
 row=json.loads((source/f'validate-{index}.json').read_text())
 assert row['successful'] and record['exit']==0 and record['validation_exit']==0
 for key in totals:totals[key]+=row['counts'][key]
 process_checks+=row['summary']['process_checks_passed']
 for case in row['cases']:
  if case['status'] in ['skipped','todo']:pending.append({'file':record['file'],**case})
result={'registered_cases':totals,'process_checks':process_checks,'completed_captures':len(summary['records']),'executable_sha256':summary['executable_sha256'],'original_pending_cases':pending}
(source/'validated-totals.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
