from pathlib import Path
import subprocess,json,sys
root=Path.cwd();task=root/'zig-out/icu-stream-port-2026-10-09';commands=[
('abi-buffer',['bun','test','build-support/bundle-native-modules.test.ts','build-support/native_module_abi.test.ts','build-support/core_builtin_abi.test.ts']),
('build-home-buffer',['zig-out/toolchains/zig-aarch64-macos-0.17.0-dev.2163+89ff10d56/zig','build','home','-Doptimize=Debug','-Dstrip=true','-Denable_jsc=true','-j1','--summary','all']),
('native-core-buffer',['env','HOME_NATIVE_VM=1','BUN_DEBUG_QUIET_LOGS=1',str(root/'zig-out/bin/home'),'run',str(root/'tests/runtime/native-node-core-cli.test.mjs')]),
('native-ipc-buffer',['env','HOME_NATIVE_VM=1','BUN_DEBUG_QUIET_LOGS=1',str(root/'zig-out/bin/home'),'run',str(root/'tests/runtime/native-spawn-sync-ipc.test.mjs')]),
('corpus-buffer',[sys.executable,str(task/'run-corpus.py'),'buffer']),
]
rows=[]
for name,command in commands:
 with (task/(name+'.log')).open('wb') as log:result=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT)
 rows.append({'label':name,'command':command,'exit':result.returncode});print(name,result.returncode,flush=True)
 if result.returncode:break
(task/'batch-buffer-summary.json').write_text(json.dumps(rows,indent=2)+'\n')
sys.exit(0 if len(rows)==len(commands) and all(row['exit']==0 for row in rows) else 1)
