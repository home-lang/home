from pathlib import Path
import json,gzip,hashlib,subprocess,tempfile
root=Path(__file__).resolve().parents[2];source=root/'zig-out/icu-stream-port-2026-10-09';dest=root/'docs/docs/bun-port-evidence/2026-10-09-icu-streaming';dest.mkdir(parents=True,exist_ok=True);files=[]
def retain(data,name):
 p=dest/(name+'.gz');p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(gzip.compress(data,mtime=0));files.append({'path':str(p.relative_to(dest)),'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
for p in sorted(source.rglob('*')):
 if p.is_file() and p.suffix in ['.json','.jsonl','.log','.xml','.stdout','.stderr','.txt','.ts','.py','.mjs','.cjs','.diff','.cpp','.h','.js','.zig','.cc','.NOTICE']:
  retain(p.read_bytes(),'raw/'+str(p.relative_to(source)))
tracked=['build-support/bundle-native-modules.ts', 'build-support/bundle-native-modules.test.ts', 'build-support/native_bindings.zig', 'packages/runtime/upstream/src/jsc/bindings/HomeICUBinding.cpp', 'packages/runtime/upstream/src/jsc/bindings/napi_finalizer.cpp', 'packages/runtime/upstream/src/jsc/bindings/napi_finalizer.h', 'packages/runtime/upstream/src/jsc/modules/NodeBufferModule.h', 'tests/runtime/native-node-core-cli.test.mjs']
for name in tracked:retain((root/name).read_bytes(),'source/'+name)
manifest={'schema':1,'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'upstream':'4982b91e3702094330f3be3883354c52b8c01323','platform':'Darwin arm64','results':json.loads((source/'buffer/validated-totals.json').read_text()),'scope':'60 original utility/ICU/encoding entries. Native ICU converter creation/decode/transcode/error names/width, environment-free finalization and public buffer.transcode are implemented. Original assertions and deadlines stay unchanged; skips/TODOs receive no passing credit. Other registry/native dependencies, complete whole-suite, Release/ASAN and all-platform parity remain incomplete.','evidence_limitations':['The first 60-entry run exposed the public buffer.transcode stub and receives no passing credit. Portable generator checks reproduce the compiled factory headers and unity wrapper; the rebuilt constants header differs and is not claimed byte-identical. Final execution and source snapshots are retained separately.'],'files':files}
(dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for row in files:assert hashlib.sha256(gzip.decompress((dest/row['path']).read_bytes())).hexdigest()==row['sha256']
with tempfile.TemporaryDirectory(prefix='home-node-builtin-evidence-') as temp:
 restored=Path(temp)
 for row in files:
  if row['path'].startswith('raw/buffer/corpus-'):
   path=restored/row['path'].removeprefix('raw/buffer/').removesuffix('.gz');path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(gzip.decompress((dest/row['path']).read_bytes()))
 for index in range(1,61):
  result=subprocess.run(['python3',str(root/'scripts/summarize-bun-corpus.py'),str(restored/f'corpus-{index}')],capture_output=True,text=True,cwd=root);assert result.returncode==0,(index,result.stdout,result.stderr)
print(json.dumps({'compressed_artifacts':len(files),'restored_validated_reports':60,'destination':str(dest)}))
