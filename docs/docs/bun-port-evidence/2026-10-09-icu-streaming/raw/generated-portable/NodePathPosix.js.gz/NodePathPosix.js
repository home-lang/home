(function () {"use strict";
// zig-out/icu-stream-port-2026-10-09/generated-portable/NodePathPosix.mts
var $;
$ = (@getInternalField(@internalModuleRegistry, 125) || @createInternalModuleById(125)).posix;
return $

})
