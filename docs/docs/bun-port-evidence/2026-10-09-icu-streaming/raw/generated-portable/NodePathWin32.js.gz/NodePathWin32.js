(function () {"use strict";
// zig-out/icu-stream-port-2026-10-09/generated-portable/NodePathWin32.mts
var $;
$ = (@getInternalField(@internalModuleRegistry, 125) || @createInternalModuleById(125)).win32;
return $

})
