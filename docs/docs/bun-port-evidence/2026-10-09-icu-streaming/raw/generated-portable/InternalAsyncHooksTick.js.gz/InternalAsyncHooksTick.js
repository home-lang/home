(function () {"use strict";
// zig-out/icu-stream-port-2026-10-09/generated-portable/InternalAsyncHooksTick.mts
var $, tickInitHooks = [], nextAsyncId = 1;
$ = {
  tickInitHooks,
  newAsyncId() {
    return ++nextAsyncId;
  }
};
return $

})
