(function () {"use strict";
// zig-out/icu-stream-port-2026-10-09/generated-portable/NodeDNSPromises.mts
var $;
$ = (@getInternalField(@internalModuleRegistry, 112) || @createInternalModuleById(112)).promises;
return $

})
