(function () {"use strict";
// zig-out/icu-stream-port-2026-10-09/generated-portable/NodeAssertStrict.mts
var $;
$ = (@getInternalField(@internalModuleRegistry, 103) || @createInternalModuleById(103)).strict;
return $

})
