(function () {"use strict";
// zig-out/icu-stream-port-2026-10-09/generated-portable/InternalUtilMime.mts
var $, { MIMEParams, MIMEType } = @lazy(26);
$ = {
  MIMEParams,
  MIMEType
};
return $

})
