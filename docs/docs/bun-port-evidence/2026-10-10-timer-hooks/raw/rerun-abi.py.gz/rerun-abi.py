import subprocess,json,pathlib,re,sys
root=pathlib.Path(__file__).resolve().parents[2];task=pathlib.Path(__file__).resolve().parent
names=['generates owned builtins and the stream adapter while preserving other literals','rejects invalid native ownership: NodeVMModule.cpp','rejects invalid native ownership: JSEventTarget.cpp','rejects invalid native ownership: NodeTimerObject.cpp']
pattern='^(?:'+'|'.join(re.escape(n) for n in names)+')$'
command=['/Users/chris/.bun/bin/bun','test','build-support/bundle-native-modules.test.ts','-t',pattern]
with (task/'abi-corrected.log').open('wb') as log:result=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT,timeout=240)
(task/'abi-corrected-scope.json').write_text(json.dumps({'names':names,'command':command,'exit':result.returncode},indent=2)+'\n')
sys.exit(result.returncode)
