#line 1 "/Users/chris/Code/Home/lang-bun-port/packages/runtime/upstream/src/jsc/bindings/NodeTimerObject.cpp"

#include "root.h"

#include "JavaScriptCore/InternalFieldTuple.h"
#include "JavaScriptCore/ArgList.h"
#include "JavaScriptCore/JSCast.h"
#include "JavaScriptCore/JSObject.h"
#include "JavaScriptCore/Heap.h"
#include "ZigGlobalObject.h"

#include "ZigGeneratedClasses.h"
#include <JavaScriptCore/JSPromise.h>
#include <JavaScriptCore/ObjectConstructor.h>
#include "JavaScriptCore/JSCJSValue.h"
#include "AsyncContextFrame.h"
#include "InternalModuleRegistry.h"
namespace Bun {
using namespace JSC;

static JSValue callTimerLifecycle(JSGlobalObject* globalObject, ASCIILiteral name, MarkedArgumentBuffer& arguments)
{
    auto& vm = globalObject->vm();
    auto scope = DECLARE_THROW_SCOPE(vm);
    auto* global = uncheckedDowncast<Zig::GlobalObject>(globalObject);
    auto module = global->internalModuleRegistry()->requireId(global, vm, InternalModuleRegistry::InternalAsyncHooksTick);
    RETURN_IF_EXCEPTION(scope, {});
    auto function = module.get(global, Identifier::fromString(vm, name));
    RETURN_IF_EXCEPTION(scope, {});
    auto result = JSC::call(global, function, jsUndefined(), arguments, "Timer lifecycle function must be callable"_s);
    RETURN_IF_EXCEPTION(scope, {});
    return result;
}

extern "C" void Home__AsyncTimer__lifecycle(JSGlobalObject* globalObject, EncodedJSValue timer, uint8_t operation)
{
    auto& vm = globalObject->vm();
    auto scope = DECLARE_TOP_EXCEPTION_SCOPE(vm);
    MarkedArgumentBuffer arguments;
    arguments.append(JSValue::decode(timer));
    arguments.append(jsBoolean(operation == 1));
    auto name = operation <= 1 ? "createTimer"_s : operation == 2 ? "destroyTimer"_s : "refreshTimer"_s;
    callTimerLifecycle(globalObject, name, arguments);
    if (scope.exception()) {
        auto* exception = scope.exception();
        (void)scope.tryClearException();
        Bun__reportUnhandledError(globalObject, JSValue::encode(exception));
    }
}

static bool call(JSGlobalObject* globalObject, JSValue timerObject, JSValue callbackValue, JSValue argumentsValue)
{
    auto& vm = JSC::getVM(globalObject);
    auto scope = DECLARE_TOP_EXCEPTION_SCOPE(vm);

    JSValue restoreAsyncContext {};
    JSC::InternalFieldTuple* asyncContextData = nullptr;

    if (auto* wrapper = dynamicDowncast<AsyncContextFrame>(callbackValue)) {
        callbackValue = wrapper->callback.get();
        asyncContextData = globalObject->m_asyncContextData.get();
        restoreAsyncContext = asyncContextData->getInternalField(0);
        asyncContextData->putInternalField(vm, 0, wrapper->context.get());
    }

    MarkedArgumentBuffer lifecycleRoots;
    lifecycleRoots.append(timerObject);
    auto previousExecution = callTimerLifecycle(globalObject, "enterTimer"_s, lifecycleRoots);
    lifecycleRoots.append(previousExecution);
    if (scope.exception()) {
        auto* exception = scope.exception();
        (void)scope.tryClearException();
        Bun__reportUnhandledError(globalObject, JSValue::encode(exception));
        if (asyncContextData) asyncContextData->putInternalField(vm, 0, restoreAsyncContext);
        return true;
    }
    bool hadException = false;

    if (auto* promise = dynamicDowncast<JSPromise>(callbackValue)) {
        // This was a Bun.sleep() call
        promise->resolve(globalObject, vm, jsUndefined());
    } else {
        auto callData = JSC::getCallData(callbackValue);
        if (callData.type == CallData::Type::None) {
            Bun__reportUnhandledError(globalObject, JSValue::encode(createNotAFunctionError(globalObject, callbackValue)));
            hadException = true;
        } else {
            MarkedArgumentBuffer args;
            if (auto* butterfly = dynamicDowncast<JSCellButterfly>(argumentsValue)) {
                //  If it's a JSCellButterfly, there is more than 1 argument.
                unsigned length = butterfly->length();
                args.ensureCapacity(length);
                for (unsigned i = 0; i < length; ++i) {
                    args.append(butterfly->get(i));
                }
            } else if (!argumentsValue.isUndefined()) {
                // Otherwise, it's a single argument.
                args.append(argumentsValue);
            }

            JSC::profiledCall(globalObject, ProfilingReason::API, callbackValue, callData, timerObject, args);
        }
    }

    if (scope.exception()) [[unlikely]] {
        auto* exception = scope.exception();
        (void)scope.tryClearException();
        Bun__reportUnhandledError(globalObject, JSValue::encode(exception));
        hadException = true;
    }

    callTimerLifecycle(globalObject, "leaveTimer"_s, lifecycleRoots);
    if (scope.exception()) {
        auto* exception = scope.exception();
        (void)scope.tryClearException();
        Bun__reportUnhandledError(globalObject, JSValue::encode(exception));
        hadException = true;
    }

    if (asyncContextData) {
        asyncContextData->putInternalField(vm, 0, restoreAsyncContext);
    }

    return hadException;
}

// Returns true if an exception was thrown.
extern "C" bool Bun__JSTimeout__call(JSGlobalObject* globalObject, EncodedJSValue timerObject, EncodedJSValue callbackValue, EncodedJSValue argumentsValue)
{
    auto& vm = globalObject->vm();
    if (vm.hasPendingTerminationException()) [[unlikely]] {
        return true;
    }

    return call(globalObject, JSValue::decode(timerObject), JSValue::decode(callbackValue), JSValue::decode(argumentsValue));
}

}
