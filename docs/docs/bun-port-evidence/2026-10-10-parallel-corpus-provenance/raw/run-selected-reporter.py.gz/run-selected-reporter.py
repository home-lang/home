from pathlib import Path
import subprocess,os,json,sys
root=Path(__file__).resolve().parents[2];task=Path(__file__).resolve().parent;phase='reporter-verified';report=task/phase
name='js/junit-reporter/junit.test.js';selected='should emit separate testcase entries for each retry attempt'
env=os.environ.copy();env['BUN_DEBUG_QUIET_LOGS']='1';env['HOME_BUN_CORPUS_REPORT_DIR']=str(report)
for key in ['HOME_NATIVE_VM','HOME_CORPUS_FULL_VM','HOME_NATIVE_RUN']:env.pop(key,None)
command=[str(root/'zig-out/bin/home'),'test',str(root/'packages/runtime/test/test'/name),'-t',selected]
with (task/(phase+'.log')).open('wb') as log:result=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=240)
with (task/(phase+'-validate.json')).open('wb') as log:validation=subprocess.run([sys.executable,str(root/'scripts/summarize-bun-corpus.py'),str(report)],cwd=root,stdout=log,stderr=subprocess.STDOUT)
observed=json.loads((task/(phase+'-validate.json')).read_text());passed=[case for case in observed.get('cases',[]) if case['status']=='passed'];scope_matches=len(passed)==1 and passed[0]['name']==selected and observed['counts']['passed']==1 and all(case['status'] in ['passed','filtered'] for case in observed['cases'])
(task/(phase+'-selection.json')).write_text(json.dumps({'file':name,'test_name_pattern':selected,'command':command,'exit':result.returncode,'validation_exit':validation.returncode,'scope_matches':scope_matches},indent=2)+'\n')
print('original selected reporter case',result.returncode,validation.returncode,scope_matches)
sys.exit(0 if result.returncode==0 and validation.returncode==0 and scope_matches else 1)
