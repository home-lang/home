import { AsyncLocalStorage } from 'node:async_hooks';
const storage = new AsyncLocalStorage();
for (const hostname of [undefined, '127.0.0.1']) {
 const seen = []; let resolve; const done = new Promise(r => resolve = r);
 const timer = setTimeout(() => { seen.push({type:'timeout'}); resolve(); }, 5000);
 let server;
 await storage.run('creation', async () => {
  server = Bun.serve({port:0, hostname, fetch(request, server) { seen.push({type:'fetch', store:storage.getStore(), url:request.url}); if(server.upgrade(request)) return null; return new Response('upgrade failed'); }, websocket:{open(){ seen.push({type:'server-open',store:storage.getStore()}); }, message(ws){ ws.close(); }}});
  const ws = new WebSocket('ws://' + server.hostname + ':' + server.port);
  ws.addEventListener('open', () => {seen.push({type:'open', store:storage.getStore()});ws.send('hello');});
  ws.addEventListener('error', event => {seen.push({type:'error',store:storage.getStore(),message:event.message,error:String(event.error)});});
  ws.addEventListener('close', event => {seen.push({type:'close',store:storage.getStore(),code:event.code,reason:event.reason});resolve();});
 });
 await done; clearTimeout(timer); server.stop(true); console.log(JSON.stringify({hostname:server.hostname,seen}));
}
