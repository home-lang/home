import { AsyncLocalStorage } from 'node:async_hooks';
import { setTimeout as delay } from 'node:timers/promises';
for (const flush of [false, true]) {
 const storage = new AsyncLocalStorage(); const events = [];
 const stream = storage.run('source-creation', () => new ReadableStream({type:'direct',
  pull(controller) { events.push({event:'pull',store:storage.getStore()}); controller.write('hello'); if(flush)controller.flush(); },
  cancel(reason) { events.push({event:'cancel',store:storage.getStore(),reason}); },
 }));
 const reader = stream.getReader(); let settled = false;
 reader.read().then(value => {settled=true;events.push({event:'read',done:value.done,bytes:value.value?.byteLength});}, error => {settled=true;events.push({event:'read-error',message:error.message});});
 await delay(25);events.push({event:'before-cancel',settled});
 await reader.cancel('probe-reason'); await delay(25);events.push({event:'after-cancel',settled});
 reader.releaseLock(); await stream.cancel('after-release');
 console.log(JSON.stringify({flush,events}));
}
