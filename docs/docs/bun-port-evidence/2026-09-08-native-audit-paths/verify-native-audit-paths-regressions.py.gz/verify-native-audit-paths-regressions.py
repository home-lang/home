import difflib,gzip,hashlib,json,os,re,shutil,subprocess,tarfile,tempfile,time
from pathlib import Path
root=Path.cwd(); evidence=(root/'zig-out/bun-port-recovery').resolve(); out=evidence/'native-audit-paths-regressions';out.mkdir(exist_ok=False)
home=root/'zig-out/bin/home';bun=Path('/Users/chris/Code/bun/build/release/bun');project=root/'packages/runtime/test';build=evidence/'build-native-audit-paths-reclaimed.log'
assert 'Build Summary: 46/46 steps succeeded' in build.read_text(), 'New native build did not succeed'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(home)!='1bc7b238520d498baee344c02fd475419f38e23c66eb8d2440a33b5a42dde8f5','Stale executable'
manifest={'source_commit':subprocess.check_output(['git','rev-parse','13fda557c'],text=True).strip(),'home_sha256':sha(home),'bun_sha256':sha(bun),'build_log_sha256':sha(build),'results':[]}
def save(): (out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
cases=[]
for name in ['native-audit-protocol','native-patch-lifecycle','native-link-bin-ownership','native-link-lifecycle','native-local-dependency-identity','native-update-outdated','native-frozen-prerelease']:
 source=root/'tests/runtime'/(name+'.test.mjs');cases.append((name,[home,'run',source],root,{'HOME_NATIVE_VM':'1'},source))
for name,relative in [('link','cli/install/bun-link.test.ts'),('native-binlink','cli/install/bun-install-native-binlink.test.ts')]:
 source=project/'test'/relative
 for runtime,exe in [('home',home),('bun',bun)]:
  args=[exe,'test']
  if runtime=='bun':args+=['--config='+str(project/'bunfig.toml')]
  args+=[source];cases.append((name+'-'+runtime,args,root if runtime=='home' else project,{},source))
for label,args,cwd,extra,source in cases:manifest['results'].append({'label':label,'argv':list(map(str,args)),'cwd':str(cwd),'source_sha256':sha(source),'status':'selected'})
save()
for case,row in zip(cases,manifest['results']):
 label,args,cwd,extra,source=case;env=os.environ.copy()
 for key in ['HOME_NATIVE_VM','HOME_CORPUS_FULL_VM','HOME_BUN_TEST_EXECUTABLE']:env.pop(key,None)
 env.update(BUN_DEBUG_QUIET_LOGS='1',BUN_FEATURE_FLAG_INTERNAL_FOR_TESTING='1',BUN_GARBAGE_COLLECTOR_LEVEL='0',NO_COLOR='1',HOME_RUN_LABEL='native-link-'+label);env.update(extra)
 # Original link tests also receive a private global prefix, inherited by their unchanged harness.
 sandbox=Path(tempfile.mkdtemp(prefix='home-link-suite-'+label+'-'))
 env.update(BUN_INSTALL=str(sandbox/'install'),BUN_INSTALL_GLOBAL_DIR=str(sandbox/'global'),BUN_INSTALL_BIN=str(sandbox/'bin'),BUN_INSTALL_CACHE_DIR=str(sandbox/'cache'))
 log=out/(label+'.log');row.update(status='started',log=str(log),global_fixture=str(sandbox),environment_overrides={key:env[key] for key in ['BUN_INSTALL','BUN_INSTALL_GLOBAL_DIR','BUN_INSTALL_BIN','BUN_INSTALL_CACHE_DIR']},native_environment=extra);save()
 snap=source.parent/'__snapshots__'/(source.name+'.snap');old=snap.read_bytes() if snap.exists() else None;start=time.monotonic()
 with log.open('xb') as stream:
  code=subprocess.run(['perl',str(root/'scripts/run-bounded.pl'),'240',*map(str,args)],cwd=cwd,env=env,stdin=subprocess.DEVNULL,stdout=stream,stderr=subprocess.STDOUT).returncode
 clean=re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]','',log.read_text(errors='replace'))
 row.update(status='completed',exit_code=code,seconds=time.monotonic()-start,log_sha256=sha(log),source_unchanged=sha(source)==row['source_sha256'],pass_reports=re.findall(r'(?m)^\s*(\d+) pass\s*$',clean),fail_reports=re.findall(r'(?m)^\s*(\d+) fail\s*$',clean))
 new=snap.read_bytes() if snap.exists() else None;row['snapshot_unchanged']=new==old
 if new!=old:
  (out/(label+'.snapshot.diff')).write_text(''.join(difflib.unified_diff((old or b'').decode().splitlines(True),(new or b'').decode().splitlines(True))))
  if old is None:snap.unlink()
  else:snap.write_bytes(old)
  row['snapshot_restored']=True
 with tarfile.open(out/(label+'.global-fixture.tar.gz'),'w:gz',dereference=False) as archive:archive.add(sandbox,arcname=label)
 shutil.rmtree(sandbox);row['global_fixture_archived_and_removed']=True
 save();print(json.dumps(row),flush=True)
 if not row['source_unchanged']:raise RuntimeError('Test source modified during execution')
raise SystemExit(int(any(r['exit_code']!=0 or not r['snapshot_unchanged'] for r in manifest['results'])))
