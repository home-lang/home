import hashlib,json,re,subprocess
from pathlib import Path
root=Path.cwd();base=(root/'zig-out/bun-port-recovery').resolve();fixture=root/'packages/runtime/test/test/cli/install/registry/fixtures/audit/express@3/bun.lock';snapshot=root/'packages/runtime/test/test/cli/install/__snapshots__/bun-audit.test.ts.snap'
pin='4982b91e3702094330f3be3883354c52b8c01323'
for p in [fixture,snapshot]:
 relative=str(p.relative_to(root/'packages/runtime/test'));expected=subprocess.check_output(['git','-C','/Users/chris/Code/bun','show',pin+':'+relative]);assert p.read_bytes()==expected
# This fixed upstream fixture is JSON with trailing commas; its strings are
# package names, version ranges and integrity digests. Do not edit the file.
raw=fixture.read_text();data=json.loads(re.sub(r',\s*([}\]])',r'\1',raw));packages=data['packages']
def resolve(parent,name):
 prefix=parent
 while prefix:
  candidate=prefix+'/'+name
  if candidate in packages:return candidate
  prefix=prefix.rsplit('/',1)[0] if '/' in prefix else ''
 return name if name in packages else None
def trace(path):
 names=path.split(' › ');current=names[0];rows=[]
 assert current in data['workspaces']['']['dependencies']
 for name in names[1:]:
  package=packages[current];deps=package[2].get('dependencies',{})
  row={'parent_key':current,'parent_version':package[0],'dependency':name,'declared_range':deps.get(name),'resolved_key':resolve(current,name)};rows.append(row)
  if name not in deps:row['error']='Dependency edge absent from resolved package';return {'path':path,'valid':False,'edges':rows}
  current=row['resolved_key'];assert current is not None
 return {'path':path,'valid':True,'edges':rows,'terminal_version':packages[current][0]}
expected=next(line.strip() for line in snapshot.read_text().splitlines() if ' › ' in line and line.strip().endswith('base64-url'))
log=(base/'native-audit-paths/bun-audit.test.ts-home.log').read_text();log=re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]','',log)
actual=next(line[1:].strip() for line in log.splitlines() if line.startswith('+') and ' › ' in line and line.strip().endswith('base64-url'))
result={'pin':pin,'fixture_sha256':hashlib.sha256(fixture.read_bytes()).hexdigest(),'snapshot_sha256':hashlib.sha256(snapshot.read_bytes()).hexdigest(),'source_files_identical_to_pin':True,'expected_snapshot_path':trace(expected),'home_resolved_path':trace(actual)}
assert result['expected_snapshot_path']['valid'] is False
assert result['expected_snapshot_path']['edges'][-1]['parent_key']=='csrf/uid-safe'
assert result['home_resolved_path']['valid'] is True
(base/'audit-snapshot-edges.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
