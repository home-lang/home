from pathlib import Path
p=Path('packages/runtime/upstream/src/jsc/bindings/HomeInspectorSession.h');s=p.read_text().replace('    std::unordered_map<int, int> responseIds;','    std::unordered_map<int, int> responseIds;\n    std::unordered_map<WTF::String, int, WTFStringHash> realmObjects;')
# std::unordered_map needs an explicit hash outside WTF String hash infrastructure.
s=s.replace('std::unordered_map<WTF::String, int, WTFStringHash> realmObjects','WTF::HashMap<WTF::String, int> realmObjects')
# Per-command forwarding controller attachment is temporary: no new strong realm root.
pos=s.index('inline void LocalInspectorChannel::sendMessageToFrontend')
helper='''class InspectorRealmForwarder final : public Inspector::FrontendChannel {
public:
    LocalInspectorChannel& channel;
    int realm;
    InspectorRealmForwarder(LocalInspectorChannel& owner,int id):channel(owner),realm(id) { }
    ConnectionType connectionType() const final { return ConnectionType::Local; }
    void sendMessageToFrontend(const WTF::String& message) final {
        auto parsed=JSON::Value::parseJSON(message);auto object=parsed?parsed->asObject():nullptr;
        if(object && object->getInteger("id"_s)) {
            if(auto result=object->getObject("result"_s)) {
                if(auto value=result->getObject("result"_s)) {
                    auto id=value->getString("objectId"_s);if(!id.isEmpty()) channel.realmObjects.set(id,realm);
                }
            }
            channel.sendMessageToFrontend(message);
        }
    }
};
inline bool dispatchInspectorRealm(LocalInspectorChannel& channel,JSON::Object& request) {
    auto method=request.getString("method"_s);auto params=request.getObject("params"_s);
    if(!params) return false;
    auto requested=params->getInteger("contextId"_s);
    if(!requested) requested=params->getInteger("executionContextId"_s);
    if(!requested) {
        auto object=params->getString("objectId"_s);
        auto found=channel.realmObjects.find(object);if(found!=channel.realmObjects.end()) requested=found->value;
    }
    if(!requested || *requested==static_cast<int>(channel.context)) return false;
    InspectorRealm* selected=nullptr;
    for(auto& entry:inspectorRealms()) if(entry.second->owner==channel.global && entry.second->id==*requested) {selected=entry.second.get();break;}
    if(!selected || !selected->global) {
        auto error=JSON::Object::create();error->setInteger("code"_s,-32000);error->setString("message"_s,"Cannot find context with specified id"_s);
        auto response=JSON::Object::create();response->setInteger("id"_s,*request.getInteger("id"_s));response->setObject("error"_s,WTF::move(error));channel.sendMessageToFrontend(response->toJSONString());return true;
    }
    JSC::Strong<JSC::JSGlobalObject> protect(channel.global->vm(),selected->global.get());
    InspectorRealmForwarder forward(channel,selected->id);
    auto& controller=protect->inspectorController();controller.connectFrontend(forward,false,false);
    params->remove("contextId"_s);params->remove("executionContextId"_s);
    controller.dispatchMessageFromFrontend(request.toJSONString());
    controller.disconnectFrontend(forward);
    return true;
}
'''
s=s[:pos]+helper+s[pos:];s=s.replace('#include <wtf/JSONValues.h>','#include <wtf/JSONValues.h>\n#include <wtf/HashMap.h>');s=s.replace('if (!channel->dispatchAdapter(*request)) global->inspectorController().dispatchMessageFromFrontend(request->toJSONString());','if (!channel->dispatchAdapter(*request) && !dispatchInspectorRealm(*channel,*request)) global->inspectorController().dispatchMessageFromFrontend(request->toJSONString());');s=s.replace('    responseIds.clear();','    responseIds.clear();\n    realmObjects.clear();');p.write_text(s)
