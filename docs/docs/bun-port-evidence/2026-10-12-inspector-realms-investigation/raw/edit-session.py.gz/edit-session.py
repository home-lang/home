from pathlib import Path
p=Path('packages/runtime/upstream/src/jsc/bindings/HomeInspectorSession.h');s=p.read_text().replace('#include "HomeInspectorAgents.h"','#include "HomeInspectorAgents.h"\n#include "HomeInspectorRealms.h"');pos=s.index('class LocalInspectorHandle final')
helper='''inline WTF::String inspectorContextCreatedMessage(int id, const WTF::String& name, const WTF::String& origin) {
    auto description = JSON::Object::create();
    description->setInteger("id"_s, id);
    description->setString("origin"_s, origin);
    description->setString("name"_s, name);
    auto params = JSON::Object::create(); params->setObject("context"_s, WTF::move(description));
    auto event = JSON::Object::create(); event->setString("method"_s, "Runtime.executionContextCreated"_s);
    event->setObject("params"_s, WTF::move(params)); return event->toJSONString();
}
inline void inspectorRealmCreated(InspectorRealm& realm) {
    std::vector<std::shared_ptr<LocalInspectorChannel>> channels;
    { std::lock_guard lock(localInspectorLock()); auto found=localInspectorChannels().find(realm.owner); if(found!=localInspectorChannels().end()) channels=found->second; }
    auto message=inspectorContextCreatedMessage(realm.id,realm.name,realm.origin);
    for(auto& channel:channels) if(channel->runtimeEnabled) channel->sendMessageToFrontend(message);
}
inline void inspectorRealmDestroyed(JSC::JSGlobalObject* owner,int id) {
    std::vector<std::shared_ptr<LocalInspectorChannel>> channels;
    { std::lock_guard lock(localInspectorLock()); auto found=localInspectorChannels().find(owner); if(found!=localInspectorChannels().end()) channels=found->second; }
    auto params=JSON::Object::create();params->setInteger("executionContextId"_s,id);
    auto event=JSON::Object::create();event->setString("method"_s,"Runtime.executionContextDestroyed"_s);event->setObject("params"_s,WTF::move(params));
    auto message=event->toJSONString();
    // GC retirement only queues native data; JS delivery occurs on the owner loop.
    for(auto& channel:channels) if(channel->runtimeEnabled) channel->sendMessageToFrontend(message);
}
'''
s=s[:pos]+helper+s[pos:];a=s.index('            auto description = JSON::Object::create();',s.index('if (method == "Runtime.enable"'));b=s.index('\n        }\n        return false;',a)
s=s[:a]+'''            sendMessageToFrontend(inspectorContextCreatedMessage(static_cast<int>(context),global->name(),""_s));
            for(auto& entry:inspectorRealms()) if(entry.second->owner==global && entry.second->global)
                sendMessageToFrontend(inspectorContextCreatedMessage(entry.second->id,entry.second->name,entry.second->origin));'''+s[b:]
p.write_text(s)
