import pathlib,json,subprocess,sys
p=pathlib.Path(__file__).resolve().parent
records=[]
for group in ['suite-before','native-final/suite-reports','native-final/outcomes-reports','suite-corrected']:
 for report in sorted((p/group).glob('report-*')):
  if not report.is_dir():continue
  child=subprocess.run([sys.executable,'scripts/summarize-bun-corpus.py',str(report)],capture_output=True,text=True)
  result=json.loads(child.stdout);out=p/'control-validation'/group/(report.name+'.json');out.parent.mkdir(parents=True,exist_ok=True);out.write_text(child.stdout)
  records.append({'path':str(report.relative_to(p)),'validation':str(out.relative_to(p)),'exit':child.returncode,'successful':result.get('successful'),'counts':result.get('counts'),'errors':result.get('errors')})
(p/'control-validation.json').write_text(json.dumps(records,indent=2)+'\n')
print('controls',len(records),'incomplete',[(r['path'],r['errors']) for r in records if r['errors']])
