// Query only the requested filesystems; do not enumerate unrelated mounts.
#include <stdint.h>
#include <stdio.h>
#include <sys/mount.h>

int main(int argc, char **argv) {
    if (argc < 2) return 2;
    for (int index = 1; index < argc; index++) {
        struct statfs volume;
        if (statfs(argv[index], &volume) || !volume.f_bsize) return 1;
        // Preserve negative kernel availability rather than wrapping it into
        // an apparently huge free volume. Use wide arithmetic for block sizes.
        long double bytes = (long double)(int64_t)volume.f_bavail * volume.f_bsize;
        printf("available_bytes: %.0Lf\n", bytes);
    }
    return 0;
}
