// Read process relationships and start identities without inspecting arguments.
#include <errno.h>
#include <inttypes.h>
#include <libproc.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/proc_info.h>

int main(void) {
    int capacity = proc_listallpids(NULL, 0);
    if (capacity <= 0 || capacity > 1000000) return 1;
    capacity += 256;
    int *pids = calloc((size_t)capacity, sizeof(*pids));
    if (!pids) return 1;
    int count = proc_listallpids(pids, capacity * (int)sizeof(*pids));
    if (count <= 0 || count >= capacity) { free(pids); return 1; }
    for (int index = 0; index < count; index++) {
        if (pids[index] <= 0) continue;
        struct proc_bsdinfo info = {0};
        int bytes = proc_pidinfo(pids[index], PROC_PIDTBSDINFO, 0, &info, sizeof(info));
        if (bytes != sizeof(info)) {
            if (errno == ESRCH) continue;
            fprintf(stderr,"pid=%d errno=%d bytes=%d\n",pids[index],errno,bytes); free(pids); return 1;
        }
        printf("%u %u %u %" PRIu64 ":%" PRIu64 "\n", info.pbi_pid,
               info.pbi_ppid, info.pbi_pgid, info.pbi_start_tvsec, info.pbi_start_tvusec);
    }
    free(pids);
    return 0;
}
