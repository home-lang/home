import subprocess,os,json
from pathlib import Path
p=Path('zig-out/fs-core-corpus-2026-10-14/temporal');env=os.environ.copy();env['PATH']='/Users/chris/.bun/bin:'+env['PATH'];rows=[]
commands=[('ownership-console',['/Users/chris/.bun/bin/bun','test','build-support/bundle-native-modules.test.ts','-t','generates owned builtins|NodeFSStatBinding|rejects native class identity|rejects error and native-wrapper ABI|rejects invalid native ownership: (ConsoleObject|BunCPUProfiler)']),('lint-fixture',['/Users/chris/.bun/bin/bunx','--bun','pickier','build-support/bundle-native-modules.test.ts'])]
for name,args in commands:
 with (p/(name+'.log')).open('wb') as f:r=subprocess.run(args,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=150)
 rows.append({'name':name,'exit':r.returncode});print(name,r.returncode,flush=True)
(p/'fixture-final-results.json').write_text(json.dumps(rows,indent=2)+'\n');raise SystemExit(any(x['exit'] for x in rows))
