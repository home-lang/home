from pathlib import Path
import subprocess,os,json,hashlib
root=Path.cwd();p=root/'zig-out/fs-core-corpus-2026-10-14/temporal';rows=[]
(p/'executable.json').write_text(json.dumps({'sha256':hashlib.sha256((root/'zig-out/bin/home').read_bytes()).hexdigest(),'bytes':(root/'zig-out/bin/home').stat().st_size},indent=2)+'\n')
commands=[('node-control-2',['/Users/chris/.local/share/pantry/global/packages/nodejs.org/v26.10.0/bin/node','tests/runtime/native-stat-timestamps.test.mjs'],{}),('home-disabled',[str(root/'zig-out/bin/home'),'tests/runtime/native-stat-timestamps.test.mjs'],{}),('home-enabled',[str(root/'zig-out/bin/home'),'tests/runtime/native-stat-timestamps.test.mjs'],{'BUN_JSC_useTemporal':'1'}),('post-corpus',['python3','zig-out/fs-core-corpus-2026-10-14/temporal/post-corpus/run-originals.py'],{}),('ownership',['/Users/chris/.bun/bin/bun','test','build-support/bundle-native-modules.test.ts'],{})]
for name,args,extra in commands:
 env=os.environ.copy();env.update(extra)
 with (p/(name+'.log')).open('wb') as f:
  try:r=subprocess.run(args,env=env,cwd=root,stdout=f,stderr=subprocess.STDOUT,timeout=1200 if name == "ownership" else 900 if name == "post-corpus" else 180)
  except subprocess.TimeoutExpired:r=subprocess.CompletedProcess([],124)
 rows.append({'name':name,'command':args,'env':extra,'exit':r.returncode});print(name,r.returncode,flush=True)
 if r.returncode: break
(p/'controls-results.json').write_text(json.dumps(rows,indent=2)+'\n')
raise SystemExit(any(x['exit'] for x in rows))
