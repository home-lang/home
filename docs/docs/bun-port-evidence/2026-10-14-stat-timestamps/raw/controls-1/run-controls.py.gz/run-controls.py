from pathlib import Path
import subprocess,os,json,hashlib
root=Path.cwd();p=root/'zig-out/fs-core-corpus-2026-10-14/temporal';rows=[]
commands=[('node-control-2',['/Users/chris/.local/share/pantry/global/packages/nodejs.org/v26.10.0/bin/node','tests/runtime/native-stat-timestamps.test.mjs'],{}),('home-disabled',[str(root/'zig-out/bin/home'),'tests/runtime/native-stat-timestamps.test.mjs'],{}),('home-enabled',[str(root/'zig-out/bin/home'),'tests/runtime/native-stat-timestamps.test.mjs'],{'BUN_JSC_useTemporal':'1'}),('ownership',['/Users/chris/.bun/bin/bun','test','build-support/bundle-native-modules.test.ts'],{})]
for name,args,extra in commands:
 env=os.environ.copy();env.update(extra)
 with (p/(name+'.log')).open('wb') as f:
  try:r=subprocess.run(args,env=env,cwd=root,stdout=f,stderr=subprocess.STDOUT,timeout=180)
  except subprocess.TimeoutExpired:r=subprocess.CompletedProcess([],124)
 rows.append({'name':name,'command':args,'env':extra,'exit':r.returncode});print(name,r.returncode,flush=True)
(p/'controls-results.json').write_text(json.dumps(rows,indent=2)+'\n')
raise SystemExit(any(x['exit'] for x in rows))
