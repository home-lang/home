import subprocess,json,os
from pathlib import Path
p=Path('zig-out/fs-core-corpus-2026-10-14/temporal');rows=[];env=os.environ.copy();env['PATH']='/Users/chris/.bun/bin:'+env['PATH']
for i,f in enumerate(['build-support/bundle-native-modules.ts','build-support/bundle-native-modules.test.ts','tests/runtime/native-stat-timestamps.test.mjs'],1):
 with (p/f'lint-{i}.log').open('wb') as log:
  r=subprocess.run(['/Users/chris/.bun/bin/bunx','--bun','pickier',f],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
 rows.append({'file':f,'exit':r.returncode});print(f,r.returncode,flush=True)
(p/'lint-results.json').write_text(json.dumps(rows,indent=2)+'\n');raise SystemExit(any(x['exit'] for x in rows))
