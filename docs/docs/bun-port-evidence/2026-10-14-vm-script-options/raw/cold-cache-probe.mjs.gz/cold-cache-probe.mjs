import vm from 'node:vm'
const rows=[]
for(const [label,value] of [['empty-buffer',Buffer.alloc(0)],['empty-view',new Uint8Array(0)],['empty-dataview',new DataView(new ArrayBuffer(0))]]){
 const source='17 + 25 /* cold cached data '+label+' */';const script=new vm.Script(source,{cachedData:value});rows.push({label,rejected:script.cachedDataRejected,result:script.runInThisContext()})
}
console.log(JSON.stringify(rows,null,2))
