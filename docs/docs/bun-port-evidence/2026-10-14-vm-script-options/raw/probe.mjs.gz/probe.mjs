import vm from 'node:vm'
const rows=[]
for(const phase of ['construct','run']){
 const ignored=phase==='construct'?['contextName','contextOrigin','timeout','microtaskMode']:['filename','lineOffset','columnOffset','cachedData','produceCachedData','contextName','contextOrigin'];
 for(const key of ignored){const reads=[];const marker=new Error(key);const options={get [key](){reads.push(key);throw marker}};try{const result=phase==='construct'?new vm.Script('42',options).runInThisContext():new vm.Script('42').runInThisContext(options);rows.push({phase,key,reads,result})}catch(e){rows.push({phase,key,reads,marker:e===marker,error:e.name,code:e.code})}}
}
for(const phase of ['construct','run']){
 const operations=[];const options=new Proxy({}, {get(t,k){operations.push(['get',String(k)]);return Reflect.get(t,k)},has(t,k){operations.push(['has',String(k)]);return Reflect.has(t,k)}});try{const result=phase==='construct'?new vm.Script('42',options).runInThisContext():new vm.Script('42').runInThisContext(options);rows.push({phase,operations,result})}catch(e){rows.push({phase,operations,error:e.name,code:e.code})}
}
const reads=[];const marker=new Error('lineOffset getter');try{new vm.Script('42',{get filename(){reads.push('filename');return 17},get lineOffset(){reads.push('lineOffset');throw marker}})}catch(e){rows.push({name:'constructor precedence',reads,marker:e===marker,error:e.name,code:e.code})}
console.log(JSON.stringify(rows,null,2))
