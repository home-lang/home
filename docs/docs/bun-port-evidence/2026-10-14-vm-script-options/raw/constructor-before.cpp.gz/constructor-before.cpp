bool ScriptOptions::fromJS(JSC::JSGlobalObject* globalObject, JSC::VM& vm, JSC::ThrowScope& scope, JSC::JSValue optionsArg, JSValue* importer)
{
    if (importer) {
        *importer = jsUndefined();
    }

    bool any = BaseVMOptions::fromJS(globalObject, vm, scope, optionsArg);
    RETURN_IF_EXCEPTION(scope, false);

    if (!optionsArg.isUndefined() && !optionsArg.isString()) {
        JSObject* options = asObject(optionsArg);

        // Validate contextName and contextOrigin are strings
        auto contextNameOpt = options->getIfPropertyExists(globalObject, Identifier::fromString(vm, "contextName"_s));
        RETURN_IF_EXCEPTION(scope, false);
        if (contextNameOpt) {
            if (!contextNameOpt.isUndefined() && !contextNameOpt.isString()) {
                ERR::INVALID_ARG_TYPE(scope, globalObject, "options.contextName"_s, "string"_s, contextNameOpt);
                return false;
            }
            any = true;
        }

        auto contextOriginOpt = options->getIfPropertyExists(globalObject, Identifier::fromString(vm, "contextOrigin"_s));
        RETURN_IF_EXCEPTION(scope, false);
        if (contextOriginOpt) {
            if (!contextOriginOpt.isUndefined() && !contextOriginOpt.isString()) {
                ERR::INVALID_ARG_TYPE(scope, globalObject, "options.contextOrigin"_s, "string"_s, contextOriginOpt);
                return false;
            }
            any = true;
        }

        if (validateTimeout(globalObject, vm, scope, options, this->timeout)) {
            RETURN_IF_EXCEPTION(scope, false);
            any = true;
        }

        if (validateProduceCachedData(globalObject, vm, scope, options, this->produceCachedData)) {
            RETURN_IF_EXCEPTION(scope, false);
            any = true;
        }

        if (validateCachedData(globalObject, vm, scope, options, this->cachedData)) {
            RETURN_IF_EXCEPTION(scope, false);
            any = true;
        }

        // Handle importModuleDynamically option
        JSValue importModuleDynamicallyValue = options->getIfPropertyExists(globalObject, Identifier::fromString(vm, "importModuleDynamically"_s));
        RETURN_IF_EXCEPTION(scope, {});

        if (importModuleDynamicallyValue) {
            if ((importModuleDynamicallyValue.isCallable() || isUseMainContextDefaultLoaderConstant(globalObject, importModuleDynamicallyValue))) {
                if (importer) {
                    *importer = importModuleDynamicallyValue;
                }
                any = true;
            } else if (!importModuleDynamicallyValue.isUndefined()) {
                ERR::INVALID_ARG_TYPE(scope, globalObject, "options.importModuleDynamically"_s, "function"_s, importModuleDynamicallyValue);
                return false;
            }
        }
    }

    return any;
}
