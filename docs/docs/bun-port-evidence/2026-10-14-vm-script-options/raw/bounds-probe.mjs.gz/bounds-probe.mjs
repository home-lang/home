import vm from 'node:vm'
const rows=[]
for(const [label,value] of [['empty-buffer',Buffer.alloc(0)],['empty-view',new Uint8Array(0)],['empty-dataview',new DataView(new ArrayBuffer(0))],['arraybuffer',new ArrayBuffer(0)]])try{const script=new vm.Script('42',{cachedData:value});rows.push({label,rejected:script.cachedDataRejected,result:script.runInThisContext()})}catch(e){rows.push({label,error:e.name,code:e.code})}
for(const value of [1,2**32-1,2**32,0,-1,1.5,NaN])try{rows.push({timeout:String(value),result:new vm.Script('42').runInThisContext({timeout:value})})}catch(e){rows.push({timeout:String(value),error:e.name,code:e.code})}
for(const value of [-0,0,2147483647,-2147483648,2147483648,1.5])try{rows.push({offset:String(value),result:new vm.Script('42',{lineOffset:value,columnOffset:value}).runInThisContext()})}catch(e){rows.push({offset:String(value),error:e.name,code:e.code})}
console.log(JSON.stringify(rows,null,2))
