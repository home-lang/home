Tracked from #66 and #885, following #889 and #890.

Native Home's Script constructor reads and validates contextName/contextOrigin/timeout even though they are not construction options. Script execution reads filename/lineOffset/columnOffset even though those belong to construction. Has-property lookups cause observable Proxy `has` operations, and validation runs before all constructor getters have been read.

The diagnostic comparison with Node v26.10.0 establishes these differences, plus execution timeouts above uint32 being accepted, and valid integer source offsets being rejected when supplied as double-backed JavaScript values (including negative zero). Arrays/functions are accepted as option objects, and raw ArrayBuffer cachedData is accepted instead of rejecting the non-view input.

Acceptance includes independent construction/execution parsing, ordinary property reads, constructor snapshots and validation/getter exception order, GC protection for earlier getter results, strict object/view types, positive uint32 timeouts, and signed int32 offsets regardless of JS numeric storage representation.

The Node trace also contains internal script parsing-context and debugger-first-line symbols that Home does not read. Empty cached-data status differs between runtimes. These remaining observations must stay visible in the broader compatibility audit; no exact full diagnostic-match credit is claimed for them.

The public option parser fixes and regression coverage are implemented locally; build/validation are in progress. All 15 additional unchanged pinned script/cache/source-location files passed at the baseline, including test-vm-basic.js. Baseline main: `59d35c06682ece3b876ff8ee80b47c6c4650838e`; Bun pin: `4982b91e3702094330f3be3883354c52b8c01323`.
