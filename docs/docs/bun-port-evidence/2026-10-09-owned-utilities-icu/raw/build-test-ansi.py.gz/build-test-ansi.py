from pathlib import Path
import os,subprocess,json,sys
root=Path.cwd();task=root/'zig-out/utility-port-2026-10-09';commands=[
('abi-final',['bun','test','build-support/bundle-native-modules.test.ts','build-support/native_module_abi.test.ts','build-support/core_builtin_abi.test.ts']),
('build-home-ansi',['zig-out/toolchains/zig-aarch64-macos-0.17.0-dev.2163+89ff10d56/zig','build','home','-Doptimize=Debug','-Dstrip=true','-Denable_jsc=true','-j1','--summary','all']),
('native-controls-ansi',['env','HOME_NATIVE_VM=1','BUN_DEBUG_QUIET_LOGS=1',str(root/'zig-out/bin/home'),'run',str(root/'tests/runtime/native-spawn-sync-ipc.test.mjs')]),
('corpus-first-ansi',[sys.executable,str(task/'run-corpus.py'),'first']),
]
results=[]
for label,command in commands:
 with (task/(label+'.log')).open('wb') as log:result=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT)
 results.append({'label':label,'command':command,'exit':result.returncode});print(label,result.returncode,flush=True)
 if result.returncode!=0:break
(task/'batch-ansi-summary.json').write_text(json.dumps(results,indent=2)+'\n')
sys.exit(0 if len(results)==len(commands) and all(row['exit']==0 for row in results) else 1)
