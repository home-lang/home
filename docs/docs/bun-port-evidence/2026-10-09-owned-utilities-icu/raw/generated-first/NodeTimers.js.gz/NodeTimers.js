(function () {"use strict";
// zig-out/utility-port-2026-10-09/generated-first/NodeTimers.mts
var $, { throwNotImplemented } = @getInternalField(@internalModuleRegistry, 38) || @createInternalModuleById(38), timersPromisesValue;
$ = {
  setTimeout,
  clearTimeout,
  setInterval,
  setImmediate,
  clearInterval,
  clearImmediate,
  get promises() {
    return timersPromisesValue ??= @getInternalField(@internalModuleRegistry, 139) || @createInternalModuleById(139);
  },
  set promises(value) {
    timersPromisesValue = value;
  },
  active(timer) {
    if (@isCallable(timer?.refresh))
      timer.refresh();
    else
      throwNotImplemented("'timers.active'");
  },
  unenroll(timer) {
    if (@isCallable(timer?.refresh)) {
      clearTimeout(timer);
      return;
    }
    throwNotImplemented("'timers.unenroll'");
  },
  enroll(timer, _msecs) {
    if (@isCallable(timer?.refresh)) {
      timer.refresh();
      return;
    }
    throwNotImplemented("'timers.enroll'");
  }
};
return $

})
