(function () {"use strict";
// zig-out/utility-port-2026-10-09/generated-first/NodePathWin32.mts
var $;
$ = (@getInternalField(@internalModuleRegistry, 125) || @createInternalModuleById(125)).win32;
return $

})
