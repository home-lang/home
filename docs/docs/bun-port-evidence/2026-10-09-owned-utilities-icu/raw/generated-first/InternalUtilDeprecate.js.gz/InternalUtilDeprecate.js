(function () {"use strict";
// zig-out/utility-port-2026-10-09/generated-first/InternalUtilDeprecate.mts
var $, { validateString } = @getInternalField(@internalModuleRegistry, 86) || @createInternalModuleById(86), codesWarned = /* @__PURE__ */ new Set;
function getDeprecationWarningEmitter(code, msg, deprecated, shouldEmitWarning = () => !0) {
  let warned = !1;
  return function() {
    if (!warned && shouldEmitWarning())
      if (warned = !0, code !== @undefined) {
        if (!codesWarned.has(code))
          process.emitWarning(msg, "DeprecationWarning", code, deprecated), codesWarned.add(code);
      } else
        process.emitWarning(msg, "DeprecationWarning", deprecated);
  };
}
function deprecate(fn, msg, code) {
  if (code !== @undefined)
    validateString(code, "code");
  let emitDeprecationWarning = getDeprecationWarningEmitter(code, msg, deprecated);
  function deprecated(...args) {
    if (!process.noDeprecation)
      emitDeprecationWarning();
    if (new.target)
      return Reflect.construct(fn, args, new.target);
    return fn.@apply(this, args);
  }
  return Object.setPrototypeOf(deprecated, fn), deprecated;
}
$ = {
  deprecate
};
return $

})
