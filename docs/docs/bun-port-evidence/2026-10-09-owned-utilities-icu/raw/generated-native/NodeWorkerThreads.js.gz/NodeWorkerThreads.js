(function () {"use strict";
// zig-out/utility-port-2026-10-09/generated-native/NodeWorkerThreads.mts
var $, EventEmitter = @getInternalField(@internalModuleRegistry, 114) || @createInternalModuleById(114), { AsyncResource } = @getInternalField(@internalModuleRegistry, 104) || @createInternalModuleById(104), Readable = @getInternalField(@internalModuleRegistry, 73) || @createInternalModuleById(73), { throwNotImplemented, warnNotImplementedOnce } = @getInternalField(@internalModuleRegistry, 38) || @createInternalModuleById(38), {
  MessageChannel,
  BroadcastChannel,
  Worker: WebWorker
} = globalThis, SHARE_ENV = Symbol("nodejs.worker_threads.SHARE_ENV"), isMainThread = Bun.isMainThread, {
  0: _workerData,
  1: _threadId,
  2: _receiveMessageOnPort,
  3: environmentData,
  4: nativeParentPort
} = @lazy(93), urlRevokeRegistry = @undefined;
function injectFakeEmitter(Class) {
  function messageEventHandler(event) {
    return event.data;
  }
  function errorEventHandler(event) {
    return event.error;
  }
  let wrappedListener = Symbol("wrappedListener");
  function wrapped(run, listener) {
    let callback = function(event) {
      return listener(run(event));
    };
    return listener[wrappedListener] = callback, callback;
  }
  function functionForEventType(event, listener) {
    switch (event) {
      case "close": {
        let callback = function(event2) {
          return listener.@call(this, event2);
        };
        return listener[wrappedListener] = callback, callback;
      }
      case "error":
      case "messageerror":
        return wrapped(errorEventHandler, listener);
      default:
        return wrapped(messageEventHandler, listener);
    }
  }
  Class.prototype.on = function(event, listener) {
    return this.addEventListener(event, functionForEventType(event, listener)), this;
  }, Class.prototype.off = function(event, listener) {
    if (listener)
      this.removeEventListener(event, listener[wrappedListener] || listener);
    else
      this.removeEventListener(event);
    return this;
  }, Class.prototype.once = function(event, listener) {
    return this.addEventListener(event, functionForEventType(event, listener), {
      once: !0
    }), this;
  };
  function EventClass(eventName) {
    if (eventName === "error" || eventName === "messageerror")
      return ErrorEvent;
    return MessageEvent;
  }
  Class.prototype.emit = function(event, ...args) {
    return this.dispatchEvent(new (EventClass(event))(event, ...args)), this;
  }, Class.prototype.prependListener = Class.prototype.on, Class.prototype.prependOnceListener = Class.prototype.once;
}
var _MessagePort = globalThis.MessagePort;
injectFakeEmitter(_MessagePort);
var MessagePort = _MessagePort, nativeMessagePortClose = MessagePort.prototype.close;
MessagePort.prototype.close = function(callback) {
  if (typeof callback === "function")
    this.addEventListener("close", callback, { once: !0 });
  return nativeMessagePortClose.@call(this);
};
var resourceLimits = {}, kJSTransferableMarker = "__bunNodeWorkerJSTransferable";
function isJSTransferableMarker(value) {
  return typeof value[kJSTransferableMarker] === "string" && Object.prototype.hasOwnProperty.@call(value, kJSTransferableMarker);
}
function deserializeJSTransferable(marker) {
  switch (marker[kJSTransferableMarker]) {
    case "internal/fs/promises:FileHandle": {
      let { FileHandle, kDeserialize } = (@getInternalField(@internalModuleRegistry, 116) || @createInternalModuleById(116)).promises.@data, handle = new FileHandle(-1);
      return handle[kDeserialize](marker.data), handle;
    }
    default:
      return marker;
  }
}
function unpackJSTransferables(value, memo) {
  if (value === null || typeof value !== "object")
    return value;
  memo ??= /* @__PURE__ */ new Map;
  let cached = memo.get(value);
  if (cached !== @undefined)
    return cached;
  if (isJSTransferableMarker(value)) {
    let instance = deserializeJSTransferable(value);
    return memo.set(value, instance), instance;
  }
  if (memo.set(value, value), @isArray(value)) {
    for (let i = 0;i < value.length; i++)
      if (i in value)
        value[i] = unpackJSTransferables(value[i], memo);
    return value;
  }
  if (value instanceof Map) {
    let entries = [];
    for (let { 0: k, 1: v } of value)
      entries.push([unpackJSTransferables(k, memo), unpackJSTransferables(v, memo)]);
    value.clear();
    for (let { 0: k, 1: v } of entries)
      value.set(k, v);
    return value;
  }
  if (value instanceof Set) {
    let items = [];
    for (let v of value)
      items.push(unpackJSTransferables(v, memo));
    value.clear();
    for (let v of items)
      value.add(v);
    return value;
  }
  let proto = Object.getPrototypeOf(value);
  if (proto === Object.prototype || proto === null)
    for (let key of Object.keys(value))
      value[key] = unpackJSTransferables(value[key], memo);
  return value;
}
var kRestoreJSTransferables = Symbol("kRestoreJSTransferables"), kFinalizeJSTransferables = Symbol("kFinalizeJSTransferables");
function packJSTransferables(options) {
  let transferList = options?.transferList;
  if (!transferList || !@isArray(transferList) || transferList.length === 0)
    return options;
  let hasCandidate = !1;
  for (let item of transferList)
    if (item !== null && typeof item === "object" && !(item instanceof @ArrayBuffer) && !(item instanceof _MessagePort) && !@isTypedArrayView(item)) {
      hasCandidate = !0;
      break;
    }
  if (!hasCandidate)
    return options;
  let { kTransfer, kTransferList, kDeserialize } = (@getInternalField(@internalModuleRegistry, 116) || @createInternalModuleById(116)).promises.@data, replacements, nativeTransferList = [], neutered = [];
  function restoreNeutered() {
    for (let { 0: item, 1: data } of neutered)
      try {
        item[kDeserialize](data);
      } catch {}
  }
  try {
    for (let item of transferList)
      if (item !== null && typeof item === "object" && typeof item[kTransfer] === "function") {
        if (replacements?.has(item))
          throw new DOMException(`Transfer list contains duplicate ${item.constructor?.name ?? "entry"}`, "DataCloneError");
        let extraTransfers = item[kTransferList]?.(), { data, deserializeInfo } = item[kTransfer]();
        if (neutered.push([item, data]), (replacements ??= /* @__PURE__ */ new Map).set(item, {
          [kJSTransferableMarker]: deserializeInfo,
          data
        }), @isArray(extraTransfers))
          nativeTransferList.push(...extraTransfers);
      } else
        nativeTransferList.push(item);
  } catch (e) {
    throw restoreNeutered(), e;
  }
  if (!replacements)
    return options;
  let seen = /* @__PURE__ */ new Map, usedMarkers = /* @__PURE__ */ new Set;
  function replace(value) {
    if (value === null || typeof value !== "object")
      return value;
    let replacement = replacements.get(value);
    if (replacement !== @undefined)
      return usedMarkers.add(value), replacement;
    let cached = seen.get(value);
    if (cached !== @undefined)
      return cached;
    if (@isArray(value)) {
      let out = new @Array(value.length);
      seen.set(value, out);
      for (let i = 0;i < value.length; i++)
        if (i in value)
          out[i] = replace(value[i]);
      return out;
    }
    if (value instanceof Map) {
      let out = /* @__PURE__ */ new Map;
      seen.set(value, out);
      for (let { 0: k, 1: v } of value)
        out.set(replace(k), replace(v));
      return out;
    }
    if (value instanceof Set) {
      let out = /* @__PURE__ */ new Set;
      seen.set(value, out);
      for (let v of value)
        out.add(replace(v));
      return out;
    }
    let proto = Object.getPrototypeOf(value);
    if (proto === Object.prototype || proto === null) {
      let out = {};
      seen.set(value, out);
      for (let key of Object.keys(value))
        out[key] = replace(value[key]);
      return out;
    }
    return value;
  }
  let packed;
  try {
    packed = {
      ...options,
      workerData: replace(options.workerData),
      transferList: nativeTransferList
    };
  } catch (e) {
    throw restoreNeutered(), e;
  }
  return packed[kRestoreJSTransferables] = restoreNeutered, packed[kFinalizeJSTransferables] = function() {
    for (let { 0: item, 1: data } of neutered)
      if (!usedMarkers.has(item) && typeof data?.fd === "number" && data.fd >= 0)
        try {
          (@getInternalField(@internalModuleRegistry, 116) || @createInternalModuleById(116)).closeSync(data.fd);
        } catch {}
  }, packed;
}
var workerData = unpackJSTransferables(_workerData), threadId = _threadId;
function receiveMessageOnPort(port) {
  return _receiveMessageOnPort(port);
}
var parentPort = nativeParentPort;
function getEnvironmentData(key) {
  return environmentData.get(key);
}
function setEnvironmentData(key, value) {
  if (value === @undefined)
    environmentData.delete(key);
  else
    environmentData.set(key, value);
}
function markAsUntransferable() {
  throwNotImplemented("worker_threads.markAsUntransferable");
}
function moveMessagePortToContext() {
  throwNotImplemented("worker_threads.moveMessagePortToContext");
}

class Worker extends EventEmitter {
  #worker;
  #performance;
  #onExitPromise = @undefined;
  #hasExited = !1;
  #urlToRevoke = "";
  constructor(filename, options = {}) {
    super();
    let eventResource = new AsyncResource("WORKER");
    options = packJSTransferables(options);
    let builtinsGeneratorHatesEval = "eval";
    if (options && builtinsGeneratorHatesEval in options)
      if (options[builtinsGeneratorHatesEval]) {
        let blob = new Blob([filename], { type: "" });
        this.#urlToRevoke = filename = URL.createObjectURL(blob);
      } else
        this.#urlToRevoke = filename;
    try {
      this.#worker = new WebWorker(filename, options, this);
    } catch (e) {
      if (options[kRestoreJSTransferables]?.(), this.#urlToRevoke)
        URL.revokeObjectURL(this.#urlToRevoke);
      throw e;
    }
    if (options[kFinalizeJSTransferables]?.(), this.#worker.addEventListener("close", eventResource.bind(this.#onClose, this), {
      once: !0
    }), this.#worker.addEventListener("error", eventResource.bind(this.#onError, this)), this.#worker.addEventListener("message", eventResource.bind(this.#onMessage, this)), this.#worker.addEventListener("messageerror", eventResource.bind(this.#onMessageError, this)), this.#worker.addEventListener("open", eventResource.bind(this.#onOpen, this), {
      once: !0
    }), this.#urlToRevoke) {
      if (!urlRevokeRegistry)
        urlRevokeRegistry = new FinalizationRegistry((url) => {
          URL.revokeObjectURL(url);
        });
      urlRevokeRegistry.register(this.#worker, this.#urlToRevoke);
    }
  }
  get threadId() {
    return this.#worker.threadId;
  }
  ref() {
    this.#worker.ref();
  }
  unref() {
    this.#worker.unref();
  }
  get stdin() {
    return null;
  }
  get stdout() {
    return null;
  }
  get stderr() {
    return null;
  }
  get performance() {
    return this.#performance ??= {
      eventLoopUtilization() {
        return warnNotImplementedOnce("worker_threads.Worker.performance"), {
          idle: 0,
          active: 0,
          utilization: 0
        };
      }
    };
  }
  terminate(callback) {
    if (typeof callback === "function")
      process.emitWarning("Passing a callback to worker.terminate() is deprecated. It returns a Promise instead.", "DeprecationWarning", "DEP0132"), this.#worker.addEventListener("close", (event) => callback(null, event.code), { once: !0 });
    let onExitPromise = this.#onExitPromise;
    if (onExitPromise)
      return @isPromise(onExitPromise) ? onExitPromise : @Promise.@resolve(onExitPromise);
    if (this.#hasExited)
      return @Promise.@resolve(@undefined);
    let { resolve, promise } = @Promise.withResolvers();
    return this.#worker.addEventListener("close", (event) => {
      resolve(event.code);
    }, { once: !0 }), this.#worker.terminate(), this.#onExitPromise = promise;
  }
  postMessage(...args) {
    return this.#worker.postMessage.@apply(this.#worker, args);
  }
  getHeapSnapshot(options) {
    return this.#worker.getHeapSnapshot(options).then((s) => new HeapSnapshotStream(s));
  }
  #onClose(e) {
    this.#hasExited = !0, this.#onExitPromise = e.code, this.emit("exit", e.code);
  }
  #onError(event) {
    let error = event?.error, message = event.message;
    if (message !== "") {
      error = Error(message, { cause: event });
      let stack = event?.stack;
      if (stack)
        error.stack = stack;
    }
    this.emit("error", error);
  }
  #onMessage(event) {
    this.emit("message", event.data);
  }
  #onMessageError(event) {
    this.emit("messageerror", event.error ?? event.data ?? event);
  }
  #onOpen() {
    this.emit("online");
  }
  async[Symbol.asyncDispose]() {
    await this.terminate();
  }
}

class HeapSnapshotStream extends Readable {
  #json;
  constructor(json) {
    super();
    this.#json = json;
  }
  _read() {
    if (this.#json !== @undefined)
      this.push(this.#json), this.push(null), this.#json = @undefined;
  }
}
$ = {
  Worker,
  workerData,
  parentPort,
  resourceLimits,
  isMainThread,
  MessageChannel,
  BroadcastChannel,
  MessagePort,
  getEnvironmentData,
  setEnvironmentData,
  getHeapSnapshot() {
    return {};
  },
  markAsUntransferable,
  moveMessagePortToContext,
  receiveMessageOnPort,
  SHARE_ENV,
  threadId
};
return $

})
