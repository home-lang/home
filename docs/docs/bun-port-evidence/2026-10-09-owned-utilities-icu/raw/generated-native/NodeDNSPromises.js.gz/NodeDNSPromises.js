(function () {"use strict";
// zig-out/utility-port-2026-10-09/generated-native/NodeDNSPromises.mts
var $;
$ = (@getInternalField(@internalModuleRegistry, 112) || @createInternalModuleById(112)).promises;
return $

})
