(function () {"use strict";
// zig-out/utility-port-2026-10-09/generated-native/NodePathPosix.mts
var $;
$ = (@getInternalField(@internalModuleRegistry, 125) || @createInternalModuleById(125)).posix;
return $

})
