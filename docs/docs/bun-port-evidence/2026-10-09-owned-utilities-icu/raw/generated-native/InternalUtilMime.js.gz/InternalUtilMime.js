(function () {"use strict";
// zig-out/utility-port-2026-10-09/generated-native/InternalUtilMime.mts
var $, { MIMEParams, MIMEType } = @lazy(26);
$ = {
  MIMEParams,
  MIMEType
};
return $

})
