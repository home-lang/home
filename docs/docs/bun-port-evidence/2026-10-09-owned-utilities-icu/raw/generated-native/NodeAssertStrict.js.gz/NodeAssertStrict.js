(function () {"use strict";
// zig-out/utility-port-2026-10-09/generated-native/NodeAssertStrict.mts
var $;
$ = (@getInternalField(@internalModuleRegistry, 103) || @createInternalModuleById(103)).strict;
return $

})
