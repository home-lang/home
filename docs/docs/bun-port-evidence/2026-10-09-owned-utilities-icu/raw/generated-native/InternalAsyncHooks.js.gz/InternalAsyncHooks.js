(function () {"use strict";
// zig-out/utility-port-2026-10-09/generated-native/InternalAsyncHooks.mts
var $, activeHooks = 0;
function enabledHooksExist() {
  return activeHooks > 0;
}
function markHookEnabled() {
  activeHooks += 1;
}
function markHookDisabled() {
  if (activeHooks > 0)
    activeHooks -= 1;
}
$ = {
  enabledHooksExist,
  markHookEnabled,
  markHookDisabled
};
return $

})
