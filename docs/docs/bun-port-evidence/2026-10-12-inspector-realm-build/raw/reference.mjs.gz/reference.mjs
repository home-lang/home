import assert from 'node:assert/strict';
import vm from 'node:vm';
import {Session} from 'node:inspector/promises';
const before=vm.createContext({answer:41},{name:'before-realm',origin:'https://before.example'});
const session=new Session();session.connect();const created=[];session.on('Runtime.executionContextCreated',event=>created.push(event.params.context));
await session.post('Runtime.enable');
const after=vm.createContext({answer:42},{name:'after-realm',origin:'https://after.example'});
await new Promise(resolve=>setImmediate(resolve));
console.log(JSON.stringify(created));
for(const [name,value] of [['before-realm',41],['after-realm',42]]){
 const context=created.find(context=>context.name===name);assert(context,name);
 assert.equal(context.origin,`https://${name.startsWith('before')?'before':'after'}.example`);
 const response=await session.post('Runtime.evaluate',{expression:'answer',contextId:context.id,returnByValue:true});assert.equal(response.result.value,value);
}
session.disconnect();assert.equal(vm.runInContext('answer',before),41);assert.equal(vm.runInContext('answer',after),42);console.log('realm lifecycle and evaluation passed');
