import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { basename, join } from 'node:path'

assert.match(basename(process.execPath), /^bun(?:\.exe)?$/)
const directory = mkdtempSync(join(tmpdir(), 'home-native-audit-'))
const definitions = [
  ['production-parent', '1.0.0', { bridge: '1.0.0' }],
  ['development-parent', '1.0.0', { bridge: '2.0.0' }],
  ['bridge', '1.0.0', { 'production-leaf': '1.0.0' }],
  ['bridge', '2.0.0', { 'development-leaf': '1.0.0' }],
  ['production-leaf', '1.0.0', {}],
  ['development-leaf', '1.0.0', {}],
  ['workspace-dev-only', '1.0.0', {}],
]
const packages = new Map()
for (const [name, version, dependencies] of definitions) {
  const bytes = await new Bun.Archive({
    'package/package.json': JSON.stringify({ name, version, dependencies }),
    'package/index.js': `module.exports = ${JSON.stringify(`${name}@${version}`)};`,
  }, { compress: 'gzip' }).bytes()
  packages.set(`${name}@${version}`, { name, version, dependencies, bytes, integrity: `sha512-${createHash('sha512').update(bytes).digest('base64')}` })
}
const audits = []
let response = {}
let status = 200
const server = Bun.serve({
  hostname: '127.0.0.1', port: 0,
  async fetch(request) {
    const path = decodeURIComponent(new URL(request.url).pathname)
    if (path === '/-/npm/v1/security/advisories/bulk') {
      const bytes = new Uint8Array(await request.arrayBuffer())
      const body = JSON.parse(new TextDecoder().decode(Bun.gunzipSync(bytes)))
      audits.push({ method: request.method, headers: Object.fromEntries(request.headers), body })
      return typeof response === 'string' ? new Response(response, { status }) : Response.json(response, { status })
    }
    if (path.endsWith('.tgz')) {
      const archive = packages.get(path.slice(1, -4))
      return archive ? new Response(archive.bytes) : new Response('missing fixture', { status: 404 })
    }
    const name = path.slice(1)
    const available = [...packages.values()].filter(pkg => pkg.name === name)
    return Response.json({
      name, 'dist-tags': { latest: available.at(-1)?.version },
      versions: Object.fromEntries(available.map(pkg => [pkg.version, { name, version: pkg.version, dependencies: pkg.dependencies, dist: { tarball: `${server.url}${encodeURIComponent(`${name}@${pkg.version}`)}.tgz`, integrity: pkg.integrity } }])),
    })
  },
})
const env = { ...process.env, HOME_NATIVE_VM: '1', NO_COLOR: '1', BUN_INSTALL_CACHE_DIR: join(directory, 'cache') }
async function run(args, expected = 0) {
  const child = Bun.spawn([process.execPath, ...args], { cwd: directory, env, stdout: 'pipe', stderr: 'pipe', stdin: 'ignore' })
  const timeout = setTimeout(() => child.kill('SIGKILL'), 15000)
  try {
    const [code, stdout, stderr] = await Promise.all([child.exited, new Response(child.stdout).text(), new Response(child.stderr).text()])
    assert.equal(code, expected, `${args.join(' ')}\n${stderr}\n${stdout}`)
    return { stdout, stderr }
  } finally {
    clearTimeout(timeout)
  }
}
function normalize(body) {
  return Object.fromEntries(Object.entries(body).sort().map(([name, versions]) => [name, [...versions].sort()]))
}
try {
  writeFileSync(join(directory, 'package.json'), JSON.stringify({ name: 'audit-root', dependencies: { 'production-parent': '1.0.0' }, devDependencies: { 'development-parent': '1.0.0' } }))
  writeFileSync(join(directory, 'bunfig.toml'), `[install]\nregistry = ${JSON.stringify(server.url.href)}\nlinker = "hoisted"\n`)
  await run(['install'])
  response = { bridge: [{ id: 700001, severity: 'high', title: 'Fixture advisory', url: 'https://example.invalid/GHSA-home-fixture', vulnerable_versions: '<2.0.0' }] }
  const report = await run(['audit', '--prod'], 1)
  console.log(JSON.stringify({ request: audits.at(-1).body, stdout: report.stdout, stderr: report.stderr }))
  assert.doesNotMatch(report.stdout, /development-parent/, 'production report must exclude development-only paths to unaffected versions')
} finally {
  await server.stop(true)
  rmSync(directory, { recursive: true, force: true })
}
console.log('native production audit path regression passed')
