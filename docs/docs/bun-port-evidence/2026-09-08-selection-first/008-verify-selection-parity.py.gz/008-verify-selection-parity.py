#!/usr/bin/env python3
"""Compare native selection with the pinned runner, without executing tests."""
import hashlib, json, os, subprocess
from pathlib import Path

root = Path.cwd()
evidence = root / 'zig-out/bun-port-recovery/selection-parity-first'
evidence.mkdir()
bun = Path('/Users/chris/Code/bun')
pin = '4982b91e3702094330f3be3883354c52b8c01323'
assert subprocess.check_output(['git', '-C', str(bun), 'rev-parse', 'HEAD'], text=True).strip() == pin
for relative in ['scripts/runner.node.mjs', 'test/expectations.txt', 'test/vendor.json']:
    assert subprocess.check_output(['git','-C',str(bun),'show','HEAD:'+relative]) == (bun/relative).read_bytes(), relative+' changed from pin'
runner = (bun / 'scripts/runner.node.mjs').read_text()
manifest = root / 'packages/runtime/test/test/BUN_TRACKED_FILES.txt'
assert (bun / 'test/vendor.json').read_bytes() == (root / 'packages/runtime/test/test/vendor.json').read_bytes()
js = r"""
import {readFileSync, writeFileSync, readdirSync, existsSync} from 'node:fs';
import {basename, extname, dirname, join, sep} from 'node:path';
const runner = readFileSync(process.argv[2], 'utf8');
const corpusRoot = process.argv[3];
const out = process.argv[4];
const mirror = process.argv[5];
const vendorRoot = process.argv[6];
const definitions = ['getTestExpectations', 'getTestModifiers', 'isJavaScript', 'isJavaScriptTest', 'isNodeTest', 'isClusterTest', 'isTest', 'isTestStrict', 'isHidden', 'getTests', 'getRelevantTests'];
let code = '';
for (const name of definitions) {
  const expression = new RegExp('^function ' + name + '\\([^]*?^}', 'm');
  const match = runner.match(expression);
  if (!match) throw new Error('missing pinned function ' + name);
  code += match[0] + '\n';
}
let context = {executable:'home',os:'linux',arch:'x64',is_ci:true};
let isCI=true, isMacOS=false, isX64=true, isQuiet=true, options={}, filters=[], allFiles=[];
let cwd=corpusRoot.slice(0, -5);
const getOs=()=>context.os, getArch=()=>context.arch, getDistro=()=>context.distro,
  getDistroVersion=()=>context.distro_version, getAbi=()=>context.abi, getAbiVersion=()=>context.abi_version;
const functions = eval(code + '; ({getTestExpectations,getTestModifiers,getTests,getRelevantTests})');
const files=functions.getTests(corpusRoot);
const expectations=functions.getTestExpectations();
const upstream=readFileSync(join(corpusRoot,'expectations.txt'),'utf8');
cwd=mirror.slice(0,-5);
const homeExpectations=functions.getTestExpectations();
const homeSource=readFileSync(join(mirror,'expectations.txt'),'utf8');
const contexts=[
 {executable:'home',os:'darwin',arch:'aarch64',distro:'macOS',distro_version:'26.0'},
 {executable:'home-asan',os:'darwin',arch:'x64',distro:'macOS',distro_version:'15.6'},
 {executable:'home',os:'darwin',arch:'x64',is_ci:false},
 {executable:'bun-linux-x64-baseline',os:'linux',arch:'x64',distro:'ubuntu',distro_version:'24.04',abi:'gnu',abi_version:'2.39'},
 {executable:'home-asan',os:'linux',arch:'x64',distro:'alpine',distro_version:'3.23',abi:'musl',abi_version:'1.2.5'},
 {executable:'home',os:'linux',arch:'aarch64',distro:'debian',distro_version:'13',abi:'gnu',abi_version:'2.41'},
 {executable:'home.exe',os:'windows',arch:'aarch64',distro:'Microsoft Windows [Version 10.0.26100]',distro_version:'Microsoft Windows [Version 10.0.26100]'},
 {executable:'bun-windows-x64-baseline-asan.exe',os:'windows',arch:'x64'},
];
const configurations=[{}, {node_only:true}, {includes:[' ,js/node, js/bun, '],excludes:['http2,fs/']}, {shard:0,max_shards:3}, {shard:1,max_shards:3}, {shard:2,max_shards:3}, {filters:['html','expect.test'],shard:2,max_shards:3}, {includes:[' , '],modified_tests:['js/bun/test/expect.test.js','js/web/html/html-rewriter-doctype.test.ts']}];
const runs=[], reference=[];
for (const current of contexts) for(const config of configurations) {
 context={is_ci:true,...current}; isCI=context.is_ci; isMacOS=context.os==='darwin'; isX64=context.arch==='x64';
 options={'node-tests':config.node_only,include:config.includes,exclude:config.excludes,shard:String(config.shard??0),'max-shards':String(config.max_shards??1)};
 filters=config.filters??[]; allFiles=(config.modified_tests??[]).map(x=>'test/'+x);
 const modifiers=functions.getTestModifiers(context.executable);
 const selected=functions.getRelevantTests(corpusRoot,modifiers,homeExpectations);
 const upstreamSelected=new Set(functions.getRelevantTests(corpusRoot,modifiers,expectations));
 runs.push({context,options:config});
 reference.push({modifiers,selected:selected.map(x=>files.indexOf(x)),additional_home_coverage:selected.filter(x=>!upstreamSelected.has(x)).map(x=>files.indexOf(x))});
}
writeFileSync(join(out,'input.json'),JSON.stringify({files,upstream_expectations:upstream,home_expectations:homeSource,runs}));
writeFileSync(join(out,'reference.json'),JSON.stringify({definitions:code,runs:reference}));
const vendor=JSON.parse(readFileSync(join(mirror,'vendor.json'),'utf8'))[0];
const begin=runner.indexOf('        const isTest = path => {',runner.indexOf('async function getVendorTests'));
const end=runner.indexOf('\n        return {',begin);
const block=runner.slice(begin,end);
const vendorSelection=new Function('vendorPath','testParentPath','testPathPrefix','testExtensions','skipTests','filters','readdirSync','join','isJavaScriptTest',block+'\nreturn testPaths;');
const isJavaScriptTest=new Function('basename',code+';return isJavaScriptTest;')(basename);
const entries=readdirSync(join(vendorRoot,'test'),{encoding:'utf8',recursive:true});
const selected=vendorSelection(vendorRoot,join(vendorRoot,'test'),'test',vendor.testExtensions,vendor.skipTests,[],readdirSync,join,isJavaScriptTest);
writeFileSync(join(out,'vendor-reference.json'),JSON.stringify({block,entries,selected:selected.map(x=>x.slice(5))}));
"""
# Preserve exact extracted source and complete selected arrays alongside checks.
(evidence / 'reference.mjs').write_text(js)
command = ['node', str(evidence/'reference.mjs'), str(bun/'scripts/runner.node.mjs'), str(bun/'test'), str(evidence), str(root/'packages/runtime/test/test'), str(root/'packages/runtime/test/vendor/elysia')]
result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
(evidence/'reference.log').write_bytes(result.stdout)
assert result.returncode == 0, result.stdout.decode(errors='replace')
inputs=json.loads((evidence/'input.json').read_text())
assert len(inputs['files']) == 4754
result=subprocess.run([str(root/'zig-out/bun-port-recovery/corpus-selection-probe'),str(evidence/'input.json'),str(evidence/'native.json')],stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
(evidence/'native.log').write_bytes(result.stdout)
assert result.returncode == 0, result.stdout.decode(errors='replace')
actual=json.loads((evidence/'native.json').read_text())['runs']
expected=json.loads((evidence/'reference.json').read_text())['runs']
for index,(native,reference) in enumerate(zip(actual,expected,strict=True)):
    for field in ('modifiers','selected','additional_home_coverage'):
        assert native[field] == reference[field], (index,field, inputs['runs'][index],native[field][:30],reference[field][:30])
    assert sorted(native['selected']+[entry['index'] for entry in native['excluded']])==list(range(len(inputs['files'])))
native_vendor=json.loads((root/'zig-out/bun-port-recovery/elysia-native-selection-first.json').read_text())
ref_vendor=json.loads((evidence/'vendor-reference.json').read_text())
assert native_vendor['entries']==ref_vendor['entries'], 'vendor recursive entry order differs'
assert native_vendor['selected']==ref_vendor['selected'], 'vendor selection differs'
assert native_vendor['excluded']==['ws/connection.test.ts']
summary={'kind':'selection-only; no corpus case passes','bun_revision':pin,'vendor_revision':subprocess.check_output(['git','-C',str(root/'packages/runtime/test/vendor/elysia'),'rev-parse','HEAD'],text=True).strip(),'primary_inventory':len(inputs['files']),'contexts':len(actual),'decisions_compared':len(inputs['files'])*len(actual),'vendor_entries':len(native_vendor['entries']),'vendor_selected':len(native_vendor['selected']),'vendor_excluded':native_vendor['excluded'],'runs':[{'context':run['context'],'options':run['options'],'selected':len(native['selected']),'excluded':len(native['excluded']),'extra':len(native['additional_home_coverage'])} for run,native in zip(inputs['runs'],actual)],'verified':True}
(evidence/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({key:value for key,value in summary.items() if key!='runs'},indent=2))
