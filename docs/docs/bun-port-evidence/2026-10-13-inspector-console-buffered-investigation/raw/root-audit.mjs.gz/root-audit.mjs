import assert from 'node:assert/strict'
import vm from 'node:vm'
import { Session } from 'node:inspector/promises'
async function collect() {
  for (let i = 0; i < 20; i++) {
    await new Promise(resolve => setImmediate(resolve))
    if (globalThis.Bun) Bun.gc(true)
    else globalThis.gc()
    await new Promise(resolve => setImmediate(resolve))
  }
}
function createWeakContexts() {
  const first = vm.createContext({ answer: 41 }, { name: 'collect-first' })
  const second = vm.createContext({ answer: 42 }, { name: 'collect-second' })
  return [new WeakRef(first), new WeakRef(second)]
}
const weak = createWeakContexts()
await collect()
assert.deepEqual(weak.map(reference => reference.deref() !== undefined), [false, false])
const timerContext = (() => {
  const context = vm.createContext({ answer: 42 }, { name: 'buffered-timer-context' })
  vm.runInContext('console.count("unobserved"); console.time("unobserved"); console.timeLog("unobserved", {answer}); console.timeEnd("unobserved")', context)
  return new WeakRef(context)
})()
await collect()
assert.notEqual(timerContext.deref(), undefined)

const session = new Session()
session.connect()
const contexts = []
const destroyed = []
const consoleEvents = []
session.on('Runtime.consoleAPICalled', event => consoleEvents.push(event.params))
session.on('Runtime.executionContextCreated', event => contexts.push(event.params.context))
session.on('Runtime.executionContextDestroyed', event => destroyed.push(event.params.executionContextId))
await session.post('Runtime.enable')
const buffered = contexts.find(context => context.name === 'buffered-timer-context')
assert(buffered)
const timerLog = consoleEvents.find(event => event.executionContextId === buffered.id && event.type === 'log' && /^unobserved: [\d.]+\s?ms$/.test(event.args[0]?.value))
assert(timerLog)
const properties = await session.post('Runtime.getProperties', { objectId: timerLog.args[1].objectId, ownProperties: true })
assert.equal(properties.result.find(property => property.name === 'answer').value.value, 42)
await session.post('Runtime.evaluate', { contextId: buffered.id, expression: 'console.clear()' })
await session.post('Runtime.releaseObjectGroup', { objectGroup: 'console' })
await session.post('Console.clearMessages')
await collect()
const {writeFileSync}=await import('node:fs')
writeFileSync(process.argv[2],JSON.stringify(Bun.generateHeapSnapshot()))
process.stdout.write('CONNECTED_RETAINED='+String(timerContext.deref()!==undefined)+'\n')
session.disconnect()
await collect()
writeFileSync(process.argv[2]+'.disconnected.json',JSON.stringify(Bun.generateHeapSnapshot()))
process.stdout.write('DISCONNECTED_RETAINED='+String(timerContext.deref()!==undefined)+'\n')
process.stdout.write('ROOT_AUDIT_COMPLETE\n')
