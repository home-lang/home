from pathlib import Path
import subprocess,json,os,sys,hashlib
p=Path(__file__).resolve().parent
steps=[('build-buffered', ['zig-out/toolchains/zig-aarch64-macos-0.17.0-dev.2163+89ff10d56/zig','build','home','--cache-dir','.home-native-console-cache','-Doptimize=Debug','-Dstrip=true','-Denable_jsc=true','-j1','--summary','all'],1800),('focused-buffered',[sys.executable,str(p/'run-focused.py')],1200),('broad-buffered',[sys.executable,str(p/'validation/run-broad.py')],1200)]
rows=[]
for name,cmd,deadline in steps:
 env = os.environ.copy()
 if name != 'build-buffered':
  # The outer guard retains the machine lock; this inner guard preserves the
  # existing stricter test ceiling without reacquiring that same lock.
  env.update(HOME_RUN_MAX_MB='3840', HOME_RUN_LOCK=str(p/'test-stage.lock'), HOME_RUN_LOCK_WAIT='1')
  cmd = ['perl','scripts/run-bounded.pl',str(deadline)] + cmd
 with (p/(name+'.log')).open('wb') as log:
  try:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,env=env,timeout=deadline+(30 if name != 'build-buffered' else 0))
  except subprocess.TimeoutExpired:r=subprocess.CompletedProcess(cmd,124)
 rows.append({'name':name,'command':cmd,'exit':r.returncode,'deadline_seconds':deadline});(p/'buffered-batch-results.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,r.returncode,flush=True)
 if r.returncode:sys.exit(r.returncode)
 if name.startswith('build'):
  f=Path('zig-out/bin/home');(p/'buffered-executable.json').write_text(json.dumps({'source':subprocess.check_output(['/usr/bin/git','rev-parse','HEAD'],text=True).strip(),'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'bytes':f.stat().st_size},indent=2)+'\n')
