import vm from 'node:vm'
import {Session} from 'node:inspector/promises'
async function collect(){for(let i=0;i<20;i++){await new Promise(r=>setImmediate(r));if(globalThis.Bun)Bun.gc(true);else globalThis.gc();await new Promise(r=>setImmediate(r))}}
const weak=(()=>{const c=vm.createContext({answer:42},{name:'unobserved-timer-reference'});vm.runInContext('console.count("unobserved"); console.time("unobserved"); console.timeLog("unobserved", {answer}); console.timeEnd("unobserved")',c);return new WeakRef(c)})()
await collect();process.stdout.write('BEFORE_ATTACH='+String(weak.deref()!==undefined)+'\n')
const s=new Session();s.connect();const events=[],contexts=[];s.on('Runtime.consoleAPICalled',e=>events.push(e.params));s.on('Runtime.executionContextCreated',e=>contexts.push(e.params.context));await s.post('Runtime.enable')
process.stdout.write('REPLAY='+JSON.stringify(events)+'\n')
const realm=contexts.find(c=>c.name==='unobserved-timer-reference');if(realm) await s.post('Runtime.evaluate',{contextId:realm.id,expression:'console.clear()'})
await s.post('Runtime.releaseObjectGroup',{objectGroup:'console'});await s.post('Console.clearMessages');s.disconnect();await collect();process.stdout.write('AFTER_CLEAR='+String(weak.deref()!==undefined)+'\n');process.stdout.write('UNOBSERVED_TIMER_COMPLETE\n')
