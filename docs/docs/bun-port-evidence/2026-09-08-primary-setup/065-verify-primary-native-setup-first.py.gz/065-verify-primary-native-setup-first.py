import hashlib,json,os,shutil,signal,subprocess,tempfile,time
from pathlib import Path
root=Path.cwd();evidence=root/'zig-out/bun-port-recovery';out=evidence/'primary-native-setup-first';out.mkdir()
project=root/'packages/runtime/test';home=root/'zig-out/bin/home'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
setup=json.loads((project/'BUN_SETUP_FILES.json').read_text());pin=setup['bun_pin'];upstream=Path('/Users/chris/Code/bun')
originals={entry['path']:entry['sha256'] for entry in setup['files']}
for name in ['test/package.json','test/bun.lock','test/bunfig.toml']:
 original=subprocess.check_output(['git','-C',str(upstream),'show',f'{pin}:{name}'])
 assert (project/name).read_bytes()==original,name
 originals[name]=sha(project/name)
for path,digest in originals.items():assert sha(project/path)==digest,path
for path in originals:
 target=out/'before'/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((project/path).read_bytes())
manifest={'kind':'original primary root and test installation; no test-case credit','source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'bun_pin':pin,'home_sha256':sha(home),'original_inputs':originals,'attempts_per_install':1,'runs':[],'cleanup':[]}
def save():(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
save()
# Both top-level dependency trees are owned generated setup, not fixture trees.
for relative in ['node_modules','test/node_modules']:
 target=project/relative
 tracked=subprocess.check_output(['git','ls-files','-z','--',str(target.relative_to(root))]).split(b'\0')
 assert not any(tracked),relative
 assert not target.is_symlink(),relative
 if target.exists():
  size=sum(p.lstat().st_size for p in target.rglob('*') if not p.is_symlink() and p.is_file())
  manifest['cleanup'].append({'path':str(target),'generated_file_bytes':size});save();shutil.rmtree(target)
base=os.environ.copy()
for key in ['HOME_BUN_TEST_EXECUTABLE','HOME_CORPUS_FULL_VM','HOME_BUN_CORPUS_REPORT_DIR','HOME_CORPUS_VENDOR_PLAN_OUTPUT']:
 base.pop(key,None)
base.update(HOME_NATIVE_VM='1',CI='1',FORCE_COLOR='1',BUN_FEATURE_FLAG_INTERNAL_FOR_TESTING='1',BUN_DEBUG_QUIET_LOGS='1',BUN_GARBAGE_COLLECTOR_LEVEL='1',BUN_JSC_randomIntegrityAuditRate='1.0',BUN_RUNTIME_TRANSPILER_CACHE_PATH='0',BUN_ENABLE_CRASH_REPORTING='0')
for label,cwd in [('root-install',project),('test-install',project/'test')]:
 with tempfile.TemporaryDirectory(prefix='home-primary-setup-') as temporary:
  temporary=Path(temporary);aliases=temporary/'bin';aliases.mkdir();cache=temporary/'tmp';cache.mkdir()
  for alias in ['bun','node','home']:(aliases/alias).symlink_to(home)
  env=base.copy();env['PATH']=str(aliases)+os.pathsep+base.get('PATH','')
  for key in ['TMPDIR','BUN_TMPDIR','TEST_TMPDIR','BUN_INSTALL_CACHE_DIR']:env[key]=str(cache)
  argv=[str(home),'install'];row={'label':label,'argv':argv,'cwd':str(cwd),'timeout_ms':180000,'status':'started','aliases':{alias:sha(aliases/alias) for alias in ['bun','node','home']}}
  manifest['runs'].append(row);save();start=time.monotonic();print(label,'starting',flush=True)
  child=subprocess.Popen(argv,cwd=cwd,env=env,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
  timed_out=False
  try:stdout,stderr=child.communicate(timeout=180)
  except subprocess.TimeoutExpired:
   timed_out=True;os.killpg(child.pid,signal.SIGKILL);stdout,stderr=child.communicate()
  (out/(label+'.stdout')).write_bytes(stdout);(out/(label+'.stderr')).write_bytes(stderr)
  row.update(status='completed',returncode=child.returncode,timed_out=timed_out,seconds=time.monotonic()-start,stdout_sha256=sha(out/(label+'.stdout')),stderr_sha256=sha(out/(label+'.stderr')))
  save();print(json.dumps(row),flush=True)
changed=[]
for path,digest in originals.items():
 if not (project/path).is_file() or sha(project/path)!=digest:
  changed.append(path);target=out/'after'/path;target.parent.mkdir(parents=True,exist_ok=True)
  if (project/path).exists():target.write_bytes((project/path).read_bytes())
manifest.update(changed_inputs=changed,home_unchanged=sha(home)==manifest['home_sha256'],installs_succeeded=all(r['returncode']==0 and not r['timed_out'] for r in manifest['runs']))
(out/'setup-diff.patch').write_bytes(subprocess.check_output(['git','diff','--','packages/runtime/test']))
save();print(json.dumps({k:v for k,v in manifest.items() if k!='original_inputs'},indent=2),flush=True)
raise SystemExit(0 if manifest['installs_succeeded'] and not changed and manifest['home_unchanged'] else 1)
