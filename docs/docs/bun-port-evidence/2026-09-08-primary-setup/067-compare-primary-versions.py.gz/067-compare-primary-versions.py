import json,os,subprocess
from pathlib import Path
root=Path.cwd();out=root/'zig-out/bun-port-recovery/primary-version-control';out.mkdir()
for label,exe in [('home',str(root/'zig-out/bin/home')),('bun','/Users/chris/Code/bun/build/release/bun')]:
 env=os.environ.copy();env['HOME_NATIVE_VM']='1'
 result=subprocess.run([exe,'--print','JSON.stringify({execPath:process.execPath,versions:process.versions,release:process.release})'],env=env,capture_output=True,timeout=20)
 (out/(label+'.stdout')).write_bytes(result.stdout);(out/(label+'.stderr')).write_bytes(result.stderr)
 print(label,result.returncode,result.stdout.decode(),flush=True)
