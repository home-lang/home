import hashlib,json,os,shutil,signal,subprocess,tempfile,time
from pathlib import Path
root=Path.cwd();out=root/'zig-out/bun-port-recovery/duckdb-lifecycle-first';out.mkdir()
parent=root/'packages/runtime/test/test/node_modules/.bun/duckdb@1.3.1+d56b95ac411b1cdd/node_modules';original=parent/'duckdb'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
manifest={'kind':'isolated lifecycle failure diagnosis, not suite setup retry or passing case credit','runs':[]}
def save():(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for label,exe in [('home',root/'zig-out/bin/home'),('bun',Path('/Users/chris/Code/bun/build/release/bun'))]:
 with tempfile.TemporaryDirectory(prefix='home-duckdb-lifecycle-') as name:
  base=Path(name);modules=base/'node_modules';modules.mkdir();cwd=modules/'duckdb'
  shutil.copytree(original,cwd,symlinks=True,ignore=shutil.ignore_patterns('build','node_modules'))
  for dependency in parent.iterdir():
   if dependency.name!='duckdb':(modules/dependency.name).symlink_to(dependency.resolve(),target_is_directory=dependency.is_dir())
  aliases=base/'bin';aliases.mkdir();cache=base/'tmp';cache.mkdir()
  for alias in ['bun','node','home']:(aliases/alias).symlink_to(exe)
  env=os.environ.copy();env.update(HOME_NATIVE_VM='1',CI='1',BUN_ENABLE_CRASH_REPORTING='0',PATH=str(aliases)+os.pathsep+env.get('PATH',''),npm_config_loglevel='verbose',npm_config_devdir=str(base/'headers'))
  for key in ['TMPDIR','BUN_TMPDIR','TEST_TMPDIR','BUN_INSTALL_CACHE_DIR']:env[key]=str(cache)
  program=parent/'.bin/node-pre-gyp';argv=[str(exe),str(program),'install','--fallback-to-build']
  row={'label':label,'argv':argv,'timeout_ms':180000,'executable_sha256':sha(exe),'package_sha256':sha(cwd/'package.json'),'cwd':str(cwd),'status':'started'};manifest['runs'].append(row);save();print(label,'starting',flush=True);start=time.monotonic()
  child=subprocess.Popen(argv,cwd=cwd,env=env,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
  timed_out=False
  try:stdout,stderr=child.communicate(timeout=180)
  except subprocess.TimeoutExpired:timed_out=True;os.killpg(child.pid,signal.SIGKILL);stdout,stderr=child.communicate()
  (out/(label+'.stdout')).write_bytes(stdout);(out/(label+'.stderr')).write_bytes(stderr)
  row.update(status='completed',returncode=child.returncode,timed_out=timed_out,seconds=time.monotonic()-start,stdout_sha256=sha(out/(label+'.stdout')),stderr_sha256=sha(out/(label+'.stderr')));save();print(json.dumps(row),flush=True)
print(json.dumps(manifest,indent=2))
