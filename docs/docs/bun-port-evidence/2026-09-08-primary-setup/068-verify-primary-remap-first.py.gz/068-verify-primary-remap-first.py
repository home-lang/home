import hashlib,json,os,selectors,signal,subprocess,tempfile,time,urllib.request,urllib.error
from pathlib import Path
root=Path.cwd();evidence=root/'zig-out/bun-port-recovery';out=evidence/'primary-remap-first';out.mkdir()
setup=json.loads((evidence/'primary-native-setup-first/manifest.json').read_text())
assert setup['installs_succeeded'] and setup['home_unchanged'], 'install gate failed'
project=root/'packages/runtime/test';home=root/'zig-out/bin/home';package=project/'node_modules/bun-tracestrings'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
files={str(p.relative_to(package)):sha(p) for p in package.rglob('*') if p.is_file() and 'node_modules' not in p.relative_to(package).parts}
owned_db=[project/name for name in ['bun-remap.db','bun-remap.db-wal','bun-remap.db-shm','bun-remap.db-journal']]
assert not any(p.exists() for p in owned_db), 'refuse to reuse existing service database'
manifest={'kind':'unchanged pinned crash-remap service startup and local protocol controls; no original test-case credit','home_sha256':sha(home),'bun_pin':setup['bun_pin'],'dependency':'bun-tracestrings#912ca63e26c51429d3e6799aa2a6ab079b188fd8','dependency_source_sha256':files,'startup_deadline_ms':5000,'attempts':1,'checks':[]}
def save():(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tempfile.TemporaryDirectory(prefix='home-primary-remap-') as name:
 aliases=Path(name)/'bin';aliases.mkdir()
 for alias in ['bun','node','home']:(aliases/alias).symlink_to(home)
 env=os.environ.copy();env.update(HOME_NATIVE_VM='1',CI='true',BUN_DEBUG_QUIET_LOGS='1',NO_COLOR='1',PATH=str(aliases)+os.pathsep+env.get('PATH',''))
 argv=[str(home),'run','--silent','ci-remap-server',str(home),str(project),setup['bun_pin']]
 manifest.update(argv=argv,cwd=str(project),status='started');save();start=time.monotonic();stdout=b'';stderr=b''
 child=subprocess.Popen(argv,cwd=project,env=env,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
 selector=selectors.DefaultSelector();selector.register(child.stdout,selectors.EVENT_READ,'stdout');selector.register(child.stderr,selectors.EVENT_READ,'stderr');port=None
 try:
  while port is None and time.monotonic()-start<5 and child.poll() is None:
   for key,_ in selector.select(max(0,5-(time.monotonic()-start))):
    data=os.read(key.fileobj.fileno(),65536)
    if not data:selector.unregister(key.fileobj);continue
    if key.data=='stdout':stdout+=data
    else:stderr+=data
   for line in stdout.splitlines():
    if line.isdigit():port=int(line);break
  manifest.update(port=port,startup_seconds=time.monotonic()-start);save()
  assert port is not None and 0<port<65536,'server failed original startup deadline'
  def request(path):
   try:
    with urllib.request.urlopen(f'http://127.0.0.1:{port}'+path,timeout=5) as response:return response.status,response.read().decode()
   except urllib.error.HTTPError as error:return error.code,error.read().decode()
  for path,expected in [('/traces',(200,'[]')),('/unknown',(404,'Not found')),('/invalid-trace/ack',(200,'ok'))]:
   actual=request(path);manifest['checks'].append({'path':path,'status':actual[0],'body':actual[1],'passed':actual==expected});save();assert actual==expected
  status,body=request('/traces');trace=json.loads(body);assert status==200 and trace==[{'failed_parse':'invalid-trace'}],(status,trace)
  manifest['checks'].append({'path':'/traces','status':status,'body':trace,'passed':True});assert request('/traces')==(200,'[]')
  manifest['checks'].append({'path':'/traces','consumed_once':True,'passed':True});manifest['protocol_succeeded']=True
 except Exception as error:
  manifest.update(protocol_succeeded=False,error=str(error))
 finally:
  selector.close()
  if child.poll() is None:os.killpg(child.pid,signal.SIGTERM)
  try:remaining_out,remaining_err=child.communicate(timeout=5)
  except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);remaining_out,remaining_err=child.communicate();manifest['cleanup_required_kill']=True
  stdout+=remaining_out;stderr+=remaining_err
  (out/'stdout').write_bytes(stdout);(out/'stderr').write_bytes(stderr)
  manifest.update(status='completed',returncode=child.returncode,stdout_sha256=sha(out/'stdout'),stderr_sha256=sha(out/'stderr'),sources_unchanged=all((package/p).is_file() and sha(package/p)==digest for p,digest in files.items()),home_unchanged=sha(home)==manifest['home_sha256'])
  manifest['owned_generated_cleanup']=[]
  for path in owned_db:
   if path.exists():manifest['owned_generated_cleanup'].append({'path':str(path),'bytes':path.stat().st_size,'sha256':sha(path)});path.unlink()
  save()
print(json.dumps({k:v for k,v in manifest.items() if k!='dependency_source_sha256'},indent=2))
raise SystemExit(0 if manifest.get('protocol_succeeded') and manifest['sources_unchanged'] and manifest['home_unchanged'] else 1)
