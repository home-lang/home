from pathlib import Path
import subprocess,os,json
p=Path('zig-out/inspector-session-2026-10-12');rows=[]
for name in ['reference','session-routing','native-inspector-session']:
 with (p/(name+'-prototype.log')).open('wb') as log:r=subprocess.run(['./zig-out/bin/home','run',str(p/(name+'.mjs'))],stdout=log,stderr=subprocess.STDOUT,env=os.environ.copy(),timeout=60)
 rows.append({'file':name,'exit':r.returncode});print(name,r.returncode,flush=True)
(p/'core-controls.json').write_text(json.dumps(rows,indent=2)+'\n')
