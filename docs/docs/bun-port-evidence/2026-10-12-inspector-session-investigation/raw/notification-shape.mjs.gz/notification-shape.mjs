import {Session} from 'node:inspector/promises'
const session=new Session();session.connect();const notifications=[];session.on('inspectorNotification',message=>notifications.push({method:message.method,paramKeys:Object.keys(message.params||{})}));await session.post('Runtime.enable');await new Promise(resolve=>setImmediate(resolve));console.log(JSON.stringify(notifications));session.disconnect()
