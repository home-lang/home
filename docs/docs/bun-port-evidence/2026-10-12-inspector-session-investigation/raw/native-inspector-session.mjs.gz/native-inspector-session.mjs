import assert from 'node:assert/strict'
import {Session} from 'node:inspector/promises'
import {Session as CallbackSession} from 'node:inspector'
const session=new Session();session.connect();assert.throws(()=>session.connect(),{code:'ERR_INSPECTOR_ALREADY_CONNECTED'})
const notifications=[];session.on('inspectorNotification',message=>notifications.push(message))
await session.post('Runtime.enable')
assert.equal((await session.post('Runtime.evaluate',{expression:'21*2',returnByValue:true})).result.value,42)
assert(notifications.some(message=>message.method==='Runtime.executionContextCreated'))
assert.throws(()=>session.connectToMainThread(),{code:'ERR_INSPECTOR_NOT_WORKER'})
const callbacks=new CallbackSession();callbacks.connect()
let called=false
callbacks.post('Runtime.evaluate',{expression:'6*7',returnByValue:true},(error,result)=>{assert.equal(error,null);assert.equal(result.result.value,42);called=true;callbacks.disconnect()})
assert(called)
session.disconnect();session.disconnect();session.connect()
assert.equal((await session.post('Runtime.evaluate',{expression:'2+3',returnByValue:true})).result.value,5)
session.disconnect()
console.log('native inspector dispatch, notification, reconnect and callback disconnect passed')
