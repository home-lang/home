from pathlib import Path
import subprocess,json,hashlib,os,sys
root=Path.cwd();p=root/'zig-out/inspector-session-2026-10-12';zig=str(root/'zig-out/toolchains/zig-aarch64-macos-0.17.0-dev.2163+89ff10d56/zig');rows=[]
for name,backup in [('HomeCPUProfilerState.h','HomeCPUProfilerState.before.h'),('BunCPUProfiler.cpp','BunCPUProfiler.before.cpp')]:
 source=root/'packages/runtime/upstream/src/jsc/bindings'/name;original=(p/backup).read_bytes();assert source.read_bytes()==original;marker=('// Home generation input probe: '+name+'\n').encode()
 try:
  source.write_bytes(original+marker)
  with (p/('input-probe-'+name+'.log')).open('wb') as log:r=subprocess.run([zig,'build','native-runtime-modules','-Denable_jsc=true','-j1','--summary','all'],cwd=root,env=os.environ.copy(),stdout=log,stderr=subprocess.STDOUT,timeout=120)
  assert r.returncode==0,name
  copies=list((root/'.zig-cache/o').glob('*/native-modules/'+name));matching=[x for x in copies if marker in x.read_bytes()];assert matching,name
  rows.append({'file':name,'probe_exit':r.returncode,'generated_marker_copies':len(matching),'original_sha256':hashlib.sha256(original).hexdigest()})
 finally:source.write_bytes(original)
with (p/'input-probe-restored.log').open('wb') as log:r=subprocess.run([zig,'build','native-runtime-modules','-Denable_jsc=true','-j1','--summary','all'],cwd=root,env=os.environ.copy(),stdout=log,stderr=subprocess.STDOUT,timeout=120)
assert r.returncode==0
for name,backup in [('HomeCPUProfilerState.h','HomeCPUProfilerState.before.h'),('BunCPUProfiler.cpp','BunCPUProfiler.before.cpp')]:
 original=(p/backup).read_bytes();assert (root/'packages/runtime/upstream/src/jsc/bindings'/name).read_bytes()==original
 copies=list((root/'.zig-cache/o').glob('*/native-modules/'+name));assert any(x.read_bytes()==original or x.read_bytes().endswith(original) for x in copies)
(p/'input-probe.json').write_text(json.dumps({'rows':rows,'restored_generation_exit':r.returncode},indent=2)+'\n');print('Header-only and source-only edits regenerated owned inputs; source bytes restored',flush=True)
