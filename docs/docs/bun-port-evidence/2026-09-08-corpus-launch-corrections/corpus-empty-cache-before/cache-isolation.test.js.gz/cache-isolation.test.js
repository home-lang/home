import { test, expect } from "bun:test";
import { readdirSync } from "node:fs";
test("fresh install cache contains no command aliases", () => {
  console.log("cache entries=" + JSON.stringify(readdirSync(process.env.BUN_INSTALL_CACHE_DIR)));
  expect(readdirSync(process.env.BUN_INSTALL_CACHE_DIR)).toEqual([]);
});
