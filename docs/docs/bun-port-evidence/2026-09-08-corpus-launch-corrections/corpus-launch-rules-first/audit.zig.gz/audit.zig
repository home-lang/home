const std = @import("std");
const launch = @import("corpus_launch.zig");
test "production launch rules match pinned runner across the full inventory" {
    const Row = struct { file: launch.File, executable: []const u8, expected: launch.Profile };
    const rows = try std.json.parseFromSlice([]Row, std.testing.allocator, @embedFile("expected.json"), .{});
    defer rows.deinit();
    for (rows.value, 0..) |row, index| {
        const actual = launch.profile(row.file, row.executable);
        std.testing.expectEqualDeep(row.expected, actual) catch |err| {
            std.debug.print("LAUNCH_MISMATCH row={d} path={s} executable={s} ci={} asan_step={}\n", .{index, row.file.relative_path, row.executable, row.file.is_ci, row.file.asan_step});
            return err;
        };
    }
    std.debug.print("LAUNCH_AUDIT {d} rule selections matched\n", .{rows.value.len});
}
