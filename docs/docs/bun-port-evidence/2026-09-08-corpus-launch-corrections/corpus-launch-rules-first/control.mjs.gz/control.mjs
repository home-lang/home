import { readFileSync } from 'node:fs';
const testTimeout = 180000, integrationTimeout = 300000;
let isCI = true, options = {};
function getTestTimeout(testPath) {
  if (
    /integration|3rd_party|docker|bun-install-registry|bun-security-scanner-matrix|v8|bundler_compile|tonic|test[\\/]napi/i.test(
      testPath,
    )
  ) {
    return integrationTimeout;
  }
  return testTimeout;
}
function getNodeParallelTestTimeout(testPath) {
  if (testPath.includes("test-dns")) return 60_000;
  if (testPath.includes("test-cluster-")) return 60_000; // cluster IPC + socket-handle passing is process-heavy under runner concurrency
  if (testPath.includes("-docker-")) return 60_000;
  if (testPath.includes("test-stdin-pipe-large")) return 60_000; // pipes 1MB stdin->stdout through an extra child process; slow under runner concurrency
  if (!isCI) return 60_000; // everything slower in debug mode
  if (options["step"]?.includes("-asan-")) return 60_000;
  return 20_000;
}
const entries = JSON.parse(readFileSync(new URL('./entries.json', import.meta.url)));
const result = [];
for (const context of [
  {is_ci:true, asan:false, asan_step:false},
  {is_ci:true, asan:true, asan_step:false},
  {is_ci:true, asan:true, asan_step:true},
  {is_ci:false, asan:false, asan_step:false},
]) {
  isCI = context.is_ci;
  options = {step: context.asan_step ? 'test-asan-linux' : 'test-linux'};
  for (const entry of entries) {
    const node = entry.node_test, test = entry.mode === 'test';
    const timeout = getTestTimeout('test/' + entry.path);
    result.push({
      file: {relative_path:entry.path, node_test:node, test_runner:test, is_ci:isCI, asan_step:context.asan_step},
      executable: context.asan ? '/bin/home-asan' : '/bin/home',
      expected: {
        file_timeout_ms: node ? getNodeParallelTestTimeout('test/' + entry.path) : test ? timeout * (context.asan ? 2 : 1) : 30000,
        test_timeout_ms: !node && test ? Math.ceil(timeout / 2) * (context.asan ? 3 : 1) : null,
        node_test:node,
        validate_runtime:context.asan || !isCI,
        no_orphans:context.asan && !node,
      }
    });
  }
}
console.log(JSON.stringify(result));
