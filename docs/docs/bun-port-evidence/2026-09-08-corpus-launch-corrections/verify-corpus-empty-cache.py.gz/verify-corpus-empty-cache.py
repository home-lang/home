from pathlib import Path
import hashlib,json,os,shutil,subprocess,tempfile,time
root=Path.cwd();ev=(root/'zig-out/bun-port-recovery').resolve();out=ev/'corpus-empty-cache-before';out.mkdir(exist_ok=False)
fixture=Path(tempfile.mkdtemp(prefix='home-corpus-cache-control-'));project=fixture/'packages/runtime/test';source=project/'test/cache-isolation.test.js';source.parent.mkdir(parents=True);(project/'bunfig.toml').write_text('[test]\n')
source.write_text('''import { test, expect } from "bun:test";
import { readdirSync } from "node:fs";
test("fresh install cache contains no command aliases", () => {
  console.log("cache entries=" + JSON.stringify(readdirSync(process.env.BUN_INSTALL_CACHE_DIR)));
  expect(readdirSync(process.env.BUN_INSTALL_CACHE_DIR)).toEqual([]);
});
''')
(out/'cache-isolation.test.js').write_bytes(source.read_bytes());rows=[]
try:
 for name,exe in [('home',root/'zig-out/bin/home'),('bun',Path('/Users/chris/Code/bun/build/release/bun'))]:
  temp=fixture/(name+'-tmp');temp.mkdir();env=os.environ.copy()
  for k in ['HOME_NATIVE_VM','HOME_CORPUS_FULL_VM','HOME_BUN_TEST_EXECUTABLE']:env.pop(k,None)
  env.update(TMPDIR=str(temp),BUN_TMPDIR=str(temp),TEST_TMPDIR=str(temp),BUN_INSTALL_CACHE_DIR=str(temp),CI='true',GITHUB_ACTIONS='true',BUN_GARBAGE_COLLECTOR_LEVEL='1',BUN_JSC_randomIntegrityAuditRate='1.0',BUN_RUNTIME_TRANSPILER_CACHE_PATH='0')
  args=[str(exe),'test',str(source)] if name=='home' else [str(exe),'test','--config='+str(project/'bunfig.toml'),'--timeout=90000',str(source)]
  log=out/(name+'.log');start=time.monotonic()
  with log.open('xb') as stream:result=subprocess.run(['perl',str(root/'scripts/run-bounded.pl'),'210',*args],cwd=root if name=='home' else project,env=env,stdout=stream,stderr=subprocess.STDOUT)
  row={'runtime':name,'argv':args,'executable_sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'exit_code':result.returncode,'seconds':time.monotonic()-start,'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()};rows.append(row);print(json.dumps(row),flush=True)
finally:shutil.rmtree(fixture)
(out/'manifest.json').write_text(json.dumps({'status':'Real generated regression, not an original corpus test. First implementation incorrectly places aliases in the cache; expected baseline Home failure and Bun pass.','results':rows},indent=2)+'\n')
raise SystemExit(int(any(r['exit_code'] for r in rows)))
