import assert from 'node:assert/strict'
import {Session} from 'node:inspector'
const s=new Session();assert.throws(()=>s.post('Runtime.enable'),{code:'ERR_INSPECTOR_NOT_CONNECTED'});s.connect();assert.throws(()=>s.post(17),{code:'ERR_INVALID_ARG_TYPE'})
let nested=false
s.post('Runtime.evaluate',{expression:'1+1',returnByValue:true},(error,result)=>{assert.equal(error,null);assert.equal(result.result.value,2);s.post('Runtime.evaluate',{expression:'2+2',returnByValue:true},(error,inner)=>{assert.equal(error,null);assert.equal(inner.result.value,4);nested=true})})
assert(nested);s.disconnect();s.connect();let callback=false;s.post('Runtime.evaluate',{expression:'3+3',returnByValue:true},(error,result)=>{assert.equal(error,null);assert.equal(result.result.value,6);callback=true;s.disconnect()});assert(callback)
console.log('inspector input validation, reentrant post and callback disconnect passed')
