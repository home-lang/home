import assert from 'node:assert/strict'
import {Session} from 'node:inspector'
const first=new Session(),second=new Session();first.connect();second.connect()
let firstValue,secondValue
first.post('Runtime.evaluate',{expression:'21*2',returnByValue:true},(error,result)=>{assert.equal(error,null);firstValue=result.result.value})
second.post('Runtime.evaluate',{expression:'5*5',returnByValue:true},(error,result)=>{assert.equal(error,null);secondValue=result.result.value})
assert.equal(firstValue,42);assert.equal(secondValue,25);first.disconnect();second.disconnect()
console.log('independent inspector session response IDs passed')
