from pathlib import Path
import subprocess,json,os,sys
p=Path('zig-out/inspector-agents-2026-10-12');rows=[]
commands=[['./zig-out/bin/home','run',str(p/'reference.mjs')],['./zig-out/bin/home','run',str(p/'session-routing.mjs')],['./zig-out/bin/home','run',str(p/'runtime-boundaries.mjs')],['./zig-out/bin/home','run',str(p/'profile-sessions.mjs')],['./zig-out/bin/home','run',str(p/'last-frontend.mjs')],[sys.executable,str(p/'run-corpus.py'),'original-main'],[sys.executable,str(p/'run-native.py'),'native-main'],['./zig-out/bin/home','run','tests/runtime/native-profiling-cli.test.mjs'],['/Users/chris/.bun/bin/bun','test','build-support/native_module_abi.test.ts','build-support/core_builtin_abi.test.ts','build-support/builtin_exports.test.ts'],[sys.executable,'-B','scripts/test_summarize_bun_corpus.py']]
for index,command in enumerate(commands,1):
 with (p/f'main-validation-{index}.log').open('wb') as log:r=subprocess.run(command,env=os.environ.copy(),stdout=log,stderr=subprocess.STDOUT,timeout=1200)
 rows.append({'command':command,'exit':r.returncode});(p/'main-validation.json').write_text(json.dumps(rows,indent=2)+'\n');print(index,r.returncode,flush=True)
 if r.returncode:sys.exit(r.returncode)
