from pathlib import Path
import subprocess,os,json
p=Path('zig-out/inspector-agents-2026-10-12');rows=[]
for name in ['reference','session-routing','native-inspector-session','profile-sessions']:
 with (p/(name+'.log')).open('wb') as log:r=subprocess.run(['./zig-out/bin/home','run',str(p/(name+'.mjs'))],env=os.environ.copy(),stdout=log,stderr=subprocess.STDOUT,timeout=60)
 rows.append({'file':name,'exit':r.returncode});print(name,r.returncode,flush=True)
(p/'core-results.json').write_text(json.dumps(rows,indent=2)+'\n')
