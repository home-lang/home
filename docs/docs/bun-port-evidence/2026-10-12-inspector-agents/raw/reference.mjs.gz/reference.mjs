import assert from 'node:assert/strict'
import { Session } from 'node:inspector/promises'
const session=new Session();session.connect()
const notices=[];session.on('inspectorNotification',message=>notices.push(message))
await session.post('Runtime.enable')
const result=await session.post('Runtime.evaluate',{expression:'21*2',returnByValue:true})
assert.equal(result.result.value,42)
assert(notices.some(message=>message.method==='Runtime.executionContextCreated'))
session.disconnect();session.disconnect();session.connect()
assert.equal((await session.post('Runtime.evaluate',{expression:'6*7',returnByValue:true})).result.value,42)
session.disconnect()
console.log('real local inspector evaluation, notifications and reconnect passed')
