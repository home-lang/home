import assert from 'node:assert/strict'
import {Session} from 'node:inspector/promises'
const first=new Session(),second=new Session();first.connect();second.connect();await first.post('Runtime.enable');await second.post('Runtime.enable');first.disconnect()
assert.equal((await second.post('Runtime.evaluate',{expression:'40+2',returnByValue:true})).result.value,42);second.disconnect()
console.log('remaining frontend stays enabled when another disconnects')
