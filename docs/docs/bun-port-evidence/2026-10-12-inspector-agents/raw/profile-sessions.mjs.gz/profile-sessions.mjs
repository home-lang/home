import assert from 'node:assert/strict'
import {Session} from 'node:inspector/promises'
const first=new Session(),second=new Session();first.connect();second.connect();await first.post('Profiler.enable');await second.post('Profiler.enable');await first.post('Profiler.start');await second.post('Profiler.start')
function sampledOwnerWork(){let n=0;for(let i=0;i<1000;i++)n+=Math.sqrt(i);return n}
let deadline=performance.now()+150;while(performance.now()<deadline)sampledOwnerWork()
const one=await first.post('Profiler.stop');assert(one.profile.samples.length>0);first.disconnect()
deadline=performance.now()+150;while(performance.now()<deadline)sampledOwnerWork()
const two=await second.post('Profiler.stop');assert(two.profile.samples.length>0);assert(two.profile.nodes.some(node=>node.callFrame.functionName==='sampledOwnerWork'));const frame=two.profile.nodes.find(node=>node.callFrame.functionName==='sampledOwnerWork').callFrame;assert.equal(frame.lineNumber,3);assert(/^\d+$/.test(frame.scriptId));assert(two.profile.timeDeltas.every(Number.isInteger));assert(Number.isInteger(two.profile.startTime));assert(Number.isInteger(two.profile.endTime));assert(two.profile.endTime>=two.profile.startTime);second.disconnect()
console.log('actual sampled profiles and independent session stop passed')
