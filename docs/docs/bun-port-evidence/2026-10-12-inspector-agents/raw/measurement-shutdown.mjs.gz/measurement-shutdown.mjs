import assert from 'node:assert/strict'
import {Worker} from 'node:worker_threads'
const worker=new Worker(`const {parentPort}=require('node:worker_threads');require('node:vm').measureMemory();parentPort.on('message',()=>{});parentPort.postMessage('pending')`,{eval:true})
await new Promise((resolve,reject)=>{worker.once('message',resolve);worker.once('error',reject)})
console.log('measurement request admitted')
const code=await worker.terminate();assert.equal(typeof code,'number')
console.log('measurement worker termination completed')
