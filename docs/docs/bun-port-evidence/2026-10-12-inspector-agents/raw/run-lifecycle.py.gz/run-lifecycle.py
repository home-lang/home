from pathlib import Path
import subprocess,json,os
p=Path('zig-out/inspector-agents-2026-10-12');rows=[]
for name,source in [('profiling','tests/runtime/native-profiling-cli.test.mjs'),('boundaries',str(p/'runtime-boundaries.mjs')),('last-frontend',str(p/'last-frontend.mjs')),('profile-sessions',str(p/'profile-sessions.mjs'))]:
 with (p/(name+'-lifecycle.log')).open('wb') as log:r=subprocess.run(['./zig-out/bin/home','run',source],env=os.environ.copy(),stdout=log,stderr=subprocess.STDOUT,timeout=120)
 rows.append({'file':name,'exit':r.returncode});print(name,r.returncode,flush=True)
 (p/'lifecycle-results.json').write_text(json.dumps(rows,indent=2)+'\n')
 if r.returncode:break
