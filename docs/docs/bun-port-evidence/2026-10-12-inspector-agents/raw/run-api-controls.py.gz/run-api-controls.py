from pathlib import Path
import subprocess,json,os
p=Path('zig-out/inspector-agents-2026-10-12');rows=[]
commands=[('shutdown',['./zig-out/bin/home','run',str(p/'measurement-shutdown.mjs')]),('profiles',['./zig-out/bin/home','run',str(p/'profile-sessions.mjs')]),('maintained',['./zig-out/bin/home','run','tests/runtime/native-profiling-cli.test.mjs']),('memory',['./zig-out/bin/home','run','tests/runtime/native-vm-memory.test.mjs'])]
for name,command in commands:
 with (p/(name+'-api-control.log')).open('wb') as log:
  try:r=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,env=os.environ.copy(),timeout=90);code=r.returncode
  except subprocess.TimeoutExpired:code=124
 rows.append({'name':name,'exit':code});(p/'api-control-results.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,code,flush=True)
 if code:break
