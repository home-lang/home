from pathlib import Path
import subprocess,os,json
p=Path(__file__).resolve().parent;rows=[]
for name in ['terminal-diagnostic.mjs','reference.mjs']:
 with (p/('repair-'+name+'.log')).open('wb') as log:r=subprocess.run(['./zig-out/bin/home',str(p/name)],env=os.environ,stdout=log,stderr=subprocess.STDOUT,timeout=30)
 rows.append({'file':name,'exit':r.returncode});print(name,r.returncode,flush=True)
(p/'diagnostic-results.json').write_text(json.dumps(rows,indent=2)+'\n')
