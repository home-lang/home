import { createServer } from 'node:http';import {once} from 'node:events';import {performance,PerformanceObserver} from 'node:perf_hooks';
const events=[];const observer=new PerformanceObserver(list=>events.push(...list.getEntries().map(e=>e.toJSON())));observer.observe({type:'resource'});
const server=createServer((req,res)=>{res.writeHead(200,{'content-type':'text/plain'});res.write('partial');});server.listen(0,'127.0.0.1');await once(server,'listening');const base=`http://127.0.0.1:${server.address().port}`;
for(const mode of ['cancel','abort']){const controller=new AbortController();const response=await fetch(base+'/'+mode,{signal:controller.signal});if(mode==='cancel')await response.body.cancel();else{controller.abort();try{await response.text()}catch{}}
await new Promise(r=>setTimeout(r,100));process.stdout.write(JSON.stringify({mode,entries:performance.getEntriesByName(base+'/'+mode,'resource').map(e=>e.toJSON()),events:events.filter(e=>e.name===base+'/'+mode)})+'\n');}
observer.disconnect();server.closeAllConnections();await new Promise(r=>server.close(r));
