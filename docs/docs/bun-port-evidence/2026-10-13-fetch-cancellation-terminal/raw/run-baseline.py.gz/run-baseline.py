from pathlib import Path
import subprocess,os,json
p=Path(__file__).resolve().parent;rows=[]
for runtime,exe in [('node','node'),('home','./zig-out/bin/home')]:
 with (p/(runtime+'.log')).open('wb') as log:
  try:r=subprocess.run([exe,str(p/'reference.mjs')],env=os.environ,stdout=log,stderr=subprocess.STDOUT,timeout=20)
  except subprocess.TimeoutExpired:r=subprocess.CompletedProcess([],124)
 rows.append({'runtime':runtime,'exit':r.returncode});print(runtime,r.returncode,flush=True)
(p/'results.json').write_text(json.dumps(rows,indent=2)+'\n')
