from pathlib import Path
import subprocess,json,os,sys,hashlib
p=Path(__file__).resolve().parent;rows=[]
commands=[['./zig-out/bin/home','tests/runtime/native-fetch-cancellation-terminal.test.mjs'],['./zig-out/bin/home','tests/runtime/native-fetch-resource-timing.test.mjs'],['./zig-out/bin/home','tests/runtime/native-fetch-connection-timing.test.mjs'],['./zig-out/bin/home','tests/runtime/native-stream-cancellation.test.mjs'],['./zig-out/bin/home','tests/runtime/native-inspector-context-events.test.mjs'],['./zig-out/bin/home',str(p/'reference.mjs')]]
for i,c in enumerate(commands,1):
 with (p/f'focused-{i}.log').open('wb') as log:
  try:r=subprocess.run(c,env=os.environ.copy(),stdout=log,stderr=subprocess.STDOUT,timeout=120)
  except subprocess.TimeoutExpired:r=subprocess.CompletedProcess(c,124)
 rows.append({'command':c,'exit':r.returncode});(p/'focused-results.json').write_text(json.dumps(rows,indent=2)+'\n');print(i,r.returncode,flush=True)
 if r.returncode:sys.exit(r.returncode)
