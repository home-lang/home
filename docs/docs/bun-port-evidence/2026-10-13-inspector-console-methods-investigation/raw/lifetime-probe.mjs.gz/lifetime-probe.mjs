import vm from 'node:vm'
import { Session } from 'node:inspector/promises'
const session = new Session(); session.connect()
const contexts = [], events = []
session.on('Runtime.executionContextCreated', e => contexts.push(e.params.context))
session.on('Runtime.consoleAPICalled', e => events.push(e.params))
await session.post('Runtime.enable')
async function collect() {
 for(let i=0;i<20;i++) { await new Promise(r=>setImmediate(r)); if(globalThis.Bun) Bun.gc(true); else globalThis.gc(); await new Promise(r=>setImmediate(r)); }
}
const reference=(()=>{const context=vm.createContext({}, {name:'console-retirement'});vm.runInContext('console.log({answer:42})',context);return new WeakRef(context)})()
const realm=contexts.find(c=>c.name==='console-retirement')
const event=events.find(e=>e.executionContextId===realm.id)
process.stdout.write('EVENT='+JSON.stringify(event)+'\n')
await collect()
process.stdout.write('BEFORE_RELEASE='+String(reference.deref()!==undefined)+'\n')
if(event?.args[0]?.objectId) {
 const result=await session.post('Runtime.getProperties',{objectId:event.args[0].objectId,ownProperties:true})
 process.stdout.write('ANSWER='+String(result.result.find(p=>p.name==='answer')?.value?.value)+'\n')
}
await session.post('Runtime.releaseObjectGroup',{objectGroup:'console'})
await collect()
process.stdout.write('AFTER_RELEASE='+String(reference.deref()!==undefined)+'\n')
await session.post('Console.clearMessages')
await collect()
process.stdout.write('AFTER_CLEAR='+String(reference.deref()!==undefined)+'\n')
session.disconnect(); await collect()
process.stdout.write('AFTER_DISCONNECT='+String(reference.deref()!==undefined)+'\n')
process.stdout.write('LIFETIME_PROBE_COMPLETE\n')
