import assert from 'node:assert/strict'
import * as fs from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
const base=fs.mkdtempSync(join(tmpdir(),'home-directory-identity-'))
try {
 for(const mode of ['sync','async']) {
  const path=join(base,mode), moved=path+'-moved'
  fs.mkdirSync(path);fs.writeFileSync(join(path,'entry.txt'),'entry')
  const dir=mode==='sync'?fs.opendirSync(path):await fs.promises.opendir(path)
  fs.renameSync(path,moved)
  fs.mkdirSync(path);fs.writeFileSync(join(path,'replacement.txt'),'replacement')
  const entries=[]
  for(;;){const entry=mode==='sync'?dir.readSync():await dir.read();if(!entry)break;assert(entry instanceof fs.Dirent);entries.push(entry.name);assert(entry.isFile())}
  assert.deepEqual(entries,['entry.txt'])
  assert.equal(dir.path,path)
  if(mode==='sync')dir.closeSync();else await dir.close()
  assert.throws(()=>dir.readSync(),{code:'ERR_DIR_CLOSED'})
 }
 console.log('opened directory identity survives rename and replacement for sync and async reads')
} finally {fs.rmSync(base,{recursive:true,force:true})}
