from pathlib import Path
import os,subprocess,sys,json
root=Path(__file__).resolve().parents[2];task=Path(__file__).resolve().parent
zig=root/'zig-out/toolchains/zig-aarch64-macos-0.17.0-dev.2163+89ff10d56/zig';bun=Path('/Users/chris/.bun/bin/bun')
steps=[['./zig-out/bin/home','run',str(task/'directory-reference.mjs')],['./zig-out/bin/home','run',str(task/'directory-lifecycle-reference.mjs')],[sys.executable,str(task/'run-native.py'),'native-final'],[sys.executable,str(task/'run-corpus.py'),'original-final'],[sys.executable,str(task/'run-config-controls.py')],[str(bun),'test','build-support/native_module_abi.test.ts','build-support/core_builtin_abi.test.ts','build-support/builtin_exports.test.ts'],[str(zig),'test','build-support/native_bindings.zig'],[sys.executable,'-B','scripts/test_summarize_bun_corpus.py'],[sys.executable,str(task/'validate-all-reports.py')]]
rows=[]
for i,command in enumerate(steps):
 with (task/f'validation-step-{i+1}.log').open('wb') as log:
  result=subprocess.run(command,cwd=root,env=os.environ.copy(),stdout=log,stderr=subprocess.STDOUT)
 rows.append({'command':command,'exit':result.returncode});(task/'validation-summary.json').write_text(json.dumps(rows,indent=2)+'\n');print('step',i+1,result.returncode,flush=True)
 if result.returncode:sys.exit(result.returncode)
