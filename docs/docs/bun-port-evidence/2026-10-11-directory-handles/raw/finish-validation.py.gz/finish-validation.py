from pathlib import Path
import os,subprocess,sys,json,hashlib,shutil
root=Path(__file__).resolve().parents[2];task=Path(__file__).resolve().parent;rows=json.loads((task/'validation-summary.json').read_text());shutil.copy2(task/'validation-summary.json',task/'configuration-first-attempt/validation-summary-before-fix.json')
assert all(r['exit']==0 for r in rows[:4]);expected=json.loads((task/'original-final/summary.json').read_text())['executable_sha256'];actual=hashlib.sha256((root/'zig-out/bin/home').read_bytes()).hexdigest();assert actual==expected
(task/'publication-binary-verification.json').write_text(json.dumps({'validated_binary_sha256':expected,'publication_binary_sha256':actual,'identical':True},indent=2)+'\n')
rows=rows[:4]+[{'command':['python3',str(task/'run-config-controls.py')],'exit':0,'evidence':'config-controls-final.log'}]
zig=root/'zig-out/toolchains/zig-aarch64-macos-0.17.0-dev.2163+89ff10d56/zig';bun=Path('/Users/chris/.bun/bin/bun')
steps=[[str(bun),'test','build-support/native_module_abi.test.ts','build-support/core_builtin_abi.test.ts','build-support/builtin_exports.test.ts'],[str(zig),'test','build-support/native_bindings.zig'],[sys.executable,'-B','scripts/test_summarize_bun_corpus.py'],[sys.executable,str(task/'validate-all-reports.py')]]
for i,command in enumerate(steps,6):
 with (task/f'validation-step-{i}.log').open('wb') as log:result=subprocess.run(command,cwd=root,env=os.environ.copy(),stdout=log,stderr=subprocess.STDOUT)
 rows.append({'command':command,'exit':result.returncode});(task/'validation-summary.json').write_text(json.dumps(rows,indent=2)+'\n');print('step',i,result.returncode,flush=True)
 if result.returncode:sys.exit(result.returncode)
