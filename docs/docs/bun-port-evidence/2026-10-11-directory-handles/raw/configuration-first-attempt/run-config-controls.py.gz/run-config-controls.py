from pathlib import Path
import os,subprocess,json
root=Path(__file__).resolve().parents[2];task=Path(__file__).resolve().parent;probe=task/'sdk-probe';probe.mkdir(exist_ok=True);alias=probe/'sdk';assert not alias.exists()
zig=root/'zig-out/toolchains/zig-aarch64-macos-0.17.0-dev.2163+89ff10d56/zig';env=os.environ.copy();env['HOME_BUN_WEBKIT_LIB']=str(alias/'lib');rows=[]
for name,expected in [('missing',False),('restored',True),('removed',False)]:
 if name=='restored':alias.symlink_to('/Users/chris/.bun/build-cache/webkit-cd821fecca0d39c8-macos-arm64',target_is_directory=True)
 if name=='removed':alias.unlink()
 result=subprocess.run([str(zig),'build','--help','-Doptimize=Debug','-Dstrip=true','-Denable_jsc=true','-j1'],cwd=root,env=env,capture_output=True,text=True,timeout=180)
 (task/f'config-{name}.log').write_text(result.stdout+result.stderr)
 native='native-runtime-bindings' in result.stdout;rows.append({'phase':name,'exit':result.returncode,'native_graph_present':native,'expected':expected});print(name,result.returncode,native,flush=True)
 assert result.returncode==0 and native==expected,name
(task/'configuration-controls.json').write_text(json.dumps(rows,indent=2)+'\n')
