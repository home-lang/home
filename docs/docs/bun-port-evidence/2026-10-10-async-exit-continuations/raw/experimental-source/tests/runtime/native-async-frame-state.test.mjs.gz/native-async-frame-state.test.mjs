import assert from 'node:assert/strict'
import { AsyncLocalStorage, AsyncResource } from 'node:async_hooks'
import { exposedInternals } from 'bun:internal-for-testing'

const Frame = exposedInternals['internal/async_context_frame']
assert.equal(typeof Frame, 'function')
assert.equal(Frame.enabled, true)
assert.equal(Frame.current(), undefined)
const key = {}
const initial = new Frame(key, 'value')
assert.equal(initial.get(key), 'value')
assert.equal(Frame.current(), undefined)
assert.equal(Frame.exchange(initial), undefined)
assert.equal(Frame.current(), initial)
const nested = new Frame({}, 'second')
assert.equal(nested.get(key), 'value')
assert.equal(Frame.exchange(nested), initial)
Frame.disable(key)
assert.equal(nested.has(key), false)
assert.equal(initial.get(key), 'value')
Frame.set(initial)
await Promise.resolve()
assert.equal(Frame.current(), initial)
Frame.set(undefined)

const first = new AsyncLocalStorage()
const second = new AsyncLocalStorage()
let captured
let resource
let outsidePromise
const inside = first.run('outer', async () => {
  captured = Frame.current()
  assert(captured instanceof Frame)
  assert.equal(captured.get(first), 'outer')
  resource = new AsyncResource('home-frame')
  second.run('other', () => {
    assert.notEqual(Frame.current(), captured)
    assert.equal(Frame.current().get(first), 'outer')
    assert.equal(Frame.current().get(second), 'other')
  })
  assert.equal(Frame.current(), captured)
  first.exit(() => {
    assert.equal(first.getStore(), undefined)
    assert.equal(Frame.current().has(first), false)
    outsidePromise = Promise.resolve().then(() => {
      assert.equal(first.getStore(), undefined)
      assert.equal(Frame.current().has(first), false)
    })
  })
  assert.equal(Frame.current(), captured)
  await Promise.resolve()
  assert.equal(Frame.current(), captured)
  assert.equal(first.getStore(), 'outer')
  await new Promise(resolve => process.nextTick(() => {
    assert.equal(Frame.current(), captured)
    resolve()
  }))
  await new Promise(resolve => setTimeout(() => {
    assert.equal(Frame.current(), captured)
    resolve()
  }, 0))
})
assert.equal(Frame.current(), undefined)
await inside
await outsidePromise
assert.equal(Frame.current(), undefined)
resource.runInAsyncScope(() => {
  assert.equal(Frame.current(), captured)
  assert.equal(first.getStore(), 'outer')
})
resource.emitDestroy()
assert.equal(Frame.current(), undefined)
console.log('native materialized frame identity, exchange, stores and continuation propagation passed')
