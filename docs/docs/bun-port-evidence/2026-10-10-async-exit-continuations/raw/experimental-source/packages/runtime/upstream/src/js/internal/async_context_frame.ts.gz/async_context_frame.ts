// The frame itself occupies JSC's continuation-preserved context slot. Promise,
// timer, stream and native callback transports retain this same GC-owned value.
const { SafeMap } = require("internal/primordials");
const setAsyncHooksEnabled = $newCppFunction("NodeAsyncHooks.cpp", "jsSetAsyncHooksEnabled", 1);

class AsyncContextFrame extends SafeMap {
  static enabled = true;

  constructor(store, data) {
    super(AsyncContextFrame.current());
    this.set(store, data);
  }

  static current() {
    return $getInternalField($asyncContext, 0);
  }

  static set(frame) {
    if (frame !== undefined) setAsyncHooksEnabled(true);
    $putInternalField($asyncContext, 0, frame);
  }

  static exchange(frame) {
    const previous = AsyncContextFrame.current();
    AsyncContextFrame.set(frame);
    return previous;
  }

  static disable(store) {
    AsyncContextFrame.current()?.disable(store);
  }

  disable(store) {
    this.delete(store);
  }
}

export default AsyncContextFrame;
