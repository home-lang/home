from pathlib import Path
import json,gzip,hashlib,subprocess
root=Path(__file__).resolve().parents[2];task=Path(__file__).resolve().parent;base=root/'docs/docs/bun-port-evidence/2026-10-10-async-exit-continuations';base.mkdir(parents=True,exist_ok=True)
counts={};reports=[]
for path in sorted((task/'final').glob('validate-*.json')):
 data=json.loads(path.read_text());assert data['successful'],path
 for key,value in data['summary'].items():
  if isinstance(value,int):counts[key]=counts.get(key,0)+value
 reports.append(path.name)
assert len(reports)==14 and counts['failed']==0
records=[]
def add(path,name):
 data=path.read_bytes();target=base/(name+'.gz');target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(gzip.compress(data,mtime=0));assert gzip.decompress(target.read_bytes())==data;records.append({'path':str(target.relative_to(base)),'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
for p in sorted(task.rglob('*')):
 if not p.is_file() or p.name.startswith('issue-') or p.name=='archive-production.log':continue
 if p.suffix in ['.log','.json','.jsonl','.py','.mjs','.stdout','.stderr','.xml','.ts','.cpp','.h']:add(p,'raw/'+str(p.relative_to(task)))
for name in ['packages/runtime/upstream/src/js/node/async_hooks.ts','packages/runtime/upstream/src/jsc/bindings/AsyncContextFrame.cpp','tests/runtime/native-async-exit-continuations.test.mjs']:add(root/name,'source/'+name)
manifest={'schema':1,'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'upstream':'4982b91e3702094330f3be3883354c52b8c01323','platform':'Darwin arm64','results':{'original_files':14,'counts':counts,'native_regression_groups':11,'generation_tests':2,'generation_assertions':596,'debug_steps':35,'debug_peak_tree_mb':5642,'conformance_peak_tree_mb':175},'features':['AsyncLocalStorage.exit removes its own store from the context captured by promises, nextTick and timers while preserving other stores and outer restoration.','Captured native callback wrappers take the unwrapping path even if the tracking flag is disabled.','The previous verified binary fails the valid exit-continuation regression; the repaired binary and local Node control pass.'],'limitations':['Two upstream TODOs remain separate from passing credit.','The attempted Map-frame integration remains unresolved after native termination and is not shipped. Its source and failure evidence are preserved under experimental-source; #871 remains open.','The defensive wrapper check is not credited with resolving the Map-frame termination.','Actual internal frame materialization, createHook/native API gaps, full Bun suite and Release/ASAN/all-platform verification remain open under #66/#871.'],'files':records}
(base/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(len(records),'verified archives',counts)
