import assert from 'node:assert/strict';
import vm from 'node:vm';
import { Session } from 'node:inspector/promises';
const context=vm.createContext({reads:0},{name:'accessor-realm'});
const session=new Session();session.connect();const contexts=[];
session.on('Runtime.executionContextCreated',event=>contexts.push(event.params.context));await session.post('Runtime.enable');
for(const contextId of [undefined,contexts.find(context=>context.name==='accessor-realm').id]) {
 const object=(await session.post('Runtime.evaluate',{expression:'globalThis.inspectorAccessorReads=0; ({plain:11,get accessor(){globalThis.inspectorAccessorReads++;return 22},set setter(value){}})',contextId,objectGroup:'accessor-regression'})).result;
 const all=await session.post('Runtime.getProperties',{objectId:object.objectId,ownProperties:true});assert(all.result.some(property=>property.name==='plain'));
 const accessors=await session.post('Runtime.getProperties',{objectId:object.objectId,ownProperties:true,accessorPropertiesOnly:true});assert.deepEqual(accessors.result.map(property=>property.name).sort(),['accessor','setter']);assert(accessors.result.every(property=>property.get||property.set));
 assert.equal((await session.post('Runtime.evaluate',{expression:'inspectorAccessorReads',contextId,returnByValue:true})).result.value,0);
 await assert.rejects(session.post('Runtime.getProperties',{objectId:object.objectId,accessorPropertiesOnly:'invalid'}),error=>error.code==='ERR_INSPECTOR_COMMAND'&&error.message.includes('-32602'));
}
await session.post('Runtime.releaseObjectGroup',{objectGroup:'accessor-regression'});session.disconnect();assert.equal(vm.runInContext('reads',context),0);
console.log('owner and realm accessor-only property descriptors passed');
