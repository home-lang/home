import assert from 'node:assert/strict'
import * as fs from 'node:fs'
import {pathToFileURL} from 'node:url'
import {join} from 'node:path'
import {tmpdir} from 'node:os'
const directory=fs.mkdtempSync(join(tmpdir(),'home-watch-event-'))
try {
 const controller=new AbortController(),watcher=fs.promises.watch(pathToFileURL(directory),{encoding:'buffer',signal:controller.signal,maxQueue:16})
 const next=watcher.next();await new Promise(resolve=>setTimeout(resolve,150));fs.writeFileSync(join(directory,'ordinary.txt'),'data')
 let timer
 const result=await Promise.race([next,new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Error('ordinary watch event timeout')),5000)})]).finally(()=>clearTimeout(timer))
 assert.equal(result.done,false);assert(Buffer.isBuffer(result.value.filename));assert.equal(result.value.filename.toString(),'ordinary.txt')
 await watcher.return();assert.deepEqual(await watcher.next(),{value:undefined,done:true});controller.abort()
 console.log('URL promise watcher delivers native Buffer filename and closes on return')
}finally{fs.rmSync(directory,{recursive:true,force:true})}
