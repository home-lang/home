import assert from 'node:assert/strict'
import * as fs from 'node:fs'
import {pathToFileURL} from 'node:url'
import {join} from 'node:path'
import {tmpdir} from 'node:os'
const directory=fs.mkdtempSync(join(tmpdir(),'home-watch-event-'))
try {
 const controller=new AbortController(),watcher=fs.promises.watch(pathToFileURL(directory),{encoding:'utf8',signal:controller.signal,maxQueue:16})
 const next=watcher.next();await new Promise(resolve=>setTimeout(resolve,150));fs.writeFileSync(join(directory,'ordinary.txt'),'data')
 let timer
 const waitForFile=async()=>{let result=await next;while(!result.done&&result.value.filename!=='ordinary.txt')result=await watcher.next();return result}
 const result=await Promise.race([waitForFile(),new Promise((_,reject)=>{timer=setTimeout(()=>{controller.abort();reject(new Error('ordinary watch event timeout'))},5000)})]).finally(()=>clearTimeout(timer))
 assert.equal(result.done,false);assert.equal(typeof result.value.filename,'string');assert.equal(result.value.filename,'ordinary.txt')
 await watcher.return();assert.deepEqual(await watcher.next(),{value:undefined,done:true});controller.abort()
 console.log('URL promise watcher delivers native filename and closes on return')
}finally{fs.rmSync(directory,{recursive:true,force:true})}
