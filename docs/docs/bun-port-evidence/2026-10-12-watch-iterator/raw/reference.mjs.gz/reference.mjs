import assert from 'node:assert/strict'
import * as fs from 'node:fs'
import {pathToFileURL} from 'node:url'
import {join} from 'node:path'
import {tmpdir} from 'node:os'
const directory=fs.mkdtempSync(join(tmpdir(),'home-watch-iterator-'))
try {
 const reason=new Error('ordinary abort')
 const pre=fs.promises.watch(pathToFileURL(directory),{signal:AbortSignal.abort(reason)})
 assert.equal(typeof pre.next,'function');assert.strictEqual(pre[Symbol.asyncIterator](),pre)
 await assert.rejects(pre.next(),error=>error.name==='AbortError'&&error.cause===reason)
 assert.deepEqual(await pre.next(),{value:undefined,done:true})
 const unopened=fs.promises.watch(pathToFileURL(directory));assert.deepEqual(await unopened.return(),{value:undefined,done:true})
 const controller=new AbortController();const watcher=fs.promises.watch(pathToFileURL(directory),{signal:controller.signal})
 assert.strictEqual(watcher[Symbol.asyncIterator](),watcher)
 const next=watcher.next();controller.abort(reason)
 await assert.rejects(next,error=>error.name==='AbortError'&&error.cause===reason)
 assert.deepEqual(await watcher.next(),{value:undefined,done:true})
 console.log('promise watcher URL paths, iterator identity, unopened return and abort lifecycle passed')
}finally{fs.rmSync(directory,{recursive:true,force:true})}
