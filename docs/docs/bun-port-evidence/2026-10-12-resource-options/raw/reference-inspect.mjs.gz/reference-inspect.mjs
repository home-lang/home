import {performance} from 'node:perf_hooks'
for(const value of [undefined,0,1,1.5,'2',null,-1]){
 try{performance.setResourceTimingBufferSize(value);console.log('buffer',String(value),'ok')}catch(error){console.log('buffer',String(value),error.code,error.message)}
}
for(const value of [undefined,2,null,{toString(){return 'name'}}]){
 try{performance.clearResourceTimings(value);console.log('clear',String(value),'ok')}catch(error){console.log('clear',String(value),error.code,error.message)}
}
performance.setResourceTimingBufferSize(250)
