import vm from 'node:vm';
function make(){const first=vm.createContext({},{name:'first-dropped'});const second=vm.createContext({},{name:'second-dropped'});return [new WeakRef(first),new WeakRef(second)]}
const weak=make();for(let i=0;i<20;i++){await new Promise(r=>setImmediate(r));if(globalThis.Bun)Bun.gc(true);else globalThis.gc();await new Promise(r=>setImmediate(r));}process.stdout.write(JSON.stringify({alive:weak.map(ref=>!!ref.deref())})+'\n');
