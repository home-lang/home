from pathlib import Path
import subprocess,json,sys,os
p=Path(__file__).resolve().parent;rows=[]
for name in ['run-broadcast-focused.py','run-broad.py']:
 with (p/(name+'.log')).open('wb') as log:r=subprocess.run([sys.executable,str(p/name)],env=os.environ.copy(),stdout=log,stderr=subprocess.STDOUT,timeout=1200)
 rows.append({'driver':name,'exit':r.returncode});(p/'merged-results.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,r.returncode,flush=True)
 if r.returncode:sys.exit(r.returncode)
