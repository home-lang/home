import assert from 'node:assert/strict'
import vm from 'node:vm'
const tick=()=>new Promise(resolve=>setImmediate(resolve))
function create(kind){
 const context=vm.createContext({})
 let retained
 if(kind==='primitive') vm.runInContext('1+2',context)
 if(kind==='property') vm.runInContext('globalThis.value=42;undefined',context)
 if(kind==='closure') retained=vm.runInContext('globalThis.value=42;()=>value',context)
 if(kind==='script'){ retained=new vm.Script('globalThis.value=42;undefined'); retained.runInContext(context) }
 if(kind==='compile'){retained=vm.compileFunction('return value',[],{parsingContext:context});vm.runInContext('globalThis.value=42',context)}
 return {kind,weak:new WeakRef(context),retained}
}
const rows=['empty','primitive','property','closure','script','compile'].map(create)
for(let turn=0;turn<4;turn++){await tick();Bun.gc(true)}
for(const row of rows){
 console.log(row.kind,'cleared',row.weak.deref()===undefined)
 if(row.kind==='closure'||row.kind==='compile')assert.equal(row.retained(),42)
 if(row.kind==='script')assert.equal(row.retained.runInNewContext({}),undefined)
}
console.log('retained ordinary VM values remain callable')
