from pathlib import Path
import subprocess,os,json,sys
p=Path(__file__).resolve().parent;rows=[]
commands=[['node','--expose-gc',str(p/'multiple-context-retention.mjs')],['./zig-out/bin/home',str(p/'multiple-context-retention.mjs')],['./zig-out/bin/home','tests/runtime/native-vm-context-collection.test.mjs'],['./zig-out/bin/home','tests/runtime/native-inspector-console.test.mjs'],['./zig-out/bin/home',str(p/'console-protocol.mjs')],['./zig-out/bin/home','tests/runtime/native-inspector-context-events.test.mjs'],['./zig-out/bin/home','tests/runtime/native-inspector-async-properties.test.mjs'],['./zig-out/bin/home','tests/runtime/native-profiling-cli.test.mjs'],['./zig-out/bin/home','tests/runtime/native-fetch-cancellation-terminal.test.mjs']]
for i,c in enumerate(commands,1):
 with (p/f'revision-focused-{i}.log').open('wb') as log:
  try:r=subprocess.run(c,env=os.environ.copy(),stdout=log,stderr=subprocess.STDOUT,timeout=120)
  except subprocess.TimeoutExpired:r=subprocess.CompletedProcess(c,124)
 rows.append({'command':c,'exit':r.returncode});(p/'revision-focused-results.json').write_text(json.dumps(rows,indent=2)+'\n');print(i,r.returncode,flush=True)
 if r.returncode:sys.exit(r.returncode)
