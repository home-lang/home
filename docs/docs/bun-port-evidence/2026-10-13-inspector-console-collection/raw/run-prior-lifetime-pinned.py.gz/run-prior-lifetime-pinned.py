from pathlib import Path
import subprocess,os,json
p=Path(__file__).resolve().parent;rows=[]
for name in ['ordinary-lifetime-controls.mjs','payload-lifetime.mjs','operator-matrix.mjs','operator-matrix-reverse.mjs','operator-matrix-host-eval.mjs']:
 with (p/('prior-'+name+'.log')).open('wb') as log:
  try:r=subprocess.run([str(p/'home-revision'),str(p/('prior-'+name))],env=os.environ.copy(),stdout=log,stderr=subprocess.STDOUT,timeout=120)
  except subprocess.TimeoutExpired:r=subprocess.CompletedProcess([],124)
 rows.append({'file':name,'exit':r.returncode});print(name,r.returncode,flush=True)
(p/'prior-lifetime-results.json').write_text(json.dumps(rows,indent=2)+'\n')
