import vm from 'node:vm'
const tick=()=>new Promise(resolve=>setImmediate(resolve))
function make(source){const context=vm.createContext({});vm.runInContext(source,context);return new WeakRef(context)}
const refs=[['marker','globalThis.marker=true;undefined'],['payload','globalThis.payload=new Array(8000).fill(9);undefined']].map(([label,source])=>({label,weak:make(source)}))
for(let i=0;i<4;i++){await tick();Bun.gc(true)}
const result=await vm.measureMemory({mode:'detailed',execution:'eager'})
console.log('remaining contexts',result.other.length)
for(const row of refs)console.log(row.label,'cleared',row.weak.deref()===undefined)
