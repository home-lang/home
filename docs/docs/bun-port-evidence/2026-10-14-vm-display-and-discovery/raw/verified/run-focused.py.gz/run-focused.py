from pathlib import Path
import subprocess,json,os,hashlib,sys
p=Path(__file__).resolve().parent;root=p.parents[2];env=os.environ.copy();env['BUN_DEBUG_QUIET_LOGS']='1'
commands=[('node-memory',['node','--expose-gc','tests/runtime/native-vm-memory.test.mjs']),('home-memory',['zig-out/bin/home','tests/runtime/native-vm-memory.test.mjs']),('home-collection',['zig-out/bin/home','tests/runtime/native-vm-context-collection.test.mjs']),('home-console',['zig-out/bin/home','tests/runtime/native-inspector-console.test.mjs']),('home-display-probe',['zig-out/bin/home',str(p.parent/'display/probe.mjs')]),('home-nested-display-probe',['zig-out/bin/home',str(p.parent/'display/nested-probe.mjs')])]
rows=[]
for name,args in commands:
 with (p/(name+'.log')).open('wb') as log:
  try:r=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,cwd=root,env=env,timeout=240)
  except subprocess.TimeoutExpired:r=subprocess.CompletedProcess(args,124)
 rows.append({'name':name,'argv':args,'exit':r.returncode});(p/'focused-results.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,r.returncode,flush=True)
(p/'executable.json').write_text(json.dumps({'sha256':hashlib.sha256((root/'zig-out/bin/home').read_bytes()).hexdigest(),'bytes':(root/'zig-out/bin/home').stat().st_size},indent=2)+'\n')
assert all(row['exit']==0 for row in rows),rows
