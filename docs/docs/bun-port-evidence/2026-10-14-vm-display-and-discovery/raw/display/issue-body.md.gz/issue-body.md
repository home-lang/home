Tracked from #66 and #891.

The native Script runner parses displayErrors but always calls the VM stack decorator. As a result, displayErrors:false still prefixes the source filename/line and source text in runInThisContext, runInContext and runInNewContext. It also invokes a user-defined error.stack getter that Node leaves untouched when decoration is disabled.

Acceptance: default/true retain source decoration; false preserves the original thrown error and avoids stack getter reads; nested boundaries decorate only when enabled and at most once. Node v26.10.0 diagnostics establish all 14 method/nesting/getter outcomes.

The owned runner now gates decoration on the parsed option, with regression coverage. Build and validation are in progress. Baseline discovery covers every one of the 97 unchanged pinned parallel test-vm files, plus two Bun-specific VM files. The additional context/module, watchdog/microtask timeout, memory, SIGINT, caught-parse-error and low-stack batches all passed unchanged at baseline. Full suite/platform acceptance remains tracked in #66.
