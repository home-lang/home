import vm from 'node:vm'
const rows=[]
for(const [method,run] of [['this', (script, options)=>script.runInThisContext(options)],['context',(script,options)=>script.runInContext(vm.createContext({}),options)],['new',(script,options)=>script.runInNewContext({},options)]])for(const displayErrors of [undefined,true,false]){
 const source='throw new Error("display marker")';const script=new vm.Script(source,{filename:'display-probe.vm'});try{run(script,{displayErrors})}catch(e){rows.push({method,display:String(displayErrors),name:e.name,message:e.message,decorated:e.stack.startsWith('display-probe.vm:1\n'),sourceLine:e.stack.includes(source+'\n')})}
}
console.log(JSON.stringify(rows,null,2))
