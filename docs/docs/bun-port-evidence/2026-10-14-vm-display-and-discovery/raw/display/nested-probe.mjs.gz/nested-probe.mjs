import vm from 'node:vm'
const rows=[]
for(const innerDisplay of [false,true])for(const outerDisplay of [false,true]){
 const context=vm.createContext({inner(){new vm.Script('throw new Error("nested display")',{filename:'inner-display.vm'}).runInThisContext({displayErrors:innerDisplay})}})
 try{new vm.Script('inner()',{filename:'outer-display.vm'}).runInContext(context,{displayErrors:outerDisplay})}catch(e){rows.push({innerDisplay,outerDisplay,decorated:e.stack.startsWith('inner-display.vm:1\n'),headers:(e.stack.match(/inner-display\.vm:1\n/g)||[]).length})}
}
const marker=new Error('stack getter marker');let reads=0;Object.defineProperty(marker,'stack',{get(){reads++;throw new Error('stack getter executed')}});const context=vm.createContext({marker});try{new vm.Script('throw marker').runInContext(context,{displayErrors:false})}catch(e){rows.push({name:'identity and getter suppression',same:e===marker,reads})}
console.log(JSON.stringify(rows,null,2))
