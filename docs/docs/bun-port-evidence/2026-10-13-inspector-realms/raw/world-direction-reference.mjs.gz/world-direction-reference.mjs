import assert from 'node:assert/strict';
import vm from 'node:vm';
import { Session } from 'node:inspector/promises';
const realm = vm.createContext({value: 11}, {name: 'argument-direction'});
const session = new Session(); session.connect(); const contexts = [];
session.on('Runtime.executionContextCreated', event => contexts.push(event.params.context));
await session.post('Runtime.enable');
const id = contexts.find(context => context.name === 'argument-direction').id;
const owner = (await session.post('Runtime.evaluate', {expression: '({value: 22})', objectGroup: 'direction'})).result.objectId;
const remote = (await session.post('Runtime.evaluate', {expression: '({value})', contextId: id, objectGroup: 'direction'})).result.objectId;
for (const [receiver, argument] of [[owner, remote], [remote, owner]]) {
  await assert.rejects(session.post('Runtime.callFunctionOn', {objectId: receiver, functionDeclaration: 'function(other) { return this.value + other.value; }', arguments: [{objectId: argument}], returnByValue: true}), error => error.code === 'ERR_INSPECTOR_COMMAND' && error.message.includes('same JavaScript world'));
}
for (const [objectId, expected] of [[owner,44], [remote,22]]) {
  const reply = await session.post('Runtime.callFunctionOn', {objectId, functionDeclaration: 'function(other) { return this.value + other.value; }', arguments: [{objectId}], returnByValue:true});
  assert.equal(reply.result.value,expected);
}
await session.post('Runtime.releaseObjectGroup', {objectGroup:'direction'});
session.disconnect(); assert.equal(vm.runInContext('value',realm),11);
console.log('owner/realm foreign-world rejection and same-world arguments passed');
