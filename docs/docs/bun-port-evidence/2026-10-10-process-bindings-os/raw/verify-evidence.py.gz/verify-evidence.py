from pathlib import Path
import json,gzip,hashlib,subprocess,tempfile,sys
root=Path(__file__).resolve().parents[2];base=root/'docs/docs/bun-port-evidence/2026-10-10-process-bindings-os';m=json.loads((base/'manifest.json').read_text());rows=[];failed=0
with tempfile.TemporaryDirectory(prefix='home-process-evidence-') as name:
 out=Path(name)
 for r in m['files']:
  data=gzip.decompress((base/r['path']).read_bytes());assert len(data)==r['bytes'];assert hashlib.sha256(data).hexdigest()==r['sha256']
  if r['path'].startswith('raw/final/'):
   p=out/r['path'][4:-3];p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
 for p in sorted((out/'final').glob('corpus-*')):
  if not p.is_dir():continue
  index=p.name.split('-')[1];expected=json.loads((out/'final'/('validate-'+index+'.json')).read_text())
  result=subprocess.run([sys.executable,str(root/'scripts/summarize-bun-corpus.py'),str(p)],capture_output=True,text=True);actual=json.loads(result.stdout)
  assert result.returncode==(0 if expected['successful'] else 1)
  for key in ['successful','counts','summary','capture_completeness','errors']:assert actual.get(key)==expected.get(key),(p,key)
  failed+=not expected['successful'];rows.append(p.name)
 assert len(rows)==14
print(json.dumps({'archives_verified':len(m['files']),'restored_reports':len(rows),'recorded_failed_reports':failed,'all_recorded_outcomes_match':True},indent=2))
