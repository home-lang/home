from pathlib import Path
import json,gzip,hashlib,subprocess
root=Path(__file__).resolve().parents[2];task=Path(__file__).resolve().parent;base=root/'docs/docs/bun-port-evidence/2026-10-10-process-bindings-os';base.mkdir(parents=True,exist_ok=True)
counts={};reports=[]
for path in sorted((task/'final').glob('validate-*.json')):
 data=json.loads(path.read_text());assert data.get('capture_completeness',{}).get('incomplete',0)==0,path
 for key,value in data['summary'].items():
  if isinstance(value,int):counts[key]=counts.get(key,0)+value
 reports.append(path.name)
assert len(reports)==14 and counts['failed']==1 and counts['failed_files']==1
records=[]
def add(path,name):
 data=path.read_bytes();target=base/(name+'.gz');target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(gzip.compress(data,mtime=0));assert gzip.decompress(target.read_bytes())==data;records.append({'path':str(target.relative_to(base)),'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
for p in sorted(task.rglob('*')):
 if not p.is_file() or p.name.startswith('issue-') or p.name=='archive-production.log':continue
 if p.suffix in ['.log','.json','.jsonl','.py','.mjs','.stdout','.stderr','.xml']:add(p,'raw/'+str(p.relative_to(task)))
for name in json.loads((task/'source-final-hashes.json').read_text()):add(root/name,'source/'+name)
manifest={'schema':1,'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'upstream':'4982b91e3702094330f3be3883354c52b8c01323','platform':'Darwin arm64','results':{'original_files':14,'counts':counts,'native_regression_groups':14},'features':['Six native process bindings compile from Home with exact class-header/cache validation, including standalone constants and UV objects.','Process config reports actual backend FIPS mode and pointer width; config/X509 bindings retain per-process private identity.','Priority APIs validate types/ranges before system calls and normalize permission errors to the libuv contract.','UserInfo reads actual account data via libuv, propagates option getters and supports buffer encoding.'],'limitations':['The unchanged broad process file expects ICU to be unsupported; that conflicts with the implemented ICU API and remains #872. The retained full-scope outcome is not declared green.','Initial priority/getter failures and compile diagnostics remain without final passing credit.','Other process-binding stubs, full OS/process/native/API behavior, complete Bun suite and Release/ASAN/all-platform verification remain open under #66.'],'files':records}
(base/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(len(records),'verified archives',counts)
