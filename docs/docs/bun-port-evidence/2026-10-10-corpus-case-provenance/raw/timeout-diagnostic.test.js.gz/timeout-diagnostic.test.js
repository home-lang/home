import { test } from 'bun:test';
test('ordinary pending promise deadline', () => new Promise(() => {}));
