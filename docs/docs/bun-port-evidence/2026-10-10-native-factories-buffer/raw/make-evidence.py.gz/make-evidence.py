from pathlib import Path
import json,gzip,hashlib,subprocess
root=Path(__file__).resolve().parents[2];task=Path(__file__).resolve().parent;base=root/'docs/docs/bun-port-evidence/2026-10-10-native-factories-buffer';base.mkdir(parents=True,exist_ok=True)
counts={};reports=[]
for path in sorted((task/'first').glob('validate-*.json')):
 data=json.loads(path.read_text());assert data['successful'],path
 for key,value in data['summary'].items():
  if isinstance(value,int):counts[key]=counts.get(key,0)+value
 reports.append(path.name)
assert len(reports)==30 and counts['failed']==0
records=[]
def add(path,name):
 data=path.read_bytes();target=base/(name+'.gz');target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(gzip.compress(data,mtime=0));assert gzip.decompress(target.read_bytes())==data;records.append({'path':str(target.relative_to(base)),'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
for p in sorted(task.rglob('*')):
 if not p.is_file() or p.name.startswith('issue-') or p.name=='archive-production.log':continue
 if p.suffix in ['.log','.json','.jsonl','.py','.mjs','.stdout','.stderr','.xml']:add(p,'raw/'+str(p.relative_to(task)))
for name in json.loads((task/'source-final-hashes.json').read_text()):add(root/name,'source/'+name)
manifest={'schema':1,'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'upstream':'4982b91e3702094330f3be3883354c52b8c01323','platform':'Darwin arm64','results':{'original_files':30,'counts':counts,'native_regression_groups':13,'factory_headers_owned':12,'debug_steps':36,'debug_peak_tree_mb':5653,'conformance_peak_tree_mb':2109},'features':['All twelve linked native module factory headers execute from Home-owned copies with complete inventory rejection.','Standalone native Buffer implementation and encoding/list helpers compile from Home with exact linked class-header ABI validation.','The native module unity is fully Home-owned, including terminal and object-module generation.','JS2Native dispatch compiles from Home; generated dispatch bodies/IDs remain byte-identical while factory includes share the owned headers.'],'limitations':['Existing Home buffer.transcode routing is preserved; the Buffer source adds an extern-template declaration for typed-array ClassInfo supplied by the linked JSC library.','Earlier generator unit/path mistakes, deadline expiration, duplicate declaration, dispatch include and template diagnostics remain without final passing credit.','This verifies ordinary Buffer/decoder/constants/module/TTY APIs, not all Buffer behavior or complete native dependency ownership. Full suite and Release/ASAN/all-platform verification remain open under #66.'],'files':records}
(base/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(len(records),'verified archives',counts)
