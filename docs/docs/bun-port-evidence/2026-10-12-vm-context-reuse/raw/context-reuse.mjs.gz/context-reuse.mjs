import assert from 'node:assert/strict'
import vm from 'node:vm'
const sandbox={}
new vm.Script('let retainedLexical=40;globalThis.realmObject=Object;undefined').runInNewContext(sandbox)
assert.equal(vm.isContext(sandbox),true)
assert.equal(new vm.Script('retainedLexical+2').runInNewContext(sandbox),42)
assert.equal(vm.runInContext('retainedLexical+2',sandbox),42)
assert.equal(new vm.Script('Object===realmObject').runInNewContext(sandbox),true)
const already=vm.createContext({})
vm.runInContext('let existingLexical=7',already)
assert.equal(vm.runInNewContext('existingLexical',already),7)
console.log('Script and module runInNewContext preserve context identity and lexical state')
const checkpoint=vm.createContext({value:0},{microtaskMode:'afterEvaluate'});new vm.Script('Promise.resolve().then(()=>value++)').runInNewContext(checkpoint);assert.equal(checkpoint.value,1)
