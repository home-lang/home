from pathlib import Path
import subprocess,os,json,sys
p=Path('zig-out/vm-sandbox-owner-2026-10-12');rows=[]
commands=[['./zig-out/bin/home','run',str(p/'context-reuse.mjs')],[sys.executable,str(p/'run-corpus.py'),'original'],[sys.executable,str(p/'run-native.py'),'native'],['./zig-out/bin/home','run','tests/runtime/native-profiling-cli.test.mjs'],['/Users/chris/.bun/bin/bun','test','build-support/native_module_abi.test.ts','build-support/core_builtin_abi.test.ts','build-support/builtin_exports.test.ts'],[sys.executable,'-B','scripts/test_summarize_bun_corpus.py']]
for index,command in enumerate(commands,1):
 with (p/f'validation-{index}.log').open('wb') as log:r=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,env=os.environ.copy(),timeout=1200)
 rows.append({'command':command,'exit':r.returncode});(p/'validation.json').write_text(json.dumps(rows,indent=2)+'\n');print(index,r.returncode,flush=True)
 if r.returncode:sys.exit(r.returncode)
