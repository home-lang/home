import vm from 'node:vm'
function create(){const context=vm.createContext({__homeSandboxIdentity:{}});vm.runInContext('globalThis.__homeRetentionMarker=true;undefined',context);return new WeakRef(context)}
const weak=create();await new Promise(resolve=>setImmediate(resolve));Bun.gc(true);await new Promise(resolve=>setImmediate(resolve))
const snapshot=Bun.generateHeapSnapshot('jsc')
const stride=snapshot.type==='GCDebugging'?7:4,nodes=new Map(),back=new Map(),roots=new Set(),targets=[]
for(let i=0;i<snapshot.nodes.length;i+=stride){const id=snapshot.nodes[i],name=snapshot.nodeClassNames[snapshot.nodes[i+2]];nodes.set(id,name);if(name.includes('NodeVM')&&name.includes('Global'))targets.push(id)}
for(let i=0;i<snapshot.edges.length;i+=4){const from=snapshot.edges[i],to=snapshot.edges[i+1],type=snapshot.edgeTypes[snapshot.edges[i+2]],name=(type==='Property'||type==='Variable')?snapshot.edgeNames[snapshot.edges[i+3]]:type;let list=back.get(to);if(!list)back.set(to,list=[]);list.push({from,name});if(from===0)roots.add(to)}

const targets2=[]
for(let i=0;i<snapshot.edges.length;i+=4){const from=snapshot.edges[i],type=snapshot.edgeTypes[snapshot.edges[i+2]],name=snapshot.edgeNames[snapshot.edges[i+3]];if(type==='Property'&&name==='__homeSandboxIdentity')targets2.push(from)}
console.log('sandbox targets',targets2.length)
for(const target of targets2){const q=[{id:target,path:[]}],seen=new Set();let found=0;while(q.length&&found<8){const item=q.shift();if(seen.has(item.id)||nodes.get(item.id)==='NodeVMGlobalObject')continue;seen.add(item.id);if(item.id===0||roots.has(item.id)){console.log('sandbox root',nodes.get(item.id),JSON.stringify(item.path));found++;continue}if(item.path.length>=16)continue;for(const edge of back.get(item.id)||[])q.push({id:edge.from,path:[{from:nodes.get(edge.from)||'Root',edge:edge.name,to:nodes.get(item.id)},...item.path]})}}
