Home now creates Node resource entries with timing/body/cache metadata, owns a resource buffer and overflow lifecycle, routes buffered resource observers, and compiles ResourceTiming/PerformanceResourceTiming/NetworkLoadMetrics from Home. Source: https://github.com/home-lang/home/commit/456552ef6f35471e956bbe1f7c520622c2dd8250.

The global WebCore path is still incomplete: `JSPerformance.cpp` markResourceTiming returns undefined, native resource buffer overflow processing is commented out, and automatic fetch producers do not yet feed the new Node resource timeline. Node module queries and WebCore global queries currently have separate resource state. The selected manual-API conformance does not prove global/fetch integration.

Acceptance:

- Implement global resource creation and automatic fetch timing from actual request milestones.
- Unify resource identity, query results, clear/resize behavior, overflow recovery and observer delivery across Node and global APIs.
- Preserve class/receiver semantics and teardown ownership through both paths.
- Expand unchanged upstream coverage and ordinary valid fetch/resource conformance; retain failures and avoid assertion edits or filename-specific behavior.
- Complete remaining resource argument/coercion, selective clearing and native base-class interactions.

Parents: #869 and #66. Darwin arm64 manual Node API conformance is a checkpoint, not full resource or Bun-suite parity.
