import assert from 'node:assert/strict';import vm from 'node:vm';import {Session} from 'node:inspector/promises';
const first=vm.createContext({value:11},{name:'first'}),second=vm.createContext({value:22},{name:'second'});const s=new Session();s.connect();const contexts=[];s.on('Runtime.executionContextCreated',x=>contexts.push(x.params.context));await s.post('Runtime.enable');
const handles=[];
for(const name of ['first','second']) {const context=contexts.find(x=>x.name===name);assert(context);const {result}=await s.post('Runtime.evaluate',{expression:'({value})',contextId:context.id,objectGroup:'realm-regression'});assert.equal(typeof result.objectId,'string');handles.push(result.objectId);}
assert.notEqual(handles[0],handles[1]);
for(let i=0;i<handles.length;i++){const result=await s.post('Runtime.getProperties',{objectId:handles[i],ownProperties:true});assert.equal(result.result.find(x=>x.name==='value').value.value,i?22:11);await s.post('Runtime.releaseObject',{objectId:handles[i]});}
s.disconnect();assert.equal(vm.runInContext('value',first),11);assert.equal(vm.runInContext('value',second),22);console.log('remote objects retain exact realm ownership');
