from pathlib import Path
import subprocess,json,sys,os,hashlib
root=Path.cwd();p=Path(__file__).resolve().parent;rows=[]
for r in json.loads((p/'event-source-hashes.json').read_text()):assert hashlib.sha256((root/r['path']).read_bytes()).hexdigest()==r['sha256']
commands=[['./zig-out/bin/home','tests/runtime/native-inspector-context-events.test.mjs'],['./zig-out/bin/home','tests/runtime/native-inspector-async-properties.test.mjs'],['./zig-out/bin/home','tests/runtime/native-profiling-cli.test.mjs'],[sys.executable,str(p/'run-variants.py')],[sys.executable,str(p/'run-realm-regressions.py')]]
for index,command in enumerate(commands,1):
 with (p/f'event-validation-{index}.log').open('wb') as log:
  try:result=subprocess.run(command,env=os.environ.copy(),stdout=log,stderr=subprocess.STDOUT,timeout=240)
  except subprocess.TimeoutExpired:result=subprocess.CompletedProcess(command,124)
 rows.append({'command':command,'exit':result.returncode});(p/'event-validation-results.json').write_text(json.dumps(rows,indent=2)+'\n');print(index,result.returncode,flush=True)
 if result.returncode:sys.exit(result.returncode)
