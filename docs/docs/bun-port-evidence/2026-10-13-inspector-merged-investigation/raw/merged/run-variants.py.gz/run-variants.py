from pathlib import Path
import subprocess,json,os
p=Path(__file__).resolve().parent;rows=[]
for runtime,command in [('node',['node','--expose-gc']),('home',['./zig-out/bin/home'])]:
 for mode in ['no-session','enabled','evaluated','detached']:
  with (p/(runtime+'-collection-'+mode+'.log')).open('wb') as log:
   result=subprocess.run(command+[str(p/'collection-variants.mjs'),mode],stdout=log,stderr=subprocess.STDOUT,env=os.environ,timeout=30)
  rows.append({'runtime':runtime,'mode':mode,'exit':result.returncode});print(runtime,mode,result.returncode,flush=True)
(p/'collection-variant-results.json').write_text(json.dumps(rows,indent=2)+'\n')
