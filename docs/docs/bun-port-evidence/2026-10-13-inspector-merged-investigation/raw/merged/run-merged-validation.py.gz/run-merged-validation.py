from pathlib import Path
import subprocess,sys,json,os
p=Path(__file__).resolve().parent;rows=[]
for name in ['run-event-validation.py','run-broad-validation.py']:
 with (p/(name+'.log')).open('wb') as log:result=subprocess.run([sys.executable,str(p/name)],env=os.environ.copy(),stdout=log,stderr=subprocess.STDOUT,timeout=1200)
 rows.append({'driver':name,'exit':result.returncode});(p/'merged-results.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,result.returncode,flush=True)
 if result.returncode:sys.exit(result.returncode)
