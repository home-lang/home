from pathlib import Path
import subprocess,json,sys,os
p=Path(__file__).resolve().parent;rows=[]
commands=[['./zig-out/bin/home',str(p/'fetch-cancellation-diagnostic.mjs')],['node','--expose-gc',str(p/'collection-returned-scope.mjs')],['./zig-out/bin/home',str(p/'collection-returned-scope.mjs')],['/Users/chris/.bun/bin/bun','test','build-support/native_module_abi.test.ts','build-support/core_builtin_abi.test.ts','build-support/builtin_exports.test.ts'],[sys.executable,'-B','scripts/test_summarize_bun_corpus.py']]
for index,command in enumerate(commands,1):
 with (p/f'integration-diagnostic-{index}.log').open('wb') as log:
  try:r=subprocess.run(command,env=os.environ.copy(),stdout=log,stderr=subprocess.STDOUT,timeout=120)
  except subprocess.TimeoutExpired:r=subprocess.CompletedProcess(command,124)
 rows.append({'command':command,'exit':r.returncode});(p/'integration-diagnostic-results.json').write_text(json.dumps(rows,indent=2)+'\n');print(index,r.returncode,flush=True)
