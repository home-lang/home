Parent #66; related #703/#709/#722.

While reviewing the native outcome journal, the current capture implementation exposes a remaining deadline gap in `packages/home_test/src/adapters/jsc_bootstrap.zig::runSpawnSyncCaptured`. The selected corpus deadline is passed to `multi_reader.fill`. Once stdout/stderr reach EOF, the function calls `child.wait(io)` without the remaining deadline. A fixture that closes both output descriptors and stays alive can therefore pass beyond its original process deadline while the outer runner waits for termination. The process deadline must cover the entire child lifetime, including after pipe EOF. This is a source-level finding; the specific closed-pipe control has not yet been executed.

Required work:

- Apply the unchanged selected upstream deadline through child termination, as well as pipe draining; do not extend deadlines, retry, or invent a passing process outcome.
- Preserve both complete captures and timeout/signal identity in the durable #722 record.
- Verify with real children that close stdout/stderr and remain alive past the actual 20-second Node deadline, children that close pipes and exit successfully before it, and ordinary output-bearing timeout cases. Ensure only owned descendants are terminated.
- Retain first-run evidence, original fixture/source integrity, and executable identity. Cover the Windows child-wait path on its native platform before claiming that platform verified.

Do not treat the outer machine supervisor's larger timeout as a substitute for the original per-file deadline. Full logical corpus parity remains incomplete.
