import hashlib,json,os,re,subprocess,time
from pathlib import Path
root=Path.cwd(); evidence=(root/'zig-out/bun-port-recovery').resolve(); out=evidence/'corpus-journal-corrected';out.mkdir(exist_ok=False)
home=root/'zig-out/bin/home'; build=evidence/'build-corpus-journal-diagnostics.log'
assert 'Build Summary: 23/23 steps succeeded' in build.read_text(), 'native build must succeed before execution'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(home)!='0eb2bafd6575d1d83a5296e96c3f3ce2cb1c5a6072ea945dd3ac6eb71c35b147','stale executable'
manifest={'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'home_sha256':sha(home),'build_log_sha256':sha(build),'runtime_sources':{p:sha(root/p) for p in ['packages/home_test/src/corpus_journal.zig','packages/home_test/src/corpus_runner.zig','packages/home_test/src/adapters/jsc_bootstrap.zig','packages/home_test/src/result.zig','src/main.zig']},'runs':[]}
def save(): (out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
save()
def run(label,args,env):
 row={'label':label,'argv':list(map(str,args)),'status':'started'};manifest['runs'].append(row);save()
 log=out/(label+'.log');start=time.monotonic()
 with log.open('xb') as stream:
  code=subprocess.run(['perl',str(root/'scripts/run-bounded.pl'),'300',*map(str,args)],cwd=root,env=env,stdin=subprocess.DEVNULL,stdout=stream,stderr=subprocess.STDOUT).returncode
 row.update(status='completed',exit_code=code,seconds=time.monotonic()-start,log_sha256=sha(log));save();print(json.dumps(row),flush=True)
 return code
base=os.environ.copy()
for key in ['HOME_NATIVE_VM','HOME_CORPUS_FULL_VM','HOME_BUN_TEST_EXECUTABLE','HOME_BUN_CORPUS_REPORT_DIR']:base.pop(key,None)
private_env=base|{'HOME_NATIVE_VM':'1','HOME_CORPUS_EVIDENCE_DIR':str(out/'private-reports'),'HOME_RUN_LABEL':'native-corpus-outcome-controls'}
private=root/'tests/runtime/native-corpus-outcomes.test.mjs';manifest['private_source_sha256']=sha(private);save()
run('private-controls',[home,'run',private],private_env)
paths=['js/bun/test/expect.test.js','js/web/html/FormData-multipart-serialization.test.ts','js/web/html/html-rewriter-doctype.test.ts','js/node/test/parallel/test-buffer-isencoding.js','js/bun/empty-file.test.ts','js/bun/test/test-fixture-diff-indexed-properties.js']
sources=[root/'packages/runtime/test/test'/p for p in paths]
protected=sources+[s.parent/'__snapshots__'/(s.name+'.snap') for s in sources if (s.parent/'__snapshots__'/(s.name+'.snap')).exists()]
originals={str(p):sha(p) for p in protected};manifest['original_sources_and_snapshots']=originals;save()
run('original-matrix',[home,'test',*sources],base|{'HOME_BUN_CORPUS_REPORT_DIR':str(out/'original-reports'),'HOME_RUN_LABEL':'native-corpus-original-outcomes'})
manifest['original_integrity']={p:sha(Path(p))==before for p,before in originals.items()};manifest['executable_unchanged']=sha(home)==manifest['home_sha256'];save()
for report in [out/'original-reports',*sorted((out/'private-reports').glob('report-*'))]:
 if not report.exists():continue
 label='validated-'+report.name
 run(label,['python3',root/'scripts/summarize-bun-corpus.py',report],base|{'HOME_RUN_LABEL':label})
assert all(manifest['original_integrity'].values()),'original sources/snapshots changed'
assert manifest['executable_unchanged'],'executable changed'
expected={'private-controls':0,'original-matrix':0,'validated-original-reports':0}
for row in manifest['runs']:
 expected_code=expected.get(row['label'],1)
 row['expected_exit_code']=expected_code
 row['matches_expected_exit']=row['exit_code']==expected_code
manifest['verification_passed']=all(row['matches_expected_exit'] for row in manifest['runs'])
save()
raise SystemExit(0 if manifest['verification_passed'] else 1)
