from pathlib import Path
import subprocess,os,json,sys
root=Path(__file__).resolve().parents[2];task=Path(__file__).resolve().parent; phase=sys.argv[1] if len(sys.argv)>1 else 'tls-selected';report=task/phase
env=os.environ.copy();env['BUN_DEBUG_QUIET_LOGS']='1';env['HOME_BUN_CORPUS_REPORT_DIR']=str(report)
for key in ['HOME_NATIVE_VM','HOME_CORPUS_FULL_VM','HOME_NATIVE_RUN']:env.pop(key,None)
name='js/node/tls/node-tls-server.test.ts'; selected='ALPNCallback returning an offered protocol completes the handshake with it'
command=[str(root/'zig-out/bin/home'),'test',str(root/'packages/runtime/test/test'/name),'-t',selected]
with (task/(phase+'.log')).open('wb') as log: result=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=240)
with (task/(phase+'-validate.json')).open('wb') as log: validation=subprocess.run([sys.executable,str(root/'scripts/summarize-bun-corpus.py'),str(report)],cwd=root,stdout=log,stderr=subprocess.STDOUT)
observed=json.loads((task/(phase+'-validate.json')).read_text()); passed_cases=[c for c in observed['cases'] if c['status']=='passed'];scope_matches=observed['counts']['passed']==1 and observed['counts'].get('filtered')==37 and len(passed_cases)==1 and passed_cases[0]['name']==selected and all(c['status'] in ['passed','filtered'] for c in observed['cases'])
(task/(phase+'-selection.json')).write_text(json.dumps({'file':name,'test_name_pattern':selected,'command':command,'exit':result.returncode,'validation_exit':validation.returncode,'scope_matches':scope_matches},indent=2)+'\n')
print('selected ordinary ALPN callback case',result.returncode,validation.returncode)
sys.exit(0 if result.returncode==0 and validation.returncode==0 and scope_matches else 1)
