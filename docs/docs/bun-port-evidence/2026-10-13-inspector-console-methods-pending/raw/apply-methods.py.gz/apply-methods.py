from pathlib import Path
import os
p=Path('packages/runtime/src/native/inspector_controller.cpp');s=p.read_text()
needle='static auto* inspectorManagers = new std::unordered_map<JSC::JSGlobalObject*, Inspector::InjectedScriptManager*>;'
insert='''
// Read the SDK's canonical records rather than maintaining parallel counters
// or timers in the protocol bridge. The subclass does not change SDK layouts.
class HomeInspectorConsoleAgent final : public Inspector::InspectorConsoleAgent {
    WTF_DEPRECATED_MAKE_FAST_ALLOCATED(HomeInspectorConsoleAgent);
public:
    explicit HomeInspectorConsoleAgent(Inspector::AgentContext& context)
        : Inspector::InspectorConsoleAgent(context) { }
    WTF::String lastMessage() const { return m_consoleMessages.isEmpty() ? WTF::String() : m_consoleMessages.last()->message(); }
    bool hasCounter(const WTF::String& label) const { return m_counts.contains(label); }
    bool hasTimer(const WTF::String& label) const { return m_times.contains(label); }
};
static thread_local auto* inspectorConsoleAgents = new std::unordered_map<JSC::JSGlobalObject*, HomeInspectorConsoleAgent*>;
static HomeInspectorConsoleAgent* consoleAgentFor(JSC::JSGlobalObject& global) {
    auto found = inspectorConsoleAgents->find(&global);
    return found == inspectorConsoleAgents->end() ? nullptr : found->second;
}
'''
assert needle in s;s=s.replace(needle,needle+insert)
s=s.replace('void inspectorConsoleMessage(Inspector::ConsoleMessage& message) {','static void inspectorConsoleMessageWithType(Inspector::ConsoleMessage& message, const WTF::String& overrideType) {',1)
s=s.replace('    params->setString("type"_s,type);','    params->setString("type"_s,overrideType.isEmpty() ? type : overrideType);',1)
needle='    params->setArray("args"_s,WTF::move(args));';s=s.replace(needle,'''    if (!args->length() && (message.type() == JSC::MessageType::EndGroup || message.type() == JSC::MessageType::Clear)) {
        auto argument = JSON::Object::create();
        argument->setString("type"_s, "string"_s);
        argument->setString("value"_s, message.type() == JSC::MessageType::Clear ? "console.clear"_s : "console.groupEnd"_s);
        args->pushObject(WTF::move(argument));
    }
'''+needle,1)
pos=s.index('void inspectorConsoleArguments(JSC::JSGlobalObject& global')
s=s[:pos]+'''void inspectorConsoleMessage(Inspector::ConsoleMessage& message) {
    inspectorConsoleMessageWithType(message, ""_s);
}
static void emitConsoleRecord(JSC::JSGlobalObject& global, const WTF::String& type, const WTF::String& text, Inspector::ScriptArguments* extra = nullptr) {
    if (!inspectorHasConsoleListeners(global) || text.isNull()) return;
    WTF::Vector<JSC::Strong<JSC::Unknown>> values;
    values.append(JSC::Strong<JSC::Unknown>(global.vm(), JSC::jsString(global.vm(), text)));
    if (extra) for (size_t i = 0; i < extra->argumentCount(); ++i)
        values.append(JSC::Strong<JSC::Unknown>(global.vm(), extra->argumentAt(i)));
    auto arguments = Inspector::ScriptArguments::create(&global, WTF::move(values));
    Inspector::ConsoleMessage message(JSC::MessageSource::ConsoleAPI, JSC::MessageType::Log, JSC::MessageLevel::Log, text, WTF::move(arguments), &global);
    inspectorConsoleMessageWithType(message, type);
}
void inspectorConsoleCount(JSC::JSGlobalObject& global, const WTF::String& label, bool reset) {
    auto* agent = consoleAgentFor(global);
    if (!agent) return;
    bool exists = agent->hasCounter(label);
    if (reset) agent->countReset(&global, label); else agent->count(&global, label);
    if (reset && exists) return;
    emitConsoleRecord(global, reset ? "warning"_s : "count"_s, agent->lastMessage());
}
void inspectorConsoleTime(JSC::JSGlobalObject& global, const WTF::String& label) {
    auto* agent = consoleAgentFor(global);
    if (!agent) return;
    bool exists = agent->hasTimer(label);
    agent->startTiming(&global, label);
    if (exists) emitConsoleRecord(global, "warning"_s, agent->lastMessage());
}
void inspectorConsoleTiming(JSC::JSGlobalObject& global, const WTF::String& label, Inspector::ScriptArguments* arguments) {
    auto* agent = consoleAgentFor(global);
    if (!agent) return;
    bool exists = agent->hasTimer(label);
    if (arguments) agent->logTiming(&global, label, arguments->copyRef()); else agent->stopTiming(&global, label);
    emitConsoleRecord(global, exists ? (arguments ? "log"_s : "timeEnd"_s) : "warning"_s, agent->lastMessage(), exists ? arguments : nullptr);
}

'''+s[pos:]
changes={'void count':'inspectorConsoleCount(*global,label,false);','void countReset':'inspectorConsoleCount(*global,label,true);','void time':'inspectorConsoleTime(*global,label);','void timeEnd':'inspectorConsoleTiming(*global,label,nullptr);'}
for method,body in changes.items():
 start=s.index('    '+method+'(JSC::JSGlobalObject* global,');end=s.index('\n',start)
 s=s[:start]+s[start:end].split(' final {')[0]+' final { '+body+' }'+s[end:]
start=s.index('    void timeLog(JSC::JSGlobalObject* global,');end=s.index('\n',start);s=s[:start]+s[start:end].split(' final {')[0]+' final { inspectorConsoleTiming(*global,label,arguments.ptr()); }'+s[end:]
s=s.replace('auto consoleAgent = makeUniqueRef<InspectorConsoleAgent>(context);','auto consoleAgent = makeUniqueRef<Home::HomeInspectorConsoleAgent>(context);\n    (*Home::inspectorConsoleAgents)[&m_globalObject] = consoleAgent.ptr();')
s=s.replace('    Home::retireInspectorManager(m_globalObject, m_injectedScriptManager.get());','    Home::inspectorConsoleAgents->erase(&m_globalObject);\n    Home::retireInspectorManager(m_globalObject, m_injectedScriptManager.get());',1)
outputs={p:s}
p=Path('packages/runtime/upstream/src/jsc/bindings/HomeInspectorRealms.h');s=p.read_text();needle='void inspectorConsoleMessage(Inspector::ConsoleMessage&);';assert needle in s;s=s.replace(needle,needle+'\nvoid inspectorConsoleCount(JSC::JSGlobalObject&, const WTF::String&, bool reset);\nvoid inspectorConsoleTime(JSC::JSGlobalObject&, const WTF::String&);\nvoid inspectorConsoleTiming(JSC::JSGlobalObject&, const WTF::String&, Inspector::ScriptArguments*);');outputs[p]=s
p=Path('packages/runtime/upstream/src/jsc/bindings/ConsoleObject.cpp');s=p.read_text()
for method,call in [('count','inspectorConsoleCount(*globalObject, label, false)'),('countReset','inspectorConsoleCount(*globalObject, label, true)'),('time','inspectorConsoleTime(*globalObject, label)'),('timeEnd','inspectorConsoleTiming(*globalObject, label, nullptr)')]:
 needle=f'void ConsoleObject::{method}(JSGlobalObject* globalObject, const String& label)\n{{';assert needle in s;s=s.replace(needle,needle+'\n    Home::'+call+';',1)
needle='void ConsoleObject::timeLog(JSGlobalObject* globalObject, const String& label,\n    Ref<ScriptArguments>&& arguments)\n{';assert needle in s;s=s.replace(needle,needle+'\n    Home::inspectorConsoleTiming(*globalObject, label, arguments.ptr());',1);outputs[p]=s
for p,s in outputs.items():
 tmp=p.with_suffix(p.suffix+'.tmp');tmp.write_text(s);os.replace(tmp,p)
