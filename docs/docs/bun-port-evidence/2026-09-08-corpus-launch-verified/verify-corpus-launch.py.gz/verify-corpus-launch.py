from pathlib import Path
import difflib,gzip,hashlib,json,os,re,shutil,subprocess,tempfile,time
root=Path.cwd();ev=(root/'zig-out/bun-port-recovery').resolve();out=ev/'corpus-launch-native';out.mkdir(exist_ok=False);project=root/'packages/runtime/test';home=root/'zig-out/bin/home';bun=Path('/Users/chris/Code/bun/build/release/bun')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
build=(ev/'build-corpus-launch-ownership.log').read_text();match=re.search(r'Build Summary: (\d+)/(\d+) steps succeeded',build);assert match and match[1]==match[2], 'Native build/harness not fully successful'
assert sha(home)!='0909fe2ed15effca4940fb7c32ab618149381b87fa5530ddbd2b3638e9aa61bc','Stale Home binary'
manifest={'runtime_source':'0785d795a','home_sha256':sha(home),'bun_sha256':sha(bun),'status':'Selected original files only; scripts and empty files do not invent passing test cases. Audit snapshot failure #721 remains expected to be exposed, not accepted as a pass.','results':[]}
files=[('js/workerd/html-rewriter.test.js','test'),('js/web/html/html-rewriter-doctype.test.ts','test'),('js/node/test/parallel/test-buffer-isencoding.js','run'),('js/node/test/parallel/test-module-isBuiltin.js','test'),('js/bun/empty-file.test.ts','test'),('cli/install/bun-link.test.ts','test'),('cli/install/bun-audit.test.ts','test')]
def save():(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for relative,mode in files:
 source=project/'test'/relative;node=relative.startswith('js/node/test/')
 pinned=subprocess.check_output(['git','-C','/Users/chris/Code/bun','show','4982b91e3702094330f3be3883354c52b8c01323:test/'+relative]);assert source.read_bytes()==pinned
 for runtime,exe in [('home',home),('bun',bun)]:
  label=relative.replace('/','--')+'-'+runtime;args=[str(exe),'test',str(source)] if runtime=='home' else [str(exe),mode,'--config='+str(project/('bunfig.node-test.toml' if node else 'bunfig.toml'))]
  if runtime=='bun':
   if not node:args+=['--timeout=90000','--reporter=dots']
   args+=[str(source)]
  manifest['results'].append({'label':label,'runtime':runtime,'relative':relative,'node':node,'mode':mode,'argv':args,'source_sha256':sha(source),'status':'selected'})
save()
for row in manifest['results']:
 source=project/'test'/row['relative'];snapshot=source.parent/'__snapshots__'/(source.name+'.snap');before=source.read_bytes();old=snapshot.read_bytes() if snapshot.exists() else None
 fixture=Path(tempfile.mkdtemp(prefix='home-launch-verify-'));temp=fixture/'tmp';temp.mkdir();env=os.environ.copy()
 for key in ['HOME_NATIVE_VM','HOME_CORPUS_FULL_VM','HOME_BUN_TEST_EXECUTABLE','NO_COLOR','FORCE_COLOR']:env.pop(key,None)
 env.update(CI='true',GITHUB_ACTIONS='true',BUN_INSTALL=str(fixture/'install'),BUN_INSTALL_GLOBAL_DIR=str(fixture/'global'),BUN_INSTALL_BIN=str(fixture/'bin'),BUN_INSTALL_CACHE_DIR=str(temp),TMPDIR=str(temp),BUN_TMPDIR=str(temp),TEST_TMPDIR=str(temp),HOME_RUN_LABEL=row['label'])
 if row['runtime']=='bun':
  env['PATH']=str(bun.parent)+os.pathsep+env.get('PATH','')
  env.update(BUN_DEBUG_QUIET_LOGS='1',BUN_FEATURE_FLAG_INTERNAL_FOR_TESTING='1',BUN_GARBAGE_COLLECTOR_LEVEL='1',BUN_JSC_randomIntegrityAuditRate='1.0',BUN_RUNTIME_TRANSPILER_CACHE_PATH='0',BUN_ENABLE_CRASH_REPORTING='0',FORCE_COLOR='0' if row['node'] else '1')
  if row['node']:env['NO_COLOR']='1'
 log=out/(row['label']+'.log');row.update(status='started',fixture=str(fixture));save();started=time.monotonic()
 with log.open('xb') as stream:
  code=subprocess.run(['perl',str(root/'scripts/run-bounded.pl'),'60' if row['node'] else '210',*row['argv']],env=env,cwd=root if row['runtime']=='home' else project,stdout=stream,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL).returncode
 plain=re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]','',log.read_text(errors='replace'));new=snapshot.read_bytes() if snapshot.exists() else None
 row.update(status='completed',exit_code=code,seconds=time.monotonic()-started,log_sha256=sha(log),source_unchanged=before==source.read_bytes(),snapshot_unchanged=old==new,pass_reports=re.findall(r'(?m)^\s*(\d+) pass\s*$',plain),fail_reports=re.findall(r'(?m)^\s*(\d+) fail\s*$',plain),process_reports=re.findall(r'(?m)^(?:process checks passed|file processes failed|files skipped by upstream|comment-only files)[^\n]*',plain))
 if old!=new:
  (out/(row['label']+'.snapshot.diff')).write_text(''.join(difflib.unified_diff((old or b'').decode().splitlines(True),(new or b'').decode().splitlines(True))))
  if old is None:snapshot.unlink()
  else:snapshot.write_bytes(old)
  row['snapshot_restored']=True
 if not row['source_unchanged']:
  (out/(row['label']+'.source.diff')).write_text(''.join(difflib.unified_diff(before.decode().splitlines(True),source.read_text().splitlines(True))));source.write_bytes(before);row['source_restored']=True
 inventory=[]
 for p in fixture.rglob('*'):
  st=p.lstat();inventory.append({'path':str(p.relative_to(fixture)),'bytes':st.st_size,'mode':st.st_mode})
 (out/(row['label']+'.inventory.json.gz')).write_bytes(gzip.compress(json.dumps(inventory).encode(),mtime=0));shutil.rmtree(fixture);row['fixture_removed']=True
 save();print(json.dumps(row),flush=True)
raise SystemExit(int(any(r['exit_code']!=0 or not r['source_unchanged'] or not r['snapshot_unchanged'] for r in manifest['results'])))
