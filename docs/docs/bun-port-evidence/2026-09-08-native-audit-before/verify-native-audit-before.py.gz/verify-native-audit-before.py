import difflib,gzip,hashlib,json,os,re,shutil,subprocess,tempfile,time,xml.etree.ElementTree as ET
from pathlib import Path
root=Path.cwd();project=root/'packages/runtime/test';out=(root/'zig-out/bun-port-recovery').resolve()/'native-audit-before';out.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
runner=Path('/Users/chris/Code/bun/scripts/runner.node.mjs')
manifest={'runtime_source':'a4b73596f','runner_reference_sha256':sha(runner),'profile':{'file_seconds':180,'per_test_cli_ms':90000,'source_timeout_override_preserved':True,'gc_level':'1','integrity_audit':'1.0','transpiler_cache':'0','fresh_tmp_and_cache_per_file':True,'junit':True},'results':[]}
def save():(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
cases=[]
for filename in ['bun-audit.test.ts']:
 for runtime,exe in [('home',root/'zig-out/bin/home'),('bun',Path('/Users/chris/Code/bun/build/release/bun'))]:
  label=filename+'-'+runtime;source=project/'test/cli/install'/filename;junit=out/(label+'.xml')
  args=[str(exe),'test','--config='+str(project/'bunfig.toml'),'--timeout=90000','--reporter=dots','--reporter=junit','--reporter-outfile='+str(junit),str(source)]
  row={'label':label,'argv':args,'executable_sha256':sha(exe),'source_sha256':sha(source),'status':'selected'};manifest['results'].append(row);cases.append((runtime,source,row,junit))
save()
for runtime,source,row,junit in cases:
 env=os.environ.copy()
 for key in ['HOME_NATIVE_VM','HOME_CORPUS_FULL_VM','HOME_BUN_TEST_EXECUTABLE','NO_COLOR']:env.pop(key,None)
 env.update(FORCE_COLOR='1',GITHUB_ACTIONS='true',BUN_DEBUG_QUIET_LOGS='1',BUN_FEATURE_FLAG_INTERNAL_FOR_TESTING='1',BUN_GARBAGE_COLLECTOR_LEVEL='1',BUN_JSC_randomIntegrityAuditRate='1.0',BUN_RUNTIME_TRANSPILER_CACHE_PATH='0',BUN_ENABLE_CRASH_REPORTING='0',HOME_RUN_LABEL='original-audit-'+row['label'])
 if runtime=='home':env.update(HOME_NATIVE_VM='1',HOME_CORPUS_FULL_VM='1')
 sandbox=Path(tempfile.mkdtemp(prefix='home-original-audit-'));temp=sandbox/'tmp';temp.mkdir()
 env.update(BUN_INSTALL=str(sandbox/'install'),BUN_INSTALL_GLOBAL_DIR=str(sandbox/'global'),BUN_INSTALL_BIN=str(sandbox/'bin'),BUN_INSTALL_CACHE_DIR=str(temp),TMPDIR=str(temp),BUN_TMPDIR=str(temp),TEST_TMPDIR=str(temp))
 snapshot=source.parent/'__snapshots__'/(source.name+'.snap');snapshot_before=snapshot.read_bytes() if snapshot.exists() else None
 before=source.read_bytes();start=time.monotonic();log=out/(row['label']+'.log');row.update(status='started',log=str(log),fixture=str(sandbox));save()
 with log.open('xb') as stream:code=subprocess.run(['perl',str(root/'scripts/run-bounded.pl'),'180',*row['argv']],cwd=project,env=env,stdout=stream,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL).returncode
 text=re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]','',log.read_text(errors='replace'))
 row.update(status='completed',exit_code=code,seconds=time.monotonic()-start,source_unchanged=source.read_bytes()==before,log_sha256=sha(log),pass_reports=re.findall(r'(?m)^\s*(\d+) pass\s*$',text),fail_reports=re.findall(r'(?m)^\s*(\d+) fail\s*$',text))
 if not row['source_unchanged']:
  (out/(row['label']+'.source.diff')).write_text(''.join(difflib.unified_diff(before.decode().splitlines(True),source.read_text().splitlines(True))))
  source.write_bytes(before);row['source_restored']=True
 snapshot_after=snapshot.read_bytes() if snapshot.exists() else None;row['snapshot_unchanged']=snapshot_after==snapshot_before
 if not row['snapshot_unchanged']:
  (out/(row['label']+'.snapshot.diff')).write_text(''.join(difflib.unified_diff((snapshot_before or b'').decode().splitlines(True),(snapshot_after or b'').decode().splitlines(True))))
  if snapshot_before is None:snapshot.unlink()
  else:snapshot.write_bytes(snapshot_before)
  row['snapshot_restored']=True
 if junit.exists():
  row['junit_sha256']=sha(junit)
  try:row['junit_cases']=len(ET.parse(junit).findall('.//testcase'))
  except ET.ParseError as err:row['junit_error']=str(err)
 # Preserve a path/size inventory of generated data before removing this
 # run's entire private temp/cache tree. Test logs and JUnit remain durable.
 inventory=[]
 for p in sandbox.rglob('*'):
  try:st=p.lstat();inventory.append({'path':str(p.relative_to(sandbox)),'bytes':st.st_size,'mode':st.st_mode})
  except OSError:pass
 artifact=out/(row['label']+'.fixture-inventory.json.gz');artifact.write_bytes(gzip.compress(json.dumps(inventory,indent=2).encode(),mtime=0))
 shutil.rmtree(sandbox);row['generated_fixture_removed']=True;save();print(json.dumps(row),flush=True)
raise SystemExit(int(any(r['exit_code']!=0 or not r['source_unchanged'] or not r['snapshot_unchanged'] for r in manifest['results'])))
