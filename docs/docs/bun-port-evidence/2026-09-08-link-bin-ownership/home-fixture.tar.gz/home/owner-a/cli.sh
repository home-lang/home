#!/bin/sh
printf "owner-a\n"
