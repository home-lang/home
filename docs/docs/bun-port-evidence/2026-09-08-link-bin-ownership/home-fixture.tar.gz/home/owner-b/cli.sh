#!/bin/sh
printf "owner-b\n"
