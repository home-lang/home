import hashlib,json,os,shutil,subprocess,tarfile,tempfile
from pathlib import Path
root=Path.cwd();out=(root/'zig-out/bun-port-recovery/link-bin-ownership');out.mkdir(exist_ok=False)
results=[]
for runtime,exe in [('home',root/'zig-out/bin/home'),('bun',Path('/Users/chris/Code/bun/build/release/bun'))]:
 fixture=Path(tempfile.mkdtemp(prefix='home-bin-ownership-'+runtime+'-'));prefix=fixture/'global';bins=fixture/'bin'
 env={**os.environ,'HOME_NATIVE_VM':'1','BUN_DEBUG_QUIET_LOGS':'1','NO_COLOR':'1','BUN_INSTALL':str(fixture/'install'),'BUN_INSTALL_GLOBAL_DIR':str(prefix),'BUN_INSTALL_BIN':str(bins),'BUN_INSTALL_CACHE_DIR':str(fixture/'cache')}
 for name in ['owner-a','owner-b']:
  package=fixture/name;package.mkdir();(package/'package.json').write_text(json.dumps({'name':'native-'+name,'version':'1.0.0','bin':{'shared-native-command':'cli.sh'}}));(package/'cli.sh').write_text('#!/bin/sh\nprintf "'+name+'\\n"\n');(package/'cli.sh').chmod(0o755)
 row={'runtime':runtime,'executable':str(exe),'sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'fixture':str(fixture),'steps':[]};results.append(row)
 for name,args in [('owner-a',['link']),('owner-b',['link']),('owner-a',['unlink'])]:
  child=subprocess.run([str(exe),*args],cwd=fixture/name,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=15)
  bin=bins/'shared-native-command'
  row['steps'].append({'package':name,'args':args,'exit_code':child.returncode,'stdout':child.stdout.decode(),'stderr':child.stderr.decode(),'bin_exists':bin.exists(),'bin_target':str(bin.resolve()) if bin.exists() else None,'owner_b_registered':(prefix/'node_modules/native-owner-b').exists()})
 row['removed_other_packages_current_bin']=row['steps'][1]['bin_target']==str((fixture/'owner-b/cli.sh').resolve()) and not row['steps'][2]['bin_exists'] and row['steps'][2]['owner_b_registered']
 with tarfile.open(out/(runtime+'-fixture.tar.gz'),'w:gz',dereference=False) as archive:archive.add(fixture,arcname=runtime)
 shutil.rmtree(fixture);row['fixture_archived_and_removed']=True
 (out/'manifest.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(row),flush=True)
