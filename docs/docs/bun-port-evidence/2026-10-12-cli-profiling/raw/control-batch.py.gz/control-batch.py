from pathlib import Path
import subprocess,json,os
p=Path('zig-out/vm-retention-owner-2026-10-12');rows=[]
for name in ['caller-lifetime','caller-order']:
 with (p/(name+'.log')).open('wb') as log:r=subprocess.run(['./zig-out/bin/home','run',str(p/(name+'.mjs'))],stdout=log,stderr=subprocess.STDOUT,timeout=60,env=os.environ.copy())
 rows.append({'name':name,'exit':r.returncode});print(name,r.returncode,flush=True)
(p/'controls.json').write_text(json.dumps(rows,indent=2)+'\n')
