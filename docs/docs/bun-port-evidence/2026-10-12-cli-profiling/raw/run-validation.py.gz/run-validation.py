from pathlib import Path
import subprocess,os,json,sys
p=Path('zig-out/vm-retention-owner-2026-10-12');rows=[]
commands=[['./zig-out/bin/home','run','tests/runtime/native-profiling-cli.test.mjs'],[sys.executable,str(p/'run-profiling-originals.py')],['./zig-out/bin/home','run','tests/runtime/native-vm-memory.test.mjs'],['./zig-out/bin/home','run','tests/runtime/native-corpus-suite.test.mjs'],['./zig-out/bin/home','run','tests/runtime/native-async-context.test.mjs'],['./zig-out/bin/home','run','tests/runtime/native-worker-fs-task-shutdown.test.mjs'],['/Users/chris/.bun/bin/bun','test','build-support/native_module_abi.test.ts','build-support/core_builtin_abi.test.ts','build-support/builtin_exports.test.ts'],[sys.executable,'-B','scripts/test_summarize_bun_corpus.py']]
for index,command in enumerate(commands,1):
 with (p/f'validation-{index}.log').open('wb') as log:r=subprocess.run(command,env=os.environ.copy(),stdout=log,stderr=subprocess.STDOUT,timeout=600)
 rows.append({'command':command,'exit':r.returncode});(p/'validation.json').write_text(json.dumps(rows,indent=2)+'\n');print(index,r.returncode,flush=True)
 if r.returncode:sys.exit(r.returncode)
