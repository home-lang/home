import vm from 'node:vm'
const tick=()=>new Promise(resolve=>setImmediate(resolve))
function release(mode){const context=vm.createContext({});if(mode==='module')vm.runInContext('globalThis.value=42;undefined',context);else new vm.Script('globalThis.value=42;undefined').runInContext(context);return new WeakRef(context)}
const rows=['script','module'].map(mode=>({mode,weak:release(mode)}))
for(let i=0;i<4;i++){await tick();Bun.gc(true)}
for(const row of rows)console.log(row.mode,'cleared',row.weak.deref()===undefined)
