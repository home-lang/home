from pathlib import Path
import os,subprocess,json,hashlib,sys
root=Path.cwd();task=root/'zig-out/vm-retention-owner-2026-10-12';out=task/'original-profiling';out.mkdir(exist_ok=True);rows=[]
for index,name in enumerate(['cli/heap-prof.test.ts','cli/run/cpu-prof.test.ts'],1):
 env=os.environ.copy();env['HOME_BUN_CORPUS_REPORT_DIR']=str(out/f'report-{index}');env['BUN_DEBUG_QUIET_LOGS']='1'
 for key in ['HOME_NATIVE_VM','HOME_CORPUS_FULL_VM','HOME_NATIVE_RUN']:env.pop(key,None)
 command=[str(root/'zig-out/bin/home'),'test',str(root/'packages/runtime/test/test'/name)]
 with (out/f'run-{index}.log').open('wb') as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=240)
 with (out/f'validate-{index}.json').open('wb') as log:v=subprocess.run([sys.executable,'scripts/summarize-bun-corpus.py',str(out/f'report-{index}')],stdout=log,stderr=subprocess.STDOUT)
 rows.append({'file':name,'command':command,'exit':r.returncode,'validation_exit':v.returncode});print(name,r.returncode,v.returncode,flush=True)
(out/'summary.json').write_text(json.dumps({'executable_sha256':hashlib.sha256((root/'zig-out/bin/home').read_bytes()).hexdigest(),'rows':rows},indent=2)+'\n')
sys.exit(0 if all(x['exit']==0 and x['validation_exit']==0 for x in rows) else 1)
