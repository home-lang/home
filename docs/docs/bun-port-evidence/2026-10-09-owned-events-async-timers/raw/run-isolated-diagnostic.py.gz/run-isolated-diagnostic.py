from pathlib import Path
import os,json,subprocess,tempfile,time,hashlib
root=Path(__file__).resolve().parents[2];task=root/'zig-out/events-async-port-2026-10-09';out=task/'diagnostics-isolated';out.mkdir(exist_ok=True);exe=root/'zig-out/bin/home';records=[]
with tempfile.TemporaryDirectory(prefix='home-async-diagnostics-') as tmp:
 env=os.environ.copy();env.update(HOME_NATIVE_VM='1',HOME_CORPUS_FULL_VM='1',BUN_DEBUG_QUIET_LOGS='1',BUN_ENABLE_CRASH_REPORTING='0',BUN_FEATURE_FLAG_INTERNAL_FOR_TESTING='1',TMPDIR=tmp,TEST_TMPDIR=tmp)
 for key in ['HOME_NATIVE_RUN','HOME_BUN_CORPUS_REPORT_DIR']:env.pop(key,None)
 jobs=[('websocket-todo',[str(exe),'test','--todo','--test-name-pattern','WebSocket client','--config='+str(root/'packages/runtime/test/bunfig.toml'),'--timeout=90000','--reporter=junit','--reporter-outfile',str(out/'websocket-todo.junit.xml'),str(root/'packages/runtime/test/test/js/node/async_hooks/AsyncLocalStorage.test.ts')])]
 for name,command in jobs:
  start=time.monotonic()
  with (out/(name+'.log')).open('wb') as log:
   try:
    result=subprocess.run(command,cwd=root/'packages/runtime/test',env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180);code=result.returncode
   except subprocess.TimeoutExpired:code=124
  records.append({'name':name,'argv':command,'exit':code,'seconds':round(time.monotonic()-start,3)})
  print(name,code,flush=True)
(out/'summary.json').write_text(json.dumps({'executable_sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'records':records},indent=2)+'\n')
