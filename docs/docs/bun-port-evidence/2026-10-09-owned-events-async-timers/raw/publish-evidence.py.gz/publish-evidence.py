from pathlib import Path
import json,gzip,hashlib,subprocess,tempfile
root=Path(__file__).resolve().parents[2];source=root/'zig-out/events-async-port-2026-10-09';dest=root/'docs/docs/bun-port-evidence/2026-10-09-owned-events-async-timers';dest.mkdir(parents=True,exist_ok=True);files=[]
def retain(data,name):
 p=dest/(name+'.gz');p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(gzip.compress(data,mtime=0));files.append({'path':str(p.relative_to(dest)),'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
for p in sorted(source.rglob('*')):
 if p.is_file() and p.suffix in ['.json','.jsonl','.log','.xml','.stdout','.stderr','.txt','.ts','.py']:
  retain(p.read_bytes(),'raw/'+str(p.relative_to(source)))
tracked=['build.zig','build-support/bundle-native-modules.ts','build-support/bundle-native-modules.test.ts','build-support/native_bindings.zig','tests/runtime/native-async-context.test.mjs']+['packages/runtime/upstream/src/js/'+name for name in ['node/events.ts','node/async_hooks.ts','node/timers.ts','node/timers.promises.ts','internal/async_hooks.ts','internal/async_hooks_tick.ts']]+['packages/runtime/upstream/src/jsc/bindings/'+name for name in ['NodeAsyncHooks.cpp','NodeAsyncHooks.h']]
for name in tracked:retain((root/name).read_bytes(),'source/'+name)
manifest={'schema':1,'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'upstream':'4982b91e3702094330f3be3883354c52b8c01323','platform':'Darwin arm64','results':json.loads((source/'main/validated-totals.json').read_text()),'scope':'8 explicit original events/async-context/timer files; 3 original TODOs remain unresolved. Whole-suite, release-mode, other-platform and remaining native ownership parity remain incomplete.','files':files}
(dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for row in files:assert hashlib.sha256(gzip.decompress((dest/row['path']).read_bytes())).hexdigest()==row['sha256']
with tempfile.TemporaryDirectory(prefix='home-node-builtin-evidence-') as temp:
 restored=Path(temp)
 for row in files:
  if row['path'].startswith('raw/main/corpus-'):
   path=restored/row['path'].removeprefix('raw/main/').removesuffix('.gz');path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(gzip.decompress((dest/row['path']).read_bytes()))
 for index in range(1,9):
  result=subprocess.run(['python3',str(root/'scripts/summarize-bun-corpus.py'),str(restored/f'corpus-{index}')],capture_output=True,text=True,cwd=root);assert result.returncode==0,(index,result.stdout,result.stderr)
print(json.dumps({'compressed_artifacts':len(files),'restored_validated_reports':8,'destination':str(dest)}))
