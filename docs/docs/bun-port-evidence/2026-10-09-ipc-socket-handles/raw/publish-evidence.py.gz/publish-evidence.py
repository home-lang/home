from pathlib import Path
import json,gzip,hashlib,subprocess,tempfile
root=Path(__file__).resolve().parents[2];source=root/'zig-out/ipc-handles-port-2026-10-09';dest=root/'docs/docs/bun-port-evidence/2026-10-09-ipc-socket-handles';dest.mkdir(parents=True,exist_ok=True);files=[]
def retain(data,name):
 p=dest/(name+'.gz');p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(gzip.compress(data,mtime=0));files.append({'path':str(p.relative_to(dest)),'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
for p in sorted(source.rglob('*')):
 if p.is_file() and p.suffix in ['.json','.jsonl','.log','.xml','.stdout','.stderr','.txt','.ts','.py','.mjs','.cjs','.diff','.cpp','.h','.js']:
  retain(p.read_bytes(),'raw/'+str(p.relative_to(source)))
tracked=['build-support/bundle-native-modules.ts', 'build-support/bundle-native-modules.test.ts', 'build-support/native_bindings.zig', 'build-support/native_module_abi.ts', 'build-support/native_module_abi.test.ts', 'packages/runtime/src/jsc/ipc.zig', 'packages/runtime/src/runtime/socket/udp_socket.zig', 'packages/runtime/src/uws_sys/udp.zig', 'packages/runtime/upstream/src/js/builtins/Ipc.ts', 'packages/runtime/upstream/src/js/node/dgram.ts', 'packages/runtime/upstream/src/js/node/net.ts', 'packages/runtime/upstream/src/jsc/bindings/IPC.cpp', 'packages/runtime/upstream/src/uws_sys/HomeUws.cpp', 'packages/runtime/upstream/src/uws_sys/HomeUDPFD.cpp', 'tests/runtime/native-spawn-sync-ipc.test.mjs', 'tests/runtime/fixtures/ipc-handle-failure-peer.js', 'tests/runtime/fixtures/ipc-receive-handles-peer.js', 'tests/runtime/fixtures/ipc-send-handles-peer.js']
for name in tracked:retain((root/name).read_bytes(),'source/'+name)
manifest={'schema':1,'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'upstream':'4982b91e3702094330f3be3883354c52b8c01323','platform':'Darwin arm64','results':json.loads((source/'final/validated-totals.json').read_text()),'scope':'11 explicit original socket/UDP/IPC/cluster suites, two runs. Native controls cover bidirectional Node/Home and Home/Home TCP/UDP transfer, listener receipt, 2 MiB envelopes, keepOpen, NACK retransmission/exhaustion, queued callbacks, disconnect and invalid UDP/file descriptor ownership. Original skips receive no passing credit. Windows handle transport, cluster connection tracking, malformed/closed handles, GC/stress, complete native/registry ownership, whole-suite, Release/ASAN and other-platform parity remain incomplete.','files':files}
(dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for row in files:assert hashlib.sha256(gzip.decompress((dest/row['path']).read_bytes())).hexdigest()==row['sha256']
with tempfile.TemporaryDirectory(prefix='home-node-builtin-evidence-') as temp:
 restored=Path(temp)
 for row in files:
  if row['path'].startswith('raw/final/corpus-'):
   path=restored/row['path'].removeprefix('raw/final/').removesuffix('.gz');path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(gzip.decompress((dest/row['path']).read_bytes()))
 for index in range(1,12):
  result=subprocess.run(['python3',str(root/'scripts/summarize-bun-corpus.py'),str(restored/f'corpus-{index}')],capture_output=True,text=True,cwd=root);assert result.returncode==0,(index,result.stdout,result.stderr)
print(json.dumps({'compressed_artifacts':len(files),'restored_validated_reports':11,'destination':str(dest)}))
