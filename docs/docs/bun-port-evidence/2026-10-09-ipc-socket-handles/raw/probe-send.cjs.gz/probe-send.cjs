const assert=require('node:assert/strict');const {fork}=require('node:child_process');const net=require('node:net');const dgram=require('node:dgram');const fs=require('node:fs');const os=require('node:os');const path=require('node:path');
const home=process.argv[2],dir=fs.mkdtempSync(path.join(os.tmpdir(),'home-send-handles-')),script=path.join(dir,'sender.cjs');
fs.writeFileSync(script,`
const net=require('node:net'),dgram=require('node:dgram');let tcp,udp,listener;
process.on('uncaughtException',e=>{console.error(e);process.exit(1)});
listener=net.createServer(socket=>{tcp=socket;process.send('tcp',socket,{keepOpen:false},error=>{if(error)throw error;listener.close();process.send('tcp-ack');});});
listener.listen(0,'127.0.0.1',()=>process.send({tcpPort:listener.address().port}));
process.on('message',kind=>{if(kind==='udp'){udp=dgram.createSocket('udp4');udp.bind(0,'127.0.0.1',()=>process.send('udp',udp,error=>{if(error)throw error;udp.close();process.send('udp-ack');}));}if(kind==='finish')process.disconnect();});
`);
let diagnostics='',tcpDone=false,udpDone=false,udpHandle,client;const child=fork(script,[],{execPath:home,execArgv:[],env:{...process.env,HOME_NATIVE_VM:'1',BUN_DEBUG_QUIET_LOGS:'1'},stdio:['ignore','ignore','pipe','ipc']});
child.stderr.on('data',x=>diagnostics+=x);const timer=setTimeout(()=>{console.error('SEND_TIMEOUT',{tcpDone,udpDone},diagnostics);child.kill();if(client)client.destroy();process.exitCode=1;},10000);
child.on('message',(kind,handle)=>{if(kind.tcpPort){client=net.connect(kind.tcpPort,'127.0.0.1');let data='';client.setEncoding('utf8');client.on('data',x=>data+=x);client.on('end',()=>{assert.equal(data,'tcp-from-node');tcpDone=true;child.send('udp');});}if(kind==='tcp'){assert.ok(handle instanceof net.Socket);handle.end('tcp-from-node');}if(kind==='udp'){assert.ok(handle instanceof dgram.Socket);udpHandle=handle;handle.once('message',(data,peer)=>{assert.equal(data.toString(),'udp-from-node');udpDone=true;handle.close();child.send('finish');});}if(kind==='udp-ack'){const port=udpHandle.address().port;const s=dgram.createSocket('udp4');s.send('udp-from-node',port,'127.0.0.1',e=>{if(e)throw e;s.close();});}});
child.on('exit',(code,signal)=>{clearTimeout(timer);fs.rmSync(dir,{recursive:true,force:true});assert.equal(signal,null,diagnostics);assert.equal(code,0,diagnostics);assert.ok(tcpDone&&udpDone,diagnostics);console.log('Home sent TCP and UDP descriptors to Node');});
