const assert = require('node:assert/strict');
const { fork } = require('node:child_process');
const net = require('node:net');
const dgram = require('node:dgram');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const home = process.argv[2];
const dir = fs.mkdtempSync(path.join(os.tmpdir(),'home-handles-'));
const receiver = path.join(dir,'receiver.cjs');
fs.writeFileSync(receiver, `
const net = require('node:net'); const dgram = require('node:dgram');
process.on('uncaughtException', error => {console.error(error);process.exit(1);});
process.on('message', (kind, handle) => {console.error('HANDLE_KIND',kind,handle?.constructor?.name);
 if(kind==='tcp') { handle.end('tcp-from-home'); }
 if(kind==='udp') { handle.once('message', (data, peer) => {handle.send('udp-from-home',peer.port,peer.address,error=>{if(error)throw error;handle.close();});});process.send('udp-ready'); }
 if(kind==='finish')process.disconnect();
});
process.send('ready');
`);
let child; let diagnostics='';let tcpDone=false,udpDone=false;
const timer=setTimeout(()=>{console.error('HANDLE_TIMEOUT',JSON.stringify({tcpDone,udpDone}),diagnostics);if(child)child.kill();process.exitCode=1;},8000);
const server=net.createServer(socket=>{child.send('tcp',socket,{keepOpen:false});server.close();});
const udp=dgram.createSocket('udp4');
server.listen(0,'127.0.0.1',()=>{
 const port=server.address().port;
 child=fork(receiver,[],{execPath:home,execArgv:[],env:{...process.env,HOME_NATIVE_VM:'1',BUN_DEBUG_QUIET_LOGS:'1'},stdio:['ignore','ignore','pipe','ipc']});
 child.stderr.on('data',x=>diagnostics+=x);
 child.on('message',message=>{
  if(message==='ready') {const client=net.connect(port,'127.0.0.1');let text='';client.setEncoding('utf8');client.on('data',x=>text+=x);client.on('end',()=>{assert.equal(text,'tcp-from-home');console.error('TCP_DONE');tcpDone=true;udp.bind(0,'127.0.0.1',()=>child.send('udp',udp));});}
  if(message==='udp-ready'){console.error('UDP_READY');const port=udp.address().port;udp.close(()=>{const client=dgram.createSocket('udp4');client.on('message',data=>{assert.equal(data.toString(),'udp-from-home');udpDone=true;client.close();child.send('finish');});client.send('ping',port,'127.0.0.1');});}
 });
 child.on('exit',(code,signal)=>{clearTimeout(timer);server.close();try{udp.close();}catch{}fs.rmSync(dir,{recursive:true,force:true});assert.equal(signal,null,diagnostics);assert.equal(code,0,diagnostics);assert.ok(tcpDone&&udpDone,diagnostics);console.log('Home received TCP and UDP descriptors from Node');});
});
