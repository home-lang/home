(function () {"use strict";
// zig-out/ipc-handles-port-2026-10-09/generated-net-2/NodeAssertStrict.mts
var $;
$ = (@getInternalField(@internalModuleRegistry, 103) || @createInternalModuleById(103)).strict;
return $

})
