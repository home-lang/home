from pathlib import Path
import subprocess,os,json
p=Path(__file__).resolve().parent;rows=[]
for runtime,c in [('node',['node','--expose-gc']),('home',['./zig-out/bin/home'])]:
 with (p/(runtime+'-ordinary-weakref.log')).open('wb') as log:r=subprocess.run(c+[str(p/'weakref-job-reference.mjs')],env=os.environ,stdout=log,stderr=subprocess.STDOUT,timeout=30)
 rows.append({'runtime':runtime,'exit':r.returncode});print(runtime,r.returncode,flush=True)
(p/'weakref-results.json').write_text(json.dumps(rows,indent=2)+'\n')
