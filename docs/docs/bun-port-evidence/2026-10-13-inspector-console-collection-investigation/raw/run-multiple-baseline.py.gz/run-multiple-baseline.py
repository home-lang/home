from pathlib import Path
import subprocess,json,os
p=Path(__file__).resolve().parent;rows=[]
for runtime,c in [('node',['node','--expose-gc']),('home',[str(p/'home-baseline')])]:
 with (p/(runtime+'-multiple-baseline.log')).open('wb') as log:r=subprocess.run(c+[str(p/'multiple-context-retention.mjs')],env=os.environ,stdout=log,stderr=subprocess.STDOUT,timeout=30)
 rows.append({'runtime':runtime,'exit':r.returncode});print(runtime,r.returncode,flush=True)
(p/'multiple-baseline-results.json').write_text(json.dumps(rows,indent=2)+'\n')
