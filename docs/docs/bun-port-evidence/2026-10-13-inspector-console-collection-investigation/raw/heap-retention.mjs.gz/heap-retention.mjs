import vm from 'node:vm';import {writeFileSync} from 'node:fs';
function make(){const sandbox={uniqueHeapMarker:'home-context-retention-marker'};vm.createContext(sandbox,{name:'retention-marker'});return new WeakRef(sandbox)}
const weak=make();for(let i=0;i<20;i++){await new Promise(r=>setImmediate(r));Bun.gc(true);await new Promise(r=>setImmediate(r));}const snapshot=Bun.generateHeapSnapshot();writeFileSync(process.argv[2],JSON.stringify(snapshot));process.stdout.write(JSON.stringify({alive:!!weak.deref(),keys:Object.keys(snapshot)})+'\n');
