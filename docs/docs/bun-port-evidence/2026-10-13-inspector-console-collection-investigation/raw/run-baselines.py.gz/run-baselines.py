from pathlib import Path
import subprocess,os,json
p=Path(__file__).resolve().parent;rows=[]
commands=[['./zig-out/bin/home',str(p/'console-protocol.mjs')],['./zig-out/bin/home',str(p/'heap-retention.mjs'),str(p/'heap.json')]]
for i,c in enumerate(commands,1):
 with (p/f'baseline-{i}.log').open('wb') as log:r=subprocess.run(c,env=os.environ.copy(),stdout=log,stderr=subprocess.STDOUT,timeout=60)
 rows.append({'command':c,'exit':r.returncode});print(i,r.returncode,flush=True)
(p/'baseline-results.json').write_text(json.dumps(rows,indent=2)+'\n')
