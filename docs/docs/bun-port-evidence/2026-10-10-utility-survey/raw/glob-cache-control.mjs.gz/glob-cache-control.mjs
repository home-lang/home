import assert from 'node:assert/strict';
import path from 'node:path';
for(let i=0;i<3;i++){
 assert.equal(path.win32.matchesGlob('foo/bar.js','foo\\*.js'),true);
 assert.equal(path.posix.matchesGlob('foo/bar.js','foo/*.js'),true);
 assert.equal(path.posix.matchesGlob('foo/bar.js','foo\\*.js'),false);
 assert.equal(path.win32.matchesGlob('foo/bar.js','foo/*.js'),true);
}
console.log('alternating POSIX/Windows glob patterns passed');
