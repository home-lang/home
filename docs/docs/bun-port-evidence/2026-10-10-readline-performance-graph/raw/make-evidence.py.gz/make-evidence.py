from pathlib import Path
import json,gzip,hashlib,subprocess,sys,re
root=Path(__file__).resolve().parents[2];task=Path(__file__).resolve().parent;base=root/'docs/docs/bun-port-evidence/2026-10-10-readline-performance-graph';base.mkdir(parents=True,exist_ok=True)
counts={};reports=[]
for path in sorted((task/'terminal').glob('validate-*.json')):
 data=json.loads(path.read_text());assert data['successful'],path
 for key,value in data['summary'].items():
  if isinstance(value,int):counts[key]=counts.get(key,0)+value
 reports.append(path.name)
assert len(reports)==31 and counts['failed']==0 and counts['skipped_files']==0
records=[]
def add(path,name):
 data=path.read_bytes();target=base/(name+'.gz');target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(gzip.compress(data,mtime=0));assert gzip.decompress(target.read_bytes())==data;records.append({'path':str(target.relative_to(base)),'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
for p in sorted(task.rglob('*')):
 if not p.is_file() or p.name.startswith('issue-') or 'manual-fixture' in p.parts:continue
 if p.suffix in ['.log','.json','.jsonl','.py','.stdout','.stderr','.xml']:
  add(p,'raw/'+str(p.relative_to(task)))
for name in json.loads((task/'ported-files.json').read_text()):add(root/'packages/runtime/upstream/src'/name,'source/packages/runtime/upstream/src/'+name)
for name in ['build-support/bundle-native-modules.ts','build-support/bundle-native-modules.test.ts','build-support/native_bindings.zig']:add(root/name,'source/'+name)
manifest={'schema':1,'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'upstream':'4982b91e3702094330f3be3883354c52b8c01323','platform':'Darwin arm64','results':{'original_files':31,'counts':counts,'native_regression_groups':7,'abi_tests':89,'abi_assertions':1406,'debug_steps':34,'debug_peak_tree_mb':5876,'conformance_peak_tree_mb':203,'host_tool':'Bun 1.4.2 (744846f84)','runtime_abi_gate':'Final Home executable'},'features':['Home owns six connected readline, terminal and performance registry modules and four native histogram/TTY sources.','Pinned readline completion/display behavior and Node performance entry observers execute from the owned module graph.','Native histogram uses standard quiet NaN without a suppressed macro; generation invalidates on every selected external class header.'],'limitations':['The TERM=dumb run retains 25 registered failures and seven skipped files; capable-terminal final run preserves original assertions and deadlines and executes all 31 files.','Older upstream host Bun loses captured child stderr during relative discovery; installed newer host and final Home ABI gates are independently recorded.','Compiler failures, outer ABI timeout and disk refusal are retained without passing credit.','Performance utilization/timing/resource APIs, independent delay-monitor lifetime, remaining module/native dependencies, complete Bun suite and Release/ASAN/all-platform parity are not established by this checkpoint.'],'files':records}
(base/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(len(records),'verified archives',counts)
