import assert from 'node:assert/strict'
import { Session } from 'node:inspector/promises'
import { Worker } from 'node:worker_threads'
const session=new Session();session.connect();await session.post('Profiler.enable');await session.post('Profiler.start')
const worker=new Worker(`const {parentPort}=require('node:worker_threads');const {Session}=require('node:inspector');const s=new Session();s.connect();s.disconnect();parentPort.postMessage('done')`,{eval:true})
const exit=new Promise((resolve,reject)=>{worker.once('exit',resolve);worker.once('error',reject)})
await new Promise((resolve,reject)=>{worker.once('message',resolve);worker.once('error',reject)})
assert.equal(await exit,0)
function ownProfileWork(){let n=0;for(let i=0;i<1000;i++)n+=Math.sqrt(i);return n}
const end=performance.now()+150;while(performance.now()<end)ownProfileWork()
const activeWorker=new Worker(`const {Session}=require('node:inspector');const s=new Session();s.connect();s.post('Profiler.enable');s.post('Profiler.start');const end=performance.now()+100;while(performance.now()<end)Math.sqrt(42)`,{eval:true})
assert.equal(await new Promise((resolve,reject)=>{activeWorker.once('exit',resolve);activeWorker.once('error',reject)}),0)
const result=await session.post('Profiler.stop');assert(result.profile.nodes.length>0);assert(result.profile.samples.length>0);session.disconnect()
console.log('worker session disconnect preserves parent CPU profiling')
