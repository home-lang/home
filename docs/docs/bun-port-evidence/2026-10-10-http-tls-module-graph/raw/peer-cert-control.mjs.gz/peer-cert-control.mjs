import { connect } from 'node:tls'
const socket = connect({ host: 'bun.sh', port: 443, servername: 'bun.sh' }, () => {
  const cert = socket.getPeerCertificate()
  console.log(JSON.stringify({ subject: cert.subject, issuer: cert.issuer, infoAccess: cert.infoAccess, valid_from: cert.valid_from, valid_to: cert.valid_to }))
  socket.end()
})
socket.on('error', error => { console.error(error); process.exitCode = 1 })
