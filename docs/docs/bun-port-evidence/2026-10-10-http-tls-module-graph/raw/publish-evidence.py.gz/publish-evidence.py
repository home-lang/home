from pathlib import Path
import subprocess,json,gzip,hashlib,tempfile,re
r=Path.cwd();t=r/'zig-out/http-tls-graph-port-2026-10-10';dest=r/'docs/docs/bun-port-evidence/2026-10-10-http-tls-module-graph';dest.mkdir(parents=True,exist_ok=True)
abi=(t/'abi-published.log').read_text();assert '81 pass' in abi and '0 fail' in abi
native=json.loads((t/'published-check-summary.json').read_text());assert all(row['exit']==0 for row in native if row['label']!='published-corpus')
assert 'Build Summary: 34/34 steps succeeded' in (t/'build-bun-contract-invalidated-cache.log').read_text()
selected=json.loads((t/'selection.json').read_text());latest={}
for phase in ['final-regular','published','maximum-final']:
 summary=t/phase/'summary.json'
 if not summary.exists():continue
 for i,row in enumerate(json.loads(summary.read_text())['records'],1):latest[row['file']]={**row,'stage':phase,'index':i}
assert set(latest)==set(selected),(len(latest),len(selected))
counts={key:0 for key in ['passed','failed','skipped','todo','process_checks_passed','skipped_files','comment_only_files','failed_files']}
for row in latest.values():
 d=json.loads((t/row['stage']/f"validate-{row['index']}.json").read_text())
 for key in counts:counts[key]+=d['summary'][key]
(t/'published-outcomes.json').write_text(json.dumps({'counts':counts,'files':list(latest.values()),'failed_files':[n for n,row in latest.items() if row['exit'] or row['validation_exit']]},indent=2)+'\n')
files=[]
def retain(data,name):
 p=dest/(name+'.gz');p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(gzip.compress(data,mtime=0));files.append({'path':str(p.relative_to(dest)),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
for p in sorted(t.rglob('*')):
 if p.is_file() and p.suffix in ['.json','.jsonl','.log','.xml','.ts','.mts','.js','.mjs','.py','.h','.cpp','.zig','.stdout','.stderr','.txt']:retain(p.read_bytes(),'raw/'+str(p.relative_to(t)))
for n,digest in json.loads((t/'tested-source-published.json').read_text()).items():
 data=(r/n).read_bytes();assert hashlib.sha256(data).hexdigest()==digest;retain(data,'source/'+n)
manifest={'schema':1,'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'upstream':'4982b91e3702094330f3be3883354c52b8c01323','platform':'Darwin arm64','scope':{'selected_original_files':len(selected),'ordinary_files':892,'maximum_files':1,'explicit_owned_registry_modules':112,'new_owned_modules':22,'internal_test_adapters':1},'counts':counts,'failed_files':[n for n,row in latest.items() if row['exit'] or row['validation_exit']],'verification':{'native_groups':18,'abi_tests':81,'abi_assertions':1332,'debug_build_steps':34},'scope_status':'Incomplete. Original failures, skips, TODOs and unexecuted platform coverage are not passing parity.','limitations':['All selected test sources match the pin. Seven pre-existing fixture differences are recorded; the two literal users of renewed HTTP certificates are outside this selection, but no blanket transitive fixture-identity claim is made.','The ordinary 4 GiB file could not fit the regular 3,840 MB guard. Dedicated original workload profiles and the pinned Bun control are retained; no assertion, allocation or original case deadline was reduced.','The broad final ordinary run tested a temporary Node range-message spelling. Published-source reruns supersede affected initial failures and the complete Bun HTTP2 suite after restoration of the Bun contract. The contradictory original assertions remain tracked in #868, without filename-sensitive behavior.','Incomplete guard-stopped reports and failed/refused launches are retained without passing credit. Internal HTTP2/Undici and native wire-state failures remain open in #867; TLS failures remain open in #532.','Full Bun-suite, remaining native ownership and Release/ASAN/all-platform parity remain unfinished.'],'resource_profiles':json.loads((t/'resource-profiles.json').read_text()),'latest_outcomes':list(latest.values()),'files':files}
(dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for row in files:
 data=gzip.decompress((dest/row['path']).read_bytes());assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
# Restore exactly the authoritative per-file stage, including failures, and
# check its validator result rather than requiring every report to be green.
with tempfile.TemporaryDirectory(prefix='home-http-evidence-') as temp:
 restored=Path(temp)
 for row in files:
  if row['path'].startswith('raw/') and '/corpus-' in row['path']:
   p=restored/row['path'].removeprefix('raw/').removesuffix('.gz');p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(gzip.decompress((dest/row['path']).read_bytes()))
 for row in latest.values():
  report=restored/row['stage']/f"corpus-{row['index']}";result=subprocess.run(['python3',str(r/'scripts/summarize-bun-corpus.py'),str(report)],capture_output=True,text=True);assert result.returncode==row['validation_exit'],(row['file'],result.returncode)
print(json.dumps({'archives':len(files),'restored_reports':len(latest),'counts':counts,'failed_files':len(manifest['failed_files'])}))
