var $;
const { hideFromStack } = (__intrinsic__getInternalField(__intrinsic__internalModuleRegistry, 38) || __intrinsic__createInternalModuleById(38));

const RegExpPrototypeExec = RegExp.prototype.exec;
const ArrayIsArray = Array.isArray;
const ObjectPrototypeHasOwnProperty = Object.prototype.hasOwnProperty;

const tokenRegExp = /^[\^_`a-zA-Z\-0-9!#$%&'*+.|~]+$/;
/**
 * Verifies that the given val is a valid HTTP token
 * per the rules defined in RFC 7230
 * See https://tools.ietf.org/html/rfc7230#section-3.2.6
 */
function checkIsHttpToken(val) {
  return RegExpPrototypeExec.__intrinsic__call(tokenRegExp, val) !== null;
}

/*
  The rules for the Link header field are described here:
  https://www.rfc-editor.org/rfc/rfc8288.html#section-3

  This regex validates any string surrounded by angle brackets
  (not necessarily a valid URI reference) followed by zero or more
  link-params separated by semicolons.

  The parameter name excludes "=" so it cannot overlap with the optional
  "=value" suffix; otherwise inputs like "<>;a=b;a=b;...;a=b " trigger
  catastrophic backtracking.
*/
const linkValueRegExp = /^(?:<[^>]*>)(?:\s*;\s*[^;"\s=]+(?:=(")?[^;"\s]*\1)?)*$/;
const linkValueForbiddenCharsRegExp = /[\r\n]/;
function validateLinkHeaderFormat(value, name) {
  if (
    typeof value === "undefined" ||
    !RegExpPrototypeExec.__intrinsic__call(linkValueRegExp, value) ||
    RegExpPrototypeExec.__intrinsic__call(linkValueForbiddenCharsRegExp, value) !== null
  ) {
    throw __intrinsic__makeErrorWithCode(120, 
      name,
      value,
      `must be an array or string of format "</styles.css>; rel=preload; as=style"`,
    );
  }
}

function validateLinkHeaderValue(hints) {
  if (typeof hints === "string") {
    validateLinkHeaderFormat(hints, "hints");
    return hints;
  } else if (ArrayIsArray(hints)) {
    const hintsLength = hints.length;
    let result = "";

    if (hintsLength === 0) {
      return result;
    }

    for (let i = 0; i < hintsLength; i++) {
      const link = hints[i];
      validateLinkHeaderFormat(link, "hints");
      result += link;

      if (i !== hintsLength - 1) {
        result += ", ";
      }
    }

    return result;
  }

  throw __intrinsic__makeErrorWithCode(120, 
    "hints",
    hints,
    `must be an array or string of format "</styles.css>; rel=preload; as=style"`,
  );
}

function validateString(value, name) {
  if (typeof value !== "string") throw __intrinsic__makeErrorWithCode(119, name, "string", value);
}

function validateFunction(value, name) {
  if (typeof value !== "function") throw __intrinsic__makeErrorWithCode(119, name, "function", value);
}

function validateBoolean(value, name) {
  if (typeof value !== "boolean") throw __intrinsic__makeErrorWithCode(119, name, "boolean", value);
}

function validateUndefined(value, name) {
  if (value !== undefined) throw __intrinsic__makeErrorWithCode(119, name, "undefined", value);
}

function validateInternalField(object, fieldKey, className) {
  if (typeof object !== "object" || object === null || !ObjectPrototypeHasOwnProperty.__intrinsic__call(object, fieldKey)) {
    throw __intrinsic__makeErrorWithCode(119, "this", className, object);
  }
}

/** Validate a string-or-URL path and return it resolved to an absolute path string. */
function getValidatedPath(p: any) {
  if (p instanceof URL) return Bun.fileURLToPath(p as URL);
  if (typeof p !== "string") throw __intrinsic__makeErrorWithCode(119, "path", "string or URL", p);
  if (p.startsWith("file:")) return Bun.fileURLToPath(p);
  return (__intrinsic__getInternalField(__intrinsic__internalModuleRegistry, 125) || __intrinsic__createInternalModuleById(125)).resolve(p);
}

function throwIfNullBytesInFileName(filename: string) {
  if (filename.indexOf("\u0000") !== -1) {
    throw __intrinsic__makeErrorWithCode(120, "path", "string without null bytes", filename);
  }
}

/**
 * node's fs getValidatedPath (lib/internal/fs/utils.js): converts URL
 * *instances* via fileURLToPath, accepts strings and Buffers as-is (no
 * path.resolve, no "file:"-prefix string sniffing), and rejects null bytes.
 */
function getValidatedFsPath(p: any, propName: string = "path") {
  if (p instanceof URL) p = Bun.fileURLToPath(p);
  if (typeof p === "string") {
    if (p.indexOf("\u0000") !== -1) {
      throw __intrinsic__makeErrorWithCode(120, propName, p, "must be a string, Uint8Array, or URL without null bytes");
    }
    return p;
  }
  if (p instanceof Uint8Array) {
    if (p.indexOf(0) !== -1) {
      throw __intrinsic__makeErrorWithCode(120, propName, p, "must be a string, Uint8Array, or URL without null bytes");
    }
    return p;
  }
  throw __intrinsic__makeErrorWithCode(119, propName, ["string", "Buffer", "URL"], p);
}

hideFromStack(validateLinkHeaderValue, validateInternalField);
hideFromStack(validateString, validateFunction, validateBoolean, validateUndefined);
hideFromStack(getValidatedPath, getValidatedFsPath, throwIfNullBytesInFileName);

$ = {
  /** (value, name) */
  validateObject: __intrinsic__lazy(27),
  validateLinkHeaderValue: validateLinkHeaderValue,
  checkIsHttpToken: checkIsHttpToken,
  /** `(value, name, min, max)` */
  validateInteger: __intrinsic__lazy(28),
  /** `(value, name, min, max)` */
  validateNumber: __intrinsic__lazy(29),
  /** `(value, name)` */
  validateString,
  /** `(number, name)` */
  validateFiniteNumber: __intrinsic__lazy(30),
  /** `(number, name, lower, upper, def)` */
  checkRangesOrGetDefault: __intrinsic__lazy(31),
  /** `(value, name)` */
  validateFunction,
  /** `(value, name)` */
  validateBoolean,
  /** `(port, name = 'Port', allowZero = true)` */
  validatePort: __intrinsic__lazy(32),
  /** `(signal, name)` */
  validateAbortSignal: __intrinsic__lazy(33),
  /** `(value, name, minLength = 0)` */
  validateArray: __intrinsic__lazy(34),
  /** `(value, name, min = -2147483648, max = 2147483647)` */
  validateInt32: __intrinsic__lazy(35),
  /** `(value, name, positive = false)` */
  validateUint32: __intrinsic__lazy(36),
  /** `(signal, name = 'signal')` */
  validateSignalName: __intrinsic__lazy(37),
  /** `(data, encoding)` */
  validateEncoding: __intrinsic__lazy(38),
  /** `(value, name)` */
  validatePlainFunction: __intrinsic__lazy(39),
  /** `(value, name)` */
  validateUndefined,
  /** `(buffer, name = 'buffer')` */
  validateBuffer: __intrinsic__lazy(40),
  /** `(value, name, oneOf)` */
  validateOneOf: __intrinsic__lazy(41),
  isUint8Array: value => value instanceof Uint8Array,
  /** `(object, fieldKey, className)` */
  validateInternalField,
  /** `(path)` — accepts a string or file URL, returns it resolved to an absolute path string */
  getValidatedPath,
  getValidatedFsPath,
  /** `(filename)` */
  throwIfNullBytesInFileName,
};
;$$EXPORT$$($).$$EXPORT_END$$;
