(function () {"use strict";
// .zig-cache/o/bb9353210c22a89660eb2e4b9083cc39/native-modules/InternalValidators.mts
var $, { hideFromStack } = @getInternalField(@internalModuleRegistry, 38) || @createInternalModuleById(38), RegExpPrototypeExec = @RegExp.prototype.exec, ArrayIsArray = @Array.isArray, ObjectPrototypeHasOwnProperty = Object.prototype.hasOwnProperty, tokenRegExp = /^[\^_`a-zA-Z\-0-9!#$%&'*+.|~]+$/;
function checkIsHttpToken(val) {
  return RegExpPrototypeExec.@call(tokenRegExp, val) !== null;
}
var linkValueRegExp = /^(?:<[^>]*>)(?:\s*;\s*[^;"\s=]+(?:=(")?[^;"\s]*\1)?)*$/, linkValueForbiddenCharsRegExp = /[\r\n]/;
function validateLinkHeaderFormat(value, name) {
  if (typeof value > "u" || !RegExpPrototypeExec.@call(linkValueRegExp, value) || RegExpPrototypeExec.@call(linkValueForbiddenCharsRegExp, value) !== null)
    throw @makeErrorWithCode(120, name, value, 'must be an array or string of format "</styles.css>; rel=preload; as=style"');
}
function validateLinkHeaderValue(hints) {
  if (typeof hints === "string")
    return validateLinkHeaderFormat(hints, "hints"), hints;
  else if (ArrayIsArray(hints)) {
    let hintsLength = hints.length, result = "";
    if (hintsLength === 0)
      return result;
    for (let i = 0;i < hintsLength; i++) {
      let link = hints[i];
      if (validateLinkHeaderFormat(link, "hints"), result += link, i !== hintsLength - 1)
        result += ", ";
    }
    return result;
  }
  throw @makeErrorWithCode(120, "hints", hints, 'must be an array or string of format "</styles.css>; rel=preload; as=style"');
}
function validateString(value, name) {
  if (typeof value !== "string")
    throw @makeErrorWithCode(119, name, "string", value);
}
function validateFunction(value, name) {
  if (typeof value !== "function")
    throw @makeErrorWithCode(119, name, "function", value);
}
function validateBoolean(value, name) {
  if (typeof value !== "boolean")
    throw @makeErrorWithCode(119, name, "boolean", value);
}
function validateUndefined(value, name) {
  if (value !== @undefined)
    throw @makeErrorWithCode(119, name, "undefined", value);
}
function validateInternalField(object, fieldKey, className) {
  if (typeof object !== "object" || object === null || !ObjectPrototypeHasOwnProperty.@call(object, fieldKey))
    throw @makeErrorWithCode(119, "this", className, object);
}
function getValidatedPath(p) {
  if (p instanceof URL)
    return Bun.fileURLToPath(p);
  if (typeof p !== "string")
    throw @makeErrorWithCode(119, "path", "string or URL", p);
  if (p.startsWith("file:"))
    return Bun.fileURLToPath(p);
  return (@getInternalField(@internalModuleRegistry, 125) || @createInternalModuleById(125)).resolve(p);
}
function throwIfNullBytesInFileName(filename) {
  if (filename.indexOf("\x00") !== -1)
    throw @makeErrorWithCode(120, "path", "string without null bytes", filename);
}
function getValidatedFsPath(p, propName = "path") {
  if (p instanceof URL)
    p = Bun.fileURLToPath(p);
  if (typeof p === "string") {
    if (p.indexOf("\x00") !== -1)
      throw @makeErrorWithCode(120, propName, p, "must be a string, Uint8Array, or URL without null bytes");
    return p;
  }
  if (p instanceof @Uint8Array) {
    if (p.indexOf(0) !== -1)
      throw @makeErrorWithCode(120, propName, p, "must be a string, Uint8Array, or URL without null bytes");
    return p;
  }
  throw @makeErrorWithCode(119, propName, ["string", "Buffer", "URL"], p);
}
hideFromStack(validateLinkHeaderValue, validateInternalField);
hideFromStack(validateString, validateFunction, validateBoolean, validateUndefined);
hideFromStack(getValidatedPath, getValidatedFsPath, throwIfNullBytesInFileName);
$ = {
  validateObject: @lazy(27),
  validateLinkHeaderValue,
  checkIsHttpToken,
  validateInteger: @lazy(28),
  validateNumber: @lazy(29),
  validateString,
  validateFiniteNumber: @lazy(30),
  checkRangesOrGetDefault: @lazy(31),
  validateFunction,
  validateBoolean,
  validatePort: @lazy(32),
  validateAbortSignal: @lazy(33),
  validateArray: @lazy(34),
  validateInt32: @lazy(35),
  validateUint32: @lazy(36),
  validateSignalName: @lazy(37),
  validateEncoding: @lazy(38),
  validatePlainFunction: @lazy(39),
  validateUndefined,
  validateBuffer: @lazy(40),
  validateOneOf: @lazy(41),
  isUint8Array: (value) => value instanceof @Uint8Array,
  validateInternalField,
  getValidatedPath,
  getValidatedFsPath,
  throwIfNullBytesInFileName
};
return $

})
