(function (){"use strict";// build/release/tmp_modules/internal-for-testing.ts
var $, fmtBinding = @lazy(99), highlightJavaScript = (code) => fmtBinding(code, "highlight-javascript"), highlightJavaScriptRedacted = (code) => fmtBinding(code, "highlight-javascript-redacted"), escapePowershell = (code) => fmtBinding(code, "escape-powershell"), canonicalizeIP = @lazy(81), xxHash3ForTesting = @lazy(100), SQL = @lazy(1), patchInternals = {
  parse: @lazy(101),
  apply: @lazy(102),
  makeDiff: @lazy(103)
}, internalSourceMap = {
  fromVLQ: @lazy(104),
  toVLQ: @lazy(105),
  find: @lazy(106)
}, shellLex = @lazy(107), shellParse = @lazy(108), sslCtxLiveCount = @lazy(109), escapeRegExp = @lazy(110), escapeRegExpForPackageNameMatching = @lazy(111), shellInternals = {
  lex: (a, ...b) => shellLex(a.raw, b),
  parse: (a, ...b) => shellParse(a.raw, b),
  builtinDisabled: @lazy(112)
}, subprocessInternals = {
  injectStdioReadError: @lazy(113)
}, iniInternals = {
  parse: @lazy(114),
  loadNpmrc: @lazy(115)
}, cssInternals = {
  minifyTestWithOptions: @lazy(116),
  minifyErrorTestWithOptions: @lazy(117),
  testWithOptions: @lazy(118),
  prefixTestWithOptions: @lazy(119),
  minifyTest: @lazy(120),
  prefixTest: @lazy(121),
  _test: @lazy(122),
  attrTest: @lazy(123)
}, crash_handler = @lazy(124), upgrade_test_helpers = @lazy(125), install_test_helpers = @lazy(126), jscInternals = @lazy(127), nativeFrameForTesting = @lazy(128), memfd_create = @lazy(129), createStatsForIno = @lazy(130), setSyntheticAllocationLimitForTesting = @lazy(131), npm_manifest_test_helpers = @lazy(132), npa = @lazy(133), npmTag = @lazy(134), readTarball = @lazy(135), isArchitectureMatch = @lazy(136), isOperatingSystemMatch = @lazy(137), createSocketPair = @lazy(138), isModuleResolveFilenameSlowPathEnabled = @lazy(139), frameworkRouterInternals = @lazy(140), bindgen = @lazy(141), noOpForTesting = @lazy(142), isolatedModuleCacheSourceType = @lazy(143), Dequeue = @getInternalField(@internalModuleRegistry, 20) || @createInternalModuleById(20);
const { Duplex: HomeDuplex } = (@getInternalField(@internalModuleRegistry, 136) || @createInternalModuleById(136));
const HOME_UV_ECANCELED = -125;

// Logical port of Node v26.3.0's stream_wrap request surface. The pinned Bun
// source leaves this binding unimplemented, so Home owns these compatibility
// objects together with the JSStreamSocket adapter below.
class HomeStreamRequest {
  constructor() {
    this.oncomplete = null;
    this.callback = null;
    this.handle = null;
  }
}

class HomeShutdownWrap extends HomeStreamRequest {}
class HomeWriteWrap extends HomeStreamRequest {}

function homeStreamWrapError() {
  const error = new Error('Stream has StringDecoder set or is in objectMode');
  error.code = 'ERR_STREAM_WRAP';
  return error;
}

class HomeJSStreamSocket extends HomeDuplex {
  #writePending = 0;
  #shutdownRequest = null;
  #closed = false;

  constructor(stream) {
    super({ readable: stream.readable !== false, writable: stream.writable !== false });
    this.stream = stream;
    this._handle = { _parentWrap: this, shutdown: request => this.#shutdown(request) };

    stream.pause();
    stream.on('error', error => this.emit('error', error));
    const ondata = chunk => {
      if (typeof chunk === 'string' || stream.readableObjectMode === true) {
        stream.pause();
        stream.removeListener('data', ondata);
        this.emit('error', homeStreamWrapError());
        return;
      }
      if (!this.destroyed) this.push(chunk);
    };
    stream.on('data', ondata);
    stream.once('end', () => this.push(null));
    stream.once('close', () => {
      this.#closed = true;
      if (!this.destroyed) this.destroy();
    });

    // Match Node's JSStreamSocket startup: request the first read after every
    // forwarding listener exists, so decoded strings and object-mode chunks
    // are rejected even when userland has not attached a data consumer.
    this.read(0);
  }

  static get StreamWrap() {
    return HomeJSStreamSocket;
  }

  _read() {
    this.stream.resume();
  }

  _write(chunk, encoding, callback) {
    this.#writePending++;
    try {
      this.stream.write(chunk, encoding, error => {
        this.#writePending--;
        callback(error);
        this.#finishPendingShutdown();
      });
    } catch (error) {
      this.#writePending--;
      callback(error);
      this.#finishPendingShutdown();
    }
  }

  _final(callback) {
    this.stream.end(callback);
  }

  _destroy(error, callback) {
    this.#closed = true;
    this.stream.destroy(error ?? undefined);
    this.#finishShutdown(HOME_UV_ECANCELED);
    callback(error);
  }

  #shutdown(request) {
    if (this.#shutdownRequest !== null) return 0;
    this.#shutdownRequest = request;
    if (this.destroyed || this.#closed) queueMicrotask(() => this.#finishShutdown(HOME_UV_ECANCELED));
    else this.#finishPendingShutdown();
    return 0;
  }

  #finishPendingShutdown() {
    if (this.#shutdownRequest === null || this.#writePending !== 0) return;
    this.stream.end(() => this.#finishShutdown(0));
  }

  #finishShutdown(status) {
    const request = this.#shutdownRequest;
    if (request === null) return;
    this.#shutdownRequest = null;
    request.oncomplete?.(status);
  }
}

const homeStreamWrapBinding = {
  ShutdownWrap: HomeShutdownWrap,
  WriteWrap: HomeWriteWrap,
  kReadBytesOrError: 0,
  kArrayBufferOffset: 1,
  kBytesWritten: 2,
  kLastWriteWasAsync: 3,
  streamBaseState: new Int32Array(4),
};
function homeInternalTestBinding(name) {
  if (name === 'stream_wrap') return homeStreamWrapBinding;
  return process.binding(name);
}
var exposedInternals = {
  "internal/js_stream_socket": HomeJSStreamSocket,
  "internal/test/binding": { internalBinding: homeInternalTestBinding },
  "internal/streams/add-abort-signal": @getInternalField(@internalModuleRegistry, 47) || @createInternalModuleById(47),
  "internal/async_context_frame": @getInternalField(@internalModuleRegistry, 8) || @createInternalModuleById(8),
  "internal/async_hooks": @getInternalField(@internalModuleRegistry, 9) || @createInternalModuleById(9)
}, fs = (@getInternalField(@internalModuleRegistry, 115) || @createInternalModuleById(115)).@data, fsStreamInternals = {
  writeStreamFastPath(str) {
    return str[(@getInternalField(@internalModuleRegistry, 27) || @createInternalModuleById(27)).kWriteStreamFastPath];
  }
}, arrayBufferViewHasBuffer = @lazy(144), timerInternals = {
  timerClockMs: @lazy(145)
}, decodeURIComponentSIMD = @lazy(146), getDevServerDeinitCount = @lazy(147), getCounters = @lazy(148), linearFifoOrderedRemoveProbe = @lazy(149), hasNonReifiedStatic = @lazy(150), setSocketOptions = @lazy(151), structuredCloneAdvanced = @lazy(152), lsanDoLeakCheck = @lazy(153), isASANEnabled = @lazy(154), BunString_toThreadSafeRefCountDelta = @lazy(155), lowercaseHeaderNameSIMD = @lazy(156), getEventLoopStats = @lazy(157), hostedGitInfo = {
  parseUrl: @lazy(158),
  fromUrl: @lazy(159)
}, translateUVErrorToE = @lazy(160), translateNtStatusToE = @lazy(161), sysErrorNameFromLibuv = @lazy(162), sigactionLayout = @lazy(163), stringsInternals = {
  toUTF16AllocSentinel: @lazy(164)
}, fetchH2Internals = {
  liveCounts: @lazy(165)
}, fetchH3Internals = {
  liveCounts: @lazy(166)
}, fileSinkInternals = {
  liveCount: @lazy(167)
};
return{
  xxHash3ForTesting,
  upgrade_test_helpers,
  translateUVErrorToE,
  translateNtStatusToE,
  timerInternals,
  sysErrorNameFromLibuv,
  subprocessInternals,
  structuredCloneAdvanced,
  stringsInternals,
  sslCtxLiveCount,
  sigactionLayout,
  shellInternals,
  setSyntheticAllocationLimitForTesting,
  setSocketOptions,
  readTarball,
  patchInternals,
  npm_manifest_test_helpers,
  npmTag,
  npa,
  noOpForTesting,
  nativeFrameForTesting,
  memfd_create,
  lsanDoLeakCheck,
  lowercaseHeaderNameSIMD,
  linearFifoOrderedRemoveProbe,
  jscInternals,
  isolatedModuleCacheSourceType,
  isOperatingSystemMatch,
  isModuleResolveFilenameSlowPathEnabled,
  isArchitectureMatch,
  isASANEnabled,
  internalSourceMap,
  install_test_helpers,
  iniInternals,
  hostedGitInfo,
  highlightJavaScriptRedacted,
  highlightJavaScript,
  hasNonReifiedStatic,
  getEventLoopStats,
  getDevServerDeinitCount,
  getCounters,
  fsStreamInternals,
  fs,
  frameworkRouterInternals,
  fileSinkInternals,
  fetchH3Internals,
  fetchH2Internals,
  exposedInternals,
  escapeRegExpForPackageNameMatching,
  escapeRegExp,
  escapePowershell,
  decodeURIComponentSIMD,
  cssInternals,
  createStatsForIno,
  createSocketPair,
  crash_handler,
  canonicalizeIP,
  bindgen,
  arrayBufferViewHasBuffer,
  SQL,
  Dequeue,
  BunString_toThreadSafeRefCountDelta
};})
