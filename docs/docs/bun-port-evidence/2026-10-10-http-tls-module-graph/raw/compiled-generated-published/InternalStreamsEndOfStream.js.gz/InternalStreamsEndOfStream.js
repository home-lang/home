(function () {"use strict";
// .zig-cache/o/bb9353210c22a89660eb2e4b9083cc39/native-modules/InternalStreamsEndOfStream.mts
var $, { kEmptyObject, once } = @getInternalField(@internalModuleRegistry, 38) || @createInternalModuleById(38), { validateAbortSignal, validateFunction, validateObject, validateBoolean } = @getInternalField(@internalModuleRegistry, 86) || @createInternalModuleById(86), {
  isClosed,
  isReadable,
  isReadableNodeStream,
  isReadableStream,
  isReadableFinished,
  isReadableErrored,
  isWritable,
  isWritableNodeStream,
  isWritableStream,
  isWritableFinished,
  isWritableErrored,
  isNodeStream,
  willEmitClose: _willEmitClose,
  kIsClosedPromise
} = @getInternalField(@internalModuleRegistry, 76) || @createInternalModuleById(76), SymbolDispose = Symbol.dispose, PromisePrototypeThen = @Promise.prototype.@then, addAbortListener, AsyncResource;
function isRequest(stream) {
  return stream.setHeader && typeof stream.abort === "function";
}
var nop = () => {};
function bindAsyncResource(fn, type) {
  AsyncResource ??= (@getInternalField(@internalModuleRegistry, 104) || @createInternalModuleById(104)).AsyncResource;
  let resource = new AsyncResource(type);
  return function(...args) {
    return resource.runInAsyncScope(fn, this, ...args);
  };
}
function hasAsyncContext() {
  return @getInternalField(@asyncContext, 0) !== @undefined;
}
function getEosErrored(stream) {
  let errored = isWritableErrored(stream) || isReadableErrored(stream);
  return typeof errored !== "boolean" && errored || null;
}
function getEosOnCloseError(stream, readable, readableFinished, writable, writableFinished) {
  let errored = getEosErrored(stream);
  if (errored)
    return errored;
  if (readable && !readableFinished && isReadableNodeStream(stream, !0)) {
    if (!isReadableFinished(stream, !1))
      return @makeErrorWithCode(235);
  }
  if (writable && !writableFinished) {
    if (!isWritableFinished(stream, !1))
      return @makeErrorWithCode(235);
  }
  return null;
}
var kEosNodeSynchronousCallback = Symbol("kEosNodeSynchronousCallback");
function eos(stream, options, callback) {
  if (arguments.length === 2)
    callback = options, options = kEmptyObject;
  else if (options == null)
    options = kEmptyObject;
  else
    validateObject(options, "options");
  if (validateFunction(callback, "callback"), validateAbortSignal(options.signal, "options.signal"), isReadableStream(stream) || isWritableStream(stream))
    return eosWeb(stream, options, callback);
  if (!isNodeStream(stream))
    throw @makeErrorWithCode(119, "stream", ["ReadableStream", "WritableStream", "Stream"], stream);
  let readable = options.readable ?? isReadableNodeStream(stream), writable = options.writable ?? isWritableNodeStream(stream), willEmitClose = _willEmitClose(stream) && isReadableNodeStream(stream) === readable && isWritableNodeStream(stream) === writable, writableFinished = isWritableFinished(stream, !1), readableFinished = isReadableFinished(stream, !1), wState = stream._writableState, rState = stream._readableState, immediateResult;
  if (isClosed(stream))
    immediateResult = getEosOnCloseError(stream, readable, readableFinished, writable, writableFinished);
  else if (wState?.errorEmitted || rState?.errorEmitted) {
    if (!willEmitClose)
      immediateResult = getEosErrored(stream);
  } else if (!readable && (!willEmitClose || isReadable(stream)) && (writableFinished || isWritable(stream) === !1) && (wState == null || wState.pendingcb === @undefined || wState.pendingcb === 0))
    immediateResult = getEosErrored(stream);
  else if (!writable && (!willEmitClose || isWritable(stream)) && (readableFinished || isReadable(stream) === !1))
    immediateResult = getEosErrored(stream);
  else if (rState && stream.req && stream.aborted)
    immediateResult = getEosErrored(stream);
  let cleanup = () => {
    callback = nop;
  };
  if (immediateResult !== @undefined) {
    if (options.error !== !1)
      stream.on("error", nop), cleanup = () => {
        callback = nop, stream.removeListener("error", nop);
      };
  } else {
    let signal2 = options.signal;
    if (signal2?.aborted)
      immediateResult = @makeAbortError(@undefined, { cause: signal2.reason });
  }
  let invokeImmediate = () => {
    if (immediateResult === null)
      callback.@call(stream);
    else
      callback.@call(stream, immediateResult);
  };
  if (immediateResult !== @undefined && options[kEosNodeSynchronousCallback])
    return invokeImmediate(), cleanup;
  if (hasAsyncContext())
    callback = bindAsyncResource(callback, "STREAM_END_OF_STREAM");
  if (immediateResult !== @undefined)
    return process.nextTick(invokeImmediate), cleanup;
  callback = once(callback);
  let onlegacyfinish = () => {
    if (!stream.writable)
      onfinish();
  }, onfinish = () => {
    if (writableFinished = !0, stream.destroyed)
      willEmitClose = !1;
    if (willEmitClose && (!stream.readable || readable))
      return;
    if (!readable || readableFinished)
      callback.@call(stream);
  }, onend = () => {
    if (readableFinished = !0, stream.destroyed)
      willEmitClose = !1;
    if (willEmitClose && (!stream.writable || writable))
      return;
    if (!writable || writableFinished)
      callback.@call(stream);
  }, onerror = (err) => {
    callback.@call(stream, err);
  }, onclose = () => {
    let error = getEosOnCloseError(stream, readable, readableFinished, writable, writableFinished);
    if (error === null)
      callback.@call(stream);
    else
      callback.@call(stream, error);
  }, onrequest = () => {
    stream.req.on("finish", onfinish);
  };
  if (isRequest(stream)) {
    if (stream.on("complete", onfinish), !willEmitClose)
      stream.on("abort", onclose);
    if (stream.req)
      onrequest();
    else
      stream.on("request", onrequest);
  } else if (writable && !wState)
    stream.on("end", onlegacyfinish), stream.on("close", onlegacyfinish);
  if (!willEmitClose && typeof stream.aborted === "boolean")
    stream.on("aborted", onclose);
  if (stream.on("end", onend), stream.on("finish", onfinish), options.error !== !1)
    stream.on("error", onerror);
  stream.on("close", onclose), cleanup = () => {
    callback = nop, stream.removeListener("aborted", onclose), stream.removeListener("complete", onfinish), stream.removeListener("abort", onclose), stream.removeListener("request", onrequest);
    let streamReq = stream.req;
    if (streamReq)
      streamReq.removeListener("finish", onfinish);
    stream.removeListener("end", onlegacyfinish), stream.removeListener("close", onlegacyfinish), stream.removeListener("finish", onfinish), stream.removeListener("end", onend), stream.removeListener("error", onerror), stream.removeListener("close", onclose);
  };
  let signal = options.signal;
  if (signal) {
    let abort = () => {
      let endCallback = callback;
      cleanup(), endCallback.@call(stream, @makeAbortError(@undefined, { cause: signal.reason }));
    };
    addAbortListener ??= (@getInternalField(@internalModuleRegistry, 3) || @createInternalModuleById(3)).addAbortListener;
    let disposable = addAbortListener(signal, abort), originalCallback = callback;
    callback = once((...args) => {
      disposable[SymbolDispose](), originalCallback.@apply(stream, args);
    });
  }
  return cleanup;
}
function eosWeb(stream, options, callback) {
  if (hasAsyncContext())
    callback = once(bindAsyncResource(callback, "STREAM_END_OF_STREAM"));
  else
    callback = once(callback);
  let isAborted = !1, abort = nop, signal = options.signal;
  if (signal)
    if (abort = () => {
      isAborted = !0, callback.@call(stream, @makeAbortError(@undefined, { cause: signal.reason }));
    }, signal.aborted)
      process.nextTick(abort);
    else {
      addAbortListener ??= (@getInternalField(@internalModuleRegistry, 3) || @createInternalModuleById(3)).addAbortListener;
      let disposable = addAbortListener(signal, abort), originalCallback = callback;
      callback = once((...args) => {
        disposable[SymbolDispose](), originalCallback.@apply(stream, args);
      });
    }
  let resolverFn = (...args) => {
    if (!isAborted)
      process.nextTick(() => callback.@apply(stream, args));
  };
  return PromisePrototypeThen.@call(stream[kIsClosedPromise].promise, resolverFn, resolverFn), nop;
}
function finished(stream, opts) {
  let autoCleanup = !1;
  if (opts === null)
    opts = kEmptyObject;
  if (opts?.cleanup)
    validateBoolean(opts.cleanup, "cleanup"), autoCleanup = opts.cleanup;
  return new @Promise((resolve, reject) => {
    let cleanup = eos(stream, opts, (err) => {
      if (autoCleanup)
        cleanup();
      if (err)
        reject(err);
      else
        resolve();
    });
  });
}
eos.finished = finished;
eos.kEosNodeSynchronousCallback = kEosNodeSynchronousCallback;
$ = eos;
return $

})
