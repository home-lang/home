(function () {"use strict";
// .zig-cache/o/bb9353210c22a89660eb2e4b9083cc39/native-modules/NodeDNSPromises.mts
var $;
$ = (@getInternalField(@internalModuleRegistry, 112) || @createInternalModuleById(112)).promises;
return $

})
