(function () {"use strict";
// .zig-cache/o/bb9353210c22a89660eb2e4b9083cc39/native-modules/InternalTimers.mts
var $, { validateNumber } = @getInternalField(@internalModuleRegistry, 86) || @createInternalModuleById(86), NumberIsFinite = Number.isFinite;
function getTimerDuration(msecs, name) {
  if (validateNumber(msecs, name), msecs < 0 || !NumberIsFinite(msecs))
    throw @makeErrorWithCode(160, name, "a non-negative finite number", msecs);
  if (msecs > 2147483647)
    return process.emitWarning(`${msecs} does not fit into a 32-bit signed integer.
Timer duration was truncated to 2147483647.`, "TimeoutOverflowWarning"), 2147483647;
  return msecs;
}
$ = {
  kTimeout: Symbol("timeout"),
  getTimerDuration
};
return $

})
