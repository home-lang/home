(function () {"use strict";
// .zig-cache/o/bb9353210c22a89660eb2e4b9083cc39/native-modules/NodePathWin32.mts
var $;
$ = (@getInternalField(@internalModuleRegistry, 125) || @createInternalModuleById(125)).win32;
return $

})
