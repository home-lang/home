(function () {"use strict";
// .zig-cache/o/bb9353210c22a89660eb2e4b9083cc39/native-modules/NodeStreamWrap.mts
var $;
process.emitWarning("The _stream_wrap module is deprecated.", "DeprecationWarning", "DEP0125");
$ = @getInternalField(@internalModuleRegistry, 136) || @createInternalModuleById(136);
return $

})
