(function () {"use strict";
// .zig-cache/o/bb9353210c22a89660eb2e4b9083cc39/native-modules/InternalStreamsPassthrough.mts
var $, Transform = @getInternalField(@internalModuleRegistry, 75) || @createInternalModuleById(75);
function PassThrough(options) {
  if (!(this instanceof PassThrough))
    return new PassThrough(options);
  Transform.@call(this, options);
}
@toClass(PassThrough, "PassThrough", Transform);
PassThrough.prototype._transform = function(chunk, encoding, cb) {
  cb(null, chunk);
};
$ = PassThrough;
return $

})
