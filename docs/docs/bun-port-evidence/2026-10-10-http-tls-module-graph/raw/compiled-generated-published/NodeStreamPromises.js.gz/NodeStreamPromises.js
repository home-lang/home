(function () {"use strict";
// .zig-cache/o/bb9353210c22a89660eb2e4b9083cc39/native-modules/NodeStreamPromises.mts
var $;
$ = (@getInternalField(@internalModuleRegistry, 136) || @createInternalModuleById(136)).promises;
return $

})
