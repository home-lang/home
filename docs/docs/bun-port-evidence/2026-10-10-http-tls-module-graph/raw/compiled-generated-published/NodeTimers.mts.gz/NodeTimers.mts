var $;
const { throwNotImplemented } = (__intrinsic__getInternalField(__intrinsic__internalModuleRegistry, 38) || __intrinsic__createInternalModuleById(38));

var timersPromisesValue;

$ = {
  setTimeout,
  clearTimeout,
  setInterval,
  setImmediate,
  clearInterval,
  clearImmediate,
  get promises() {
    return (timersPromisesValue ??= (__intrinsic__getInternalField(__intrinsic__internalModuleRegistry, 139) || __intrinsic__createInternalModuleById(139)));
  },
  set promises(value) {
    timersPromisesValue = value;
  },
  active(timer) {
    if (__intrinsic__isCallable(timer?.refresh)) {
      timer.refresh();
    } else {
      throwNotImplemented("'timers.active'");
    }
  },
  unenroll(timer) {
    if (__intrinsic__isCallable(timer?.refresh)) {
      clearTimeout(timer);
      return;
    }

    throwNotImplemented("'timers.unenroll'");
  },
  enroll(timer, _msecs) {
    if (__intrinsic__isCallable(timer?.refresh)) {
      timer.refresh();
      return;
    }

    throwNotImplemented("'timers.enroll'");
  },
};
;$$EXPORT$$($).$$EXPORT_END$$;
