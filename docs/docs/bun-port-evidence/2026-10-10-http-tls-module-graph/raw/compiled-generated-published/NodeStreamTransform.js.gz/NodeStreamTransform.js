(function () {"use strict";
// .zig-cache/o/bb9353210c22a89660eb2e4b9083cc39/native-modules/NodeStreamTransform.mts
var $;
$ = @getInternalField(@internalModuleRegistry, 75) || @createInternalModuleById(75);
return $

})
