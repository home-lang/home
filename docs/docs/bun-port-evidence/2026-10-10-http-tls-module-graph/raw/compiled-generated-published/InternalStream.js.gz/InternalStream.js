(function () {"use strict";
// .zig-cache/o/bb9353210c22a89660eb2e4b9083cc39/native-modules/InternalStream.mts
var $, ObjectKeys = Object.keys, ObjectDefineProperty = Object.defineProperty, customPromisify = Symbol.for("nodejs.util.promisify.custom"), { streamReturningOperators, promiseReturningOperators } = @getInternalField(@internalModuleRegistry, 70) || @createInternalModuleById(70), compose = @getInternalField(@internalModuleRegistry, 48) || @createInternalModuleById(48), { setDefaultHighWaterMark, getDefaultHighWaterMark } = @getInternalField(@internalModuleRegistry, 74) || @createInternalModuleById(74), { pipeline } = @getInternalField(@internalModuleRegistry, 72) || @createInternalModuleById(72), { destroyer } = @getInternalField(@internalModuleRegistry, 49) || @createInternalModuleById(49), eos = @getInternalField(@internalModuleRegistry, 53) || @createInternalModuleById(53), promises = @getInternalField(@internalModuleRegistry, 45) || @createInternalModuleById(45), utils = @getInternalField(@internalModuleRegistry, 76) || @createInternalModuleById(76), { isArrayBufferView, isUint8Array } = @getInternalField(@internalModuleRegistry, 164) || @createInternalModuleById(164), Stream = (@getInternalField(@internalModuleRegistry, 68) || @createInternalModuleById(68)).Stream;
Stream.isDestroyed = utils.isDestroyed;
Stream.isDisturbed = utils.isDisturbed;
Stream.isErrored = utils.isErrored;
Stream.isReadable = utils.isReadable;
Stream.isWritable = utils.isWritable;
Stream.Readable = @getInternalField(@internalModuleRegistry, 73) || @createInternalModuleById(73);
var streamKeys = ObjectKeys(streamReturningOperators);
for (let i = 0;i < streamKeys.length; i++) {
  let fn2 = function(...args) {
    if (new.target)
      throw @makeErrorWithCode(115);
    return Stream.Readable.from(op.@apply(this, args));
  };
  fn = fn2;
  let key = streamKeys[i], op = streamReturningOperators[key];
  ObjectDefineProperty(fn2, "name", { __proto__: null, value: op.name }), ObjectDefineProperty(fn2, "length", { __proto__: null, value: op.length }), ObjectDefineProperty(Stream.Readable.prototype, key, {
    __proto__: null,
    value: fn2,
    enumerable: !1,
    configurable: !0,
    writable: !0
  });
}
var fn, promiseKeys = ObjectKeys(promiseReturningOperators);
for (let i = 0;i < promiseKeys.length; i++) {
  let fn2 = function(...args) {
    if (new.target)
      throw @makeErrorWithCode(115);
    return @Promise.@resolve().then(() => op.@apply(this, args));
  };
  fn = fn2;
  let key = promiseKeys[i], op = promiseReturningOperators[key];
  ObjectDefineProperty(fn2, "name", { __proto__: null, value: op.name }), ObjectDefineProperty(fn2, "length", { __proto__: null, value: op.length }), ObjectDefineProperty(Stream.Readable.prototype, key, {
    __proto__: null,
    value: fn2,
    enumerable: !1,
    configurable: !0,
    writable: !0
  });
}
var fn;
Stream.Writable = @getInternalField(@internalModuleRegistry, 77) || @createInternalModuleById(77);
Stream.Duplex = @getInternalField(@internalModuleRegistry, 50) || @createInternalModuleById(50);
Stream.Transform = @getInternalField(@internalModuleRegistry, 75) || @createInternalModuleById(75);
Stream.PassThrough = @getInternalField(@internalModuleRegistry, 71) || @createInternalModuleById(71);
Stream.duplexPair = @getInternalField(@internalModuleRegistry, 52) || @createInternalModuleById(52);
Stream.pipeline = pipeline;
var { addAbortSignal } = @getInternalField(@internalModuleRegistry, 47) || @createInternalModuleById(47);
Stream.addAbortSignal = addAbortSignal;
Stream.finished = eos;
Stream.destroy = destroyer;
Stream.compose = compose;
Stream.setDefaultHighWaterMark = setDefaultHighWaterMark;
Stream.getDefaultHighWaterMark = getDefaultHighWaterMark;
ObjectDefineProperty(Stream, "promises", {
  __proto__: null,
  configurable: !0,
  enumerable: !0,
  get() {
    return promises;
  }
});
ObjectDefineProperty(pipeline, customPromisify, {
  __proto__: null,
  enumerable: !0,
  get() {
    return promises.pipeline;
  }
});
ObjectDefineProperty(eos, customPromisify, {
  __proto__: null,
  enumerable: !0,
  get() {
    return promises.finished;
  }
});
Stream.Stream = Stream;
Stream._isArrayBufferView = isArrayBufferView;
Stream._isUint8Array = isUint8Array;
Stream._uint8ArrayToBuffer = function _uint8ArrayToBuffer(chunk) {
  return new @Buffer(chunk.buffer, chunk.byteOffset, chunk.byteLength);
};
$ = Stream;
return $

})
