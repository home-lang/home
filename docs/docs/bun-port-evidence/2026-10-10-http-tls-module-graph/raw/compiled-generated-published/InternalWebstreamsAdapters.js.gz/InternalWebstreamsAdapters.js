(function () {"use strict";
// .zig-cache/o/bb9353210c22a89660eb2e4b9083cc39/native-modules/InternalWebstreamsAdapters.mts
var $, {
  SafePromiseAllReturnVoid,
  SafeSet,
  TypedArrayPrototypeGetBuffer,
  TypedArrayPrototypeGetByteOffset,
  TypedArrayPrototypeGetByteLength
} = @getInternalField(@internalModuleRegistry, 36) || @createInternalModuleById(36), Writable = @getInternalField(@internalModuleRegistry, 77) || @createInternalModuleById(77), Readable = @getInternalField(@internalModuleRegistry, 73) || @createInternalModuleById(73), Duplex = @getInternalField(@internalModuleRegistry, 50) || @createInternalModuleById(50), { destroyer } = @getInternalField(@internalModuleRegistry, 49) || @createInternalModuleById(49), { isDestroyed, isReadable, isWritable, isWritableEnded } = @getInternalField(@internalModuleRegistry, 76) || @createInternalModuleById(76), { kEmptyObject } = @getInternalField(@internalModuleRegistry, 38) || @createInternalModuleById(38), { validateBoolean, validateObject, validateOneOf } = @getInternalField(@internalModuleRegistry, 86) || @createInternalModuleById(86), { isAnyArrayBuffer } = @getInternalField(@internalModuleRegistry, 164) || @createInternalModuleById(164), eos = @getInternalField(@internalModuleRegistry, 53) || @createInternalModuleById(53), { kEosNodeSynchronousCallback } = eos, normalizeEncoding = @lazy(42), ArrayPrototypeFilter = @Array.prototype.filter, ArrayPrototypeMap = @Array.prototype.map, ObjectEntries = Object.entries, ObjectDefineProperty = Object.defineProperty, StringPrototypeStartsWith = @String.prototype.startsWith, PromiseWithResolvers = @Promise.withResolvers.bind(@Promise), PromiseResolve = @Promise.@resolve.bind(@Promise), PromisePrototypeThen = @Promise.prototype.@then, SafePromisePrototypeFinally = @Promise.prototype.finally, constants_zlib = @processBindingConstants.zlib, kValidateChunk = Symbol("kValidateChunk"), kDestroyOnSyncError = Symbol("kDestroyOnSyncError");
function tryTransferToNativeReadable(stream, options) {
  let ptr = stream.@bunNativePtr;
  if (!ptr || ptr === -1)
    return @undefined;
  return (@getInternalField(@internalModuleRegistry, 69) || @createInternalModuleById(69)).constructNativeReadable(stream, options);
}

class ReadableFromWeb extends Readable {
  #reader;
  #closed;
  #pendingChunks;
  #stream;
  constructor(options, stream) {
    let { objectMode, highWaterMark, encoding, signal } = options;
    super({
      objectMode,
      highWaterMark,
      encoding,
      signal
    });
    this.#pendingChunks = [], this.#reader = @undefined, this.#stream = stream, this.#closed = !1;
  }
  #drainPending() {
    var pendingChunks = this.#pendingChunks, pendingChunksI = 0, pendingChunksCount = pendingChunks.length;
    for (;pendingChunksI < pendingChunksCount; pendingChunksI++) {
      let chunk = pendingChunks[pendingChunksI];
      if (pendingChunks[pendingChunksI] = @undefined, !this.push(chunk, @undefined))
        return this.#pendingChunks = pendingChunks.slice(pendingChunksI + 1), !0;
    }
    if (pendingChunksCount > 0)
      this.#pendingChunks = [];
    return !1;
  }
  #handleDone(reader) {
    reader.releaseLock(), this.#reader = @undefined, this.#closed = !0, this.push(null);
    return;
  }
  async _read() {
    var stream = this.#stream, reader = this.#reader;
    if (stream)
      reader = this.#reader = stream.getReader(), this.#stream = @undefined;
    else if (this.#drainPending())
      return;
    var deferredError;
    try {
      do {
        var done = !1, value;
        let firstResult = reader.readMany();
        if (@isPromise(firstResult)) {
          if ({ done, value } = await firstResult, this.#closed) {
            this.#pendingChunks.push(...value);
            return;
          }
        } else
          ({ done, value } = firstResult);
        if (done) {
          this.#handleDone(reader);
          return;
        }
        if (!this.push(value[0])) {
          this.#pendingChunks = value.slice(1);
          return;
        }
        for (let i = 1, count = value.length;i < count; i++)
          if (!this.push(value[i])) {
            this.#pendingChunks = value.slice(i + 1);
            return;
          }
      } while (!this.#closed);
    } catch (e) {
      deferredError = e;
    }
    if (deferredError)
      throw deferredError;
  }
  _destroy(error, callback) {
    if (!this.#closed) {
      var reader = this.#reader;
      if (reader)
        this.#reader = @undefined, reader.cancel(error).finally(() => {
          this.#closed = !0, callback(error);
        });
      return;
    }
    try {
      callback(error);
    } catch (error2) {
      globalThis.reportError(error2);
    }
  }
}
var encoder = /* @__PURE__ */ new TextEncoder, ZLIB_FAILURES = new SafeSet([
  ...ArrayPrototypeFilter.@call(ArrayPrototypeMap.@call(ObjectEntries(constants_zlib), ({ 0: code, 1: value }) => value < 0 ? code : null), Boolean),
  "Z_NEED_DICT"
]);
function handleKnownInternalErrors(cause) {
  let causeCode = cause?.code;
  switch (!0) {
    case causeCode === "ERR_STREAM_PREMATURE_CLOSE":
      return @makeAbortError(@undefined, { cause });
    case ZLIB_FAILURES.has(causeCode):
    case (causeCode != null && StringPrototypeStartsWith.@call(causeCode, "ERR__ERROR_")): {
      let error = @makeTypeError("");
      return ObjectDefineProperty(error, "cause", {
        __proto__: null,
        configurable: !0,
        enumerable: !1,
        value: cause,
        writable: !0
      }), ObjectDefineProperty(error, "code", {
        __proto__: null,
        configurable: !0,
        enumerable: !0,
        value: causeCode,
        writable: !0
      }), error;
    }
    default:
      return cause;
  }
}
var noop = () => {};
function newWritableStreamFromStreamWritable(streamWritable, options = kEmptyObject) {
  if (!(streamWritable && typeof streamWritable?.write === "function" && typeof streamWritable?.on === "function"))
    throw @makeErrorWithCode(119, "streamWritable", "stream.Writable", streamWritable);
  if (isDestroyed(streamWritable) || !isWritable(streamWritable)) {
    let writable = new @WritableStream;
    return writable.close(), writable;
  }
  let highWaterMark = streamWritable.writableHighWaterMark, strategy = streamWritable.writableObjectMode ? new CountQueuingStrategy({ highWaterMark }) : { highWaterMark }, controller, backpressurePromise, closed;
  function onDrain() {
    if (backpressurePromise !== @undefined)
      backpressurePromise.resolve();
  }
  let cleanup = eos(streamWritable, (error) => {
    if (error = handleKnownInternalErrors(error), cleanup(), streamWritable.on("error", () => {}), error != null) {
      if (backpressurePromise !== @undefined)
        backpressurePromise.reject(error);
      if (closed !== @undefined)
        closed.reject(error), closed = @undefined;
      controller.error(error), controller = @undefined;
      return;
    }
    if (closed !== @undefined) {
      closed.resolve(), closed = @undefined;
      return;
    }
    controller.error(@makeAbortError()), controller = @undefined;
  });
  return streamWritable.on("drain", onDrain), new @WritableStream({
    start(c) {
      controller = c;
    },
    write(chunk) {
      try {
        if (options[kValidateChunk]?.(chunk), !streamWritable.writableObjectMode && isAnyArrayBuffer(chunk))
          chunk = new @Uint8Array(chunk);
        if (streamWritable.writableNeedDrain || !streamWritable.write(chunk)) {
          if (backpressurePromise = PromiseWithResolvers(), !streamWritable.writableNeedDrain)
            backpressurePromise.resolve();
          return SafePromisePrototypeFinally.@call(backpressurePromise.promise, () => {
            backpressurePromise = @undefined;
          });
        }
      } catch (error) {
        if (options[kDestroyOnSyncError])
          destroyer(streamWritable, error);
        throw error;
      }
    },
    abort(reason) {
      destroyer(streamWritable, reason);
    },
    close() {
      if (closed === @undefined && !isWritableEnded(streamWritable))
        return closed = PromiseWithResolvers(), streamWritable.end(), closed.promise;
      return controller = @undefined, PromiseResolve();
    }
  }, strategy);
}
function newStreamWritableFromWritableStream(writableStream, options = kEmptyObject) {
  if (!@inherits(2, writableStream))
    throw @makeErrorWithCode(119, "writableStream", "WritableStream", writableStream);
  validateObject(options, "options");
  let { highWaterMark, decodeStrings = !0, objectMode = !1, signal } = options;
  validateBoolean(objectMode, "options.objectMode"), validateBoolean(decodeStrings, "options.decodeStrings");
  let writer = writableStream.getWriter(), closed = !1, writable = new Writable({
    highWaterMark,
    objectMode,
    decodeStrings,
    signal,
    writev(chunks, callback) {
      function done(error) {
        try {
          callback(error);
        } catch (error2) {
          process.nextTick(() => destroyer(writable, error2));
        }
      }
      PromisePrototypeThen.@call(writer.ready, () => {
        return PromisePrototypeThen.@call(SafePromiseAllReturnVoid(chunks, (data) => writer.write(data.chunk)), done, done);
      }, done);
    },
    write(chunk, encoding, callback) {
      if (typeof chunk === "string" && decodeStrings && !objectMode)
        if (normalizeEncoding(encoding) === "utf8")
          chunk = encoder.encode(chunk);
        else
          chunk = @Buffer.from(chunk, encoding), chunk = new @Uint8Array(TypedArrayPrototypeGetBuffer(chunk), TypedArrayPrototypeGetByteOffset(chunk), TypedArrayPrototypeGetByteLength(chunk));
      function done(error) {
        try {
          callback(error);
        } catch (error2) {
          destroyer(writable, error2);
        }
      }
      PromisePrototypeThen.@call(writer.ready, () => {
        return PromisePrototypeThen.@call(writer.write(chunk), done, done);
      }, done);
    },
    destroy(error, callback) {
      function done() {
        try {
          callback(error);
        } catch (error2) {
          process.nextTick(() => {
            throw error2;
          });
        }
      }
      if (!closed) {
        if (error != null)
          PromisePrototypeThen.@call(writer.abort(error), done, done);
        else
          PromisePrototypeThen.@call(writer.close(), done, done);
        return;
      }
      done();
    },
    final(callback) {
      function done(error) {
        try {
          callback(error);
        } catch (error2) {
          process.nextTick(() => destroyer(writable, error2));
        }
      }
      if (!closed)
        PromisePrototypeThen.@call(writer.close(), done, done);
    }
  });
  return PromisePrototypeThen.@call(writer.closed, () => {
    if (closed = !0, !isWritableEnded(writable))
      destroyer(writable, @makeErrorWithCode(235));
  }, (error) => {
    closed = !0, destroyer(writable, error);
  }), writable;
}
var kErrorSentinelAttached = Symbol("kErrorSentinelAttached");
function newReadableStreamFromStreamReadable(streamReadable, options = kEmptyObject) {
  if (typeof streamReadable?._readableState !== "object")
    throw @makeErrorWithCode(119, "streamReadable", "stream.Readable", streamReadable);
  validateObject(options, "options");
  let optionsType = options.type;
  if (optionsType !== @undefined)
    validateOneOf(optionsType, "options.type", ["bytes", @undefined]);
  let isBYOB = optionsType === "bytes", controller, wasCanceled = !1, strategy, underlyingSource = {
    __proto__: null,
    type: isBYOB ? "bytes" : @undefined,
    start(c) {
      controller = c;
    },
    cancel(reason) {
      wasCanceled = !0, destroyer(streamReadable, reason);
    }
  }, readable = isReadable(streamReadable), objectMode = streamReadable.readableObjectMode;
  if (readable) {
    underlyingSource.pull = function pull() {
      streamReadable.resume();
    };
    let highWaterMark = streamReadable.readableHighWaterMark;
    strategy = isBYOB ? { highWaterMark } : options.strategy ?? new (objectMode ? CountQueuingStrategy : ByteLengthQueuingStrategy)({ highWaterMark });
  }
  let readableStream = new @ReadableStream(underlyingSource, strategy), cleanup = noop;
  if (cleanup = eos(streamReadable, {
    __proto__: null,
    writable: !1,
    [kEosNodeSynchronousCallback]: !0
  }, (error) => {
    if (error = handleKnownInternalErrors(error), cleanup(), !(kErrorSentinelAttached in streamReadable))
      streamReadable.on("error", noop), streamReadable[kErrorSentinelAttached] = !0;
    if (wasCanceled)
      return;
    if (wasCanceled = !0, error)
      return controller.error(error);
    if (controller.close(), isBYOB)
      controller.byobRequest?.respond(0);
  }), wasCanceled)
    cleanup();
  else if (readable)
    streamReadable.pause(), streamReadable.on("data", function onData(chunk) {
      if (@Buffer.isBuffer(chunk) && !objectMode)
        chunk = new @Uint8Array(chunk);
      if (controller.enqueue(chunk), controller.desiredSize <= 0)
        streamReadable.pause();
    });
  return readableStream;
}
function newStreamReadableFromReadableStream(readableStream, options = kEmptyObject) {
  if (!@inherits(1, readableStream))
    throw @makeErrorWithCode(119, "readableStream", "ReadableStream", readableStream);
  validateObject(options, "options");
  let { highWaterMark, encoding, objectMode = !1, signal } = options;
  if (encoding !== @undefined && !@Buffer.isEncoding(encoding))
    throw @makeErrorWithCode(120, "options.encoding", encoding);
  return validateBoolean(objectMode, "options.objectMode"), tryTransferToNativeReadable(readableStream, options) || new ReadableFromWeb({
    highWaterMark,
    encoding,
    objectMode,
    signal
  }, readableStream);
}
var dep0201Warned = !1;
function emitDEP0201() {
  if (dep0201Warned)
    return;
  dep0201Warned = !0, process.emitWarning("Passing 'options.type' to Duplex.toWeb() is deprecated. To specify the ReadableStream type, use 'options.readableType'.", "DeprecationWarning", "DEP0201");
}
function newReadableWritablePairFromDuplex(duplex, options = kEmptyObject) {
  if (typeof duplex?._writableState !== "object" || typeof duplex?._readableState !== "object")
    throw @makeErrorWithCode(119, "duplex", "stream.Duplex", duplex);
  validateObject(options, "options");
  let readableOptions = {
    __proto__: null,
    type: options.readableType
  }, optionsType;
  if (options.readableType == null && (optionsType = options.type) != null)
    emitDEP0201(), readableOptions.type = optionsType;
  if (isDestroyed(duplex)) {
    let writable2 = new @WritableStream, readable2 = new @ReadableStream({ type: readableOptions.type });
    return writable2.close(), readable2.cancel(), { readable: readable2, writable: writable2 };
  }
  let writableOptions = {
    __proto__: null,
    [kValidateChunk]: options[kValidateChunk],
    [kDestroyOnSyncError]: options[kDestroyOnSyncError]
  }, writable = isWritable(duplex) ? newWritableStreamFromStreamWritable(duplex, writableOptions) : new @WritableStream;
  if (!isWritable(duplex))
    writable.close();
  let readable = isReadable(duplex) ? newReadableStreamFromStreamReadable(duplex, readableOptions) : new @ReadableStream({ type: readableOptions.type });
  if (!isReadable(duplex))
    readable.cancel();
  return { writable, readable };
}
function newStreamDuplexFromReadableWritablePair(pair = kEmptyObject, options = kEmptyObject) {
  validateObject(pair, "pair");
  let { readable: readableStream, writable: writableStream } = pair;
  if (!@inherits(1, readableStream))
    throw @makeErrorWithCode(119, "pair.readable", "ReadableStream", readableStream);
  if (!@inherits(2, writableStream))
    throw @makeErrorWithCode(119, "pair.writable", "WritableStream", writableStream);
  validateObject(options, "options");
  let { allowHalfOpen = !1, objectMode = !1, encoding, decodeStrings = !0, highWaterMark, signal } = options;
  if (validateBoolean(objectMode, "options.objectMode"), encoding !== @undefined && !@Buffer.isEncoding(encoding))
    throw @makeErrorWithCode(120, encoding, "options.encoding");
  let writer = writableStream.getWriter(), reader = readableStream.getReader(), writableClosed = !1, readableClosed = !1, duplex = new Duplex({
    allowHalfOpen,
    highWaterMark,
    objectMode,
    encoding,
    decodeStrings,
    signal,
    writev(chunks, callback) {
      function done(error) {
        try {
          callback(error);
        } catch (error2) {
          process.nextTick(() => destroyer(duplex, error2));
        }
      }
      PromisePrototypeThen.@call(writer.ready, () => {
        return PromisePrototypeThen.@call(SafePromiseAllReturnVoid(chunks, (data) => writer.write(data.chunk)), done, done);
      }, done);
    },
    write(chunk, encoding2, callback) {
      if (typeof chunk === "string" && decodeStrings && !objectMode)
        if (normalizeEncoding(encoding2) === "utf8")
          chunk = encoder.encode(chunk);
        else
          chunk = @Buffer.from(chunk, encoding2), chunk = new @Uint8Array(TypedArrayPrototypeGetBuffer(chunk), TypedArrayPrototypeGetByteOffset(chunk), TypedArrayPrototypeGetByteLength(chunk));
      function done(error) {
        try {
          callback(error);
        } catch (error2) {
          destroyer(duplex, error2);
        }
      }
      PromisePrototypeThen.@call(writer.ready, () => {
        return PromisePrototypeThen.@call(writer.write(chunk), done, done);
      }, done);
    },
    final(callback) {
      function done(error) {
        try {
          callback(error);
        } catch (error2) {
          process.nextTick(() => destroyer(duplex, error2));
        }
      }
      if (!writableClosed)
        PromisePrototypeThen.@call(writer.close(), done, done);
    },
    read() {
      PromisePrototypeThen.@call(reader.read(), (chunk) => {
        if (chunk.done)
          duplex.push(null);
        else
          duplex.push(chunk.value);
      }, (error) => destroyer(duplex, error));
    },
    destroy(error, callback) {
      function done() {
        try {
          callback(error);
        } catch (error2) {
          process.nextTick(() => {
            throw error2;
          });
        }
      }
      async function closeWriter() {
        if (!writableClosed)
          await writer.abort(error);
      }
      async function closeReader() {
        if (!readableClosed)
          await reader.cancel(error);
      }
      if (!writableClosed || !readableClosed) {
        PromisePrototypeThen.@call(SafePromiseAllReturnVoid([closeWriter(), closeReader()]), done, done);
        return;
      }
      done();
    }
  });
  return PromisePrototypeThen.@call(writer.closed, () => {
    if (writableClosed = !0, !isWritableEnded(duplex))
      destroyer(duplex, @makeErrorWithCode(235));
  }, (error) => {
    writableClosed = !0, readableClosed = !0, destroyer(duplex, error);
  }), PromisePrototypeThen.@call(reader.closed, () => {
    readableClosed = !0;
  }, (error) => {
    writableClosed = !0, readableClosed = !0, destroyer(duplex, error);
  }), duplex;
}
function newBufferSourceTransformPairFromDuplex(duplex) {
  let { isArrayBufferView, isSharedArrayBuffer } = @getInternalField(@internalModuleRegistry, 164) || @createInternalModuleById(164);
  return newReadableWritablePairFromDuplex(duplex, {
    [kValidateChunk]: function validateBufferSourceChunk(chunk) {
      if (isSharedArrayBuffer(isArrayBufferView(chunk) ? chunk.buffer : chunk))
        throw @makeErrorWithCode(119, "chunk", ["ArrayBuffer", "Buffer", "TypedArray", "DataView"], chunk);
    },
    [kDestroyOnSyncError]: !0
  });
}
$ = {
  newWritableStreamFromStreamWritable,
  newReadableStreamFromStreamReadable,
  newStreamWritableFromWritableStream,
  newStreamReadableFromReadableStream,
  newReadableWritablePairFromDuplex,
  newStreamDuplexFromReadableWritablePair,
  newBufferSourceTransformPairFromDuplex,
  kValidateChunk,
  kDestroyOnSyncError,
  _ReadableFromWeb: ReadableFromWeb
};
return $

})
