(function () {"use strict";
// .zig-cache/o/bb9353210c22a89660eb2e4b9083cc39/native-modules/NodeStreamDuplex.mts
var $;
$ = @getInternalField(@internalModuleRegistry, 50) || @createInternalModuleById(50);
return $

})
