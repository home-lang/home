(function () {"use strict";
// .zig-cache/o/bb9353210c22a89660eb2e4b9083cc39/native-modules/NodeStreamWritable.mts
var $;
$ = @getInternalField(@internalModuleRegistry, 77) || @createInternalModuleById(77);
return $

})
