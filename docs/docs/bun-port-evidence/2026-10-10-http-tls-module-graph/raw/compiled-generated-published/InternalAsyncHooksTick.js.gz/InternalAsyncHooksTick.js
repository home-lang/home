(function () {"use strict";
// .zig-cache/o/bb9353210c22a89660eb2e4b9083cc39/native-modules/InternalAsyncHooksTick.mts
var $, tickInitHooks = [], nextAsyncId = 1;
$ = {
  tickInitHooks,
  newAsyncId() {
    return ++nextAsyncId;
  }
};
return $

})
