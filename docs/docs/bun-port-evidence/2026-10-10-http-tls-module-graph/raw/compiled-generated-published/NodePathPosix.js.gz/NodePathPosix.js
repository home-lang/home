(function () {"use strict";
// .zig-cache/o/bb9353210c22a89660eb2e4b9083cc39/native-modules/NodePathPosix.mts
var $;
$ = (@getInternalField(@internalModuleRegistry, 125) || @createInternalModuleById(125)).posix;
return $

})
