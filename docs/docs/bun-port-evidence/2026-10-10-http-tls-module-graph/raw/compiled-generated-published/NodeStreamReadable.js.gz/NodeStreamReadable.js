(function () {"use strict";
// .zig-cache/o/bb9353210c22a89660eb2e4b9083cc39/native-modules/NodeStreamReadable.mts
var $;
$ = @getInternalField(@internalModuleRegistry, 73) || @createInternalModuleById(73);
return $

})
