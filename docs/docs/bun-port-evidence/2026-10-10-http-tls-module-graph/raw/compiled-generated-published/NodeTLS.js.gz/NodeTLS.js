(function () {"use strict";
// .zig-cache/o/bb9353210c22a89660eb2e4b9083cc39/native-modules/NodeTLS.mts
var $, { isArrayBufferView } = @getInternalField(@internalModuleRegistry, 164) || @createInternalModuleById(164), net = @getInternalField(@internalModuleRegistry, 122) || @createInternalModuleById(122), Duplex = @getInternalField(@internalModuleRegistry, 50) || @createInternalModuleById(50), EventEmitter = @getInternalField(@internalModuleRegistry, 114) || @createInternalModuleById(114), addServerName = @lazy(72), { throwNotImplemented } = @getInternalField(@internalModuleRegistry, 38) || @createInternalModuleById(38), { throwOnInvalidTLSArray } = @getInternalField(@internalModuleRegistry, 79) || @createInternalModuleById(79), {
  validateString,
  validateNumber,
  validateUint32,
  validateBuffer,
  validateFunction
} = @getInternalField(@internalModuleRegistry, 86) || @createInternalModuleById(86), { Server: NetServer, Socket: NetSocket } = net, getBundledRootCertificates = @lazy(78), getExtraCACertificates = @lazy(79), getSystemCACertificates = @lazy(80), canonicalizeIP = @lazy(81), getTLSDefaultCiphers = @lazy(82), setTLSDefaultCiphers = @lazy(83), _VALID_CIPHERS_SET;
function getValidCiphersSet() {
  if (!_VALID_CIPHERS_SET)
    _VALID_CIPHERS_SET = /* @__PURE__ */ new Set([
      "EXP1024-RC4-MD5",
      "EXP1024-RC2-CBC-MD5",
      "EXP1024-DES-CBC-SHA",
      "EXP1024-DHE-DSS-DES-CBC-SHA",
      "EXP1024-RC4-SHA",
      "EXP1024-DHE-DSS-RC4-SHA",
      "DHE-DSS-RC4-SHA",
      "AES128-SHA",
      "DH-DSS-AES128-SHA",
      "DH-RSA-AES128-SHA",
      "DHE-DSS-AES128-SHA",
      "DHE-RSA-AES128-SHA",
      "ADH-AES128-SHA",
      "AES256-SHA",
      "DH-DSS-AES256-SHA",
      "DH-RSA-AES256-SHA",
      "DHE-DSS-AES256-SHA",
      "DHE-RSA-AES256-SHA",
      "ADH-AES256-SHA",
      "ECDH-ECDSA-NULL-SHA",
      "ECDH-ECDSA-RC4-SHA",
      "ECDH-ECDSA-DES-CBC3-SHA",
      "ECDH-ECDSA-AES128-SHA",
      "ECDH-ECDSA-AES256-SHA",
      "ECDHE-ECDSA-NULL-SHA",
      "ECDHE-ECDSA-RC4-SHA",
      "ECDHE-ECDSA-DES-CBC3-SHA",
      "ECDHE-ECDSA-AES128-SHA",
      "ECDHE-ECDSA-AES256-SHA",
      "ECDH-RSA-NULL-SHA",
      "ECDH-RSA-RC4-SHA",
      "ECDH-RSA-DES-CBC3-SHA",
      "ECDH-RSA-AES128-SHA",
      "ECDH-RSA-AES256-SHA",
      "ECDHE-RSA-NULL-SHA",
      "ECDHE-RSA-RC4-SHA",
      "ECDHE-RSA-DES-CBC3-SHA",
      "ECDHE-RSA-AES128-SHA",
      "ECDHE-RSA-AES256-SHA",
      "ECDHE-RSA-AES128-SHA256",
      "AECDH-NULL-SHA",
      "AECDH-RC4-SHA",
      "AECDH-DES-CBC3-SHA",
      "AECDH-AES128-SHA",
      "AECDH-AES256-SHA",
      "PSK-RC4-SHA",
      "PSK-3DES-EDE-CBC-SHA",
      "PSK-AES128-CBC-SHA",
      "PSK-AES256-CBC-SHA",
      "ECDHE-PSK-AES128-CBC-SHA",
      "ECDHE-PSK-AES256-CBC-SHA",
      "SRP-3DES-EDE-CBC-SHA",
      "SRP-RSA-3DES-EDE-CBC-SHA",
      "SRP-DSS-3DES-EDE-CBC-SHA",
      "SRP-AES-128-CBC-SHA",
      "SRP-RSA-AES-128-CBC-SHA",
      "SRP-DSS-AES-128-CBC-SHA",
      "SRP-AES-256-CBC-SHA",
      "SRP-RSA-AES-256-CBC-SHA",
      "SRP-DSS-AES-256-CBC-SHA",
      "CAMELLIA128-SHA",
      "DH-DSS-CAMELLIA128-SHA",
      "DH-RSA-CAMELLIA128-SHA",
      "DHE-DSS-CAMELLIA128-SHA",
      "DHE-RSA-CAMELLIA128-SHA",
      "ADH-CAMELLIA128-SHA",
      "CAMELLIA256-SHA",
      "DH-DSS-CAMELLIA256-SHA",
      "DH-RSA-CAMELLIA256-SHA",
      "DHE-DSS-CAMELLIA256-SHA",
      "DHE-RSA-CAMELLIA256-SHA",
      "ADH-CAMELLIA256-SHA",
      "SEED-SHA",
      "DH-DSS-SEED-SHA",
      "DH-RSA-SEED-SHA",
      "DHE-DSS-SEED-SHA",
      "DHE-RSA-SEED-SHA",
      "ADH-SEED-SHA",
      "NULL-SHA256",
      "AES128-SHA256",
      "AES256-SHA256",
      "DH-DSS-AES128-SHA256",
      "DH-RSA-AES128-SHA256",
      "DHE-DSS-AES128-SHA256",
      "DHE-RSA-AES128-SHA256",
      "DH-DSS-AES256-SHA256",
      "DH-RSA-AES256-SHA256",
      "DHE-DSS-AES256-SHA256",
      "DHE-RSA-AES256-SHA256",
      "ADH-AES128-SHA256",
      "ADH-AES256-SHA256",
      "AES128-GCM-SHA256",
      "AES256-GCM-SHA384",
      "DHE-RSA-AES128-GCM-SHA256",
      "DHE-RSA-AES256-GCM-SHA384",
      "DH-RSA-AES128-GCM-SHA256",
      "DH-RSA-AES256-GCM-SHA384",
      "DHE-DSS-AES128-GCM-SHA256",
      "DHE-DSS-AES256-GCM-SHA384",
      "DH-DSS-AES128-GCM-SHA256",
      "DH-DSS-AES256-GCM-SHA384",
      "ADH-AES128-GCM-SHA256",
      "ADH-AES256-GCM-SHA384",
      "ECDHE-ECDSA-AES128-SHA256",
      "ECDHE-ECDSA-AES256-SHA384",
      "ECDH-ECDSA-AES128-SHA256",
      "ECDH-ECDSA-AES256-SHA384",
      "ECDHE-RSA-AES128-SHA256",
      "ECDHE-RSA-AES256-SHA384",
      "ECDH-RSA-AES128-SHA256",
      "ECDH-RSA-AES256-SHA384",
      "ECDHE-ECDSA-AES128-GCM-SHA256",
      "ECDHE-ECDSA-AES256-GCM-SHA384",
      "ECDH-ECDSA-AES128-GCM-SHA256",
      "ECDH-ECDSA-AES256-GCM-SHA384",
      "ECDHE-RSA-AES128-GCM-SHA256",
      "ECDHE-RSA-AES256-GCM-SHA384",
      "ECDH-RSA-AES128-GCM-SHA256",
      "ECDH-RSA-AES256-GCM-SHA384",
      "ECDHE-RSA-CHACHA20-POLY1305",
      "ECDHE-ECDSA-CHACHA20-POLY1305",
      "ECDHE-PSK-CHACHA20-POLY1305",
      "TLS_AES_128_GCM_SHA256",
      "TLS_AES_256_GCM_SHA384",
      "TLS_CHACHA20_POLY1305_SHA256",
      "HIGH",
      "!aNULL",
      "!eNULL",
      "!EXPORT",
      "!DES",
      "!RC4",
      "!MD5",
      "!PSK",
      "!SRP",
      "!CAMELLIA"
    ]);
  return _VALID_CIPHERS_SET;
}
var CIPHER_LIST_SELECTORS = /* @__PURE__ */ new Set([
  "DEFAULT",
  "ALL",
  "COMPLEMENTOFDEFAULT",
  "COMPLEMENTOFALL",
  "HIGH",
  "MEDIUM",
  "LOW",
  "PSK",
  "aNULL",
  "eNULL",
  "NULL",
  "EXPORT",
  "EXP",
  "kRSA",
  "aRSA",
  "RSA",
  "kDHE",
  "kEDH",
  "DH",
  "DHE",
  "EDH",
  "kECDHE",
  "kEECDH",
  "ECDHE",
  "EECDH",
  "ECDH",
  "aECDSA",
  "ECDSA",
  "aDSS",
  "DSS",
  "AES",
  "AESGCM",
  "AESCCM",
  "CHACHA20",
  "3DES",
  "DES",
  "RC4",
  "RC2",
  "MD5",
  "SHA",
  "SHA1",
  "SHA256",
  "SHA384",
  "CAMELLIA",
  "ARIA",
  "SRP",
  "TLSv1",
  "TLSv1.0",
  "TLSv1.2",
  "TLSv1.3",
  "SSLv3"
]);
function validateCiphers(ciphers, name = "options") {
  if (ciphers !== @undefined && ciphers !== null) {
    validateString(ciphers, `${name}.ciphers`);
    let ciphersSet = getValidCiphersSet(), requested = ciphers.split(":");
    for (let r of requested)
      if (r && !ciphersSet.has(r)) {
        if (r.includes("@SECLEVEL")) {
          let err = Error("error:0f000076:SSL routines:OPENSSL_internal:INVALID_COMMAND");
          throw err.code = "ERR_SSL_INVALID_COMMAND", err.library = "SSL routines", err.function = "OPENSSL_internal", err.reason = "INVALID_COMMAND", err;
        }
        let first = r.charCodeAt(0);
        if (first === 33 || first === 45 || first === 43 || first === 64 || r.includes("+") || CIPHER_LIST_SELECTORS.has(r))
          continue;
        throw @makeErrorWithCode(255);
      }
  }
}
var VALID_TLS_VERSIONS = /* @__PURE__ */ new Set(["TLSv1", "TLSv1.1", "TLSv1.2", "TLSv1.3"]), _SECURE_PROTOCOL_METHODS;
function getSecureProtocolMethods() {
  if (!_SECURE_PROTOCOL_METHODS)
    _SECURE_PROTOCOL_METHODS = /* @__PURE__ */ new Set([
      "TLS_method",
      "TLS_client_method",
      "TLS_server_method",
      "SSLv23_method",
      "SSLv23_client_method",
      "SSLv23_server_method",
      "TLSv1_method",
      "TLSv1_client_method",
      "TLSv1_server_method",
      "TLSv1_1_method",
      "TLSv1_1_client_method",
      "TLSv1_1_server_method",
      "TLSv1_2_method",
      "TLSv1_2_client_method",
      "TLSv1_2_server_method"
    ]);
  return _SECURE_PROTOCOL_METHODS;
}
function invalidProtocolMethod(message) {
  let error = @makeTypeError(message);
  return error.code = "ERR_TLS_INVALID_PROTOCOL_METHOD", error;
}
function validateSecureProtocol(secureProtocol) {
  if (secureProtocol === @undefined || secureProtocol === null)
    return;
  if (validateString(secureProtocol, "options.secureProtocol"), secureProtocol.startsWith("SSLv2_"))
    throw invalidProtocolMethod("SSLv2 methods disabled");
  if (secureProtocol.startsWith("SSLv3_"))
    throw invalidProtocolMethod("SSLv3 methods disabled");
  if (!getSecureProtocolMethods().has(secureProtocol))
    throw invalidProtocolMethod(`Unknown method: ${secureProtocol}`);
}
function validateSecureContextOptions(options) {
  let {
    ciphers,
    passphrase,
    ecdhCurve,
    minVersion,
    maxVersion,
    sessionTimeout,
    ticketKeys,
    clientCertEngine,
    dhparam,
    secureProtocol
  } = options;
  if (validateSecureProtocol(secureProtocol), ciphers !== @undefined && ciphers !== null)
    validateString(ciphers, "options.ciphers");
  if (passphrase !== @undefined && passphrase !== null)
    validateString(passphrase, "options.passphrase");
  if (ecdhCurve !== @undefined && ecdhCurve !== null)
    validateString(ecdhCurve, "options.ecdhCurve");
  if (clientCertEngine !== @undefined && clientCertEngine !== null) {
    if (typeof clientCertEngine !== "string")
      throw @makeErrorWithCode(119, "options.clientCertEngine", ["string", "null", "undefined"], clientCertEngine);
    throw @makeErrorWithCode(20, "Custom engines not supported by this OpenSSL");
  }
  if (dhparam === "auto")
    throw @makeErrorWithCode(51, "Automatic DH parameter selection is not supported");
  if (minVersion != null && !VALID_TLS_VERSIONS.has(minVersion))
    throw @makeErrorWithCode(247, @String(minVersion), "minimum");
  if (maxVersion != null && !VALID_TLS_VERSIONS.has(maxVersion))
    throw @makeErrorWithCode(247, @String(maxVersion), "maximum");
  if (ticketKeys !== @undefined && ticketKeys !== null) {
    validateBuffer(ticketKeys, "options.ticketKeys");
    let ticketKeysByteLength = ticketKeys.byteLength;
    if (ticketKeysByteLength !== 48)
      throw @makeErrorWithCode(120, "options.ticketKeys", ticketKeysByteLength, "must be exactly 48 bytes");
  }
  if (sessionTimeout !== @undefined && sessionTimeout !== null) {
    if (typeof sessionTimeout !== "number")
      throw @makeErrorWithCode(119, "options.sessionTimeout", "number", sessionTimeout);
    if (!Number.isInteger(sessionTimeout))
      throw @makeErrorWithCode(160, "options.sessionTimeout", "an integer", sessionTimeout);
    if (sessionTimeout < 0 || sessionTimeout > 2147483647)
      throw @makeErrorWithCode(160, "options.sessionTimeout", ">= 0 && <= 2147483647", sessionTimeout);
  }
}
var SymbolReplace = Symbol.replace, RegExpPrototypeSymbolReplace = @RegExp.prototype[SymbolReplace], RegExpPrototypeExec = @RegExp.prototype.exec, ObjectAssign = Object.assign, StringPrototypeStartsWith = @String.prototype.startsWith, StringPrototypeSlice = @String.prototype.slice, StringPrototypeIncludes = @String.prototype.includes, StringPrototypeSplit = @String.prototype.split, StringPrototypeIndexOf = @String.prototype.indexOf, StringPrototypeSubstring = @String.prototype.substring, StringPrototypeEndsWith = @String.prototype.endsWith, StringFromCharCode = @String.fromCharCode, StringPrototypeCharCodeAt = @String.prototype.charCodeAt, ArrayPrototypeIncludes = @Array.prototype.includes, ArrayPrototypeJoin = @Array.prototype.join, ArrayPrototypeForEach = @Array.prototype.forEach, ArrayPrototypePush = @Array.prototype.push, ArrayPrototypeSome = @Array.prototype.some, ArrayPrototypeReduce = @Array.prototype.reduce, ObjectFreeze = Object.freeze;
function parseCertString() {
  throwNotImplemented("Not implemented");
}
function rejectUnauthorizedDefault() {
  let value = process.env.NODE_TLS_REJECT_UNAUTHORIZED;
  return value !== "0" && value !== "false";
}
function unfqdn(host) {
  return RegExpPrototypeSymbolReplace.@call(/[.]$/, host, "");
}
function toLowerCase(c) {
  return StringFromCharCode(32 + StringPrototypeCharCodeAt.@call(c, 0));
}
function splitHost(host) {
  return StringPrototypeSplit.@call(RegExpPrototypeSymbolReplace.@call(/[A-Z]/g, unfqdn(host), toLowerCase), ".");
}
function check(hostParts, pattern, wildcards) {
  if (!pattern)
    return !1;
  let patternParts = splitHost(pattern);
  if (hostParts.length !== patternParts.length)
    return !1;
  if (ArrayPrototypeIncludes.@call(patternParts, ""))
    return !1;
  let isBad = (s) => RegExpPrototypeExec.@call(/[^\u0021-\u007F]/u, s) !== null;
  if (ArrayPrototypeSome.@call(patternParts, isBad))
    return !1;
  for (let i = hostParts.length - 1;i > 0; i -= 1)
    if (hostParts[i] !== patternParts[i])
      return !1;
  let hostSubdomain = hostParts[0], patternSubdomain = patternParts[0], patternSubdomainParts = StringPrototypeSplit.@call(patternSubdomain, "*");
  if (patternSubdomainParts.length === 1 || StringPrototypeIncludes.@call(patternSubdomain, "xn--"))
    return hostSubdomain === patternSubdomain;
  if (!wildcards)
    return !1;
  if (patternSubdomainParts.length > 2)
    return !1;
  if (patternParts.length <= 2)
    return !1;
  let { 0: prefix, 1: suffix } = patternSubdomainParts;
  if (prefix.length + suffix.length > hostSubdomain.length)
    return !1;
  if (!StringPrototypeStartsWith.@call(hostSubdomain, prefix))
    return !1;
  if (!StringPrototypeEndsWith.@call(hostSubdomain, suffix))
    return !1;
  return !0;
}
var jsonStringPattern = /^"(?:[^"\\\u0000-\u001f]|\\(?:["\\/bfnrt]|u[0-9a-fA-F]{4}))*"/;
function splitEscapedAltNames(altNames) {
  let result = [], currentToken = "", offset = 0;
  while (offset !== altNames.length) {
    let nextSep = StringPrototypeIndexOf.@call(altNames, ", ", offset), nextQuote = StringPrototypeIndexOf.@call(altNames, '"', offset);
    if (nextQuote !== -1 && (nextSep === -1 || nextQuote < nextSep)) {
      currentToken += StringPrototypeSubstring.@call(altNames, offset, nextQuote);
      let match = RegExpPrototypeExec.@call(jsonStringPattern, StringPrototypeSubstring.@call(altNames, nextQuote));
      if (!match)
        throw @makeErrorWithCode(243);
      currentToken += JSON.parse(match[0]), offset = nextQuote + match[0].length;
    } else if (nextSep !== -1)
      currentToken += StringPrototypeSubstring.@call(altNames, offset, nextSep), ArrayPrototypePush.@call(result, currentToken), currentToken = "", offset = nextSep + 2;
    else
      currentToken += StringPrototypeSubstring.@call(altNames, offset), offset = altNames.length;
  }
  return ArrayPrototypePush.@call(result, currentToken), result;
}
function checkServerIdentity(hostname, cert) {
  let { subject, subjectaltname: altNames } = cert, dnsNames = [], ips = [];
  if (hostname = "" + hostname, altNames) {
    let splitAltNames = StringPrototypeIncludes.@call(altNames, '"') ? splitEscapedAltNames(altNames) : StringPrototypeSplit.@call(altNames, ", ");
    ArrayPrototypeForEach.@call(splitAltNames, (name) => {
      if (StringPrototypeStartsWith.@call(name, "DNS:"))
        ArrayPrototypePush.@call(dnsNames, StringPrototypeSlice.@call(name, 4));
      else if (StringPrototypeStartsWith.@call(name, "IP Address:"))
        ArrayPrototypePush.@call(ips, canonicalizeIP(StringPrototypeSlice.@call(name, 11)));
    });
  }
  let valid = !1, reason = "Unknown reason";
  if (hostname = unfqdn(hostname), net.isIP(hostname)) {
    if (valid = ArrayPrototypeIncludes.@call(ips, canonicalizeIP(hostname)), !valid)
      reason = `IP: ${hostname} is not in the cert's list: ` + ArrayPrototypeJoin.@call(ips, ", ");
  } else {
    let hasDnsNames = dnsNames.length > 0;
    if (hasDnsNames || subject?.CN) {
      let hostParts = splitHost(hostname), wildcard = (pattern) => check(hostParts, pattern, !0);
      if (hasDnsNames) {
        if (valid = ArrayPrototypeSome.@call(dnsNames, wildcard), !valid)
          reason = `Host: ${hostname}. is not in the cert's altnames: ${altNames}`;
      } else {
        let cn = subject.CN;
        if (@Array.isArray(cn))
          valid = ArrayPrototypeSome.@call(cn, wildcard);
        else if (cn)
          valid = wildcard(cn);
        if (!valid)
          reason = `Host: ${hostname}. is not cert's CN: ${cn}`;
      }
    } else
      reason = "Cert does not contain a DNS name";
  }
  if (!valid)
    return @makeErrorWithCode(244, reason, hostname, cert);
}
var NativeSecureContext = @lazy(84), TLS1_VERSION = 769, TLS1_1_VERSION = 770, TLS1_2_VERSION = 771, TLS1_3_VERSION = 772;
function tlsStringToProtocolVersion(v) {
  switch (v) {
    case "TLSv1":
      return TLS1_VERSION;
    case "TLSv1.1":
      return TLS1_1_VERSION;
    case "TLSv1.2":
      return TLS1_2_VERSION;
    case "TLSv1.3":
      return TLS1_3_VERSION;
    default:
      return 0;
  }
}
function secureProtocolToVersionRange(secureProtocol) {
  if (typeof secureProtocol !== "string")
    return null;
  if (secureProtocol === "TLSv1_method" || secureProtocol === "TLSv1_client_method" || secureProtocol === "TLSv1_server_method")
    return [TLS1_VERSION, TLS1_VERSION];
  if (secureProtocol === "TLSv1_1_method" || secureProtocol === "TLSv1_1_client_method" || secureProtocol === "TLSv1_1_server_method")
    return [TLS1_1_VERSION, TLS1_1_VERSION];
  if (secureProtocol === "TLSv1_2_method" || secureProtocol === "TLSv1_2_client_method" || secureProtocol === "TLSv1_2_server_method")
    return [TLS1_2_VERSION, TLS1_2_VERSION];
  return null;
}
function processPfxOptions(options) {
  if (options == null || options.pfx == null)
    return options;
  let out = { ...options }, keys = out.key == null ? [] : @Array.isArray(out.key) ? [...out.key] : [out.key], certs = out.cert == null ? [] : @Array.isArray(out.cert) ? [...out.cert] : [out.cert], pfxCAs = [], entries = @Array.isArray(out.pfx) ? out.pfx : [out.pfx];
  for (let entry of entries) {
    let buf = entry, passphrase = out.passphrase;
    if (entry != null && typeof entry === "object" && !@Buffer.isBuffer(entry) && !@isTypedArrayView(entry)) {
      let entryBuf = entry.buf;
      if (entryBuf !== @undefined) {
        buf = entryBuf;
        let entryPassphrase = entry.passphrase;
        if (entryPassphrase !== @undefined)
          passphrase = entryPassphrase;
      }
    }
    let parsed = NativeSecureContext.parsePkcs12(buf, passphrase);
    keys.push(parsed.key), certs.push(parsed.cert);
    let parsedCA = parsed.ca;
    if (parsedCA)
      pfxCAs.push(parsedCA);
  }
  if (out.key = keys.length === 1 ? keys[0] : keys, out.cert = certs.length === 1 ? certs[0] : certs, pfxCAs.length)
    out._pfxExtraCACerts = pfxCAs;
  return out.pfx = @undefined, out;
}
function newNativeSecureContext(options, cached = !0) {
  maybeWarnAboutExtraCACerts(), options = options == null ? {} : processPfxOptions(options);
  let pfxExtraCAs = options._pfxExtraCACerts;
  if (pfxExtraCAs)
    cached = !1;
  let ALPNProtocols = options.ALPNProtocols;
  if (@Array.isArray(ALPNProtocols)) {
    let normalized = {};
    convertALPNProtocols(ALPNProtocols, normalized), options = { ...options, ALPNProtocols: normalized.ALPNProtocols };
  }
  if (options) {
    let { key, cert, ca } = options;
    if (!key || !cert || !ca)
      options = {
        ...options,
        key: key || null,
        cert: cert || null,
        ca: ca || null
      };
  }
  if (options) {
    let { minVersion: optMinVersion, maxVersion: optMaxVersion, secureProtocol: optSecureProtocol } = options;
    {
      let minVersion, maxVersion, range = secureProtocolToVersionRange(optSecureProtocol);
      if (range)
        minVersion = range[0], maxVersion = range[1];
      else
        minVersion = tlsStringToProtocolVersion(optMinVersion ?? DEFAULT_MIN_VERSION), maxVersion = tlsStringToProtocolVersion(optMaxVersion ?? DEFAULT_MAX_VERSION);
      options = { ...options, minVersion, maxVersion };
    }
  }
  let ctx = (cached ? NativeSecureContext.intern : NativeSecureContext.createPrivate)(options);
  if (pfxExtraCAs)
    for (let pem of pfxExtraCAs)
      ctx.addCACert(pem);
  return ctx;
}
var InternalSecureContext = class SecureContext {
  context;
  servername;
  constructor(options, cached = !0) {
    if (_defaultCACertificatesOverride !== @undefined && (options == null || options.ca == null))
      options = { ...options, ca: _defaultCACertificatesOverride };
    if (options) {
      validateSecureContextOptions(options);
      let cert = options.cert;
      if (cert)
        throwOnInvalidTLSArray("options.cert", cert);
      let key = options.key;
      if (key)
        throwOnInvalidTLSArray("options.key", key);
      let ca = options.ca;
      if (ca)
        throwOnInvalidTLSArray("options.ca", ca);
      if (options.servername != null && typeof options.servername !== "string")
        @throwTypeError("servername argument must be an string");
      if (options.secureOptions != null && typeof options.secureOptions !== "number")
        @throwTypeError("secureOptions argument must be an number");
      let privateKeyIdentifier = options.privateKeyIdentifier;
      if (!@isUndefinedOrNull(privateKeyIdentifier)) {
        let privateKeyEngine = options.privateKeyEngine;
        if (@isUndefinedOrNull(privateKeyEngine))
          throw @makeErrorWithCode(120, "options.privateKeyEngine", privateKeyEngine);
        if (typeof privateKeyEngine !== "string")
          throw @makeErrorWithCode(119, "options.privateKeyEngine", ["string", "null", "undefined"], privateKeyEngine);
        if (typeof privateKeyIdentifier !== "string")
          throw @makeErrorWithCode(119, "options.privateKeyIdentifier", ["string", "null", "undefined"], privateKeyIdentifier);
      }
    }
    this.context = newNativeSecureContext(options, cached), this.servername = options?.servername;
  }
};
function SecureContext2(options) {
  return new InternalSecureContext(options);
}
function createSecureContext(options) {
  if (options instanceof InternalSecureContext)
    return options;
  return new InternalSecureContext(options, !1);
}
function translatePeerCertificate(c) {
  return c;
}
var ksecureContext = Symbol("ksecureContext"), kcheckServerIdentity = Symbol("kcheckServerIdentity"), ksession = Symbol("ksession"), krenegotiationDisabled = Symbol("renegotiationDisabled"), buntls = Symbol.for("::buntls::"), kNativeSecureContextCtor = Symbol.for("::buntlsnativesecurecontextctor::");
function TLSSocket(socket, options) {
  this[ksecureContext] = @undefined, this.ALPNProtocols = @undefined, this[kcheckServerIdentity] = @undefined, this[ksession] = @undefined, this.alpnProtocol = null, this._secureEstablished = !1, this._rejectUnauthorized = rejectUnauthorizedDefault(), this._securePending = !0, this._newSessionPending = @undefined, this._controlReleased = @undefined, this.secureConnecting = !1, this._SNICallback = @undefined, this.servername = @undefined, this.authorized = !1, this.authorizationError, this[krenegotiationDisabled] = @undefined, this.encrypted = !0;
  let isNetSocketOrDuplex = socket instanceof Duplex;
  if (socket != null && !isNetSocketOrDuplex && socket instanceof EventEmitter)
    throw @makeErrorWithCode(119, "socket", "Duplex", socket);
  options = isNetSocketOrDuplex ? { ...options, allowHalfOpen: !1 } : options || socket || {}, NetSocket.@call(this, options);
  let isServer = !!options.isServer;
  if (this.isServer = isServer, isServer) {
    let sniCallback = options.SNICallback;
    if (sniCallback != null)
      validateFunction(sniCallback, "options.SNICallback"), this._SNICallback = sniCallback;
    let alpnCallback = options.ALPNCallback;
    if (alpnCallback != null) {
      if (validateFunction(alpnCallback, "options.ALPNCallback"), options.ALPNProtocols)
        throw @makeErrorWithCode(254);
      this._ALPNCallback = alpnCallback;
    }
  }
  if (this.ciphers = options.ciphers, this.ciphers)
    validateCiphers(options.ciphers);
  if (typeof options === "object") {
    let { ALPNProtocols } = options;
    if (ALPNProtocols)
      convertALPNProtocols(ALPNProtocols, this);
    if (isNetSocketOrDuplex && !this.isServer)
      this._handle = socket, this._handle._parentWrap = this;
  }
  this[ksecureContext] = options.secureContext || new InternalSecureContext(options), this.authorized = !1, this.secureConnecting = !0, this._secureEstablished = !1, this._securePending = !0;
  let checkServerIdentityOption = options.checkServerIdentity;
  if (checkServerIdentityOption !== @undefined)
    validateFunction(checkServerIdentityOption, "options.checkServerIdentity");
  if (this[kcheckServerIdentity] = checkServerIdentityOption || checkServerIdentity, this[ksession] = options.session || null, isNetSocketOrDuplex && this.isServer)
    this[Symbol.for("::bunUpgradeServerTLS::")](socket, this[buntls](null, null));
}
@toClass(TLSSocket, "TLSSocket", NetSocket);
TLSSocket.prototype._destroySSL = function _destroySSL() {
  this.secureConnecting = !1, this._secureEstablished = !1;
};
TLSSocket.prototype._start = function _start() {
  this.connect();
};
TLSSocket.prototype._final = function _final(callback) {
  if (!this._handle)
    return callback();
  if (this.secureConnecting)
    return this.once("secureConnect", NetSocket.prototype._final.bind(this, callback));
  return NetSocket.prototype._final.@call(this, callback);
};
TLSSocket.prototype.getSession = function getSession() {
  return this._handle?.getSession?.();
};
TLSSocket.prototype.getEphemeralKeyInfo = function getEphemeralKeyInfo() {
  let info = this._handle?.getEphemeralKeyInfo?.();
  if (info == null)
    return info;
  return { type: info.type, name: info.name, size: info.size };
};
TLSSocket.prototype.getCipher = function getCipher() {
  return this._handle?.getCipher?.();
};
TLSSocket.prototype.getSharedSigalgs = function getSharedSigalgs() {
  return this._handle?.getSharedSigalgs?.();
};
TLSSocket.prototype.getProtocol = function getProtocol() {
  return this._handle?.getTLSVersion?.() ?? null;
};
TLSSocket.prototype.getFinished = function getFinished() {
  return this._handle?.getTLSFinishedMessage?.() || @undefined;
};
TLSSocket.prototype.getPeerFinished = function getPeerFinished() {
  return this._handle?.getTLSPeerFinishedMessage?.() || @undefined;
};
TLSSocket.prototype.isSessionReused = function isSessionReused() {
  return this._handle?.isSessionReused?.() ?? !1;
};
TLSSocket.prototype.renegotiate = function renegotiate(options, callback) {
  if (options === null || typeof options !== "object")
    throw @makeErrorWithCode(119, "options", "object", options);
  if (callback !== @undefined)
    validateFunction(callback, "callback");
  if (this.destroyed)
    return;
  if (this[krenegotiationDisabled]) {
    let error2 = @makeErrorWithCode(250);
    if (typeof callback === "function")
      process.nextTick(callback, error2);
    return !1;
  }
  let socket = this._handle;
  if (!socket)
    return;
  let requestCert = !!this._requestCert, rejectUnauthorized = !!this._rejectUnauthorized, { requestCert: requestCertOption, rejectUnauthorized: rejectUnauthorizedOption } = options;
  if (requestCertOption !== @undefined)
    requestCert = !!requestCertOption;
  if (rejectUnauthorizedOption !== @undefined)
    rejectUnauthorized = !!rejectUnauthorizedOption;
  if (requestCert !== this._requestCert || rejectUnauthorized !== this._rejectUnauthorized)
    socket.setVerifyMode?.(requestCert, rejectUnauthorized), this._requestCert = requestCert, this._rejectUnauthorized = rejectUnauthorized;
  let error = @makeErrorWithCode(251);
  if (typeof callback === "function")
    process.nextTick(callback, error);
  return !1;
};
TLSSocket.prototype.disableRenegotiation = function disableRenegotiation() {
  return this[krenegotiationDisabled] = !0, this._handle?.disableRenegotiation?.();
};
TLSSocket.prototype.getTLSTicket = function getTLSTicket() {
  return this._handle?.getTLSTicket?.();
};
TLSSocket.prototype.setKeyCert = function setKeyCert(context) {
  let ctx = context?.context ? context : new InternalSecureContext(context);
  this._handle?.setKeyCert?.(ctx.context);
};
TLSSocket.prototype.exportKeyingMaterial = function exportKeyingMaterial(length, label, context) {
  if (validateUint32(length, "length", !0), validateString(label, "label"), context !== @undefined)
    validateBuffer(context, "context");
  if (!this._secureEstablished)
    throw @makeErrorWithCode(253);
  if (context)
    return this._handle?.exportKeyingMaterial?.(length, label, context);
  return this._handle?.exportKeyingMaterial?.(length, label);
};
TLSSocket.prototype.setMaxSendFragment = function setMaxSendFragment(size) {
  return this._handle?.setMaxSendFragment?.(size) || !1;
};
TLSSocket.prototype.enableTrace = function enableTrace() {};
TLSSocket.prototype.setServername = function setServername(name) {
  if (validateString(name, "name"), this.isServer)
    throw @makeErrorWithCode(252);
  this.servername = name, this._handle?.setServername?.(name);
};
TLSSocket.prototype.setSession = function setSession(session) {
  if (this[ksession] = session, typeof session === "string")
    session = @Buffer.from(session, "latin1");
  return this._handle?.setSession?.(session);
};
TLSSocket.prototype.getPeerCertificate = function getPeerCertificate(detailed) {
  let handle = this._handle;
  if (handle) {
    let cert = arguments.length < 1 ? handle.getPeerCertificate?.() : handle.getPeerCertificate?.(!detailed);
    if (cert)
      return translatePeerCertificate(cert);
    return {};
  }
  return null;
};
TLSSocket.prototype.getCertificate = function getCertificate() {
  let cert = this._handle?.getCertificate?.();
  if (cert)
    return translatePeerCertificate(cert);
};
TLSSocket.prototype.getPeerX509Certificate = function getPeerX509Certificate() {
  let cert = this.getPeerCertificate(!0);
  if (!cert || !cert.raw)
    return this._handle?.getPeerX509Certificate?.();
  let { X509Certificate } = @getInternalField(@internalModuleRegistry, 108) || @createInternalModuleById(108), seen = /* @__PURE__ */ new Map, toX509 = (chainCert) => {
    if (!chainCert || !chainCert.raw)
      return @undefined;
    let cached = seen.get(chainCert);
    if (cached)
      return cached;
    let x509 = new X509Certificate(chainCert.raw);
    seen.set(chainCert, x509);
    let issuerCertificate = chainCert.issuerCertificate;
    if (issuerCertificate && issuerCertificate !== chainCert) {
      let issuer = toX509(issuerCertificate);
      if (issuer)
        Object.defineProperty(x509, "issuerCertificate", {
          __proto__: null,
          value: issuer,
          configurable: !0,
          enumerable: !1
        });
    }
    return x509;
  };
  return toX509(cert);
};
TLSSocket.prototype.getX509Certificate = function getX509Certificate() {
  return this._handle?.getX509Certificate?.();
};
TLSSocket.prototype[buntls] = function(port, host) {
  let ctx = this[ksecureContext], servername = this.servername || ctx?.servername;
  if (servername === @undefined)
    servername = host && !net.isIP(host) ? host : "";
  return {
    socket: this._handle,
    ALPNProtocols: this.ALPNProtocols,
    checkServerIdentity: this[kcheckServerIdentity],
    session: this[ksession],
    rejectUnauthorized: this._rejectUnauthorized,
    requestCert: this._requestCert,
    ciphers: this.ciphers,
    secureContext: ctx?.context,
    servername
  };
};
var CLIENT_RENEG_LIMIT = 3, CLIENT_RENEG_WINDOW = 600;
function Server(options, secureConnectionListener) {
  if (!(this instanceof Server))
    return new Server(options, secureConnectionListener);
  if (options != null && typeof options !== "object" && typeof options !== "function")
    throw @makeErrorWithCode(119, "options", "object", options);
  if (options != null && typeof options === "object") {
    let sniCallback = options.SNICallback;
    if (sniCallback != null)
      validateFunction(sniCallback, "options.SNICallback"), this._SNICallback = sniCallback;
    let alpnCallback = options.ALPNCallback;
    if (alpnCallback != null) {
      if (validateFunction(alpnCallback, "options.ALPNCallback"), options.ALPNProtocols)
        throw @makeErrorWithCode(254);
      this._ALPNCallback = alpnCallback;
    }
  }
  NetServer.@apply(this, [options, secureConnectionListener]), this.key = @undefined, this.cert = @undefined, this.ca = @undefined, this.passphrase = @undefined, this.secureOptions = @undefined, this._rejectUnauthorized = rejectUnauthorizedDefault(), this._requestCert = @undefined, this.servername = @undefined, this.ALPNProtocols = @undefined;
  let contexts = null;
  this.addContext = function(hostname, context) {
    if (typeof hostname !== "string")
      @throwTypeError("hostname must be a string");
    if (!(context instanceof InternalSecureContext))
      context = new InternalSecureContext(context);
    let handle = this._handle;
    if (handle)
      addServerName(handle, hostname, context.context);
    else {
      if (!contexts)
        contexts = /* @__PURE__ */ new Map;
      contexts.set(hostname, context);
    }
  }, this.setSecureContext = function(options2) {
    if (options2 instanceof InternalSecureContext)
      options2 = options2.context;
    if (options2) {
      validateSecureContextOptions(options2), options2 = processPfxOptions(options2);
      let { ALPNProtocols } = options2;
      if (ALPNProtocols)
        convertALPNProtocols(ALPNProtocols, this);
      else
        this.ALPNProtocols = @undefined;
      let cert = options2.cert;
      if (cert)
        throwOnInvalidTLSArray("options.cert", cert);
      this.cert = cert;
      let key = options2.key;
      if (key)
        throwOnInvalidTLSArray("options.key", key);
      this.key = key;
      let keyLength = @Array.isArray(key) ? key.length : 0;
      if (keyLength > 1 && cert) {
        let certs = @Array.isArray(cert) ? cert : [cert];
        try {
          let { createPrivateKey, X509Certificate } = @getInternalField(@internalModuleRegistry, 108) || @createInternalModuleById(108);
          for (let i = 0;i < keyLength; i++) {
            let k = key[i];
            if (typeof k !== "string" && !@isTypedArrayView(k))
              continue;
            let pairedCert = certs[i < certs.length ? i : certs.length - 1], certType = new X509Certificate(pairedCert).publicKey.asymmetricKeyType;
            if (createPrivateKey(k).asymmetricKeyType !== certType) {
              let err = Error("error:0b000074:X.509 certificate routines:OPENSSL_internal:KEY_TYPE_MISMATCH");
              throw err.code = "ERR_OSSL_X509_KEY_TYPE_MISMATCH", err.library = "X.509 certificate routines", err.function = "OPENSSL_internal", err.reason = "KEY_TYPE_MISMATCH", err;
            }
          }
        } catch (e) {
          if (e?.code === "ERR_OSSL_X509_KEY_TYPE_MISMATCH")
            throw e;
        }
      }
      let ca = options2.ca;
      if (_defaultCACertificatesOverride !== @undefined && ca == null)
        ca = _defaultCACertificatesOverride;
      let pfxExtraCAs = options2._pfxExtraCACerts;
      if (pfxExtraCAs?.length)
        ca = ca == null ? pfxExtraCAs : @Array.isArray(ca) ? [...ca, ...pfxExtraCAs] : [ca, ...pfxExtraCAs];
      if (ca)
        throwOnInvalidTLSArray("options.ca", ca);
      this.ca = ca;
      let passphrase = options2.passphrase;
      if (passphrase && typeof passphrase !== "string")
        throw @makeErrorWithCode(119, "options.passphrase", "string", passphrase);
      this.passphrase = passphrase;
      let servername = options2.servername;
      if (servername && typeof servername !== "string")
        throw @makeErrorWithCode(119, "options.servername", "string", servername);
      this.servername = servername;
      let secureOptions = options2.secureOptions || 0;
      if (secureOptions && typeof secureOptions !== "number")
        throw @makeErrorWithCode(119, "options.secureOptions", "number", secureOptions);
      this.secureOptions = secureOptions;
      let requestCert = options2.requestCert || !1;
      if (requestCert)
        this._requestCert = requestCert;
      else
        this._requestCert = @undefined;
      let rejectUnauthorized = options2.rejectUnauthorized;
      if (typeof rejectUnauthorized < "u")
        this._rejectUnauthorized = rejectUnauthorized;
      else
        this._rejectUnauthorized = rejectUnauthorizedDefault();
      let ciphers = options2.ciphers;
      if (typeof ciphers < "u") {
        if (typeof ciphers !== "string")
          throw @makeErrorWithCode(119, "options.ciphers", "string", ciphers);
        validateCiphers(ciphers);
      }
      this.ciphers = options2.ciphers, this.secureProtocol = options2.secureProtocol, this.minVersion = options2.minVersion, this.maxVersion = options2.maxVersion;
    }
  }, Server.prototype[kNativeSecureContextCtor] = NativeSecureContext, Server.prototype.getTicketKeys = function() {
    throw Error("Not implented in Bun yet");
  }, Server.prototype.setTicketKeys = function(keys) {
    if (!@ArrayBuffer.isView(keys))
      throw @makeErrorWithCode(119, "buffer", ["Buffer", "TypedArray", "DataView"], keys);
    if (keys.byteLength !== 48)
      throw @makeErrorWithCode(120, "buffer", keys, "Session ticket keys must be a 48-byte buffer");
    throw Error("Not implented in Bun yet");
  }, this[buntls] = function(port, host, isClient) {
    return [
      {
        serverName: this.servername || host || "localhost",
        key: this.key,
        cert: this.cert,
        ca: this.ca,
        passphrase: this.passphrase,
        secureOptions: this.secureOptions,
        rejectUnauthorized: this._rejectUnauthorized,
        requestCert: isClient ? !0 : this._requestCert,
        ALPNProtocols: this.ALPNProtocols,
        clientRenegotiationLimit: CLIENT_RENEG_LIMIT,
        clientRenegotiationWindow: CLIENT_RENEG_WINDOW,
        contexts,
        ciphers: this.ciphers,
        ...(() => {
          let minVersion, maxVersion, range = secureProtocolToVersionRange(this.secureProtocol);
          if (range)
            minVersion = range[0], maxVersion = range[1];
          else
            minVersion = tlsStringToProtocolVersion(this.minVersion ?? DEFAULT_MIN_VERSION), maxVersion = tlsStringToProtocolVersion(this.maxVersion ?? DEFAULT_MAX_VERSION);
          return { minVersion, maxVersion };
        })()
      },
      TLSSocket
    ];
  }, this.setSecureContext(options), maybeWarnAboutExtraCACerts();
  let handshakeTimeout = options && options.handshakeTimeout || 120000;
  validateNumber(handshakeTimeout, "options.handshakeTimeout"), this._handshakeTimeout = handshakeTimeout;
}
@toClass(Server, "Server", NetServer);
function createServer(options, connectionListener) {
  return new Server(options, connectionListener);
}
var DEFAULT_ECDH_CURVE = "auto", DEFAULT_MIN_VERSION = "TLSv1.2", DEFAULT_MAX_VERSION = "TLSv1.3";
{
  let execArgv = process.execArgv, hasFlag = (flag) => execArgv.includes(flag);
  if (hasFlag("--tls-min-v1.0"))
    DEFAULT_MIN_VERSION = "TLSv1";
  else if (hasFlag("--tls-min-v1.1"))
    DEFAULT_MIN_VERSION = "TLSv1.1";
  else if (hasFlag("--tls-min-v1.2"))
    DEFAULT_MIN_VERSION = "TLSv1.2";
  else if (hasFlag("--tls-min-v1.3"))
    DEFAULT_MIN_VERSION = "TLSv1.3";
  if (hasFlag("--tls-max-v1.3"))
    DEFAULT_MAX_VERSION = "TLSv1.3";
  else if (hasFlag("--tls-max-v1.2"))
    DEFAULT_MAX_VERSION = "TLSv1.2";
}
function normalizeConnectArgs(listArgs) {
  let args = net._normalizeArgs(listArgs);
  if (listArgs[1] !== null && typeof listArgs[1] === "object")
    ObjectAssign(args[0], listArgs[1]);
  else if (listArgs[2] !== null && typeof listArgs[2] === "object")
    ObjectAssign(args[0], listArgs[2]);
  return args;
}
function connect(...args) {
  let normal = normalizeConnectArgs(args), options = normal[0], { ALPNProtocols, servername } = options;
  if ("checkServerIdentity" in options)
    validateFunction(options.checkServerIdentity, "options.checkServerIdentity");
  if (servername && net.isIP(servername))
    throw @makeErrorWithCode(120, "options.servername", servername, "Setting the TLS ServerName to an IP address is not permitted.");
  if (ALPNProtocols)
    convertALPNProtocols(ALPNProtocols, options);
  let tlssock = new TLSSocket(options), timeout = options.timeout;
  if (timeout)
    tlssock.setTimeout(timeout);
  return tlssock.connect(normal);
}
function getCiphers() {
  return getDefaultCiphers().split(":");
}
function convertProtocols(protocols) {
  let lens = new @Array(protocols.length), buff = @Buffer.allocUnsafe(ArrayPrototypeReduce.@call(protocols, (p, c, i) => {
    let len = @Buffer.byteLength(c);
    if (len > 255) {
      let err = RangeError(`The byte length of the protocol at index ${i} exceeds the maximum length. It must be <= 255. Received ${len}`);
      throw err.code = "ERR_OUT_OF_RANGE", err;
    }
    return lens[i] = len, p + 1 + len;
  }, 0)), offset = 0;
  for (let i = 0, c = protocols.length;i < c; i++)
    buff[offset++] = lens[i], buff.write(protocols[i], offset), offset += lens[i];
  return buff;
}
function convertALPNProtocols(protocols, out) {
  if (@Array.isArray(protocols))
    out.ALPNProtocols = convertProtocols(protocols);
  else if (isArrayBufferView(protocols))
    out.ALPNProtocols = @Buffer.from(protocols.buffer.slice(protocols.byteOffset, protocols.byteOffset + protocols.byteLength));
}
var bundledRootCertificates;
function cacheBundledRootCertificates() {
  return bundledRootCertificates ||= getBundledRootCertificates(), bundledRootCertificates;
}
var getUseSystemCA = @lazy(85), defaultCACertificates;
function cacheDefaultCACertificates() {
  if (defaultCACertificates)
    return defaultCACertificates;
  defaultCACertificates = [];
  let bundled = cacheBundledRootCertificates();
  for (let i = 0;i < bundled.length; ++i)
    ArrayPrototypePush.@call(defaultCACertificates, bundled[i]);
  if (getUseSystemCA() || process.env.NODE_USE_SYSTEM_CA === "1") {
    let system = cacheSystemCACertificates();
    for (let i = 0;i < system.length; ++i)
      ArrayPrototypePush.@call(defaultCACertificates, system[i]);
  }
  if (process.env.NODE_EXTRA_CA_CERTS) {
    let extra = cacheExtraCACertificates();
    for (let i = 0;i < extra.length; ++i)
      ArrayPrototypePush.@call(defaultCACertificates, extra[i]);
  }
  return ObjectFreeze(defaultCACertificates), defaultCACertificates;
}
var systemCACertificates;
function cacheSystemCACertificates() {
  return systemCACertificates ||= getSystemCACertificates(), systemCACertificates;
}
var extraCACertificates;
function cacheExtraCACertificates() {
  return extraCACertificates ||= getExtraCACertificates(), extraCACertificates;
}
var warnedAboutExtraCACerts = !1;
function maybeWarnAboutExtraCACerts() {
  if (warnedAboutExtraCACerts)
    return;
  warnedAboutExtraCACerts = !0;
  let extraPath = process.env.NODE_EXTRA_CA_CERTS;
  if (!extraPath)
    return;
  try {
    (@getInternalField(@internalModuleRegistry, 116) || @createInternalModuleById(116)).accessSync(extraPath);
  } catch (err) {
    process.stderr.write(`Warning: Ignoring extra certs from \`${extraPath}\`, load failed: ${err?.code === "ENOENT" ? "No such file or directory" : err?.message}
`);
  }
}
var _defaultCACertificatesOverride, _X509CertificateClass;
function setDefaultCACertificates(certs) {
  if (!@isArray(certs)) {
    let received;
    if (certs === null)
      received = "null";
    else if (typeof certs === "object")
      received = `an instance of ${certs.constructor?.name ?? "Object"}`;
    else if (typeof certs === "string")
      received = `type string ('${certs}')`;
    else
      received = `type ${typeof certs} (${@String(certs)})`;
    let error = @makeTypeError(`The "certs" argument must be an instance of Array. Received ${received}`);
    throw error.code = "ERR_INVALID_ARG_TYPE", error;
  }
  _X509CertificateClass ??= (@getInternalField(@internalModuleRegistry, 108) || @createInternalModuleById(108)).X509Certificate;
  let seen = /* @__PURE__ */ new Set, normalized = [];
  for (let i = 0;i < certs.length; i++) {
    let cert = certs[i];
    if (typeof cert !== "string" && !isArrayBufferView(cert))
      throw @makeErrorWithCode(119, `certs[${i}]`, "string or an instance of ArrayBufferView", cert);
    let text = typeof cert === "string" ? cert : @Buffer.from(cert.buffer, cert.byteOffset, cert.byteLength).toString("latin1"), blocks = text.includes("-----BEGIN") ? text.split(/(?=-----BEGIN [A-Z0-9 ]*CERTIFICATE-----)/).filter((block) => block.includes("CERTIFICATE-----")) : [cert];
    for (let block of blocks) {
      let x509 = new _X509CertificateClass(block), fingerprint = x509.fingerprint256;
      if (!seen.has(fingerprint))
        seen.add(fingerprint), normalized.push(x509.toString());
    }
  }
  _defaultCACertificatesOverride = normalized;
}
function getCACertificates(type = "default") {
  switch (validateString(type, "type"), type) {
    case "default":
      if (_defaultCACertificatesOverride !== @undefined)
        return _defaultCACertificatesOverride.slice();
      return cacheDefaultCACertificates();
    case "bundled":
      return cacheBundledRootCertificates();
    case "system":
      return cacheSystemCACertificates();
    case "extra":
      return cacheExtraCACertificates();
    default:
      throw @makeErrorWithCode(120, "type", type);
  }
}
function tlsCipherFilter(a) {
  return !a.startsWith("TLS_");
}
function getDefaultCiphers() {
  let ciphers = getTLSDefaultCiphers();
  return `TLS_AES_256_GCM_SHA384:TLS_CHACHA20_POLY1305_SHA256:TLS_AES_128_GCM_SHA256${ciphers ? ":" + ciphers : ""}`;
}
$ = {
  CLIENT_RENEG_LIMIT,
  CLIENT_RENEG_WINDOW,
  connect,
  convertALPNProtocols,
  createSecureContext,
  createServer,
  get DEFAULT_CIPHERS() {
    return getDefaultCiphers();
  },
  set DEFAULT_CIPHERS(value) {
    if (value)
      validateCiphers(value, "value"), value = value.split(":").filter(tlsCipherFilter).join(":");
    setTLSDefaultCiphers(value);
  },
  DEFAULT_ECDH_CURVE,
  get DEFAULT_MAX_VERSION() {
    return DEFAULT_MAX_VERSION;
  },
  set DEFAULT_MAX_VERSION(value) {
    DEFAULT_MAX_VERSION = value;
  },
  get DEFAULT_MIN_VERSION() {
    return DEFAULT_MIN_VERSION;
  },
  set DEFAULT_MIN_VERSION(value) {
    DEFAULT_MIN_VERSION = value;
  },
  getCiphers,
  setDefaultCACertificates,
  parseCertString,
  SecureContext: SecureContext2,
  Server,
  TLSSocket,
  checkServerIdentity,
  get rootCertificates() {
    return cacheBundledRootCertificates();
  },
  getCACertificates
};
return $

})
