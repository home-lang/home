(function () {"use strict";
// .zig-cache/o/bb9353210c22a89660eb2e4b9083cc39/native-modules/InternalAsyncHooks.mts
var $, activeHooks = 0;
function enabledHooksExist() {
  return activeHooks > 0;
}
function markHookEnabled() {
  activeHooks += 1;
}
function markHookDisabled() {
  if (activeHooks > 0)
    activeHooks -= 1;
}
$ = {
  enabledHooksExist,
  markHookEnabled,
  markHookDisabled
};
return $

})
