(function () {"use strict";
// zig-out/http-tls-graph-port-2026-10-10/generated/NodePathPosix.mts
var $;
$ = (@getInternalField(@internalModuleRegistry, 125) || @createInternalModuleById(125)).posix;
return $

})
