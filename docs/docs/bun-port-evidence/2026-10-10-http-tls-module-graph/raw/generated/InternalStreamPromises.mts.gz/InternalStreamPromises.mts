var $;
"use strict";

const ArrayPrototypePop = Array.prototype.pop;

const { isIterable, isNodeStream, isWebStream } = (__intrinsic__getInternalField(__intrinsic__internalModuleRegistry, 76) || __intrinsic__createInternalModuleById(76));
const { pipelineImpl: pl } = (__intrinsic__getInternalField(__intrinsic__internalModuleRegistry, 72) || __intrinsic__createInternalModuleById(72));
const { finished } = (__intrinsic__getInternalField(__intrinsic__internalModuleRegistry, 53) || __intrinsic__createInternalModuleById(53));

// require("internal/stream");

function pipeline(...streams) {
  return new Promise((resolve, reject) => {
    let signal;
    let end;
    const lastArg = streams[streams.length - 1];
    if (
      lastArg &&
      typeof lastArg === "object" &&
      !isNodeStream(lastArg) &&
      !isIterable(lastArg) &&
      !isWebStream(lastArg)
    ) {
      const options = ArrayPrototypePop.__intrinsic__call(streams);
      signal = options.signal;
      end = options.end;
    }

    pl(
      streams,
      (err, value) => {
        if (err) {
          reject(err);
        } else {
          resolve(value);
        }
      },
      { signal, end },
    );
  });
}

$ = {
  finished,
  pipeline,
};
;$$EXPORT$$($).$$EXPORT_END$$;
