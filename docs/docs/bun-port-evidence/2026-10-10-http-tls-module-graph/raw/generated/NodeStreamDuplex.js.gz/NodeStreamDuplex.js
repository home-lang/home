(function () {"use strict";
// zig-out/http-tls-graph-port-2026-10-10/generated/NodeStreamDuplex.mts
var $;
$ = @getInternalField(@internalModuleRegistry, 50) || @createInternalModuleById(50);
return $

})
