(function () {"use strict";
// zig-out/http-tls-graph-port-2026-10-10/generated/NodePathWin32.mts
var $;
$ = (@getInternalField(@internalModuleRegistry, 125) || @createInternalModuleById(125)).win32;
return $

})
