(function () {"use strict";
// zig-out/http-tls-graph-port-2026-10-10/generated/InternalStreamPromises.mts
var $, ArrayPrototypePop = @Array.prototype.pop, { isIterable, isNodeStream, isWebStream } = @getInternalField(@internalModuleRegistry, 76) || @createInternalModuleById(76), { pipelineImpl: pl } = @getInternalField(@internalModuleRegistry, 72) || @createInternalModuleById(72), { finished } = @getInternalField(@internalModuleRegistry, 53) || @createInternalModuleById(53);
function pipeline(...streams) {
  return new @Promise((resolve, reject) => {
    let signal, end, lastArg = streams[streams.length - 1];
    if (lastArg && typeof lastArg === "object" && !isNodeStream(lastArg) && !isIterable(lastArg) && !isWebStream(lastArg)) {
      let options = ArrayPrototypePop.@call(streams);
      signal = options.signal, end = options.end;
    }
    pl(streams, (err, value) => {
      if (err)
        reject(err);
      else
        resolve(value);
    }, { signal, end });
  });
}
$ = {
  finished,
  pipeline
};
return $

})
