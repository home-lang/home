(function () {"use strict";
// zig-out/http-tls-graph-port-2026-10-10/generated/NodeHttp.mts
var $, { validateInteger, validateObject } = @getInternalField(@internalModuleRegistry, 86) || @createInternalModuleById(86), httpAgent = @getInternalField(@internalModuleRegistry, 89) || @createInternalModuleById(89), { Agent } = httpAgent, { ClientRequest } = @getInternalField(@internalModuleRegistry, 90) || @createInternalModuleById(90), { validateHeaderName, validateHeaderValue, parsers } = @getInternalField(@internalModuleRegistry, 91) || @createInternalModuleById(91), { IncomingMessage } = @getInternalField(@internalModuleRegistry, 92) || @createInternalModuleById(92), { OutgoingMessage } = @getInternalField(@internalModuleRegistry, 93) || @createInternalModuleById(93), { Server, ServerResponse } = @getInternalField(@internalModuleRegistry, 94) || @createInternalModuleById(94), { METHODS, STATUS_CODES, setMaxHTTPHeaderSize, getMaxHTTPHeaderSize } = @getInternalField(@internalModuleRegistry, 31) || @createInternalModuleById(31);
(@getInternalField(@internalModuleRegistry, 145) || @createInternalModuleById(145)).debuglog("http");
var { WebSocket, CloseEvent, MessageEvent } = globalThis;
function createServer(options, callback) {
  return new Server(options, callback);
}
function request(url, options, cb) {
  return new ClientRequest(url, options, cb);
}
function get(url, options, cb) {
  let req = request(url, options, cb);
  return req.end(), req;
}
var http_exports = {
  Agent,
  Server,
  METHODS,
  STATUS_CODES,
  createServer,
  ServerResponse,
  IncomingMessage,
  request,
  get,
  get maxHeaderSize() {
    return getMaxHTTPHeaderSize();
  },
  set maxHeaderSize(value) {
    setMaxHTTPHeaderSize(value);
  },
  validateHeaderName,
  validateHeaderValue,
  setMaxIdleHTTPParsers(max) {
    validateInteger(max, "max", 1), parsers.max = max;
  },
  setGlobalProxyFromEnv,
  get globalAgent() {
    return httpAgent.globalAgent;
  },
  set globalAgent(value) {
    httpAgent.globalAgent = value;
  },
  ClientRequest,
  OutgoingMessage,
  WebSocket,
  CloseEvent,
  MessageEvent
};
function noopRestore() {}
function setGlobalProxyFromEnv(env = process.env) {
  validateObject(env, "proxyEnv");
  let { parseProxyUrl } = @getInternalField(@internalModuleRegistry, 31) || @createInternalModuleById(31), httpProxy = parseProxyUrl(env, "http:"), httpsProxy = parseProxyUrl(env, "https:");
  if (httpProxy === null && httpsProxy === null)
    return noopRestore;
  if (httpProxy !== null && URL.canParse(httpProxy) === !1)
    throw @makeErrorWithCode(202, `Invalid proxy URL: ${httpProxy}`);
  if (httpsProxy !== null && URL.canParse(httpsProxy) === !1)
    throw @makeErrorWithCode(202, `Invalid proxy URL: ${httpsProxy}`);
  let originalHttpsAgent, originalHttpAgent;
  if (httpProxy !== null)
    originalHttpAgent = httpAgent.globalAgent, httpAgent.globalAgent = new Agent({
      keepAlive: !0,
      scheduling: "lifo",
      timeout: 5000,
      proxyEnv: env
    });
  if (httpsProxy !== null) {
    let https = @getInternalField(@internalModuleRegistry, 119) || @createInternalModuleById(119);
    originalHttpsAgent = https.globalAgent, https.globalAgent = new https.Agent({
      keepAlive: !0,
      scheduling: "lifo",
      timeout: 5000,
      proxyEnv: env
    });
  }
  return function restore() {
    if (originalHttpAgent !== @undefined)
      httpAgent.globalAgent = originalHttpAgent;
    if (originalHttpsAgent !== @undefined)
      (@getInternalField(@internalModuleRegistry, 119) || @createInternalModuleById(119)).globalAgent = originalHttpsAgent;
  };
}
$ = http_exports;
return $

})
