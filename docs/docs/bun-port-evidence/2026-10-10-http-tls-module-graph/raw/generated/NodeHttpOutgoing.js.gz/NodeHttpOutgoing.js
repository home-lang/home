(function () {"use strict";
// zig-out/http-tls-graph-port-2026-10-10/generated/NodeHttpOutgoing.mts
var $, { Stream } = @getInternalField(@internalModuleRegistry, 46) || @createInternalModuleById(46), { isUint8Array, validateString } = @getInternalField(@internalModuleRegistry, 86) || @createInternalModuleById(86), { deprecate } = @getInternalField(@internalModuleRegistry, 83) || @createInternalModuleById(83), { getDefaultHighWaterMark } = @getInternalField(@internalModuleRegistry, 74) || @createInternalModuleById(74), { kOutHeaders, kNeedDrain, utcDate } = @getInternalField(@internalModuleRegistry, 31) || @createInternalModuleById(31), {
  validateHeaderName,
  validateHeaderValue,
  _checkInvalidHeaderChar: checkInvalidHeaderChar,
  chunkExpression: RE_TE_CHUNKED
} = @getInternalField(@internalModuleRegistry, 91) || @createInternalModuleById(91), { FakeSocket } = @getInternalField(@internalModuleRegistry, 32) || @createInternalModuleById(32), EE = @getInternalField(@internalModuleRegistry, 114) || @createInternalModuleById(114), ObjectDefineProperty = Object.defineProperty, ObjectKeys = Object.keys, ObjectValues = Object.values, ObjectHasOwn = Object.hasOwn, ArrayIsArray = @Array.isArray, MathFloor = Math.floor, kCorked = Symbol("corked"), kSocket = Symbol("kSocket"), kChunkedBuffer = Symbol("kChunkedBuffer"), kChunkedLength = Symbol("kChunkedLength"), kUniqueHeaders = Symbol("kUniqueHeaders"), kBytesWritten = Symbol("kBytesWritten"), kErrored = Symbol("errored"), kHighWaterMark = Symbol("kHighWaterMark"), kRejectNonStandardBodyWrites = Symbol("kRejectNonStandardBodyWrites"), nop = () => {}, RE_CONN_CLOSE = /(?:^|\W)close(?:$|\W)/i;
function isCookieField(s) {
  return s.length === 6 && s.toLowerCase() === "cookie";
}
function isContentDispositionField(s) {
  return s.length === 19 && s.toLowerCase() === "content-disposition";
}
function OutgoingMessage(options) {
  Stream.@call(this, options), this.outputData = [], this.outputSize = 0, this.writable = !0, this.destroyed = !1, this._last = !1, this.chunkedEncoding = !1, this.shouldKeepAlive = !0, this.maxRequestsOnConnectionReached = !1, this._defaultKeepAlive = !0, this.useChunkedEncodingByDefault = !0, this.sendDate = !1, this._removedConnection = !1, this._removedContLen = !1, this._removedTE = !1, this.strictContentLength = !1, this[kBytesWritten] = 0, this._contentLength = null, this._hasBody = !0, this._trailer = "", this[kNeedDrain] = !1, this.finished = !1, this._headerSent = !1, this[kCorked] = 0, this[kChunkedBuffer] = [], this[kChunkedLength] = 0, this._closed = !1, this[kSocket] = null, this._header = null, this[kOutHeaders] = null, this._keepAliveTimeout = 0, this._onPendingData = nop, this[kErrored] = null, this[kHighWaterMark] = options?.highWaterMark ?? getDefaultHighWaterMark(), this[kRejectNonStandardBodyWrites] = options?.rejectNonStandardBodyWrites ?? !1;
}
@toClass(OutgoingMessage, "OutgoingMessage", Stream);
ObjectDefineProperty(OutgoingMessage.prototype, "errored", {
  __proto__: null,
  get() {
    return this[kErrored];
  }
});
ObjectDefineProperty(OutgoingMessage.prototype, "closed", {
  __proto__: null,
  get() {
    return this._closed;
  }
});
ObjectDefineProperty(OutgoingMessage.prototype, "writableFinished", {
  __proto__: null,
  get() {
    return this.finished && this.outputSize === 0 && (!this[kSocket] || this[kSocket].writableLength === 0);
  }
});
ObjectDefineProperty(OutgoingMessage.prototype, "writableObjectMode", {
  __proto__: null,
  get() {
    return !1;
  }
});
ObjectDefineProperty(OutgoingMessage.prototype, "writableLength", {
  __proto__: null,
  get() {
    return this.outputSize + this[kChunkedLength] + (this[kSocket] ? this[kSocket].writableLength : 0);
  }
});
ObjectDefineProperty(OutgoingMessage.prototype, "writableHighWaterMark", {
  __proto__: null,
  get() {
    return this[kSocket] ? this[kSocket].writableHighWaterMark : this[kHighWaterMark];
  }
});
ObjectDefineProperty(OutgoingMessage.prototype, "writableCorked", {
  __proto__: null,
  get() {
    return this[kCorked];
  }
});
ObjectDefineProperty(OutgoingMessage.prototype, "connection", {
  __proto__: null,
  get: function() {
    return this[kSocket];
  },
  set: function(val) {
    this.socket = val;
  }
});
ObjectDefineProperty(OutgoingMessage.prototype, "socket", {
  __proto__: null,
  get: function() {
    return this[kSocket];
  },
  set: function(val) {
    for (let n = 0;n < this[kCorked]; n++)
      val?.cork(), this[kSocket]?.uncork();
    this[kSocket] = val;
  }
});
OutgoingMessage.prototype._renderHeaders = function _renderHeaders() {
  if (this._header)
    throw @makeErrorWithCode(70, "render");
  let headersMap = this[kOutHeaders], headers = {};
  if (headersMap !== null) {
    let keys = ObjectKeys(headersMap);
    for (let i = 0, l = keys.length;i < l; i++) {
      let key = keys[i];
      headers[headersMap[key][0]] = headersMap[key][1];
    }
  }
  return headers;
};
OutgoingMessage.prototype.cork = function cork() {
  if (this[kCorked]++, this[kSocket])
    this[kSocket].cork();
};
OutgoingMessage.prototype.uncork = function uncork() {
  if (this[kCorked]--, this[kSocket])
    this[kSocket].uncork();
  if (this[kCorked] || this[kChunkedBuffer].length === 0)
    return;
  let len = this[kChunkedLength], buf = this[kChunkedBuffer], callbacks;
  this._send(len.toString(16), "latin1", null), this._send(crlf_buf, null, null);
  for (let n = 0;n < buf.length; n += 3)
    if (this._send(buf[n + 0], buf[n + 1], null), buf[n + 2])
      callbacks ??= [], callbacks.push(buf[n + 2]);
  this._send(crlf_buf, null, callbacks?.length ? runChunkCallbacks.bind(@undefined, callbacks) : null), this[kChunkedBuffer].length = 0, this[kChunkedLength] = 0;
};
function runChunkCallbacks(callbacks, err) {
  for (let callback of callbacks)
    callback(err);
}
OutgoingMessage.prototype.setTimeout = function setTimeout(msecs, callback) {
  if (callback)
    this.on("timeout", callback);
  if (!this[kSocket])
    this.once("socket", function socketSetTimeoutOnConnect(socket) {
      socket.setTimeout(msecs);
    });
  else
    this[kSocket].setTimeout(msecs);
  return this;
};
OutgoingMessage.prototype.destroy = function destroy(error) {
  if (this.destroyed)
    return this;
  if (this.destroyed = !0, this[kErrored] = error, this[kSocket])
    this[kSocket].destroy(error);
  else
    process.nextTick(emitDestroyNT, this);
  return this;
};
function emitDestroyNT(self) {
  if (!self._closed)
    self._closed = !0, self.emit("close");
}
OutgoingMessage.prototype._send = function _send(data, encoding, callback, byteLength) {
  let header;
  if (!this._headerSent && (header = this._header) !== null) {
    if (typeof data === "string" && (encoding === "utf8" || encoding === "latin1" || !encoding))
      data = header + data;
    else
      this.outputData.unshift({
        data: header,
        encoding: "latin1",
        callback: null
      }), this.outputSize += header.length, this._onPendingData(header.length);
    this._headerSent = !0;
  }
  return this._writeRaw(data, encoding, callback, byteLength);
};
OutgoingMessage.prototype._writeRaw = _writeRaw;
function _writeRaw(data, encoding, callback, _size) {
  let conn = this[kSocket];
  if (conn?.destroyed)
    return !1;
  if (typeof encoding === "function")
    callback = encoding, encoding = null;
  if (conn && conn._httpMessage === this && conn.writable) {
    if (this.outputData.length)
      this._flushOutput(conn);
    return conn.write(data, encoding, callback);
  }
  return this.outputData.push({ data, encoding, callback }), this.outputSize += data.length, this._onPendingData(data.length), this.outputSize < this[kHighWaterMark];
}
OutgoingMessage.prototype._storeHeader = _storeHeader;
function _storeHeader(firstLine, headers) {
  let state = {
    connection: !1,
    contLen: !1,
    te: !1,
    date: !1,
    expect: !1,
    trailer: !1,
    header: firstLine
  };
  if (headers) {
    if (headers === this[kOutHeaders])
      for (let key in headers) {
        let entry = headers[key];
        processHeader(this, state, entry[0], entry[1], !1);
      }
    else if (ArrayIsArray(headers)) {
      let headersLength = headers.length;
      if (headersLength && ArrayIsArray(headers[0]))
        for (let i = 0;i < headersLength; i++) {
          let entry = headers[i];
          processHeader(this, state, entry[0], entry[1], !0);
        }
      else {
        if (headersLength % 2 !== 0)
          throw @makeErrorWithCode(120, "headers", headers);
        for (let n = 0;n < headersLength; n += 2)
          processHeader(this, state, headers[n + 0], headers[n + 1], !0);
      }
    } else
      for (let key in headers)
        if (ObjectHasOwn(headers, key))
          processHeader(this, state, key, headers[key], !0);
  }
  let { header } = state;
  if (this.sendDate && !state.date)
    header += "Date: " + utcDate() + `\r
`;
  if (this.chunkedEncoding && (this.statusCode === 204 || this.statusCode === 304))
    this.chunkedEncoding = !1, this.shouldKeepAlive = !1;
  if (this._removedConnection)
    this._last = !this.shouldKeepAlive;
  else if (!state.connection) {
    let shouldSendKeepAlive = this.shouldKeepAlive && (state.contLen || this.useChunkedEncodingByDefault || this.agent);
    if (shouldSendKeepAlive && this.maxRequestsOnConnectionReached)
      header += `Connection: close\r
`;
    else if (shouldSendKeepAlive) {
      header += `Connection: keep-alive\r
`;
      let keepAliveTimeout = this._keepAliveTimeout;
      if (keepAliveTimeout && this._defaultKeepAlive) {
        let timeoutSeconds = MathFloor(keepAliveTimeout / 1000), max = "", maxRequestsPerSocket = this._maxRequestsPerSocket;
        if (~~maxRequestsPerSocket > 0)
          max = `, max=${maxRequestsPerSocket}`;
        header += `Keep-Alive: timeout=${timeoutSeconds}${max}\r
`;
      }
    } else
      this._last = !0, header += `Connection: close\r
`;
  }
  if (!state.contLen && !state.te)
    if (!this._hasBody)
      this.chunkedEncoding = !1;
    else if (!this.useChunkedEncodingByDefault)
      this._last = !0;
    else {
      let contentLength;
      if (!state.trailer && !this._removedContLen && typeof (contentLength = this._contentLength) === "number")
        header += "Content-Length: " + contentLength + `\r
`;
      else if (!this._removedTE)
        header += `Transfer-Encoding: chunked\r
`, this.chunkedEncoding = !0;
      else
        this._last = !0;
    }
  if (this.chunkedEncoding !== !0 && state.trailer)
    throw @makeErrorWithCode(74);
  if (this._header = header + `\r
`, this._headerSent = !1, state.expect)
    this._send("");
}
function processHeader(self, state, key, value, validate) {
  if (validate)
    validateHeaderName(key);
  if (isContentDispositionField(key) && self._contentLength)
    if (ArrayIsArray(value))
      for (let i = 0;i < value.length; i++)
        value[i] = @Buffer.from(value[i], "latin1");
    else
      value = @Buffer.from(value, "latin1");
  if (ArrayIsArray(value)) {
    let valueLength = value.length;
    if ((valueLength < 2 || !isCookieField(key)) && (!self[kUniqueHeaders] || !self[kUniqueHeaders].has(key.toLowerCase()))) {
      for (let i = 0;i < valueLength; i++)
        storeHeader(self, state, key, value[i], validate);
      return;
    }
    value = value.join("; ");
  }
  storeHeader(self, state, key, value, validate);
}
function storeHeader(self, state, key, value, validate) {
  if (validate)
    validateHeaderValue(key, value);
  state.header += key + ": " + value + `\r
`, matchHeader(self, state, key, value);
}
function matchHeader(self, state, field, value) {
  if (field.length < 4 || field.length > 17)
    return;
  switch (field = field.toLowerCase(), field) {
    case "connection":
      if (state.connection = !0, self._removedConnection = !1, RE_CONN_CLOSE.test(value))
        self._last = !0;
      else
        self.shouldKeepAlive = !0;
      break;
    case "transfer-encoding":
      if (state.te = !0, self._removedTE = !1, RE_TE_CHUNKED.test(value))
        self.chunkedEncoding = !0;
      break;
    case "content-length":
      state.contLen = !0, self._contentLength = +value, self._removedContLen = !1;
      break;
    case "date":
    case "expect":
    case "trailer":
      state[field] = !0;
      break;
    case "keep-alive":
      self._defaultKeepAlive = !1;
      break;
  }
}
function parseUniqueHeadersOption(headers) {
  if (!ArrayIsArray(headers))
    return null;
  let unique = /* @__PURE__ */ new Set, l = headers.length;
  for (let i = 0;i < l; i++)
    unique.add(headers[i].toLowerCase());
  return unique;
}
OutgoingMessage.prototype.setHeader = function setHeader(name, value) {
  if (this._header)
    throw @makeErrorWithCode(70, "set");
  validateHeaderName(name), validateHeaderValue(name, value);
  let headers = this[kOutHeaders];
  if (headers === null)
    this[kOutHeaders] = headers = { __proto__: null };
  return headers[name.toLowerCase()] = [name, value], this;
};
OutgoingMessage.prototype.setHeaders = function setHeaders(headers) {
  if (this._header)
    throw @makeErrorWithCode(70, "set");
  if (!headers || ArrayIsArray(headers) || typeof headers.keys !== "function" || typeof headers.get !== "function")
    throw @makeErrorWithCode(119, "headers", ["Headers", "Map"], headers);
  let cookies = null;
  for (let { 0: key, 1: value } of headers) {
    if (key === "set-cookie") {
      if (ArrayIsArray(value))
        cookies ??= [], cookies.push(...value);
      else
        cookies ??= [], cookies.push(value);
      continue;
    }
    this.setHeader(key, value);
  }
  if (cookies != null)
    this.setHeader("set-cookie", cookies);
  return this;
};
OutgoingMessage.prototype.appendHeader = function appendHeader(name, value) {
  if (this._header)
    throw @makeErrorWithCode(70, "append");
  validateHeaderName(name), validateHeaderValue(name, value);
  let field = name.toLowerCase(), headers = this[kOutHeaders];
  if (headers === null || !headers[field])
    return this.setHeader(name, value);
  if (!ArrayIsArray(headers[field][1]))
    headers[field][1] = [headers[field][1]];
  let existingValues = headers[field][1];
  if (ArrayIsArray(value))
    for (let i = 0, length = value.length;i < length; i++)
      existingValues.push(value[i]);
  else
    existingValues.push(value);
  return this;
};
OutgoingMessage.prototype.getHeader = function getHeader(name) {
  validateString(name, "name");
  let headers = this[kOutHeaders];
  if (headers === null)
    return;
  return headers[name.toLowerCase()]?.[1];
};
OutgoingMessage.prototype.getHeaderNames = function getHeaderNames() {
  return this[kOutHeaders] !== null ? ObjectKeys(this[kOutHeaders]) : [];
};
OutgoingMessage.prototype.getRawHeaderNames = function getRawHeaderNames() {
  let headersMap = this[kOutHeaders];
  if (headersMap === null)
    return [];
  let values = ObjectValues(headersMap), headers = @Array(values.length);
  for (let i = 0, l = values.length;i < l; i++)
    headers[i] = values[i][0];
  return headers;
};
OutgoingMessage.prototype.getHeaders = function getHeaders() {
  let headers = this[kOutHeaders], ret = { __proto__: null };
  if (headers) {
    let keys = ObjectKeys(headers);
    for (let i = 0;i < keys.length; ++i) {
      let key = keys[i], val = headers[key][1];
      ret[key] = val;
    }
  }
  return ret;
};
OutgoingMessage.prototype.hasHeader = function hasHeader(name) {
  return validateString(name, "name"), this[kOutHeaders] !== null && !!this[kOutHeaders][name.toLowerCase()];
};
OutgoingMessage.prototype.removeHeader = function removeHeader(name) {
  if (validateString(name, "name"), this._header)
    throw @makeErrorWithCode(70, "remove");
  let key = name.toLowerCase();
  switch (key) {
    case "connection":
      this._removedConnection = !0;
      break;
    case "content-length":
      this._removedContLen = !0;
      break;
    case "transfer-encoding":
      this._removedTE = !0;
      break;
    case "date":
      this.sendDate = !1;
      break;
  }
  if (this[kOutHeaders] !== null)
    delete this[kOutHeaders][key];
};
OutgoingMessage.prototype._implicitHeader = function _implicitHeader() {
  throw @makeErrorWithCode(151, "_implicitHeader()");
};
ObjectDefineProperty(OutgoingMessage.prototype, "headersSent", {
  __proto__: null,
  configurable: !0,
  enumerable: !0,
  get: function() {
    return !!this._header;
  }
});
ObjectDefineProperty(OutgoingMessage.prototype, "writableEnded", {
  __proto__: null,
  get: function() {
    return this.finished;
  }
});
ObjectDefineProperty(OutgoingMessage.prototype, "writableNeedDrain", {
  __proto__: null,
  get: function() {
    return !this.destroyed && !this.finished && this[kNeedDrain];
  }
});
var crlf_buf = @Buffer.from(`\r
`);
OutgoingMessage.prototype.write = function write(chunk, encoding, callback) {
  if (typeof encoding === "function")
    callback = encoding, encoding = null;
  let ret = write_(this, chunk, encoding, callback, !1);
  if (!ret)
    this[kNeedDrain] = !0;
  return ret;
};
function onError(msg, err, callback) {
  if (msg.destroyed)
    return;
  process.nextTick(emitErrorNt, msg, err, callback);
}
function emitErrorNt(msg, err, callback) {
  if (callback(err), typeof msg.emit === "function" && !msg.destroyed)
    msg.emit("error", err);
}
function strictContentLength(msg) {
  return msg.strictContentLength && msg._contentLength != null && msg._hasBody && !msg._removedContLen && !msg.chunkedEncoding && !msg.hasHeader("transfer-encoding");
}
function write_(msg, chunk, encoding, callback, fromEnd) {
  if (typeof callback !== "function")
    callback = nop;
  if (chunk === null)
    throw @makeErrorWithCode(234);
  else if (typeof chunk !== "string" && !isUint8Array(chunk))
    throw @makeErrorWithCode(119, "chunk", ["string", "Buffer", "Uint8Array"], chunk);
  let err;
  if (msg.finished)
    err = @makeErrorWithCode(241);
  else if (msg.destroyed)
    err = @makeErrorWithCode(232, "write");
  if (err) {
    if (!msg.destroyed)
      onError(msg, err, callback);
    else
      process.nextTick(callback, err);
    return !1;
  }
  let len;
  if (msg.strictContentLength) {
    len ??= typeof chunk === "string" ? @Buffer.byteLength(chunk, encoding) : chunk.byteLength;
    let contentLength = msg._contentLength;
    if (strictContentLength(msg) && (fromEnd ? msg[kBytesWritten] + len !== contentLength : msg[kBytesWritten] + len > contentLength))
      throw @makeErrorWithCode(71, len + msg[kBytesWritten], contentLength);
    msg[kBytesWritten] += len;
  }
  if (!msg._header) {
    if (fromEnd)
      len ??= typeof chunk === "string" ? @Buffer.byteLength(chunk, encoding) : chunk.byteLength, msg._contentLength = len;
    msg._implicitHeader();
  }
  if (!msg._hasBody)
    if (msg[kRejectNonStandardBodyWrites])
      throw @makeErrorWithCode(69);
    else
      return process.nextTick(callback), !0;
  let msgSocket;
  if (!fromEnd && (msgSocket = msg.socket) && !msgSocket.writableCorked)
    msgSocket.cork(), process.nextTick(connectionCorkNT, msgSocket);
  let ret;
  if (msg.chunkedEncoding && chunk.length !== 0)
    if (len ??= typeof chunk === "string" ? @Buffer.byteLength(chunk, encoding) : chunk.byteLength, msg[kCorked] && msg._headerSent)
      msg[kChunkedBuffer].push(chunk, encoding, callback), msg[kChunkedLength] += len, ret = msg[kChunkedLength] < msg[kHighWaterMark];
    else
      msg._send(len.toString(16), "latin1", null), msg._send(crlf_buf, null, null), msg._send(chunk, encoding, null, len), ret = msg._send(crlf_buf, null, callback);
  else
    ret = msg._send(chunk, encoding, callback, len);
  return ret;
}
function connectionCorkNT(conn) {
  conn.uncork();
}
OutgoingMessage.prototype.addTrailers = function addTrailers(headers) {
  this._trailer = "";
  let keys = ObjectKeys(headers), isArray = ArrayIsArray(headers);
  for (let i = 0, l = keys.length;i < l; i++) {
    let field, value, key = keys[i];
    if (isArray)
      field = headers[key][0], value = headers[key][1];
    else
      field = key, value = headers[key];
    validateHeaderName(field, "Trailer name");
    let isArrayValue = ArrayIsArray(value), valueLength = isArrayValue ? value.length : 0;
    if (isArrayValue && valueLength > 1 && (!this[kUniqueHeaders] || !this[kUniqueHeaders].has(field.toLowerCase())))
      for (let j = 0, l2 = valueLength;j < l2; j++) {
        if (checkInvalidHeaderChar(value[j]))
          throw @makeErrorWithCode(123, "trailer content", field);
        this._trailer += field + ": " + value[j] + `\r
`;
      }
    else {
      if (isArrayValue)
        value = value.join("; ");
      if (checkInvalidHeaderChar(value))
        throw @makeErrorWithCode(123, "trailer content", field);
      this._trailer += field + ": " + value + `\r
`;
    }
  }
};
function onFinish(outmsg) {
  if (outmsg?.socket?._hadError)
    return;
  outmsg.emit("finish");
}
OutgoingMessage.prototype.end = function end(chunk, encoding, callback) {
  if (typeof chunk === "function")
    callback = chunk, chunk = null, encoding = null;
  else if (typeof encoding === "function")
    callback = encoding, encoding = null;
  if (chunk) {
    if (this.finished)
      return onError(this, @makeErrorWithCode(241), typeof callback !== "function" ? nop : callback), this;
    if (this[kSocket])
      this[kSocket].cork();
    write_(this, chunk, encoding, null, !0);
  } else if (this.finished) {
    if (typeof callback === "function")
      if (!this.writableFinished)
        this.on("finish", callback);
      else
        callback(@makeErrorWithCode(230, "end"));
    return this;
  } else if (!this._header) {
    if (this[kSocket])
      this[kSocket].cork();
    this._contentLength = 0, this._implicitHeader();
  }
  if (typeof callback === "function")
    this.once("finish", callback);
  let contentLength;
  if (strictContentLength(this) && this[kBytesWritten] !== (contentLength = this._contentLength))
    throw @makeErrorWithCode(71, this[kBytesWritten], contentLength);
  let finish = onFinish.bind(@undefined, this);
  if (this._hasBody && this.chunkedEncoding)
    this._send(`0\r
` + this._trailer + `\r
`, "latin1", finish);
  else if (!this._headerSent || this.writableLength || chunk)
    this._send("", "latin1", finish);
  else
    process.nextTick(finish);
  if (this[kSocket])
    this[kSocket]._writableState.corked = 1, this[kSocket].uncork();
  if (this[kCorked] = 1, this.uncork(), this.finished = !0, this.outputData.length === 0 && this[kSocket] && this[kSocket]._httpMessage === this)
    this._finish();
  return this;
};
OutgoingMessage.prototype._finish = function _finish() {
  this.emit("prefinish");
};
OutgoingMessage.prototype._flush = function _flush() {
  let socket = this[kSocket];
  if (socket?.writable) {
    if (this._flushOutput(socket), this.finished)
      this._finish();
    else if (this[kNeedDrain] && this.writableLength === 0)
      this[kNeedDrain] = !1, this.emit("drain");
  }
};
OutgoingMessage.prototype._flushOutput = function _flushOutput(socket) {
  let outputLength = this.outputData.length;
  if (outputLength <= 0)
    return @undefined;
  let outputData = this.outputData;
  socket.cork();
  let ret;
  for (let i = 0;i < outputLength; i++) {
    let { data, encoding, callback } = outputData[i];
    outputData[i].data = null, ret = socket.write(data, encoding, callback);
  }
  return socket.uncork(), this.outputData = [], this._onPendingData(-this.outputSize), this.outputSize = 0, ret;
};
OutgoingMessage.prototype.flushHeaders = function flushHeaders() {
  if (!this._header)
    this._implicitHeader();
  this._send("");
};
OutgoingMessage.prototype.pipe = function pipe() {
  this.emit("error", @makeErrorWithCode(231));
};
OutgoingMessage.prototype[EE.captureRejectionSymbol] = function(err, _event) {
  this.destroy(err);
};
ObjectDefineProperty(OutgoingMessage.prototype, "_headers", {
  __proto__: null,
  get: deprecate(function() {
    return this.getHeaders();
  }, "OutgoingMessage.prototype._headers is deprecated", "DEP0066"),
  set: deprecate(function(val) {
    if (val == null)
      this[kOutHeaders] = null;
    else if (typeof val === "object") {
      let headers = this[kOutHeaders] = { __proto__: null }, keys = ObjectKeys(val);
      for (let i = 0;i < keys.length; ++i) {
        let name = keys[i];
        headers[name.toLowerCase()] = [name, val[name]];
      }
    }
  }, "OutgoingMessage.prototype._headers is deprecated", "DEP0066")
});
ObjectDefineProperty(OutgoingMessage.prototype, "headers", {
  __proto__: null,
  get() {
    return this.getHeaders();
  },
  set(val) {
    if (val == null)
      this[kOutHeaders] = null;
    else if (typeof val === "object") {
      this[kOutHeaders] = { __proto__: null };
      let keys = ObjectKeys(val);
      for (let i = 0;i < keys.length; ++i) {
        let name = keys[i];
        this.setHeader(name, val[name]);
      }
    }
  }
});
ObjectDefineProperty(OutgoingMessage.prototype, "_headerNames", {
  __proto__: null,
  get: deprecate(function() {
    let headers = this[kOutHeaders];
    if (headers !== null) {
      let out = { __proto__: null }, keys = ObjectKeys(headers);
      for (let i = 0;i < keys.length; ++i) {
        let key = keys[i], val = headers[key][0];
        out[key] = val;
      }
      return out;
    }
    return null;
  }, "OutgoingMessage.prototype._headerNames is deprecated", "DEP0066"),
  set: deprecate(function(val) {
    if (typeof val === "object" && val !== null) {
      let headers = this[kOutHeaders];
      if (!headers)
        return;
      let keys = ObjectKeys(val);
      for (let i = 0;i < keys.length; ++i) {
        let header = headers[keys[i]];
        if (header)
          header[0] = val[keys[i]];
      }
    }
  }, "OutgoingMessage.prototype._headerNames is deprecated", "DEP0066")
});
$ = {
  kHighWaterMark,
  kUniqueHeaders,
  kOutHeaders,
  kErrored,
  kSocket,
  kRejectNonStandardBodyWrites,
  parseUniqueHeadersOption,
  validateHeaderName,
  validateHeaderValue,
  OutgoingMessage,
  FakeSocket
};
return $

})
