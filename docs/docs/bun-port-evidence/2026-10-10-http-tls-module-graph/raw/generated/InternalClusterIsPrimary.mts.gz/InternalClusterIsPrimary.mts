var $;
// tiny module to shortcut getting access to this boolean without loading the entire node:cluster module
$ = {
  isPrimary: Bun.env.NODE_UNIQUE_ID == null,
};
;$$EXPORT$$($).$$EXPORT_END$$;
