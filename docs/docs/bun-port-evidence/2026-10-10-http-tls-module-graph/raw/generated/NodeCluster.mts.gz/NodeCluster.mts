var $;
// Hardcoded module "node:cluster"

const { isPrimary } = (__intrinsic__getInternalField(__intrinsic__internalModuleRegistry, 15) || __intrinsic__createInternalModuleById(15));
const cluster = isPrimary ? (__intrinsic__getInternalField(__intrinsic__internalModuleRegistry, 16) || __intrinsic__createInternalModuleById(16)) : (__intrinsic__getInternalField(__intrinsic__internalModuleRegistry, 14) || __intrinsic__createInternalModuleById(14));
$ = cluster;

//
//

function initializeClusterIPC() {
  if (process.argv[1] && process.env.NODE_UNIQUE_ID) {
    cluster._setupWorker();
    // Make sure it's not accidentally inherited by child processes.
    delete process.env.NODE_UNIQUE_ID;
  }
}

if (Bun.isMainThread) {
  initializeClusterIPC();
}
;$$EXPORT$$($).$$EXPORT_END$$;
