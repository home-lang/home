(function () {"use strict";
// zig-out/http-tls-graph-port-2026-10-10/generated/InternalStreamsPassthrough.mts
var $, Transform = @getInternalField(@internalModuleRegistry, 75) || @createInternalModuleById(75);
function PassThrough(options) {
  if (!(this instanceof PassThrough))
    return new PassThrough(options);
  Transform.@call(this, options);
}
@toClass(PassThrough, "PassThrough", Transform);
PassThrough.prototype._transform = function(chunk, encoding, cb) {
  cb(null, chunk);
};
$ = PassThrough;
return $

})
