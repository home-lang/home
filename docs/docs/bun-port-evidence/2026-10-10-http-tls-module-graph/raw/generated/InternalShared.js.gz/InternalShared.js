(function () {"use strict";
// zig-out/http-tls-graph-port-2026-10-10/generated/InternalShared.mts
var $, { SafeArrayIterator } = @getInternalField(@internalModuleRegistry, 36) || @createInternalModuleById(36), ObjectFreeze = Object.freeze;

class NotImplementedError extends Error {
  code;
  constructor(feature, issue, extra) {
    super(feature + " is not yet implemented in Bun." + (issue ? " Track the status & thumbs up the issue: https://github.com/oven-sh/bun/issues/" + issue : "") + (extra ? ". " + extra : ""));
    this.name = "NotImplementedError", this.code = "ERR_NOT_IMPLEMENTED", hideFromStack(NotImplementedError);
  }
  get ["constructor"]() {
    return Error;
  }
}
function throwNotImplemented(feature, issue, extra) {
  throw hideFromStack(throwNotImplemented), new NotImplementedError(feature, issue, extra);
}
function hideFromStack(...fns) {
  for (let fn of fns)
    Object.defineProperty(fn, "name", {
      value: "::bunternal::"
    });
}
var warned;
function warnNotImplementedOnce(feature, issue) {
  if (!warned)
    warned = /* @__PURE__ */ new Set;
  if (warned.has(feature))
    return;
  warned.add(feature), console.warn(new NotImplementedError(feature, issue));
}
var util;

class ExceptionWithHostPort extends Error {
  errno;
  syscall;
  port;
  address;
  constructor(err, syscall, address, port) {
    util ??= @getInternalField(@internalModuleRegistry, 145) || @createInternalModuleById(145);
    let code = util.getSystemErrorName(err), details = "";
    if (port && port > 0)
      details = ` ${address}:${port}`;
    else if (address)
      details = ` ${address}`;
    super(`${syscall} ${code}${details}`);
    if (this.errno = err, this.code = code, this.syscall = syscall, this.address = address, port)
      this.port = port;
  }
  get ["constructor"]() {
    return Error;
  }
}

class NodeAggregateError extends AggregateError {
  constructor(errors, message) {
    super(new SafeArrayIterator(errors), message);
    this.code = errors[0]?.code;
  }
  get ["constructor"]() {
    return AggregateError;
  }
}

class ConnResetException extends Error {
  constructor(msg) {
    super(msg);
    this.code = "ECONNRESET";
  }
  get ["constructor"]() {
    return Error;
  }
}

class ErrnoException extends Error {
  errno;
  syscall;
  constructor(err, syscall, original) {
    util ??= @getInternalField(@internalModuleRegistry, 145) || @createInternalModuleById(145);
    let code = util.getSystemErrorName(err), message = original ? `${syscall} ${code} ${original}` : `${syscall} ${code}`;
    super(message);
    this.errno = err, this.code = code, this.syscall = syscall;
  }
  get ["constructor"]() {
    return Error;
  }
}
function once(callback, { preserveReturnValue = !1 } = kEmptyObject) {
  let called = !1, returnValue;
  return function(...args) {
    if (called)
      return returnValue;
    called = !0;
    let result = callback.@apply(this, args);
    return returnValue = preserveReturnValue ? result : @undefined, result;
  };
}
var kEmptyObject = ObjectFreeze(Object.create(null));
function getLazy(initializer) {
  let value, initialized = !1;
  return function() {
    if (initialized)
      return value;
    return value = initializer(), initialized = !0, value;
  };
}
var observerCounts = /* @__PURE__ */ new Map, kObservers = /* @__PURE__ */ new Set, kNodeEntryTypes = /* @__PURE__ */ new Set(["net", "dns", "http"]);
function hasObserver(type) {
  return (observerCounts.get(type) ?? 0) > 0;
}
function startPerf(target, key, context) {
  context.startTime = performance.now(), target[key] = context;
}
function stopPerf(target, key, context) {
  let ctx = target[key];
  if (!ctx)
    return;
  target[key] = @undefined;
  let startTime = ctx.startTime, entry = {
    name: ctx.name,
    entryType: ctx.type,
    startTime,
    duration: performance.now() - startTime,
    detail: ctx.detail !== @undefined || context?.detail !== @undefined ? { ...ctx.detail, ...context?.detail } : @undefined
  };
  for (let observer of kObservers)
    observer.bufferEntry(entry);
}

class NodeEntryObserver {
  callback;
  owner;
  types = /* @__PURE__ */ new Set;
  buffer = [];
  scheduled = !1;
  constructor(callback, owner) {
    this.callback = callback, this.owner = owner;
  }
  observe(types) {
    for (let type of this.types)
      observerCounts.set(type, (observerCounts.get(type) ?? 1) - 1);
    this.types = new Set(types);
    for (let type of this.types)
      observerCounts.set(type, (observerCounts.get(type) ?? 0) + 1);
    kObservers.add(this);
  }
  disconnect() {
    for (let type of this.types)
      observerCounts.set(type, (observerCounts.get(type) ?? 1) - 1);
    this.types.clear(), this.buffer = [], kObservers.delete(this);
  }
  bufferEntry(entry) {
    if (!this.types.has(entry.entryType))
      return;
    if (this.buffer.push(entry), !this.scheduled)
      this.scheduled = !0, setImmediate(() => {
        this.scheduled = !1;
        let entries = this.buffer;
        if (entries.length === 0)
          return;
        this.buffer = [], this.callback.@call(@undefined, makeNodeEntryList(entries), this.owner);
      });
  }
}
function makeNodeEntryList(entries) {
  let sorted = entries.slice().sort((a, b) => a.startTime - b.startTime);
  return {
    getEntries() {
      return sorted.slice();
    },
    getEntriesByType(type) {
      return sorted.filter((entry) => entry.entryType === type);
    },
    getEntriesByName(name, type) {
      return sorted.filter((entry) => entry.name === name && (type === @undefined || entry.entryType === type));
    }
  };
}
$ = {
  NotImplementedError,
  throwNotImplemented,
  hideFromStack,
  warnNotImplementedOnce,
  ExceptionWithHostPort,
  NodeAggregateError,
  ConnResetException,
  ErrnoException,
  once,
  getLazy,
  hasObserver,
  startPerf,
  stopPerf,
  kNodeEntryTypes,
  NodeEntryObserver,
  kHandle: Symbol("kHandle"),
  kAutoDestroyed: Symbol("kAutoDestroyed"),
  kResistStopPropagation: Symbol("kResistStopPropagation"),
  kWeakHandler: Symbol("kWeak"),
  kGetNativeReadableProto: Symbol("kGetNativeReadableProto"),
  kEmptyObject
};
return $

})
