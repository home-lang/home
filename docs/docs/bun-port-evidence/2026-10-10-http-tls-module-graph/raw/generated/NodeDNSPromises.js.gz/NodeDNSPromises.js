(function () {"use strict";
// zig-out/http-tls-graph-port-2026-10-10/generated/NodeDNSPromises.mts
var $;
$ = (@getInternalField(@internalModuleRegistry, 112) || @createInternalModuleById(112)).promises;
return $

})
