(function () {"use strict";
// zig-out/http-tls-graph-port-2026-10-10/generated/NodeStreamPromises.mts
var $;
$ = (@getInternalField(@internalModuleRegistry, 136) || @createInternalModuleById(136)).promises;
return $

})
