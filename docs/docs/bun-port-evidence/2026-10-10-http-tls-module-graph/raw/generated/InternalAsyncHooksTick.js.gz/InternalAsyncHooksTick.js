(function () {"use strict";
// zig-out/http-tls-graph-port-2026-10-10/generated/InternalAsyncHooksTick.mts
var $, tickInitHooks = [], nextAsyncId = 1;
$ = {
  tickInitHooks,
  newAsyncId() {
    return ++nextAsyncId;
  }
};
return $

})
