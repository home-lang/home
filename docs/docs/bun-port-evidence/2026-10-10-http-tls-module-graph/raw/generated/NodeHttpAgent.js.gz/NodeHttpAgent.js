(function () {"use strict";
// zig-out/http-tls-graph-port-2026-10-10/generated/NodeHttpAgent.mts
var $, EventEmitter = @getInternalField(@internalModuleRegistry, 114) || @createInternalModuleById(114), { parseProxyConfigFromEnv, kProxyConfig, checkShouldUseProxy, kWaitForProxyTunnel } = @getInternalField(@internalModuleRegistry, 31) || @createInternalModuleById(31), { getLazy, kEmptyObject, once } = @getInternalField(@internalModuleRegistry, 38) || @createInternalModuleById(38), { validateNumber, validateOneOf, validateString } = @getInternalField(@internalModuleRegistry, 86) || @createInternalModuleById(86), { isIP } = @getInternalField(@internalModuleRegistry, 34) || @createInternalModuleById(34), kOnKeylog = Symbol("onkeylog"), kRequestOptions = Symbol("requestOptions"), kRequestAsyncResource = Symbol("requestAsyncResource"), { AsyncResource } = @getInternalField(@internalModuleRegistry, 104) || @createInternalModuleById(104);
function freeSocketErrorListener(err) {
  let socket = this;
  socket.destroy(), socket.emit("agentRemove");
}
function Agent(options) {
  if (!(this instanceof Agent))
    return new Agent(options);
  if (EventEmitter.@call(this), this.options = { __proto__: null, ...options }, this.defaultPort = this.options.defaultPort || 80, this.protocol = this.options.protocol || "http:", this.options.noDelay === @undefined)
    this.options.noDelay = !0;
  this.options.path = null, this.requests = { __proto__: null }, this.sockets = { __proto__: null }, this.freeSockets = { __proto__: null }, this.keepAliveMsecs = this.options.keepAliveMsecs || 1000, this.keepAlive = this.options.keepAlive || !1, this.maxSockets = this.options.maxSockets || Agent.defaultMaxSockets, this.maxFreeSockets = this.options.maxFreeSockets || 256, this.scheduling = this.options.scheduling || "lifo", this.maxTotalSockets = this.options.maxTotalSockets, this.totalSocketCount = 0, this.agentKeepAliveTimeoutBuffer = typeof this.options.agentKeepAliveTimeoutBuffer === "number" && this.options.agentKeepAliveTimeoutBuffer >= 0 && Number.isFinite(this.options.agentKeepAliveTimeoutBuffer) ? this.options.agentKeepAliveTimeoutBuffer : 1000;
  let proxyEnv = this.options.proxyEnv;
  if (typeof proxyEnv === "object" && proxyEnv !== null)
    this[kProxyConfig] = parseProxyConfigFromEnv(proxyEnv, this.protocol, this.keepAlive);
  validateOneOf(this.scheduling, "scheduling", ["fifo", "lifo"]);
  let maxTotalSockets = this.maxTotalSockets;
  if (maxTotalSockets !== @undefined)
    validateNumber(maxTotalSockets, "maxTotalSockets", 1);
  else
    this.maxTotalSockets = @Infinity;
  this.on("free", (socket, options2) => {
    let name = this.getName(options2);
    if (!socket.writable) {
      socket.destroy();
      return;
    }
    let requests = this.requests[name];
    if (requests?.length) {
      let req2 = requests.shift(), reqAsyncRes = req2[kRequestAsyncResource];
      if (reqAsyncRes)
        reqAsyncRes.runInAsyncScope(setRequestSocket, @undefined, this, req2, socket), req2[kRequestAsyncResource] = null;
      else
        setRequestSocket(this, req2, socket);
      if (requests.length === 0)
        delete this.requests[name];
      return;
    }
    let req = socket._httpMessage;
    if (!req || !req.shouldKeepAlive || !this.keepAlive) {
      socket.destroy();
      return;
    }
    let freeSockets = this.freeSockets[name] || [], freeLen = freeSockets.length, count = freeLen, namedSockets = this.sockets[name];
    if (namedSockets)
      count += namedSockets.length;
    if (this.totalSocketCount > this.maxTotalSockets || count > this.maxSockets || freeLen >= this.maxFreeSockets || !this.keepSocketAlive(socket)) {
      socket.destroy();
      return;
    }
    this.freeSockets[name] = freeSockets, socket._httpMessage = null, this.removeSocket(socket, options2), socket.once("error", freeSocketErrorListener), freeSockets.push(socket);
  }), this.on("newListener", maybeEnableKeylog);
}
@toClass(Agent, "Agent", EventEmitter);
function maybeEnableKeylog(eventName) {
  if (eventName === "keylog") {
    this.removeListener("newListener", maybeEnableKeylog);
    let agent = this;
    this[kOnKeylog] = function onkeylog(keylog) {
      agent.emit("keylog", keylog, this);
    };
    for (let socket of Object.values(this.sockets).flat())
      socket.on("keylog", this[kOnKeylog]);
  }
}
var tls = getLazy(() => @getInternalField(@internalModuleRegistry, 141) || @createInternalModuleById(141)), net = getLazy(() => @getInternalField(@internalModuleRegistry, 122) || @createInternalModuleById(122));
Agent.defaultMaxSockets = @Infinity;
Agent.prototype.createConnection = function createConnection(...args) {
  let normalized = net()._normalizeArgs(args), options = normalized[0], cb = normalized[1];
  if (!checkShouldUseProxy(this[kProxyConfig], options))
    return net().createConnection(...args);
  let connectOptions = {
    ...this[kProxyConfig].proxyConnectionOptions
  }, proxyProtocol = this[kProxyConfig].protocol;
  if (proxyProtocol === "http:")
    return net().connect(connectOptions, cb);
  else if (proxyProtocol === "https:")
    return tls().connect(connectOptions, cb);
};
Agent.prototype.getName = function getName(options = kEmptyObject) {
  let { host, port, localAddress, family, socketPath } = options, name = host || "localhost";
  if (name += ":", port)
    name += port;
  if (name += ":", localAddress)
    name += localAddress;
  if (family === 4 || family === 6)
    name += `:${family}`;
  if (socketPath)
    name += `:${socketPath}`;
  return name;
};
function handleSocketAfterProxy(err, req) {
  if (err.code === "ERR_PROXY_TUNNEL") {
    if (err.proxyTunnelTimeout)
      req.emit("timeout");
    req.emit("error", err);
  }
}
Agent.prototype.addRequest = function addRequest(req, options, port, localAddress) {
  if (typeof options === "string")
    options = {
      __proto__: null,
      host: options,
      port,
      localAddress
    };
  options = { __proto__: null, ...options, ...this.options };
  let socketPath = options.socketPath;
  if (socketPath)
    options.path = socketPath;
  normalizeServerName(options, req);
  let name = this.getName(options);
  this.sockets[name] ||= [];
  let freeSockets = this.freeSockets[name], socket;
  if (freeSockets) {
    while (freeSockets.length && freeSockets[0].destroyed)
      freeSockets.shift();
    if (socket = this.scheduling === "fifo" ? freeSockets.shift() : freeSockets.pop(), !freeSockets.length)
      delete this.freeSockets[name];
  }
  let sockLen = (freeSockets ? freeSockets.length : 0) + this.sockets[name].length;
  if (socket)
    this.reuseSocket(socket, req), setRequestSocket(this, req, socket), this.sockets[name].push(socket);
  else if (sockLen < this.maxSockets && this.totalSocketCount < this.maxTotalSockets)
    this.createSocket(req, options, onSocketCreated.bind(this, req));
  else
    this.requests[name] ||= [], req[kRequestOptions] = options, req[kRequestAsyncResource] = new AsyncResource("QueuedRequest"), this.requests[name].push(req);
};
Agent.prototype.createSocket = function createSocket(req, options, cb) {
  options = { __proto__: null, ...options, ...this.options };
  let socketPath = options.socketPath;
  if (socketPath)
    options.path = socketPath;
  normalizeServerName(options, req);
  let timeout = req.timeout || this.options.timeout || @undefined;
  if (timeout)
    options.timeout = timeout;
  let name = this.getName(options);
  options._agentKey = name, options.encoding = null;
  let oncreate = once((err, s) => {
    if (err)
      return cb(err, s);
    this.sockets[name] ||= [], this.sockets[name].push(s), this.totalSocketCount++, installListeners(this, s, options), cb(null, s);
  }), keepAlive = this.keepAlive;
  if (keepAlive)
    options.keepAlive = keepAlive, options.keepAliveInitialDelay = this.keepAliveMsecs;
  let newSocket = this.createConnection(options, oncreate);
  if (newSocket && !newSocket[kWaitForProxyTunnel])
    oncreate(null, newSocket);
};
function normalizeServerName(options, req) {
  if (!options.servername && options.servername !== "")
    options.servername = calculateServerName(options, req);
}
function calculateServerName(options, req) {
  let servername = options.host, hostHeader = req.getHeader("host");
  if (hostHeader)
    if (validateString(hostHeader, "options.headers.host"), hostHeader[0] === "[") {
      let index = hostHeader.indexOf("]");
      if (index === -1)
        servername = hostHeader;
      else
        servername = hostHeader.substring(1, index);
    } else
      servername = hostHeader.split(":", 1)[0];
  if (isIP(servername))
    servername = "";
  return servername;
}
function installListeners(agent, s, options) {
  function onFree() {
    agent.emit("free", s, options);
  }
  s.on("free", onFree);
  function onClose() {
    agent.totalSocketCount--, agent.removeSocket(s, options);
  }
  s.on("close", onClose);
  function onTimeout() {
    let sockets = agent.freeSockets;
    if (Object.keys(sockets).some((name) => sockets[name].includes(s)))
      return s.destroy();
  }
  s.on("timeout", onTimeout);
  function onRemove() {
    agent.totalSocketCount--, agent.removeSocket(s, options), s.removeListener("close", onClose), s.removeListener("free", onFree), s.removeListener("timeout", onTimeout), s.removeListener("agentRemove", onRemove);
  }
  if (s.on("agentRemove", onRemove), agent[kOnKeylog])
    s.on("keylog", agent[kOnKeylog]);
}
Agent.prototype.removeSocket = function removeSocket(s, options) {
  let name = this.getName(options), sets = [this.sockets];
  if (!s.writable)
    sets.push(this.freeSockets);
  for (let sk = 0;sk < sets.length; sk++) {
    let sockets = sets[sk], socket = sockets[name];
    if (socket) {
      let index = socket.indexOf(s);
      if (index !== -1) {
        if (socket.splice(index, 1), socket.length === 0)
          delete sockets[name];
      }
    }
  }
  let req, requests = this.requests;
  if (requests[name]?.length)
    req = requests[name][0];
  else {
    let keys = Object.keys(requests);
    for (let i = 0;i < keys.length; i++) {
      let prop = keys[i];
      if (this.sockets[prop]?.length)
        break;
      req = this.requests[prop][0], options = req[kRequestOptions];
      break;
    }
  }
  if (req && options)
    req[kRequestOptions] = @undefined, this.createSocket(req, options, onSocketCreatedForPending.bind(@undefined, req));
};
function onSocketCreated(req, err, socket) {
  if (err) {
    handleSocketAfterProxy(err, req), req.onSocket(socket, err);
    return;
  }
  setRequestSocket(this, req, socket);
}
function onSocketCreatedForPending(req, err, socket) {
  if (err) {
    handleSocketAfterProxy(err, req), req.onSocket(socket ?? null, err);
    return;
  }
  socket.emit("free");
}
Agent.prototype.keepSocketAlive = function keepSocketAlive(socket) {
  socket.setKeepAlive(!0, this.keepAliveMsecs), socket.unref();
  let agentTimeout = this.options.timeout || 0, canKeepSocketAlive = !0, res = socket._httpMessage?.res;
  if (res) {
    let keepAliveHint = res.headers["keep-alive"];
    if (keepAliveHint) {
      let hint = /^timeout=(\d+)/.exec(keepAliveHint)?.[1];
      if (hint) {
        let serverHintTimeout = Number.parseInt(hint) * 1000 - this.agentKeepAliveTimeoutBuffer;
        if (serverHintTimeout = serverHintTimeout > 0 ? serverHintTimeout : 0, serverHintTimeout === 0)
          canKeepSocketAlive = !1;
        else if (serverHintTimeout < agentTimeout)
          agentTimeout = serverHintTimeout;
      }
    }
  }
  if (socket.timeout !== agentTimeout)
    socket.setTimeout(agentTimeout);
  return canKeepSocketAlive;
};
Agent.prototype.reuseSocket = function reuseSocket(socket, req) {
  socket.removeListener("error", freeSocketErrorListener), req.reusedSocket = !0, socket.ref();
};
Agent.prototype.destroy = function destroy() {
  let sets = [this.freeSockets, this.sockets];
  for (let s = 0;s < sets.length; s++) {
    let set = sets[s], keys = Object.keys(set);
    for (let v = 0;v < keys.length; v++) {
      let setName = set[keys[v]];
      for (let n = 0;n < setName.length; n++)
        setName[n].destroy();
    }
  }
};
function setRequestSocket(agent, req, socket) {
  req.onSocket(socket);
  let agentTimeout = agent.options.timeout || 0;
  if (req.timeout === @undefined || req.timeout === agentTimeout)
    return;
  socket.setTimeout(req.timeout);
}
function shouldUseEnvProxy() {
  let value = process.env.NODE_USE_ENV_PROXY;
  if (Boolean(value) === !1 || value === "0")
    return !1;
  let httpProxy = process.env.http_proxy || process.env.HTTP_PROXY, httpsProxy = process.env.https_proxy || process.env.HTTPS_PROXY;
  if (httpProxy && URL.canParse(httpProxy) === !1)
    throw @makeErrorWithCode(143, httpProxy);
  if (httpsProxy && URL.canParse(httpsProxy) === !1)
    throw @makeErrorWithCode(143, httpsProxy);
  return !0;
}
$ = {
  Agent,
  globalAgent: new Agent({
    keepAlive: !0,
    scheduling: "lifo",
    timeout: 5000,
    proxyEnv: shouldUseEnvProxy() ? process.env : @undefined
  }),
  shouldUseEnvProxy
};
return $

})
