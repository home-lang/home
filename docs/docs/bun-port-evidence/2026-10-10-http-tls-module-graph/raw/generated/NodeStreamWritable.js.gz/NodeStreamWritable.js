(function () {"use strict";
// zig-out/http-tls-graph-port-2026-10-10/generated/NodeStreamWritable.mts
var $;
$ = @getInternalField(@internalModuleRegistry, 77) || @createInternalModuleById(77);
return $

})
