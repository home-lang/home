(function () {"use strict";
// zig-out/http-tls-graph-port-2026-10-10/generated/NodeStreamTransform.mts
var $;
$ = @getInternalField(@internalModuleRegistry, 75) || @createInternalModuleById(75);
return $

})
