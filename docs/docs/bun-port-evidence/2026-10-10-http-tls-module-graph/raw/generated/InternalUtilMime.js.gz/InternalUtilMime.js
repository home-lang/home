(function () {"use strict";
// zig-out/http-tls-graph-port-2026-10-10/generated/InternalUtilMime.mts
var $, { MIMEParams, MIMEType } = @lazy(26);
$ = {
  MIMEParams,
  MIMEType
};
return $

})
