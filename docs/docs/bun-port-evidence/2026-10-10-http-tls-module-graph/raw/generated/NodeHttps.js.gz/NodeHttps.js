(function () {"use strict";
// zig-out/http-tls-graph-port-2026-10-10/generated/NodeHttps.mts
var $, http = @getInternalField(@internalModuleRegistry, 117) || @createInternalModuleById(117), tls = @getInternalField(@internalModuleRegistry, 141) || @createInternalModuleById(141), { isIP } = @getInternalField(@internalModuleRegistry, 122) || @createInternalModuleById(122), net = @getInternalField(@internalModuleRegistry, 122) || @createInternalModuleById(122), { urlToHttpOptions } = @getInternalField(@internalModuleRegistry, 81) || @createInternalModuleById(81), { kEmptyObject, once } = @getInternalField(@internalModuleRegistry, 38) || @createInternalModuleById(38), { kProxyConfig, checkShouldUseProxy, kWaitForProxyTunnel } = @getInternalField(@internalModuleRegistry, 31) || @createInternalModuleById(31), ArrayPrototypeShift = @Array.prototype.shift, ObjectAssign = Object.assign, ArrayPrototypeUnshift = @Array.prototype.unshift, JSONStringify = JSON.stringify;
function request(...args) {
  let options = {};
  if (typeof args[0] === "string") {
    let urlStr = ArrayPrototypeShift.@call(args);
    options = urlToHttpOptions(new URL(urlStr));
  } else if (args[0] instanceof URL)
    options = urlToHttpOptions(ArrayPrototypeShift.@call(args));
  if (args[0] && typeof args[0] !== "function")
    ObjectAssign.@call(null, options, ArrayPrototypeShift.@call(args));
  return options._defaultAgent = https.globalAgent, ArrayPrototypeUnshift.@call(args, options), new http.ClientRequest(...args);
}
function get(input, options, cb) {
  let req = request(input, options, cb);
  return req.end(), req;
}
function getTunnelConfigForProxiedHttps(agent, reqOptions) {
  if (agent[kProxyConfig] === @undefined || agent[kProxyConfig] === null)
    return null;
  if ((reqOptions.protocol || agent.protocol) !== "https:")
    return null;
  let shouldUseProxy = checkShouldUseProxy(agent[kProxyConfig], reqOptions);
  if (shouldUseProxy === !1 || shouldUseProxy === null || shouldUseProxy === @undefined)
    return null;
  let { auth } = agent[kProxyConfig], ipType = isIP(reqOptions.host), requestHost = ipType === 6 ? `[${reqOptions.host}]` : reqOptions.host, requestPort = reqOptions.port || agent.defaultPort, endpoint = `${requestHost}:${requestPort}`, payload = `CONNECT ${endpoint} HTTP/1.1\r
`;
  if (auth)
    payload += `proxy-authorization: ${auth}\r
`;
  if (agent.keepAlive || agent.maxSockets !== @Infinity)
    payload += `proxy-connection: keep-alive\r
`;
  return payload += `host: ${endpoint}`, payload += `\r
\r
`, {
    __proto__: null,
    proxyTunnelPayload: payload,
    requestOptions: {
      __proto__: null,
      servername: reqOptions.servername || (ipType ? @undefined : reqOptions.host),
      ...reqOptions
    }
  };
}
function establishTunnel(agent, socket, options, tunnelConfig, afterSocket) {
  let { proxyTunnelPayload } = tunnelConfig, tunnelDone = !1;
  function read() {
    let chunk;
    while (tunnelDone === !1 && (chunk = socket.read()) !== null)
      if (onProxyData(chunk) !== -1)
        break;
    if (tunnelDone === !1)
      socket.once("readable", read);
  }
  function cleanup() {
    tunnelDone = !0, socket.removeListener("end", onProxyEnd), socket.removeListener("error", onProxyError), socket.removeListener("readable", read), socket.setTimeout(0);
  }
  function onProxyError(err) {
    cleanup(), afterSocket(err, socket);
  }
  let buffer = "";
  function onProxyData(chunk) {
    let str = chunk.toString();
    buffer += str;
    let headerEndIndex = buffer.indexOf(`\r
\r
`);
    if (headerEndIndex === -1)
      return headerEndIndex;
    let statusLine = buffer.substring(0, buffer.indexOf(`\r
`)), statusCode = statusLine.split(" ")[1];
    if (statusCode !== "200") {
      cleanup();
      let message = `Failed to establish tunnel to ${proxyTunnelPayload.split("\r")[0].split(" ")[1]} via ${agent[kProxyConfig].href}: ${statusLine}`, err = @makeErrorWithCode(324, message);
      err.statusCode = parseInt(statusCode), afterSocket(err, socket);
    } else {
      let onTLSHandshakeError2 = function(err) {
        afterSocket(err, tunneledSocket);
      }, onTLSHandshakeSuccess2 = function() {
        tunneledSocket.removeListener("error", onTLSHandshakeError2), afterSocket(null, tunneledSocket);
      }, onTunneledSocketFree2 = function() {
        socket.emit("free");
      };
      var onTLSHandshakeError = onTLSHandshakeError2, onTLSHandshakeSuccess = onTLSHandshakeSuccess2, onTunneledSocketFree = onTunneledSocketFree2;
      cleanup();
      let { requestOptions } = tunnelConfig;
      tunnelConfig.requestOptions = null, requestOptions.socket = socket;
      let tunneledSocket;
      tunneledSocket = tls.connect(requestOptions, onTLSHandshakeSuccess2), tunneledSocket.on("free", onTunneledSocketFree2), tunneledSocket.on("error", onTLSHandshakeError2);
      let agentKey = requestOptions._agentKey;
      if (agentKey)
        tunneledSocket.on("session", onSocketSession.bind(agent, agentKey)), tunneledSocket.once("close", onSocketClose.bind(agent, agentKey));
    }
    return headerEndIndex;
  }
  function onProxyEnd() {
    cleanup();
    let err = @makeErrorWithCode(324, "Connection to establish proxy tunnel ended unexpectedly");
    afterSocket(err, socket);
  }
  let proxyTunnelTimeout = tunnelConfig.requestOptions.timeout;
  function onProxyTimeout() {
    cleanup();
    let err = @makeErrorWithCode(324, `Connection to establish proxy tunnel timed out after ${proxyTunnelTimeout}ms`);
    err.proxyTunnelTimeout = proxyTunnelTimeout, afterSocket(err, socket);
  }
  if (proxyTunnelTimeout && proxyTunnelTimeout > 0)
    socket.setTimeout(proxyTunnelTimeout, onProxyTimeout);
  socket.on("error", onProxyError), socket.on("end", onProxyEnd), socket.write(proxyTunnelPayload), read();
}
function createConnection(...args) {
  let options;
  if (args[0] !== null && typeof args[0] === "object")
    options = args[0];
  else if (args[1] !== null && typeof args[1] === "object")
    options = { ...args[1] };
  else if (args[2] === null || typeof args[2] !== "object")
    options = {};
  else
    options = { ...args[2] };
  if (typeof args[0] === "number")
    options.port = args[0];
  if (typeof args[1] === "string")
    options.host = args[1];
  let cb, lastArg = args[args.length - 1];
  if (typeof lastArg === "function")
    cb = lastArg;
  let agentKey = options._agentKey;
  if (agentKey) {
    let session = this._getSession(agentKey);
    if (session)
      options = {
        session,
        ...options
      };
  }
  let socket, tunnelConfig = getTunnelConfigForProxiedHttps(this, options);
  if (tunnelConfig === null)
    socket = tls.connect(options);
  else {
    let onError2 = function(err) {
      cleanupAndPropagate(err, socket);
    }, onTimeout2 = function() {
      let err = @makeErrorWithCode(324, `Connection to establish proxy tunnel timed out after ${proxyTunnelTimeout}ms`);
      err.proxyTunnelTimeout = proxyTunnelTimeout, cleanupAndPropagate(err, socket);
    }, onProxyConnection2 = function() {
      socket.removeListener("error", onError2), establishTunnel(agent, socket, options, tunnelConfig, cleanupAndPropagate);
    };
    var onError = onError2, onTimeout = onTimeout2, onProxyConnection = onProxyConnection2;
    let connectOptions = {
      ...this[kProxyConfig].proxyConnectionOptions
    }, agent = this, proxyTunnelTimeout = tunnelConfig.requestOptions.timeout, cleanupAndPropagate = once(function cleanupAndPropagateImpl(err, currentSocket) {
      if (socket.removeListener("error", onError2), socket.removeListener("timeout", onTimeout2), err && err.code === "ERR_PROXY_TUNNEL" && err.statusCode === @undefined)
        socket.destroy();
      if (cb)
        cb(err, currentSocket);
    });
    if (this[kProxyConfig].protocol === "http:")
      socket = net.connect(connectOptions, onProxyConnection2);
    else
      socket = tls.connect(connectOptions, onProxyConnection2);
    if (socket.on("error", onError2), proxyTunnelTimeout)
      socket.setTimeout(proxyTunnelTimeout, onTimeout2);
    socket[kWaitForProxyTunnel] = !0;
  }
  if (agentKey && tunnelConfig === null)
    socket.on("session", onSocketSession.bind(this, agentKey)), socket.once("close", onSocketClose.bind(this, agentKey));
  return socket;
}
function onSocketSession(agentKey, session) {
  this._cacheSession(agentKey, session);
}
function onSocketClose(agentKey, err) {
  if (err)
    this._evictSession(agentKey);
}
function Agent(options) {
  if (!(this instanceof Agent))
    return new Agent(options);
  if (options = { __proto__: null, ...options }, options.defaultPort ??= 443, options.protocol ??= "https:", http.Agent.@call(this, options), this.maxCachedSessions = this.options.maxCachedSessions, this.maxCachedSessions === @undefined)
    this.maxCachedSessions = 100;
  this._sessionCache = {
    map: {},
    list: []
  };
}
@toClass(Agent, "Agent", http.Agent);
Agent.prototype.createConnection = createConnection;
Agent.prototype.getName = function getName(options = kEmptyObject) {
  let name = http.Agent.prototype.getName.@call(this, options), {
    ca,
    cert,
    clientCertEngine,
    ciphers,
    key,
    pfx,
    rejectUnauthorized,
    servername,
    host,
    minVersion,
    maxVersion,
    secureProtocol,
    crl,
    honorCipherOrder,
    ecdhCurve,
    dhparam,
    secureOptions,
    sessionIdContext,
    sigalgs,
    privateKeyIdentifier,
    privateKeyEngine
  } = options;
  if (name += ":", ca)
    name += ca;
  if (name += ":", cert)
    name += cert;
  if (name += ":", clientCertEngine)
    name += clientCertEngine;
  if (name += ":", ciphers)
    name += ciphers;
  if (name += ":", key)
    name += key;
  if (name += ":", pfx)
    name += pfx;
  if (name += ":", rejectUnauthorized !== @undefined)
    name += rejectUnauthorized;
  if (name += ":", servername && servername !== host)
    name += servername;
  if (name += ":", minVersion)
    name += minVersion;
  if (name += ":", maxVersion)
    name += maxVersion;
  if (name += ":", secureProtocol)
    name += secureProtocol;
  if (name += ":", crl)
    name += crl;
  if (name += ":", honorCipherOrder !== @undefined)
    name += honorCipherOrder;
  if (name += ":", ecdhCurve)
    name += ecdhCurve;
  if (name += ":", dhparam)
    name += dhparam;
  if (name += ":", secureOptions !== @undefined)
    name += secureOptions;
  if (name += ":", sessionIdContext)
    name += sessionIdContext;
  if (name += ":", sigalgs)
    name += JSONStringify(sigalgs);
  if (name += ":", privateKeyIdentifier)
    name += privateKeyIdentifier;
  if (name += ":", privateKeyEngine)
    name += privateKeyEngine;
  return name;
};
Agent.prototype._getSession = function _getSession(key) {
  return this._sessionCache.map[key];
};
Agent.prototype._cacheSession = function _cacheSession(key, session) {
  if (this.maxCachedSessions === 0)
    return;
  let sessionMap = this._sessionCache.map;
  if (sessionMap[key]) {
    sessionMap[key] = session;
    return;
  }
  if (this._sessionCache.list.length >= this.maxCachedSessions) {
    let oldKey = this._sessionCache.list.shift();
    delete this._sessionCache.map[oldKey];
  }
  this._sessionCache.list.push(key), this._sessionCache.map[key] = session;
};
Agent.prototype._evictSession = function _evictSession(key) {
  let index = this._sessionCache.list.indexOf(key);
  if (index === -1)
    return;
  this._sessionCache.list.splice(index, 1), delete this._sessionCache.map[key];
};
var { shouldUseEnvProxy } = @getInternalField(@internalModuleRegistry, 89) || @createInternalModuleById(89), https = {
  Agent,
  globalAgent: new Agent({
    keepAlive: !0,
    scheduling: "lifo",
    timeout: 5000,
    proxyEnv: shouldUseEnvProxy() ? process.env : @undefined
  }),
  Server: http.Server,
  createServer: http.createServer,
  get,
  request
};
$ = https;
return $

})
