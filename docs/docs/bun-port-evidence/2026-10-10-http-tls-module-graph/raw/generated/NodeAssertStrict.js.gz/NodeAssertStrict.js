(function () {"use strict";
// zig-out/http-tls-graph-port-2026-10-10/generated/NodeAssertStrict.mts
var $;
$ = (@getInternalField(@internalModuleRegistry, 103) || @createInternalModuleById(103)).strict;
return $

})
