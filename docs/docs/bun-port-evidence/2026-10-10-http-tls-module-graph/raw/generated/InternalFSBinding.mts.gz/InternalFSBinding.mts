var $;
// The native `node:fs` binding (`createBinding`), created once here
// and shared by `node:fs`, `node:fs/promises`, and the lazily loaded `internal/fs/*` modules.
$ = __intrinsic__lazy(9) as __intrinsic__ZigGeneratedClasses.NodeJSFS;
;$$EXPORT$$($).$$EXPORT_END$$;
