(function () {"use strict";
// zig-out/http-tls-graph-port-2026-10-10/generated/InternalFSBinding.mts
var $;
$ = @lazy(9);
return $

})
