(function () {"use strict";
// zig-out/http-tls-graph-port-2026-10-10/generated/NodeHttpIncoming.mts
var $, Readable = @getInternalField(@internalModuleRegistry, 73) || @createInternalModuleById(73), finished = @getInternalField(@internalModuleRegistry, 53) || @createInternalModuleById(53), {
  abortedSymbol,
  eofInProgress,
  kHandle,
  noBodySymbol,
  typeSymbol,
  NodeHTTPIncomingRequestType,
  fakeSocketSymbol,
  emitErrorNextTickIfErrorListenerNT,
  NodeHTTPBodyReadState,
  emitEOFIncomingMessage,
  NodeHTTPResponseAbortEvent,
  setRequestTimeout,
  kAbortController
} = @getInternalField(@internalModuleRegistry, 31) || @createInternalModuleById(31), { FakeSocket } = @getInternalField(@internalModuleRegistry, 32) || @createInternalModuleById(32), ObjectDefineProperty = Object.defineProperty, ArrayPrototypeSlice = @Array.prototype.slice, kHeaders = Symbol("kHeaders"), kHeadersDistinct = Symbol("kHeadersDistinct"), kHeadersCount = Symbol("kHeadersCount"), kTrailers = Symbol("kTrailers"), kTrailersDistinct = Symbol("kTrailersDistinct"), kTrailersCount = Symbol("kTrailersCount");
function readStart(socket) {
  if (socket && !socket._paused && socket.readable)
    socket.resume();
}
function readStop(socket) {
  if (socket)
    socket.pause();
}
function onIncomingMessagePauseNodeHTTPResponse() {
  let handle = this[kHandle];
  if (handle && !this.destroyed)
    handle.pause();
}
function onIncomingMessageResumeNodeHTTPResponse() {
  let handle = this[kHandle];
  if (handle && !this.destroyed) {
    let resumed = handle.resume();
    if (resumed && resumed !== !0) {
      if ((handle.hasBody & NodeHTTPBodyReadState.done) !== 0)
        emitEOFIncomingMessage(this);
      this.push(resumed);
    }
  }
}
function IncomingMessage(socket) {
  if (this[abortedSymbol] = !1, this[eofInProgress] = !1, this._consuming = !1, this._dumped = !1, this.complete = !1, this._closed = !1, this[kHeaders] = null, this[kHeadersCount] = 0, this[kTrailers] = null, this[kTrailersCount] = 0, this.rawTrailers = [], this[kAbortController] = null, socket === kHandle) {
    this[typeSymbol] = NodeHTTPIncomingRequestType.NodeHTTPResponse, this.url = arguments[1], this.method = arguments[2];
    let rawHeaders = arguments[4], maxHeadersCount = arguments[7]?.server?.maxHeadersCount;
    if (typeof maxHeadersCount === "number" && maxHeadersCount > 0 && rawHeaders.length > maxHeadersCount * 2)
      rawHeaders = ArrayPrototypeSlice.@call(rawHeaders, 0, maxHeadersCount * 2);
    if (this.rawHeaders = rawHeaders, this[kHeadersCount] = rawHeaders.length, this[kHandle] = arguments[5], this[noBodySymbol] = !arguments[6], this[fakeSocketSymbol] = arguments[7], this.client = arguments[7], this.upgrade = null, Readable.@call(this), arguments[6])
      this.on("pause", onIncomingMessagePauseNodeHTTPResponse), this.on("resume", onIncomingMessageResumeNodeHTTPResponse);
  } else {
    let streamOptions;
    if (socket)
      streamOptions = {
        highWaterMark: socket.readableHighWaterMark
      };
    Readable.@call(this, streamOptions), this[fakeSocketSymbol] = socket, this.httpVersionMajor = null, this.httpVersionMinor = null, this.httpVersion = null, this.rawHeaders = [], this.joinDuplicateHeaders = !1, this.upgrade = null, this.url = "", this.method = null, this.statusCode = null, this.statusMessage = null, this.client = socket, this[noBodySymbol] = !1;
  }
  this._readableState.readingMore = !0;
}
@toClass(IncomingMessage, "IncomingMessage", Readable);
IncomingMessage.prototype.httpVersion = "1.1";
IncomingMessage.prototype.httpVersionMajor = 1;
IncomingMessage.prototype.httpVersionMinor = 1;
IncomingMessage.prototype.url = "";
IncomingMessage.prototype.method = null;
IncomingMessage.prototype.statusCode = null;
IncomingMessage.prototype.statusMessage = null;
IncomingMessage.prototype.upgrade = null;
IncomingMessage.prototype.joinDuplicateHeaders = !1;
ObjectDefineProperty(IncomingMessage.prototype, "socket", {
  __proto__: null,
  get: function() {
    let socket = this[fakeSocketSymbol];
    if (socket === @undefined && this[typeSymbol] === NodeHTTPIncomingRequestType.NodeHTTPResponse)
      socket = this[fakeSocketSymbol] = new FakeSocket(this);
    return socket;
  },
  set: function(val) {
    this[fakeSocketSymbol] = val;
  }
});
ObjectDefineProperty(IncomingMessage.prototype, "connection", {
  __proto__: null,
  get: function() {
    return this.socket;
  },
  set: function(val) {
    this.socket = val;
  }
});
ObjectDefineProperty(IncomingMessage.prototype, "aborted", {
  __proto__: null,
  get: function() {
    return this[abortedSymbol];
  },
  set: function(val) {
    this[abortedSymbol] = val;
  }
});
ObjectDefineProperty(IncomingMessage.prototype, "headers", {
  __proto__: null,
  get: function() {
    if (!this[kHeaders]) {
      this[kHeaders] = {};
      let src = this.rawHeaders, dst = this[kHeaders];
      for (let n = 0;n < this[kHeadersCount]; n += 2)
        this._addHeaderLine(src[n + 0], src[n + 1], dst);
    }
    return this[kHeaders];
  },
  set: function(val) {
    this[kHeaders] = val;
  }
});
ObjectDefineProperty(IncomingMessage.prototype, "headersDistinct", {
  __proto__: null,
  get: function() {
    if (!this[kHeadersDistinct]) {
      this[kHeadersDistinct] = { __proto__: null };
      let src = this.rawHeaders, dst = this[kHeadersDistinct];
      for (let n = 0;n < this[kHeadersCount]; n += 2)
        this._addHeaderLineDistinct(src[n + 0], src[n + 1], dst);
    }
    return this[kHeadersDistinct];
  },
  set: function(val) {
    this[kHeadersDistinct] = val;
  }
});
ObjectDefineProperty(IncomingMessage.prototype, "trailers", {
  __proto__: null,
  get: function() {
    if (!this[kTrailers]) {
      this[kTrailers] = {};
      let src = this.rawTrailers, dst = this[kTrailers];
      for (let n = 0;n < this[kTrailersCount]; n += 2)
        this._addHeaderLine(src[n + 0], src[n + 1], dst);
    }
    return this[kTrailers];
  },
  set: function(val) {
    this[kTrailers] = val;
  }
});
ObjectDefineProperty(IncomingMessage.prototype, "trailersDistinct", {
  __proto__: null,
  get: function() {
    if (!this[kTrailersDistinct]) {
      this[kTrailersDistinct] = { __proto__: null };
      let src = this.rawTrailers, dst = this[kTrailersDistinct];
      for (let n = 0;n < this[kTrailersCount]; n += 2)
        this._addHeaderLineDistinct(src[n + 0], src[n + 1], dst);
    }
    return this[kTrailersDistinct];
  },
  set: function(val) {
    this[kTrailersDistinct] = val;
  }
});
ObjectDefineProperty(IncomingMessage.prototype, "signal", {
  __proto__: null,
  configurable: !0,
  get: function() {
    if (this[kAbortController] === null) {
      let ac = new AbortController;
      if (this[kAbortController] = ac, this.destroyed)
        ac.abort();
      else
        this.once("close", function() {
          ac.abort();
        });
    }
    return this[kAbortController].signal;
  }
});
IncomingMessage.prototype.setTimeout = function setTimeout(msecs, callback) {
  if (callback)
    this.on("timeout", callback);
  let handle = this[kHandle];
  if (handle)
    setRequestTimeout(handle, Math.ceil(msecs / 1000));
  else
    this.socket?.setTimeout(msecs);
  return this;
};
IncomingMessage.prototype._read = function _read(_n) {
  if (!this._consuming)
    this._readableState.readingMore = !1, this._consuming = !0;
  let handle = this[kHandle];
  if (!handle) {
    let socket2 = this.socket;
    if (socket2 && socket2.readable)
      readStart(socket2);
    return;
  }
  let socket = this.socket;
  if (socket && socket.readable)
    socket.resume();
  if (this[eofInProgress])
    return;
  if (this[noBodySymbol]) {
    emitEOFIncomingMessage(this);
    return;
  }
  let bodyReadState = handle.hasBody;
  if ((bodyReadState & NodeHTTPBodyReadState.done) !== 0 || bodyReadState === NodeHTTPBodyReadState.none || this._dumped)
    emitEOFIncomingMessage(this);
  if ((bodyReadState & NodeHTTPBodyReadState.hasBufferedDataDuringPause) !== 0) {
    let drained = handle.drainRequestBody();
    if (drained && !this._dumped)
      this.push(drained);
  }
  if (!handle.ondata)
    handle.ondata = onDataIncomingMessage.bind(this), handle.hasCustomOnData = !1;
};
function onDataIncomingMessage(chunk, isLast, aborted) {
  if (aborted === NodeHTTPResponseAbortEvent.abort) {
    this.destroy();
    return;
  }
  if (chunk && !this._dumped)
    this.push(chunk);
  if (isLast)
    emitEOFIncomingMessage(this);
}
IncomingMessage.prototype._destroy = function _destroy(err, cb) {
  let shouldEmitAborted = !this.readableEnded || !this.complete;
  if (shouldEmitAborted)
    this[abortedSymbol] = !0, this.emit("aborted");
  let handle = this[kHandle];
  if (handle) {
    if (this[kHandle] = @undefined, handle.onabort = handle.ondata = @undefined, !handle.finished && shouldEmitAborted && this.socket)
      handle.abort();
    let socket2 = this.socket;
    if (socket2 && !socket2.destroyed && shouldEmitAborted)
      socket2.destroy(err);
    if (@isCallable(cb))
      emitErrorNextTickIfErrorListenerNT(this, err, cb);
    return;
  }
  let socket = this.socket;
  if (socket && !socket.destroyed && this.aborted) {
    socket.destroy(err);
    let state = { cleanup: @undefined };
    state.cleanup = finished(socket, onFinishedAfterDestroy.bind(this, state, err, cb));
  } else
    process.nextTick(onError, this, err, cb);
};
function onFinishedAfterDestroy(state, err, cb, e) {
  if (e?.code === "ERR_STREAM_PREMATURE_CLOSE")
    e = null;
  state.cleanup(), process.nextTick(onError, this, e || err, cb);
}
IncomingMessage.prototype._addHeaderLines = _addHeaderLines;
function _addHeaderLines(headers, n) {
  if (headers?.length) {
    let dest;
    if (this.complete)
      this.rawTrailers = headers, this[kTrailersCount] = n, dest = this[kTrailers];
    else
      this.rawHeaders = headers, this[kHeadersCount] = n, dest = this[kHeaders];
    if (dest)
      for (let i = 0;i < n; i += 2)
        this._addHeaderLine(headers[i], headers[i + 1], dest);
  }
}
function matchKnownFields(field, lowercased) {
  switch (field.length) {
    case 3:
      if (field === "Age" || field === "age")
        return "age";
      break;
    case 4:
      if (field === "Host" || field === "host")
        return "host";
      if (field === "From" || field === "from")
        return "from";
      if (field === "ETag" || field === "etag")
        return "etag";
      if (field === "Date" || field === "date")
        return "\x00date";
      if (field === "Vary" || field === "vary")
        return "\x00vary";
      break;
    case 6:
      if (field === "Server" || field === "server")
        return "server";
      if (field === "Cookie" || field === "cookie")
        return "\x02cookie";
      if (field === "Origin" || field === "origin")
        return "\x00origin";
      if (field === "Expect" || field === "expect")
        return "\x00expect";
      if (field === "Accept" || field === "accept")
        return "\x00accept";
      break;
    case 7:
      if (field === "Referer" || field === "referer")
        return "referer";
      if (field === "Expires" || field === "expires")
        return "expires";
      if (field === "Upgrade" || field === "upgrade")
        return "\x00upgrade";
      break;
    case 8:
      if (field === "Location" || field === "location")
        return "location";
      if (field === "If-Match" || field === "if-match")
        return "\x00if-match";
      break;
    case 10:
      if (field === "User-Agent" || field === "user-agent")
        return "user-agent";
      if (field === "Set-Cookie" || field === "set-cookie")
        return "\x01";
      if (field === "Connection" || field === "connection")
        return "\x00connection";
      break;
    case 11:
      if (field === "Retry-After" || field === "retry-after")
        return "retry-after";
      break;
    case 12:
      if (field === "Content-Type" || field === "content-type")
        return "content-type";
      if (field === "Max-Forwards" || field === "max-forwards")
        return "max-forwards";
      break;
    case 13:
      if (field === "Authorization" || field === "authorization")
        return "authorization";
      if (field === "Last-Modified" || field === "last-modified")
        return "last-modified";
      if (field === "Cache-Control" || field === "cache-control")
        return "\x00cache-control";
      if (field === "If-None-Match" || field === "if-none-match")
        return "\x00if-none-match";
      break;
    case 14:
      if (field === "Content-Length" || field === "content-length")
        return "content-length";
      break;
    case 15:
      if (field === "Accept-Encoding" || field === "accept-encoding")
        return "\x00accept-encoding";
      if (field === "Accept-Language" || field === "accept-language")
        return "\x00accept-language";
      if (field === "X-Forwarded-For" || field === "x-forwarded-for")
        return "\x00x-forwarded-for";
      break;
    case 16:
      if (field === "Content-Encoding" || field === "content-encoding")
        return "\x00content-encoding";
      if (field === "X-Forwarded-Host" || field === "x-forwarded-host")
        return "\x00x-forwarded-host";
      break;
    case 17:
      if (field === "If-Modified-Since" || field === "if-modified-since")
        return "if-modified-since";
      if (field === "Transfer-Encoding" || field === "transfer-encoding")
        return "\x00transfer-encoding";
      if (field === "X-Forwarded-Proto" || field === "x-forwarded-proto")
        return "\x00x-forwarded-proto";
      break;
    case 19:
      if (field === "Proxy-Authorization" || field === "proxy-authorization")
        return "proxy-authorization";
      if (field === "If-Unmodified-Since" || field === "if-unmodified-since")
        return "if-unmodified-since";
      break;
  }
  if (lowercased)
    return "\x00" + field;
  return matchKnownFields(field.toLowerCase(), !0);
}
IncomingMessage.prototype._addHeaderLine = _addHeaderLine;
function _addHeaderLine(field, value, dest) {
  field = matchKnownFields(field);
  let flag = field.charCodeAt(0);
  if (flag === 0 || flag === 2)
    if (field = field.slice(1), typeof dest[field] === "string")
      dest[field] += (flag === 0 ? ", " : "; ") + value;
    else
      dest[field] = value;
  else if (flag === 1)
    if (dest["set-cookie"] !== @undefined)
      dest["set-cookie"].push(value);
    else
      dest["set-cookie"] = [value];
  else if (this.joinDuplicateHeaders)
    if (dest[field] === @undefined)
      dest[field] = value;
    else
      dest[field] += ", " + value;
  else if (dest[field] === @undefined)
    dest[field] = value;
}
IncomingMessage.prototype._addHeaderLineDistinct = _addHeaderLineDistinct;
function _addHeaderLineDistinct(field, value, dest) {
  if (field = field.toLowerCase(), !dest[field])
    dest[field] = [value];
  else
    dest[field].push(value);
}
IncomingMessage.prototype._dumpAndCloseReadable = function _dumpAndCloseReadable() {
  this._dumped = !0, this._readableState.ended = !0, this._readableState.endEmitted = !0, this._readableState.destroyed = !0, this._readableState.closed = !0, this._readableState.closeEmitted = !0;
};
IncomingMessage.prototype._dump = function _dump() {
  if (!this._dumped) {
    this._dumped = !0, this.removeAllListeners("data");
    let handle = this[kHandle];
    if (handle)
      handle.ondata = @undefined;
    this.resume();
  }
};
function onError(self, error, cb) {
  if (self.listenerCount("error") === 0)
    cb();
  else
    cb(error);
}

$ = {"readStop": readStop, "readStart": readStart, "IncomingMessage": IncomingMessage};
return $
})
