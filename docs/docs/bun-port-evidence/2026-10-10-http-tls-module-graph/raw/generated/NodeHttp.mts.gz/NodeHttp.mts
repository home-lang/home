var $;
const { validateInteger, validateObject } = (__intrinsic__getInternalField(__intrinsic__internalModuleRegistry, 86) || __intrinsic__createInternalModuleById(86));
const httpAgent = (__intrinsic__getInternalField(__intrinsic__internalModuleRegistry, 89) || __intrinsic__createInternalModuleById(89));
const { Agent } = httpAgent;
const { ClientRequest } = (__intrinsic__getInternalField(__intrinsic__internalModuleRegistry, 90) || __intrinsic__createInternalModuleById(90));
const { validateHeaderName, validateHeaderValue, parsers } = (__intrinsic__getInternalField(__intrinsic__internalModuleRegistry, 91) || __intrinsic__createInternalModuleById(91));
const { IncomingMessage } = (__intrinsic__getInternalField(__intrinsic__internalModuleRegistry, 92) || __intrinsic__createInternalModuleById(92));
const { OutgoingMessage } = (__intrinsic__getInternalField(__intrinsic__internalModuleRegistry, 93) || __intrinsic__createInternalModuleById(93));
const { Server, ServerResponse } = (__intrinsic__getInternalField(__intrinsic__internalModuleRegistry, 94) || __intrinsic__createInternalModuleById(94));

const { METHODS, STATUS_CODES, setMaxHTTPHeaderSize, getMaxHTTPHeaderSize } = (__intrinsic__getInternalField(__intrinsic__internalModuleRegistry, 31) || __intrinsic__createInternalModuleById(31));

// Like Node.js's lib/_http_client.js creating its debuglog('http'): emits the
// sensitive-data process warning when NODE_DEBUG enables the http section.
(__intrinsic__getInternalField(__intrinsic__internalModuleRegistry, 145) || __intrinsic__createInternalModuleById(145)).debuglog("http");

const { WebSocket, CloseEvent, MessageEvent } = globalThis;

function createServer(options, callback) {
  return new Server(options, callback);
}

/**
 * Makes an HTTP request.
 * @param {string | URL} url
 * @param {HTTPRequestOptions} [options]
 * @param {Function} [cb]
 * @returns {ClientRequest}
 */
function request(url, options, cb) {
  return new ClientRequest(url, options, cb);
}

/**
 * Makes a `GET` HTTP request.
 * @param {string | URL} url
 * @param {HTTPRequestOptions} [options]
 * @param {Function} [cb]
 * @returns {ClientRequest}
 */
function get(url, options, cb) {
  const req = request(url, options, cb);
  req.end();
  return req;
}

const http_exports = {
  Agent,
  Server,
  METHODS,
  STATUS_CODES,
  createServer,
  ServerResponse,
  IncomingMessage,
  request,
  get,
  get maxHeaderSize() {
    return getMaxHTTPHeaderSize();
  },
  set maxHeaderSize(value) {
    setMaxHTTPHeaderSize(value);
  },
  validateHeaderName,
  validateHeaderValue,
  setMaxIdleHTTPParsers(max) {
    validateInteger(max, "max", 1);
    parsers.max = max;
  },
  setGlobalProxyFromEnv,
  // Assigning http.globalAgent must affect the agent used by http.request
  // (which reads it from the node:_http_agent module), like Node.js.
  get globalAgent() {
    return httpAgent.globalAgent;
  },
  set globalAgent(value) {
    httpAgent.globalAgent = value;
  },
  ClientRequest,
  OutgoingMessage,
  WebSocket,
  CloseEvent,
  MessageEvent,
};

function noopRestore() {}

// Port of Node.js's http.setGlobalProxyFromEnv() (lib/http.js):
// https://github.com/nodejs/node/blob/v26.3.0/lib/http.js
// Points the global http and
// https agents at the proxy servers configured through the given environment
// variables, returning a function that restores the previous agents.
// (The fetch() global dispatcher half is not applicable here.)
function setGlobalProxyFromEnv(env = process.env) {
  validateObject(env, "proxyEnv");
  const { parseProxyUrl } = (__intrinsic__getInternalField(__intrinsic__internalModuleRegistry, 31) || __intrinsic__createInternalModuleById(31));
  const httpProxy = parseProxyUrl(env, "http:");
  const httpsProxy = parseProxyUrl(env, "https:");

  if (httpProxy === null && httpsProxy === null) {
    return noopRestore;
  }

  if (httpProxy !== null && URL.canParse(httpProxy) === false) {
    throw __intrinsic__makeErrorWithCode(202, `Invalid proxy URL: ${httpProxy}`);
  }
  if (httpsProxy !== null && URL.canParse(httpsProxy) === false) {
    throw __intrinsic__makeErrorWithCode(202, `Invalid proxy URL: ${httpsProxy}`);
  }

  let originalHttpsAgent, originalHttpAgent;
  if (httpProxy !== null) {
    originalHttpAgent = httpAgent.globalAgent;
    httpAgent.globalAgent = new Agent({
      keepAlive: true,
      scheduling: "lifo",
      timeout: 5000,
      proxyEnv: env,
    });
  }
  if (httpsProxy !== null) {
    const https = (__intrinsic__getInternalField(__intrinsic__internalModuleRegistry, 119) || __intrinsic__createInternalModuleById(119));
    originalHttpsAgent = https.globalAgent;
    https.globalAgent = new https.Agent({
      keepAlive: true,
      scheduling: "lifo",
      timeout: 5000,
      proxyEnv: env,
    });
  }

  return function restore() {
    if (originalHttpAgent !== undefined) {
      httpAgent.globalAgent = originalHttpAgent;
    }
    if (originalHttpsAgent !== undefined) {
      (__intrinsic__getInternalField(__intrinsic__internalModuleRegistry, 119) || __intrinsic__createInternalModuleById(119)).globalAgent = originalHttpsAgent;
    }
  };
}

$ = http_exports;
;$$EXPORT$$($).$$EXPORT_END$$;
