(function () {"use strict";
// zig-out/http-tls-graph-port-2026-10-10/generated/NodeTLSCommon.mts
var $;
function translatePeerCertificate(c) {
  if (!c)
    return null;
  if (c.issuerCertificate != null && c.issuerCertificate !== c)
    c.issuerCertificate = translatePeerCertificate(c.issuerCertificate);
  if (c.infoAccess != null) {
    let info = c.infoAccess, parsed = c.infoAccess = Object.create(null);
    info.replace(/([^\n:]*):([^\n]*)(?:\n|$)/g, (all, key, val) => {
      if (val.charCodeAt(0) === 34)
        val = JSON.parse(val);
      if (key in parsed)
        parsed[key].push(val);
      else
        parsed[key] = [val];
    });
  }
  return c;
}
$ = {
  translatePeerCertificate
};
return $

})
