(function () {"use strict";
// zig-out/http-tls-graph-port-2026-10-10/generated/InternalFSCpSync.mts
var $, { validateObject, validateBoolean, validateFunction, validateInteger } = @getInternalField(@internalModuleRegistry, 86) || @createInternalModuleById(86), {
  chmodSync,
  copyFileSync,
  existsSync,
  lstatSync,
  mkdirSync,
  readdirSync,
  readlinkSync,
  statSync,
  symlinkSync,
  unlinkSync,
  utimesSync
} = @getInternalField(@internalModuleRegistry, 116) || @createInternalModuleById(116), { dirname, isAbsolute, join, parse, resolve, sep } = @getInternalField(@internalModuleRegistry, 125) || @createInternalModuleById(125), { EEXIST, EISDIR, EINVAL, ENOTDIR } = @processBindingConstants.os.errno, ArrayPrototypeEvery = @Array.prototype.every, ArrayPrototypeFilter = @Array.prototype.filter, StringPrototypeSplit = @String.prototype.split;
var defaultCpOptions = {
  dereference: !1,
  errorOnExist: !1,
  filter: @undefined,
  force: !0,
  preserveTimestamps: !1,
  recursive: !1,
  verbatimSymlinks: !1,
  mode: 0
};
function decorateSystemError(err, prefix, context) {
  let { syscall, code, message: ctxMessage, path, dest, errno } = context, message = `${prefix}: ${syscall} returned ${code} (${ctxMessage})`;
  if (path !== @undefined)
    message += ` ${path}`;
  if (dest !== @undefined)
    message += ` => ${dest}`;
  if (err.message = message, err.name = "SystemError", err.info = context, err.errno = errno, err.syscall = syscall, path !== @undefined)
    err.path = path;
  if (dest !== @undefined)
    err.dest = dest;
  return err;
}
function fsCpDirToNonDirError(context) {
  return decorateSystemError(@makeErrorWithCode(62, context.message), "Cannot overwrite non-directory with directory", context);
}
function fsCpEExistError(context) {
  return decorateSystemError(@makeErrorWithCode(325, context.message), "Target already exists", context);
}
function fsCpEinvalError(context) {
  return decorateSystemError(@makeErrorWithCode(63, context.message), "Invalid src or dest", context);
}
function fsCpFifoPipeError(context) {
  return decorateSystemError(@makeErrorWithCode(64, context.message), "Cannot copy a FIFO pipe", context);
}
function fsCpNonDirToDirError(context) {
  return decorateSystemError(@makeErrorWithCode(65, context.message), "Cannot overwrite directory with non-directory", context);
}
function fsCpSocketError(context) {
  return decorateSystemError(@makeErrorWithCode(66, context.message), "Cannot copy a socket file", context);
}
function fsCpSymlinkToSubdirectoryError(context) {
  return decorateSystemError(@makeErrorWithCode(326, context.message), "Cannot overwrite symlink in subdirectory of self", context);
}
function fsCpUnknownError(context) {
  return decorateSystemError(@makeErrorWithCode(67, context.message), "Cannot copy an unknown file type", context);
}
function fsEisdirError(context) {
  return decorateSystemError(@makeErrorWithCode(68, context.message), "Path is a directory", context);
}
function getValidMode(mode) {
  if (mode == null)
    return 0;
  return validateInteger(mode, "mode", 0, 7), mode;
}
var kValidatedCpOptions = Symbol("kValidatedCpOptions");
function validateCpOptions(options) {
  if (options?.[kValidatedCpOptions])
    return options;
  if (options === @undefined)
    return options = { ...defaultCpOptions }, options[kValidatedCpOptions] = !0, options;
  if (validateObject(options, "options"), options = { ...defaultCpOptions, ...options }, validateBoolean(options.dereference, "options.dereference"), validateBoolean(options.errorOnExist, "options.errorOnExist"), validateBoolean(options.force, "options.force"), validateBoolean(options.preserveTimestamps, "options.preserveTimestamps"), validateBoolean(options.recursive, "options.recursive"), validateBoolean(options.verbatimSymlinks, "options.verbatimSymlinks"), options.mode = getValidMode(options.mode), options.dereference === !0 && options.verbatimSymlinks === !0)
    throw @makeErrorWithCode(116, 'Option "dereference" cannot be used in combination with option "verbatimSymlinks"');
  let { filter } = options;
  if (filter !== @undefined)
    validateFunction(filter, "options.filter");
  return options[kValidatedCpOptions] = !0, options;
}
function areIdentical(srcStat, destStat) {
  return destStat.ino && destStat.dev && destStat.ino === srcStat.ino && destStat.dev === srcStat.dev;
}
var normalizePathToArray = (path) => ArrayPrototypeFilter.@call(StringPrototypeSplit.@call(resolve(path), sep), Boolean);
function isSrcSubdir(src, dest) {
  let srcArr = normalizePathToArray(src), destArr = normalizePathToArray(dest);
  return ArrayPrototypeEvery.@call(srcArr, (cur, i) => destArr[i] === cur);
}
function checkPathsSync(src, dest, opts) {
  if (opts.filter) {
    let shouldCopy = opts.filter(src, dest);
    if (@isPromise(shouldCopy))
      throw @makeErrorWithCode(136, "boolean", "filter", shouldCopy);
    if (!shouldCopy)
      return { __proto__: null, skipped: !0 };
  }
  let { srcStat, destStat } = getStatsSync(src, dest, opts);
  if (destStat) {
    if (areIdentical(srcStat, destStat))
      throw fsCpEinvalError({
        message: "src and dest cannot be the same",
        path: dest,
        syscall: "cp",
        errno: EINVAL,
        code: "EINVAL"
      });
    if (srcStat.isDirectory() && !destStat.isDirectory())
      throw fsCpDirToNonDirError({
        message: `cannot overwrite non-directory ${dest} with directory ${src}`,
        path: dest,
        syscall: "cp",
        errno: EISDIR,
        code: "EISDIR"
      });
    if (!srcStat.isDirectory() && destStat.isDirectory())
      throw fsCpNonDirToDirError({
        message: `cannot overwrite directory ${dest} with non-directory ${src}`,
        path: dest,
        syscall: "cp",
        errno: ENOTDIR,
        code: "ENOTDIR"
      });
  }
  if (srcStat.isDirectory() && isSrcSubdir(src, dest))
    throw fsCpEinvalError({
      message: `cannot copy ${src} to a subdirectory of self ${dest}`,
      path: dest,
      syscall: "cp",
      errno: EINVAL,
      code: "EINVAL"
    });
  return { __proto__: null, srcStat, destStat, skipped: !1 };
}
function getStatsSync(src, dest, opts) {
  let destStat, statFunc = opts.dereference ? (file) => statSync(file, { bigint: !0 }) : (file) => lstatSync(file, { bigint: !0 }), srcStat = statFunc(src);
  try {
    destStat = statFunc(dest);
  } catch (err) {
    if (err.code === "ENOENT")
      return { srcStat, destStat: null };
    throw err;
  }
  return { srcStat, destStat };
}
function checkParentPathsSync(src, srcStat, dest) {
  let srcParent = resolve(dirname(src)), destParent = resolve(dirname(dest));
  if (destParent === srcParent || destParent === parse(destParent).root)
    return;
  let destStat;
  try {
    destStat = statSync(destParent, { bigint: !0 });
  } catch (err) {
    if (err.code === "ENOENT")
      return;
    throw err;
  }
  if (areIdentical(srcStat, destStat))
    throw fsCpEinvalError({
      message: `cannot copy ${src} to a subdirectory of self ${dest}`,
      path: dest,
      syscall: "cp",
      errno: EINVAL,
      code: "EINVAL"
    });
  return checkParentPathsSync(src, srcStat, destParent);
}
function treeContainsOnlyFilesAndDirsSync(root) {
  let stack = [root];
  while (stack.length) {
    let dir = stack.pop(), entries;
    try {
      entries = readdirSync(dir, { withFileTypes: !0 });
    } catch {
      return !1;
    }
    for (let i = 0;i < entries.length; i++) {
      let entry = entries[i];
      if (entry.isDirectory())
        stack.push(join(dir, entry.name));
      else if (!entry.isFile())
        return !1;
    }
  }
  return !0;
}
function tryNativeFastPathSync(src, dest, opts) {
  let checked = checkPathsSync(src, dest, opts), { srcStat, destStat } = checked;
  if (checkParentPathsSync(src, srcStat, dest), srcStat.isDirectory() && !opts.recursive)
    throw fsEisdirError({
      message: `${src} is a directory (not copied)`,
      path: src,
      syscall: "cp",
      errno: EISDIR,
      code: "EISDIR"
    });
  if (srcStat.isDirectory())
    return {
      ok: !destStat && treeContainsOnlyFilesAndDirsSync(src),
      checked
    };
  return { ok: srcStat.isFile() && (!destStat || destStat.isFile()), checked };
}
function cpSyncFn(src, dest, opts, checked) {
  let { srcStat, destStat, skipped } = checked ?? checkPathsSync(src, dest, opts);
  if (skipped)
    return;
  if (checked === @undefined)
    checkParentPathsSync(src, srcStat, dest);
  return checkParentDir(destStat, src, dest, opts);
}
function checkParentDir(destStat, src, dest, opts) {
  let destParent = dirname(dest);
  if (!existsSync(destParent))
    mkdirSync(destParent, { recursive: !0 });
  return getStats(destStat, src, dest, opts);
}
function getStats(destStat, src, dest, opts) {
  let srcStat = (opts.dereference ? statSync : lstatSync)(src);
  if (srcStat.isDirectory() && opts.recursive)
    return onDir(srcStat, destStat, src, dest, opts);
  else if (srcStat.isDirectory())
    throw fsEisdirError({
      message: `${src} is a directory (not copied)`,
      path: src,
      syscall: "cp",
      errno: EISDIR,
      code: "EISDIR"
    });
  else if (srcStat.isFile() || srcStat.isCharacterDevice() || srcStat.isBlockDevice())
    return onFile(srcStat, destStat, src, dest, opts);
  else if (srcStat.isSymbolicLink())
    return onLink(destStat, src, dest, opts);
  else if (srcStat.isSocket())
    throw fsCpSocketError({
      message: `cannot copy a socket file: ${dest}`,
      path: dest,
      syscall: "cp",
      errno: EINVAL,
      code: "EINVAL"
    });
  else if (srcStat.isFIFO())
    throw fsCpFifoPipeError({
      message: `cannot copy a FIFO pipe: ${dest}`,
      path: dest,
      syscall: "cp",
      errno: EINVAL,
      code: "EINVAL"
    });
  throw fsCpUnknownError({
    message: `cannot copy an unknown file type: ${dest}`,
    path: dest,
    syscall: "cp",
    errno: EINVAL,
    code: "EINVAL"
  });
}
function onFile(srcStat, destStat, src, dest, opts) {
  if (!destStat)
    return copyFile(srcStat, src, dest, opts);
  return mayCopyFile(srcStat, src, dest, opts);
}
function mayCopyFile(srcStat, src, dest, opts) {
  if (opts.force)
    return unlinkSync(dest), copyFile(srcStat, src, dest, opts);
  else if (opts.errorOnExist)
    throw fsCpEExistError({
      message: `${dest} already exists`,
      path: dest,
      syscall: "cp",
      errno: EEXIST,
      code: "EEXIST"
    });
}
function copyFile(srcStat, src, dest, opts) {
  if (copyFileSync(src, dest, opts.mode), opts.preserveTimestamps)
    handleTimestamps(srcStat.mode, src, dest);
  return setDestMode(dest, srcStat.mode);
}
function handleTimestamps(srcMode, src, dest) {
  if (fileIsNotWritable(srcMode))
    makeFileWritable(dest, srcMode);
  return setDestTimestamps(src, dest);
}
function fileIsNotWritable(srcMode) {
  return (srcMode & 128) === 0;
}
function makeFileWritable(dest, srcMode) {
  return setDestMode(dest, srcMode | 128);
}
function setDestMode(dest, srcMode) {
  return chmodSync(dest, srcMode);
}
function setDestTimestamps(src, dest) {
  let updatedSrcStat = statSync(src);
  return utimesSync(dest, updatedSrcStat.atime, updatedSrcStat.mtime);
}
function onDir(srcStat, destStat, src, dest, opts) {
  if (!destStat)
    return mkDirAndCopy(srcStat.mode, src, dest, opts);
  if (opts.errorOnExist && !opts.force)
    throw fsCpEExistError({
      message: `${dest} already exists`,
      path: dest,
      syscall: "cp",
      errno: EEXIST,
      code: "EEXIST"
    });
  return copyDir(src, dest, opts);
}
function mkDirAndCopy(srcMode, src, dest, opts) {
  return mkdirSync(dest), copyDir(src, dest, opts), setDestMode(dest, srcMode);
}
function copyDir(src, dest, opts) {
  for (let dirent of readdirSync(src, { withFileTypes: !0 })) {
    let { name } = dirent, srcItem = join(src, name), destItem = join(dest, name), { destStat, skipped } = checkPathsSync(srcItem, destItem, opts);
    if (!skipped)
      getStats(destStat, srcItem, destItem, opts);
  }
}
function onLink(destStat, src, dest, opts) {
  let resolvedSrc = readlinkSync(src);
  if (!opts.verbatimSymlinks && !isAbsolute(resolvedSrc))
    resolvedSrc = resolve(dirname(src), resolvedSrc);
  if (!destStat)
    return symlinkSync(resolvedSrc, dest);
  let resolvedDest;
  try {
    resolvedDest = readlinkSync(dest);
  } catch (err) {
    if (err.code === "EINVAL" || err.code === "UNKNOWN")
      return symlinkSync(resolvedSrc, dest);
    throw err;
  }
  if (!isAbsolute(resolvedDest))
    resolvedDest = resolve(dirname(dest), resolvedDest);
  let srcIsDir = !1;
  try {
    srcIsDir = statSync(src).isDirectory();
  } catch {}
  if (srcIsDir && isSrcSubdir(resolvedSrc, resolvedDest))
    throw fsCpEinvalError({
      message: `cannot copy ${resolvedSrc} to a subdirectory of self ${resolvedDest}`,
      path: dest,
      syscall: "cp",
      errno: EINVAL,
      code: "EINVAL"
    });
  if (statSync(dest).isDirectory() && isSrcSubdir(resolvedDest, resolvedSrc))
    throw fsCpSymlinkToSubdirectoryError({
      message: `cannot overwrite ${resolvedDest} with ${resolvedSrc}`,
      path: dest,
      syscall: "cp",
      errno: EINVAL,
      code: "EINVAL"
    });
  return copyLink(resolvedSrc, dest);
}
function copyLink(resolvedSrc, dest) {
  return unlinkSync(dest), symlinkSync(resolvedSrc, dest);
}
$ = {
  cpSyncFn,
  validateCpOptions,
  tryNativeFastPathSync,
  errno: { EEXIST, EISDIR, EINVAL, ENOTDIR },
  fsCpDirToNonDirError,
  fsCpEExistError,
  fsCpEinvalError,
  fsCpFifoPipeError,
  fsCpNonDirToDirError,
  fsCpSocketError,
  fsCpSymlinkToSubdirectoryError,
  fsCpUnknownError,
  fsEisdirError,
  areIdentical,
  isSrcSubdir
};
return $

})
