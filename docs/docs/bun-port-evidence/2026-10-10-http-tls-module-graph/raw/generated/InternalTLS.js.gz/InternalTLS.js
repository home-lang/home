(function () {"use strict";
// zig-out/http-tls-graph-port-2026-10-10/generated/InternalTLS.mts
var $, { isTypedArray, isArrayBuffer } = @getInternalField(@internalModuleRegistry, 164) || @createInternalModuleById(164);
function isPemObject(obj) {
  return @isObject(obj) && "pem" in obj;
}
function isPemArray(obj) {
  return @isArray(obj) && obj.every(isPemObject);
}
function isValidTLSItem(obj) {
  if (typeof obj === "string" || isTypedArray(obj) || isArrayBuffer(obj) || @inherits(0, obj) || isPemArray(obj))
    return !0;
  return !1;
}
function findInvalidTLSItem(obj) {
  if (@isArray(obj))
    for (var i = 0, length = obj.length;i < length; i++) {
      let item = obj[i];
      if (!isValidTLSItem(item))
        return item;
    }
  return obj;
}
function throwOnInvalidTLSArray(name, value) {
  if (!isValidTLSArray(value))
    throw @makeErrorWithCode(119, name, VALID_TLS_ERROR_MESSAGE_TYPES, findInvalidTLSItem(value));
}
function isValidTLSArray(obj) {
  if (isValidTLSItem(obj))
    return !0;
  if (@isArray(obj)) {
    for (var i = 0, length = obj.length;i < length; i++) {
      let item = obj[i];
      if (!isValidTLSItem(item))
        return !1;
    }
    return !0;
  }
  return !1;
}
var VALID_TLS_ERROR_MESSAGE_TYPES = "string or an instance of Buffer, TypedArray, DataView, or BunFile";

$ = {"throwOnInvalidTLSArray": throwOnInvalidTLSArray, "isValidTLSItem": isValidTLSItem, "isValidTLSArray": isValidTLSArray, "VALID_TLS_ERROR_MESSAGE_TYPES": VALID_TLS_ERROR_MESSAGE_TYPES};
return $
})
