(function () {"use strict";
// zig-out/http-tls-graph-port-2026-10-10/generated/NodeHttpServer.mts
var $, EventEmitter = @getInternalField(@internalModuleRegistry, 114) || @createInternalModuleById(114), { Duplex, Stream } = @getInternalField(@internalModuleRegistry, 136) || @createInternalModuleById(136), {
  _checkInvalidHeaderChar: checkInvalidHeaderChar,
  chunkExpression,
  continueExpression,
  validateHeaderName,
  validateHeaderValue
} = @getInternalField(@internalModuleRegistry, 91) || @createInternalModuleById(91), {
  validateObject,
  validateLinkHeaderValue,
  validateBoolean,
  validateInteger,
  validateFunction
} = @getInternalField(@internalModuleRegistry, 86) || @createInternalModuleById(86), { ConnResetException, hasObserver, startPerf, stopPerf } = @getInternalField(@internalModuleRegistry, 38) || @createInternalModuleById(38), kServerResponseStatistics = Symbol("ServerResponseStatistics"), { isPrimary } = @getInternalField(@internalModuleRegistry, 15) || @createInternalModuleById(15), { throwOnInvalidTLSArray } = @getInternalField(@internalModuleRegistry, 79) || @createInternalModuleById(79), {
  kInternalSocketData,
  serverSymbol,
  kHandle,
  kRealListen,
  tlsSymbol,
  optionsSymbol,
  kDeferredTimeouts,
  kDeprecatedReplySymbol,
  headerStateSymbol,
  NodeHTTPHeaderState,
  kPendingCallbacks,
  kRequest,
  kCloseCallback,
  NodeHTTPResponseFlags,
  emitErrorNextTickIfErrorListenerNT,
  getIsNextIncomingMessageHTTPS,
  setIsNextIncomingMessageHTTPS,
  callCloseCallback,
  emitCloseNT,
  NodeHTTPResponseAbortEvent,
  STATUS_CODES,
  isTlsSymbol,
  hasServerResponseFinished,
  NodeHTTPBodyReadState,
  controllerSymbol,
  firstWriteSymbol,
  deferredSymbol,
  eofInProgress,
  runSymbol,
  drainMicrotasks,
  setServerIdleTimeout,
  setServerCustomOptions,
  getMaxHTTPHeaderSize,
  fakeSocketSymbol,
  utcDate,
  kOutHeaders
} = @getInternalField(@internalModuleRegistry, 31) || @createInternalModuleById(31), { FakeSocket } = @getInternalField(@internalModuleRegistry, 32) || @createInternalModuleById(32), NumberIsNaN = Number.isNaN, { format } = @getInternalField(@internalModuleRegistry, 84) || @createInternalModuleById(84), { IncomingMessage } = @getInternalField(@internalModuleRegistry, 92) || @createInternalModuleById(92), {
  OutgoingMessage,
  kErrored,
  kHighWaterMark,
  kSocket,
  kRejectNonStandardBodyWrites
} = @getInternalField(@internalModuleRegistry, 93) || @createInternalModuleById(93), OutgoingMessagePrototype = OutgoingMessage.prototype, { kIncomingMessage } = @getInternalField(@internalModuleRegistry, 91) || @createInternalModuleById(91), kConnectionsCheckingInterval = Symbol("http.server.connectionsCheckingInterval"), kTrackedConnections = Symbol("http.server.trackedConnections"), getBunServerAllClosedPromise = @lazy(44), sendHelper = @lazy(4), kServerResponse = Symbol("ServerResponse"), kChunkedEncoding = Symbol("kChunkedEncoding"), kShouldKeepAlive = Symbol("kShouldKeepAlive"), kOptimizeEmptyRequests = Symbol("kOptimizeEmptyRequests"), GlobalPromise = globalThis.Promise, kEmptyBuffer = @Buffer.alloc(0), ObjectKeys = Object.keys, MathMin = Math.min, MathFloor = Math.floor, cluster;
function emitCloseServer(self) {
  callCloseCallback(self), self.emit("close");
}
function emitCloseNTServer() {
  process.nextTick(emitCloseServer, this);
}
function setCloseCallback(self, callback) {
  if (callback === self[kCloseCallback])
    return;
  if (self[kCloseCallback])
    throw Error("Close callback already set");
  self[kCloseCallback] = callback;
}
function assignSocketInternal(self, socket) {
  if (socket._httpMessage)
    throw @makeErrorWithCode(75, "Socket already assigned");
  socket._httpMessage = self, setCloseCallback(socket, onServerResponseClose), self.socket = socket, self.emit("socket", socket);
}
function onServerResponseClose() {
  let httpMessage = this._httpMessage;
  if (httpMessage)
    emitCloseNT(httpMessage);
}
function strictContentLength(response) {
  if (response.strictContentLength) {
    let contentLength = response._contentLength ?? response.getHeader("content-length");
    if (contentLength && response._hasBody && !response._removedContLen && !response.chunkedEncoding && !response.hasHeader("transfer-encoding")) {
      if (typeof contentLength === "number")
        return contentLength;
      else if (typeof contentLength === "string") {
        if (contentLength = parseInt(contentLength, 10), NumberIsNaN(contentLength))
          return;
        return contentLength;
      }
    }
  }
}
var ServerResponse_writeDeprecated = function _write(chunk, encoding, callback) {
  if (@isCallable(encoding))
    callback = encoding, encoding = @undefined;
  if (!@isCallable(callback))
    callback = @undefined;
  if (encoding && encoding !== "buffer")
    chunk = @Buffer.from(chunk, encoding);
  if (this.destroyed || this.finished) {
    if (chunk)
      emitErrorNextTickIfErrorListenerNT(this, @makeErrorWithCode(241), callback);
    return !1;
  }
  if (this[firstWriteSymbol] === @undefined && !this.headersSent) {
    if (this[firstWriteSymbol] = chunk, callback)
      callback();
    return;
  }
  ensureReadableStreamController.@call(this, (controller) => {
    if (controller.write(chunk), callback)
      callback();
  });
};
function onNodeHTTPServerSocketTimeout() {
  let req = this[kRequest], reqTimeout = req && !req.complete && req.emit("timeout", this), res = this._httpMessage, resTimeout = res && res.emit("timeout", this), serverTimeout = this.server.emit("timeout", this);
  if (!reqTimeout && !resTimeout && !serverTimeout)
    this.destroy();
}
function emitRequestCloseNT(self) {
  callCloseCallback(self), self.emit("close");
}
function emitListeningNextTick(self, hostname, port) {
  if (self.listening = !!self[serverSymbol])
    self.emit("listening", null, hostname, port);
}
function normalizeServerTls(tls) {
  let requestCert = !!tls.requestCert;
  return tls.requestCert = requestCert, tls.rejectUnauthorized = requestCert ? tls.rejectUnauthorized !== !1 : !1, tls;
}
function Server(options, callback) {
  if (!(this instanceof Server))
    return new Server(options, callback);
  if (EventEmitter.@call(this), this.on("listening", setupConnectionsTracking), this.listening = !1, this._unref = !1, this.maxRequestsPerSocket = 0, this.maxHeadersCount = null, this[kInternalSocketData] = @undefined, this[kTrackedConnections] = /* @__PURE__ */ new Set, this[tlsSymbol] = null, this.noDelay = !0, typeof options === "function")
    callback = options, options = {};
  else if (options == null)
    options = {};
  else {
    validateObject(options, "options"), options = { ...options };
    let cert = options.cert;
    if (cert)
      throwOnInvalidTLSArray("options.cert", cert), this[isTlsSymbol] = !0;
    let key = options.key;
    if (key)
      throwOnInvalidTLSArray("options.key", key), this[isTlsSymbol] = !0;
    let ca = options.ca;
    if (ca)
      throwOnInvalidTLSArray("options.ca", ca), this[isTlsSymbol] = !0;
    let passphrase = options.passphrase;
    if (passphrase && typeof passphrase !== "string")
      throw @makeErrorWithCode(119, "options.passphrase", "string", passphrase);
    let serverName = options.servername;
    if (serverName && typeof serverName !== "string")
      throw @makeErrorWithCode(119, "options.servername", "string", serverName);
    let secureOptions = options.secureOptions || 0;
    if (secureOptions && typeof secureOptions !== "number")
      throw @makeErrorWithCode(119, "options.secureOptions", "number", secureOptions);
    if (this[isTlsSymbol])
      this[tlsSymbol] = normalizeServerTls({
        serverName,
        key,
        cert,
        ca,
        passphrase,
        secureOptions,
        requestCert: options.requestCert,
        rejectUnauthorized: options.rejectUnauthorized
      });
    else
      this[tlsSymbol] = null;
  }
  if (this[optionsSymbol] = options, storeHTTPOptions.@call(this, options), callback)
    this.on("request", callback);
  return this;
}
@toClass(Server, "Server", EventEmitter);
Server.prototype[kIncomingMessage] = @undefined;
Server.prototype[kServerResponse] = @undefined;
Server.prototype[kConnectionsCheckingInterval] = @undefined;
function rethrowUncaught(err) {
  throw err;
}
function noopConnectionsCheck() {}
function setupConnectionsTracking() {
  if (this[kConnectionsCheckingInterval])
    clearInterval(this[kConnectionsCheckingInterval]);
  let delay = this.connectionsCheckingInterval || 30000;
  this[kConnectionsCheckingInterval] = setInterval(noopConnectionsCheck, delay), this[kConnectionsCheckingInterval].unref();
}
Server.prototype.ref = function() {
  return this._unref = !1, this[serverSymbol]?.ref?.(), this;
};
Server.prototype.unref = function() {
  return this._unref = !0, this[serverSymbol]?.unref?.(), this;
};
Server.prototype.closeAllConnections = function() {
  let server = this[serverSymbol];
  if (!server)
    return;
  this[serverSymbol] = @undefined, clearInterval(this[kConnectionsCheckingInterval]), this.listening = !1, server.stop(!0);
};
Server.prototype.getConnections = function(callback) {
  let count = this[kTrackedConnections]?.size ?? 0;
  if (typeof callback === "function")
    process.nextTick(callback, null, count);
  return this;
};
Server.prototype.closeIdleConnections = function() {
  this[serverSymbol]?.closeIdleConnections();
};
Server.prototype.close = function(optionalCallback) {
  let server = this[serverSymbol];
  if (clearInterval(this[kConnectionsCheckingInterval]), !server) {
    if (typeof optionalCallback === "function")
      process.nextTick(optionalCallback, @makeErrorWithCode(218));
    return;
  }
  if (this[serverSymbol] = @undefined, typeof optionalCallback === "function")
    setCloseCallback(this, optionalCallback);
  this.listening = !1, server.closeIdleConnections(), server.stop();
};
Server.prototype[EventEmitter.captureRejectionSymbol] = function(err, event, ...args) {
  switch (event) {
    case "request": {
      let { 1: res2 } = args;
      if (!res2.headersSent && !res2.writableEnded) {
        let names = res2.getHeaderNames();
        for (let i = 0;i < names.length; i++)
          res2.removeHeader(names[i]);
        res2.statusCode = 500, res2.end(STATUS_CODES[500]);
      } else
        res2.destroy();
      break;
    }
    default:
      let { 1: res } = args;
      res?.socket?.destroy();
      break;
  }
};
Server.prototype[Symbol.asyncDispose] = function() {
  let { resolve, reject, promise } = @Promise.withResolvers();
  return this.close(function(err, ...args) {
    if (err)
      reject(err);
    else
      resolve(...args);
  }), promise;
};
Server.prototype.address = function() {
  if (!this[serverSymbol])
    return null;
  return this[serverSymbol].address;
};
Server.prototype.listen = function() {
  let server = this, port, host, onListen, socketPath, tls = this[tlsSymbol], argc = arguments.length;
  if (argc > 0) {
    let arg0 = arguments[0];
    if ((@isObject(arg0) || @isCallable(arg0)) && arg0 !== null) {
      port = arg0.port, host = arg0.host, socketPath = arg0.path;
      let otherTLS = arg0.tls;
      if (otherTLS && @isObject(otherTLS))
        tls = normalizeServerTls({ ...otherTLS });
    } else if (typeof arg0 === "string" && !(Number(arg0) >= 0))
      socketPath = arg0;
    else if (port = arg0, argc > 1 && typeof arguments[1] === "string")
      host = arguments[1];
  }
  if (port === @undefined && !socketPath)
    port = 0;
  if (typeof port === "string") {
    let portNumber = parseInt(port);
    if (!Number.isNaN(portNumber))
      port = portNumber;
  }
  let lastArg = arguments[argc - 1];
  if (@isCallable(lastArg))
    onListen = lastArg;
  try {
    if (isPrimary)
      return server[kRealListen](tls, port, host, socketPath, !1, onListen), this;
    if (cluster === @undefined)
      cluster = @getInternalField(@internalModuleRegistry, 106) || @createInternalModuleById(106);
    server.once("listening", () => {
      cluster.worker.state = "listening";
      let address = server.address(), message = {
        act: "listening",
        port: address && address.port || port,
        data: null,
        addressType: 4
      };
      sendHelper(message, null);
    }), server[kRealListen](tls, port, host, socketPath, !0, onListen);
  } catch (err) {
    setTimeout(() => server.emit("error", err), 1);
  }
  return this;
};
Server.prototype[kRealListen] = function(tls, port, host, socketPath, reusePort, onListen) {
  {
    let ResponseClass = this[optionsSymbol].ServerResponse || ServerResponse, RequestClass = this[optionsSymbol].IncomingMessage || IncomingMessage, canUseInternalAssignSocket = ResponseClass?.prototype.assignSocket === ServerResponse.prototype.assignSocket, isHTTPS = !1, server = this;
    if (tls)
      this.serverName = tls.serverName || host || "localhost";
    if (this[serverSymbol] = Bun.serve({
      idleTimeout: 0,
      tls,
      port,
      hostname: host,
      unix: socketPath,
      reusePort,
      websocket: {
        open(ws) {
          ws.data.open(ws);
        },
        message(ws, message) {
          ws.data.message(ws, message);
        },
        close(ws, code, reason) {
          ws.data.close(ws, code, reason);
        },
        drain(ws) {
          ws.data.drain(ws);
        },
        ping(ws, data) {
          ws.data.ping(ws, data);
        },
        pong(ws, data) {
          ws.data.pong(ws, data);
        }
      },
      maxRequestBodySize: Number.MAX_SAFE_INTEGER,
      onNodeHTTPRequest(bunServer, url, method, headersObject, headersArray, handle, hasBody, socketHandle, isSocketNew, socket, isAncientHTTP, connectHead) {
        let prevIsNextIncomingMessageHTTPS = getIsNextIncomingMessageHTTPS();
        if (setIsNextIncomingMessageHTTPS(isHTTPS), !socket)
          socket = new NodeHTTPServerSocket(server, socketHandle, !!tls);
        let http_req = new RequestClass(kHandle, url, method, headersObject, headersArray, handle, hasBody, socket);
        if (isAncientHTTP)
          http_req.httpVersion = "1.0", http_req.httpVersionMajor = 1, http_req.httpVersionMinor = 0;
        if (server.joinDuplicateHeaders)
          http_req.joinDuplicateHeaders = !0;
        if (method === "CONNECT") {
          if (server.listenerCount("connect") > 0) {
            socket[kEnableStreaming](!0);
            let { promise: promise2, resolve: resolve2 } = @newPromiseCapability(@Promise), head = connectHead ? connectHead : kEmptyBuffer;
            return http_req.upgrade = !0, server.emit("connect", http_req, socket, head), socket.once("close", resolve2), promise2;
          } else
            socketHandle.close();
          return;
        }
        socket[kEnableStreaming](!1);
        let http_res = new ResponseClass(http_req, {
          [kHandle]: handle,
          [kRejectNonStandardBodyWrites]: server.rejectNonStandardBodyWrites
        });
        if (http_res._keepAliveTimeout = server.keepAliveTimeout, !requestShouldKeepAlive(http_req))
          http_res[kMustCloseConnection] = !0;
        if (http_res.once("finish", endSocketOnFinishIfNeeded.bind(@undefined, socket, http_res)), hasObserver("http"))
          startPerf(http_res, kServerResponseStatistics, {
            type: "http",
            name: "HttpRequest",
            detail: {
              req: {
                method: http_req.method,
                url: http_req.url,
                headers: http_req.headers
              }
            }
          }), http_res.once("finish", stopServerResponsePerf);
        if (setIsNextIncomingMessageHTTPS(prevIsNextIncomingMessageHTTPS), handle.onabort = onServerRequestEvent.bind(socket), hasBody)
          handle.pause();
        drainMicrotasks();
        let resolveFunction, didFinish = !1, isRequestsLimitSet = typeof server.maxRequestsPerSocket === "number" && server.maxRequestsPerSocket > 0, reachedRequestsLimit = !1;
        if (isRequestsLimitSet) {
          let requestCount = (socket._requestCount || 0) + 1;
          if (socket._requestCount = requestCount, http_res._maxRequestsPerSocket = server.maxRequestsPerSocket, http_res.maxRequestsOnConnectionReached = server.maxRequestsPerSocket <= requestCount, server.maxRequestsPerSocket < requestCount)
            reachedRequestsLimit = !0;
        }
        if (isSocketNew && !reachedRequestsLimit)
          server.emit("connection", socket);
        socket[kRequest] = http_req;
        let is_upgrade = !1;
        if (http_req.headers.upgrade !== @undefined) {
          let connectionHeader = http_req.headers.connection;
          if (typeof connectionHeader === "string" && RE_CONN_UPGRADE.test(connectionHeader))
            is_upgrade = !!server.shouldUpgradeCallback(http_req);
        }
        if (http_req.upgrade = is_upgrade, !is_upgrade)
          if (canUseInternalAssignSocket)
            assignSocketInternal(http_res, socket);
          else
            http_res.assignSocket(socket);
        function onClose() {
          if (didFinish = !0, resolveFunction)
            resolveFunction();
        }
        if (setCloseCallback(http_res, onClose), server[kOptimizeEmptyRequests] && !is_upgrade && http_req.headers["content-length"] === @undefined && http_req.headers["transfer-encoding"] === @undefined)
          http_req._dumpAndCloseReadable();
        if (reachedRequestsLimit)
          server.emit("dropRequest", http_req, socket), http_res.writeHead(503), http_res.end(), socket.destroy();
        else if (is_upgrade) {
          socketHandle.upgradeToTunnel(), socket[kEnableStreaming](!0);
          let upgradeHead = connectHead ? connectHead : kEmptyBuffer, upgradeHandled;
          try {
            upgradeHandled = server.emit("upgrade", http_req, socket, upgradeHead);
          } catch (err) {
            process.nextTick(rethrowUncaught, err), upgradeHandled = !0;
          }
          if (!upgradeHandled) {
            socket.destroy();
            return;
          }
          let { promise: upgradePromise, resolve: resolveUpgrade } = @newPromiseCapability(@Promise);
          return socket.once("close", resolveUpgrade), upgradePromise;
        } else if (server.requireHostHeader && http_req.headers.host === @undefined && http_req.httpVersionMajor === 1 && http_req.httpVersionMinor >= 1)
          http_res.writeHead(400, { Connection: "close" }), http_res.end();
        else {
          let expectHeader = http_req.headers.expect;
          if (expectHeader !== @undefined)
            if (continueExpression.test(expectHeader))
              if (server.listenerCount("checkContinue") > 0)
                server.emit("checkContinue", http_req, http_res);
              else
                http_res.writeContinue(), server.emit("request", http_req, http_res);
            else if (server.listenerCount("checkExpectation") > 0)
              server.emit("checkExpectation", http_req, http_res);
            else
              http_res.writeHead(417), http_res.end();
          else
            server.emit("request", http_req, http_res);
        }
        if (socket.cork(), handle.finished || didFinish) {
          handle = @undefined, http_res[kCloseCallback] = @undefined, http_res.detachSocket(socket);
          return;
        }
        if (http_res.socket)
          http_res.on("finish", http_res.detachSocket.bind(http_res, socket));
        let { resolve, promise } = @newPromiseCapability(@Promise);
        return resolveFunction = resolve, promise;
      }
    }), getBunServerAllClosedPromise(this[serverSymbol]).@then(emitCloseNTServer.bind(this)), isHTTPS = this[serverSymbol].protocol === "https", setServerCustomOptions(this[serverSymbol], this.requireHostHeader, !0, typeof this.maxHeaderSize < "u" ? this.maxHeaderSize : getMaxHTTPHeaderSize(), onServerClientError.bind(this)), this?._unref)
      this[serverSymbol]?.unref?.();
    if (@isCallable(onListen))
      this.once("listening", onListen);
    if (this[kDeferredTimeouts]) {
      for (let { msecs, callback } of this[kDeferredTimeouts])
        this.setTimeout(msecs, callback);
      delete this[kDeferredTimeouts];
    }
    setTimeout(emitListeningNextTick, 1, this, this[serverSymbol]?.hostname, this[serverSymbol]?.port);
  }
};
Server.prototype.setTimeout = function(msecs, callback) {
  let server = this[serverSymbol];
  if (server) {
    if (setServerIdleTimeout(server, Math.ceil(msecs / 1000)), typeof callback === "function")
      this.once("timeout", callback);
  } else
    (this[kDeferredTimeouts] ??= []).push({ msecs, callback });
  return this;
};
function onServerRequestEvent(event) {
  let socket = this;
  switch (event) {
    case NodeHTTPResponseAbortEvent.abort: {
      if (!socket.destroyed)
        socket.destroy();
      break;
    }
    case NodeHTTPResponseAbortEvent.timeout: {
      socket.emit("timeout");
      break;
    }
  }
}
function onServerClientError(ssl, socket, errorCode, rawPacket) {
  let self = this, err;
  switch (errorCode) {
    case 2 /* HTTP_PARSER_ERROR_INVALID_CONTENT_LENGTH */:
      err = @makeErrorWithCode(295, "Parse Error");
      break;
    case 3 /* HTTP_PARSER_ERROR_INVALID_TRANSFER_ENCODING */:
      err = @makeErrorWithCode(296, "Parse Error");
      break;
    case 8 /* HTTP_PARSER_ERROR_INVALID_EOF */:
      err = @makeErrorWithCode(297, "Parse Error");
      break;
    case 9 /* HTTP_PARSER_ERROR_INVALID_METHOD */:
      err = @makeErrorWithCode(298, "Parse Error: Invalid method encountered"), err.bytesParsed = 1;
      break;
    case 10 /* HTTP_PARSER_ERROR_INVALID_HEADER_TOKEN */:
      err = @makeErrorWithCode(308, "Parse Error: Invalid header token encountered");
      break;
    case 6 /* HTTP_PARSER_ERROR_REQUEST_HEADER_FIELDS_TOO_LARGE */:
      err = @makeErrorWithCode(309, "Parse Error: Header overflow"), err.bytesParsed = rawPacket.byteLength;
      break;
    default:
      err = @makeErrorWithCode(299, "Parse Error");
      break;
  }
  err.rawPacket = rawPacket;
  let existingDuplex = socket.duplex, nodeSocket = existingDuplex ?? new NodeHTTPServerSocket(self, socket, ssl);
  if (!existingDuplex)
    self.emit("connection", nodeSocket);
  if (self.emit("clientError", err, nodeSocket), nodeSocket.listenerCount("error") > 0)
    nodeSocket.emit("error", err);
}
var kBytesWritten = Symbol("kBytesWritten"), kEnableStreaming = Symbol("kEnableStreaming");
function onServerSocketError(_err) {
  this.removeListener("error", onServerSocketError), this.on("error", noopOnError);
}
function noopOnError() {}
var NodeHTTPServerSocket = class Socket extends Duplex {
  bytesRead = 0;
  connecting = !1;
  timeout = 0;
  [kBytesWritten] = 0;
  [kHandle];
  server;
  _httpMessage;
  _secureEstablished = !1;
  #pendingCallback = null;
  constructor(server, handle, encrypted) {
    super();
    this.server = server, this[kHandle] = handle, this._secureEstablished = !!handle?.secureEstablished, handle.onclose = this.#onClose.bind(this), handle.duplex = this, this.encrypted = encrypted, this.on("timeout", onNodeHTTPServerSocketTimeout), this.on("error", onServerSocketError), server[kTrackedConnections]?.add(this);
  }
  get bytesWritten() {
    let handle = this[kHandle];
    return handle ? handle.response?.getBytesWritten?.() ?? handle.bytesWritten ?? this[kBytesWritten] ?? 0 : this[kBytesWritten] ?? 0;
  }
  set bytesWritten(value) {
    this[kBytesWritten] = value;
  }
  [kEnableStreaming](enable) {
    let handle = this[kHandle];
    if (handle)
      if (enable)
        handle.ondata = this.#onData.bind(this), handle.ondrain = this.#onDrain.bind(this);
      else
        handle.ondata = @undefined, handle.ondrain = @undefined;
  }
  #onDrain() {
    let handle = this[kHandle];
    this[kBytesWritten] = handle ? handle.response?.getBytesWritten?.() ?? handle.bytesWritten ?? 0 : 0;
    let callback = this.#pendingCallback;
    if (callback)
      this.#pendingCallback = null, callback();
    this.emit("drain");
  }
  #onData(chunk, last) {
    if (chunk)
      this.push(chunk);
    if (last) {
      let handle = this[kHandle];
      if (handle)
        handle.ondata = @undefined;
      this.push(null);
    }
  }
  #closeHandle(handle, callback, err) {
    this[kHandle] = @undefined, handle.onclose = this.#onCloseForDestroy.bind(this, callback, err), handle.close();
    let req = this._httpMessage?.req;
    if (req && !req.complete)
      req.destroy();
  }
  #onClose() {
    this[kHandle] = null, this.server?.[kTrackedConnections]?.delete(this);
    let message = this._httpMessage, req = message?.req;
    if (req && !req.destroyed && !req[kHandle]?.upgraded)
      if (req[kHandle] = @undefined, req.listenerCount("error") > 0)
        req.destroy(new ConnResetException("aborted"));
      else
        req.destroy();
    if (message && !message._closed)
      process.nextTick(emitCloseNT, message);
  }
  #onCloseForDestroy(closeCallback, err) {
    if (this.#onClose(), @isCallable(closeCallback))
      closeCallback(err);
  }
  _onTimeout() {
    let response = this[kHandle]?.response;
    if (response && response.writableLength > 0)
      return;
    this.emit("timeout");
  }
  _unrefTimer() {}
  address() {
    return this[kHandle]?.remoteAddress || null;
  }
  get bufferSize() {
    return this.writableLength;
  }
  connect(_port, _host, _connectListener) {
    return this;
  }
  _destroy(err, callback) {
    let handle = this[kHandle];
    if (!handle) {
      if (@isCallable(callback))
        callback(err);
      return;
    }
    if (handle.ondata = @undefined, handle.closed) {
      let onclose = handle.onclose;
      if (handle.onclose = @undefined, @isCallable(onclose))
        onclose.@call(handle);
      if (@isCallable(callback))
        callback(err);
      return;
    }
    this.#closeHandle(handle, callback, err);
  }
  _final(callback) {
    let handle = this[kHandle];
    if (!handle) {
      callback();
      return;
    }
    handle.end(), callback();
  }
  get localAddress() {
    return this[kHandle]?.localAddress?.address;
  }
  get localFamily() {
    return this[kHandle]?.localAddress?.family;
  }
  get localPort() {
    return this[kHandle]?.localAddress?.port;
  }
  get pending() {
    return this.connecting;
  }
  #resumeSocket() {
    let handle = this[kHandle], response = handle?.response;
    if (response) {
      let resumed = response.resume();
      if (resumed && resumed !== !0) {
        let bodyReadState = handle.hasBody, req = this._httpMessage?.req;
        if ((bodyReadState & NodeHTTPBodyReadState.done) !== 0)
          emitServerSocketEOFNT(this, req);
        if (req)
          req.push(resumed);
        this.push(resumed);
      }
    }
  }
  _read(_size) {
    this.#resumeSocket();
  }
  get readyState() {
    if (this.connecting)
      return "opening";
    if (this.readable)
      return this.writable ? "open" : "readOnly";
    else
      return this.writable ? "writeOnly" : "closed";
  }
  ref() {
    return this;
  }
  get remoteAddress() {
    return this.address()?.address;
  }
  set remoteAddress(val) {
    this.address().address = val;
  }
  get remotePort() {
    return this.address()?.port;
  }
  set remotePort(val) {
    this.address().port = val;
  }
  get remoteFamily() {
    return this.address()?.family;
  }
  set remoteFamily(val) {
    this.address().family = val;
  }
  resetAndDestroy() {}
  setKeepAlive(_enable = !1, _initialDelay = 0) {}
  setNoDelay(_noDelay = !0) {
    return this;
  }
  setTimeout(_timeout, _callback) {
    return this;
  }
  setEncoding(_encoding) {
    let err = Error("Changing the socket encoding is not allowed per RFC7230 Section 3.");
    throw err.code = "ERR_HTTP_SOCKET_ENCODING", err;
  }
  unref() {
    return this;
  }
  _write(_chunk, _encoding, _callback) {
    let handle = this[kHandle], err;
    try {
      if (handle) {
        if (!handle.write(_chunk, _encoding) && handle.ondrain)
          return this.#pendingCallback = _callback, !1;
      }
    } catch (e) {
      err = e;
    }
    if (err)
      _callback(err);
    else
      _callback();
  }
  pause() {
    let response = this[kHandle]?.response;
    if (response)
      response.pause();
    return super.pause();
  }
  resume() {
    return this.#resumeSocket(), super.resume();
  }
  get [kInternalSocketData]() {
    return this[kHandle]?.response;
  }
};
function _writeHead(statusCode, reason, obj, response) {
  let originalStatusCode = statusCode, hasContentLength = response.hasHeader("content-length");
  if (statusCode |= 0, statusCode < 100 || statusCode > 999)
    throw @makeErrorWithCode(73, format("%s", originalStatusCode));
  if (typeof reason === "string")
    response.statusMessage = reason;
  else {
    if (!response.statusMessage)
      response.statusMessage = STATUS_CODES[statusCode] || "unknown";
    obj ??= reason;
  }
  if (checkInvalidHeaderChar(response.statusMessage))
    throw @makeErrorWithCode(123, "statusMessage");
  response.statusCode = statusCode;
  {
    let k;
    if (@isArray(obj)) {
      let length = obj.length;
      if (length && @isArray(obj[0]))
        for (let i = 0;i < length; i++) {
          let k2 = obj[i];
          if (k2)
            response.appendHeader(k2[0], k2[1]);
        }
      else {
        if (length % 2 !== 0)
          throw @makeErrorWithCode(120, "headers", obj);
        if ((response.chunkedEncoding !== !0 || response.hasHeader("content-length")) && (response._trailer || response.hasHeader("trailer")))
          throw @makeErrorWithCode(74, "Trailers are invalid with this transfer encoding");
        for (let n = 0;n < length; n += 2)
          k = obj[n + 0], response.removeHeader(k);
        for (let n = 0;n < length; n += 2)
          if (k = obj[n], k)
            response.appendHeader(k, obj[n + 1]);
      }
    } else if (obj) {
      let keys = Object.keys(obj), length = keys.length;
      for (let i = 0;i < length; i++)
        if (k = keys[i], k)
          response.setHeader(k, obj[k]);
    }
    if ((response.chunkedEncoding !== !0 || response.hasHeader("content-length")) && (response._trailer || response.hasHeader("trailer"))) {
      if (hasContentLength)
        response.removeHeader("trailer");
      else
        response.removeHeader("content-length");
      throw @makeErrorWithCode(74, "Trailers are invalid with this transfer encoding");
    }
  }
  updateHasBody(response, statusCode);
}
Object.defineProperty(NodeHTTPServerSocket, "name", { value: "Socket" });
function ServerResponse(req, options) {
  if (!(this instanceof ServerResponse))
    return new ServerResponse(req, options);
  if (OutgoingMessage.@call(this, options), this.useChunkedEncodingByDefault = !0, this[kDeprecatedReplySymbol] = options?.[kDeprecatedReplySymbol])
    this[controllerSymbol] = @undefined, this[firstWriteSymbol] = @undefined, this[deferredSymbol] = @undefined, this.write = ServerResponse_writeDeprecated, this.end = ServerResponse_finalDeprecated;
  if (this.req = req, this.sendDate = !0, this._sent100 = !1, this[headerStateSymbol] = NodeHTTPHeaderState.none, this[kPendingCallbacks] = [], this.finished = !1, req.method === "HEAD")
    this._hasBody = !1;
  if (req.httpVersionMajor < 1 || req.httpVersionMinor < 1)
    this.useChunkedEncodingByDefault = chunkExpression.test(req.headers?.te ?? ""), this.shouldKeepAlive = !1;
  if (options) {
    let handle = options[kHandle];
    if (handle)
      this[kHandle] = handle;
    else
      this[kHandle] = req[kHandle];
    if (options[kRejectNonStandardBodyWrites] !== @undefined)
      this[kRejectNonStandardBodyWrites] = options[kRejectNonStandardBodyWrites];
  } else
    this[kHandle] = req[kHandle];
  this.statusCode = 200, this.statusMessage = @undefined, this.chunkedEncoding = !1;
}
@toClass(ServerResponse, "ServerResponse", OutgoingMessage);
function renderNativeHeaders(res) {
  let headersMap = res[kOutHeaders], flat = [], hasDate = !1, hasConnection = !1, hasKeepAlive = !1;
  if (headersMap !== null && headersMap !== @undefined)
    for (let key in headersMap) {
      let entry = headersMap[key], name = entry[0], value = entry[1];
      if (key === "date")
        hasDate = !0;
      else if (key === "connection") {
        if (hasConnection = !0, RE_CONN_CLOSE.test(@isArray(value) ? value.join(", ") : @String(value)))
          res[kMustCloseConnection] = !0;
      } else if (key === "keep-alive")
        hasKeepAlive = !0;
      if (@isArray(value)) {
        let valueLength = value.length;
        if (valueLength < 2 || key !== "cookie")
          for (let i = 0;i < valueLength; i++)
            flat.push(name, @String(value[i]));
        else
          flat.push(name, value.join("; "));
      } else
        flat.push(name, @String(value));
    }
  if (res.sendDate && !hasDate)
    flat.push("Date", utcDate());
  let defectiveNoBodyResponse = !1;
  if (res[kOutHeaders]?.["transfer-encoding"] !== @undefined) {
    let statusCode = res[kSnapshotStatusCode] ?? res.statusCode;
    if (statusCode === 204 || statusCode === 304)
      defectiveNoBodyResponse = !0, res[kMustCloseConnection] = !0;
  }
  let closeDelimited = !1, forceChunked = !1;
  if (res[kOutHeaders]?.["content-length"] === @undefined && res[kOutHeaders]?.["transfer-encoding"] === @undefined) {
    if (res._hasBody === !1)
      ;
    else if (res._removedTE)
      closeDelimited = !0, res[kMustCloseConnection] = !0;
    else if (res._removedContLen)
      forceChunked = !0;
  }
  if (res._removedConnection) {
    if (res.shouldKeepAlive === !1)
      res[kMustCloseConnection] = !0;
  } else if (!hasConnection)
    if (!defectiveNoBodyResponse && !closeDelimited && !res.maxRequestsOnConnectionReached && res.shouldKeepAlive !== !1 && requestShouldKeepAlive(res.req)) {
      flat.push("Connection", "keep-alive");
      let keepAliveTimeout = res._keepAliveTimeout;
      if (keepAliveTimeout && !hasKeepAlive) {
        let max = "", maxRequestsPerSocket = res._maxRequestsPerSocket;
        if (~~maxRequestsPerSocket > 0)
          max = `, max=${maxRequestsPerSocket}`;
        flat.push("Keep-Alive", `timeout=${MathFloor(keepAliveTimeout / 1000)}${max}`);
      }
    } else {
      if (res.shouldKeepAlive === !1)
        res[kMustCloseConnection] = !0;
      flat.push("Connection", "close");
    }
  if (res._hasBody === !1)
    flat.push("\x00", "2");
  if (closeDelimited)
    flat.push("\x00", "1");
  else if (forceChunked)
    flat.push("Transfer-Encoding", "chunked");
  return flat;
}
var kMustCloseConnection = Symbol("kMustCloseConnection");
function stopServerResponsePerf() {
  if (this[kServerResponseStatistics] && hasObserver("http"))
    stopPerf(this, kServerResponseStatistics, {
      detail: {
        res: {
          statusCode: this.statusCode,
          statusMessage: this.statusMessage,
          headers: typeof this.getHeaders === "function" ? this.getHeaders() : {}
        }
      }
    });
}
function endSocketOnFinishIfNeeded(socket, res) {
  if (res[kMustCloseConnection])
    socket?.end();
}
var RE_CONN_CLOSE = /(?:^|\W)close(?:$|\W)/i, RE_CONN_UPGRADE = /(?:^|\W)upgrade(?:$|\W)/i;
function requestShouldKeepAlive(req) {
  if (!req)
    return !0;
  let connection = req.headers.connection;
  if (req.httpVersionMajor === 1 && req.httpVersionMinor === 0)
    return !1;
  return !(typeof connection === "string" && RE_CONN_CLOSE.test(connection));
}
function isHTTPServerHeaderStateSentOrAssigned(state) {
  return state === NodeHTTPHeaderState.sent || state === NodeHTTPHeaderState.assigned;
}
function throwIfServerHeadersSent(self, action) {
  if (isHTTPServerHeaderStateSentOrAssigned(self[headerStateSymbol]))
    throw @makeErrorWithCode(70, action);
}
ServerResponse.prototype.setHeader = function setHeader(name, value) {
  return throwIfServerHeadersSent(this, "set"), OutgoingMessagePrototype.setHeader.@call(this, name, value);
};
ServerResponse.prototype.appendHeader = function appendHeader(name, value) {
  return throwIfServerHeadersSent(this, "append"), OutgoingMessagePrototype.appendHeader.@call(this, name, value);
};
ServerResponse.prototype.setHeaders = function setHeaders(headers) {
  return throwIfServerHeadersSent(this, "set"), OutgoingMessagePrototype.setHeaders.@call(this, headers);
};
ServerResponse.prototype.removeHeader = function removeHeader(name) {
  return throwIfServerHeadersSent(this, "remove"), OutgoingMessagePrototype.removeHeader.@call(this, name);
};
Object.defineProperty(ServerResponse.prototype, "headers", {
  get() {
    return this.getHeaders();
  },
  set(value) {
    if (throwIfServerHeadersSent(this, "set"), this[kOutHeaders] = null, !value)
      return;
    if (@isArray(value))
      for (let { 0: key, 1: val } of value)
        this.appendHeader(key, val);
    else if (typeof value.entries === "function")
      for (let { 0: key, 1: val } of value.entries())
        this.appendHeader(key, val);
    else {
      let keys = ObjectKeys(value);
      for (let i = 0;i < keys.length; i++)
        this.setHeader(keys[i], value[keys[i]]);
    }
  }
});
Object.defineProperty(ServerResponse.prototype, "socket", {
  get() {
    return this[fakeSocketSymbol] ??= new FakeSocket(this);
  },
  set(value) {
    this[fakeSocketSymbol] = value, this[kSocket] = value;
  }
});
Object.defineProperty(ServerResponse.prototype, "connection", {
  get() {
    return this.socket;
  },
  set(value) {
    this.socket = value;
  }
});
Object.defineProperty(ServerResponse.prototype, "chunkedEncoding", {
  get() {
    return this[kChunkedEncoding] ?? !1;
  },
  set(value) {
    this[kChunkedEncoding] = value;
  }
});
Object.defineProperty(ServerResponse.prototype, "writableCorked", {
  get() {
    return this.socket.writableCorked;
  },
  set(_value) {}
});
ServerResponse.prototype.cork = function cork() {
  this.socket.cork();
};
ServerResponse.prototype.uncork = function uncork() {
  this.socket.uncork();
};
ServerResponse.prototype.setTimeout = function setTimeout2(msecs, callback) {
  if (callback)
    this.on("timeout", callback);
  if (!this[fakeSocketSymbol])
    this.once("socket", function socketSetTimeoutOnConnect(socket) {
      socket.setTimeout(msecs);
    });
  else
    this.socket.setTimeout(msecs);
  return this;
};
ServerResponse.prototype._removedConnection = !1;
ServerResponse.prototype._removedContLen = !1;
ServerResponse.prototype._hasBody = !0;
ServerResponse.prototype._ended = !1;
ServerResponse.prototype[kRejectNonStandardBodyWrites] = @undefined;
Object.defineProperty(ServerResponse.prototype, "headersSent", {
  get() {
    return this[headerStateSymbol] === NodeHTTPHeaderState.sent || this[headerStateSymbol] === NodeHTTPHeaderState.assigned;
  },
  set(value) {
    this[headerStateSymbol] = value ? NodeHTTPHeaderState.sent : NodeHTTPHeaderState.none;
  }
});
ServerResponse.prototype._writeRaw = function(chunk, encoding, callback) {
  if (!this[kHandle])
    return OutgoingMessagePrototype._writeRaw.@apply(this, arguments);
  return this.socket.write(chunk, encoding, callback);
};
ServerResponse.prototype.writeEarlyHints = function(hints, cb) {
  if (validateObject(hints, "hints"), hints.link === null || hints.link === @undefined)
    return;
  let link = validateLinkHeaderValue(hints.link);
  if (link.length === 0)
    return;
  if (checkInvalidHeaderChar(link))
    throw @makeErrorWithCode(123, "header content", "Link");
  let headers = { __proto__: null, Link: link }, keys = ObjectKeys(hints);
  for (let i = 0;i < keys.length; i++) {
    let key = keys[i];
    if (key !== "link")
      headers[key] = hints[key];
  }
  this.writeInformation(103, headers, cb);
};
function processInformationHeader(name, value) {
  return validateHeaderName(name), validateHeaderValue(name, value), `${name}: ${value}\r
`;
}
ServerResponse.prototype.writeInformation = function writeInformation(statusCode, headers, cb) {
  if (this.headersSent)
    throw @makeErrorWithCode(70, "write");
  if (validateInteger(statusCode, "statusCode", 100, 199), statusCode === 101)
    throw @makeErrorWithCode(73, statusCode);
  let statusMessage = STATUS_CODES[statusCode] || "unknown", head = `HTTP/1.1 ${statusCode} ${statusMessage}\r
`;
  if (headers !== @undefined && headers !== null)
    if (@isArray(headers)) {
      let headersLength = headers.length;
      if (headersLength && @isArray(headers[0]))
        for (let i = 0;i < headersLength; i++) {
          let entry = headers[i];
          head += processInformationHeader(entry[0], entry[1]);
        }
      else {
        if (headersLength % 2 !== 0)
          throw @makeErrorWithCode(120, "headers", headers);
        for (let i = 0;i < headersLength; i += 2)
          head += processInformationHeader(headers[i], headers[i + 1]);
      }
    } else {
      validateObject(headers, "headers");
      let keys = ObjectKeys(headers);
      for (let i = 0;i < keys.length; i++) {
        let key = keys[i];
        head += processInformationHeader(key, headers[key]);
      }
    }
  return head += `\r
`, this._writeRaw(head, "ascii", cb);
};
ServerResponse.prototype.writeProcessing = function(cb) {
  return this.writeInformation(102, null, cb);
};
ServerResponse.prototype.writeContinue = function(cb) {
  if (this.headersSent)
    throw @makeErrorWithCode(70, "write");
  if (!this[kHandle]) {
    this.writeInformation(100, null, cb), this._sent100 = !0;
    return;
  }
  this.socket[kHandle]?.response?.writeContinue(), this._sent100 = !0, cb?.();
};
ServerResponse.prototype.end = function(chunk, encoding, callback) {
  let handle = this[kHandle];
  if (handle?.aborted)
    return this;
  if (@isCallable(chunk))
    callback = chunk, chunk = @undefined, encoding = @undefined;
  else if (@isCallable(encoding))
    callback = encoding, encoding = @undefined;
  else if (!@isCallable(callback))
    callback = @undefined;
  if (hasServerResponseFinished(this, chunk, callback))
    return this;
  if (!handle) {
    if (this[fakeSocketSymbol] || this.outputData?.length || !this._header)
      return OutgoingMessagePrototype.end.@call(this, chunk, encoding, callback);
    if (@isCallable(callback))
      process.nextTick(callback);
    return this;
  }
  if (this[headerStateSymbol] === NodeHTTPHeaderState.none)
    updateHasBody(this, this.statusCode);
  if (chunk && !this._hasBody)
    if (this[kRejectNonStandardBodyWrites])
      throw @makeErrorWithCode(69);
    else
      chunk = @undefined;
  let headerState = this[headerStateSymbol];
  if (callWriteHeadIfObservable(this, headerState), handle.flags & NodeHTTPResponseFlags.closed_or_completed)
    return !0;
  if (headerState !== NodeHTTPHeaderState.sent)
    handle.cork(() => {
      handle.writeHead(this[kSnapshotStatusCode] ?? this.statusCode, this[kSnapshotStatusMessage] ?? this.statusMessage, renderNativeHeaders(this)), this[headerStateSymbol] = NodeHTTPHeaderState.sent, this._contentLength = handle.end(chunk, encoding, @undefined, strictContentLength(this));
    });
  else if (!(!chunk && handle.ended) && !handle.aborted)
    handle.end(chunk, encoding, @undefined, strictContentLength(this));
  this._header = " ";
  let req = this.req, socket = this[fakeSocketSymbol] ?? req.socket;
  if (!req._consuming && !req?._readableState?.resumeScheduled)
    req._dump();
  if (this.detachSocket(socket), this.finished = !0, process.nextTick((self) => {
    self._ended = !0;
  }, this), this.emit("prefinish"), this._callPendingCallbacks(), callback)
    process.nextTick(function(callback2, self) {
      self.emit("finish");
      try {
        callback2();
      } catch (err) {
        self.emit("error", err);
      }
      process.nextTick(emitCloseNT, self);
    }, callback, this);
  else
    process.nextTick(function(self) {
      self.emit("finish"), process.nextTick(emitCloseNT, self);
    }, this);
  return this;
};
Object.defineProperty(ServerResponse.prototype, "writable", {
  get() {
    return !0;
  },
  set(_value) {}
});
ServerResponse.prototype.write = function(chunk, encoding, callback) {
  let handle = this[kHandle];
  if (@isCallable(chunk))
    callback = chunk, chunk = @undefined, encoding = @undefined;
  else if (@isCallable(encoding))
    callback = encoding, encoding = @undefined;
  else if (!@isCallable(callback))
    callback = @undefined;
  if (hasServerResponseFinished(this, chunk, callback))
    return !1;
  let result = 0, headerState = this[headerStateSymbol];
  if (callWriteHeadIfObservable(this, headerState), !handle)
    return OutgoingMessagePrototype.write.@call(this, chunk, encoding, callback);
  if (this[headerStateSymbol] === NodeHTTPHeaderState.none)
    updateHasBody(this, this.statusCode);
  if (chunk && !this._hasBody)
    if (this[kRejectNonStandardBodyWrites])
      throw @makeErrorWithCode(69);
    else
      chunk = @undefined;
  if (handle.flags & NodeHTTPResponseFlags.closed_or_completed)
    return !0;
  if (this[headerStateSymbol] !== NodeHTTPHeaderState.sent)
    handle.cork(() => {
      handle.writeHead(this[kSnapshotStatusCode] ?? this.statusCode, this[kSnapshotStatusMessage] ?? this.statusMessage, renderNativeHeaders(this)), this[headerStateSymbol] = NodeHTTPHeaderState.sent, result = handle.write(chunk, encoding, allowWritesToContinue.bind(this), strictContentLength(this));
    });
  else
    result = handle.write(chunk, encoding, allowWritesToContinue.bind(this), strictContentLength(this));
  if (result < 0) {
    if (callback)
      this[kPendingCallbacks].push(callback);
    return !1;
  }
  if (this._callPendingCallbacks(), callback)
    process.nextTick(callback);
  let written = 0;
  if (chunk) {
    if (written = typeof chunk === "string" ? @Buffer.byteLength(chunk, encoding) : chunk.length, written > 0 && this.getHeader("content-length") === @undefined)
      written += written.toString(16).length + 4;
  }
  if (written > 0) {
    if (this[kBytesBuffered] = (this[kBytesBuffered] ?? 0) + written, scheduleWriteAccountingFlush(this), this[kBytesBuffered] >= this.writableHighWaterMark)
      return !1;
  }
  return !0;
};
var kBytesBuffered = Symbol("kBytesBuffered"), kAccountingFlushScheduled = Symbol("kAccountingFlushScheduled");
function flushWriteAccountingNT(res) {
  res[kAccountingFlushScheduled] = !1;
  let needsDrain = (res[kBytesBuffered] ?? 0) >= res.writableHighWaterMark;
  if (res[kBytesBuffered] = 0, needsDrain && !res.destroyed && !res.finished)
    res.emit("drain");
}
function scheduleWriteAccountingFlush(res) {
  if (res[kAccountingFlushScheduled])
    return;
  res[kAccountingFlushScheduled] = !0, process.nextTick(flushWriteAccountingNT, res);
}
ServerResponse.prototype._callPendingCallbacks = function() {
  let originalLength = this[kPendingCallbacks].length;
  for (let i = 0;i < originalLength; ++i)
    process.nextTick(this[kPendingCallbacks][i]);
  if (this[kPendingCallbacks].length == originalLength)
    this[kPendingCallbacks] = [];
  else
    this[kPendingCallbacks].splice(0, originalLength);
};
ServerResponse.prototype._finish = function() {
  this.emit("prefinish");
};
ServerResponse.prototype.detachSocket = function(socket) {
  if (socket && socket._httpMessage === this) {
    if (socket[kCloseCallback])
      socket[kCloseCallback] = @undefined;
    if (socket.removeListener("close", onServerResponseClose), socket._httpMessage = null, socket[kRequest] === this.req)
      socket[kRequest] = @undefined;
  }
  this.socket = null;
};
ServerResponse.prototype._implicitHeader = function() {
  if (this.headersSent)
    return;
  this.writeHead(this.statusCode);
};
Object.defineProperty(ServerResponse.prototype, "writableNeedDrain", {
  get() {
    return !this.destroyed && !this.finished && ((this[kHandle]?.bufferedAmount ?? 0) !== 0 || (this[kBytesBuffered] ?? 0) >= this.writableHighWaterMark);
  }
});
Object.defineProperty(ServerResponse.prototype, "writableFinished", {
  get() {
    return !!(this.finished && (!this[kHandle] || this[kHandle].finished));
  }
});
Object.defineProperty(ServerResponse.prototype, "writableLength", {
  get() {
    if (this.writableFinished)
      return 0;
    return (this[kBytesBuffered] ?? 0) + (this[kHandle]?.bufferedAmount ?? 0);
  }
});
Object.defineProperty(ServerResponse.prototype, "writableHighWaterMark", {
  get() {
    return this.socket?.writableHighWaterMark ?? this[kHighWaterMark] ?? 65536;
  }
});
Object.defineProperty(ServerResponse.prototype, "closed", {
  get() {
    return this._closed;
  }
});
ServerResponse.prototype._send = function(data, encoding, callback, _byteLength) {
  let handle = this[kHandle];
  if (!handle)
    return OutgoingMessagePrototype._send.@apply(this, arguments);
  if (this[headerStateSymbol] !== NodeHTTPHeaderState.sent)
    handle.cork(() => {
      handle.writeHead(this[kSnapshotStatusCode] ?? this.statusCode, this[kSnapshotStatusMessage] ?? this.statusMessage, renderNativeHeaders(this)), this[headerStateSymbol] = NodeHTTPHeaderState.sent, handle.write(data, encoding, callback, strictContentLength(this));
    });
  else
    handle.write(data, encoding, callback, strictContentLength(this));
};
var kSnapshotStatusCode = Symbol("kSnapshotStatusCode"), kSnapshotStatusMessage = Symbol("kSnapshotStatusMessage");
ServerResponse.prototype.writeHead = function(statusCode, statusMessage, headers) {
  if (this.headersSent)
    throw @makeErrorWithCode(70, "writeHead");
  if (_writeHead(statusCode, statusMessage, headers, this), this[kSnapshotStatusCode] = this.statusCode, this[kSnapshotStatusMessage] = this.statusMessage, this[headerStateSymbol] = NodeHTTPHeaderState.assigned, !this[kHandle] && !this._header) {
    let statusLine = `HTTP/1.1 ${this.statusCode} ${this.statusMessage}\r
`;
    this._storeHeader(statusLine, this[kOutHeaders]);
  }
  return this;
};
ServerResponse.prototype.assignSocket = function(socket) {
  if (socket._httpMessage)
    throw @makeErrorWithCode(75, "Socket already assigned");
  socket._httpMessage = this, socket.once("close", onServerResponseClose), this.socket = socket, this.emit("socket", socket), this._flush();
};
Object.defineProperty(ServerResponse.prototype, "shouldKeepAlive", {
  get() {
    return this[kShouldKeepAlive] ?? !0;
  },
  set(value) {
    this[kShouldKeepAlive] = value;
  }
});
ServerResponse.prototype.destroy = function(err) {
  if (this.destroyed)
    return this;
  let handle = this[kHandle];
  if (this.destroyed = !0, this[kErrored] = err, handle)
    handle.abort();
  if (this?.socket?.destroy(err), !this._closed)
    this._closed = !0, this.emit("close");
  return this;
};
ServerResponse.prototype.emit = function(event) {
  if (event === "close")
    callCloseCallback(this);
  return Stream.prototype.emit.@apply(this, arguments);
};
ServerResponse.prototype.flushHeaders = function() {
  if (this[headerStateSymbol] === NodeHTTPHeaderState.sent)
    return;
  if (this[headerStateSymbol] !== NodeHTTPHeaderState.assigned)
    this._implicitHeader();
  let handle = this[kHandle];
  if (handle) {
    if (this[headerStateSymbol] === NodeHTTPHeaderState.assigned)
      this[headerStateSymbol] = NodeHTTPHeaderState.sent, handle.writeHead(this[kSnapshotStatusCode] ?? this.statusCode, this[kSnapshotStatusMessage] ?? this.statusMessage, renderNativeHeaders(this));
    handle.flushHeaders();
  } else
    this._send("");
};
function updateHasBody(response, statusCode) {
  if (statusCode === 204 || statusCode === 304 || statusCode >= 100 && statusCode <= 199)
    response._hasBody = !1;
}
function emitServerSocketEOF(self, req) {
  if (self.push(null), req)
    req.push(null), req.complete = !0;
}
function emitServerSocketEOFNT(self, req) {
  if (req)
    req[eofInProgress] = !0;
  process.nextTick(emitServerSocketEOF, self);
}
var OriginalWriteHeadFn, OriginalImplicitHeadFn;
function callWriteHeadIfObservable(self, headerState) {
  if (headerState === NodeHTTPHeaderState.none && !(self.writeHead === OriginalWriteHeadFn && self._implicitHeader === OriginalImplicitHeadFn))
    self.writeHead(self.statusCode, self.statusMessage);
}
function allowWritesToContinue() {
  this._callPendingCallbacks(), this.emit("drain");
}
function drainHeadersIfObservable() {
  if (this._implicitHeader === OriginalImplicitHeadFn && this.writeHead === OriginalWriteHeadFn)
    return;
  this._implicitHeader();
}
function ServerResponse_finalDeprecated(chunk, encoding, callback) {
  if (@isCallable(encoding))
    callback = encoding, encoding = @undefined;
  if (!@isCallable(callback))
    callback = @undefined;
  if (this.destroyed || this.finished) {
    if (chunk)
      emitErrorNextTickIfErrorListenerNT(this, @makeErrorWithCode(241), callback);
    return !1;
  }
  if (encoding && encoding !== "buffer")
    chunk = @Buffer.from(chunk, encoding);
  let req = this.req, shouldEmitClose = req && req.emit && !this.finished;
  if (!this.headersSent) {
    let data = this[firstWriteSymbol];
    if (chunk)
      if (data) {
        if (encoding)
          data = @Buffer.from(data, encoding);
        data = new Blob([data, chunk]);
      } else
        data = chunk;
    else if (!data)
      data = @undefined;
    else
      data = new Blob([data]);
    if (this[firstWriteSymbol] = @undefined, this.finished = !0, this.headersSent = !0, drainHeadersIfObservable.@call(this), this[kDeprecatedReplySymbol](new Response(data, {
      headers: this.getHeaders(),
      status: this.statusCode,
      statusText: this.statusMessage ?? STATUS_CODES[this.statusCode]
    })), shouldEmitClose)
      req.complete = !0, process.nextTick(emitRequestCloseNT, req);
    callback?.();
    return;
  }
  this.finished = !0, ensureReadableStreamController.@call(this, (controller) => {
    if (chunk && encoding)
      chunk = @Buffer.from(chunk, encoding);
    let prom;
    if (chunk)
      controller.write(chunk), prom = controller.end();
    else
      prom = controller.end();
    let handler = () => {
      callback();
      let deferred = this[deferredSymbol];
      if (deferred)
        this[deferredSymbol] = @undefined, deferred();
    };
    if (@isPromise(prom))
      prom.then(handler, handler);
    else
      handler();
  });
}
OriginalWriteHeadFn = ServerResponse.prototype.writeHead;
OriginalImplicitHeadFn = ServerResponse.prototype._implicitHeader;
function defaultShouldUpgradeCallback() {
  return this.listenerCount("upgrade") > 0;
}
function storeHTTPOptions(options) {
  this[kIncomingMessage] = options.IncomingMessage || IncomingMessage, this[kServerResponse] = options.ServerResponse || ServerResponse;
  let maxHeaderSize = options.maxHeaderSize;
  if (maxHeaderSize !== @undefined)
    validateInteger(maxHeaderSize, "maxHeaderSize", 0);
  this.maxHeaderSize = maxHeaderSize;
  let insecureHTTPParser = options.insecureHTTPParser;
  if (insecureHTTPParser !== @undefined)
    validateBoolean(insecureHTTPParser, "options.insecureHTTPParser");
  this.insecureHTTPParser = insecureHTTPParser;
  let requestTimeout = options.requestTimeout;
  if (requestTimeout !== @undefined)
    validateInteger(requestTimeout, "requestTimeout", 0), this.requestTimeout = requestTimeout;
  else
    this.requestTimeout = 300000;
  let headersTimeout = options.headersTimeout;
  if (headersTimeout !== @undefined)
    validateInteger(headersTimeout, "headersTimeout", 0), this.headersTimeout = headersTimeout;
  else
    this.headersTimeout = MathMin(60000, this.requestTimeout);
  if (this.requestTimeout > 0 && this.headersTimeout > 0 && this.headersTimeout > this.requestTimeout)
    throw @makeErrorWithCode(160, "headersTimeout", "<= requestTimeout", headersTimeout);
  let keepAliveTimeout = options.keepAliveTimeout;
  if (keepAliveTimeout !== @undefined)
    validateInteger(keepAliveTimeout, "keepAliveTimeout", 0), this.keepAliveTimeout = keepAliveTimeout;
  else
    this.keepAliveTimeout = 5000;
  let connectionsCheckingInterval = options.connectionsCheckingInterval;
  if (connectionsCheckingInterval !== @undefined)
    validateInteger(connectionsCheckingInterval, "connectionsCheckingInterval", 0), this.connectionsCheckingInterval = connectionsCheckingInterval;
  else
    this.connectionsCheckingInterval = 30000;
  let requireHostHeader = options.requireHostHeader;
  if (requireHostHeader !== @undefined)
    validateBoolean(requireHostHeader, "options.requireHostHeader"), this.requireHostHeader = requireHostHeader;
  else
    this.requireHostHeader = !0;
  let joinDuplicateHeaders = options.joinDuplicateHeaders;
  if (joinDuplicateHeaders !== @undefined)
    validateBoolean(joinDuplicateHeaders, "options.joinDuplicateHeaders");
  this.joinDuplicateHeaders = joinDuplicateHeaders;
  let shouldUpgradeCallback = options.shouldUpgradeCallback;
  if (shouldUpgradeCallback !== @undefined)
    validateFunction(shouldUpgradeCallback, "options.shouldUpgradeCallback"), this.shouldUpgradeCallback = shouldUpgradeCallback;
  else
    this.shouldUpgradeCallback = defaultShouldUpgradeCallback;
  let rejectNonStandardBodyWrites = options.rejectNonStandardBodyWrites;
  if (rejectNonStandardBodyWrites !== @undefined)
    validateBoolean(rejectNonStandardBodyWrites, "options.rejectNonStandardBodyWrites"), this.rejectNonStandardBodyWrites = rejectNonStandardBodyWrites;
  else
    this.rejectNonStandardBodyWrites = !1;
  let optimizeEmptyRequests = options.optimizeEmptyRequests;
  if (optimizeEmptyRequests !== @undefined)
    validateBoolean(optimizeEmptyRequests, "options.optimizeEmptyRequests");
  this[kOptimizeEmptyRequests] = optimizeEmptyRequests || !1;
}
function ensureReadableStreamController(run) {
  let thisController = this[controllerSymbol];
  if (thisController)
    return run(thisController);
  this.headersSent = !0;
  let firstWrite = this[firstWriteSymbol], old_run = this[runSymbol];
  if (old_run) {
    old_run.push(run);
    return;
  }
  this[runSymbol] = [run], this[kDeprecatedReplySymbol](new Response(new @ReadableStream({
    type: "direct",
    pull: (controller) => {
      if (this[controllerSymbol] = controller, firstWrite)
        controller.write(firstWrite);
      firstWrite = @undefined;
      for (let run2 of this[runSymbol])
        run2(controller);
      if (!this.finished) {
        let { promise, resolve } = @newPromiseCapability(GlobalPromise);
        return this[deferredSymbol] = resolve, promise;
      }
    }
  }), {
    headers: this.getHeaders(),
    status: this.statusCode,
    statusText: this.statusMessage ?? STATUS_CODES[this.statusCode]
  }));
}
$ = {
  Server,
  ServerResponse,
  kConnectionsCheckingInterval
};
return $

})
