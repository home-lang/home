(function () {"use strict";
// zig-out/http-tls-graph-port-2026-10-10/generated/InternalClusterIsPrimary.mts
var $;
$ = {
  isPrimary: Bun.env.NODE_UNIQUE_ID == null
};
return $

})
