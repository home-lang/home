import http from 'node:http'
import { spawn, exec } from 'node:child_process'
import { mkdtempSync, openSync, ftruncateSync, closeSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { createHash } from 'node:crypto'
const mode = process.argv[2]
if (mode === 'request') {
  let bytes = 0
  process.on('exit', () => console.error('client exit', bytes))
  http.get({ port: +process.argv[3], path: '/' }, res => {
    res.on('data', chunk => { bytes += chunk.length })
    for (const event of ['end', 'close', 'aborted']) res.on(event, () => console.error('client', event, bytes))
    res.pipe(process.stdout)
  })
} else if (mode === 'hash') {
  const hash = createHash('sha1')
  let bytes = 0
  process.stdin.on('data', chunk => { bytes += chunk.length; hash.update(chunk) })
  process.stdin.on('end', () => console.error('stdin end', bytes))
  process.stdin.on('close', () => { console.error('stdin close', bytes); process.stdout.write(hash.digest('hex')) })
} else {
  const directory = mkdtempSync(join(tmpdir(), 'home-chunk-pipeline-'))
  const file = join(directory, 'big')
  const fd = openSync(file, 'w'); ftruncateSync(fd, 10 * 1024 * 1024); closeSync(fd)
  const server = http.createServer((req, res) => {
    let bytes = 0, backpressure = 0
    res.writeHead(200)
    const cat = spawn('cat', [file])
    cat.stdout.on('data', chunk => { bytes += chunk.length; if (!res.write(chunk)) backpressure++ })
    cat.stdout.on('end', () => { console.error('cat end', bytes, backpressure); res.end() })
    for (const event of ['finish', 'close']) res.on(event, () => console.error('server', event, bytes))
  })
  server.listen(0, () => {
    exec('"$NODE" "$FILE" request ' + server.address().port + ' | "$NODE" "$FILE" hash', {
      env: { ...process.env, NODE: process.execPath, FILE: import.meta.filename },
    }, (error, stdout, stderr) => {
      console.log(JSON.stringify({ error: error && String(error), stdout, stderr }))
      server.close(() => rmSync(directory, { recursive: true, force: true }))
    })
  })
}
