var $;
"use strict";

const ObjectKeys = Object.keys;
const ObjectDefineProperty = Object.defineProperty;

const customPromisify = Symbol.for("nodejs.util.promisify.custom");
const { streamReturningOperators, promiseReturningOperators } = (__intrinsic__getInternalField(__intrinsic__internalModuleRegistry, 70) || __intrinsic__createInternalModuleById(70));
const compose = (__intrinsic__getInternalField(__intrinsic__internalModuleRegistry, 48) || __intrinsic__createInternalModuleById(48));
const { setDefaultHighWaterMark, getDefaultHighWaterMark } = (__intrinsic__getInternalField(__intrinsic__internalModuleRegistry, 74) || __intrinsic__createInternalModuleById(74));
const { pipeline } = (__intrinsic__getInternalField(__intrinsic__internalModuleRegistry, 72) || __intrinsic__createInternalModuleById(72));
const { destroyer } = (__intrinsic__getInternalField(__intrinsic__internalModuleRegistry, 49) || __intrinsic__createInternalModuleById(49));
const eos = (__intrinsic__getInternalField(__intrinsic__internalModuleRegistry, 53) || __intrinsic__createInternalModuleById(53));
const promises = (__intrinsic__getInternalField(__intrinsic__internalModuleRegistry, 45) || __intrinsic__createInternalModuleById(45));
const utils = (__intrinsic__getInternalField(__intrinsic__internalModuleRegistry, 76) || __intrinsic__createInternalModuleById(76));
const { isArrayBufferView, isUint8Array } = (__intrinsic__getInternalField(__intrinsic__internalModuleRegistry, 164) || __intrinsic__createInternalModuleById(164));
const Stream = (__intrinsic__getInternalField(__intrinsic__internalModuleRegistry, 68) || __intrinsic__createInternalModuleById(68)).Stream;

Stream.isDestroyed = utils.isDestroyed;
Stream.isDisturbed = utils.isDisturbed;
Stream.isErrored = utils.isErrored;
Stream.isReadable = utils.isReadable;
Stream.isWritable = utils.isWritable;

Stream.Readable = (__intrinsic__getInternalField(__intrinsic__internalModuleRegistry, 73) || __intrinsic__createInternalModuleById(73));
const streamKeys = ObjectKeys(streamReturningOperators);
for (let i = 0; i < streamKeys.length; i++) {
  const key = streamKeys[i];
  const op = streamReturningOperators[key];
  function fn(...args) {
    if (new.target) {
      throw __intrinsic__makeErrorWithCode(115, );
    }
    return Stream.Readable.from(op.__intrinsic__apply(this, args));
  }
  ObjectDefineProperty(fn, "name", { __proto__: null, value: op.name });
  ObjectDefineProperty(fn, "length", { __proto__: null, value: op.length });
  ObjectDefineProperty(Stream.Readable.prototype, key, {
    __proto__: null,
    value: fn,
    enumerable: false,
    configurable: true,
    writable: true,
  });
}
const promiseKeys = ObjectKeys(promiseReturningOperators);
for (let i = 0; i < promiseKeys.length; i++) {
  const key = promiseKeys[i];
  const op = promiseReturningOperators[key];
  function fn(...args) {
    if (new.target) {
      throw __intrinsic__makeErrorWithCode(115, );
    }
    return Promise.__intrinsic__resolve().then(() => op.__intrinsic__apply(this, args));
  }
  ObjectDefineProperty(fn, "name", { __proto__: null, value: op.name });
  ObjectDefineProperty(fn, "length", { __proto__: null, value: op.length });
  ObjectDefineProperty(Stream.Readable.prototype, key, {
    __proto__: null,
    value: fn,
    enumerable: false,
    configurable: true,
    writable: true,
  });
}
Stream.Writable = (__intrinsic__getInternalField(__intrinsic__internalModuleRegistry, 77) || __intrinsic__createInternalModuleById(77));
Stream.Duplex = (__intrinsic__getInternalField(__intrinsic__internalModuleRegistry, 50) || __intrinsic__createInternalModuleById(50));
Stream.Transform = (__intrinsic__getInternalField(__intrinsic__internalModuleRegistry, 75) || __intrinsic__createInternalModuleById(75));
Stream.PassThrough = (__intrinsic__getInternalField(__intrinsic__internalModuleRegistry, 71) || __intrinsic__createInternalModuleById(71));
Stream.duplexPair = (__intrinsic__getInternalField(__intrinsic__internalModuleRegistry, 52) || __intrinsic__createInternalModuleById(52));
Stream.pipeline = pipeline;
const { addAbortSignal } = (__intrinsic__getInternalField(__intrinsic__internalModuleRegistry, 47) || __intrinsic__createInternalModuleById(47));
Stream.addAbortSignal = addAbortSignal;
Stream.finished = eos;
Stream.destroy = destroyer;
Stream.compose = compose;
Stream.setDefaultHighWaterMark = setDefaultHighWaterMark;
Stream.getDefaultHighWaterMark = getDefaultHighWaterMark;

ObjectDefineProperty(Stream, "promises", {
  __proto__: null,
  configurable: true,
  enumerable: true,
  get() {
    return promises;
  },
});

ObjectDefineProperty(pipeline, customPromisify, {
  __proto__: null,
  enumerable: true,
  get() {
    return promises.pipeline;
  },
});

ObjectDefineProperty(eos, customPromisify, {
  __proto__: null,
  enumerable: true,
  get() {
    return promises.finished;
  },
});

// Backwards-compat with node 0.4.x
Stream.Stream = Stream;

Stream._isArrayBufferView = isArrayBufferView;
Stream._isUint8Array = isUint8Array;
Stream._uint8ArrayToBuffer = function _uint8ArrayToBuffer(chunk) {
  return new __intrinsic__Buffer(chunk.buffer, chunk.byteOffset, chunk.byteLength);
};

$ = Stream;
;$$EXPORT$$($).$$EXPORT_END$$;
