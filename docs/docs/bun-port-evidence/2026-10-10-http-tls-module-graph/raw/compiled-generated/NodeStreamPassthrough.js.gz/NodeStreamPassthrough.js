(function () {"use strict";
// .zig-cache/o/8a4449a75d845ea6cf5295895b03fd23/native-modules/NodeStreamPassthrough.mts
var $;
$ = @getInternalField(@internalModuleRegistry, 71) || @createInternalModuleById(71);
return $

})
