(function () {"use strict";
// .zig-cache/o/8a4449a75d845ea6cf5295895b03fd23/native-modules/NodePathPosix.mts
var $;
$ = (@getInternalField(@internalModuleRegistry, 125) || @createInternalModuleById(125)).posix;
return $

})
