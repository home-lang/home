(function () {"use strict";
// .zig-cache/o/8a4449a75d845ea6cf5295895b03fd23/native-modules/NodeDNSPromises.mts
var $;
$ = (@getInternalField(@internalModuleRegistry, 112) || @createInternalModuleById(112)).promises;
return $

})
