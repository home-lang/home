(function () {"use strict";
// .zig-cache/o/8a4449a75d845ea6cf5295895b03fd23/native-modules/NodeStreamDuplex.mts
var $;
$ = @getInternalField(@internalModuleRegistry, 50) || @createInternalModuleById(50);
return $

})
