var $;
// Hardcoded module "node:path/posix"
$ = (__intrinsic__getInternalField(__intrinsic__internalModuleRegistry, 125) || __intrinsic__createInternalModuleById(125)).posix;
;$$EXPORT$$($).$$EXPORT_END$$;
