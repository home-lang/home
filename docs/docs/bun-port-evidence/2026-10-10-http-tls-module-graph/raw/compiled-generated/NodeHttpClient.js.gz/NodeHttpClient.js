(function () {"use strict";
// .zig-cache/o/8a4449a75d845ea6cf5295895b03fd23/native-modules/NodeHttpClient.mts
var $, net = @getInternalField(@internalModuleRegistry, 122) || @createInternalModuleById(122), { kEmptyObject, once, ConnResetException, hasObserver, startPerf, stopPerf } = @getInternalField(@internalModuleRegistry, 38) || @createInternalModuleById(38), kClientRequestStatistics = Symbol("ClientRequestStatistics"), {
  _checkIsHttpToken: checkIsHttpToken,
  freeParser,
  parsers,
  HTTPParser,
  isLenient,
  prepareError,
  kSkipPendingData
} = @getInternalField(@internalModuleRegistry, 91) || @createInternalModuleById(91), { kUniqueHeaders, parseUniqueHeadersOption, OutgoingMessage } = @getInternalField(@internalModuleRegistry, 93) || @createInternalModuleById(93), Agent = @getInternalField(@internalModuleRegistry, 89) || @createInternalModuleById(89), { urlToHttpOptions } = @getInternalField(@internalModuleRegistry, 81) || @createInternalModuleById(81), { kOutHeaders, kNeedDrain, kProxyConfig, checkShouldUseProxy } = @getInternalField(@internalModuleRegistry, 31) || @createInternalModuleById(31), { validateInteger, validateBoolean, validateString } = @getInternalField(@internalModuleRegistry, 86) || @createInternalModuleById(86), { getTimerDuration } = @getInternalField(@internalModuleRegistry, 78) || @createInternalModuleById(78), { addAbortSignal } = @getInternalField(@internalModuleRegistry, 47) || @createInternalModuleById(47), finished = @getInternalField(@internalModuleRegistry, 53) || @createInternalModuleById(53), dc = @getInternalField(@internalModuleRegistry, 110) || @createInternalModuleById(110), ObjectAssign = Object.assign, ObjectDefineProperty = Object.defineProperty, ObjectKeys = Object.keys, NumberIsFinite = Number.isFinite, ArrayIsArray = @Array.isArray, onClientRequestCreatedChannel = dc.channel("http.client.request.created"), onClientRequestStartChannel = dc.channel("http.client.request.start"), onClientRequestErrorChannel = dc.channel("http.client.request.error"), onClientResponseFinishChannel = dc.channel("http.client.response.finish");
function emitErrorEvent(request, error) {
  if (onClientRequestErrorChannel.hasSubscribers)
    onClientRequestErrorChannel.publish({
      request,
      error
    });
  request.emit("error", error);
}
function onCreateConnection(err, socket) {
  if (err)
    process.nextTick(emitErrorEvent, this, err);
  else
    this.onSocket(socket);
}
var INVALID_PATH_REGEX = /[^\u0021-\u00ff]/, kError = Symbol("kError"), kPath = Symbol("kPath"), kLenientAll = HTTPParser.kLenientAll | 0, kLenientNone = HTTPParser.kLenientNone | 0;
function validateHost(host, name) {
  if (host !== null && host !== @undefined && typeof host !== "string")
    throw @makeErrorWithCode(119, `options.${name}`, ["string", "undefined", "null"], host);
  return host;
}

class HTTPClientAsyncResource {
  type;
  req;
  constructor(type, req) {
    this.type = type, this.req = req;
  }
}
function isURLInstance(input) {
  return input != null && typeof input === "object" && input instanceof URL;
}
function rewriteForProxiedHttp(req, reqOptions) {
  if (req._header)
    return !1;
  let agent = req.agent;
  if (!agent || !agent[kProxyConfig])
    return !1;
  if ((reqOptions.protocol || agent.protocol) !== "http:")
    return !1;
  if (!checkShouldUseProxy(agent[kProxyConfig], reqOptions))
    return !1;
  let { auth } = agent[kProxyConfig];
  if (auth)
    req.setHeader("proxy-authorization", auth);
  if (req.shouldKeepAlive)
    req.setHeader("proxy-connection", "keep-alive");
  else
    req.setHeader("proxy-connection", "close");
  let requestBase = `http://${req.getHeader("host") || "localhost"}`, requestURL = new URL(req.path, requestBase), reqOptionsPort = reqOptions.port;
  if (reqOptionsPort)
    requestURL.port = reqOptionsPort;
  return req.path = requestURL.href, !0;
}
function ClientRequest(input, options, cb) {
  if (!(this instanceof ClientRequest))
    return new ClientRequest(input, options, cb);
  if (OutgoingMessage.@call(this), typeof input === "string")
    input = urlToHttpOptions(new URL(input));
  else if (isURLInstance(input))
    input = urlToHttpOptions(input);
  else
    cb = options, options = input, input = null;
  if (typeof options === "function")
    cb = options, options = input || kEmptyObject;
  else
    options = ObjectAssign({ __proto__: null }, input, options);
  let agent = options.agent, defaultAgent = options._defaultAgent || Agent.globalAgent;
  if (agent === !1)
    agent = new defaultAgent.constructor;
  else if (agent === null || agent === @undefined) {
    if (typeof options.createConnection !== "function")
      agent = defaultAgent;
  } else if (typeof agent.addRequest !== "function")
    throw @makeErrorWithCode(119, "options.agent", ["Agent-like Object", "undefined", "false"], agent);
  this.agent = agent;
  let protocol = options.protocol || defaultAgent.protocol, expectedProtocol = defaultAgent.protocol, agentProtocol = this.agent?.protocol;
  if (agentProtocol)
    expectedProtocol = agentProtocol;
  let optionsPath = options.path;
  if (optionsPath) {
    let path = @String(optionsPath);
    if (INVALID_PATH_REGEX.test(path))
      throw @makeErrorWithCode(258, "Request path");
  }
  if (protocol !== expectedProtocol)
    throw @makeErrorWithCode(135, protocol, expectedProtocol);
  let defaultPort = options.defaultPort || this.agent?.defaultPort, optsWithoutSignal = { __proto__: null, ...options }, port = optsWithoutSignal.port = options.port || defaultPort || 80, host = optsWithoutSignal.host = validateHost(options.hostname, "hostname") || validateHost(options.host, "host") || "localhost", setHost = options.setHost !== @undefined ? Boolean(options.setHost) : options.setDefaultHeaders !== !1;
  this._removedConnection = options.setDefaultHeaders === !1, this._removedContLen = options.setDefaultHeaders === !1, this._removedTE = options.setDefaultHeaders === !1, this.socketPath = options.socketPath;
  let optionsTimeout = options.timeout;
  if (optionsTimeout !== @undefined)
    this.timeout = getTimerDuration(optionsTimeout, "timeout");
  let signal = options.signal;
  if (signal)
    addAbortSignal(signal, this), delete optsWithoutSignal.signal;
  let method = options.method;
  if (method != null)
    validateString(method, "options.method");
  if (method) {
    if (!checkIsHttpToken(method))
      throw @makeErrorWithCode(129, "Method", method);
    method = this.method = method.toUpperCase();
  } else
    method = this.method = "GET";
  let maxHeaderSize = options.maxHeaderSize;
  if (maxHeaderSize !== @undefined)
    validateInteger(maxHeaderSize, "maxHeaderSize", 0);
  this.maxHeaderSize = maxHeaderSize;
  let insecureHTTPParser = options.insecureHTTPParser;
  if (insecureHTTPParser !== @undefined)
    validateBoolean(insecureHTTPParser, "options.insecureHTTPParser");
  this.insecureHTTPParser = insecureHTTPParser;
  let joinDuplicateHeaders = options.joinDuplicateHeaders;
  if (joinDuplicateHeaders !== @undefined)
    validateBoolean(joinDuplicateHeaders, "options.joinDuplicateHeaders");
  if (this.joinDuplicateHeaders = joinDuplicateHeaders, this[kPath] = options.path || "/", cb)
    this.once("response", cb);
  if (method === "GET" || method === "HEAD" || method === "DELETE" || method === "OPTIONS" || method === "TRACE" || method === "CONNECT")
    this.useChunkedEncodingByDefault = !1;
  else
    this.useChunkedEncodingByDefault = !0;
  this._ended = !1, this.res = null, this.aborted = !1, this.timeoutCb = null, this.upgradeOrConnect = !1, this.parser = null, this.maxHeadersCount = null, this.reusedSocket = !1, this.host = host, this.protocol = protocol;
  let thisAgent = this.agent;
  if (thisAgent)
    if (!thisAgent.keepAlive && !NumberIsFinite(thisAgent.maxSockets))
      this._last = !0, this.shouldKeepAlive = !1;
    else
      this._last = !1, this.shouldKeepAlive = !0;
  let optionsHeaders = options.headers;
  if (!ArrayIsArray(optionsHeaders)) {
    if (optionsHeaders) {
      let keys = ObjectKeys(optionsHeaders);
      for (let i = 0;i < keys.length; i++) {
        let key = keys[i];
        this.setHeader(key, optionsHeaders[key]);
      }
    }
    if (host && !this.getHeader("host") && setHost) {
      let hostHeader = host, posColon = hostHeader.indexOf(":");
      if (posColon !== -1 && hostHeader.includes(":", posColon + 1) && hostHeader.charCodeAt(0) !== 91)
        hostHeader = `[${hostHeader}]`;
      if (port && +port !== defaultPort)
        hostHeader += ":" + port;
      this.setHeader("Host", hostHeader);
    }
    let auth = options.auth;
    if (auth && !this.getHeader("Authorization"))
      this.setHeader("Authorization", "Basic " + @Buffer.from(auth).toString("base64"));
    if (this.getHeader("expect")) {
      if (this._header)
        throw @makeErrorWithCode(70, "render");
      rewriteForProxiedHttp(this, optsWithoutSignal), this._storeHeader(this.method + " " + this.path + ` HTTP/1.1\r
`, this[kOutHeaders]);
    } else
      rewriteForProxiedHttp(this, optsWithoutSignal);
  } else
    rewriteForProxiedHttp(this, optsWithoutSignal), this._storeHeader(this.method + " " + this.path + ` HTTP/1.1\r
`, optionsHeaders);
  if (this[kUniqueHeaders] = parseUniqueHeadersOption(options.uniqueHeaders), thisAgent)
    thisAgent.addRequest(this, optsWithoutSignal);
  else {
    this._last = !0, this.shouldKeepAlive = !1;
    let opts = optsWithoutSignal, socketPath;
    if (opts.path || (socketPath = opts.socketPath))
      if (opts = { ...optsWithoutSignal }, socketPath ??= opts.socketPath, socketPath)
        opts.path = socketPath;
      else
        opts.path &&= @undefined;
    if (typeof opts.createConnection === "function") {
      let oncreate = once(onCreateConnection.bind(this));
      try {
        let newSocket = opts.createConnection(opts, oncreate);
        if (newSocket)
          oncreate(null, newSocket);
      } catch (err) {
        oncreate(err);
      }
    } else
      this.onSocket(net.createConnection(opts));
  }
  if (onClientRequestCreatedChannel.hasSubscribers)
    onClientRequestCreatedChannel.publish({
      request: this
    });
}
@toClass(ClientRequest, "ClientRequest", OutgoingMessage);
ObjectDefineProperty(ClientRequest.prototype, "path", {
  __proto__: null,
  get() {
    return this[kPath];
  },
  set(value) {
    let path = @String(value);
    if (INVALID_PATH_REGEX.test(path))
      throw @makeErrorWithCode(258, "Request path");
    this[kPath] = path;
  },
  configurable: !0,
  enumerable: !0
});
ClientRequest.prototype._finish = function _finish() {
  if (OutgoingMessage.prototype._finish.@call(this), hasObserver("http"))
    startPerf(this, kClientRequestStatistics, {
      type: "http",
      name: "HttpClient",
      detail: {
        req: {
          method: this.method,
          url: `${this.protocol}//${this.host}${this.path}`,
          headers: typeof this.getHeaders === "function" ? this.getHeaders() : {}
        }
      }
    });
  if (onClientRequestStartChannel.hasSubscribers)
    onClientRequestStartChannel.publish({
      request: this
    });
};
ClientRequest.prototype._implicitHeader = function _implicitHeader() {
  if (this._header)
    throw @makeErrorWithCode(70, "render");
  this._storeHeader(this.method + " " + this.path + ` HTTP/1.1\r
`, this[kOutHeaders]);
};
ClientRequest.prototype.abort = function abort() {
  if (this.aborted)
    return;
  this.aborted = !0, process.nextTick(emitAbortNT, this), this.destroy();
};
ClientRequest.prototype.destroy = function destroy(err) {
  if (this.destroyed)
    return this;
  this.destroyed = !0;
  let res = this.res;
  if (res)
    res._dump();
  return this[kError] = err, this.socket?.destroy(err), this;
};
function emitAbortNT(req) {
  req.emit("abort");
}
function ondrain() {
  let msg = this._httpMessage;
  if (msg && !msg.finished && msg[kNeedDrain])
    msg[kNeedDrain] = !1, msg.emit("drain");
}
function socketCloseListener() {
  let socket = this, req = socket._httpMessage, parser = socket.parser, res = req.res;
  if (req.destroyed = !0, res) {
    if (!res.complete)
      res.destroy(new ConnResetException("aborted"));
    if (req._closed = !0, req.emit("close"), !res.aborted && res.readable)
      res.push(null);
  } else {
    if (!req.socket._hadError)
      req.socket._hadError = !0, emitErrorEvent(req, new ConnResetException("socket hang up"));
    req._closed = !0, req.emit("close");
  }
  let outputData = req.outputData;
  if (outputData)
    outputData.length = 0;
  if (parser)
    parser.finish(), freeParser(parser, req, socket);
}
function socketErrorListener(err) {
  let socket = this, req = socket._httpMessage;
  if (req)
    socket._hadError = !0, emitErrorEvent(req, err);
  let parser = socket.parser;
  if (parser)
    parser.finish(), freeParser(parser, req, socket);
  socket.removeListener("data", socketOnData), socket.removeListener("end", socketOnEnd), socket.destroy();
}
function socketOnEnd() {
  let socket = this, req = this._httpMessage, parser = this.parser;
  if (!req.res && !req.socket._hadError)
    req.socket._hadError = !0, emitErrorEvent(req, new ConnResetException("socket hang up"));
  if (parser)
    parser.finish(), freeParser(parser, req, socket);
  socket.destroy();
}
function socketOnData(d) {
  let socket = this, req = this._httpMessage, parser = this.parser, ret = parser.execute(d);
  if (ret instanceof Error)
    prepareError(ret, parser, d), freeParser(parser, req, socket), socket.removeListener("data", socketOnData), socket.removeListener("end", socketOnEnd), socket.destroy(), req.socket._hadError = !0, emitErrorEvent(req, ret);
  else {
    let res = parser.incoming;
    if (res?.upgrade) {
      let bytesParsed = ret;
      req.res = res, socket.removeListener("data", socketOnData), socket.removeListener("end", socketOnEnd), socket.removeListener("drain", ondrain);
      let timeoutCb = req.timeoutCb;
      if (timeoutCb)
        socket.removeListener("timeout", timeoutCb);
      socket.removeListener("timeout", responseOnTimeout), parser.finish(), freeParser(parser, req, socket);
      let bodyHead = d.slice(bytesParsed, d.length), eventName = req.method === "CONNECT" ? "connect" : "upgrade";
      if (req.listenerCount(eventName) > 0)
        req.upgradeOrConnect = !0, socket.emit("agentRemove"), socket.removeListener("close", socketCloseListener), socket.removeListener("error", socketErrorListener), socket._httpMessage = null, socket.readableFlowing = null, req.emit(eventName, res, socket, bodyHead), req.destroyed = !0, req._closed = !0, req.emit("close");
      else
        socket.destroy();
    } else if (res?.complete && !statusIsInformational(res.statusCode))
      socket.removeListener("data", socketOnData), socket.removeListener("end", socketOnEnd), socket.removeListener("drain", ondrain), freeParser(parser, req, socket);
  }
}
function statusIsInformational(status) {
  return status < 200 && status >= 100 && status !== 101;
}
function parserOnIncomingClient(res, shouldKeepAlive) {
  let socket = this.socket, req = socket._httpMessage, existingRes = req.res;
  if (existingRes) {
    socket.destroy();
    let parser = socket.parser;
    if (parser)
      parser.incoming = existingRes, parser.incoming[kSkipPendingData] = !0;
    return 0;
  }
  if (req.res = res, res.upgrade)
    return 2;
  let method = req.method;
  if (method === "CONNECT")
    return res.upgrade = !0, 2;
  let statusCode = res.statusCode;
  if (statusIsInformational(statusCode)) {
    if (req.res = null, statusCode === 100)
      req.emit("continue");
    return req.emit("information", {
      statusCode,
      statusMessage: res.statusMessage,
      httpVersion: res.httpVersion,
      httpVersionMajor: res.httpVersionMajor,
      httpVersionMinor: res.httpVersionMinor,
      headers: res.headers,
      rawHeaders: res.rawHeaders
    }), 1;
  }
  if (req.shouldKeepAlive && !shouldKeepAlive && !req.upgradeOrConnect)
    req.shouldKeepAlive = !1;
  if (req[kClientRequestStatistics] && hasObserver("http"))
    stopPerf(req, kClientRequestStatistics, {
      detail: {
        res: {
          statusCode: res.statusCode,
          statusMessage: res.statusMessage,
          headers: res.headers
        }
      }
    });
  if (onClientResponseFinishChannel.hasSubscribers)
    onClientResponseFinishChannel.publish({
      request: req,
      response: res
    });
  if (req.res = res, res.req = req, res.on("end", responseOnEnd), req.on("finish", requestOnFinish), socket.on("timeout", responseOnTimeout), req.aborted || !req.emit("response", res))
    res._dump();
  if (method === "HEAD")
    return 1;
  if (res.statusCode === 304)
    return res.complete = !0, 1;
  return 0;
}
function responseKeepAlive(req) {
  let socket = req.socket;
  if (req.timeoutCb)
    socket.setTimeout(0, req.timeoutCb), req.timeoutCb = null;
  socket.removeListener("close", socketCloseListener), socket.removeListener("error", socketErrorListener), socket.removeListener("data", socketOnData), socket.removeListener("end", socketOnEnd), process.nextTick(emitFreeNT, req), req.destroyed = !0;
  let reqRes = req.res;
  if (reqRes)
    reqRes.socket = null;
}
function responseOnEnd() {
  let req = this.req, socket = req.socket;
  if (socket) {
    if (req.timeoutCb)
      socket.removeListener("timeout", emitRequestTimeout);
    socket.removeListener("timeout", responseOnTimeout);
  }
  if (req._ended = !0, !req.shouldKeepAlive) {
    if (socket.writable)
      if (typeof socket.destroySoon === "function")
        socket.destroySoon();
      else
        socket.end();
  } else if (req.writableFinished && !this.aborted)
    responseKeepAlive(req);
}
function responseOnTimeout() {
  let req = this._httpMessage;
  if (!req)
    return;
  let res = req.res;
  if (!res)
    return;
  res.emit("timeout");
}
function requestOnFinish() {
  let req = this;
  if (req.shouldKeepAlive && req._ended && !req.destroyed)
    responseKeepAlive(req);
}
function emitFreeNT(req) {
  req._closed = !0, req.emit("close");
  let socket = req.socket;
  if (socket)
    socket.emit("free");
}
function tickOnSocket(req, socket) {
  let parser = parsers.alloc();
  req.socket = socket;
  let lenient = req.insecureHTTPParser === @undefined ? isLenient() : req.insecureHTTPParser;
  parser.initialize(HTTPParser.RESPONSE, new HTTPClientAsyncResource("HTTPINCOMINGMESSAGE", req), req.maxHeaderSize || 0, lenient ? kLenientAll : kLenientNone), parser.socket = socket, parser.outgoing = req, req.parser = parser, socket.parser = parser, socket._httpMessage = req;
  let maxHeadersCount = req.maxHeadersCount;
  if (typeof maxHeadersCount === "number")
    parser.maxHeaderPairs = maxHeadersCount << 1;
  if (parser.joinDuplicateHeaders = req.joinDuplicateHeaders, parser.onIncoming = parserOnIncomingClient, socket.on("data", socketOnData), socket.on("end", socketOnEnd), socket.on("close", socketCloseListener), socket.on("drain", ondrain), req.timeout !== @undefined || req.agent?.options?.timeout)
    listenSocketTimeout(req);
  req.emit("socket", socket);
}
function emitRequestTimeout() {
  let req = this._httpMessage;
  if (req)
    req.emit("timeout");
}
function onSocketListenTimeout(socket) {
  socket.once("timeout", emitRequestTimeout);
}
function listenSocketTimeout(req) {
  if (req.timeoutCb)
    return;
  req.timeoutCb = emitRequestTimeout;
  let reqSocket = req.socket;
  if (reqSocket)
    reqSocket.once("timeout", emitRequestTimeout);
  else
    req.on("socket", onSocketListenTimeout);
}
ClientRequest.prototype.onSocket = function onSocket(socket, err) {
  if (socket && !err)
    socket._httpMessage = this, socket.on("error", socketErrorListener);
  process.nextTick(onSocketNT, this, socket, err);
};
function destroyRequestOnSocketNT(req, socket, err) {
  if (!req.aborted && !err)
    err = new ConnResetException("socket hang up");
  if (err && err.code !== "ERR_PROXY_TUNNEL" && !socket?._hadError)
    emitErrorEvent(req, err);
  req._closed = !0, req.emit("close");
}
function onSocketNT(req, socket, err) {
  if (req.destroyed || err) {
    if (req.destroyed = !0, socket)
      if (!err && req.agent && !socket.destroyed)
        socket.emit("free"), socket.removeListener("error", socketErrorListener);
      else {
        finished(socket.destroy(err || req[kError]), onSocketFinishedDestroy.bind(@undefined, req, socket, err));
        return;
      }
    destroyRequestOnSocketNT(req, socket, err || req[kError]);
  } else
    tickOnSocket(req, socket), req._flush();
}
function onSocketFinishedDestroy(req, socket, err, er) {
  if (er?.code === "ERR_STREAM_PREMATURE_CLOSE")
    er = null;
  destroyRequestOnSocketNT(req, socket, er || err);
}
function callSocketMethod(method, arguments_) {
  if (method)
    this.socket[method].@apply(this.socket, arguments_);
}
function deferToConnectOnSocket(method, arguments_) {
  if (this.socket.writable)
    callSocketMethod.@call(this, method, arguments_);
  else
    this.socket.once("connect", callSocketMethod.bind(this, method, arguments_));
}
ClientRequest.prototype._deferToConnect = _deferToConnect;
function _deferToConnect(method, arguments_) {
  if (!this.socket)
    this.once("socket", deferToConnectOnSocket.bind(this, method, arguments_));
  else
    deferToConnectOnSocket.@call(this, method, arguments_);
}
ClientRequest.prototype.setTimeout = function setTimeout(msecs, callback) {
  if (this._ended)
    return this;
  if (listenSocketTimeout(this), msecs = getTimerDuration(msecs, "msecs"), callback)
    this.once("timeout", callback);
  let socket = this.socket;
  if (socket)
    setSocketTimeout(socket, msecs);
  else
    this.once("socket", onSocketSetTimeout.bind(@undefined, msecs));
  return this;
};
function onSocketSetTimeout(msecs, sock) {
  setSocketTimeout(sock, msecs);
}
function setSocketTimeout(sock, msecs) {
  if (sock.connecting)
    sock.once("connect", function() {
      sock.setTimeout(msecs);
    });
  else
    sock.setTimeout(msecs);
}
ClientRequest.prototype.setNoDelay = function setNoDelay(noDelay) {
  this._deferToConnect("setNoDelay", [noDelay]);
};
ClientRequest.prototype.setSocketKeepAlive = function setSocketKeepAlive(enable, initialDelay) {
  this._deferToConnect("setKeepAlive", [enable, initialDelay]);
};
ClientRequest.prototype.clearTimeout = function clearTimeout(cb) {
  this.setTimeout(0, cb);
};
$ = {
  ClientRequest
};
return $

})
