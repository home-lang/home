(function () {"use strict";
// .zig-cache/o/8a4449a75d845ea6cf5295895b03fd23/native-modules/NodeStream.mts
var $, exports = @getInternalField(@internalModuleRegistry, 46) || @createInternalModuleById(46);
exports.eos = @getInternalField(@internalModuleRegistry, 53) || @createInternalModuleById(53);
$ = exports;
return $

})
