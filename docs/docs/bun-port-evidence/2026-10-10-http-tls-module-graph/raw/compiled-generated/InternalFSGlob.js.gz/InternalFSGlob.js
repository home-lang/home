(function () {"use strict";
// .zig-cache/o/8a4449a75d845ea6cf5295895b03fd23/native-modules/InternalFSGlob.mts
var $, { validateObject, validateString, validateBoolean, validateArray } = @getInternalField(@internalModuleRegistry, 86) || @createInternalModuleById(86), { join, resolve, basename, dirname, isAbsolute } = @getInternalField(@internalModuleRegistry, 125) || @createInternalModuleById(125), { kEmptyObject } = @getInternalField(@internalModuleRegistry, 38) || @createInternalModuleById(38);
var _fs;
function lazyFs() {
  return _fs ??= @getInternalField(@internalModuleRegistry, 116) || @createInternalModuleById(116);
}
var _fsPromises;
function lazyFsPromises() {
  return _fsPromises ??= @getInternalField(@internalModuleRegistry, 115) || @createInternalModuleById(115);
}
function compareDirentName(a, b) {
  return a.name < b.name ? -1 : a.name > b.name ? 1 : 0;
}
function identity(v) {
  return v;
}
function nullOnReject() {
  return null;
}
function emptyArrayOnReject() {
  return [];
}
function excludeNothing(_path) {
  return !1;
}
function makeMatchersExclude(matchers) {
  return function isExcludedByMatchers(value) {
    for (let matcher of matchers)
      if (matcher.match(value))
        return !0;
    return !1;
  };
}
function statForFileTypes(cache, root, path) {
  return cache.statSync(isAbsolute(path) ? path : join(root, path));
}
var kStats = Symbol("stats"), _DirentFromStats;
function lazyDirentFromStats() {
  if (_DirentFromStats === @undefined) {
    let { Dirent } = lazyFs();

    class DirentFromStats extends Dirent {
      constructor(name, stats, path) {
        super(name, null, path);
        this[kStats] = stats;
      }
    }
    for (let key of [
      "isBlockDevice",
      "isCharacterDevice",
      "isDirectory",
      "isFIFO",
      "isFile",
      "isSocket",
      "isSymbolicLink"
    ])
      DirentFromStats.prototype[key] = function() {
        return this[kStats][key]();
      };
    _DirentFromStats = DirentFromStats;
  }
  return _DirentFromStats;
}
function toPathIfFileURL(url) {
  if (url == null || typeof url === "string")
    return url;
  if (url instanceof URL || typeof url === "object" && typeof url.href === "string" && typeof url.protocol === "string")
    return Bun.fileURLToPath(url);
  return url;
}
async function getDirent(path) {
  let stat;
  try {
    stat = await lazyFsPromises().lstat(path);
  } catch {
    return null;
  }
  return new (lazyDirentFromStats())(basename(path), stat, dirname(path));
}
function sortDirents(dirents) {
  return dirents.sort(compareDirentName);
}
function getDirentSync(path) {
  let stat;
  try {
    stat = lazyFs().lstatSync(path);
  } catch {
    return null;
  }
  return new (lazyDirentFromStats())(basename(path), stat, dirname(path));
}
function validateStringArrayOrFunction(value, name) {
  if (@isArray(value)) {
    for (let i = 0;i < value.length; ++i)
      if (typeof value[i] !== "string")
        throw @makeErrorWithCode(119, `${name}[${i}]`, "string", value[i]);
    return;
  }
  if (typeof value !== "function")
    throw @makeErrorWithCode(119, name, ["string[]", "function"], value);
}
function validateStringArray(value, name) {
  validateArray(value, name);
  for (let i = 0;i < value.length; ++i)
    validateString(value[i], `${name}[${i}]`);
}
function createMatcher(pattern, options = kEmptyObject) {
  let opts = {
    __proto__: null,
    nocase: !0,
    windowsPathsNoEscape: !0,
    nonegate: !0,
    nocomment: !0,
    optimizationLevel: 2,
    platform: "darwin",
    nocaseMagicOnly: !0,
    ...options
  };
  return new (lazyMinimatch()).Minimatch(pattern, opts);
}
function cloneSet(values) {
  let cloned = /* @__PURE__ */ new Set;
  for (let value of values)
    cloned.add(value);
  return cloned;
}

class Cache {
  #cache = /* @__PURE__ */ new Map;
  #statsCache = /* @__PURE__ */ new Map;
  #followStatsCache = /* @__PURE__ */ new Map;
  #readdirCache = /* @__PURE__ */ new Map;
  #realpathCache = /* @__PURE__ */ new Map;
  stat(path) {
    let cached = this.#statsCache.get(path);
    if (cached)
      return cached;
    let promise = getDirent(path);
    return this.#statsCache.set(path, promise), promise;
  }
  statSync(path) {
    let cached = this.#statsCache.get(path);
    if (cached && !(cached instanceof @Promise))
      return cached;
    let val = getDirentSync(path);
    return this.#statsCache.set(path, val), val;
  }
  followStat(path) {
    let cached = this.#followStatsCache.get(path);
    if (cached)
      return cached;
    let promise = lazyFsPromises().stat(path).then(identity, nullOnReject);
    return this.#followStatsCache.set(path, promise), promise;
  }
  followStatSync(path) {
    let cached = this.#followStatsCache.get(path);
    if (cached && !(cached instanceof @Promise))
      return cached;
    let val;
    try {
      val = lazyFs().statSync(path);
    } catch {
      val = null;
    }
    return this.#followStatsCache.set(path, val), val;
  }
  realpath(path) {
    let cached = this.#realpathCache.get(path);
    if (cached)
      return cached;
    let promise = lazyFsPromises().realpath(path).then(identity, nullOnReject);
    return this.#realpathCache.set(path, promise), promise;
  }
  realpathSync(path) {
    let cached = this.#realpathCache.get(path);
    if (cached && !(cached instanceof @Promise))
      return cached;
    let val;
    try {
      val = lazyFs().realpathSync(path);
    } catch {
      val = null;
    }
    return this.#realpathCache.set(path, val), val;
  }
  addToStatCache(path, val) {
    this.#statsCache.set(path, val);
  }
  async readdir(path) {
    let cached = this.#readdirCache.get(path);
    if (cached)
      return cached;
    let promise = lazyFsPromises().readdir(path, { __proto__: null, withFileTypes: !0 }).then(sortDirents, emptyArrayOnReject);
    return this.#readdirCache.set(path, promise), promise;
  }
  readdirSync(path) {
    let cached = this.#readdirCache.get(path);
    if (cached)
      return cached;
    let val;
    try {
      val = sortDirents(lazyFs().readdirSync(path, { __proto__: null, withFileTypes: !0 }));
    } catch {
      val = [];
    }
    return this.#readdirCache.set(path, val), val;
  }
  add(path, pattern) {
    let cache = this.#cache.get(path);
    if (!cache)
      cache = /* @__PURE__ */ new Set, this.#cache.set(path, cache);
    let originalSize = cache.size;
    for (let index of pattern.indexes)
      cache.add(pattern.cacheKey(index));
    return cache.size !== originalSize + pattern.indexes.size;
  }
  seen(path, pattern, index) {
    return this.#cache.get(path)?.has(pattern.cacheKey(index));
  }
}

class Pattern {
  #pattern;
  #globStrings;
  indexes;
  symlinks;
  realpaths;
  last;
  constructor(pattern, globStrings, indexes, symlinks, realpaths = /* @__PURE__ */ new Set) {
    this.#pattern = pattern, this.#globStrings = globStrings, this.indexes = indexes, this.symlinks = symlinks, this.realpaths = realpaths, this.last = pattern.length - 1;
  }
  isLast(isDirectory) {
    return this.indexes.has(this.last) || this.at(-1) === "" && isDirectory && this.indexes.has(this.last - 1) && this.at(-2) === lazyMinimatch().GLOBSTAR;
  }
  isFirst() {
    return this.indexes.has(0);
  }
  get hasSeenSymlinks() {
    for (let i of this.indexes)
      if (!this.symlinks.has(i))
        return !0;
    return !1;
  }
  at(index) {
    return this.#pattern.at(index);
  }
  child(indexes, symlinks = /* @__PURE__ */ new Set, realpaths = this.realpaths) {
    return new Pattern(this.#pattern, this.#globStrings, indexes, symlinks, realpaths);
  }
  test(index, path) {
    if (index > this.#pattern.length)
      return !1;
    let pattern = this.#pattern[index];
    if (pattern === lazyMinimatch().GLOBSTAR)
      return !0;
    if (typeof pattern === "string")
      return pattern === path;
    if (typeof pattern?.test === "function")
      return pattern.test(path);
    return !1;
  }
  cacheKey(index) {
    let key = "";
    for (let i = index;i < this.#globStrings.length; i++)
      if (key += this.#globStrings[i], i !== this.#globStrings.length - 1)
        key += "/";
    return key;
  }
}

class ResultSet extends Set {
  #root = ".";
  #isExcluded = excludeNothing;
  setup(root, isExcludedFn) {
    this.#root = root, this.#isExcluded = isExcludedFn;
  }
  add(value) {
    if (this.#isExcluded(resolve(this.#root, value)))
      return !1;
    return super.add(value), !0;
  }
}

class Glob {
  #root;
  #exclude;
  #cache = new Cache;
  #results = new ResultSet;
  #queue = [];
  #subpatterns = /* @__PURE__ */ new Map;
  #patterns;
  #withFileTypes;
  #followSymlinks = !1;
  #isExcluded = excludeNothing;
  matchers;
  constructor(pattern, options = kEmptyObject) {
    validateObject(options, "options");
    let { exclude, cwd, followSymlinks, withFileTypes } = options;
    if (this.#root = toPathIfFileURL(cwd) ?? process.cwd(), followSymlinks != null)
      validateBoolean(followSymlinks, "options.followSymlinks"), this.#followSymlinks = followSymlinks;
    if (this.#withFileTypes = !!withFileTypes, exclude != null)
      if (validateStringArrayOrFunction(exclude, "options.exclude"), @isArray(exclude)) {
        let matchers = [];
        for (let pat of exclude)
          matchers.push(createMatcher(resolve(this.#root, pat)));
        this.#isExcluded = makeMatchersExclude(matchers), this.#results.setup(this.#root, this.#isExcluded);
      } else
        this.#exclude = exclude;
    let patterns;
    if (typeof pattern === "object")
      validateStringArray(pattern, "patterns"), patterns = pattern;
    else
      validateString(pattern, "patterns"), patterns = [pattern];
    this.matchers = [], this.#patterns = [];
    for (let pat of patterns) {
      let matcher = createMatcher(pat);
      this.matchers.push(matcher);
      for (let i = 0;i < matcher.set.length; i++)
        this.#patterns.push(new Pattern(matcher.set[i], matcher.globParts[i], (/* @__PURE__ */ new Set()).add(0), /* @__PURE__ */ new Set));
    }
  }
  globSync() {
    this.#queue.push({ __proto__: null, path: ".", patterns: this.#patterns });
    while (this.#queue.length > 0) {
      let item = this.#queue.pop();
      for (let i = 0;i < item.patterns.length; i++)
        this.#addSubpatterns(item.path, item.patterns[i]);
      for (let [path, patterns] of this.#subpatterns)
        this.#queue.push({ __proto__: null, path, patterns });
      this.#subpatterns.clear();
    }
    return @Array.from(this.#results, this.#withFileTypes ? statForFileTypes.bind(null, this.#cache, this.#root) : @undefined);
  }
  #isDirectorySync(path, stat, pattern) {
    if (stat?.isDirectory())
      return !0;
    if (!stat?.isSymbolicLink())
      return !1;
    if (this.#followSymlinks)
      return !!this.#cache.followStatSync(path)?.isDirectory();
    return pattern.hasSeenSymlinks;
  }
  async#isDirectory(path, stat, pattern) {
    if (stat?.isDirectory())
      return !0;
    if (!stat?.isSymbolicLink())
      return !1;
    if (this.#followSymlinks)
      return !!(await this.#cache.followStat(path))?.isDirectory();
    return pattern.hasSeenSymlinks;
  }
  #nextRealpathsSync(path, isDirectory, pattern) {
    if (!this.#followSymlinks || !isDirectory)
      return pattern.realpaths;
    let real = this.#cache.realpathSync(path);
    if (real === null)
      return pattern.realpaths;
    let realpaths = cloneSet(pattern.realpaths);
    return realpaths.add(real), realpaths;
  }
  async#nextRealpaths(path, isDirectory, pattern) {
    if (!this.#followSymlinks || !isDirectory)
      return pattern.realpaths;
    let real = await this.#cache.realpath(path);
    if (real === null)
      return pattern.realpaths;
    let realpaths = cloneSet(pattern.realpaths);
    return realpaths.add(real), realpaths;
  }
  async#isCyclic(path, isDirectory, pattern) {
    if (!this.#followSymlinks || !isDirectory)
      return !1;
    let real = await this.#cache.realpath(path);
    return real !== null && pattern.realpaths.has(real);
  }
  #isCyclicSync(path, isDirectory, pattern) {
    if (!this.#followSymlinks || !isDirectory)
      return !1;
    let real = this.#cache.realpathSync(path);
    return real !== null && pattern.realpaths.has(real);
  }
  #addSubpattern(path, pattern) {
    if (this.#isExcluded(path))
      return;
    let fullpath = resolve(this.#root, path);
    if (this.#isExcluded(`${fullpath}/`) && this.#cache.statSync(fullpath).isDirectory())
      return;
    if (this.#exclude) {
      if (this.#withFileTypes) {
        let stat = this.#cache.statSync(fullpath);
        if (stat !== null) {
          if (this.#exclude(stat))
            return;
        }
      } else if (this.#exclude(path))
        return;
    }
    if (!this.#subpatterns.has(path))
      this.#subpatterns.set(path, [pattern]);
    else
      this.#subpatterns.get(path).push(pattern);
  }
  #addSubpatterns(path, pattern) {
    if (this.#cache.add(path, pattern))
      return;
    let fullpath = resolve(this.#root, path), stat = this.#cache.statSync(fullpath), last = pattern.last, isDirectory = this.#isDirectorySync(fullpath, stat, pattern), isLast = pattern.isLast(isDirectory), isFirst = pattern.isFirst();
    if (this.#isExcluded(fullpath))
      return;
    if (isFirst && pattern.at(0) === "") {
      this.#addSubpattern("/", pattern.child((/* @__PURE__ */ new Set()).add(1)));
      return;
    }
    if (isFirst && pattern.at(0) === "..") {
      this.#addSubpattern("../", pattern.child((/* @__PURE__ */ new Set()).add(1)));
      return;
    }
    if (isFirst && pattern.at(0) === ".") {
      this.#addSubpattern(".", pattern.child((/* @__PURE__ */ new Set()).add(1)));
      return;
    }
    if (isLast && typeof pattern.at(-1) === "string") {
      let p = pattern.at(-1);
      if (this.#cache.statSync(join(fullpath, p)) && (p || isDirectory))
        this.#results.add(join(path, p));
      if (pattern.indexes.size === 1 && pattern.indexes.has(last))
        return;
    } else if (isLast && pattern.at(-1) === lazyMinimatch().GLOBSTAR && (path !== "." || pattern.at(0) === "." || last === 0 && stat))
      this.#results.add(path);
    if (!isDirectory || this.#isCyclicSync(fullpath, isDirectory, pattern))
      return;
    let nextRealpaths = this.#nextRealpathsSync(fullpath, isDirectory, pattern), children, firstPattern = pattern.indexes.size === 1 && pattern.at(pattern.indexes.values().next().value);
    if (typeof firstPattern === "string") {
      let stat2 = this.#cache.statSync(join(fullpath, firstPattern));
      if (stat2)
        setDirentName(stat2, firstPattern), children = [stat2];
      else
        return;
    } else
      children = this.#cache.readdirSync(fullpath);
    for (let i = 0;i < children.length; i++) {
      let entry = children[i], entryPath = join(path, entry.name), entryFullpath = join(fullpath, entry.name);
      this.#cache.addToStatCache(entryFullpath, entry);
      let entryIsDirectory = entry.isDirectory() || this.#followSymlinks && entry.isSymbolicLink() && !!this.#cache.followStatSync(entryFullpath)?.isDirectory(), subPatterns = /* @__PURE__ */ new Set, nSymlinks = /* @__PURE__ */ new Set;
      for (let index of pattern.indexes) {
        if (this.#cache.seen(entryPath, pattern, index) || this.#cache.seen(entryPath, pattern, index + 1))
          return;
        let current = pattern.at(index), nextIndex = index + 1, next = pattern.at(nextIndex), fromSymlink = !this.#followSymlinks && pattern.symlinks.has(index);
        if (current === lazyMinimatch().GLOBSTAR) {
          let isDot = entry.name[0] === ".", nextMatches = pattern.test(nextIndex, entry.name), nextNonGlobIndex = nextIndex;
          while (pattern.at(nextNonGlobIndex) === lazyMinimatch().GLOBSTAR)
            nextNonGlobIndex++;
          let matchesDot = isDot && pattern.test(nextNonGlobIndex, entry.name);
          if (isDot && !matchesDot || this.#exclude && this.#exclude(this.#withFileTypes ? entry : entry.name))
            continue;
          if (!fromSymlink && entryIsDirectory)
            subPatterns.add(index);
          else if (!fromSymlink && index === last)
            this.#results.add(entryPath);
          if (nextMatches && nextIndex === last && !isLast)
            this.#results.add(entryPath);
          else if (nextMatches && entryIsDirectory)
            subPatterns.add(index + 2);
          if ((nextMatches || pattern.at(0) === ".") && (entryIsDirectory || entry.isSymbolicLink()) && !fromSymlink)
            subPatterns.add(nextIndex);
          if (!this.#followSymlinks && entry.isSymbolicLink())
            nSymlinks.add(index);
          if (next === ".." && entryIsDirectory) {
            let parent = join(path, "..");
            if (nextIndex < last) {
              if (!this.#subpatterns.has(path) && !this.#cache.seen(path, pattern, nextIndex + 1))
                this.#subpatterns.set(path, [pattern.child((/* @__PURE__ */ new Set()).add(nextIndex + 1))]);
              if (!this.#subpatterns.has(parent) && !this.#cache.seen(parent, pattern, nextIndex + 1))
                this.#subpatterns.set(parent, [pattern.child((/* @__PURE__ */ new Set()).add(nextIndex + 1))]);
            } else {
              if (!this.#cache.seen(path, pattern, nextIndex))
                this.#cache.add(path, pattern.child((/* @__PURE__ */ new Set()).add(nextIndex))), this.#results.add(path);
              if (!this.#cache.seen(path, pattern, nextIndex) || !this.#cache.seen(parent, pattern, nextIndex))
                this.#cache.add(parent, pattern.child((/* @__PURE__ */ new Set()).add(nextIndex))), this.#results.add(parent);
            }
          }
        }
        if (typeof current === "string") {
          if (pattern.test(index, entry.name) && index !== last)
            subPatterns.add(nextIndex);
          else if (current === "." && pattern.test(nextIndex, entry.name))
            if (nextIndex === last)
              this.#results.add(entryPath);
            else
              subPatterns.add(nextIndex + 1);
        }
        if (typeof current === "object" && pattern.test(index, entry.name)) {
          if (index === last)
            this.#results.add(entryPath);
          else if (entryIsDirectory)
            subPatterns.add(nextIndex);
        }
      }
      if (subPatterns.size > 0)
        this.#addSubpattern(entryPath, pattern.child(subPatterns, nSymlinks, nextRealpaths));
    }
  }
  async* glob() {
    this.#queue.push({ __proto__: null, path: ".", patterns: this.#patterns });
    while (this.#queue.length > 0) {
      let item = this.#queue.pop();
      for (let i = 0;i < item.patterns.length; i++)
        yield* this.#iterateSubpatterns(item.path, item.patterns[i]);
      for (let [path, patterns] of this.#subpatterns)
        this.#queue.push({ __proto__: null, path, patterns });
      this.#subpatterns.clear();
    }
  }
  async* #iterateSubpatterns(path, pattern) {
    if (this.#cache.add(path, pattern))
      return;
    let fullpath = resolve(this.#root, path), stat = await this.#cache.stat(fullpath), last = pattern.last, isDirectory = await this.#isDirectory(fullpath, stat, pattern), isLast = pattern.isLast(isDirectory), isFirst = pattern.isFirst();
    if (this.#isExcluded(fullpath))
      return;
    if (isFirst && pattern.at(0) === "") {
      this.#addSubpattern("/", pattern.child((/* @__PURE__ */ new Set()).add(1)));
      return;
    }
    if (isFirst && pattern.at(0) === "..") {
      this.#addSubpattern("../", pattern.child((/* @__PURE__ */ new Set()).add(1)));
      return;
    }
    if (isFirst && pattern.at(0) === ".") {
      this.#addSubpattern(".", pattern.child((/* @__PURE__ */ new Set()).add(1)));
      return;
    }
    if (isLast && typeof pattern.at(-1) === "string") {
      let p = pattern.at(-1), stat2 = await this.#cache.stat(join(fullpath, p));
      if (stat2 && (p || isDirectory)) {
        let result = join(path, p);
        if (!this.#results.has(result)) {
          if (this.#results.add(result))
            yield this.#withFileTypes ? stat2 : result;
        }
      }
      if (pattern.indexes.size === 1 && pattern.indexes.has(last))
        return;
    } else if (isLast && pattern.at(-1) === lazyMinimatch().GLOBSTAR && (path !== "." || pattern.at(0) === "." || last === 0 && stat)) {
      if (!this.#results.has(path)) {
        if (this.#results.add(path))
          yield this.#withFileTypes ? stat : path;
      }
    }
    if (!isDirectory || await this.#isCyclic(fullpath, isDirectory, pattern))
      return;
    let nextRealpaths = await this.#nextRealpaths(fullpath, isDirectory, pattern), children, firstPattern = pattern.indexes.size === 1 && pattern.at(pattern.indexes.values().next().value);
    if (typeof firstPattern === "string") {
      let stat2 = await this.#cache.stat(join(fullpath, firstPattern));
      if (stat2)
        setDirentName(stat2, firstPattern), children = [stat2];
      else
        return;
    } else
      children = await this.#cache.readdir(fullpath);
    for (let i = 0;i < children.length; i++) {
      let entry = children[i], entryPath = join(path, entry.name), entryFullpath = join(fullpath, entry.name);
      this.#cache.addToStatCache(entryFullpath, entry);
      let entryIsDirectory = entry.isDirectory() || this.#followSymlinks && entry.isSymbolicLink() && !!(await this.#cache.followStat(entryFullpath))?.isDirectory(), subPatterns = /* @__PURE__ */ new Set, nSymlinks = /* @__PURE__ */ new Set;
      for (let index of pattern.indexes) {
        if (this.#cache.seen(entryPath, pattern, index) || this.#cache.seen(entryPath, pattern, index + 1))
          return;
        let current = pattern.at(index), nextIndex = index + 1, next = pattern.at(nextIndex), fromSymlink = !this.#followSymlinks && pattern.symlinks.has(index);
        if (current === lazyMinimatch().GLOBSTAR) {
          let isDot = entry.name[0] === ".", nextMatches = pattern.test(nextIndex, entry.name), nextNonGlobIndex = nextIndex;
          while (pattern.at(nextNonGlobIndex) === lazyMinimatch().GLOBSTAR)
            nextNonGlobIndex++;
          let matchesDot = isDot && pattern.test(nextNonGlobIndex, entry.name);
          if (isDot && !matchesDot || this.#exclude && this.#exclude(this.#withFileTypes ? entry : entry.name))
            continue;
          if (!fromSymlink && entryIsDirectory)
            subPatterns.add(index);
          else if (!fromSymlink && index === last) {
            if (!this.#results.has(entryPath) && this.#results.add(entryPath))
              yield this.#withFileTypes ? entry : entryPath;
          }
          if (nextMatches && nextIndex === last && !isLast) {
            if (!this.#results.has(entryPath) && this.#results.add(entryPath))
              yield this.#withFileTypes ? entry : entryPath;
          } else if (nextMatches && entryIsDirectory)
            subPatterns.add(index + 2);
          if ((nextMatches || pattern.at(0) === ".") && (entryIsDirectory || entry.isSymbolicLink()) && !fromSymlink)
            subPatterns.add(nextIndex);
          if (!this.#followSymlinks && entry.isSymbolicLink())
            nSymlinks.add(index);
          if (next === ".." && entryIsDirectory) {
            let parent = join(path, "..");
            if (nextIndex < last) {
              if (!this.#subpatterns.has(path) && !this.#cache.seen(path, pattern, nextIndex + 1))
                this.#subpatterns.set(path, [pattern.child((/* @__PURE__ */ new Set()).add(nextIndex + 1))]);
              if (!this.#subpatterns.has(parent) && !this.#cache.seen(parent, pattern, nextIndex + 1))
                this.#subpatterns.set(parent, [pattern.child((/* @__PURE__ */ new Set()).add(nextIndex + 1))]);
            } else {
              if (!this.#cache.seen(path, pattern, nextIndex)) {
                if (this.#cache.add(path, pattern.child((/* @__PURE__ */ new Set()).add(nextIndex))), !this.#results.has(path)) {
                  if (this.#results.add(path))
                    yield this.#withFileTypes ? this.#cache.statSync(fullpath) : path;
                }
              }
              if (!this.#cache.seen(path, pattern, nextIndex) || !this.#cache.seen(parent, pattern, nextIndex)) {
                if (this.#cache.add(parent, pattern.child((/* @__PURE__ */ new Set()).add(nextIndex))), !this.#results.has(parent)) {
                  if (this.#results.add(parent))
                    yield this.#withFileTypes ? this.#cache.statSync(join(this.#root, parent)) : parent;
                }
              }
            }
          }
        }
        if (typeof current === "string") {
          if (pattern.test(index, entry.name) && index !== last)
            subPatterns.add(nextIndex);
          else if (current === "." && pattern.test(nextIndex, entry.name))
            if (nextIndex === last) {
              if (!this.#results.has(entryPath)) {
                if (this.#results.add(entryPath))
                  yield this.#withFileTypes ? entry : entryPath;
              }
            } else
              subPatterns.add(nextIndex + 1);
        }
        if (typeof current === "object" && pattern.test(index, entry.name)) {
          if (index === last) {
            if (!this.#results.has(entryPath)) {
              if (this.#results.add(entryPath))
                yield this.#withFileTypes ? entry : entryPath;
            }
          } else if (entryIsDirectory)
            subPatterns.add(nextIndex);
        }
      }
      if (subPatterns.size > 0)
        this.#addSubpattern(entryPath, pattern.child(subPatterns, nSymlinks, nextRealpaths));
    }
  }
}
function setDirentName(dirent, name) {
  try {
    dirent.name = name;
  } catch {
    Object.defineProperty(dirent, "name", {
      value: name,
      writable: !0,
      enumerable: !0,
      configurable: !0
    });
  }
}
function glob(pattern, options) {
  return new Glob(pattern, options).glob();
}
function globSync(pattern, options) {
  return new Glob(pattern, options).globSync();
}
$ = { glob, globSync, Glob };
var _minimatch;
function lazyMinimatch() {
  if (_minimatch)
    return _minimatch;
  let exports = {}, module = { exports };
  var __getOwnPropNames = Object.getOwnPropertyNames, __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  }, require_commonjs = __commonJS({
    "node_modules/balanced-match/dist/commonjs/index.js"(exports2) {
      Object.defineProperty(exports2, "__esModule", { value: !0 }), exports2.range = exports2.balanced = void 0;
      var balanced = (a, b, str) => {
        let ma = a instanceof @RegExp ? maybeMatch(a, str) : a, mb = b instanceof @RegExp ? maybeMatch(b, str) : b, r = ma !== null && mb != null && (0, exports2.range)(ma, mb, str);
        return r && {
          start: r[0],
          end: r[1],
          pre: str.slice(0, r[0]),
          body: str.slice(r[0] + ma.length, r[1]),
          post: str.slice(r[1] + mb.length)
        };
      };
      exports2.balanced = balanced;
      var maybeMatch = (reg, str) => {
        let m = str.match(reg);
        return m ? m[0] : null;
      }, range = (a, b, str) => {
        let begs, beg, left, right = void 0, result, ai = str.indexOf(a), bi = str.indexOf(b, ai + 1), i = ai;
        if (ai >= 0 && bi > 0) {
          if (a === b)
            return [ai, bi];
          begs = [], left = str.length;
          while (i >= 0 && !result) {
            if (i === ai)
              begs.push(i), ai = str.indexOf(a, i + 1);
            else if (begs.length === 1) {
              let r = begs.pop();
              if (r !== void 0)
                result = [r, bi];
            } else {
              if (beg = begs.pop(), beg !== void 0 && beg < left)
                left = beg, right = bi;
              bi = str.indexOf(b, i + 1);
            }
            i = ai < bi && ai >= 0 ? ai : bi;
          }
          if (begs.length && right !== void 0)
            result = [left, right];
        }
        return result;
      };
      exports2.range = range;
    }
  }), require_commonjs2 = __commonJS({
    "node_modules/brace-expansion/dist/commonjs/index.js"(exports2) {
      Object.defineProperty(exports2, "__esModule", { value: !0 }), exports2.EXPANSION_MAX = void 0, exports2.expand = expand;
      var balanced_match_1 = require_commonjs(), escSlash = "\x00SLASH" + Math.random() + "\x00", escOpen = "\x00OPEN" + Math.random() + "\x00", escClose = "\x00CLOSE" + Math.random() + "\x00", escComma = "\x00COMMA" + Math.random() + "\x00", escPeriod = "\x00PERIOD" + Math.random() + "\x00", escSlashPattern = new @RegExp(escSlash, "g"), escOpenPattern = new @RegExp(escOpen, "g"), escClosePattern = new @RegExp(escClose, "g"), escCommaPattern = new @RegExp(escComma, "g"), escPeriodPattern = new @RegExp(escPeriod, "g"), slashPattern = /\\\\/g, openPattern = /\\{/g, closePattern = /\\}/g, commaPattern = /\\,/g, periodPattern = /\\\./g;
      exports2.EXPANSION_MAX = 1e5;
      function numeric(str) {
        return !isNaN(str) ? parseInt(str, 10) : str.charCodeAt(0);
      }
      function escapeBraces(str) {
        return str.replace(slashPattern, escSlash).replace(openPattern, escOpen).replace(closePattern, escClose).replace(commaPattern, escComma).replace(periodPattern, escPeriod);
      }
      function unescapeBraces(str) {
        return str.replace(escSlashPattern, "\\").replace(escOpenPattern, "{").replace(escClosePattern, "}").replace(escCommaPattern, ",").replace(escPeriodPattern, ".");
      }
      function parseCommaParts(str) {
        if (!str)
          return [""];
        let parts = [], m = (0, balanced_match_1.balanced)("{", "}", str);
        if (!m)
          return str.split(",");
        let { pre, body, post } = m, p = pre.split(",");
        p[p.length - 1] += "{" + body + "}";
        let postParts = parseCommaParts(post);
        if (post.length)
          p[p.length - 1] += postParts.shift(), p.push(...postParts);
        return parts.push(...p), parts;
      }
      function expand(str, options = {}) {
        if (!str)
          return [];
        let { max = exports2.EXPANSION_MAX } = options;
        if (str.slice(0, 2) === "{}")
          str = "\\{\\}" + str.slice(2);
        return expand_(escapeBraces(str), max, !0).map(unescapeBraces);
      }
      function embrace(str) {
        return "{" + str + "}";
      }
      function isPadded(el) {
        return /^-?0\d/.test(el);
      }
      function lte(i, y) {
        return i <= y;
      }
      function gte(i, y) {
        return i >= y;
      }
      function expand_(str, max, isTop) {
        let expansions = [], m = (0, balanced_match_1.balanced)("{", "}", str);
        if (!m)
          return [str];
        let pre = m.pre, post = m.post.length ? expand_(m.post, max, !1) : [""];
        if (m.pre.endsWith("$"))
          for (let k = 0;k < post.length && k < max; k++) {
            let expansion = pre + "{" + m.body + "}" + post[k];
            expansions.push(expansion);
          }
        else {
          let isNumericSequence = /^-?\d+\.\.-?\d+(?:\.\.-?\d+)?$/.test(m.body), isAlphaSequence = /^[a-zA-Z]\.\.[a-zA-Z](?:\.\.-?\d+)?$/.test(m.body), isSequence = isNumericSequence || isAlphaSequence, isOptions = m.body.indexOf(",") >= 0;
          if (!isSequence && !isOptions) {
            let mPost = m.post;
            if (mPost.match(/,(?!,).*\}/))
              return str = m.pre + "{" + m.body + escClose + mPost, expand_(str, max, !0);
            return [str];
          }
          let n;
          if (isSequence)
            n = m.body.split(/\.\./);
          else if (n = parseCommaParts(m.body), n.length === 1 && n[0] !== void 0) {
            if (n = expand_(n[0], max, !1).map(embrace), n.length === 1)
              return post.map((p) => m.pre + n[0] + p);
          }
          let N;
          if (isSequence && n[0] !== void 0 && n[1] !== void 0) {
            let x = numeric(n[0]), y = numeric(n[1]), width = Math.max(n[0].length, n[1].length), incr = n.length === 3 && n[2] !== void 0 ? Math.max(Math.abs(numeric(n[2])), 1) : 1, test = lte;
            if (y < x)
              incr *= -1, test = gte;
            let pad = n.some(isPadded);
            N = [];
            for (let i = x;test(i, y); i += incr) {
              let c;
              if (isAlphaSequence) {
                if (c = @String.fromCharCode(i), c === "\\")
                  c = "";
              } else if (c = @String(i), pad) {
                let need = width - c.length;
                if (need > 0) {
                  let z = new @Array(need + 1).join("0");
                  if (i < 0)
                    c = "-" + z + c.slice(1);
                  else
                    c = z + c;
                }
              }
              N.push(c);
            }
          } else {
            N = [];
            for (let j = 0;j < n.length; j++)
              N.push(...expand_(n[j], max, !1));
          }
          for (let j = 0;j < N.length; j++)
            for (let k = 0;k < post.length && expansions.length < max; k++) {
              let expansion = pre + N[j] + post[k];
              if (!isTop || isSequence || expansion)
                expansions.push(expansion);
            }
        }
        return expansions;
      }
    }
  }), require_assert_valid_pattern = __commonJS({
    "dist/commonjs/assert-valid-pattern.js"(exports2) {
      Object.defineProperty(exports2, "__esModule", { value: !0 }), exports2.assertValidPattern = void 0;
      var MAX_PATTERN_LENGTH = 65536, assertValidPattern = (pattern) => {
        if (typeof pattern !== "string")
          @throwTypeError("invalid pattern");
        if (pattern.length > MAX_PATTERN_LENGTH)
          @throwTypeError("pattern is too long");
      };
      exports2.assertValidPattern = assertValidPattern;
    }
  }), require_brace_expressions = __commonJS({
    "dist/commonjs/brace-expressions.js"(exports2) {
      Object.defineProperty(exports2, "__esModule", { value: !0 }), exports2.parseClass = void 0;
      var posixClasses = {
        "[:alnum:]": ["\\p{L}\\p{Nl}\\p{Nd}", !0],
        "[:alpha:]": ["\\p{L}\\p{Nl}", !0],
        "[:ascii:]": ["\\x00-\\x7f", !1],
        "[:blank:]": ["\\p{Zs}\\t", !0],
        "[:cntrl:]": ["\\p{Cc}", !0],
        "[:digit:]": ["\\p{Nd}", !0],
        "[:graph:]": ["\\p{Z}\\p{C}", !0, !0],
        "[:lower:]": ["\\p{Ll}", !0],
        "[:print:]": ["\\p{C}", !0],
        "[:punct:]": ["\\p{P}", !0],
        "[:space:]": ["\\p{Z}\\t\\r\\n\\v\\f", !0],
        "[:upper:]": ["\\p{Lu}", !0],
        "[:word:]": ["\\p{L}\\p{Nl}\\p{Nd}\\p{Pc}", !0],
        "[:xdigit:]": ["A-Fa-f0-9", !1]
      }, braceEscape = (s) => s.replace(/[[\]\\-]/g, "\\$&"), regexpEscape = (s) => s.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, "\\$&"), rangesToString = (ranges) => ranges.join(""), parseClass = (glob2, position) => {
        let pos = position;
        if (glob2.charAt(pos) !== "[")
          throw Error("not in a brace expression");
        let ranges = [], negs = [], i = pos + 1, sawStart = !1, uflag = !1, escaping = !1, negate = !1, endPos = pos, rangeStart = "";
        WHILE:
          while (i < glob2.length) {
            let c = glob2.charAt(i);
            if ((c === "!" || c === "^") && i === pos + 1) {
              negate = !0, i++;
              continue;
            }
            if (c === "]" && sawStart && !escaping) {
              endPos = i + 1;
              break;
            }
            if (sawStart = !0, c === "\\") {
              if (!escaping) {
                escaping = !0, i++;
                continue;
              }
            }
            if (c === "[" && !escaping) {
              for (let [cls, [unip, u, neg]] of Object.entries(posixClasses))
                if (glob2.startsWith(cls, i)) {
                  if (rangeStart)
                    return ["$.", !1, glob2.length - pos, !0];
                  if (i += cls.length, neg)
                    negs.push(unip);
                  else
                    ranges.push(unip);
                  uflag = uflag || u;
                  continue WHILE;
                }
            }
            if (escaping = !1, rangeStart) {
              if (c > rangeStart)
                ranges.push(braceEscape(rangeStart) + "-" + braceEscape(c));
              else if (c === rangeStart)
                ranges.push(braceEscape(c));
              rangeStart = "", i++;
              continue;
            }
            if (glob2.startsWith("-]", i + 1)) {
              ranges.push(braceEscape(c + "-")), i += 2;
              continue;
            }
            if (glob2.startsWith("-", i + 1)) {
              rangeStart = c, i += 2;
              continue;
            }
            ranges.push(braceEscape(c)), i++;
          }
        if (endPos < i)
          return ["", !1, 0, !1];
        if (!ranges.length && !negs.length)
          return ["$.", !1, glob2.length - pos, !0];
        if (negs.length === 0 && ranges.length === 1 && /^\\?.$/.test(ranges[0]) && !negate) {
          let r = ranges[0].length === 2 ? ranges[0].slice(-1) : ranges[0];
          return [regexpEscape(r), !1, endPos - pos, !1];
        }
        let sranges = "[" + (negate ? "^" : "") + rangesToString(ranges) + "]", snegs = "[" + (negate ? "" : "^") + rangesToString(negs) + "]";
        return [ranges.length && negs.length ? "(" + sranges + "|" + snegs + ")" : ranges.length ? sranges : snegs, uflag, endPos - pos, !0];
      };
      exports2.parseClass = parseClass;
    }
  }), require_unescape = __commonJS({
    "dist/commonjs/unescape.js"(exports2) {
      Object.defineProperty(exports2, "__esModule", { value: !0 }), exports2.unescape = void 0;
      var unescape = (s, { windowsPathsNoEscape = !1, magicalBraces = !0 } = {}) => {
        if (magicalBraces)
          return windowsPathsNoEscape ? s.replace(/\[([^/\\])\]/g, "$1") : s.replace(/((?!\\).|^)\[([^/\\])\]/g, "$1$2").replace(/\\([^/])/g, "$1");
        return windowsPathsNoEscape ? s.replace(/\[([^/\\{}])\]/g, "$1") : s.replace(/((?!\\).|^)\[([^/\\{}])\]/g, "$1$2").replace(/\\([^/{}])/g, "$1");
      };
      exports2.unescape = unescape;
    }
  }), require_ast = __commonJS({
    "dist/commonjs/ast.js"(exports2) {
      var _a;
      Object.defineProperty(exports2, "__esModule", { value: !0 }), exports2.AST = void 0;
      var brace_expressions_js_1 = require_brace_expressions(), unescape_js_12 = require_unescape(), types = /* @__PURE__ */ new Set(["!", "?", "+", "*", "@"]), isExtglobType = (c) => types.has(c), isExtglobAST = (c) => isExtglobType(c.type), adoptionMap = /* @__PURE__ */ new Map([
        ["!", ["@"]],
        ["?", ["?", "@"]],
        ["@", ["@"]],
        ["*", ["*", "+", "?", "@"]],
        ["+", ["+", "@"]]
      ]), adoptionWithSpaceMap = /* @__PURE__ */ new Map([
        ["!", ["?"]],
        ["@", ["?"]],
        ["+", ["?", "*"]]
      ]), adoptionAnyMap = /* @__PURE__ */ new Map([
        ["!", ["?", "@"]],
        ["?", ["?", "@"]],
        ["@", ["?", "@"]],
        ["*", ["*", "+", "?", "@"]],
        ["+", ["+", "@", "?", "*"]]
      ]), usurpMap = /* @__PURE__ */ new Map([
        ["!", /* @__PURE__ */ new Map([["!", "@"]])],
        [
          "?",
          /* @__PURE__ */ new Map([
            ["*", "*"],
            ["+", "*"]
          ])
        ],
        [
          "@",
          /* @__PURE__ */ new Map([
            ["!", "!"],
            ["?", "?"],
            ["@", "@"],
            ["*", "*"],
            ["+", "+"]
          ])
        ],
        [
          "+",
          /* @__PURE__ */ new Map([
            ["?", "*"],
            ["*", "*"]
          ])
        ]
      ]), startNoTraversal = "(?!(?:^|/)\\.\\.?(?:$|/))", startNoDot = "(?!\\.)", addPatternStart = /* @__PURE__ */ new Set(["[", "."]), justDots = /* @__PURE__ */ new Set(["..", "."]), reSpecials = new Set("().*{}+?[]^$\\!"), regExpEscape2 = (s) => s.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, "\\$&"), qmark2 = "[^/]", star2 = qmark2 + "*?", starNoEmpty = qmark2 + "+?", ID = 0, AST = class {
        type;
        #root;
        #hasMagic;
        #uflag = !1;
        #parts = [];
        #parent;
        #parentIndex;
        #negs;
        #filledNegs = !1;
        #options;
        #toString;
        #emptyExt = !1;
        id = ++ID;
        get depth() {
          return (this.#parent?.depth ?? -1) + 1;
        }
        [/* @__PURE__ */ Symbol.for("nodejs.util.inspect.custom")]() {
          return {
            "@@type": "AST",
            id: this.id,
            type: this.type,
            root: this.#root.id,
            parent: this.#parent?.id,
            depth: this.depth,
            partsLength: this.#parts.length,
            parts: this.#parts
          };
        }
        constructor(type, parent, options = {}) {
          if (this.type = type, type)
            this.#hasMagic = !0;
          if (this.#parent = parent, this.#root = this.#parent ? this.#parent.#root : this, this.#options = this.#root === this ? options : this.#root.#options, this.#negs = this.#root === this ? [] : this.#root.#negs, type === "!" && !this.#root.#filledNegs)
            this.#negs.push(this);
          this.#parentIndex = this.#parent ? this.#parent.#parts.length : 0;
        }
        get hasMagic() {
          if (this.#hasMagic !== void 0)
            return this.#hasMagic;
          for (let p of this.#parts) {
            if (typeof p === "string")
              continue;
            if (p.type || p.hasMagic)
              return this.#hasMagic = !0;
          }
          return this.#hasMagic;
        }
        toString() {
          return this.#toString !== void 0 ? this.#toString : !this.type ? this.#toString = this.#parts.map((p) => @String(p)).join("") : this.#toString = this.type + "(" + this.#parts.map((p) => @String(p)).join("|") + ")";
        }
        #fillNegs() {
          if (this !== this.#root)
            throw Error("should only call on root");
          if (this.#filledNegs)
            return this;
          this.toString(), this.#filledNegs = !0;
          let n;
          while (n = this.#negs.pop()) {
            if (n.type !== "!")
              continue;
            let p = n, pp = p.#parent;
            while (pp) {
              for (let i = p.#parentIndex + 1;!pp.type && i < pp.#parts.length; i++)
                for (let part of n.#parts) {
                  if (typeof part === "string")
                    throw Error("string part in extglob AST??");
                  part.copyIn(pp.#parts[i]);
                }
              p = pp, pp = p.#parent;
            }
          }
          return this;
        }
        push(...parts) {
          for (let p of parts) {
            if (p === "")
              continue;
            if (typeof p !== "string" && !(p instanceof _a && p.#parent === this))
              throw Error("invalid part: " + p);
            this.#parts.push(p);
          }
        }
        toJSON() {
          let ret = this.type === null ? this.#parts.slice().map((p) => typeof p === "string" ? p : p.toJSON()) : [this.type, ...this.#parts.map((p) => p.toJSON())];
          if (this.isStart() && !this.type)
            ret.unshift([]);
          if (this.isEnd() && (this === this.#root || this.#root.#filledNegs && this.#parent?.type === "!"))
            ret.push({});
          return ret;
        }
        isStart() {
          if (this.#root === this)
            return !0;
          if (!this.#parent?.isStart())
            return !1;
          if (this.#parentIndex === 0)
            return !0;
          let p = this.#parent;
          for (let i = 0;i < this.#parentIndex; i++) {
            let pp = p.#parts[i];
            if (!(pp instanceof _a && pp.type === "!"))
              return !1;
          }
          return !0;
        }
        isEnd() {
          if (this.#root === this)
            return !0;
          if (this.#parent?.type === "!")
            return !0;
          if (!this.#parent?.isEnd())
            return !1;
          if (!this.type)
            return this.#parent?.isEnd();
          let pl = this.#parent ? this.#parent.#parts.length : 0;
          return this.#parentIndex === pl - 1;
        }
        copyIn(part) {
          if (typeof part === "string")
            this.push(part);
          else
            this.push(part.clone(this));
        }
        clone(parent) {
          let c = new _a(this.type, parent);
          for (let p of this.#parts)
            c.copyIn(p);
          return c;
        }
        static #parseAST(str, ast, pos, opt, extDepth) {
          let maxDepth = opt.maxExtglobRecursion ?? 2, escaping = !1, inBrace = !1, braceStart = -1, braceNeg = !1;
          if (ast.type === null) {
            let i2 = pos, acc2 = "";
            while (i2 < str.length) {
              let c = str.charAt(i2++);
              if (escaping || c === "\\") {
                escaping = !escaping, acc2 += c;
                continue;
              }
              if (inBrace) {
                if (i2 === braceStart + 1) {
                  if (c === "^" || c === "!")
                    braceNeg = !0;
                } else if (c === "]" && !(i2 === braceStart + 2 && braceNeg))
                  inBrace = !1;
                acc2 += c;
                continue;
              } else if (c === "[") {
                inBrace = !0, braceStart = i2, braceNeg = !1, acc2 += c;
                continue;
              }
              if (!opt.noext && isExtglobType(c) && str.charAt(i2) === "(" && extDepth <= maxDepth) {
                ast.push(acc2), acc2 = "";
                let ext2 = new _a(c, ast);
                i2 = _a.#parseAST(str, ext2, i2, opt, extDepth + 1), ast.push(ext2);
                continue;
              }
              acc2 += c;
            }
            return ast.push(acc2), i2;
          }
          let i = pos + 1, part = new _a(null, ast), parts = [], acc = "";
          while (i < str.length) {
            let c = str.charAt(i++);
            if (escaping || c === "\\") {
              escaping = !escaping, acc += c;
              continue;
            }
            if (inBrace) {
              if (i === braceStart + 1) {
                if (c === "^" || c === "!")
                  braceNeg = !0;
              } else if (c === "]" && !(i === braceStart + 2 && braceNeg))
                inBrace = !1;
              acc += c;
              continue;
            } else if (c === "[") {
              inBrace = !0, braceStart = i, braceNeg = !1, acc += c;
              continue;
            }
            if (!opt.noext && isExtglobType(c) && str.charAt(i) === "(" && (extDepth <= maxDepth || ast && ast.#canAdoptType(c))) {
              let depthAdd = ast && ast.#canAdoptType(c) ? 0 : 1;
              part.push(acc), acc = "";
              let ext2 = new _a(c, part);
              part.push(ext2), i = _a.#parseAST(str, ext2, i, opt, extDepth + depthAdd);
              continue;
            }
            if (c === "|") {
              part.push(acc), acc = "", parts.push(part), part = new _a(null, ast);
              continue;
            }
            if (c === ")") {
              if (acc === "" && ast.#parts.length === 0)
                ast.#emptyExt = !0;
              return part.push(acc), acc = "", ast.push(...parts, part), i;
            }
            acc += c;
          }
          return ast.type = null, ast.#hasMagic = void 0, ast.#parts = [str.substring(pos - 1)], i;
        }
        #canAdoptWithSpace(child) {
          return this.#canAdopt(child, adoptionWithSpaceMap);
        }
        #canAdopt(child, map = adoptionMap) {
          if (!child || typeof child !== "object" || child.type !== null || child.#parts.length !== 1 || this.type === null)
            return !1;
          let gc = child.#parts[0];
          if (!gc || typeof gc !== "object" || gc.type === null)
            return !1;
          return this.#canAdoptType(gc.type, map);
        }
        #canAdoptType(c, map = adoptionAnyMap) {
          return !!map.get(this.type)?.includes(c);
        }
        #adoptWithSpace(child, index) {
          let gc = child.#parts[0], blank = new _a(null, gc, this.options);
          blank.#parts.push(""), gc.push(blank), this.#adopt(child, index);
        }
        #adopt(child, index) {
          let gc = child.#parts[0];
          this.#parts.splice(index, 1, ...gc.#parts);
          for (let p of gc.#parts)
            if (typeof p === "object")
              p.#parent = this;
          this.#toString = void 0;
        }
        #canUsurpType(c) {
          return !!usurpMap.get(this.type)?.has(c);
        }
        #canUsurp(child) {
          if (!child || typeof child !== "object" || child.type !== null || child.#parts.length !== 1 || this.type === null || this.#parts.length !== 1)
            return !1;
          let gc = child.#parts[0];
          if (!gc || typeof gc !== "object" || gc.type === null)
            return !1;
          return this.#canUsurpType(gc.type);
        }
        #usurp(child) {
          let m = usurpMap.get(this.type), gc = child.#parts[0], nt = m?.get(gc.type);
          if (!nt)
            return !1;
          this.#parts = gc.#parts;
          for (let p of this.#parts)
            if (typeof p === "object")
              p.#parent = this;
          this.type = nt, this.#toString = void 0, this.#emptyExt = !1;
        }
        static fromGlob(pattern, options = {}) {
          let ast = new _a(null, void 0, options);
          return _a.#parseAST(pattern, ast, 0, options, 0), ast;
        }
        toMMPattern() {
          if (this !== this.#root)
            return this.#root.toMMPattern();
          let glob2 = this.toString(), [re, body, hasMagic, uflag] = this.toRegExpSource();
          if (!(hasMagic || this.#hasMagic || this.#options.nocase && !this.#options.nocaseMagicOnly && glob2.toUpperCase() !== glob2.toLowerCase()))
            return body;
          let flags = (this.#options.nocase ? "i" : "") + (uflag ? "u" : "");
          return Object.assign(new @RegExp(`^${re}$`, flags), {
            _src: re,
            _glob: glob2
          });
        }
        get options() {
          return this.#options;
        }
        toRegExpSource(allowDot) {
          let dot = allowDot ?? !!this.#options.dot;
          if (this.#root === this)
            this.#flatten(), this.#fillNegs();
          if (!isExtglobAST(this)) {
            let noEmpty = this.isStart() && this.isEnd() && !this.#parts.some((s) => typeof s !== "string"), src = this.#parts.map((p) => {
              let [re, _, hasMagic, uflag] = typeof p === "string" ? _a.#parseGlob(p, this.#hasMagic, noEmpty) : p.toRegExpSource(allowDot);
              return this.#hasMagic = this.#hasMagic || hasMagic, this.#uflag = this.#uflag || uflag, re;
            }).join(""), start2 = "";
            if (this.isStart()) {
              if (typeof this.#parts[0] === "string") {
                if (!(this.#parts.length === 1 && justDots.has(this.#parts[0]))) {
                  let aps = addPatternStart, needNoTrav = dot && aps.has(src.charAt(0)) || src.startsWith("\\.") && aps.has(src.charAt(2)) || src.startsWith("\\.\\.") && aps.has(src.charAt(4)), needNoDot = !dot && !allowDot && aps.has(src.charAt(0));
                  start2 = needNoTrav ? startNoTraversal : needNoDot ? startNoDot : "";
                }
              }
            }
            let end = "";
            if (this.isEnd() && this.#root.#filledNegs && this.#parent?.type === "!")
              end = "(?:$|\\/)";
            return [start2 + src + end, (0, unescape_js_12.unescape)(src), this.#hasMagic = !!this.#hasMagic, this.#uflag];
          }
          let repeated = this.type === "*" || this.type === "+", start = this.type === "!" ? "(?:(?!(?:" : "(?:", body = this.#partsToRegExp(dot);
          if (this.isStart() && this.isEnd() && !body && this.type !== "!") {
            let s = this.toString(), me = this;
            return me.#parts = [s], me.type = null, me.#hasMagic = void 0, [s, (0, unescape_js_12.unescape)(this.toString()), !1, !1];
          }
          let bodyDotAllowed = !repeated || allowDot || dot || !startNoDot ? "" : this.#partsToRegExp(!0);
          if (bodyDotAllowed === body)
            bodyDotAllowed = "";
          if (bodyDotAllowed)
            body = `(?:${body})(?:${bodyDotAllowed})*?`;
          let final = "";
          if (this.type === "!" && this.#emptyExt)
            final = (this.isStart() && !dot ? startNoDot : "") + starNoEmpty;
          else {
            let close = this.type === "!" ? "))" + (this.isStart() && !dot && !allowDot ? startNoDot : "") + star2 + ")" : this.type === "@" ? ")" : this.type === "?" ? ")?" : this.type === "+" && bodyDotAllowed ? ")" : this.type === "*" && bodyDotAllowed ? ")?" : `)${this.type}`;
            final = start + body + close;
          }
          return [final, (0, unescape_js_12.unescape)(body), this.#hasMagic = !!this.#hasMagic, this.#uflag];
        }
        #flatten() {
          if (!isExtglobAST(this)) {
            for (let p of this.#parts)
              if (typeof p === "object")
                p.#flatten();
          } else {
            let iterations = 0, done = !1;
            do {
              done = !0;
              for (let i = 0;i < this.#parts.length; i++) {
                let c = this.#parts[i];
                if (typeof c === "object") {
                  if (c.#flatten(), this.#canAdopt(c))
                    done = !1, this.#adopt(c, i);
                  else if (this.#canAdoptWithSpace(c))
                    done = !1, this.#adoptWithSpace(c, i);
                  else if (this.#canUsurp(c))
                    done = !1, this.#usurp(c);
                }
              }
            } while (!done && ++iterations < 10);
          }
          this.#toString = void 0;
        }
        #partsToRegExp(dot) {
          return this.#parts.map((p) => {
            if (typeof p === "string")
              throw Error("string type in extglob ast??");
            let [re, _, _hasMagic, uflag] = p.toRegExpSource(dot);
            return this.#uflag = this.#uflag || uflag, re;
          }).filter((p) => !(this.isStart() && this.isEnd()) || !!p).join("|");
        }
        static #parseGlob(glob2, hasMagic, noEmpty = !1) {
          let escaping = !1, re = "", uflag = !1, inStar = !1;
          for (let i = 0;i < glob2.length; i++) {
            let c = glob2.charAt(i);
            if (escaping) {
              escaping = !1, re += (reSpecials.has(c) ? "\\" : "") + c;
              continue;
            }
            if (c === "*") {
              if (inStar)
                continue;
              inStar = !0, re += noEmpty && /^[*]+$/.test(glob2) ? starNoEmpty : star2, hasMagic = !0;
              continue;
            } else
              inStar = !1;
            if (c === "\\") {
              if (i === glob2.length - 1)
                re += "\\\\";
              else
                escaping = !0;
              continue;
            }
            if (c === "[") {
              let [src, needUflag, consumed, magic] = (0, brace_expressions_js_1.parseClass)(glob2, i);
              if (consumed) {
                re += src, uflag = uflag || needUflag, i += consumed - 1, hasMagic = hasMagic || magic;
                continue;
              }
            }
            if (c === "?") {
              re += qmark2, hasMagic = !0;
              continue;
            }
            re += regExpEscape2(c);
          }
          return [re, (0, unescape_js_12.unescape)(glob2), !!hasMagic, uflag];
        }
      };
      exports2.AST = AST, _a = AST;
    }
  }), require_escape = __commonJS({
    "dist/commonjs/escape.js"(exports2) {
      Object.defineProperty(exports2, "__esModule", { value: !0 }), exports2.escape = void 0;
      var escape = (s, { windowsPathsNoEscape = !1, magicalBraces = !1 } = {}) => {
        if (magicalBraces)
          return windowsPathsNoEscape ? s.replace(/[?*()[\]{}]/g, "[$&]") : s.replace(/[?*()[\]\\{}]/g, "\\$&");
        return windowsPathsNoEscape ? s.replace(/[?*()[\]]/g, "[$&]") : s.replace(/[?*()[\]\\]/g, "\\$&");
      };
      exports2.escape = escape;
    }
  });
  Object.defineProperty(exports, "__esModule", { value: !0 }), exports.unescape = exports.escape = exports.AST = exports.Minimatch = exports.match = exports.makeRe = exports.braceExpand = exports.defaults = exports.filter = exports.GLOBSTAR = exports.sep = exports.minimatch = void 0;
  var brace_expansion_1 = require_commonjs2(), assert_valid_pattern_js_1 = require_assert_valid_pattern(), ast_js_1 = require_ast(), escape_js_1 = require_escape(), unescape_js_1 = require_unescape(), minimatch = (p, pattern, options = {}) => {
    if ((0, assert_valid_pattern_js_1.assertValidPattern)(pattern), !options.nocomment && pattern.charAt(0) === "#")
      return !1;
    return new Minimatch(pattern, options).match(p);
  };
  exports.minimatch = minimatch;
  var starDotExtRE = /^\*+([^+@!?*[(]*)$/, starDotExtTest = (ext2) => (f) => !f.startsWith(".") && f.endsWith(ext2), starDotExtTestDot = (ext2) => (f) => f.endsWith(ext2), starDotExtTestNocase = (ext2) => {
    return ext2 = ext2.toLowerCase(), (f) => !f.startsWith(".") && f.toLowerCase().endsWith(ext2);
  }, starDotExtTestNocaseDot = (ext2) => {
    return ext2 = ext2.toLowerCase(), (f) => f.toLowerCase().endsWith(ext2);
  }, starDotStarRE = /^\*+\.\*+$/, starDotStarTest = (f) => !f.startsWith(".") && f.includes("."), starDotStarTestDot = (f) => f !== "." && f !== ".." && f.includes("."), dotStarRE = /^\.\*+$/, dotStarTest = (f) => f !== "." && f !== ".." && f.startsWith("."), starRE = /^\*+$/, starTest = (f) => f.length !== 0 && !f.startsWith("."), starTestDot = (f) => f.length !== 0 && f !== "." && f !== "..", qmarksRE = /^\?+([^+@!?*[(]*)?$/, qmarksTestNocase = ([m0, ext2 = ""]) => {
    let noext = qmarksTestNoExt([m0]);
    if (!ext2)
      return noext;
    return ext2 = ext2.toLowerCase(), (f) => noext(f) && f.toLowerCase().endsWith(ext2);
  }, qmarksTestNocaseDot = ([m0, ext2 = ""]) => {
    let noext = qmarksTestNoExtDot([m0]);
    if (!ext2)
      return noext;
    return ext2 = ext2.toLowerCase(), (f) => noext(f) && f.toLowerCase().endsWith(ext2);
  }, qmarksTestDot = ([m0, ext2 = ""]) => {
    let noext = qmarksTestNoExtDot([m0]);
    return !ext2 ? noext : (f) => noext(f) && f.endsWith(ext2);
  }, qmarksTest = ([m0, ext2 = ""]) => {
    let noext = qmarksTestNoExt([m0]);
    return !ext2 ? noext : (f) => noext(f) && f.endsWith(ext2);
  }, qmarksTestNoExt = ([m0]) => {
    let len = m0.length;
    return (f) => f.length === len && !f.startsWith(".");
  }, qmarksTestNoExtDot = ([m0]) => {
    let len = m0.length;
    return (f) => f.length === len && f !== "." && f !== "..";
  }, defaultPlatform = typeof process === "object" && process ? typeof process.env === "object" && process.env && process.env.__MINIMATCH_TESTING_PLATFORM__ || "darwin" : "posix", path = {
    win32: { sep: "\\" },
    posix: { sep: "/" }
  };
  exports.sep = defaultPlatform === "win32" ? path.win32.sep : path.posix.sep, exports.minimatch.sep = exports.sep, exports.GLOBSTAR = /* @__PURE__ */ Symbol("globstar **"), exports.minimatch.GLOBSTAR = exports.GLOBSTAR;
  var qmark = "[^/]", star = qmark + "*?", twoStarDot = "(?:(?!(?:\\/|^)(?:\\.{1,2})($|\\/)).)*?", twoStarNoDot = "(?:(?!(?:\\/|^)\\.).)*?", filter = (pattern, options = {}) => (p) => (0, exports.minimatch)(p, pattern, options);
  exports.filter = filter, exports.minimatch.filter = exports.filter;
  var ext = (a, b = {}) => Object.assign({}, a, b), defaults = (def) => {
    if (!def || typeof def !== "object" || !Object.keys(def).length)
      return exports.minimatch;
    let orig = exports.minimatch;
    return Object.assign((p, pattern, options = {}) => orig(p, pattern, ext(def, options)), {
      Minimatch: class Minimatch2 extends orig.Minimatch {
        constructor(pattern, options = {}) {
          super(pattern, ext(def, options));
        }
        static defaults(options) {
          return orig.defaults(ext(def, options)).Minimatch;
        }
      },
      AST: class AST extends orig.AST {
        constructor(type, parent, options = {}) {
          super(type, parent, ext(def, options));
        }
        static fromGlob(pattern, options = {}) {
          return orig.AST.fromGlob(pattern, ext(def, options));
        }
      },
      unescape: (s, options = {}) => orig.unescape(s, ext(def, options)),
      escape: (s, options = {}) => orig.escape(s, ext(def, options)),
      filter: (pattern, options = {}) => orig.filter(pattern, ext(def, options)),
      defaults: (options) => orig.defaults(ext(def, options)),
      makeRe: (pattern, options = {}) => orig.makeRe(pattern, ext(def, options)),
      braceExpand: (pattern, options = {}) => orig.braceExpand(pattern, ext(def, options)),
      match: (list, pattern, options = {}) => orig.match(list, pattern, ext(def, options)),
      sep: orig.sep,
      GLOBSTAR: exports.GLOBSTAR
    });
  };
  exports.defaults = defaults, exports.minimatch.defaults = exports.defaults;
  var braceExpand = (pattern, options = {}) => {
    if ((0, assert_valid_pattern_js_1.assertValidPattern)(pattern), options.nobrace || !/\{(?:(?!\{).)*\}/.test(pattern))
      return [pattern];
    return (0, brace_expansion_1.expand)(pattern, { max: options.braceExpandMax });
  };
  exports.braceExpand = braceExpand, exports.minimatch.braceExpand = exports.braceExpand;
  var makeRe = (pattern, options = {}) => new Minimatch(pattern, options).makeRe();
  exports.makeRe = makeRe, exports.minimatch.makeRe = exports.makeRe;
  var match = (list, pattern, options = {}) => {
    let mm = new Minimatch(pattern, options);
    if (list = list.filter((f) => mm.match(f)), mm.options.nonull && !list.length)
      list.push(pattern);
    return list;
  };
  exports.match = match, exports.minimatch.match = exports.match;
  var globMagic = /[?*]|[+@!]\(.*?\)|\[|\]/, regExpEscape = (s) => s.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, "\\$&"), Minimatch = class {
    options;
    set;
    pattern;
    windowsPathsNoEscape;
    nonegate;
    negate;
    comment;
    empty;
    preserveMultipleSlashes;
    partial;
    globSet;
    globParts;
    nocase;
    isWindows;
    platform;
    windowsNoMagicRoot;
    maxGlobstarRecursion;
    regexp;
    constructor(pattern, options = {}) {
      (0, assert_valid_pattern_js_1.assertValidPattern)(pattern), options = options || {}, this.options = options, this.maxGlobstarRecursion = options.maxGlobstarRecursion ?? 200, this.pattern = pattern, this.platform = options.platform || defaultPlatform, this.isWindows = this.platform === "win32";
      let awe = "allowWindowsEscape";
      if (this.windowsPathsNoEscape = !!options.windowsPathsNoEscape || options[awe] === !1, this.windowsPathsNoEscape)
        this.pattern = this.pattern.replace(/\\/g, "/");
      this.preserveMultipleSlashes = !!options.preserveMultipleSlashes, this.regexp = null, this.negate = !1, this.nonegate = !!options.nonegate, this.comment = !1, this.empty = !1, this.partial = !!options.partial, this.nocase = !!this.options.nocase, this.windowsNoMagicRoot = options.windowsNoMagicRoot !== void 0 ? options.windowsNoMagicRoot : !!(this.isWindows && this.nocase), this.globSet = [], this.globParts = [], this.set = [], this.make();
    }
    hasMagic() {
      if (this.options.magicalBraces && this.set.length > 1)
        return !0;
      for (let pattern of this.set)
        for (let part of pattern)
          if (typeof part !== "string")
            return !0;
      return !1;
    }
    debug(..._) {}
    make() {
      let pattern = this.pattern, options = this.options;
      if (!options.nocomment && pattern.charAt(0) === "#") {
        this.comment = !0;
        return;
      }
      if (!pattern) {
        this.empty = !0;
        return;
      }
      if (this.parseNegate(), this.globSet = [...new Set(this.braceExpand())], options.debug)
        this.debug = (...args) => console.error(...args);
      this.debug(this.pattern, this.globSet);
      let rawGlobParts = this.globSet.map((s) => this.slashSplit(s));
      this.globParts = this.preprocess(rawGlobParts), this.debug(this.pattern, this.globParts);
      let set = this.globParts.map((s, _, __) => {
        if (this.isWindows && this.windowsNoMagicRoot) {
          let isUNC = s[0] === "" && s[1] === "" && (s[2] === "?" || !globMagic.test(s[2])) && !globMagic.test(s[3]), isDrive = /^[a-z]:/i.test(s[0]);
          if (isUNC)
            return [...s.slice(0, 4), ...s.slice(4).map((ss) => this.parse(ss))];
          else if (isDrive)
            return [s[0], ...s.slice(1).map((ss) => this.parse(ss))];
        }
        return s.map((ss) => this.parse(ss));
      });
      if (this.debug(this.pattern, set), this.set = set.filter((s) => s.indexOf(!1) === -1), this.isWindows)
        for (let i = 0;i < this.set.length; i++) {
          let p = this.set[i];
          if (p[0] === "" && p[1] === "" && this.globParts[i][2] === "?" && typeof p[3] === "string" && /^[a-z]:$/i.test(p[3]))
            p[2] = "?";
        }
      this.debug(this.pattern, this.set);
    }
    preprocess(globParts) {
      if (this.options.noglobstar) {
        for (let partset of globParts)
          for (let j = 0;j < partset.length; j++)
            if (partset[j] === "**")
              partset[j] = "*";
      }
      let { optimizationLevel = 1 } = this.options;
      if (optimizationLevel >= 2)
        globParts = this.firstPhasePreProcess(globParts), globParts = this.secondPhasePreProcess(globParts);
      else if (optimizationLevel >= 1)
        globParts = this.levelOneOptimize(globParts);
      else
        globParts = this.adjascentGlobstarOptimize(globParts);
      return globParts;
    }
    adjascentGlobstarOptimize(globParts) {
      return globParts.map((parts) => {
        let gs = -1;
        while ((gs = parts.indexOf("**", gs + 1)) !== -1) {
          let i = gs;
          while (parts[i + 1] === "**")
            i++;
          if (i !== gs)
            parts.splice(gs, i - gs);
        }
        return parts;
      });
    }
    levelOneOptimize(globParts) {
      return globParts.map((parts) => {
        return parts = parts.reduce((set, part) => {
          let prev = set[set.length - 1];
          if (part === "**" && prev === "**")
            return set;
          if (part === "..") {
            if (prev && prev !== ".." && prev !== "." && prev !== "**")
              return set.pop(), set;
          }
          return set.push(part), set;
        }, []), parts.length === 0 ? [""] : parts;
      });
    }
    levelTwoFileOptimize(parts) {
      if (!@Array.isArray(parts))
        parts = this.slashSplit(parts);
      let didSomething = !1;
      do {
        if (didSomething = !1, !this.preserveMultipleSlashes) {
          for (let i = 1;i < parts.length - 1; i++) {
            let p = parts[i];
            if (i === 1 && p === "" && parts[0] === "")
              continue;
            if (p === "." || p === "")
              didSomething = !0, parts.splice(i, 1), i--;
          }
          if (parts[0] === "." && parts.length === 2 && (parts[1] === "." || parts[1] === ""))
            didSomething = !0, parts.pop();
        }
        let dd = 0;
        while ((dd = parts.indexOf("..", dd + 1)) !== -1) {
          let p = parts[dd - 1];
          if (p && p !== "." && p !== ".." && p !== "**" && !(this.isWindows && /^[a-z]:$/i.test(p)))
            didSomething = !0, parts.splice(dd - 1, 2), dd -= 2;
        }
      } while (didSomething);
      return parts.length === 0 ? [""] : parts;
    }
    firstPhasePreProcess(globParts) {
      let didSomething = !1;
      do {
        didSomething = !1;
        for (let parts of globParts) {
          let gs = -1;
          while ((gs = parts.indexOf("**", gs + 1)) !== -1) {
            let gss = gs;
            while (parts[gss + 1] === "**")
              gss++;
            if (gss > gs)
              parts.splice(gs + 1, gss - gs);
            let next = parts[gs + 1], p = parts[gs + 2], p2 = parts[gs + 3];
            if (next !== "..")
              continue;
            if (!p || p === "." || p === ".." || !p2 || p2 === "." || p2 === "..")
              continue;
            didSomething = !0, parts.splice(gs, 1);
            let other = parts.slice(0);
            other[gs] = "**", globParts.push(other), gs--;
          }
          if (!this.preserveMultipleSlashes) {
            for (let i = 1;i < parts.length - 1; i++) {
              let p = parts[i];
              if (i === 1 && p === "" && parts[0] === "")
                continue;
              if (p === "." || p === "")
                didSomething = !0, parts.splice(i, 1), i--;
            }
            if (parts[0] === "." && parts.length === 2 && (parts[1] === "." || parts[1] === ""))
              didSomething = !0, parts.pop();
          }
          let dd = 0;
          while ((dd = parts.indexOf("..", dd + 1)) !== -1) {
            let p = parts[dd - 1];
            if (p && p !== "." && p !== ".." && p !== "**") {
              didSomething = !0;
              let splin = dd === 1 && parts[dd + 1] === "**" ? ["."] : [];
              if (parts.splice(dd - 1, 2, ...splin), parts.length === 0)
                parts.push("");
              dd -= 2;
            }
          }
        }
      } while (didSomething);
      return globParts;
    }
    secondPhasePreProcess(globParts) {
      for (let i = 0;i < globParts.length - 1; i++)
        for (let j = i + 1;j < globParts.length; j++) {
          let matched = this.partsMatch(globParts[i], globParts[j], !this.preserveMultipleSlashes);
          if (matched) {
            globParts[i] = [], globParts[j] = matched;
            break;
          }
        }
      return globParts.filter((gs) => gs.length);
    }
    partsMatch(a, b, emptyGSMatch = !1) {
      let ai = 0, bi = 0, result = [], which = "";
      while (ai < a.length && bi < b.length)
        if (a[ai] === b[bi])
          result.push(which === "b" ? b[bi] : a[ai]), ai++, bi++;
        else if (emptyGSMatch && a[ai] === "**" && b[bi] === a[ai + 1])
          result.push(a[ai]), ai++;
        else if (emptyGSMatch && b[bi] === "**" && a[ai] === b[bi + 1])
          result.push(b[bi]), bi++;
        else if (a[ai] === "*" && b[bi] && (this.options.dot || !b[bi].startsWith(".")) && b[bi] !== "**") {
          if (which === "b")
            return !1;
          which = "a", result.push(a[ai]), ai++, bi++;
        } else if (b[bi] === "*" && a[ai] && (this.options.dot || !a[ai].startsWith(".")) && a[ai] !== "**") {
          if (which === "a")
            return !1;
          which = "b", result.push(b[bi]), ai++, bi++;
        } else
          return !1;
      return a.length === b.length && result;
    }
    parseNegate() {
      if (this.nonegate)
        return;
      let pattern = this.pattern, negate = !1, negateOffset = 0;
      for (let i = 0;i < pattern.length && pattern.charAt(i) === "!"; i++)
        negate = !negate, negateOffset++;
      if (negateOffset)
        this.pattern = pattern.slice(negateOffset);
      this.negate = negate;
    }
    matchOne(file, pattern, partial = !1) {
      let fileStartIndex = 0, patternStartIndex = 0;
      if (this.isWindows) {
        let fileDrive = typeof file[0] === "string" && /^[a-z]:$/i.test(file[0]), fileUNC = !fileDrive && file[0] === "" && file[1] === "" && file[2] === "?" && /^[a-z]:$/i.test(file[3]), patternDrive = typeof pattern[0] === "string" && /^[a-z]:$/i.test(pattern[0]), patternUNC = !patternDrive && pattern[0] === "" && pattern[1] === "" && pattern[2] === "?" && typeof pattern[3] === "string" && /^[a-z]:$/i.test(pattern[3]), fdi = fileUNC ? 3 : fileDrive ? 0 : void 0, pdi = patternUNC ? 3 : patternDrive ? 0 : void 0;
        if (typeof fdi === "number" && typeof pdi === "number") {
          let [fd, pd] = [file[fdi], pattern[pdi]];
          if (fd.toLowerCase() === pd.toLowerCase())
            pattern[pdi] = fd, patternStartIndex = pdi, fileStartIndex = fdi;
        }
      }
      let { optimizationLevel = 1 } = this.options;
      if (optimizationLevel >= 2)
        file = this.levelTwoFileOptimize(file);
      if (pattern.includes(exports.GLOBSTAR))
        return this.#matchGlobstar(file, pattern, partial, fileStartIndex, patternStartIndex);
      return this.#matchOne(file, pattern, partial, fileStartIndex, patternStartIndex);
    }
    #matchGlobstar(file, pattern, partial, fileIndex, patternIndex) {
      let firstgs = pattern.indexOf(exports.GLOBSTAR, patternIndex), lastgs = pattern.lastIndexOf(exports.GLOBSTAR), [head, body, tail] = partial ? [pattern.slice(patternIndex, firstgs), pattern.slice(firstgs + 1), []] : [pattern.slice(patternIndex, firstgs), pattern.slice(firstgs + 1, lastgs), pattern.slice(lastgs + 1)], headLength = head.length;
      if (headLength) {
        let fileHead = file.slice(fileIndex, fileIndex + headLength);
        if (!this.#matchOne(fileHead, head, partial, 0, 0))
          return !1;
        fileIndex += headLength, patternIndex += headLength;
      }
      let fileTailMatch = 0, tailLength = tail.length;
      if (tailLength) {
        if (tailLength + fileIndex > file.length)
          return !1;
        let tailStart = file.length - tailLength;
        if (this.#matchOne(file, tail, partial, tailStart, 0))
          fileTailMatch = tailLength;
        else {
          if (file[file.length - 1] !== "" || fileIndex + tailLength === file.length)
            return !1;
          if (tailStart--, !this.#matchOne(file, tail, partial, tailStart, 0))
            return !1;
          fileTailMatch = tailLength + 1;
        }
      }
      if (!body.length) {
        let sawSome = !!fileTailMatch;
        for (let i2 = fileIndex;i2 < file.length - fileTailMatch; i2++) {
          let f = @String(file[i2]);
          if (sawSome = !0, f === "." || f === ".." || !this.options.dot && f.startsWith("."))
            return !1;
        }
        return partial || sawSome;
      }
      let bodySegments = [[[], 0]], currentBody = bodySegments[0], nonGsParts = 0, nonGsPartsSums = [0];
      for (let b of body)
        if (b === exports.GLOBSTAR)
          nonGsPartsSums.push(nonGsParts), currentBody = [[], 0], bodySegments.push(currentBody);
        else
          currentBody[0].push(b), nonGsParts++;
      let i = bodySegments.length - 1, fileLength = file.length - fileTailMatch;
      for (let b of bodySegments)
        b[1] = fileLength - (nonGsPartsSums[i--] + b[0].length);
      return !!this.#matchGlobStarBodySections(file, bodySegments, fileIndex, 0, partial, 0, !!fileTailMatch);
    }
    #matchGlobStarBodySections(file, bodySegments, fileIndex, bodyIndex, partial, globStarDepth, sawTail) {
      let bs = bodySegments[bodyIndex];
      if (!bs) {
        for (let i = fileIndex;i < file.length; i++) {
          sawTail = !0;
          let f = file[i];
          if (f === "." || f === ".." || !this.options.dot && f.startsWith("."))
            return !1;
        }
        return sawTail;
      }
      let [body, after] = bs;
      while (fileIndex <= after) {
        if (this.#matchOne(file.slice(0, fileIndex + body.length), body, partial, fileIndex, 0) && globStarDepth < this.maxGlobstarRecursion) {
          let sub = this.#matchGlobStarBodySections(file, bodySegments, fileIndex + body.length, bodyIndex + 1, partial, globStarDepth + 1, sawTail);
          if (sub !== !1)
            return sub;
        }
        let f = file[fileIndex];
        if (f === "." || f === ".." || !this.options.dot && f.startsWith("."))
          return !1;
        fileIndex++;
      }
      return partial || null;
    }
    #matchOne(file, pattern, partial, fileIndex, patternIndex) {
      let fi, pi, pl, fl;
      for (fi = fileIndex, pi = patternIndex, fl = file.length, pl = pattern.length;fi < fl && pi < pl; fi++, pi++) {
        this.debug("matchOne loop");
        let p = pattern[pi], f = file[fi];
        if (this.debug(pattern, p, f), p === !1 || p === exports.GLOBSTAR)
          return !1;
        let hit;
        if (typeof p === "string")
          hit = f === p, this.debug("string match", p, f, hit);
        else
          hit = p.test(f), this.debug("pattern match", p, f, hit);
        if (!hit)
          return !1;
      }
      if (fi === fl && pi === pl)
        return !0;
      else if (fi === fl)
        return partial;
      else if (pi === pl)
        return fi === fl - 1 && file[fi] === "";
      else
        throw Error("wtf?");
    }
    braceExpand() {
      return (0, exports.braceExpand)(this.pattern, this.options);
    }
    parse(pattern) {
      (0, assert_valid_pattern_js_1.assertValidPattern)(pattern);
      let options = this.options;
      if (pattern === "**")
        return exports.GLOBSTAR;
      if (pattern === "")
        return "";
      let m, fastTest = null;
      if (m = pattern.match(starRE))
        fastTest = options.dot ? starTestDot : starTest;
      else if (m = pattern.match(starDotExtRE))
        fastTest = (options.nocase ? options.dot ? starDotExtTestNocaseDot : starDotExtTestNocase : options.dot ? starDotExtTestDot : starDotExtTest)(m[1]);
      else if (m = pattern.match(qmarksRE))
        fastTest = (options.nocase ? options.dot ? qmarksTestNocaseDot : qmarksTestNocase : options.dot ? qmarksTestDot : qmarksTest)(m);
      else if (m = pattern.match(starDotStarRE))
        fastTest = options.dot ? starDotStarTestDot : starDotStarTest;
      else if (m = pattern.match(dotStarRE))
        fastTest = dotStarTest;
      let re = ast_js_1.AST.fromGlob(pattern, this.options).toMMPattern();
      if (fastTest && typeof re === "object")
        Reflect.defineProperty(re, "test", { value: fastTest });
      return re;
    }
    makeRe() {
      let regexp = this.regexp;
      if (regexp || regexp === !1)
        return regexp;
      let set = this.set;
      if (!set.length)
        return this.regexp = !1, this.regexp;
      let options = this.options, twoStar = options.noglobstar ? star : options.dot ? twoStarDot : twoStarNoDot, flags = new Set(options.nocase ? ["i"] : []), re = set.map((pattern) => {
        let pp = pattern.map((p) => {
          if (p instanceof @RegExp)
            for (let f of p.flags.split(""))
              flags.add(f);
          return typeof p === "string" ? regExpEscape(p) : p === exports.GLOBSTAR ? exports.GLOBSTAR : p._src;
        });
        pp.forEach((p, i) => {
          let next = pp[i + 1], prev = pp[i - 1];
          if (p !== exports.GLOBSTAR || prev === exports.GLOBSTAR)
            return;
          if (prev === void 0)
            if (next !== void 0 && next !== exports.GLOBSTAR)
              pp[i + 1] = "(?:\\/|" + twoStar + "\\/)?" + next;
            else
              pp[i] = twoStar;
          else if (next === void 0)
            pp[i - 1] = prev + "(?:\\/|\\/" + twoStar + ")?";
          else {
            let GLOBSTAR = exports.GLOBSTAR;
            if (next !== GLOBSTAR)
              pp[i - 1] = prev + "(?:\\/|\\/" + twoStar + "\\/)" + next, pp[i + 1] = GLOBSTAR;
          }
        });
        let filtered = pp.filter((p) => p !== exports.GLOBSTAR), filteredLength;
        if (this.partial && (filteredLength = filtered.length) >= 1) {
          let prefixes = [];
          for (let i = 1;i <= filteredLength; i++)
            prefixes.push(filtered.slice(0, i).join("/"));
          return "(?:" + prefixes.join("|") + ")";
        }
        return filtered.join("/");
      }).join("|"), [open, close] = set.length > 1 ? ["(?:", ")"] : ["", ""];
      if (re = "^" + open + re + close + "$", this.partial)
        re = "^(?:\\/|" + open + re.slice(1, -1) + close + ")$";
      if (this.negate)
        re = "^(?!" + re + ").+$";
      try {
        this.regexp = new @RegExp(re, [...flags].join(""));
      } catch {
        this.regexp = !1;
      }
      return this.regexp;
    }
    slashSplit(p) {
      if (this.preserveMultipleSlashes)
        return p.split("/");
      else if (this.isWindows && /^\/\/[^/]+/.test(p))
        return ["", ...p.split(/\/+/)];
      else
        return p.split(/\/+/);
    }
    match(f, partial = this.partial) {
      if (this.debug("match", f, this.pattern), this.comment)
        return !1;
      if (this.empty)
        return f === "";
      if (f === "/" && partial)
        return !0;
      let options = this.options;
      if (this.isWindows)
        f = f.split("\\").join("/");
      let ff = this.slashSplit(f);
      this.debug(this.pattern, "split", ff);
      let set = this.set;
      this.debug(this.pattern, "set", set);
      let filename = ff[ff.length - 1];
      if (!filename)
        for (let i = ff.length - 2;!filename && i >= 0; i--)
          filename = ff[i];
      for (let pattern of set) {
        let file = ff;
        if (options.matchBase && pattern.length === 1)
          file = [filename];
        if (this.matchOne(file, pattern, partial)) {
          if (options.flipNegate)
            return !0;
          return !this.negate;
        }
      }
      if (options.flipNegate)
        return !1;
      return this.negate;
    }
    static defaults(def) {
      return exports.minimatch.defaults(def).Minimatch;
    }
  };
  exports.Minimatch = Minimatch;
  var ast_js_2 = require_ast();
  Object.defineProperty(exports, "AST", {
    enumerable: !0,
    get: function() {
      return ast_js_2.AST;
    }
  });
  var escape_js_2 = require_escape();
  Object.defineProperty(exports, "escape", {
    enumerable: !0,
    get: function() {
      return escape_js_2.escape;
    }
  });
  var unescape_js_2 = require_unescape();
  return Object.defineProperty(exports, "unescape", {
    enumerable: !0,
    get: function() {
      return unescape_js_2.unescape;
    }
  }), exports.minimatch.AST = ast_js_1.AST, exports.minimatch.Minimatch = Minimatch, exports.minimatch.escape = escape_js_1.escape, exports.minimatch.unescape = unescape_js_1.unescape, _minimatch = module.exports;
}
return $

})
