(function () {"use strict";
// .zig-cache/o/8a4449a75d845ea6cf5295895b03fd23/native-modules/InternalFSBinding.mts
var $;
$ = @lazy(9);
return $

})
