var $;
// import type { Readable, Writable } from "node:stream";
// import type { WorkerOptions } from "node:worker_threads";
declare const self: typeof globalThis;
type WebWorker = InstanceType<typeof globalThis.Worker>;

const EventEmitter = (__intrinsic__getInternalField(__intrinsic__internalModuleRegistry, 114) || __intrinsic__createInternalModuleById(114));
const { AsyncResource } = (__intrinsic__getInternalField(__intrinsic__internalModuleRegistry, 104) || __intrinsic__createInternalModuleById(104));
const Readable = (__intrinsic__getInternalField(__intrinsic__internalModuleRegistry, 73) || __intrinsic__createInternalModuleById(73));
const { throwNotImplemented, warnNotImplementedOnce } = (__intrinsic__getInternalField(__intrinsic__internalModuleRegistry, 38) || __intrinsic__createInternalModuleById(38));

const {
  MessageChannel,
  BroadcastChannel,
  Worker: WebWorker,
} = globalThis as typeof globalThis & {
  // The Worker constructor secretly takes an extra parameter to provide the node:worker_threads
  // instance. This is so that it can emit the `worker` event on the process with the
  // node:worker_threads instance instead of the Web Worker instance.
  Worker: new (...args: [...ConstructorParameters<typeof globalThis.Worker>, nodeWorker: Worker]) => WebWorker;
};
const SHARE_ENV = Symbol("nodejs.worker_threads.SHARE_ENV");

const isMainThread = Bun.isMainThread;
const {
  0: _workerData,
  1: _threadId,
  2: _receiveMessageOnPort,
  3: environmentData,
  4: nativeParentPort,
} = __intrinsic__lazy(93) as [
  unknown,
  number,
  // eslint-disable-next-line pickier/no-unused-vars -- Parameter names describe the native ABI type.
  (port: unknown) => { message: unknown } | undefined,
  Map<unknown, unknown>,
  MessagePort | null,
];

type NodeWorkerOptions = import("node:worker_threads").WorkerOptions;

// Used to ensure that Blobs created to hold the source code for `eval: true` Workers get cleaned up
// after their Worker exits
let urlRevokeRegistry: FinalizationRegistry<string> | undefined = undefined;

function injectFakeEmitter(Class) {
  function messageEventHandler(event: MessageEvent) {
    return event.data;
  }

  function errorEventHandler(event: ErrorEvent) {
    return event.error;
  }

  const wrappedListener = Symbol("wrappedListener");

  function wrapped(run, listener) {
    const callback = function (event) {
      return listener(run(event));
    };
    listener[wrappedListener] = callback;
    return callback;
  }

  function functionForEventType(event, listener) {
    switch (event) {
      case "close": {
        const callback = function (event) {
          return listener.__intrinsic__call(this, event);
        };
        listener[wrappedListener] = callback;
        return callback;
      }
      case "error":
      case "messageerror": {
        return wrapped(errorEventHandler, listener);
      }

      default: {
        return wrapped(messageEventHandler, listener);
      }
    }
  }

  Class.prototype.on = function (event, listener) {
    this.addEventListener(event, functionForEventType(event, listener));

    return this;
  };

  Class.prototype.off = function (event, listener) {
    if (listener) {
      this.removeEventListener(event, listener[wrappedListener] || listener);
    } else {
      this.removeEventListener(event);
    }

    return this;
  };

  Class.prototype.once = function (event, listener) {
    this.addEventListener(event, functionForEventType(event, listener), {
      once: true,
    });

    return this;
  };

  function EventClass(eventName) {
    if (eventName === "error" || eventName === "messageerror") {
      return ErrorEvent;
    }

    return MessageEvent;
  }

  Class.prototype.emit = function (event, ...args) {
    this.dispatchEvent(new (EventClass(event))(event, ...args));

    return this;
  };

  Class.prototype.prependListener = Class.prototype.on;
  Class.prototype.prependOnceListener = Class.prototype.once;
}

const _MessagePort = globalThis.MessagePort;
injectFakeEmitter(_MessagePort);

const MessagePort = _MessagePort;

// The native binding owns close delivery, including peer/transfer/teardown
// paths. Node's optional close(callback) is an EventTarget listener: preserve
// callback identity, this, and its Event argument, including repeated close().
const nativeMessagePortClose = MessagePort.prototype.close;
MessagePort.prototype.close = function (callback) {
  if (typeof callback === "function") this.addEventListener("close", callback, { once: true });
  return nativeMessagePortClose.__intrinsic__call(this);
};

const resourceLimits = {};

// Emulation of Node's JSTransferable protocol (kTransfer/kTransferList/kDeserialize) for
// objects like FileHandle that are not natively transferable in Bun. On send, each such
// object in the transferList is replaced inside workerData by a serializable marker object;
// on receive, markers are swapped back for reconstructed instances.
// A plain string key on purpose: Symbols don't survive structured clone, and
// Bun has no native HostObject hook, so the marker must ride along inside the
// cloned graph (including Map/Set entries). This is in-band signaling: a user
// object that fabricates the key in workerData will deserialize on the worker
// side where node would deliver it unchanged. That's accepted - it is not a
// privilege boundary (worker threads share the parent's fd table anyway).
const kJSTransferableMarker = "__bunNodeWorkerJSTransferable";

function isJSTransferableMarker(value: object): boolean {
  return (
    typeof (value as Record<string, unknown>)[kJSTransferableMarker] === "string" &&
    Object.prototype.hasOwnProperty.__intrinsic__call(value, kJSTransferableMarker)
  );
}

function deserializeJSTransferable(marker: Record<string, any>): unknown {
  const deserializeInfo = marker[kJSTransferableMarker];
  switch (deserializeInfo) {
    case "internal/fs/promises:FileHandle": {
      const { FileHandle, kDeserialize } = (__intrinsic__getInternalField(__intrinsic__internalModuleRegistry, 116) || __intrinsic__createInternalModuleById(116)).promises.__intrinsic__data;
      const handle = new FileHandle(-1);
      handle[kDeserialize](marker.data);
      return handle;
    }
    default:
      return marker;
  }
}

function unpackJSTransferables(value: unknown, memo?: Map<object, unknown>): unknown {
  if (value === null || typeof value !== "object") return value;
  memo ??= new Map();
  // The memo both breaks cycles (containers map to themselves) and preserves
  // reference identity for markers: structured clone keeps a marker shared
  // between graph positions as one object, so the same marker must
  // deserialize to the same instance (one FileHandle per transferred fd,
  // like node's host-object back-references).
  const cached = memo.get(value);
  if (cached !== undefined) return cached;
  if (isJSTransferableMarker(value)) {
    const instance = deserializeJSTransferable(value as Record<string, any>);
    memo.set(value, instance);
    return instance;
  }
  memo.set(value, value);
  if (__intrinsic__isArray(value)) {
    for (let i = 0; i < value.length; i++) {
      // skip holes so sparse arrays stay sparse, like structured clone
      if (i in value) value[i] = unpackJSTransferables(value[i], memo);
    }
    return value;
  }
  // Structured clone walks Map/Set entries (keys included), so markers can
  // arrive inside them; rebuild the entries with deserialized instances.
  if (value instanceof Map) {
    const entries: Array<[unknown, unknown]> = [];
    for (const { 0: k, 1: v } of value) {
      entries.push([unpackJSTransferables(k, memo), unpackJSTransferables(v, memo)]);
    }
    value.clear();
    for (const { 0: k, 1: v } of entries) value.set(k, v);
    return value;
  }
  if (value instanceof Set) {
    const items: unknown[] = [];
    for (const v of value) items.push(unpackJSTransferables(v, memo));
    value.clear();
    for (const v of items) value.add(v);
    return value;
  }
  const proto = Object.getPrototypeOf(value);
  if (proto === Object.prototype || proto === null) {
    for (const key of Object.keys(value)) {
      (value as Record<string, unknown>)[key] = unpackJSTransferables((value as Record<string, unknown>)[key], memo);
    }
  }
  return value;
}

const kRestoreJSTransferables = Symbol("kRestoreJSTransferables");
const kFinalizeJSTransferables = Symbol("kFinalizeJSTransferables");

function packJSTransferables(options: NodeWorkerOptions): NodeWorkerOptions {
  const transferList = options?.transferList;
  if (!transferList || !__intrinsic__isArray(transferList) || transferList.length === 0) return options;
  // Avoid loading node:fs for transfer lists that only contain native transferables.
  let hasCandidate = false;
  for (const item of transferList) {
    if (
      item !== null &&
      typeof item === "object" &&
      !(item instanceof ArrayBuffer) &&
      !(item instanceof _MessagePort) &&
      !__intrinsic__isTypedArrayView(item)
    ) {
      hasCandidate = true;
      break;
    }
  }
  if (!hasCandidate) return options;

  const { kTransfer, kTransferList, kDeserialize } = (__intrinsic__getInternalField(__intrinsic__internalModuleRegistry, 116) || __intrinsic__createInternalModuleById(116)).promises.__intrinsic__data;
  let replacements: Map<object, object> | undefined;
  const nativeTransferList: unknown[] = [];
  // kTransfer() neuters the handle (extracts the bare fd); if anything later
  // in the pack/construct sequence throws, restore the already-neutered
  // handles so their fds aren't orphaned.
  const neutered: Array<[item: any, data: unknown]> = [];
  function restoreNeutered() {
    for (const { 0: item, 1: data } of neutered) {
      try {
        item[kDeserialize](data);
      } catch {
        // best effort - the handle may have been closed concurrently
      }
    }
  }
  try {
    for (const item of transferList) {
      if (item !== null && typeof item === "object" && typeof item[kTransfer] === "function") {
        if (replacements?.has(item)) {
          // node (and the HTML spec) reject duplicate transferList entries;
          // without this the second kTransfer() would read the already
          // neutered fd (-1) and clobber the real marker.
          throw new DOMException(
            `Transfer list contains duplicate ${item.constructor?.name ?? "entry"}`,
            "DataCloneError",
          );
        }
        const extraTransfers = item[kTransferList]?.();
        // May throw DataCloneError (e.g. FileHandle in use); propagate synchronously like Node.
        const { data, deserializeInfo } = item[kTransfer]();
        neutered.push([item, data]);
        (replacements ??= new Map()).set(item, {
          [kJSTransferableMarker]: deserializeInfo,
          data,
        });
        if (__intrinsic__isArray(extraTransfers)) nativeTransferList.push(...extraTransfers);
      } else {
        nativeTransferList.push(item);
      }
    }
  } catch (e) {
    restoreNeutered();
    throw e;
  }
  if (!replacements) return options;

  const seen = new Map<object, unknown>();
  const usedMarkers = new Set<object>();
  function replace(value: unknown): unknown {
    if (value === null || typeof value !== "object") return value;
    const replacement = replacements!.get(value);
    if (replacement !== undefined) {
      usedMarkers.add(value);
      return replacement;
    }
    const cached = seen.get(value);
    if (cached !== undefined) return cached;
    if (__intrinsic__isArray(value)) {
      const out = new Array(value.length);
      seen.set(value, out);
      // skip holes so sparse arrays stay sparse, like structured clone
      for (let i = 0; i < value.length; i++) {
        if (i in value) out[i] = replace(value[i]);
      }
      return out;
    }
    // Mirror structured clone: Map/Set entries (keys included) participate
    // in the graph, so a transferred handle inside them must become its
    // marker rather than being orphaned.
    if (value instanceof Map) {
      const out = new Map();
      seen.set(value, out);
      for (const { 0: k, 1: v } of value) out.set(replace(k), replace(v));
      return out;
    }
    if (value instanceof Set) {
      const out = new Set();
      seen.set(value, out);
      for (const v of value) out.add(replace(v));
      return out;
    }
    const proto = Object.getPrototypeOf(value);
    if (proto === Object.prototype || proto === null) {
      const out: Record<string, unknown> = {};
      seen.set(value, out);
      for (const key of Object.keys(value)) out[key] = replace((value as Record<string, unknown>)[key]);
      return out;
    }
    return value;
  }
  // replace() reads property getters and Proxy traps (Object.keys,
  // Object.getPrototypeOf, value[key]), and the options spread reads
  // getters on the user's options object — any of which can throw after
  // handles are already neutered. Roll back here too so a throwing
  // workerData graph doesn't orphan the fds it transferred.
  let packed;
  try {
    packed = {
      ...options,
      workerData: replace(options.workerData),
      transferList: nativeTransferList,
    };
  } catch (e) {
    restoreNeutered();
    throw e;
  }
  packed[kRestoreJSTransferables] = restoreNeutered;
  // A handle in transferList but never referenced from workerData is still
  // detached from this thread (fd === -1, like node), but no marker will
  // deserialize it on the worker side - close the orphaned fd instead of
  // leaking it (node's worker-side instance is reclaimed by GC). This runs
  // only after WebWorker construction succeeds: if construction throws, the
  // rollback above must still find the fd open to restore the handle (node
  // leaves the handle fully usable in that case).
  packed[kFinalizeJSTransferables] = function finalizeJSTransferables() {
    for (const { 0: item, 1: data } of neutered) {
      if (!usedMarkers.has(item) && typeof (data as any)?.fd === "number" && (data as any).fd >= 0) {
        try {
          (__intrinsic__getInternalField(__intrinsic__internalModuleRegistry, 116) || __intrinsic__createInternalModuleById(116)).closeSync((data as any).fd);
        } catch {
          // already closed
        }
      }
    }
  };
  return packed;
}

const workerData = unpackJSTransferables(_workerData);
const threadId = _threadId;
function receiveMessageOnPort(port: MessagePort) {
  // The native queue returns an envelope even when the payload is undefined.
  // Only an empty queue returns undefined; payload truthiness is irrelevant.
  return _receiveMessageOnPort(port);
}

// The worker VM owns a real, transferable native MessagePort before user code runs.
const parentPort: MessagePort | null = nativeParentPort;

function getEnvironmentData(key: unknown): unknown {
  return environmentData.get(key);
}

function setEnvironmentData(key: unknown, value: unknown): void {
  if (value === undefined) {
    environmentData.delete(key);
  } else {
    environmentData.set(key, value);
  }
}

function markAsUntransferable() {
  throwNotImplemented("worker_threads.markAsUntransferable");
}

function moveMessagePortToContext() {
  throwNotImplemented("worker_threads.moveMessagePortToContext");
}

class Worker extends EventEmitter {
  #worker: WebWorker;
  #performance;

  // This is used by terminate(); it is either the exit code after close, a
  // promise resolving to the exit code, or undefined before either happens.
  #onExitPromise: Promise<number> | number | undefined = undefined;
  #hasExited = false;
  #urlToRevoke = "";

  constructor(filename: string, options: NodeWorkerOptions = {}) {
    super();
    const eventResource = new AsyncResource("WORKER");

    options = packJSTransferables(options);

    const builtinsGeneratorHatesEval = "ev" + "a" + "l"[0];
    if (options && builtinsGeneratorHatesEval in options) {
      if (options[builtinsGeneratorHatesEval]) {
        // TODO: consider doing this step in native code and letting the Blob be cleaned up by the
        // C++ Worker object's destructor
        const blob = new Blob([filename], { type: "" });
        this.#urlToRevoke = filename = URL.createObjectURL(blob);
      } else {
        // if options.eval = false, allow the constructor below to fail, if
        // we convert the code to a blob, it will succeed.
        this.#urlToRevoke = filename;
      }
    }
    try {
      this.#worker = new WebWorker(filename, options as Bun.WorkerOptions, this);
    } catch (e) {
      // Restore any transferList handles that were already neutered by
      // packJSTransferables, so their fds aren't orphaned.
      options[kRestoreJSTransferables]?.();
      if (this.#urlToRevoke) {
        URL.revokeObjectURL(this.#urlToRevoke);
      }
      throw e;
    }
    // The transfer is committed - release fds that were transferred but are
    // not referenced from workerData (nothing will deserialize them).
    options[kFinalizeJSTransferables]?.();
    // Parent-side events belong to the Worker's creation resource, including
    // listeners registered later from a different AsyncLocalStorage context.
    this.#worker.addEventListener("close", eventResource.bind(this.#onClose, this), {
      once: true,
    });
    this.#worker.addEventListener("error", eventResource.bind(this.#onError, this));
    this.#worker.addEventListener("message", eventResource.bind(this.#onMessage, this));
    this.#worker.addEventListener("messageerror", eventResource.bind(this.#onMessageError, this));
    this.#worker.addEventListener("open", eventResource.bind(this.#onOpen, this), {
      once: true,
    });

    if (this.#urlToRevoke) {
      if (!urlRevokeRegistry) {
        urlRevokeRegistry = new FinalizationRegistry<string>(url => {
          URL.revokeObjectURL(url);
        });
      }
      urlRevokeRegistry.register(this.#worker, this.#urlToRevoke);
    }
  }

  get threadId() {
    return this.#worker.threadId;
  }

  ref() {
    this.#worker.ref();
  }

  unref() {
    this.#worker.unref();
  }

  get stdin() {
    // TODO:
    return null;
  }

  get stdout() {
    // TODO:
    return null;
  }

  get stderr() {
    // TODO:
    return null;
  }

  get performance() {
    return (this.#performance ??= {
      eventLoopUtilization() {
        warnNotImplementedOnce("worker_threads.Worker.performance");
        return {
          idle: 0,
          active: 0,
          utilization: 0,
        };
      },
    });
  }

  terminate(callback: unknown) {
    if (typeof callback === "function") {
      process.emitWarning(
        "Passing a callback to worker.terminate() is deprecated. It returns a Promise instead.",
        "DeprecationWarning",
        "DEP0132",
      );
      this.#worker.addEventListener("close", event => callback(null, event.code), { once: true });
    }

    const onExitPromise = this.#onExitPromise;
    if (onExitPromise) {
      return __intrinsic__isPromise(onExitPromise) ? onExitPromise : Promise.__intrinsic__resolve(onExitPromise);
    }

    // Bun's empty/zero native worker handler has no termination result. Keep
    // that distinction while settling immediately instead of installing a
    // close listener after the close event has already fired.
    if (this.#hasExited) {
      return Promise.__intrinsic__resolve(undefined);
    }

    const { resolve, promise } = Promise.withResolvers();
    this.#worker.addEventListener(
      "close",
      event => {
        resolve(event.code);
      },
      { once: true },
    );
    this.#worker.terminate();

    return (this.#onExitPromise = promise);
  }

  postMessage(...args: [any, any]) {
    return this.#worker.postMessage.__intrinsic__apply(this.#worker, args);
  }

  getHeapSnapshot(options: unknown) {
    const stringPromise = this.#worker.getHeapSnapshot(options);
    return stringPromise.then(s => new HeapSnapshotStream(s));
  }

  #onClose(e) {
    this.#hasExited = true;
    this.#onExitPromise = e.code;
    this.emit("exit", e.code);
  }

  #onError(event: ErrorEvent) {
    let error = event?.error;
    // if the thrown value serialized successfully, the message will be empty
    // if not the message is the actual error
    const message = event.message;
    if (message !== "") {
      error = new Error(message, { cause: event });
      const stack = event?.stack;
      if (stack) {
        error.stack = stack;
      }
    }
    this.emit("error", error);
  }

  #onMessage(event: MessageEvent) {
    // TODO: is this right?
    this.emit("message", event.data);
  }

  #onMessageError(event: MessageEvent) {
    // TODO: is this right?
    this.emit("messageerror", (event as any).error ?? event.data ?? event);
  }

  #onOpen() {
    this.emit("online");
  }

  async [Symbol.asyncDispose]() {
    await this.terminate();
  }
}

class HeapSnapshotStream extends Readable {
  #json: string | undefined;

  constructor(json: string) {
    super();
    this.#json = json;
  }

  _read() {
    if (this.#json !== undefined) {
      this.push(this.#json);
      this.push(null);
      this.#json = undefined;
    }
  }
}

$ = {
  Worker,
  workerData,
  parentPort,
  resourceLimits,
  isMainThread,
  MessageChannel,
  BroadcastChannel,
  MessagePort,
  getEnvironmentData,
  setEnvironmentData,
  getHeapSnapshot() {
    return {};
  },
  markAsUntransferable,
  moveMessagePortToContext,
  receiveMessageOnPort,
  SHARE_ENV,
  threadId,
};
;$$EXPORT$$($).$$EXPORT_END$$;
