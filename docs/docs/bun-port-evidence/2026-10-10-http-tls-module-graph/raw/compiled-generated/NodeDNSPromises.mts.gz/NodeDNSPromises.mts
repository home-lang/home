var $;
// Hardcoded module "node:dns/promises"
$ = (__intrinsic__getInternalField(__intrinsic__internalModuleRegistry, 112) || __intrinsic__createInternalModuleById(112)).promises;
;$$EXPORT$$($).$$EXPORT_END$$;
