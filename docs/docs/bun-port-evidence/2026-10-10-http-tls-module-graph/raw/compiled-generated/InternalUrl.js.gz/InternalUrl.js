(function () {"use strict";
// .zig-cache/o/8a4449a75d845ea6cf5295895b03fd23/native-modules/InternalUrl.mts
var $;
function urlToHttpOptions(url) {
  let options = {
    ...url,
    protocol: url.protocol,
    hostname: typeof url.hostname === "string" && url.hostname.startsWith("[") ? url.hostname.slice(1, -1) : url.hostname,
    hash: url.hash,
    search: url.search,
    pathname: url.pathname,
    path: `${url.pathname || ""}${url.search || ""}`,
    href: url.href
  }, port = url.port;
  if (port !== "")
    options.port = Number(port);
  let username = url.username, password;
  if (username || (password = url.password))
    options.auth = `${decodeURIComponent(username)}:${decodeURIComponent(password ?? url.password)}`;
  return options;
}
$ = {
  urlToHttpOptions
};
return $

})
