(function () {"use strict";
// .zig-cache/o/8a4449a75d845ea6cf5295895b03fd23/native-modules/InternalClusterIsPrimary.mts
var $;
$ = {
  isPrimary: Bun.env.NODE_UNIQUE_ID == null
};
return $

})
