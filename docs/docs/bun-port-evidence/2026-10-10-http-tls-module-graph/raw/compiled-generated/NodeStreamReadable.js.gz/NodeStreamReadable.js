(function () {"use strict";
// .zig-cache/o/8a4449a75d845ea6cf5295895b03fd23/native-modules/NodeStreamReadable.mts
var $;
$ = @getInternalField(@internalModuleRegistry, 73) || @createInternalModuleById(73);
return $

})
