(function () {"use strict";
// .zig-cache/o/8a4449a75d845ea6cf5295895b03fd23/native-modules/NodeCluster.mts
var $, { isPrimary } = @getInternalField(@internalModuleRegistry, 15) || @createInternalModuleById(15), cluster = isPrimary ? @getInternalField(@internalModuleRegistry, 16) || @createInternalModuleById(16) : @getInternalField(@internalModuleRegistry, 14) || @createInternalModuleById(14);
$ = cluster;
function initializeClusterIPC() {
  if (process.argv[1] && process.env.NODE_UNIQUE_ID)
    cluster._setupWorker(), delete process.env.NODE_UNIQUE_ID;
}
if (Bun.isMainThread)
  initializeClusterIPC();
return $

})
