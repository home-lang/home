(function () {"use strict";
// .zig-cache/o/8a4449a75d845ea6cf5295895b03fd23/native-modules/InternalStreamsPassthrough.mts
var $, Transform = @getInternalField(@internalModuleRegistry, 75) || @createInternalModuleById(75);
function PassThrough(options) {
  if (!(this instanceof PassThrough))
    return new PassThrough(options);
  Transform.@call(this, options);
}
@toClass(PassThrough, "PassThrough", Transform);
PassThrough.prototype._transform = function(chunk, encoding, cb) {
  cb(null, chunk);
};
$ = PassThrough;
return $

})
