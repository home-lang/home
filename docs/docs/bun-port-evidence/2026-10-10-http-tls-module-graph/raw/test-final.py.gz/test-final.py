from pathlib import Path
import subprocess,json,sys,os,hashlib
r=Path.cwd();t=r/'zig-out/http-tls-graph-port-2026-10-10';exe=r/'zig-out/bin/home'
assert 'Build Summary: 34/34 steps succeeded' in (t/'build-poll-microtasks.log').read_text()
env=os.environ.copy();env.update(HOME_NATIVE_VM='1',BUN_DEBUG_QUIET_LOGS='1')
groups=['test-discovery', 'stream-wrap', 'stream-cancellation', 'diagnostics-lifecycle', 'node-core-cli', 'spawn-sync-ipc', 'worker-fs-task-shutdown', 'compression-lifetime', 'worker-node-zlib-shutdown', 'worker-crypto-job-shutdown', 'tls-context', 'tls-sni-alpn', 'tls-session-keylog', 'http1-parser', 'http2-fetch', 'http3', 'fetch-compress', 'fetch-abort']
commands=[('final-native-'+n,[str(exe),'run',str(r/'tests/runtime'/('native-'+n+'.test.mjs'))]) for n in groups]
commands += [('abi-final',[str(exe),'test','build-support/bundle-native-modules.test.ts','build-support/native_module_abi.test.ts','build-support/core_builtin_abi.test.ts','build-support/builtin_exports.test.ts']),('corpus',[sys.executable,str(t/'run-corpus-profiled.py'),'final-regular'])]
rows=[]
for label,cmd in commands:
 with (t/(label+'.log')).open('wb') as log:
  try:rc=subprocess.run(cmd,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=3600 if label=='corpus' else 600).returncode
  except subprocess.TimeoutExpired:rc=124
 rows.append({'label':label,'command':cmd,'exit':rc});print(label,rc,flush=True)
 (t/'final-test-summary.json').write_text(json.dumps({'executable_sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'records':rows},indent=2)+'\n')
sys.exit(0 if all(row['exit']==0 for row in rows) else 1)
