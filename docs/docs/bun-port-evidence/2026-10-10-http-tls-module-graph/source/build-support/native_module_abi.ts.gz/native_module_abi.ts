// ABI checks for incrementally owning builtin modules while other bindings
// still come from the configured external native build.
export function assertClassHeaderAbi(home: Uint8Array, external: Uint8Array, name: string, externalPath: string): void {
  if (home.length !== external.length || home.some((byte, index) => byte !== external[index])) {
    throw new Error(`Native class ABI mismatch: ${name} differs from ${externalPath}`)
  }
}

export function assertNativeClassIds(source: string, classes: readonly (readonly string[])[]): void {
  const functions = [...source.matchAll(/JSC_DEFINE_HOST_FUNCTION\(Zig::jsFunctionInherits, \(JSC::JSGlobalObject \* globalObject, JSC::CallFrame\* callFrame\)\)\s*\{([\s\S]*?)\n\}/g)]
  const cases = classes.map(([name], id) => `case ${id}: return JSValue::encode(jsBoolean(dynamicDowncast<WebCore::JS${name}>(cell) != nullptr));`).join(' ')
  const expected = `auto id = callFrame->argument(0).toInt32(globalObject); auto value = callFrame->argument(1); if (!value.isCell()) return JSValue::encode(jsBoolean(false)); auto cell = value.asCell(); switch (id) { ${cases} } return JSValue::encode(jsBoolean(false));`
  if (functions.length !== 1 || functions[0][1].replace(/\s+/g, ' ').trim() !== expected) {
    throw new Error('Linked native class identity ABI mismatch')
  }
}

export function enumValues(header: string): Map<string, number> {
  const result = new Map<string, number>()
  for (const match of header.matchAll(/^\s*([A-Za-z][A-Za-z0-9_]*)\s*=\s*(\d+),?\s*$/gm)) {
    if (result.has(match[1])) throw new Error(`Duplicate ABI enum ${match[1]}`)
    result.set(match[1], Number(match[2]))
  }
  if (result.size === 0) throw new Error('Empty native ABI enum')
  return result
}

export function moduleEnum(id: string): string {
  return id.replace(/\.[mc]?[tj]s$/, '').replace(/[^a-zA-Z0-9]+/g, ' ').split(' ')
    .map(x => ['jsc', 'ffi', 'vm', 'tls', 'os', 'ws', 'fs', 'dns'].includes(x)
      ? x.toUpperCase() : x[0].toUpperCase() + x.slice(1)).join('')
}

export function requiredId(values: Map<string, number>, name: string): number {
  const id = values.get(name)
  if (id === undefined) throw new Error(`Linked native ABI has no ${name}`)
  return id
}

export function nativeFunctionId(header: string, type: string, filename: string, symbol: string, length: number | null): number {
  // Wrapped host calls must match their complete signature and source identity.
  // Bare Zig factories use a distinct encoded-value adapter shape.
  if (type !== 'cpp' && type !== 'zig') throw new Error(`Unsupported incremental native call: ${type} ${symbol}`)
  if (!(type === 'zig' ? /^[A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*)*$/ : /^[A-Za-z_][A-Za-z0-9_:]*$/).test(symbol)) throw new Error(`Invalid native symbol: ${symbol}`)
  let nativeTarget = symbol
  if (type === 'zig') {
    if (!/^src\/(?:[A-Za-z0-9_]+\/)*[A-Za-z0-9_]+\.zig$/.test(filename)) {
      throw new Error(`Unsupported incremental Zig source or factory: ${filename} ${symbol}`)
    }
    const prefix = `/${filename}`.replaceAll('.zig', '_zig_').replace(/[^A-Za-z]/g, '_')
    nativeTarget = `JS2Zig__${prefix}_${symbol.replace(/[^A-Za-z]/g, '_')}`
    if (length === null) {
      const declaration = `extern "C" SYSV_ABI JSC::EncodedJSValue ${nativeTarget}_workaround(Zig::GlobalObject*);`
      const escaped = nativeTarget.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
      const bodies = [...header.matchAll(new RegExp(`static ALWAYS_INLINE JSC::JSValue ${escaped}\\(Zig::GlobalObject\\* global\\) \\{([^}]+)\\}`, 'g'))]
      const expected = `return JSValue::decode(${nativeTarget}_workaround(global));`
      if (header.split(declaration).length !== 2 || bodies.length !== 1 || bodies[0][1].replace(/\s+/g, ' ').trim() !== expected) {
        throw new Error(`Linked native factory signature mismatch: ${filename} ${symbol}`)
      }
    } else if (!header.includes(`BUN_DECLARE_HOST_FUNCTION(${nativeTarget});`)) throw new Error(`Linked native dispatch has no host declaration for ${filename} ${symbol}`)
  } else if (!header.includes(`#include "${filename.replace(/\.cpp$/, '.h')}"`)) {
    throw new Error(`Linked native dispatch has no header for ${filename}`)
  }
  let target = nativeTarget
  if (length !== null) {
    if (!Number.isSafeInteger(length) || length < 0 || !/^[A-Za-z_][A-Za-z0-9_:.]*$/.test(symbol)) {
      throw new Error(`Invalid native wrapper signature: ${symbol}`)
    }
    target = `js2native_wrap_${symbol.replace(/[^A-Za-z]/g, '_')}`
    const escaped = target.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
    const wrappers = [...header.matchAll(new RegExp(`static ALWAYS_INLINE JSC::JSValue ${escaped}\\(Zig::GlobalObject\\* globalObject\\) \\{([^}]+)\\}`, 'g'))]
    const displayName = symbol.split(/[^A-Za-z0-9]/g).pop()
    const expected = `return JSC::JSFunction::create(globalObject->vm(), globalObject, ${length}, "${displayName}"_s, ${nativeTarget}, JSC::ImplementationVisibility::Public);`
    if (wrappers.length !== 1 || wrappers[0][1].replace(/\s+/g, ' ').trim() !== expected) {
      throw new Error(`Linked native wrapper signature mismatch: ${symbol}`)
    }
  }
  const matches = [...header.matchAll(/case (\d+): return ([A-Za-z_][A-Za-z0-9_:]*)\(global\);/g)]
    .filter(match => match[2] === target)
  if (matches.length !== 1) throw new Error(`Linked native dispatch must contain exactly one ${symbol}`)
  return Number(matches[0][1])
}

export function replaceModuleLiteral(header: string, name: string, replacement: string): string {
  const pattern = new RegExp(`static constexpr const char ${name}CodeBytes\\[\\d+\\] = \\{[^}]*\\};\\s*static constexpr ASCIILiteral ${name}Code = ASCIILiteral::fromLiteralUnsafe\\(${name}CodeBytes\\);`, 'g')
  const matches = [...header.matchAll(pattern)]
  if (matches.length !== 1) throw new Error(`Expected exactly one generated literal for ${name}`)
  return header.replace(pattern, () => replacement)
}
