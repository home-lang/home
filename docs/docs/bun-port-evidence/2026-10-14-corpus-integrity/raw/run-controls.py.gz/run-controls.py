from pathlib import Path
import hashlib,json,subprocess,os
p=Path(__file__).resolve().parent;root=p.parents[1];rows=[]
home=root/'zig-out/bin/home';before=hashlib.sha256(home.read_bytes()).hexdigest()
commands=[('node-alpn-callback',['/Users/chris/.local/share/pantry/global/packages/nodejs.org/v26.10.0/bin/node','tests/runtime/native-https-alpn-callback.test.mjs']),('home-alpn-callback',[str(home),'tests/runtime/native-https-alpn-callback.test.mjs']),('home-alpn-storage',[str(home),'tests/runtime/native-https-alpn-storage.test.mjs']),('home-fetch-connection',[str(home),'tests/runtime/native-fetch-connection-timing.test.mjs']),('home-init-entry',[str(home),'tests/runtime/native-init-existing-entry.test.mjs'])]
for name,args in commands:
 with (p/(name+'.log')).open('wb') as log:
  try:r=subprocess.run(args,cwd=root,stdout=log,stderr=subprocess.STDOUT,timeout=60,env=os.environ.copy())
  except subprocess.TimeoutExpired:r=subprocess.CompletedProcess([],124)
 rows.append({'name':name,'command':args,'exit':r.returncode});print(name,r.returncode,flush=True)
 (p/'control-results.json').write_text(json.dumps({'home_sha256_before':before,'results':rows},indent=2)+'\n')
after=hashlib.sha256(home.read_bytes()).hexdigest();(p/'control-results.json').write_text(json.dumps({'home_sha256_before':before,'home_sha256_after':after,'stable_executable':before==after,'results':rows},indent=2)+'\n')
raise SystemExit(any(row['exit'] for row in rows) or before!=after)
