import json,subprocess
from pathlib import Path
root=Path.cwd();out=(root/'zig-out/bun-port-recovery/child-wait-cross-compile').resolve();out.mkdir(exist_ok=False)
probe=out/'probe.zig'
probe.write_text('const std = @import("std"); const child_wait = @import("wait"); export fn observe(child: *const std.process.Child, io: *const std.Io, deadline: *const std.Io.Clock.Timestamp) bool { return child_wait.waitForExitBefore(io.*, child, deadline.*) catch false; }\n')
rows=[]
for target in ['x86_64-linux-musl','x86_64-windows-gnu']:
 args=['/Users/chris/Code/Home/lang/pantry/.bin/zig','build-obj','-target',target,'--dep','wait','-Mroot='+str(probe),'-Mwait='+str(root/'packages/home_test/src/corpus_child_wait.zig'),'-lc','-O','ReleaseFast','-fno-emit-bin']
 with (out/(target+'.log')).open('xb') as log:code=subprocess.run(args,cwd=root,stdout=log,stderr=subprocess.STDOUT).returncode
 rows.append({'target':target,'argv':args,'exit_code':code,'execution_test':False});print(rows[-1],flush=True)
(out/'manifest.json').write_text(json.dumps(rows,indent=2)+'\n')
raise SystemExit(int(any(row['exit_code'] for row in rows)))
