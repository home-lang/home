Parent #66; continues #703/#722 after the native outcome and child-lifetime work (#723).

The 4,754-path discovery inventory is pre-exclusion. Home's current `corpus_runner.runGateWithOptions` selects that inventory (with optional start/limit) and runs each path. The pinned `4982b91e3702094330f3be3883354c52b8c01323` CI runner also applies platform/build modifiers and expectations, performs root/test package installs and registry/service setup, and adds vendor suites. Therefore a run of the 4,754 paths alone cannot prove completion of the upstream CI suite.

Source evidence: `scripts/runner.node.mjs` in the pinned Bun checkout, especially `getTestExpectations`, `getTestModifiers`, `getRelevantTests`, `getVendorTests`, and `runTests`. The pinned vendor manifest currently adds Elysia tag **1.4.28**, including its explicit ws-connection exclusion. Home's copied vendor.json is identical. Home's expectations.txt differs by four removed historical exclusions (bunx and three HTTP/2 files); those additional coverage decisions must stay visible, not silently replace the pinned reference or hide failures. All 4,754 discovered paths exist and the 110 declared mirrored test dependencies are present, but this is not proof that full CI setup is equivalent.

Required work:

1. Port the actual pinned modifier/expectation/filter/shard selection contract into Home. Preserve the original reference metadata and record every exclusion with its reason/modifiers. Separately retain any deliberate additional Home coverage. Excluded, skipped, TODO, unstarted, and unsupported entries never count as passing implementation credit.
2. Audit and port the real root/test installation and registry/service preparation, including environment, configuration discovery, ownership and cleanup. Execute with Home's native commands; do not substitute system Bun, fake services, dummy configs, or reduced dependency graphs. Keep setup failures explicit in the durable journal.
3. Prepare the pinned Elysia vendor checkout and dependencies, discover its actual tests and applicable original skips, and execute it in Home with the correct project/configuration context. Retain resolved revision, source/snapshot integrity, selected inventory and complete outcomes, alongside the primary corpus.
4. Verify selection against the unchanged pinned runner across supported platform/build contexts, and verify production setup/execution. Use the original deadlines and one attempt per unchanged build; no retries or deadline extensions to obtain green results.
5. Execute the complete applicable suite, including vendor tests, and preserve all failures for feature porting. Independent native build ownership, default CLI fallback removal, native Windows/Linux/ASAN execution, and unresolved runtime features remain part of #66; passing this driver comparison alone is not full parity.

This issue is a concrete remaining prerequisite, not a redefinition of #66 as only runner infrastructure or a smaller test subset.
