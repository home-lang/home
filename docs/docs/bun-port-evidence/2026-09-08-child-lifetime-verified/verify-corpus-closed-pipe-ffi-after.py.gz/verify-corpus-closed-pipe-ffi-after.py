import hashlib,json,os,shutil,subprocess,time
from pathlib import Path
root=Path.cwd();base=(root/'zig-out/bun-port-recovery').resolve();out=base/'corpus-closed-pipe-ffi-after';out.mkdir(exist_ok=False)
assert 'Build Summary: 23/23 steps succeeded' in (base/'build-corpus-child-lifetime.log').read_text()
home=root/'zig-out/bin/home'
fixture=out/'fixture';project=fixture/'packages/runtime/test';source=project/'test/js/node/test/parallel/test-closed-pipe-deadline.js';source.parent.mkdir(parents=True)
(project/'bunfig.node-test.toml').write_text('[test]\n[install]\nauto = "disable"\n')
source.write_text("import { dlopen } from 'bun:ffi'; const fs = require('node:fs'); const lib = dlopen('/usr/lib/libSystem.B.dylib', { close: { args: ['i32'], returns: 'i32' } }); const results = [lib.symbols.close(1), lib.symbols.close(2)]; fs.writeFileSync("+json.dumps(str(out/'child-ready'))+", JSON.stringify({ pid: process.pid, results })); setInterval(() => {}, 1000);\n")
(out/'source.js').write_bytes(source.read_bytes())
temp=fixture/'tmp';temp.mkdir()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
env=os.environ.copy()
for key in ['HOME_NATIVE_VM','HOME_CORPUS_FULL_VM','HOME_BUN_TEST_EXECUTABLE']:env.pop(key,None)
env.update(HOME_BUN_CORPUS_REPORT_DIR=str(out/'reports'),TMPDIR=str(temp),HOME_RUN_LABEL='native-corpus-closed-pipe-deadline')
args=['perl',str(root/'scripts/run-bounded.pl'),'30',str(home),'test',str(source)]
manifest={'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'home_sha256':sha(home),'fixture_sha256':sha(source),'argv':args,'supervisor_bound_seconds':30,'original_node_deadline_ms':20000,'status':'started','generated_control':True}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
start=time.monotonic()
with (out/'execution.log').open('xb') as log:
 code=subprocess.run(args,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL).returncode
rows=[json.loads(line) for line in (out/'reports/events.jsonl').read_text().splitlines()]
manifest.update(status='completed',exit_code=code,seconds=time.monotonic()-start,fixture_unchanged=sha(source)==manifest['fixture_sha256'],executable_unchanged=sha(home)==manifest['home_sha256'],child_entered_fixture=(out/'child-ready').exists(),close_results=json.loads((out/'child-ready').read_text()) if (out/'child-ready').exists() else None,events=rows)
manifest['per_file_deadline_satisfied']=any(row['event']=='completed' and row.get('timed_out') is True for row in rows)
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
shutil.rmtree(fixture)
print(json.dumps({key:value for key,value in manifest.items() if key!='events'}),flush=True)
# A failing per-file deadline is not accepted as passing feature coverage.
raise SystemExit(0 if manifest['per_file_deadline_satisfied'] else 1)
