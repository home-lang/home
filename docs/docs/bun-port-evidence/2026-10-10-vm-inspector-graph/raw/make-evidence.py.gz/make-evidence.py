from pathlib import Path
import json,gzip,hashlib,subprocess,sys,re
root=Path(__file__).resolve().parents[2];task=Path(__file__).resolve().parent;base=root/'docs/docs/bun-port-evidence/2026-10-10-vm-inspector-graph';base.mkdir(parents=True,exist_ok=True)
counts={};reports=[]
for path in sorted([*(task/'first').glob('validate-*.json'),*(task/'extra').glob('validate-*.json')]):
 data=json.loads(path.read_text());assert data['successful'],path
 for key,value in data['summary'].items():
  if isinstance(value,int):counts[key]=counts.get(key,0)+value
 reports.append(path.name)
assert len(reports)==77 and counts['failed']==0 and counts['skipped_files']==0
records=[]
def add(path,name):
 data=path.read_bytes();target=base/(name+'.gz');target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(gzip.compress(data,mtime=0));assert gzip.decompress(target.read_bytes())==data;records.append({'path':str(target.relative_to(base)),'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
for p in sorted(task.rglob('*')):
 if not p.is_file() or p.name.startswith('issue-') or 'manual-fixture' in p.parts or 'obsolete-cache-manifests' in p.parts:continue
 if p.suffix in ['.log','.json','.jsonl','.py','.stdout','.stderr','.xml']:
  add(p,'raw/'+str(p.relative_to(task)))
for name in json.loads((task/'ported-files.json').read_text()):add(root/'packages/runtime/upstream/src'/name,'source/packages/runtime/upstream/src/'+name)
for name in ['build-support/bundle-native-modules.ts','build-support/bundle-native-modules.test.ts','build-support/native_bindings.zig']:add(root/name,'source/'+name)
manifest={'schema':1,'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'upstream':'4982b91e3702094330f3be3883354c52b8c01323','platform':'Darwin arm64','results':{'original_files':77,'counts':counts,'native_regression_groups':7,'debug_steps':34,'debug_peak_tree_mb':5658},'features':['Seven connected VM, engine diagnostics, console, trace/repl and inspector modules execute from Home-owned generation.','The VM context, Script, module, SourceTextModule and SyntheticModule native implementations and inspector profiler are rebuilt together with complete header ABI/cache validation.','Twenty selected implementation/header files match the Bun source pin exactly.'],'limitations':['This checkpoint verifies ordinary context/module/profiling and related conformance; broader VM verification remains outstanding.','Pinned inspector lifecycle, tracing and REPL include unfinished behavior; ownership is not credit for implementing those APIs.','Disk-guard refusals receive no test credit. Obsolete native cache outputs were removed only after terminal builds, keeping newest objects and invalidating manifests.','VM per-context memory accounting remains #870; inspector lifecycle remains #428. Full Bun-suite parity and Release/ASAN/all-platform verification remain open under #66.'],'files':records}
(base/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(len(records),'verified archives',counts)
