import assert from 'node:assert/strict'
import vm from 'node:vm'
const context=vm.createContext({value:42})
let reads=0
const options={get name(){reads++;return 'unused'},get microtaskMode(){reads++;return 'afterEvaluate'}}
assert.equal(vm.createContext(context,options),context)
assert.equal(reads,0)
assert.equal(vm.createContext(context,null),context)
for(const run of [(code,options)=>vm.runInNewContext(code,{},options),(code,options)=>new vm.Script(code).runInNewContext({},options)]){
 assert.equal(run('2+2',{name:17,origin:19}),4)
 assert.throws(()=>run('2+2',{contextName:17}),{code:'ERR_INVALID_ARG_TYPE'})
 assert.throws(()=>run('2+2',{contextOrigin:19}),{code:'ERR_INVALID_ARG_TYPE'})
}
assert.throws(()=>vm.createContext({}, {importModuleDynamically:17}),{code:'ERR_INVALID_ARG_TYPE'})
console.log('existing-context option access, mapped context options and importer validation passed')
