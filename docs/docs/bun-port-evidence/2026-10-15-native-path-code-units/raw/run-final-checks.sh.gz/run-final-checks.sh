#!/bin/sh
set -u
base=zig-out/path-native-2026-10-15
export BUN_DEBUG_QUIET_LOGS=1 BUN_GARBAGE_COLLECTOR_LEVEL=1 BUN_FEATURE_FLAG_INTERNAL_FOR_TESTING=1 BUN_JSC_randomIntegrityAuditRate=1.0 BUN_RUNTIME_TRANSPILER_CACHE_PATH=0
zig-out/bin/home tests/runtime/native-path-code-units.test.mjs "$base/node-snapshot.json" > "$base/home-control-final.log" 2>&1
control_status=$?
python3 "$base/final-originals/run-originals.py" > "$base/final-originals.log" 2>&1
original_status=$?
zig-out/bin/home "$base/unicode-case-probe.mjs" > "$base/unicode-case-home.log" 2>&1
/Users/chris/.bun/bin/bun "$base/unicode-case-probe.mjs" > "$base/unicode-case-bun.log" 2>&1
/Users/chris/.bun/bin/bun tests/runtime/native-path-code-units.test.mjs "$base/installed-bun-snapshot.json" --record > "$base/installed-bun-control.log" 2>&1
zig-out/bin/home tests/runtime/native-readdir-encoding.test.mjs > "$base/readdir-control-final.log" 2>&1
readdir_status=$?
python3 scripts/audit-bun-corpus-integrity.py --source /Users/chris/Code/bun --git /usr/bin/git --output "$base/integrity.json" > "$base/integrity.log" 2>&1
integrity_status=$?
/Users/chris/.bun/bin/bun test build-support/native_module_abi.test.ts > "$base/abi.log" 2>&1
abi_status=$?
bunx --bun pickier tests/runtime/native-path-code-units.test.mjs > "$base/lint.log" 2>&1
lint_status=$?
printf '{"control":%d,"originals":%d,"abi":%d,"lint":%d,"readdir":%d,"integrity":%d}\n' "$control_status" "$original_status" "$abi_status" "$lint_status" "$readdir_status" "$integrity_status" > "$base/final-check-status.json"
test "$readdir_status" = 0 && test "$integrity_status" = 0 && test "$control_status" = 0 && test "$original_status" = 0 && test "$abi_status" = 0 && test "$lint_status" = 0
