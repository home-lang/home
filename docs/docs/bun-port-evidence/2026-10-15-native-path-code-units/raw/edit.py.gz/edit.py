from pathlib import Path
p=Path('packages/runtime/src/runtime/node/path.zig');s=p.read_text()
s=s.replace('''    if (T != u16) {
        return bun.strings.eqlCaseInsensitiveASCII(a, b, true);
    }
}''','''    if (T != u16) return bun.strings.eqlCaseInsensitiveASCII(a, b, true);
    if (a.len != b.len) return false;
    for (a, b) |left, right| {
        if (toLowerT(T, left) != toLowerT(T, right)) return false;
    }
    return true;
}''',1)
s=s.replace('[]const T = ""','[]const T = &.{}').replace('std.mem.eql(u8, dir, root)','std.mem.eql(T, dir, root)')
# Generic outputs must retain code units rather than encode as filesystem bytes.
import re
s=re.sub(r'bun.String.createUTF8ForJS\(globalObject, (this\.[a-z_]+|(?:basename|dirname|extname|join|normalize)[A-Za-z]+T\(T, [^;]+|_formatT\(T, [^;]+|r|path)\)',r'pathStringToJS(T, globalObject, \1)',s)
insert='''// Pure path operations act on JavaScript code units. Filesystem byte encoding
// belongs to the filesystem adapters, where unpaired surrogates have different
// semantics. Keep the existing UTF-8 fast path for eight-bit inputs.
fn pathStringToJS(comptime T: type, globalObject: *jsc.JSGlobalObject, value: []const T) bun.JSError!jsc.JSValue {
    if (T == u8) return bun.String.createUTF8ForJS(globalObject, value);
    var result = bun.String.cloneUTF16(value);
    defer result.deref();
    return result.toJS(globalObject);
}

fn pathSlice16(allocator: std.mem.Allocator, value: jsc.ZigString) []const u16 {
    if (value.is16Bit()) return value.utf16SliceAligned();
    const result = bun.handleOom(allocator.alloc(u16, value.len));
    for (value.slice(), result) |code_unit, *out| out.* = code_unit;
    return result;
}

'''
s=s.replace('fn PathParsed(comptime T: type) type {',insert+'fn PathParsed(comptime T: type) type {',1)
for field in ['root','dir','base','ext','name_val']:
 line=next(x for x in s.splitlines() if 'const '+field+' = try pathStringToJS' in x)
 s=s.replace(line,line+'\n            '+field+'.protect();\n            defer '+field+'.unprotect();',1)
# Single-input APIs borrow UTF-16 while the call arguments remain rooted by C++.
for method,alloc in [('dirname',''),('extname',''),('normalize','allocator, '),('parse',''),('toNamespacedPath','allocator, ')]:
 start=s.index('pub fn '+method+'(globalObject:');end=s.index('\n}',start)
 chunk=s[start:end]
 anchor='    const pathZSlice = pathZStr.toSlice(allocator);'
 assert anchor in chunk
 branch=f'    if (pathZStr.is16Bit()) return {method}JS_T(u16, globalObject, {alloc}isWindows, pathZStr.utf16SliceAligned());\n\n'
 chunk=chunk.replace(anchor,branch+anchor)
 s=s[:start]+chunk+s[end:]
# Basename needs both inputs in the same width, including a narrow suffix.
start=s.index('pub fn basename(globalObject:');end=s.index('\n}',start);chunk=s[start:end]
anchor='    const pathZSlice = pathZStr.toSlice(allocator);'
branch='''    const suffixZStr = if (suffix_ptr) |value| try value.getZigString(globalObject) else jsc.ZigString.init("");
    if (pathZStr.is16Bit() or suffixZStr.is16Bit()) {
        const path16 = pathSlice16(allocator, pathZStr);
        defer if (!pathZStr.is16Bit()) allocator.free(path16);
        const suffix16 = pathSlice16(allocator, suffixZStr);
        defer if (!suffixZStr.is16Bit()) allocator.free(suffix16);
        return basenameJS_T(u16, globalObject, isWindows, path16, if (suffix_ptr != null) suffix16 else null);
    }

'''
chunk=chunk.replace(anchor,branch+anchor);s=s[:start]+chunk+s[end:]
# Relative inputs have the same mixed-width requirement.
start=s.index('pub fn relative(globalObject:');end=s.index('\n}',start);chunk=s[start:end]
anchor='    const fromZigSlice = fromZigStr.toSlice(allocator);'
branch='''    if (fromZigStr.is16Bit() or toZigStr.is16Bit()) {
        const from16 = pathSlice16(allocator, fromZigStr);
        defer if (!fromZigStr.is16Bit()) allocator.free(from16);
        const to16 = pathSlice16(allocator, toZigStr);
        defer if (!toZigStr.is16Bit()) allocator.free(to16);
        return relativeJS_T(u16, globalObject, allocator, isWindows, from16, to16);
    }

'''
chunk=chunk.replace(anchor,branch+anchor);s=s[:start]+chunk+s[end:]
# Join validates left-to-right, then picks a single width for every input.
start=s.index('    var paths = bun.handleOom(allocator.alloc(string, args_len));',s.index('pub fn join(globalObject:'));end=s.index('\n}',start)
s=s[:start]+'''    const strings_buf = bun.handleOom(allocator.alloc(jsc.ZigString, args_len));
    var wide = false;
    for (0..args_len, args_ptr) |i, path_ptr| {
        try validateString(globalObject, path_ptr, "paths[{d}]", .{i});
        strings_buf[i] = try path_ptr.getZigString(globalObject);
        wide = wide or strings_buf[i].is16Bit();
    }
    if (wide) {
        const paths = bun.handleOom(allocator.alloc([]const u16, args_len));
        for (strings_buf, paths) |value, *out| out.* = pathSlice16(allocator, value);
        return joinJS_T(u16, globalObject, allocator, isWindows, paths);
    }
    const paths = bun.handleOom(allocator.alloc(string, args_len));
    for (strings_buf, paths) |value, *out| out.* = value.toSlice(allocator).slice();
    return joinJS_T(u8, globalObject, allocator, isWindows, paths);'''+s[end:]
# Resolve preserves its right-to-left validation and absolute-root stopping rule.
start=s.index('    var paths_buf = try allocator.alloc(string, args_len);',s.index('pub fn resolve(globalObject:'));end=s.index('\n}',start)
s=s[:start]+'''    const strings_buf = try allocator.alloc(jsc.ZigString, args_len);
    var paths_offset: usize = args_len;
    var wide = false;
    var i = args_len;
    while (i > 0) {
        i -= 1;
        const path = args_ptr[i];
        try validateString(globalObject, path, "paths[{d}]", .{i});
        const value = try path.getZigString(globalObject);
        if (value.len == 0) continue;
        paths_offset -= 1;
        strings_buf[paths_offset] = value;
        wide = wide or value.is16Bit();
        if (!isWindows and value.charAt(0) == CHAR_FORWARD_SLASH) break;
    }
    const values = strings_buf[paths_offset..];
    if (wide) {
        const paths = try allocator.alloc([]const u16, values.len);
        for (values, paths) |value, *out| out.* = pathSlice16(allocator, value);
        return resolveJS_T(u16, globalObject, allocator, isWindows, paths);
    }
    const paths = try allocator.alloc(string, values.len);
    for (values, paths) |value, *out| out.* = value.toSlice(allocator).slice();
    if (comptime Environment.isPosix) {
        if (!isWindows and (paths.len == 0 or
            (paths.len == 1 and (strings.eqlComptime(paths[0], ".") or strings.eqlComptime(paths[0], "./")))))
            return Process__getCachedCwd(globalObject);
    }
    return resolveJS_T(u8, globalObject, allocator, isWindows, paths);'''+s[end:]
# Format copies code units immediately; getters/coercions can allocate and collect.
start=s.index('    var root: []const u8 = "";',s.index('pub fn format(globalObject:'));end=s.index('\n}',start)
s=s[:start]+'''    var fields: [5][]const u16 = .{&.{}} ** 5;
    defer for (fields) |field| allocator.free(field);
    inline for (.{ "root", "dir", "base", "name", "ext" }, 0..) |key, i| {
        if (try pathObject_ptr.getTruthy(globalObject, key)) |value| {
            const str = try value.toBunString(globalObject);
            defer str.deref();
            const units = bun.handleOom(allocator.alloc(u16, str.length()));
            for (units, 0..) |*unit, index| unit.* = str.charAt(index);
            fields[i] = units;
        }
    }
    return formatJS_T(u16, globalObject, allocator, isWindows, .{
        .root = fields[0], .dir = fields[1], .base = fields[2], .name = fields[3], .ext = fields[4],
    });'''+s[end:]
p.write_text(s)
