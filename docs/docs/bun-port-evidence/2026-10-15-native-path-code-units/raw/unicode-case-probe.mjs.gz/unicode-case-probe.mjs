import { win32, posix } from 'node:path'
const pairs = [['É', 'é'], ['Ω', 'ω'], ['Я', 'я'], ['İ', 'i\u0307'], ['Σ', 'σ'], ['\u{10400}', '\u{10428}']]
console.log(JSON.stringify({ versions: process.versions, results: pairs.map(([upper, lower]) => ({ upper, lower, win32: win32.relative(`C:\\${upper}\\file`, `C:\\${lower}\\file`), posix: posix.relative(`/${upper}/file`, `/${lower}/file`) })) }))
