#!/bin/sh
set -u
base=zig-out/path-native-2026-10-15
export BUN_DEBUG_QUIET_LOGS=1 BUN_GARBAGE_COLLECTOR_LEVEL=1 BUN_FEATURE_FLAG_INTERNAL_FOR_TESTING=1 BUN_JSC_randomIntegrityAuditRate=1.0 BUN_RUNTIME_TRANSPILER_CACHE_PATH=0
zig-out/bin/home tests/runtime/native-path-code-units.test.mjs "$base/node-snapshot.json" > "$base/home-control.log" 2>&1
control_status=$?
python3 "$base/originals/run-originals.py" > "$base/originals.log" 2>&1
original_status=$?
/Users/chris/.bun/bin/bun test build-support/native_module_abi.test.ts > "$base/abi.log" 2>&1
abi_status=$?
bunx --bun pickier tests/runtime/native-path-code-units.test.mjs > "$base/lint.log" 2>&1
lint_status=$?
printf '{"control":%d,"originals":%d,"abi":%d,"lint":%d}\n' "$control_status" "$original_status" "$abi_status" "$lint_status" > "$base/check-status.json"
test "$control_status" = 0 && test "$original_status" = 0 && test "$abi_status" = 0 && test "$lint_status" = 0
