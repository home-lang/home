import json,os,subprocess,tempfile
from pathlib import Path
root=Path.cwd(); out=(root/'zig-out/bun-port-recovery/workspace-layout-diagnosis');out.mkdir(exist_ok=False)
results=[]
for label,exe in [('home',root/'zig-out/bin/home'),('bun',Path('/Users/chris/Code/bun/build/release/bun'))]:
 base=Path(tempfile.mkdtemp(prefix='home-workspace-diagnosis-'+label+'-')); project=base/'workspace-root'; app=project/'packages/app'
 app.mkdir(parents=True)
 for d,v in [('one','1.0.0'),('two','2.0.0')]:
  p=base/d;p.mkdir();(p/'package.json').write_text(json.dumps({'name':'leading-flag-dependency','version':v}))
 (project/'package.json').write_text(json.dumps({'name':'workspace-root','workspaces':['packages/*']}))
 (project/'bunfig.toml').write_text('[install]\nlinker = "hoisted"\n')
 (app/'package.json').write_text(json.dumps({'name':'workspace-app','devDependencies':{'leading-flag-dependency':'file:../../../one'}}))
 env={**os.environ,'HOME_NATIVE_VM':'1','NO_COLOR':'1','BUN_DEBUG_QUIET_LOGS':'1'}
 steps=[]
 for args in [['install','--ignore-scripts'],['--only-missing','add','file:../../../two'],['install','--frozen-lockfile','--ignore-scripts']]:
  p=subprocess.run([str(exe),*args],cwd=app,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=15)
  steps.append({'args':args,'exit':p.returncode,'stdout':p.stdout.decode(),'stderr':p.stderr.decode(),'app_manifest':(app/'package.json').read_text(),'tree':[{'path':str(x.relative_to(base)),'link':os.readlink(x) if x.is_symlink() else None} for x in base.rglob('*')]})
 results.append({'runtime':label,'fixture':str(base),'steps':steps})
 (out/'results.json').write_text(json.dumps(results,indent=2)+'\n')
 print(json.dumps(results[-1]),flush=True)
