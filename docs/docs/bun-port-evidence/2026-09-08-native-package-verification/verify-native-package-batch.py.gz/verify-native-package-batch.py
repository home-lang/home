import difflib,hashlib,json,os,re,subprocess,time
from pathlib import Path
root=Path.cwd(); evidence=(root/'zig-out/bun-port-recovery').resolve(); out=evidence/'native-package-identity-update'
out.mkdir(exist_ok=False)
home=root/'zig-out/bin/home'; bun=Path('/Users/chris/Code/bun/build/release/bun'); project=root/'packages/runtime/test'
build=evidence/'build-native-update-table.log'
assert 'Build Summary: 46/46 steps succeeded' in build.read_text(), 'New native build did not succeed'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(home)!='fbc3cfe5af5e1c020e4aad2e6d4bae74584afbd87de970b1134e3ac653da9e15', 'Stale executable'
manifest={'source_commit':subprocess.check_output(['git','rev-parse','6a183ad72'],text=True).strip(),'home_sha256':sha(home),'bun_sha256':sha(bun),'build_log_sha256':sha(build),'results':[]}
def save(): (out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
cases=[]
for name in ['native-local-dependency-identity','native-update-outdated','native-frozen-prerelease']:
 source=root/'tests/runtime'/(name+'.test.mjs')
 cases.append((name,[home,'run',source],root,{'HOME_NATIVE_VM':'1'},source))
for name,relative,pattern in [('update','cli/install/bun-update.test.ts',None),('outdated','cli/install/bun-install-registry.test.ts','^outdated')]:
 source=project/'test'/relative
 for runtime,exe in [('home',home),('bun',bun)]:
  args=[exe,'test']
  env={}
  cwd=root if runtime=='home' else project
  if runtime=='bun' or pattern: args+=['--config='+str(project/'bunfig.toml')]
  args+=[source]
  if pattern:
   args+=['--test-name-pattern',pattern]
   if runtime=='home': env={'HOME_NATIVE_VM':'1','HOME_CORPUS_FULL_VM':'1'}
  cases.append((name+'-'+runtime,args,cwd,env,source))
for label,args,cwd,extra,source in cases:
 manifest['results'].append({'label':label,'argv':list(map(str,args)),'cwd':str(cwd),'source_sha256':sha(source),'status':'selected'})
save()
for case,row in zip(cases,manifest['results']):
 label,args,cwd,extra,source=case
 env=os.environ.copy()
 for key in ['HOME_NATIVE_VM','HOME_CORPUS_FULL_VM','HOME_BUN_TEST_EXECUTABLE']: env.pop(key,None)
 env.update(BUN_DEBUG_QUIET_LOGS='1',BUN_FEATURE_FLAG_INTERNAL_FOR_TESTING='1',BUN_GARBAGE_COLLECTOR_LEVEL='0',NO_COLOR='1',HOME_RUN_LABEL='native-package-'+label)
 env.update(extra)
 log=out/(label+'.log'); row.update(status='started',log=str(log),environment_overrides=extra);save()
 snap=source.parent/'__snapshots__'/(source.name+'.snap')
 original_snapshot=snap.read_bytes() if snap.exists() else None
 start=time.monotonic()
 with log.open('xb') as stream:
  code=subprocess.run(['perl',str(root/'scripts/run-bounded.pl'),'240',*map(str,args)],cwd=cwd,env=env,stdin=subprocess.DEVNULL,stdout=stream,stderr=subprocess.STDOUT).returncode
 raw=log.read_bytes(); clean=re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]','',raw.decode(errors='replace'))
 row.update(status='completed',exit_code=code,seconds=time.monotonic()-start,log_sha256=sha(log),source_unchanged=sha(source)==row['source_sha256'],pass_reports=re.findall(r'(?m)^\s*(\d+) pass\s*$',clean),fail_reports=re.findall(r'(?m)^\s*(\d+) fail\s*$',clean))
 current_snapshot=snap.read_bytes() if snap.exists() else None
 row['snapshot_unchanged']=current_snapshot==original_snapshot
 if not row['snapshot_unchanged']:
  (out/(label+'.snapshot.diff')).write_text(''.join(difflib.unified_diff((original_snapshot or b'').decode().splitlines(True),(current_snapshot or b'').decode().splitlines(True),fromfile=str(snap),tofile=str(snap))))
  if original_snapshot is None: snap.unlink()
  else: snap.write_bytes(original_snapshot)
  row['snapshot_restored_before_next_case']=True
 save();print(json.dumps(row),flush=True)
 if not row['source_unchanged']: raise RuntimeError('Original test changed during run')
raise SystemExit(int(any(r['exit_code']!=0 or not r['snapshot_unchanged'] for r in manifest['results'])))
