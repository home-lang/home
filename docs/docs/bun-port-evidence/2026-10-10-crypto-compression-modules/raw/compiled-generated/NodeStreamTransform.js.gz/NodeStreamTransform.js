(function () {"use strict";
// .zig-cache/o/78fa357fde6c75aea50ac5845ca62225/native-modules/NodeStreamTransform.mts
var $;
$ = @getInternalField(@internalModuleRegistry, 75) || @createInternalModuleById(75);
return $

})
