(function () {"use strict";
// .zig-cache/o/78fa357fde6c75aea50ac5845ca62225/native-modules/NodeStream.mts
var $, exports = @getInternalField(@internalModuleRegistry, 46) || @createInternalModuleById(46);
exports.eos = @getInternalField(@internalModuleRegistry, 53) || @createInternalModuleById(53);
$ = exports;
return $

})
