(function () {"use strict";
// .zig-cache/o/78fa357fde6c75aea50ac5845ca62225/native-modules/NodeFS.mts
var $, promises = @getInternalField(@internalModuleRegistry, 115) || @createInternalModuleById(115), types = @getInternalField(@internalModuleRegistry, 164) || @createInternalModuleById(164), {
  validateFunction,
  validateInteger,
  getValidatedPath,
  throwIfNullBytesInFileName
} = @getInternalField(@internalModuleRegistry, 86) || @createInternalModuleById(86), kEmptyObject = Object.freeze(Object.create(null)), isDate = types.isDate, fs = @getInternalField(@internalModuleRegistry, 23) || @createInternalModuleById(23), constants = @processBindingConstants.fs, _lazyGlob;
function lazyGlob() {
  return _lazyGlob ??= @getInternalField(@internalModuleRegistry, 26) || @createInternalModuleById(26);
}
function ensureCallback(callback) {
  if (!@isCallable(callback))
    throw @makeErrorWithCode(119, "cb", "function", callback);
  return callback;
}
function nullcallback(callback) {
  return FunctionPrototypeBind.@call(callback, @undefined, null);
}
var FunctionPrototypeBind = nullcallback.bind;
function openAsBlob(path, options) {
  return @Promise.@resolve(Bun.file(path, options));
}
var access = function(path, mode, callback) {
  if (@isCallable(mode))
    callback = mode, mode = @undefined;
  ensureCallback(callback), fs.access(path, mode).then(callback, callback);
}, appendFile = function(path, data, options, callback) {
  if (!@isCallable(callback))
    callback = options, options = @undefined;
  ensureCallback(callback), fs.appendFile(path, data, options).then(nullcallback(callback), callback);
}, close = function(fd, callback) {
  if (@isCallable(callback))
    fs.close(fd).then(() => callback(null), callback);
  else if (callback === @undefined)
    fs.close(fd).then(() => {});
  else
    callback = ensureCallback(callback);
}, rm = function(path, options, callback) {
  if (@isCallable(options))
    callback = options, options = @undefined;
  ensureCallback(callback), promises.rm(path, options).then(nullcallback(callback), callback);
}, rmdir = function(path, options, callback) {
  if (@isCallable(options))
    callback = options, options = @undefined;
  if (callback = ensureCallback(callback), options?.recursive !== @undefined)
    throw @makeErrorWithCode(120, "options.recursive", options.recursive, "is no longer supported");
  fs.rmdir(path, options).then(nullcallback(callback), callback);
}, copyFile = function(src, dest, mode, callback) {
  if (@isCallable(mode))
    callback = mode, mode = 0;
  ensureCallback(callback), fs.copyFile(src, dest, mode).then(nullcallback(callback), callback);
}, exists = function(path, callback) {
  ensureCallback(callback);
  try {
    fs.exists.@apply(fs, [path]).then((existed) => callback(existed), (_) => callback(!1));
  } catch {
    callback(!1);
  }
}, chown = function(path, uid, gid, callback) {
  ensureCallback(callback), fs.chown(path, uid, gid).then(nullcallback(callback), callback);
}, chmod = function(path, mode, callback) {
  ensureCallback(callback), fs.chmod(path, mode).then(nullcallback(callback), callback);
}, fchmod = function(fd, mode, callback) {
  ensureCallback(callback), fs.fchmod(fd, mode).then(nullcallback(callback), callback);
}, fchown = function(fd, uid, gid, callback) {
  ensureCallback(callback), fs.fchown(fd, uid, gid).then(nullcallback(callback), callback);
}, fstat = function(fd, options, callback) {
  if (@isCallable(options))
    callback = options, options = @undefined;
  fs.fstat(fd, options).then(function(stats) {
    callback(null, stats);
  }, callback);
}, fsync = function(fd, callback) {
  ensureCallback(callback), fs.fsync(fd).then(nullcallback(callback), callback);
}, ftruncate = function(fd, len = 0, callback) {
  if (@isCallable(len))
    callback = len, len = 0;
  ensureCallback(callback), fs.ftruncate(fd, len).then(nullcallback(callback), callback);
}, futimes = function(fd, atime, mtime, callback) {
  ensureCallback(callback), fs.futimes(fd, atime, mtime).then(nullcallback(callback), callback);
}, lchmod = constants.O_SYMLINK !== @undefined ? function(path, mode, callback) {
  ensureCallback(callback), fs.lchmod(path, mode).then(nullcallback(callback), callback);
} : @undefined, lchown = function(path, uid, gid, callback) {
  ensureCallback(callback), fs.lchown(path, uid, gid).then(nullcallback(callback), callback);
}, link = function(existingPath, newPath, callback) {
  ensureCallback(callback), fs.link(existingPath, newPath).then(nullcallback(callback), callback);
}, mkdir = function(path, options, callback) {
  if (@isCallable(options))
    callback = options, options = @undefined;
  ensureCallback(callback), fs.mkdir(path, options).then(nullcallback(callback), callback);
}, mkdtemp = function(prefix, options, callback) {
  if (@isCallable(options))
    callback = options, options = @undefined;
  ensureCallback(callback), fs.mkdtemp(prefix, options).then(function(folder) {
    callback(null, folder);
  }, callback);
}, open = function(path, flags, mode, callback) {
  if (arguments.length < 3)
    callback = flags;
  else if (@isCallable(mode))
    callback = mode, mode = @undefined;
  ensureCallback(callback), fs.open(path, flags, mode).then(function(fd) {
    callback(null, fd);
  }, callback);
}, fdatasync = function(fd, callback) {
  ensureCallback(callback), fs.fdatasync(fd).then(nullcallback(callback), callback);
}, read = function(fd, buffer, offsetOrOptions, length, position, callback) {
  let offset = offsetOrOptions, params = null, argc = arguments.length;
  if (argc <= 4) {
    if (argc === 4) {
      if (typeof params !== "object" || @isArray(params))
        throw @makeErrorWithCode(119, "options", "object", params);
      callback = length, params = offsetOrOptions;
    } else if (argc === 3) {
      if (!types.isArrayBufferView(buffer))
        params = buffer, { buffer = @Buffer.alloc(16384) } = params ?? {};
      callback = offsetOrOptions;
    } else
      callback = buffer, buffer = @Buffer.alloc(16384);
    if (params !== @undefined) {
      if (typeof params !== "object" || @isArray(params))
        throw @makeErrorWithCode(119, "options", "object", params);
    }
    ({ offset = 0, length = buffer?.byteLength - offset, position = null } = params ?? {});
  }
  if (!callback)
    throw @makeErrorWithCode(119, "callback", "function", callback);
  fs.read(fd, buffer, offset, length, position).then((bytesRead) => void callback(null, bytesRead, buffer), (err) => callback(err));
}, write = function(fd, buffer, offsetOrOptions, length, position, callback) {
  function wrapper(bytesWritten) {
    callback(null, bytesWritten, buffer);
  }
  if (@isTypedArrayView(buffer)) {
    if (callback ||= position || length || offsetOrOptions, ensureCallback(callback), typeof offsetOrOptions === "object")
      ({
        offset: offsetOrOptions = 0,
        length = buffer.byteLength - offsetOrOptions,
        position = null
      } = offsetOrOptions ?? {});
    fs.write(fd, buffer, offsetOrOptions, length, position).then(wrapper, callback);
    return;
  }
  if (!@isCallable(position)) {
    if (@isCallable(offsetOrOptions))
      position = offsetOrOptions, offsetOrOptions = @undefined;
    else
      position = length;
    length = "utf8";
  }
  callback = position, ensureCallback(callback), fs.write(fd, buffer, offsetOrOptions, length).then(wrapper, callback);
}, readdir = function(path, options, callback) {
  if (@isCallable(options))
    callback = options, options = @undefined;
  ensureCallback(callback), fs.readdir(path, options).then(function(files) {
    callback(null, files);
  }, callback);
}, readFile = function(path, options, callback) {
  callback ||= options, ensureCallback(callback), fs.readFile(path, options).then(function(data) {
    callback(null, data);
  }, callback);
}, writeFile = function(path, data, options, callback) {
  callback ||= options, ensureCallback(callback), fs.writeFile(path, data, options).then(nullcallback(callback), callback);
}, readlink = function(path, options, callback) {
  if (@isCallable(options))
    callback = options, options = @undefined;
  ensureCallback(callback), fs.readlink(path, options).then(function(linkString) {
    callback(null, linkString);
  }, callback);
}, rename = function(oldPath, newPath, callback) {
  ensureCallback(callback), fs.rename(oldPath, newPath).then(nullcallback(callback), callback);
}, lstat = function(path, options, callback) {
  if (@isCallable(options))
    callback = options, options = @undefined;
  ensureCallback(callback), fs.lstat(path, options).then(function(stats) {
    callback(null, stats);
  }, callback);
}, stat = function(path, options, callback) {
  if (@isCallable(options))
    callback = options, options = @undefined;
  ensureCallback(callback);
  let signal = options?.signal;
  if (signal?.aborted) {
    process.nextTick(callback, @makeAbortError(@undefined, { cause: signal.reason }));
    return;
  }
  fs.stat(path, options).then(function(stats) {
    callback(null, stats);
  }, callback);
}, statfs = function(path, options, callback) {
  if (@isCallable(options))
    callback = options, options = @undefined;
  ensureCallback(callback), fs.statfs(path, options).then(function(stats) {
    callback(null, stats);
  }, callback);
}, symlink = function(target, path, type, callback) {
  if (callback === @undefined)
    callback = type, ensureCallback(callback), type = @undefined;
  fs.symlink(target, path, type).then(callback, callback);
}, truncate = function(path, len, callback) {
  if (typeof path === "number") {
    ftruncate(path, len, callback);
    return;
  }
  if (@isCallable(len))
    callback = len, len = 0;
  else if (len === @undefined)
    len = 0;
  ensureCallback(callback), fs.truncate(path, len).then(nullcallback(callback), callback);
}, unlink = function(path, callback) {
  ensureCallback(callback), fs.unlink(path).then(nullcallback(callback), callback);
}, utimes = function(path, atime, mtime, callback) {
  ensureCallback(callback), fs.utimes(path, atime, mtime).then(nullcallback(callback), callback);
}, lutimes = function(path, atime, mtime, callback) {
  ensureCallback(callback), fs.lutimes(path, atime, mtime).then(nullcallback(callback), callback);
}, accessSync = fs.accessSync.bind(fs), appendFileSync = fs.appendFileSync.bind(fs), closeSync = fs.closeSync.bind(fs), copyFileSync = fs.copyFileSync.bind(fs), existsSync = function(_path) {
  try {
    return fs.existsSync.@apply(fs, arguments);
  } catch {
    return !1;
  }
}, chownSync = fs.chownSync.bind(fs), chmodSync = fs.chmodSync.bind(fs), fchmodSync = fs.fchmodSync.bind(fs), fchownSync = fs.fchownSync.bind(fs), fstatSync = fs.fstatSync.bind(fs), fsyncSync = fs.fsyncSync.bind(fs), ftruncateSync = fs.ftruncateSync.bind(fs), futimesSync = fs.futimesSync.bind(fs), lchmodSync = constants.O_SYMLINK !== @undefined ? fs.lchmodSync.bind(fs) : @undefined, lchownSync = fs.lchownSync.bind(fs), linkSync = fs.linkSync.bind(fs), lstatSync = fs.lstatSync.bind(fs), mkdirSync = fs.mkdirSync.bind(fs), mkdtempSync = fs.mkdtempSync.bind(fs), mkdtempDisposableSync = function(prefix, options) {
  let path = mkdtempSync(prefix, options), fullPath = (@getInternalField(@internalModuleRegistry, 125) || @createInternalModuleById(125)).resolve(path);
  function remove() {
    fs.rmSync(fullPath, { recursive: !0, force: !0 });
  }
  return { path, remove, [Symbol.dispose]: remove };
}, openSync = fs.openSync.bind(fs), readSync = function(fd, buffer, offsetOrOptions, length, position) {
  let offset = offsetOrOptions;
  if (arguments.length <= 3 || typeof offsetOrOptions === "object") {
    if (offsetOrOptions !== @undefined) {
      if (typeof offsetOrOptions !== "object" || @isArray(offsetOrOptions))
        throw @makeErrorWithCode(119, "options", "object", offsetOrOptions);
    }
    ({ offset = 0, length = buffer.byteLength - offset, position = null } = offsetOrOptions ?? {});
  }
  return fs.readSync(fd, buffer, offset, length, position);
}, writeSync = function(fd, buffer, offsetOrOptions, length, position) {
  try {
    if (types.isArrayBufferView(buffer)) {
      let offset = offsetOrOptions;
      if (typeof offset === "object" && offset !== null)
        return { offset = 0, length = buffer.byteLength - offset, position = null } = offsetOrOptions, fs.writeSync(fd, buffer, offset, length, position);
      return arguments.length <= 2 ? fs.writeSync(fd, buffer) : fs.writeSync(fd, buffer, offset, length, position);
    }
    if (typeof buffer !== "string")
      throw @makeErrorWithCode(119, "buffer", ["string", "Buffer", "TypedArray", "DataView"], buffer);
    return fs.writeSync(fd, buffer, offsetOrOptions, length);
  } catch (err) {
    let ctx = {};
    throw ctx.errno = err?.errno, ctx.syscall = err?.syscall, ctx.code = err?.code, err;
  }
}, readdirSync = fs.readdirSync.bind(fs), readFileSync = fs.readFileSync.bind(fs), fdatasyncSync = fs.fdatasyncSync.bind(fs), writeFileSync = fs.writeFileSync.bind(fs), readlinkSync = fs.readlinkSync.bind(fs), renameSync = fs.renameSync.bind(fs), statSync = fs.statSync.bind(fs), statfsSync = fs.statfsSync.bind(fs), symlinkSync = fs.symlinkSync.bind(fs), truncateSync = fs.truncateSync.bind(fs), unlinkSync = fs.unlinkSync.bind(fs), utimesSync = fs.utimesSync.bind(fs), lutimesSync = fs.lutimesSync.bind(fs), rmSync = function(path, options) {
  if (!options?.recursive) {
    let stats;
    try {
      stats = fs.lstatSync(path);
    } catch {}
    if (stats?.isDirectory())
      throw (@getInternalField(@internalModuleRegistry, 24) || @createInternalModuleById(24)).fsEisdirError({
        code: "EISDIR",
        message: "is a directory",
        path,
        syscall: "rm",
        errno: @processBindingConstants.os.errno.EISDIR
      });
  }
  return fs.rmSync(path, options);
}, rmdirSync = function(path, options) {
  if (options?.recursive !== @undefined)
    throw @makeErrorWithCode(120, "options.recursive", options.recursive, "is no longer supported");
  return fs.rmdirSync(path, options);
}, writev = function(fd, buffers, position, callback) {
  if (typeof position === "function")
    callback = position, position = null;
  callback = ensureCallback(callback), fs.writev(fd, buffers, position).@then((bytesWritten) => callback(null, bytesWritten, buffers), callback);
}, writevSync = fs.writevSync.bind(fs), readv = function(fd, buffers, position, callback) {
  if (typeof position === "function")
    callback = position, position = null;
  callback = ensureCallback(callback), fs.readv(fd, buffers, position).@then((bytesRead) => callback(null, bytesRead, buffers), callback);
}, readvSync = fs.readvSync.bind(fs), Dirent = fs.Dirent, Stats = fs.Stats, watch = function(path, options, listener) {
  return (@getInternalField(@internalModuleRegistry, 28) || @createInternalModuleById(28)).watch(path, options, listener);
}, opendir = function(path, options, callback) {
  if (typeof options === "function")
    callback = options, options = @undefined;
  validateFunction(callback, "callback");
  let result = new Dir(1, path, options, kAlreadyValidated);
  fs.stat(path).then(onOpendirStatFulfilled.bind(null, callback, path, result), onOpendirStatRejected.bind(null, callback, path));
}, { defineCustomPromisifyArgs } = @getInternalField(@internalModuleRegistry, 37) || @createInternalModuleById(37), kCustomPromisifiedSymbol = Symbol.for("nodejs.util.promisify.custom"), existsCb = exists;
exists[kCustomPromisifiedSymbol] = {
  exists(path) {
    return new @Promise((resolve) => existsCb(path, resolve));
  }
}.exists;
defineCustomPromisifyArgs(read, ["bytesRead", "buffer"]);
defineCustomPromisifyArgs(readv, ["bytesRead", "buffers"]);
defineCustomPromisifyArgs(write, ["bytesWritten", "buffer"]);
defineCustomPromisifyArgs(writev, ["bytesWritten", "buffers"]);
function watchFile(filename, options, listener) {
  return (@getInternalField(@internalModuleRegistry, 29) || @createInternalModuleById(29)).watchFile(filename, options, listener);
}
function unwatchFile(filename, listener) {
  return (@getInternalField(@internalModuleRegistry, 29) || @createInternalModuleById(29)).unwatchFile(filename, listener);
}
function createReadStream(path, options) {
  return new exports.ReadStream(path, options);
}
function createWriteStream(path, options) {
  return new exports.WriteStream(path, options);
}
var realpathSync = fs.realpathSync.bind(fs), realpath = function(p, options, callback) {
  if (@isCallable(options))
    callback = options, options = @undefined;
  ensureCallback(callback), fs.realpath(p, options, !1).then(function(resolvedPath) {
    callback(null, resolvedPath);
  }, callback);
};
realpath.native = function(p, options, callback) {
  if (@isCallable(options))
    callback = options, options = @undefined;
  ensureCallback(callback), fs.realpathNative(p, options).then(function(resolvedPath) {
    callback(null, resolvedPath);
  }, callback);
};
realpathSync.native = fs.realpathNativeSync.bind(fs);
function cpSync(src, dest, options) {
  let { cpSyncFn, validateCpOptions, tryNativeFastPathSync } = @getInternalField(@internalModuleRegistry, 24) || @createInternalModuleById(24), { getValidatedFsPath } = @getInternalField(@internalModuleRegistry, 86) || @createInternalModuleById(86);
  options = validateCpOptions(options), src = getValidatedFsPath(src, "src"), dest = getValidatedFsPath(dest, "dest");
  let { filter, dereference, preserveTimestamps, verbatimSymlinks, mode, errorOnExist, force, recursive } = options;
  if (!filter && !dereference && !preserveTimestamps && !verbatimSymlinks && !mode && !errorOnExist && force) {
    let { ok, checked } = tryNativeFastPathSync(src, dest, options);
    if (ok)
      return fs.cpSync(src, dest, recursive, errorOnExist, force, mode);
    return cpSyncFn(src, dest, options, checked);
  }
  return cpSyncFn(src, dest, options);
}
function cp(src, dest, options, callback) {
  if (@isCallable(options))
    callback = options, options = @undefined;
  ensureCallback(callback);
  let { validateCpOptions } = @getInternalField(@internalModuleRegistry, 24) || @createInternalModuleById(24), { getValidatedFsPath } = @getInternalField(@internalModuleRegistry, 86) || @createInternalModuleById(86);
  options = validateCpOptions(options), src = getValidatedFsPath(src, "src"), dest = getValidatedFsPath(dest, "dest"), promises.cp(src, dest, options).then(callOnceWithNull.bind(null, callback), callback);
}
function _toUnixTimestamp(time, name = "time") {
  if (typeof time === "string" && +time == time)
    return +time;
  if (@isFinite(time)) {
    if (time < 0)
      return Date.now() / 1000;
    return time;
  }
  if (isDate(time))
    return time.getTime() / 1000;
  throw @makeErrorWithCode(119, name, "number or Date", time);
}
function onOpendirStatFulfilled(callback, path, result, stats) {
  if (!stats.isDirectory()) {
    process.nextTick(callback, opendirNotDirError(path));
    return;
  }
  process.nextTick(callback, null, result);
}
function onOpendirStatRejected(callback, path, err) {
  process.nextTick(callback, typeof err?.errno === "number" ? opendirStatError(err, path) : err);
}
function callOnceWithNull(callback) {
  callback(null);
}
function callOnceWithNullThen(callback, value) {
  callback(null, value);
}
function opendirSync(path, options) {
  return new Dir(1, path, options);
}
function opendirStatError(err, path) {
  err.syscall = "opendir";
  let description = err.message.replace(/^[A-Z]+: /, "").replace(/, l?stat '.*'$/, "");
  return err.message = `${err.code}: ${description}, opendir '${path}'`, err;
}
function opendirNotDirError(path) {
  let err = Error(`ENOTDIR: not a directory, opendir '${path}'`);
  return err.code = "ENOTDIR", err.errno = -20, err.syscall = "opendir", err.path = path, err;
}
var kAlreadyValidated = Symbol("kAlreadyValidated");

class Dir {
  #handle;
  #path;
  #options;
  #entries = null;
  #entriesIdx = 0;
  constructor(handle, path, options, validated) {
    if (@isUndefinedOrNull(handle))
      throw @makeErrorWithCode(152, "handle");
    if (validateInteger(handle, "handle", 0), options != null && typeof options !== "object" && typeof options !== "string")
      throw @makeErrorWithCode(119, "options", "object", options);
    if (typeof options === "string")
      options = { encoding: options };
    let encoding = options?.encoding;
    if (encoding != null && encoding !== "buffer" && !@Buffer.isEncoding(encoding))
      throw @makeErrorWithCode(120, "encoding", encoding, "is invalid encoding");
    if (options?.bufferSize !== @undefined)
      validateInteger(options.bufferSize, "options.bufferSize", 1);
    if (handle === 1 && validated !== kAlreadyValidated) {
      let stats;
      try {
        stats = fs.statSync(path);
      } catch (err) {
        if (typeof err?.errno !== "number")
          throw err;
        throw opendirStatError(err, path);
      }
      if (!stats.isDirectory())
        throw opendirNotDirError(path);
    }
    this.#handle = @toLength(handle), this.#path = path, this.#options = options;
  }
  #pendingCount = 0;
  #pendingOp = null;
  #dirConcurrentError() {
    return @makeErrorWithCode(327, "Cannot do synchronous work on directory handle with concurrent asynchronous operations");
  }
  #enqueue(run) {
    let prev = this.#pendingOp, p;
    if (prev)
      p = prev.then(run, run);
    else
      try {
        let r = run();
        p = @isPromise(r) ? r : @Promise.@resolve(r);
      } catch (e) {
        p = @Promise.@reject(e);
      }
    this.#pendingCount++, this.#pendingOp = p;
    let done = this.#opDone.bind(this);
    return p.then(done, done), p;
  }
  readSync() {
    if (this.#handle < 0)
      throw @makeErrorWithCode(52);
    if (this.#pendingCount > 0)
      throw this.#dirConcurrentError();
    let entries = this.#entries ??= fs.readdirSync(this.#path, {
      withFileTypes: !0,
      encoding: this.#options?.encoding,
      recursive: this.#options?.recursive
    });
    return this.#entriesIdx < entries.length ? entries[this.#entriesIdx++] : null;
  }
  read(cb) {
    if (!@isUndefinedOrNull(cb)) {
      validateFunction(cb, "callback"), this.read().then(callOnceWithNullThen.bind(null, cb), cb);
      return;
    }
    return this.#enqueue(this.#readOp.bind(this));
  }
  #opDone() {
    if (--this.#pendingCount === 0)
      this.#pendingOp = null;
  }
  #readOp() {
    if (this.#handle < 0)
      throw @makeErrorWithCode(52);
    let entries = this.#entries;
    if (entries)
      return this.#entriesIdx < entries.length ? entries[this.#entriesIdx++] : null;
    return fs.readdir(this.#path, {
      withFileTypes: !0,
      encoding: this.#options?.encoding,
      recursive: this.#options?.recursive
    }).then(this.#onReaddir.bind(this));
  }
  #onReaddir(entries) {
    return this.#entries = entries, this.#entriesIdx = 0, this.#entriesIdx < entries.length ? entries[this.#entriesIdx++] : null;
  }
  #closeOp() {
    let handle = this.#handle;
    if (handle < 0)
      throw @makeErrorWithCode(52);
    if (handle > 2)
      fs.closeSync(handle);
    this.#handle = -1;
  }
  close(cb) {
    if (!@isUndefinedOrNull(cb)) {
      validateFunction(cb, "callback"), this.close().then(callOnceWithNull.bind(null, cb), cb);
      return;
    }
    return this.#enqueue(this.#closeOp.bind(this));
  }
  closeSync() {
    let handle = this.#handle;
    if (handle < 0)
      throw @makeErrorWithCode(52);
    if (this.#pendingCount > 0)
      throw this.#dirConcurrentError();
    if (handle > 2)
      fs.closeSync(handle);
    this.#handle = -1;
  }
  get path() {
    if (!(#path in this))
      throw @makeErrorWithCode(140, "Dir");
    return this.#path;
  }
  async* [Symbol.asyncIterator]() {
    try {
      let entry;
      while ((entry = await this.read()) !== null)
        yield entry;
    } finally {
      if (this.#handle >= 0)
        await this.close();
    }
  }
}
function glob(pattern, options, callback) {
  if (typeof options === "function")
    callback = options, options = @undefined;
  validateFunction(callback, "callback"), @Array.fromAsync(lazyGlob().glob(pattern, options ?? kEmptyObject)).then(nextTickWithNullThen.bind(null, callback), nextTickWith.bind(null, callback));
}
function nextTickWithNullThen(callback, result) {
  process.nextTick(callback, null, result);
}
function nextTickWith(callback, err) {
  process.nextTick(callback, err);
}
function globSync(pattern, options) {
  return @Array.from(lazyGlob().globSync(pattern, options ?? kEmptyObject));
}
var exports = {
  appendFile,
  appendFileSync,
  access,
  accessSync,
  chown,
  chownSync,
  chmod,
  chmodSync,
  close,
  closeSync,
  copyFile,
  copyFileSync,
  cp,
  cpSync,
  createReadStream,
  createWriteStream,
  exists,
  existsSync,
  fchown,
  fchownSync,
  fchmod,
  fchmodSync,
  fdatasync,
  fdatasyncSync,
  fstat,
  fstatSync,
  fsync,
  fsyncSync,
  ftruncate,
  ftruncateSync,
  futimes,
  futimesSync,
  glob,
  globSync,
  lchown,
  lchownSync,
  lchmod,
  lchmodSync,
  link,
  linkSync,
  lstat,
  lstatSync,
  lutimes,
  lutimesSync,
  mkdir,
  mkdirSync,
  mkdtemp,
  mkdtempSync,
  mkdtempDisposableSync,
  open,
  openSync,
  read,
  readFile,
  readFileSync,
  readSync,
  readdir,
  readdirSync,
  readlink,
  readlinkSync,
  readv,
  readvSync,
  realpath,
  realpathSync,
  rename,
  renameSync,
  rm,
  rmSync,
  rmdir,
  rmdirSync,
  stat,
  statfs,
  statSync,
  statfsSync,
  symlink,
  symlinkSync,
  truncate,
  truncateSync,
  unlink,
  unlinkSync,
  unwatchFile,
  utimes,
  utimesSync,
  watch,
  watchFile,
  write,
  writeFile,
  writeFileSync,
  writeSync,
  writev,
  writevSync,
  _toUnixTimestamp,
  openAsBlob,
  Dirent,
  opendir,
  opendirSync,
  F_OK: 0,
  R_OK: 4,
  W_OK: 2,
  X_OK: 1,
  constants,
  Dir,
  Stats,
  get ReadStream() {
    return exports.ReadStream = (@getInternalField(@internalModuleRegistry, 27) || @createInternalModuleById(27)).ReadStream;
  },
  set ReadStream(value) {
    Object.defineProperty(exports, "ReadStream", {
      value,
      writable: !0,
      configurable: !0
    });
  },
  get WriteStream() {
    return exports.WriteStream = (@getInternalField(@internalModuleRegistry, 27) || @createInternalModuleById(27)).WriteStream;
  },
  set WriteStream(value) {
    Object.defineProperty(exports, "WriteStream", {
      value,
      writable: !0,
      configurable: !0
    });
  },
  get FileReadStream() {
    return exports.FileReadStream = (@getInternalField(@internalModuleRegistry, 27) || @createInternalModuleById(27)).ReadStream;
  },
  set FileReadStream(value) {
    Object.defineProperty(exports, "FileReadStream", {
      value,
      writable: !0,
      configurable: !0
    });
  },
  get FileWriteStream() {
    return exports.FileWriteStream = (@getInternalField(@internalModuleRegistry, 27) || @createInternalModuleById(27)).WriteStream;
  },
  set FileWriteStream(value) {
    Object.defineProperty(exports, "FileWriteStream", {
      value,
      writable: !0,
      configurable: !0
    });
  },
  promises
};
$ = exports;
function setName(fn, value) {
  Object.@defineProperty(fn, "name", {
    value,
    enumerable: !1,
    configurable: !0
  });
}
setName(Dirent, "Dirent");
setName(Stats, "Stats");
setName(_toUnixTimestamp, "_toUnixTimestamp");
setName(access, "access");
setName(accessSync, "accessSync");
setName(appendFile, "appendFile");
setName(appendFileSync, "appendFileSync");
setName(chmod, "chmod");
setName(chmodSync, "chmodSync");
setName(chown, "chown");
setName(chownSync, "chownSync");
setName(close, "close");
setName(closeSync, "closeSync");
setName(copyFile, "copyFile");
setName(copyFileSync, "copyFileSync");
setName(cp, "cp");
setName(cpSync, "cpSync");
setName(createReadStream, "createReadStream");
setName(createWriteStream, "createWriteStream");
setName(exists, "exists");
setName(existsSync, "existsSync");
setName(fchmod, "fchmod");
setName(fchmodSync, "fchmodSync");
setName(fchown, "fchown");
setName(fchownSync, "fchownSync");
setName(fstat, "fstat");
setName(fstatSync, "fstatSync");
setName(fsync, "fsync");
setName(fsyncSync, "fsyncSync");
setName(ftruncate, "ftruncate");
setName(ftruncateSync, "ftruncateSync");
setName(futimes, "futimes");
setName(futimesSync, "futimesSync");
if (lchmod)
  setName(lchmod, "lchmod");
if (lchmodSync)
  setName(lchmodSync, "lchmodSync");
setName(lchown, "lchown");
setName(lchownSync, "lchownSync");
setName(link, "link");
setName(linkSync, "linkSync");
setName(lstat, "lstat");
setName(lstatSync, "lstatSync");
setName(lutimes, "lutimes");
setName(lutimesSync, "lutimesSync");
setName(mkdir, "mkdir");
setName(mkdirSync, "mkdirSync");
setName(mkdtemp, "mkdtemp");
setName(mkdtempSync, "mkdtempSync");
setName(open, "open");
setName(openSync, "openSync");
setName(read, "read");
setName(readFile, "readFile");
setName(readFileSync, "readFileSync");
setName(readSync, "readSync");
setName(readdir, "readdir");
setName(readdirSync, "readdirSync");
setName(readlink, "readlink");
setName(readlinkSync, "readlinkSync");
setName(readv, "readv");
setName(readvSync, "readvSync");
setName(realpath, "realpath");
setName(realpathSync, "realpathSync");
setName(rename, "rename");
setName(renameSync, "renameSync");
setName(rm, "rm");
setName(rmSync, "rmSync");
setName(rmdir, "rmdir");
setName(rmdirSync, "rmdirSync");
setName(stat, "stat");
setName(statfs, "statfs");
setName(statSync, "statSync");
setName(statfsSync, "statfsSync");
setName(symlink, "symlink");
setName(symlinkSync, "symlinkSync");
setName(truncate, "truncate");
setName(truncateSync, "truncateSync");
setName(unlink, "unlink");
setName(unlinkSync, "unlinkSync");
setName(unwatchFile, "unwatchFile");
setName(utimes, "utimes");
setName(utimesSync, "utimesSync");
setName(watch, "watch");
setName(watchFile, "watchFile");
setName(write, "write");
setName(writeFile, "writeFile");
setName(writeFileSync, "writeFileSync");
setName(writeSync, "writeSync");
setName(writev, "writev");
setName(writevSync, "writevSync");
setName(fdatasync, "fdatasync");
setName(fdatasyncSync, "fdatasyncSync");
setName(openAsBlob, "openAsBlob");
setName(opendir, "opendir");
return $

})
