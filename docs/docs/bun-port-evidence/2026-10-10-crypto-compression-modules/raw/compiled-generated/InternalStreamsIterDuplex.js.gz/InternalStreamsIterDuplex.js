(function () {"use strict";
// .zig-cache/o/78fa357fde6c75aea50ac5845ca62225/native-modules/InternalStreamsIterDuplex.mts
var $, { push } = @getInternalField(@internalModuleRegistry, 61) || @createInternalModuleById(61), { validateAbortSignal, validateObject } = @getInternalField(@internalModuleRegistry, 86) || @createInternalModuleById(86);
function duplex(options = { __proto__: null }) {
  validateObject(options, "options");
  let { highWaterMark, backpressure, signal, a, b } = options;
  if (a !== @undefined)
    validateObject(a, "options.a");
  if (b !== @undefined)
    validateObject(b, "options.b");
  if (signal !== @undefined)
    validateAbortSignal(signal, "options.signal");
  let { writer: aWriter, readable: bReadable } = push({
    highWaterMark: a?.highWaterMark ?? highWaterMark,
    backpressure: a?.backpressure ?? backpressure
  }), { writer: bWriter, readable: aReadable } = push({
    highWaterMark: b?.highWaterMark ?? highWaterMark,
    backpressure: b?.backpressure ?? backpressure
  }), aClosed = !1, bClosed = !1, aReadableIterator = null, bReadableIterator = null, channelA = {
    __proto__: null,
    get writer() {
      return aWriter;
    },
    get readable() {
      return {
        __proto__: null,
        [Symbol.asyncIterator]() {
          let iter = aReadable[Symbol.asyncIterator]();
          return aReadableIterator = iter, iter;
        }
      };
    },
    async close() {
      if (aClosed)
        return;
      if (aClosed = !0, aWriter.endSync(), aReadableIterator?.return)
        await aReadableIterator.return(), aReadableIterator = null;
    },
    [Symbol.asyncDispose]() {
      return this.close();
    }
  }, channelB = {
    __proto__: null,
    get writer() {
      return bWriter;
    },
    get readable() {
      return {
        __proto__: null,
        [Symbol.asyncIterator]() {
          let iter = bReadable[Symbol.asyncIterator]();
          return bReadableIterator = iter, iter;
        }
      };
    },
    async close() {
      if (bClosed)
        return;
      if (bClosed = !0, bWriter.endSync(), bReadableIterator?.return)
        await bReadableIterator.return(), bReadableIterator = null;
    },
    [Symbol.asyncDispose]() {
      return this.close();
    }
  };
  if (signal) {
    let abortBoth = () => {
      let reason = signal.reason;
      aWriter.fail(reason), bWriter.fail(reason);
    };
    if (signal.aborted)
      abortBoth();
    else
      signal.addEventListener("abort", abortBoth, { __proto__: null, once: !0 });
  }
  return [channelA, channelB];
}
$ = {
  duplex
};
return $

})
