var $;
"use strict";

$ = (__intrinsic__getInternalField(__intrinsic__internalModuleRegistry, 77) || __intrinsic__createInternalModuleById(77));
;$$EXPORT$$($).$$EXPORT_END$$;
