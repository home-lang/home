(function () {"use strict";
// .zig-cache/o/78fa357fde6c75aea50ac5845ca62225/native-modules/NodeTest.mts
var $, { jest } = Bun, { kEmptyObject, throwNotImplemented } = @getInternalField(@internalModuleRegistry, 38) || @createInternalModuleById(38), { validateBoolean, validateInteger, validateObject } = @getInternalField(@internalModuleRegistry, 86) || @createInternalModuleById(86);
var kDefaultFunction = () => {}, kDefaultOptions = kEmptyObject;
function run() {
  throwNotImplemented("run()", 5090, "Use `bun:test` in the interim.");
}
var trackMockCall;

class MockFunctionContext {
  #calls;
  #implementation;
  #original;
  #onceImplementations;
  #restore;
  #times;
  constructor(original, implementation, restore, times = @Infinity) {
    this.#calls = [], this.#original = original, this.#implementation = implementation, this.#onceImplementations = /* @__PURE__ */ new Map, this.#restore = restore, this.#times = times;
  }
  get calls() {
    return @Array.from(this.#calls);
  }
  callCount() {
    return this.#calls.length;
  }
  mockImplementation(implementation) {
    if (!@isCallable(implementation))
      throw @makeErrorWithCode(119, "implementation", "function", implementation);
    this.#implementation = implementation;
  }
  mockImplementationOnce(implementation, onCall) {
    if (!@isCallable(implementation))
      throw @makeErrorWithCode(119, "implementation", "function", implementation);
    let nextCall = this.#calls.length, call = onCall ?? nextCall;
    validateInteger(call, "onCall", nextCall), this.#onceImplementations.set(call, implementation);
  }
  resetCalls() {
    this.#calls = [];
  }
  restore() {
    if (this.#restore !== @undefined)
      this.#restore();
    else
      this.#implementation = @undefined;
  }
  static {
    trackMockCall = function(ctx, thisArg, args, target) {
      let callIndex = ctx.#calls.length, implementation = ctx.#onceImplementations.get(callIndex);
      if (implementation !== @undefined)
        ctx.#onceImplementations.delete(callIndex);
      else
        implementation = ctx.#implementation ?? ctx.#original;
      if (callIndex + 1 === ctx.#times)
        ctx.restore();
      let result, error;
      try {
        return result = target === @undefined ? implementation.@apply(thisArg, args) : Reflect.construct(implementation, args, target), result;
      } catch (e) {
        throw error = e, e;
      } finally {
        ctx.#calls.push({
          arguments: args,
          error,
          result,
          stack: Error(),
          target,
          this: thisArg
        });
      }
    };
  }
}
function createMockFunction(original, implementation, restore, times = @Infinity) {
  let context = new MockFunctionContext(original, implementation, restore, times);
  kMockContexts.push(context);
  function mockFunction(...args) {
    return trackMockCall(context, this, args, new.target);
  }
  return Object.defineProperty(mockFunction, "mock", {
    value: context,
    writable: !1,
    enumerable: !1
  }), Object.defineProperty(mockFunction, "length", {
    value: original.length,
    configurable: !0
  }), Object.defineProperty(mockFunction, "name", {
    value: original.name,
    configurable: !0
  }), mockFunction;
}
var kMockContexts = [];
function validateTimes(value, name) {
  if (value === @Infinity)
    return;
  validateInteger(value, name, 1);
}
function mockFn(original, implementation, options) {
  if (original !== null && original !== @undefined && !@isCallable(original) && typeof original === "object")
    options = implementation, implementation = original, original = @undefined;
  if (implementation !== null && implementation !== @undefined && !@isCallable(implementation) && typeof implementation === "object")
    options = implementation, implementation = @undefined;
  if (original !== @undefined && !@isCallable(original))
    throw @makeErrorWithCode(119, "original", "function", original);
  if (implementation !== @undefined && !@isCallable(implementation))
    throw @makeErrorWithCode(119, "implementation", "function", implementation);
  if (options !== @undefined)
    validateObject(options, "options");
  let { times = @Infinity } = options ?? kEmptyObject;
  return validateTimes(times, "options.times"), createMockFunction(original ?? function() {}, implementation, @undefined, times);
}
function mockMethod(objectOrFunction, methodName, implementation, options) {
  if (implementation !== null && implementation !== @undefined && !@isCallable(implementation) && typeof implementation === "object")
    options = implementation, implementation = @undefined;
  if (implementation !== @undefined && !@isCallable(implementation))
    throw @makeErrorWithCode(119, "implementation", "function", implementation);
  if ((typeof objectOrFunction !== "object" || objectOrFunction === null) && !@isCallable(objectOrFunction))
    throw @makeErrorWithCode(119, "object", "object", objectOrFunction);
  if (typeof methodName !== "string" && typeof methodName !== "symbol")
    throw @makeErrorWithCode(119, "methodName", ["string", "symbol"], methodName);
  if (options !== @undefined)
    validateObject(options, "options");
  let {
    getter = !1,
    setter = !1,
    times = @Infinity
  } = options ?? kEmptyObject;
  if (validateBoolean(getter, "options.getter"), validateBoolean(setter, "options.setter"), validateTimes(times, "options.times"), setter && getter)
    throw @makeErrorWithCode(120, "options.setter", setter, "cannot be used with 'options.getter'");
  let target = objectOrFunction, descriptor;
  while (target !== null) {
    if (descriptor = Object.getOwnPropertyDescriptor(target, methodName), descriptor !== @undefined)
      break;
    target = Object.getPrototypeOf(target);
  }
  if (descriptor === @undefined)
    throw @makeErrorWithCode(120, "methodName", methodName, "must be a method");
  let original;
  if (getter) {
    if (!@isCallable(descriptor.get))
      throw @makeErrorWithCode(120, "methodName", methodName, "must be a getter");
    original = descriptor.get;
  } else if (setter) {
    if (!@isCallable(descriptor.set))
      throw @makeErrorWithCode(120, "methodName", methodName, "must be a setter");
    original = descriptor.set;
  } else {
    if (!@isCallable(descriptor.value))
      throw @makeErrorWithCode(120, "methodName", methodName, "must be a method");
    original = descriptor.value;
  }
  let mocked = createMockFunction(original, implementation, function() {
    Object.defineProperty(objectOrFunction, methodName, descriptor);
  }, times), mockDescriptor = {
    configurable: descriptor.configurable,
    enumerable: descriptor.enumerable
  };
  if (getter || setter)
    if (getter)
      mockDescriptor.get = mocked, mockDescriptor.set = descriptor.set;
    else
      mockDescriptor.get = descriptor.get, mockDescriptor.set = mocked;
  else
    mockDescriptor.value = mocked, mockDescriptor.writable = descriptor.writable;
  return Object.defineProperty(objectOrFunction, methodName, mockDescriptor), mocked;
}
var mock = {
  fn: mockFn,
  method: mockMethod,
  getter(objectOrFunction, methodName, implementation, options) {
    if (implementation !== null && implementation !== @undefined && !@isCallable(implementation) && typeof implementation === "object")
      options = implementation, implementation = @undefined;
    let { getter = !0 } = options ?? kEmptyObject;
    if (getter === !1)
      throw @makeErrorWithCode(120, "options.getter", getter, "cannot be false");
    return mockMethod(objectOrFunction, methodName, implementation, {
      ...options,
      getter
    });
  },
  setter(objectOrFunction, methodName, implementation, options) {
    if (implementation !== null && implementation !== @undefined && !@isCallable(implementation) && typeof implementation === "object")
      options = implementation, implementation = @undefined;
    let { setter = !0 } = options ?? kEmptyObject;
    if (setter === !1)
      throw @makeErrorWithCode(120, "options.setter", setter, "cannot be false");
    return mockMethod(objectOrFunction, methodName, implementation, {
      ...options,
      setter
    });
  },
  reset() {
    mock.restoreAll(), kMockContexts.length = 0;
  },
  restoreAll() {
    for (let ctx of kMockContexts)
      ctx.restore();
  },
  module() {
    throwNotImplemented("mock.module()", 5090, "Use `bun:test` in the interim.");
  }
};
function fileSnapshot(_value, _path, _options = kEmptyObject) {
  throwNotImplemented("fileSnapshot()", 5090, "Use `bun:test` in the interim.");
}
function snapshot(_value, _options = kEmptyObject) {
  throwNotImplemented("snapshot()", 5090, "Use `bun:test` in the interim.");
}
var assert = {
  ...@getInternalField(@internalModuleRegistry, 103) || @createInternalModuleById(103),
  fileSnapshot,
  snapshot
};
delete assert.AssertionError;
delete assert.CallTracker;
delete assert.strict;
var checkNotInsideTest;

class TestContext {
  #insideTest;
  #name;
  #filePath;
  #parent;
  #abortController;
  constructor(insideTest, name, filePath, parent) {
    this.#insideTest = insideTest, this.#name = name, this.#filePath = filePath || parent?.filePath || kDefaultFilePath, this.#parent = parent;
  }
  get signal() {
    if (this.#abortController === @undefined)
      this.#abortController = new AbortController;
    return this.#abortController.signal;
  }
  get name() {
    return this.#name;
  }
  get fullName() {
    let fullName = this.#name, parent = this.#parent;
    while (parent && parent.name)
      fullName = `${parent.name} > ${fullName}`, parent = parent.#parent;
    return fullName;
  }
  get filePath() {
    return this.#filePath;
  }
  diagnostic(message) {
    console.log(message);
  }
  plan(_count, _options = kEmptyObject) {
    throwNotImplemented("plan()", 5090, "Use `bun:test` in the interim.");
  }
  get assert() {
    return assert;
  }
  get mock() {
    return throwNotImplemented("mock", 5090, "Use `bun:test` in the interim."), @undefined;
  }
  runOnly(_value) {
    throwNotImplemented("runOnly()", 5090, "Use `bun:test` in the interim.");
  }
  skip(_message) {
    throwNotImplemented("skip()", 5090, "Use `bun:test` in the interim.");
  }
  todo(_message) {
    throwNotImplemented("todo()", 5090, "Use `bun:test` in the interim.");
  }
  before(arg0, arg1) {
    let { fn } = createHook(arg0, arg1), { beforeAll } = bunTest();
    beforeAll(fn);
  }
  after(arg0, arg1) {
    let { fn } = createHook(arg0, arg1), { afterAll } = bunTest();
    afterAll(fn);
  }
  beforeEach(arg0, arg1) {
    let { fn } = createHook(arg0, arg1), { beforeEach } = bunTest();
    beforeEach(fn);
  }
  afterEach(arg0, arg1) {
    let { fn } = createHook(arg0, arg1), { afterEach } = bunTest();
    afterEach(fn);
  }
  waitFor(_condition, _options = kEmptyObject) {
    throwNotImplemented("waitFor()", 5090, "Use `bun:test` in the interim.");
  }
  test(arg0, arg1, arg2) {
    let { name, fn, options } = createTest(arg0, arg1, arg2);
    this.#checkNotInsideTest("test");
    let { test } = bunTest();
    if (options.only)
      test.only(name, fn);
    else if (options.todo)
      test.todo(name, fn);
    else if (options.skip)
      test.skip(name, fn);
    else
      test(name, fn);
  }
  describe(arg0, arg1, arg2) {
    let { name, fn } = createDescribe(arg0, arg1, arg2);
    this.#checkNotInsideTest("describe");
    let { describe } = bunTest();
    describe(name, fn);
  }
  #checkNotInsideTest(fn) {
    if (this.#insideTest)
      throwNotImplemented(`${fn}() inside another test()`, 5090, "Use `bun:test` in the interim.");
  }
  static {
    checkNotInsideTest = (ctx, fn) => {
      if (ctx)
        ctx.#checkNotInsideTest(fn);
    };
  }
}
function bunTest() {
  return jest(Bun.main);
}
var ctx = @undefined;
function describe(arg0, arg1, arg2) {
  let { name, fn } = createDescribe(arg0, arg1, arg2), { describe: describe2 } = bunTest();
  describe2(name, fn);
}
describe.skip = function(arg0, arg1, arg2) {
  let { name, fn } = createDescribe(arg0, arg1, arg2), { describe: describe2 } = bunTest();
  describe2.skip(name, fn);
};
describe.todo = function(arg0, arg1, arg2) {
  let { name, fn } = createDescribe(arg0, arg1, arg2), { describe: describe2 } = bunTest();
  describe2.todo(name, fn);
};
describe.only = function(arg0, arg1, arg2) {
  let { name, fn } = createDescribe(arg0, arg1, arg2), { describe: describe2 } = bunTest();
  describe2.only(name, fn);
};
function test(arg0, arg1, arg2) {
  let { name, fn, options } = createTest(arg0, arg1, arg2), { test: test2 } = bunTest();
  if (options.todo)
    test2.todo(name, fn, options);
  else if (options.skip)
    test2.skip(name, fn, options);
  else
    test2(name, fn, options);
}
test.skip = function(arg0, arg1, arg2) {
  let { name, fn, options } = createTest(arg0, arg1, arg2), { test: test2 } = bunTest();
  test2.skip(name, fn, options);
};
test.todo = function(arg0, arg1, arg2) {
  let { name, fn, options } = createTest(arg0, arg1, arg2), { test: test2 } = bunTest();
  test2.todo(name, fn, options);
};
test.only = function(arg0, arg1, arg2) {
  let { name, fn, options } = createTest(arg0, arg1, arg2), { test: test2 } = bunTest();
  test2.only(name, fn, options);
};
function before(arg0, arg1) {
  let { fn } = createHook(arg0, arg1), { beforeAll } = bunTest();
  beforeAll(fn);
}
function after(arg0, arg1) {
  let { fn } = createHook(arg0, arg1), { afterAll } = bunTest();
  afterAll(fn);
}
function beforeEach(arg0, arg1) {
  let { fn } = createHook(arg0, arg1), { beforeEach: beforeEach2 } = bunTest();
  beforeEach2(fn);
}
function afterEach(arg0, arg1) {
  let { fn } = createHook(arg0, arg1), { afterEach: afterEach2 } = bunTest();
  afterEach2(fn);
}
function parseTestOptions(arg0, arg1, arg2) {
  let name, options, fn;
  if (typeof arg0 === "function")
    if (name = arg0.name || "<anonymous>", fn = arg0, typeof arg1 === "object")
      options = arg1 ?? kDefaultOptions;
    else
      options = kDefaultOptions;
  else if (typeof arg0 === "string")
    if (name = arg0, typeof arg1 === "object")
      if (options = arg1 ?? kDefaultOptions, typeof arg2 === "function")
        fn = arg2;
      else
        fn = kDefaultFunction;
    else if (typeof arg1 === "function")
      fn = arg1, options = kDefaultOptions;
    else
      fn = kDefaultFunction, options = kDefaultOptions;
  else
    name = "<anonymous>", fn = kDefaultFunction, options = kDefaultOptions;
  return { name, options, fn };
}
function createTest(arg0, arg1, arg2) {
  let { name, options, fn } = parseTestOptions(arg0, arg1, arg2);
  checkNotInsideTest(ctx, "test");
  let context = new TestContext(!0, name, Bun.main, ctx);
  return { name, options, fn: (done) => {
    let originalContext = ctx;
    ctx = context;
    let endTest = (error) => {
      try {
        done(error);
      } finally {
        ctx = originalContext;
      }
    }, result, usesCallback = fn.length >= 2;
    try {
      result = usesCallback ? fn(context, endTest) : fn(context);
    } catch (error) {
      endTest(error);
      return;
    }
    if (usesCallback) {
      if (result instanceof @Promise) {
        @markPromiseAsHandled(result);
        let error = Error("A callback-style test must not also return a promise");
        error.code = "ERR_TEST_FAILURE", error.failureType = "callbackAndPromisePresent", endTest(error);
      }
    } else if (result instanceof @Promise)
      result.then(() => endTest()).catch((error) => endTest(error));
    else
      endTest();
  } };
}
function createDescribe(arg0, arg1, arg2) {
  let { name, fn, options } = parseTestOptions(arg0, arg1, arg2);
  checkNotInsideTest(ctx, "describe");
  let context = new TestContext(!1, name, Bun.main, ctx);
  return { name, options, fn: () => {
    let originalContext = ctx;
    ctx = context;
    let endDescribe = () => {
      ctx = originalContext;
    };
    try {
      return fn(context);
    } finally {
      endDescribe();
    }
  } };
}
function parseHookOptions(arg0, arg1) {
  let fn, options;
  if (typeof arg0 === "function")
    fn = arg0;
  else
    fn = kDefaultFunction;
  if (typeof arg1 === "object")
    options = arg1;
  else
    options = kDefaultOptions;
  return { fn, options };
}
function createHook(arg0, arg1) {
  let { fn, options } = parseHookOptions(arg0, arg1);
  return { options, fn: (done) => {
    let result;
    try {
      result = fn();
    } catch (error) {
      done(error);
      return;
    }
    if (result instanceof @Promise)
      result.then(() => done()).catch((error) => done(error));
    else
      done();
  } };
}
function setDefaultSnapshotSerializer(_serializers) {
  throwNotImplemented("setDefaultSnapshotSerializer()", 5090, "Use `bun:test` in the interim.");
}
function setResolveSnapshotPath(_fn) {
  throwNotImplemented("setResolveSnapshotPath()", 5090, "Use `bun:test` in the interim.");
}
test.describe = describe;
test.suite = describe;
test.test = test;
test.it = test;
test.before = before;
test.after = after;
test.beforeEach = beforeEach;
test.afterEach = afterEach;
test.assert = assert;
test.snapshot = {
  setDefaultSnapshotSerializer,
  setResolveSnapshotPath
};
test.run = run;
test.mock = mock;
$ = test;
return $

})
