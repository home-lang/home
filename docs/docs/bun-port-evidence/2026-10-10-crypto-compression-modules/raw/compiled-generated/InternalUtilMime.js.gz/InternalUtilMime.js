(function () {"use strict";
// .zig-cache/o/78fa357fde6c75aea50ac5845ca62225/native-modules/InternalUtilMime.mts
var $, { MIMEParams, MIMEType } = @lazy(26);
$ = {
  MIMEParams,
  MIMEType
};
return $

})
