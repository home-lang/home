(function () {"use strict";
// .zig-cache/o/78fa357fde6c75aea50ac5845ca62225/native-modules/InternalErrors.mts
var $, { SafeArrayIterator } = @getInternalField(@internalModuleRegistry, 36) || @createInternalModuleById(36), ArrayIsArray = @Array.isArray, ArrayPrototypePush = @Array.prototype.push;
function aggregateTwoErrors(innerError, outerError) {
  if (innerError && outerError && innerError !== outerError) {
    let outerErrors = outerError.errors;
    if (ArrayIsArray(outerErrors))
      return ArrayPrototypePush.@call(outerErrors, innerError), outerError;
    let err = AggregateError(new SafeArrayIterator([outerError, innerError]), outerError.message);
    return err.code = outerError.code, err;
  }
  return innerError || outerError;
}
$ = {
  aggregateTwoErrors
};
return $

})
