(function () {"use strict";
// .zig-cache/o/78fa357fde6c75aea50ac5845ca62225/native-modules/NodeStreamPassthrough.mts
var $;
$ = @getInternalField(@internalModuleRegistry, 71) || @createInternalModuleById(71);
return $

})
