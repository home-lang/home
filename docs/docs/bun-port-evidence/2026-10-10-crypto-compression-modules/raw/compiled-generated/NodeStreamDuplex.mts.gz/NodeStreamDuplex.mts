var $;
"use strict";

$ = (__intrinsic__getInternalField(__intrinsic__internalModuleRegistry, 50) || __intrinsic__createInternalModuleById(50));
;$$EXPORT$$($).$$EXPORT_END$$;
