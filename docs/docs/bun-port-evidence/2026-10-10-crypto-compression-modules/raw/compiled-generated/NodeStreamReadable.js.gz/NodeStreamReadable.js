(function () {"use strict";
// .zig-cache/o/78fa357fde6c75aea50ac5845ca62225/native-modules/NodeStreamReadable.mts
var $;
$ = @getInternalField(@internalModuleRegistry, 73) || @createInternalModuleById(73);
return $

})
