(function () {"use strict";
// .zig-cache/o/78fa357fde6c75aea50ac5845ca62225/native-modules/NodeStreamWrap.mts
var $;
process.emitWarning("The _stream_wrap module is deprecated.", "DeprecationWarning", "DEP0125");
$ = @getInternalField(@internalModuleRegistry, 136) || @createInternalModuleById(136);
return $

})
