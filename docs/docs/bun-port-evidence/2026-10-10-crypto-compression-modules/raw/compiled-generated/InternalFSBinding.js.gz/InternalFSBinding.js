(function () {"use strict";
// .zig-cache/o/78fa357fde6c75aea50ac5845ca62225/native-modules/InternalFSBinding.mts
var $;
$ = @lazy(9);
return $

})
