(function () {"use strict";
// .zig-cache/o/78fa357fde6c75aea50ac5845ca62225/native-modules/NodeStreamWeb.mts
var $;
$ = {
  ReadableStream: @ReadableStream,
  ReadableStreamDefaultReader: @ReadableStreamDefaultReader,
  ReadableStreamBYOBReader: @ReadableStreamBYOBReader,
  ReadableStreamBYOBRequest: @ReadableStreamBYOBRequest,
  ReadableByteStreamController: @ReadableByteStreamController,
  ReadableStreamDefaultController: @ReadableStreamDefaultController,
  TransformStream: @TransformStream,
  TransformStreamDefaultController: @TransformStreamDefaultController,
  WritableStream: @WritableStream,
  WritableStreamDefaultWriter: @WritableStreamDefaultWriter,
  WritableStreamDefaultController: @WritableStreamDefaultController,
  ByteLengthQueuingStrategy,
  CountQueuingStrategy,
  TextEncoderStream,
  TextDecoderStream,
  CompressionStream,
  DecompressionStream
};
return $

})
