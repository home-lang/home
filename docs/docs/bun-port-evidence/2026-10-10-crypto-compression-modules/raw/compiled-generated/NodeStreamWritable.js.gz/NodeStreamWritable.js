(function () {"use strict";
// .zig-cache/o/78fa357fde6c75aea50ac5845ca62225/native-modules/NodeStreamWritable.mts
var $;
$ = @getInternalField(@internalModuleRegistry, 77) || @createInternalModuleById(77);
return $

})
