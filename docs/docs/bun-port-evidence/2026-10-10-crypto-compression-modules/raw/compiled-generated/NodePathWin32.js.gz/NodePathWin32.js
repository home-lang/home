(function () {"use strict";
// .zig-cache/o/78fa357fde6c75aea50ac5845ca62225/native-modules/NodePathWin32.mts
var $;
$ = (@getInternalField(@internalModuleRegistry, 125) || @createInternalModuleById(125)).win32;
return $

})
