var $;
"use strict";

process.emitWarning("The _stream_wrap module is deprecated.", "DeprecationWarning", "DEP0125");

$ = (__intrinsic__getInternalField(__intrinsic__internalModuleRegistry, 136) || __intrinsic__createInternalModuleById(136));
;$$EXPORT$$($).$$EXPORT_END$$;
