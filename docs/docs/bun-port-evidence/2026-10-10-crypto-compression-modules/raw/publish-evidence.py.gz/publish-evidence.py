from pathlib import Path
import json,gzip,hashlib,subprocess,tempfile,re
r=Path.cwd();t=r/'zig-out/crypto-compression-port-2026-10-10';dest=r/'docs/docs/bun-port-evidence/2026-10-10-crypto-compression-modules';dest.mkdir(parents=True,exist_ok=True)
batch=json.loads((t/'complete-test-summary.json').read_text());assert all(row['exit']==0 for row in batch['records'])
abi=(t/'abi-complete.log').read_text();assert '74 pass' in abi and '0 fail' in abi
assert 'Build Summary: 34/34 steps succeeded' in (t/'build-key-capabilities.log').read_text()
selected=json.loads((t/'selection.json').read_text());counts={k:0 for k in ['passed','failed','skipped','todo','process_checks_passed','skipped_files','comment_only_files']}
rows=json.loads((t/'complete/summary.json').read_text())['records'];assert len(rows)==len(selected) and all(row['exit']==0 and row['validation_exit']==0 for row in rows)
for i in range(1,len(selected)+1):
 result=json.loads((t/'complete'/f'validate-{i}.json').read_text());assert result['successful']
 for key in counts:counts[key]+=result['summary'][key]
(t/'complete/validated-totals.json').write_text(json.dumps({'files':len(selected),'counts':counts},indent=2)+'\n')
files=[]
def retain(data,name):
 p=dest/(name+'.gz');p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(gzip.compress(data,mtime=0));files.append({'path':str(p.relative_to(dest)),'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
for p in sorted(t.rglob('*')):
 if p.is_file() and p.suffix in ['.json','.jsonl','.log','.xml','.stdout','.stderr','.txt','.ts','.py','.mjs','.mts','.js','.h','.cpp','.zig']:retain(p.read_bytes(),'raw/'+str(p.relative_to(t)))
source_names=json.loads((t/'tested-source-complete.json').read_text())
for name,digest in source_names.items():
 data=(r/name).read_bytes();assert hashlib.sha256(data).hexdigest()==digest;retain(data,'source/'+name)
for row in json.loads((t/'original-source-audit.json').read_text()):
 data=(r/'packages/runtime/test/test'/row['file']).read_bytes();assert hashlib.sha256(data).hexdigest()==row['sha256'];assert data==(Path('/Users/chris/Code/bun/test')/row['file']).read_bytes()
manifest={'schema':1,'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'upstream':'4982b91e3702094330f3be3883354c52b8c01323','platform':'Darwin arm64','results':{'original_files':len(selected),'counts':counts},'verification':{'explicit_owned_registry_modules':90,'internal_test_adapters':1,'new_owned_registry_modules':10,'debug_build_steps':34,'native_regression_groups':10,'abi_tests':74,'abi_assertions':int(re.search(r'(\d+) expect\(\) calls',abi)[1]),'build_peak_tree_mb':int(re.search(r'peak tree footprint (\d+) MB',(t/'build-key-capabilities.log').read_text())[1]),'test_peak_tree_mb':int(re.search(r'peak tree footprint (\d+) MB',(t/'test-complete.log').read_text())[1]),'build_limit_mb':8192,'test_limit_mb':3840},'features':['Home-generated crypto/zlib/zlib-iter/promisify and six legacy stream modules; Home native StringDecoder factory and implementation with exact class header ABI.','Bun.build minify.keepNames configuration retains public factory function names.','Real SHAKE XOF capability export replaces a false-returning native stub and supports custom/zero output lengths.','Streaming sign/verify validates signature capability, rejecting one-shot schemes and key-agreement-only schemes with their backend operation contracts.','Forced-drain callbacks enter an event-loop scope; nested debug scopes restore state only on the outer exit.','Pinned zlib retains output-limit and chunk-size values across getter/close/allocation paths.'],'limitations':['The initial complete 193-file run failed four files: factory names, SHAKE capability, streaming signature error contracts, and a zlib debug callback panic. It is retained without a green batch claim.','A complete repair run clears three initially failing files and exposes the later X25519/key-agreement validation branch in the signature file; that failure is retained.','A direct zlib diagnostic after the name/crypto repair and before the callback-scope change passed. The initial panic is not asserted to reproduce in every launch context. The callback audit independently found a missing scope in the forced-drain helper and a single-slot nested debug restoration defect.','All selected test sources match the pin and none were edited. The shared fixture/helper audit includes four pre-existing URL/ICU differences outside this selection; it does not claim those files match the pin.','Original Flags comments are retained in every run record. Supported runtime metadata flags (stream-iter, expose-gc, expose-internals) are applied; no unexecuted Node/V8 metadata flag is credited as feature parity.','Original registered skips/TODOs, skipped files and comment-only files receive no passing credit. Full-suite, remaining native/registry dependencies and Release/ASAN/all-platform verification remain unfinished.'],'test_batch':batch,'files':files}
(dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for row in files:
 data=gzip.decompress((dest/row['path']).read_bytes());assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
with tempfile.TemporaryDirectory(prefix='home-crypto-evidence-') as temp:
 restored=Path(temp)
 for row in files:
  if row['path'].startswith('raw/complete/corpus-'):
   p=restored/row['path'].removeprefix('raw/complete/').removesuffix('.gz');p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(gzip.decompress((dest/row['path']).read_bytes()))
 for i in range(1,len(selected)+1):
  result=subprocess.run(['python3',str(r/'scripts/summarize-bun-corpus.py'),str(restored/f'corpus-{i}')],capture_output=True,text=True);assert result.returncode==0,(i,result.stdout,result.stderr)
print(json.dumps({'archives':len(files),'restored_reports':len(selected),'counts':counts,'verification':manifest['verification']}))
