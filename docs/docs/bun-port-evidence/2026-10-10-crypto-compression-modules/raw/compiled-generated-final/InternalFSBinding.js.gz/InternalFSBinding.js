(function () {"use strict";
// .zig-cache/o/3bfa719957ebf1f3a9c33605b6afaa72/native-modules/InternalFSBinding.mts
var $;
$ = @lazy(9);
return $

})
