(function () {"use strict";
// .zig-cache/o/3bfa719957ebf1f3a9c33605b6afaa72/native-modules/NodeZlibIter.mts
var $;
process.emitWarning("zlib/iter is an experimental feature and might change at any time", "ExperimentalWarning");
var {
  compressGzip,
  compressGzipSync,
  compressDeflate,
  compressDeflateSync,
  compressBrotli,
  compressBrotliSync,
  compressZstd,
  compressZstdSync,
  decompressGzip,
  decompressGzipSync,
  decompressDeflate,
  decompressDeflateSync,
  decompressBrotli,
  decompressBrotliSync,
  decompressZstd,
  decompressZstdSync
} = @getInternalField(@internalModuleRegistry, 64) || @createInternalModuleById(64);
$ = {
  compressGzip,
  compressDeflate,
  compressBrotli,
  compressZstd,
  compressGzipSync,
  compressDeflateSync,
  compressBrotliSync,
  compressZstdSync,
  decompressGzip,
  decompressDeflate,
  decompressBrotli,
  decompressZstd,
  decompressGzipSync,
  decompressDeflateSync,
  decompressBrotliSync,
  decompressZstdSync
};
return $

})
