(function () {"use strict";
// .zig-cache/o/3bfa719957ebf1f3a9c33605b6afaa72/native-modules/NodeStreamWritable.mts
var $;
$ = @getInternalField(@internalModuleRegistry, 77) || @createInternalModuleById(77);
return $

})
