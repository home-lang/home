(function () {"use strict";
// .zig-cache/o/3bfa719957ebf1f3a9c33605b6afaa72/native-modules/NodeDNSPromises.mts
var $;
$ = (@getInternalField(@internalModuleRegistry, 112) || @createInternalModuleById(112)).promises;
return $

})
