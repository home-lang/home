(function () {"use strict";
// .zig-cache/o/3bfa719957ebf1f3a9c33605b6afaa72/native-modules/NodeStreamPromises.mts
var $;
$ = (@getInternalField(@internalModuleRegistry, 136) || @createInternalModuleById(136)).promises;
return $

})
