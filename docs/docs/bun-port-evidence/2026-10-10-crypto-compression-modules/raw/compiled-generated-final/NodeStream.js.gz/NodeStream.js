(function () {"use strict";
// .zig-cache/o/3bfa719957ebf1f3a9c33605b6afaa72/native-modules/NodeStream.mts
var $, exports = @getInternalField(@internalModuleRegistry, 46) || @createInternalModuleById(46);
exports.eos = @getInternalField(@internalModuleRegistry, 53) || @createInternalModuleById(53);
$ = exports;
return $

})
