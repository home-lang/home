(function () {"use strict";
// .zig-cache/o/3bfa719957ebf1f3a9c33605b6afaa72/native-modules/NodeStreamTransform.mts
var $;
$ = @getInternalField(@internalModuleRegistry, 75) || @createInternalModuleById(75);
return $

})
