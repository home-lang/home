(function () {"use strict";
// .zig-cache/o/3bfa719957ebf1f3a9c33605b6afaa72/native-modules/NodeStreamWeb.mts
var $;
$ = {
  ReadableStream: @ReadableStream,
  ReadableStreamDefaultReader: @ReadableStreamDefaultReader,
  ReadableStreamBYOBReader: @ReadableStreamBYOBReader,
  ReadableStreamBYOBRequest: @ReadableStreamBYOBRequest,
  ReadableByteStreamController: @ReadableByteStreamController,
  ReadableStreamDefaultController: @ReadableStreamDefaultController,
  TransformStream: @TransformStream,
  TransformStreamDefaultController: @TransformStreamDefaultController,
  WritableStream: @WritableStream,
  WritableStreamDefaultWriter: @WritableStreamDefaultWriter,
  WritableStreamDefaultController: @WritableStreamDefaultController,
  ByteLengthQueuingStrategy,
  CountQueuingStrategy,
  TextEncoderStream,
  TextDecoderStream,
  CompressionStream,
  DecompressionStream
};
return $

})
