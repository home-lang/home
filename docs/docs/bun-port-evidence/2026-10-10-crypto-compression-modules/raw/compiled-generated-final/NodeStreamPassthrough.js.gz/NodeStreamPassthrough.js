(function () {"use strict";
// .zig-cache/o/3bfa719957ebf1f3a9c33605b6afaa72/native-modules/NodeStreamPassthrough.mts
var $;
$ = @getInternalField(@internalModuleRegistry, 71) || @createInternalModuleById(71);
return $

})
