(function () {"use strict";
// .zig-cache/o/3bfa719957ebf1f3a9c33605b6afaa72/native-modules/NodeStreamDuplex.mts
var $;
$ = @getInternalField(@internalModuleRegistry, 50) || @createInternalModuleById(50);
return $

})
