(function () {"use strict";
// .zig-cache/o/3bfa719957ebf1f3a9c33605b6afaa72/native-modules/NodeStreamWrap.mts
var $;
process.emitWarning("The _stream_wrap module is deprecated.", "DeprecationWarning", "DEP0125");
$ = @getInternalField(@internalModuleRegistry, 136) || @createInternalModuleById(136);
return $

})
