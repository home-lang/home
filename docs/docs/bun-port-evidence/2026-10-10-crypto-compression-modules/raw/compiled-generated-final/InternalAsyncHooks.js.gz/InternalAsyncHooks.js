(function () {"use strict";
// .zig-cache/o/3bfa719957ebf1f3a9c33605b6afaa72/native-modules/InternalAsyncHooks.mts
var $, activeHooks = 0;
function enabledHooksExist() {
  return activeHooks > 0;
}
function markHookEnabled() {
  activeHooks += 1;
}
function markHookDisabled() {
  if (activeHooks > 0)
    activeHooks -= 1;
}
$ = {
  enabledHooksExist,
  markHookEnabled,
  markHookDisabled
};
return $

})
