(function () {"use strict";
// zig-out/crypto-compression-port-2026-10-10/generated/NodeFSPromises.mts
var $, types = @getInternalField(@internalModuleRegistry, 164) || @createInternalModuleById(164), EventEmitter = @getInternalField(@internalModuleRegistry, 114) || @createInternalModuleById(114), fs = @getInternalField(@internalModuleRegistry, 23) || @createInternalModuleById(23), { glob } = @getInternalField(@internalModuleRegistry, 26) || @createInternalModuleById(26), { validateInteger, validateBoolean, validateObject, validateAbortSignal } = @getInternalField(@internalModuleRegistry, 86) || @createInternalModuleById(86), constants = @processBindingConstants.fs, PromisePrototypeFinally = @Promise.prototype.finally, SymbolAsyncDispose = Symbol.asyncDispose, ObjectFreeze = Object.freeze, kFd = Symbol("kFd"), kRefs = Symbol("kRefs"), kClosePromise = Symbol("kClosePromise"), kCloseResolve = Symbol("kCloseResolve"), kCloseReject = Symbol("kCloseReject"), kRef = Symbol("kRef"), kUnref = Symbol("kUnref"), kTransfer = Symbol("kTransfer"), kTransferList = Symbol("kTransferList"), kDeserialize = Symbol("kDeserialize"), kEmptyObject = ObjectFreeze(Object.create(null)), kFlag = Symbol("kFlag"), kLocked = Symbol("kLocked"), kCloseSync = Symbol("kCloseSync"), SymbolDispose = Symbol.dispose, kIterDefaultChunkSize = 131072, nodeFsForIter, Interface;
function watch(filename, options = {}) {
  if (filename instanceof URL)
    @throwTypeError("Watch URLs are not supported yet");
  else if (@Buffer.isBuffer(filename))
    filename = filename.toString();
  else if (typeof filename !== "string")
    throw @makeErrorWithCode(119, "filename", ["string", "Buffer", "URL"], filename);
  let nextEventResolve = null;
  if (typeof options === "string")
    options = { encoding: options };
  let queue = @createFIFO(), ignoreMatcher = (@getInternalField(@internalModuleRegistry, 28) || @createInternalModuleById(28)).createIgnoreMatcher(options?.ignore), signal = options?.signal;
  validateAbortSignal(signal, "options.signal");
  function makeAbortError() {
    return @makeAbortError(@undefined, { cause: signal.reason });
  }
  if (signal?.aborted)
    return {
      [Symbol.asyncIterator]() {
        let closed = !1;
        return {
          async next() {
            if (closed)
              return { value: @undefined, done: !0 };
            throw closed = !0, makeAbortError();
          },
          return() {
            return closed = !0, { value: @undefined, done: !0 };
          }
        };
      }
    };
  let watcher = fs.watch(filename, options || {}, (eventType, filename2) => {
    if (eventType !== "close" && eventType !== "error" && filename2 != null && ignoreMatcher?.(filename2))
      return;
    if (queue.push({ eventType, filename: filename2 }), nextEventResolve) {
      let resolve = nextEventResolve;
      nextEventResolve = null, resolve();
    }
  });
  function onAbort() {
    if (watcher.close(), nextEventResolve) {
      let resolve = nextEventResolve;
      nextEventResolve = null, resolve();
    }
  }
  signal?.addEventListener("abort", onAbort, { once: !0 });
  function removeAbortListener() {
    signal?.removeEventListener("abort", onAbort);
  }
  return {
    [Symbol.asyncIterator]() {
      let closed = !1;
      return {
        async next() {
          while (!closed) {
            if (signal?.aborted)
              throw closed = !0, makeAbortError();
            let event;
            while (event = queue.shift()) {
              if (event.eventType === "close")
                return closed = !0, removeAbortListener(), { value: @undefined, done: !0 };
              if (event.eventType === "error")
                throw closed = !0, removeAbortListener(), event.filename;
              return { value: event, done: !1 };
            }
            let { promise, resolve } = @Promise.withResolvers();
            nextEventResolve = resolve, await promise;
          }
          return { value: @undefined, done: !0 };
        },
        return() {
          if (!closed) {
            if (watcher.close(), closed = !0, removeAbortListener(), nextEventResolve) {
              let resolve = nextEventResolve;
              nextEventResolve = null, resolve();
            }
          }
          return { value: @undefined, done: !0 };
        }
      };
    }
  };
}
async function cp(src, dest, options) {
  let { validateCpOptions } = @getInternalField(@internalModuleRegistry, 24) || @createInternalModuleById(24), { getValidatedFsPath } = @getInternalField(@internalModuleRegistry, 86) || @createInternalModuleById(86);
  options = validateCpOptions(options), src = getValidatedFsPath(src, "src"), dest = getValidatedFsPath(dest, "dest");
  let { filter, dereference, preserveTimestamps, verbatimSymlinks, mode, errorOnExist, force, recursive } = options;
  if (!filter && !dereference && !preserveTimestamps && !verbatimSymlinks && !mode && !errorOnExist && force) {
    let { ok, checked } = await (@getInternalField(@internalModuleRegistry, 25) || @createInternalModuleById(25)).tryNativeFastPath(src, dest, options);
    if (ok)
      return fs.cp(src, dest, recursive, errorOnExist, force, mode);
    return (@getInternalField(@internalModuleRegistry, 25) || @createInternalModuleById(25)).cpFn(src, dest, options, checked);
  }
  return (@getInternalField(@internalModuleRegistry, 25) || @createInternalModuleById(25)).cpFn(src, dest, options);
}
function settleFromNodeCallback(resolve, reject, err, value) {
  if (err)
    reject(err);
  else
    resolve(value);
}
async function opendir(dir, options) {
  let { promise, resolve, reject } = @Promise.withResolvers();
  return (@getInternalField(@internalModuleRegistry, 116) || @createInternalModuleById(116)).opendir(dir, options, settleFromNodeCallback.bind(null, resolve, reject)), promise;
}
var private_symbols = {
  kRef,
  kUnref,
  kFd,
  kTransfer,
  kTransferList,
  kDeserialize,
  FileHandle: null
}, _readFile = fs.readFile.bind(fs), _writeFile = fs.writeFile.bind(fs), _appendFile = fs.appendFile.bind(fs), exports = {
  access: asyncWrap(fs.access, "access"),
  appendFile: async function(fileHandleOrFdOrPath, ...args) {
    return fileHandleOrFdOrPath = fileHandleOrFdOrPath?.[kFd] ?? fileHandleOrFdOrPath, _appendFile(fileHandleOrFdOrPath, ...args);
  },
  close: asyncWrap(fs.close, "close"),
  copyFile: asyncWrap(fs.copyFile, "copyFile"),
  cp,
  exists: async function() {
    try {
      return await fs.exists.@apply(fs, arguments);
    } catch {
      return !1;
    }
  },
  chown: asyncWrap(fs.chown, "chown"),
  chmod: asyncWrap(fs.chmod, "chmod"),
  fchmod: asyncWrap(fs.fchmod, "fchmod"),
  fchown: asyncWrap(fs.fchown, "fchown"),
  fstat: asyncWrap(fs.fstat, "fstat"),
  fsync: asyncWrap(fs.fsync, "fsync"),
  fdatasync: asyncWrap(fs.fdatasync, "fdatasync"),
  ftruncate: asyncWrap(fs.ftruncate, "ftruncate"),
  futimes: asyncWrap(fs.futimes, "futimes"),
  glob,
  lchmod: asyncWrap(fs.lchmod, "lchmod"),
  lchown: asyncWrap(fs.lchown, "lchown"),
  link: asyncWrap(fs.link, "link"),
  lstat: asyncWrap(fs.lstat, "lstat"),
  mkdir: asyncWrap(fs.mkdir, "mkdir"),
  mkdtemp: asyncWrap(fs.mkdtemp, "mkdtemp"),
  mkdtempDisposable: async function(prefix, options) {
    let path = await fs.mkdtemp(prefix, options), fullPath = (@getInternalField(@internalModuleRegistry, 125) || @createInternalModuleById(125)).resolve(path);
    async function remove() {
      await fs.rm(fullPath, { recursive: !0, force: !0 });
    }
    return { path, remove, [Symbol.asyncDispose]: remove };
  },
  statfs: asyncWrap(fs.statfs, "statfs"),
  open: async (path, flags = "r", mode = 438) => {
    return new private_symbols.FileHandle(await fs.open(path, flags, mode), flags);
  },
  read: asyncWrap(fs.read, "read"),
  write: asyncWrap(fs.write, "write"),
  readdir: asyncWrap(fs.readdir, "readdir"),
  readFile: async function(fileHandleOrFdOrPath, ...args) {
    return fileHandleOrFdOrPath = fileHandleOrFdOrPath?.[kFd] ?? fileHandleOrFdOrPath, _readFile(fileHandleOrFdOrPath, ...args);
  },
  writeFile: async function(fileHandleOrFdOrPath, ...args) {
    if (fileHandleOrFdOrPath = fileHandleOrFdOrPath?.[kFd] ?? fileHandleOrFdOrPath, !@isTypedArrayView(args[0]) && typeof args[0] !== "string" && (@isCallable(args[0]?.[Symbol.iterator]) || @isCallable(args[0]?.[Symbol.asyncIterator])))
      return writeFileAsyncIterator(fileHandleOrFdOrPath, ...args);
    return _writeFile(fileHandleOrFdOrPath, ...args);
  },
  readlink: asyncWrap(fs.readlink, "readlink"),
  realpath: asyncWrap(fs.realpath, "realpath"),
  rename: asyncWrap(fs.rename, "rename"),
  stat: asyncWrap(fs.stat, "stat"),
  symlink: asyncWrap(fs.symlink, "symlink"),
  truncate: asyncWrap(fs.truncate, "truncate"),
  unlink: asyncWrap(fs.unlink, "unlink"),
  utimes: asyncWrap(fs.utimes, "utimes"),
  lutimes: asyncWrap(fs.lutimes, "lutimes"),
  rm: async function(path, options) {
    if (!options?.recursive) {
      let stats;
      try {
        stats = await fs.lstat(path);
      } catch {}
      if (stats?.isDirectory())
        throw (@getInternalField(@internalModuleRegistry, 24) || @createInternalModuleById(24)).fsEisdirError({
          code: "EISDIR",
          message: "is a directory",
          path,
          syscall: "rm",
          errno: @processBindingConstants.os.errno.EISDIR
        });
    }
    return fs.rm(path, options);
  },
  rmdir: async function(path, options) {
    if (options?.recursive !== @undefined)
      throw @makeErrorWithCode(120, "options.recursive", options.recursive, "is no longer supported");
    return fs.rmdir(path, options);
  },
  writev: async (fd, buffers, position) => {
    var bytesWritten = await fs.writev(fd, buffers, position);
    return {
      bytesWritten,
      buffers
    };
  },
  readv: async (fd, buffers, position) => {
    var bytesRead = await fs.readv(fd, buffers, position);
    return {
      bytesRead,
      buffers
    };
  },
  constants,
  watch,
  opendir,
  @data: private_symbols
};
$ = exports;
function asyncWrap(fn, name) {
  let wrapped = async function(...args) {
    return fn.@apply(fs, args);
  };
  return Object.defineProperty(wrapped, "name", { value: name }), Object.defineProperty(wrapped, "length", { value: fn.length }), wrapped;
}
{
  let {
    writeFile,
    readFile,
    fchmod,
    fchown,
    fdatasync,
    fsync,
    read,
    readv,
    fstat,
    ftruncate,
    futimes,
    write,
    writev,
    close
  } = exports, isArrayBufferView;

  class FileHandle extends EventEmitter {
    constructor(fd, flag) {
      super();
      this[kFd] = fd ? fd : -1, this[kRefs] = 1, this[kClosePromise] = null, this[kFlag] = flag;
    }
    getAsyncId() {
      throw Error("BUN TODO FileHandle.getAsyncId");
    }
    get fd() {
      return this[kFd];
    }
    [kCloseResolve];
    [kFd];
    [kFlag];
    [kClosePromise];
    [kRefs];
    [Symbol("messaging_transfer_symbol")]() {}
    async appendFile(data, options) {
      let fd = this[kFd];
      throwEBADFIfNecessary("writeFile", fd);
      let encoding = "utf8", flush = !1;
      if (options == null || typeof options === "function")
        ;
      else if (typeof options === "string")
        encoding = options;
      else
        encoding = options?.encoding ?? encoding, flush = options?.flush ?? flush;
      try {
        return this[kRef](), await writeFile(fd, data, { encoding, flush, flag: this[kFlag] });
      } finally {
        this[kUnref]();
      }
    }
    async chmod(mode) {
      let fd = this[kFd];
      throwEBADFIfNecessary("fchmod", fd);
      try {
        return this[kRef](), await fchmod(fd, mode);
      } finally {
        this[kUnref]();
      }
    }
    async chown(uid, gid) {
      let fd = this[kFd];
      throwEBADFIfNecessary("fchown", fd);
      try {
        return this[kRef](), await fchown(fd, uid, gid);
      } finally {
        this[kUnref]();
      }
    }
    async datasync() {
      let fd = this[kFd];
      throwEBADFIfNecessary("fdatasync", fd);
      try {
        return this[kRef](), await fdatasync(fd);
      } finally {
        this[kUnref]();
      }
    }
    async sync() {
      let fd = this[kFd];
      throwEBADFIfNecessary("fsync", fd);
      try {
        return this[kRef](), await fsync(fd);
      } finally {
        this[kUnref]();
      }
    }
    async read(bufferOrParams, offset, length, position) {
      let fd = this[kFd];
      throwEBADFIfNecessary("fsync", fd);
      let buffer = bufferOrParams;
      if (!types.isArrayBufferView(buffer)) {
        if (bufferOrParams !== @undefined) {
          if (typeof bufferOrParams !== "object" || @isArray(bufferOrParams))
            throw @makeErrorWithCode(119, "options", "object", bufferOrParams);
        }
        ({
          buffer = @Buffer.alloc(16384),
          offset = 0,
          length = buffer.byteLength - offset,
          position = null
        } = bufferOrParams ?? kEmptyObject);
      }
      if (offset !== null && typeof offset === "object")
        ({ offset = 0, length = buffer?.byteLength - offset, position = null } = offset);
      if (offset == null)
        offset = 0;
      else
        validateInteger(offset, "offset", 0);
      length ??= buffer?.byteLength - offset;
      try {
        this[kRef]();
        let bytesRead = await read(fd, buffer, offset, length, position);
        return { buffer, bytesRead };
      } finally {
        this[kUnref]();
      }
    }
    async readv(buffers, position) {
      let fd = this[kFd];
      throwEBADFIfNecessary("readv", fd);
      try {
        return this[kRef](), await readv(fd, buffers, position);
      } finally {
        this[kUnref]();
      }
    }
    async readFile(options) {
      let fd = this[kFd];
      throwEBADFIfNecessary("readFile", fd);
      try {
        return this[kRef](), await readFile(fd, options);
      } finally {
        this[kUnref]();
      }
    }
    readLines(options = @undefined) {
      if (Interface === @undefined)
        Interface = (@getInternalField(@internalModuleRegistry, 131) || @createInternalModuleById(131)).Interface;
      return new Interface({
        input: this.createReadStream(options),
        crlfDelay: @Infinity
      });
    }
    async stat(options) {
      let fd = this[kFd];
      throwEBADFIfNecessary("fstat", fd);
      try {
        return this[kRef](), await fstat(fd, options);
      } finally {
        this[kUnref]();
      }
    }
    async truncate(len = 0) {
      let fd = this[kFd];
      throwEBADFIfNecessary("ftruncate", fd);
      try {
        return this[kRef](), await ftruncate(fd, len);
      } finally {
        this[kUnref]();
      }
    }
    async utimes(atime, mtime) {
      let fd = this[kFd];
      throwEBADFIfNecessary("futimes", fd);
      try {
        return this[kRef](), await futimes(fd, atime, mtime);
      } finally {
        this[kUnref]();
      }
    }
    async write(buffer, offset, length, position) {
      let fd = this[kFd];
      if (throwEBADFIfNecessary("write", fd), buffer?.byteLength === 0)
        return { __proto__: null, bytesWritten: 0, buffer };
      if (isArrayBufferView ??= (@getInternalField(@internalModuleRegistry, 164) || @createInternalModuleById(164)).isArrayBufferView, isArrayBufferView(buffer)) {
        if (typeof offset === "object")
          ({ offset = 0, length = buffer.byteLength - offset, position = null } = offset ?? kEmptyObject);
        if (offset == null)
          offset = 0;
        if (typeof length !== "number")
          length = buffer.byteLength - offset;
        if (typeof position !== "number")
          position = null;
      }
      try {
        return this[kRef](), {
          buffer,
          bytesWritten: await write(fd, buffer, offset, length, position)
        };
      } finally {
        this[kUnref]();
      }
    }
    async writev(buffers, position) {
      let fd = this[kFd];
      throwEBADFIfNecessary("writev", fd);
      try {
        return this[kRef](), await writev(fd, buffers, position);
      } finally {
        this[kUnref]();
      }
    }
    async writeFile(data, options = "utf8") {
      let fd = this[kFd];
      throwEBADFIfNecessary("writeFile", fd);
      let encoding = "utf8", signal = @undefined;
      if (options == null || typeof options === "function")
        ;
      else if (typeof options === "string")
        encoding = options;
      else
        encoding = options?.encoding ?? encoding, signal = options?.signal ?? @undefined;
      try {
        return this[kRef](), await writeFile(fd, data, {
          encoding,
          flag: this[kFlag],
          signal
        });
      } finally {
        this[kUnref]();
      }
    }
    async close() {
      let fd = this[kFd];
      if (fd === -1)
        return @Promise.@resolve();
      if (this[kClosePromise])
        return this[kClosePromise];
      if (--this[kRefs] === 0)
        this[kFd] = -1, this[kClosePromise] = PromisePrototypeFinally.@call(close(fd), () => {
          this[kClosePromise] = @undefined;
        });
      else
        this[kClosePromise] = PromisePrototypeFinally.@call(new @Promise((resolve, reject) => {
          this[kCloseResolve] = resolve, this[kCloseReject] = reject;
        }), () => {
          this[kClosePromise] = @undefined, this[kCloseReject] = @undefined, this[kCloseResolve] = @undefined;
        });
      return this.emit("close"), this[kClosePromise];
    }
    async[SymbolAsyncDispose]() {
      return this.close();
    }
    readableWebStream(_options = kEmptyObject) {
      let fd = this[kFd];
      return throwEBADFIfNecessary("readableWebStream", fd), Bun.file(fd).stream();
    }
    createReadStream(options = kEmptyObject) {
      let fd = this[kFd];
      return throwEBADFIfNecessary("createReadStream", fd), new (@getInternalField(@internalModuleRegistry, 27) || @createInternalModuleById(27)).ReadStream(@undefined, {
        highWaterMark: 65536,
        ...options,
        fd: this
      });
    }
    createWriteStream(options = kEmptyObject) {
      let fd = this[kFd];
      return throwEBADFIfNecessary("createWriteStream", fd), new (@getInternalField(@internalModuleRegistry, 27) || @createInternalModuleById(27)).WriteStream(@undefined, {
        highWaterMark: 65536,
        ...options,
        fd: this
      });
    }
    pull(...args) {
      if (this[kFd] === -1)
        throw @makeErrorWithCode(137, "The FileHandle is closed");
      if (this[kClosePromise])
        throw @makeErrorWithCode(137, "The FileHandle is closing");
      if (this[kLocked])
        throw @makeErrorWithCode(137, "The FileHandle is locked");
      let { parsePullArgs } = @getInternalField(@internalModuleRegistry, 66) || @createInternalModuleById(66), { transforms, options = kEmptyObject } = parsePullArgs(args), { autoClose = !1, chunkSize: readSize = kIterDefaultChunkSize, signal } = options, { start: pos = -1, limit: remaining = -1 } = options, handle = this, fd = this[kFd];
      if (validateBoolean(autoClose, "options.autoClose"), pos !== -1)
        validateInteger(pos, "options.start", 0);
      if (remaining !== -1)
        validateInteger(remaining, "options.limit", 1);
      if (readSize !== @undefined)
        validateInteger(readSize, "options.chunkSize", 1);
      if (signal !== @undefined)
        validateAbortSignal(signal, "options.signal");
      if (signal?.aborted)
        return {
          __proto__: null,
          [Symbol.asyncIterator]() {
            let done = !1;
            return {
              __proto__: null,
              async next() {
                if (done)
                  return { value: @undefined, done: !0 };
                if (done = !0, autoClose)
                  await handle.close();
                throw signal.reason ?? new DOMException("The operation was aborted", "AbortError");
              },
              async return() {
                if (!done) {
                  if (done = !0, autoClose)
                    await handle.close();
                }
                return { value: @undefined, done: !0 };
              }
            };
          }
        };
      this[kLocked] = !0;
      let source = {
        __proto__: null,
        async* [Symbol.asyncIterator]() {
          if (handle[kFd] === -1)
            throw @makeErrorWithCode(137, "The FileHandle is closed");
          handle[kRef]();
          try {
            while (remaining !== 0) {
              if (signal?.aborted)
                throw signal.reason ?? new DOMException("The operation was aborted", "AbortError");
              let toRead = remaining > 0 ? Math.min(readSize, remaining) : readSize, buf = @Buffer.allocUnsafe(toRead), bytesRead = await read(fd, buf, 0, toRead, pos >= 0 ? pos : null) || 0;
              if (bytesRead === 0)
                break;
              if (pos >= 0)
                pos += bytesRead;
              if (remaining > 0)
                remaining -= bytesRead;
              yield [bytesRead < toRead ? buf.subarray(0, bytesRead) : buf];
            }
          } finally {
            if (handle[kLocked] = !1, handle[kUnref](), autoClose)
              await handle.close();
          }
        }
      };
      if (transforms.length > 0) {
        let pullArgs = [...transforms];
        if (options)
          pullArgs.push(options);
        return (@getInternalField(@internalModuleRegistry, 60) || @createInternalModuleById(60)).pull(source, ...pullArgs);
      }
      return source;
    }
    pullSync(...args) {
      if (this[kFd] === -1)
        throw @makeErrorWithCode(137, "The FileHandle is closed");
      if (this[kClosePromise])
        throw @makeErrorWithCode(137, "The FileHandle is closing");
      if (this[kLocked])
        throw @makeErrorWithCode(137, "The FileHandle is locked");
      let { parsePullArgs } = @getInternalField(@internalModuleRegistry, 66) || @createInternalModuleById(66), { transforms, options = kEmptyObject } = parsePullArgs(args), { autoClose = !1, chunkSize: readSize = kIterDefaultChunkSize } = options, { start: pos = -1, limit: remaining = -1 } = options, handle = this, fd = this[kFd];
      if (validateBoolean(autoClose, "options.autoClose"), pos !== -1)
        validateInteger(pos, "options.start", 0);
      if (remaining !== -1)
        validateInteger(remaining, "options.limit", 1);
      if (readSize !== @undefined)
        validateInteger(readSize, "options.chunkSize", 1);
      this[kLocked] = !0;
      let fsSync = nodeFsForIter ??= @getInternalField(@internalModuleRegistry, 116) || @createInternalModuleById(116), source = {
        __proto__: null,
        [Symbol.iterator]() {
          if (handle[kFd] === -1)
            throw @makeErrorWithCode(137, "The FileHandle is closed");
          handle[kRef]();
          let done = !1, cleanedUp = !1;
          function cleanup() {
            if (cleanedUp)
              return;
            if (cleanedUp = !0, handle[kLocked] = !1, handle[kUnref](), autoClose)
              handle[kCloseSync]();
          }
          return {
            __proto__: null,
            next() {
              if (done || remaining === 0) {
                if (!done)
                  done = !0, cleanup();
                return { value: @undefined, done: !0 };
              }
              let toRead = remaining > 0 ? Math.min(readSize, remaining) : readSize, buf = @Buffer.allocUnsafe(toRead), bytesRead;
              try {
                bytesRead = fsSync.readSync(fd, buf, 0, toRead, pos >= 0 ? pos : null) || 0;
              } catch (err) {
                throw done = !0, cleanup(), err;
              }
              if (bytesRead === 0)
                return done = !0, cleanup(), { value: @undefined, done: !0 };
              if (pos >= 0)
                pos += bytesRead;
              if (remaining > 0)
                remaining -= bytesRead;
              return { value: [bytesRead < toRead ? buf.subarray(0, bytesRead) : buf], done: !1 };
            },
            return() {
              if (!done)
                done = !0, cleanup();
              return { value: @undefined, done: !0 };
            }
          };
        }
      };
      if (transforms.length > 0)
        return (@getInternalField(@internalModuleRegistry, 60) || @createInternalModuleById(60)).pullSync(source, ...transforms);
      return source;
    }
    writer(options = kEmptyObject) {
      if (this[kFd] === -1)
        throw @makeErrorWithCode(137, "The FileHandle is closed");
      if (this[kClosePromise])
        throw @makeErrorWithCode(137, "The FileHandle is closing");
      if (this[kLocked])
        throw @makeErrorWithCode(137, "The FileHandle is locked");
      let { toUint8Array, convertChunks } = @getInternalField(@internalModuleRegistry, 66) || @createInternalModuleById(66);
      validateObject(options, "options");
      let { autoClose = !1, chunkSize: syncWriteThreshold = kIterDefaultChunkSize } = options, { start: pos = -1, limit: bytesRemaining = -1 } = options, handle = this, fd = this[kFd], totalBytesWritten = 0, closed = !1, closing = !1, pendingEndPromise = null, error = null, asyncPending = 0, deferredTeardown = null;
      function runDeferredTeardown() {
        if (deferredTeardown !== null) {
          let teardown = deferredTeardown;
          deferredTeardown = null, teardown();
        }
      }
      if (validateBoolean(autoClose, "options.autoClose"), pos !== -1)
        validateInteger(pos, "options.start", 0);
      if (bytesRemaining !== -1)
        validateInteger(bytesRemaining, "options.limit", 1);
      if (syncWriteThreshold !== @undefined)
        validateInteger(syncWriteThreshold, "options.chunkSize", 1);
      this[kLocked] = !0;
      let refAcquired = !1;
      function acquireRef() {
        if (!refAcquired)
          refAcquired = !0, handle[kRef]();
      }
      function releaseRef() {
        if (refAcquired)
          refAcquired = !1, handle[kUnref]();
      }
      let fsSync = nodeFsForIter ??= @getInternalField(@internalModuleRegistry, 116) || @createInternalModuleById(116);
      async function writeAll(buf, offset, length, position, signal) {
        asyncPending++;
        try {
          let retries = 0;
          while (length > 0) {
            let bytesWritten = await write(fd, buf, offset, length, position >= 0 ? position : null) || 0;
            if (signal?.throwIfAborted(), bytesWritten === 0) {
              if (++retries > 5)
                throw @makeErrorWithCode(159, "Operation failed: write failed after retries");
            } else
              retries = 0;
            if (totalBytesWritten += bytesWritten, offset += bytesWritten, length -= bytesWritten, position >= 0)
              position += bytesWritten;
          }
        } catch (err) {
          if (!closed && !error)
            error = err;
          throw err;
        } finally {
          if (--asyncPending === 0)
            runDeferredTeardown();
        }
      }
      async function writevAll(buffers, position, signal) {
        asyncPending++;
        try {
          let totalSize = 0;
          for (let i = 0;i < buffers.length; i++)
            totalSize += buffers[i].byteLength;
          let retries = 0;
          while (totalSize > 0) {
            let { bytesWritten } = await writev(fd, buffers, position >= 0 ? position : null);
            if (signal?.throwIfAborted(), bytesWritten === 0) {
              if (++retries > 5)
                throw @makeErrorWithCode(159, "Operation failed: writev failed after retries");
              continue;
            }
            if (retries = 0, totalBytesWritten += bytesWritten, totalSize -= bytesWritten, position >= 0)
              position += bytesWritten;
            if (totalSize > 0) {
              let remaining = @Buffer.concat(buffers), wrote = bytesWritten;
              await writeAll(remaining, wrote, remaining.length - wrote, position, signal);
              return;
            }
          }
        } catch (err) {
          if (!closed && !error)
            error = err;
          throw err;
        } finally {
          if (--asyncPending === 0)
            runDeferredTeardown();
        }
      }
      function writeSyncAll(buf, offset, length, position) {
        let retries = 0;
        while (length > 0) {
          let bytesWritten = fsSync.writeSync(fd, buf, offset, length, position >= 0 ? position : null) || 0;
          if (bytesWritten === 0) {
            if (++retries > 5)
              throw @makeErrorWithCode(159, "Operation failed: write failed after retries");
          } else
            retries = 0;
          if (totalBytesWritten += bytesWritten, offset += bytesWritten, length -= bytesWritten, position >= 0)
            position += bytesWritten;
        }
      }
      function returnTotalBytesWritten() {
        return totalBytesWritten;
      }
      async function cleanup() {
        if (closed)
          return;
        if (closed = !0, handle[kLocked] = !1, asyncPending) {
          let { promise, resolve, reject } = @Promise.withResolvers();
          return deferredTeardown = function() {
            if (releaseRef(), autoClose)
              handle.close().@then(resolve, reject);
            else
              resolve(@undefined);
          }, promise;
        }
        if (releaseRef(), autoClose)
          await handle.close();
      }
      return {
        __proto__: null,
        write(chunk, options2 = kEmptyObject) {
          if (error)
            return @Promise.@reject(error);
          if (closed)
            return @Promise.@reject(@makeErrorWithCode(138, "The writer is closed"));
          if (handle[kFd] === -1)
            return @Promise.@reject(@makeErrorWithCode(137, "The FileHandle is closed"));
          validateObject(options2, "options");
          let { signal } = options2;
          if (signal !== @undefined) {
            if (validateAbortSignal(signal, "options.signal"), signal.aborted)
              return @Promise.@reject(signal.reason);
          }
          chunk = toUint8Array(chunk);
          let chunkByteLength;
          if (bytesRemaining >= 0 && (chunkByteLength = chunk.byteLength) > bytesRemaining)
            return @Promise.@reject(@makeErrorWithCode(160, "write", `<= ${bytesRemaining} bytes`, chunkByteLength));
          if (bytesRemaining > 0)
            bytesRemaining -= chunkByteLength;
          chunkByteLength ??= chunk.byteLength;
          let position = pos;
          if (pos >= 0)
            pos += chunkByteLength;
          return acquireRef(), writeAll(chunk, 0, chunkByteLength, position, signal);
        },
        writev(chunks, options2 = kEmptyObject) {
          if (error)
            return @Promise.@reject(error);
          if (closed)
            return @Promise.@reject(@makeErrorWithCode(138, "The writer is closed"));
          if (handle[kFd] === -1)
            return @Promise.@reject(@makeErrorWithCode(137, "The FileHandle is closed"));
          validateObject(options2, "options");
          let { signal } = options2;
          if (signal !== @undefined) {
            if (validateAbortSignal(signal, "options.signal"), signal?.aborted)
              return @Promise.@reject(signal.reason);
          }
          chunks = convertChunks(chunks);
          let totalSize = 0;
          for (let i = 0;i < chunks.length; i++)
            totalSize += chunks[i].byteLength;
          if (bytesRemaining >= 0 && totalSize > bytesRemaining)
            return @Promise.@reject(@makeErrorWithCode(160, "writev", `<= ${bytesRemaining} bytes`, totalSize));
          if (bytesRemaining > 0)
            bytesRemaining -= totalSize;
          let position = pos;
          if (pos >= 0)
            pos += totalSize;
          return acquireRef(), writevAll(chunks, position, signal);
        },
        writeSync(chunk) {
          if (error || closed || asyncPending)
            return !1;
          if (handle[kFd] === -1)
            throw @makeErrorWithCode(137, "The FileHandle is closed");
          chunk = toUint8Array(chunk);
          let length = chunk.byteLength;
          if (length > syncWriteThreshold)
            return !1;
          if (length === 0)
            return !0;
          if (bytesRemaining >= 0 && length > bytesRemaining)
            return !1;
          let position = pos, bytesWritten;
          acquireRef();
          try {
            bytesWritten = fsSync.writeSync(fd, chunk, 0, length, position >= 0 ? position : null) || 0;
          } catch {
            return !1;
          }
          if (totalBytesWritten += bytesWritten, position >= 0)
            pos = position + bytesWritten;
          if (bytesWritten === length) {
            if (bytesRemaining > 0)
              bytesRemaining -= length;
            return !0;
          }
          if (writeSyncAll(chunk, bytesWritten, length - bytesWritten, position >= 0 ? position + bytesWritten : -1), position >= 0)
            pos = position + length;
          if (bytesRemaining > 0)
            bytesRemaining -= length;
          return !0;
        },
        writevSync(chunks) {
          if (error || closed || asyncPending)
            return !1;
          if (handle[kFd] === -1)
            throw @makeErrorWithCode(137, "The FileHandle is closed");
          chunks = convertChunks(chunks);
          let totalSize = 0;
          for (let i = 0;i < chunks.length; i++)
            totalSize += chunks[i].byteLength;
          if (totalSize > syncWriteThreshold)
            return !1;
          if (totalSize === 0)
            return !0;
          if (bytesRemaining >= 0 && totalSize > bytesRemaining)
            return !1;
          let position = pos, bytesWritten;
          acquireRef();
          try {
            bytesWritten = fsSync.writevSync(fd, chunks, position >= 0 ? position : null) || 0;
          } catch {
            return !1;
          }
          if (totalBytesWritten += bytesWritten, position >= 0)
            pos = position + bytesWritten;
          if (bytesWritten === totalSize) {
            if (bytesRemaining > 0)
              bytesRemaining -= totalSize;
            return !0;
          }
          let rest = @Buffer.concat(chunks);
          if (writeSyncAll(rest, bytesWritten, rest.byteLength - bytesWritten, position >= 0 ? position + bytesWritten : -1), position >= 0)
            pos = position + totalSize;
          if (bytesRemaining > 0)
            bytesRemaining -= totalSize;
          return !0;
        },
        end(options2 = kEmptyObject) {
          if (error)
            return @Promise.@reject(error);
          if (closed)
            return @Promise.@resolve(totalBytesWritten);
          if (closing)
            return pendingEndPromise;
          validateObject(options2, "options");
          let { signal } = options2;
          if (signal !== @undefined) {
            if (validateAbortSignal(signal, "options.signal"), signal.aborted)
              return @Promise.@reject(signal.reason);
          }
          return closing = !0, pendingEndPromise = cleanup().@then(returnTotalBytesWritten), pendingEndPromise;
        },
        endSync() {
          if (error)
            return -1;
          if (closed)
            return totalBytesWritten;
          if (asyncPending)
            return -1;
          if (closed = !0, handle[kLocked] = !1, releaseRef(), autoClose)
            handle[kCloseSync]();
          return totalBytesWritten;
        },
        fail(reason) {
          if (closed || error)
            return;
          error = reason ?? @makeErrorWithCode(137, "Failed"), closed = !0, handle[kLocked] = !1;
          function teardown() {
            if (releaseRef(), autoClose)
              handle[kCloseSync]();
          }
          if (asyncPending) {
            deferredTeardown = teardown;
            return;
          }
          teardown();
        },
        [SymbolAsyncDispose]() {
          if (closing)
            return pendingEndPromise ?? @Promise.@resolve();
          if (!closed && !error)
            this.fail();
          return @Promise.@resolve();
        },
        [SymbolDispose]() {
          this.fail();
        }
      };
    }
    [kCloseSync]() {
      if (this[kFd] === -1)
        return;
      if (this[kClosePromise])
        throw @makeErrorWithCode(137, "The FileHandle is closing");
      let fd = this[kFd];
      this[kFd] = -1, (nodeFsForIter ??= @getInternalField(@internalModuleRegistry, 116) || @createInternalModuleById(116)).closeSync(fd), this.emit("close");
    }
    [kTransfer]() {
      if (this[kClosePromise] || this[kRefs] > 1)
        throw new DOMException("Cannot transfer FileHandle while in use", "DataCloneError");
      let fd = this[kFd], flag = this[kFlag];
      return this[kFd] = -1, {
        data: { fd, flag },
        deserializeInfo: "internal/fs/promises:FileHandle"
      };
    }
    [kTransferList]() {
      return [];
    }
    [kDeserialize]({ fd, flag }) {
      this[kFd] = fd, this[kFlag] = flag;
    }
    [kRef]() {
      this[kRefs]++;
    }
    [kUnref]() {
      if (--this[kRefs] === 0) {
        let fd = this[kFd];
        this[kFd] = -1, (fd !== -1 ? close(fd) : @Promise.@resolve()).@then(this[kCloseResolve], this[kCloseReject]);
      }
    }
  }
  private_symbols.FileHandle = FileHandle;
}
function throwEBADFIfNecessary(fn, fd) {
  if (fd === -1) {
    let err = Error("Bad file descriptor");
    throw err.code = "EBADF", err.name = "SystemError", err.syscall = fn, err;
  }
}
async function writeFileAsyncIteratorInner(fd, iterable, encoding, signal) {
  let writer = Bun.file(fd).writer(), mustRencode = !(encoding === "utf8" || encoding === "utf-8" || encoding === "binary" || encoding === "buffer"), totalBytesWritten = 0;
  try {
    for await (let chunk of iterable) {
      if (signal?.aborted)
        throw signal.reason;
      if (mustRencode && typeof chunk === "string")
        chunk = @Buffer.from(chunk, encoding);
      else if (@isUndefinedOrNull(chunk))
        throw @makeErrorWithCode(119, "chunk", ["string", "ArrayBufferView", "ArrayBuffer"], chunk);
      let prom = writer.write(chunk);
      if (prom && @isPromise(prom))
        totalBytesWritten += await prom;
      else
        totalBytesWritten += prom;
    }
  } finally {
    await writer.end();
  }
  return totalBytesWritten;
}
async function writeFileAsyncIterator(fdOrPath, iterable, optionsOrEncoding, flag, mode) {
  let encoding, signal = null;
  if (typeof optionsOrEncoding === "object") {
    if (encoding = optionsOrEncoding?.encoding ?? (encoding || "utf8"), flag = optionsOrEncoding?.flag ?? (flag || "w"), mode = optionsOrEncoding?.mode ?? (mode || 438), signal = optionsOrEncoding?.signal ?? null, signal?.aborted)
      throw signal.reason;
  } else if (typeof optionsOrEncoding === "string" || optionsOrEncoding == null)
    encoding = optionsOrEncoding || "utf8", flag ??= "w", mode ??= 438;
  if (!@Buffer.isEncoding(encoding))
    @throwTypeError(`Unknown encoding: ${encoding}`);
  let mustClose = typeof fdOrPath === "string";
  if (mustClose)
    fdOrPath = await fs.open(fdOrPath, flag, mode);
  if (signal?.aborted) {
    if (mustClose)
      await fs.close(fdOrPath);
    throw signal.reason;
  }
  let totalBytesWritten = 0, error;
  try {
    totalBytesWritten = await writeFileAsyncIteratorInner(fdOrPath, iterable, encoding, signal);
  } catch (err) {
    error = err;
  }
  if (mustClose) {
    if (typeof flag === "string" && !flag.includes("a"))
      try {
        await fs.ftruncate(fdOrPath, totalBytesWritten);
      } catch {}
    await fs.close(fdOrPath);
  }
  if (signal?.aborted)
    error = signal.reason;
  if (error)
    throw error;
}
return $

})
