(function () {"use strict";
// zig-out/crypto-compression-port-2026-10-10/generated/NodeStreamPassthrough.mts
var $;
$ = @getInternalField(@internalModuleRegistry, 71) || @createInternalModuleById(71);
return $

})
