(function () {"use strict";
// zig-out/crypto-compression-port-2026-10-10/generated/NodeStreamWrap.mts
var $;
process.emitWarning("The _stream_wrap module is deprecated.", "DeprecationWarning", "DEP0125");
$ = @getInternalField(@internalModuleRegistry, 136) || @createInternalModuleById(136);
return $

})
