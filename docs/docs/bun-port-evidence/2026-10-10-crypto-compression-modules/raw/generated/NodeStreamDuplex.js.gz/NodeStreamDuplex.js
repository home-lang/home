(function () {"use strict";
// zig-out/crypto-compression-port-2026-10-10/generated/NodeStreamDuplex.mts
var $;
$ = @getInternalField(@internalModuleRegistry, 50) || @createInternalModuleById(50);
return $

})
