(function () {"use strict";
// zig-out/crypto-compression-port-2026-10-10/generated/NodeAssertStrict.mts
var $;
$ = (@getInternalField(@internalModuleRegistry, 103) || @createInternalModuleById(103)).strict;
return $

})
