(function () {"use strict";
// zig-out/crypto-compression-port-2026-10-10/generated/InternalFSBinding.mts
var $;
$ = @lazy(9);
return $

})
