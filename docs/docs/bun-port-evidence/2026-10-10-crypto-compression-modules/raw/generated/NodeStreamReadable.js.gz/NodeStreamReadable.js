(function () {"use strict";
// zig-out/crypto-compression-port-2026-10-10/generated/NodeStreamReadable.mts
var $;
$ = @getInternalField(@internalModuleRegistry, 73) || @createInternalModuleById(73);
return $

})
