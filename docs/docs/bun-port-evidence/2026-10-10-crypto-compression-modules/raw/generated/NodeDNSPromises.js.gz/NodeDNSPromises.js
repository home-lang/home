(function () {"use strict";
// zig-out/crypto-compression-port-2026-10-10/generated/NodeDNSPromises.mts
var $;
$ = (@getInternalField(@internalModuleRegistry, 112) || @createInternalModuleById(112)).promises;
return $

})
