(function () {"use strict";
// zig-out/crypto-compression-port-2026-10-10/generated/NodePathWin32.mts
var $;
$ = (@getInternalField(@internalModuleRegistry, 125) || @createInternalModuleById(125)).win32;
return $

})
