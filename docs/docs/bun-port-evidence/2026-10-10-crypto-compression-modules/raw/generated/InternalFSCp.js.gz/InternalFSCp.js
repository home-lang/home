(function () {"use strict";
// zig-out/crypto-compression-port-2026-10-10/generated/InternalFSCp.mts
var $, {
  errno: { EEXIST, EINVAL, EISDIR, ENOTDIR },
  fsCpDirToNonDirError,
  fsCpEExistError,
  fsCpEinvalError,
  fsCpFifoPipeError,
  fsCpNonDirToDirError,
  fsCpSocketError,
  fsCpSymlinkToSubdirectoryError,
  fsCpUnknownError,
  fsEisdirError,
  areIdentical,
  isSrcSubdir
} = @getInternalField(@internalModuleRegistry, 24) || @createInternalModuleById(24), {
  chmod,
  copyFile,
  lstat,
  mkdir,
  opendir,
  readdir,
  readlink,
  stat,
  symlink,
  unlink,
  utimes
} = @getInternalField(@internalModuleRegistry, 115) || @createInternalModuleById(115), { dirname, isAbsolute, join, parse, resolve } = @getInternalField(@internalModuleRegistry, 125) || @createInternalModuleById(125), PromisePrototypeThen = @Promise.prototype.@then, PromiseReject = @Promise.@reject;
async function checkPaths(src, dest, opts) {
  if (opts.filter && !await opts.filter(src, dest))
    return { __proto__: null, skipped: !0 };
  let { 0: srcStat, 1: destStat } = await getStats(src, dest, opts);
  if (destStat) {
    if (areIdentical(srcStat, destStat))
      throw fsCpEinvalError({
        message: "src and dest cannot be the same",
        path: dest,
        syscall: "cp",
        errno: EINVAL,
        code: "EINVAL"
      });
    if (srcStat.isDirectory() && !destStat.isDirectory())
      throw fsCpDirToNonDirError({
        message: `cannot overwrite non-directory ${dest} with directory ${src}`,
        path: dest,
        syscall: "cp",
        errno: EISDIR,
        code: "EISDIR"
      });
    if (!srcStat.isDirectory() && destStat.isDirectory())
      throw fsCpNonDirToDirError({
        message: `cannot overwrite directory ${dest} with non-directory ${src}`,
        path: dest,
        syscall: "cp",
        errno: ENOTDIR,
        code: "ENOTDIR"
      });
  }
  if (srcStat.isDirectory() && isSrcSubdir(src, dest))
    throw fsCpEinvalError({
      message: `cannot copy ${src} to a subdirectory of self ${dest}`,
      path: dest,
      syscall: "cp",
      errno: EINVAL,
      code: "EINVAL"
    });
  return { __proto__: null, srcStat, destStat, skipped: !1 };
}
function getStats(src, dest, opts) {
  let statFunc = opts.dereference ? (file) => stat(file, { bigint: !0 }) : (file) => lstat(file, { bigint: !0 });
  return @Promise.all([
    statFunc(src),
    PromisePrototypeThen.@call(statFunc(dest), @undefined, (err) => {
      if (err.code === "ENOENT")
        return null;
      throw err;
    })
  ]);
}
async function checkParentPaths(src, srcStat, dest) {
  let srcParent = resolve(dirname(src)), destParent = resolve(dirname(dest));
  if (destParent === srcParent || destParent === parse(destParent).root)
    return;
  let destStat;
  try {
    destStat = await stat(destParent, { bigint: !0 });
  } catch (err) {
    if (err.code === "ENOENT")
      return;
    throw err;
  }
  if (areIdentical(srcStat, destStat))
    throw fsCpEinvalError({
      message: `cannot copy ${src} to a subdirectory of self ${dest}`,
      path: dest,
      syscall: "cp",
      errno: EINVAL,
      code: "EINVAL"
    });
  return checkParentPaths(src, srcStat, destParent);
}
async function treeContainsOnlyFilesAndDirs(root) {
  let stack = [root];
  while (stack.length) {
    let dir = stack.pop(), entries;
    try {
      entries = await readdir(dir, { withFileTypes: !0 });
    } catch {
      return !1;
    }
    for (let i = 0;i < entries.length; i++) {
      let entry = entries[i];
      if (entry.isDirectory())
        stack.push(join(dir, entry.name));
      else if (!entry.isFile())
        return !1;
    }
  }
  return !0;
}
async function tryNativeFastPath(src, dest, opts) {
  let checked = await checkPaths(src, dest, opts), { srcStat, destStat } = checked;
  if (await checkParentPaths(src, srcStat, dest), srcStat.isDirectory() && !opts.recursive)
    throw fsEisdirError({
      message: `${src} is a directory (not copied)`,
      path: src,
      syscall: "cp",
      errno: EISDIR,
      code: "EISDIR"
    });
  if (srcStat.isDirectory())
    return {
      ok: !destStat && await treeContainsOnlyFilesAndDirs(src),
      checked
    };
  return { ok: srcStat.isFile() && (!destStat || destStat.isFile()), checked };
}
async function cpFn(src, dest, opts, checked) {
  let { srcStat, destStat, skipped } = checked ?? await checkPaths(src, dest, opts);
  if (skipped)
    return;
  if (checked === @undefined)
    await checkParentPaths(src, srcStat, dest);
  return checkParentDir(destStat, src, dest, opts);
}
async function checkParentDir(destStat, src, dest, opts) {
  let destParent = dirname(dest);
  if (await pathExists(destParent))
    return getStatsForCopy(destStat, src, dest, opts);
  return await mkdir(destParent, { recursive: !0 }), getStatsForCopy(destStat, src, dest, opts);
}
function pathExistsFulfilled() {
  return !0;
}
function pathExistsRejected(err) {
  return err.code === "ENOENT" ? !1 : PromiseReject(err);
}
function pathExists(dest) {
  return PromisePrototypeThen.@call(stat(dest), pathExistsFulfilled, pathExistsRejected);
}
async function getStatsForCopy(destStat, src, dest, opts) {
  let srcStat = await (opts.dereference ? stat : lstat)(src);
  if (srcStat.isDirectory() && opts.recursive)
    return onDir(srcStat, destStat, src, dest, opts);
  else if (srcStat.isDirectory())
    throw fsEisdirError({
      message: `${src} is a directory (not copied)`,
      path: src,
      syscall: "cp",
      errno: EISDIR,
      code: "EISDIR"
    });
  else if (srcStat.isFile() || srcStat.isCharacterDevice() || srcStat.isBlockDevice())
    return onFile(srcStat, destStat, src, dest, opts);
  else if (srcStat.isSymbolicLink())
    return onLink(destStat, src, dest, opts);
  else if (srcStat.isSocket())
    throw fsCpSocketError({
      message: `cannot copy a socket file: ${dest}`,
      path: dest,
      syscall: "cp",
      errno: EINVAL,
      code: "EINVAL"
    });
  else if (srcStat.isFIFO())
    throw fsCpFifoPipeError({
      message: `cannot copy a FIFO pipe: ${dest}`,
      path: dest,
      syscall: "cp",
      errno: EINVAL,
      code: "EINVAL"
    });
  throw fsCpUnknownError({
    message: `cannot copy an unknown file type: ${dest}`,
    path: dest,
    syscall: "cp",
    errno: EINVAL,
    code: "EINVAL"
  });
}
function onFile(srcStat, destStat, src, dest, opts) {
  if (!destStat)
    return _copyFile(srcStat, src, dest, opts);
  return mayCopyFile(srcStat, src, dest, opts);
}
async function mayCopyFile(srcStat, src, dest, opts) {
  if (opts.force)
    return await unlink(dest), _copyFile(srcStat, src, dest, opts);
  else if (opts.errorOnExist)
    throw fsCpEExistError({
      message: `${dest} already exists`,
      path: dest,
      syscall: "cp",
      errno: EEXIST,
      code: "EEXIST"
    });
}
async function _copyFile(srcStat, src, dest, opts) {
  if (await copyFile(src, dest, opts.mode), opts.preserveTimestamps)
    return handleTimestampsAndMode(srcStat.mode, src, dest);
  return setDestMode(dest, srcStat.mode);
}
async function handleTimestampsAndMode(srcMode, src, dest) {
  if (fileIsNotWritable(srcMode))
    return await makeFileWritable(dest, srcMode), setDestTimestampsAndMode(srcMode, src, dest);
  return setDestTimestampsAndMode(srcMode, src, dest);
}
function fileIsNotWritable(srcMode) {
  return (srcMode & 128) === 0;
}
function makeFileWritable(dest, srcMode) {
  return setDestMode(dest, srcMode | 128);
}
async function setDestTimestampsAndMode(srcMode, src, dest) {
  return await setDestTimestamps(src, dest), setDestMode(dest, srcMode);
}
function setDestMode(dest, srcMode) {
  return chmod(dest, srcMode);
}
async function setDestTimestamps(src, dest) {
  let updatedSrcStat = await stat(src);
  return utimes(dest, updatedSrcStat.atime, updatedSrcStat.mtime);
}
function onDir(srcStat, destStat, src, dest, opts) {
  if (!destStat)
    return mkDirAndCopy(srcStat.mode, src, dest, opts);
  if (opts.errorOnExist && !opts.force)
    throw fsCpEExistError({
      message: `${dest} already exists`,
      path: dest,
      syscall: "cp",
      errno: EEXIST,
      code: "EEXIST"
    });
  return copyDir(src, dest, opts);
}
async function mkDirAndCopy(srcMode, src, dest, opts) {
  return await mkdir(dest), await copyDir(src, dest, opts), setDestMode(dest, srcMode);
}
async function copyDir(src, dest, opts) {
  let dir = await opendir(src);
  for await (let { name } of dir) {
    let srcItem = join(src, name), destItem = join(dest, name), { destStat, skipped } = await checkPaths(srcItem, destItem, opts);
    if (!skipped)
      await getStatsForCopy(destStat, srcItem, destItem, opts);
  }
}
async function onLink(destStat, src, dest, opts) {
  let resolvedSrc = await readlink(src);
  if (!opts.verbatimSymlinks && !isAbsolute(resolvedSrc))
    resolvedSrc = resolve(dirname(src), resolvedSrc);
  if (!destStat)
    return symlink(resolvedSrc, dest);
  let resolvedDest;
  try {
    resolvedDest = await readlink(dest);
  } catch (err) {
    if (err.code === "EINVAL" || err.code === "UNKNOWN")
      return symlink(resolvedSrc, dest);
    throw err;
  }
  if (!isAbsolute(resolvedDest))
    resolvedDest = resolve(dirname(dest), resolvedDest);
  let srcIsDir = (await stat(src)).isDirectory();
  if (srcIsDir && isSrcSubdir(resolvedSrc, resolvedDest))
    throw fsCpEinvalError({
      message: `cannot copy ${resolvedSrc} to a subdirectory of self ${resolvedDest}`,
      path: dest,
      syscall: "cp",
      errno: EINVAL,
      code: "EINVAL"
    });
  if (srcIsDir && isSrcSubdir(resolvedDest, resolvedSrc))
    throw fsCpSymlinkToSubdirectoryError({
      message: `cannot overwrite ${resolvedDest} with ${resolvedSrc}`,
      path: dest,
      syscall: "cp",
      errno: EINVAL,
      code: "EINVAL"
    });
  return copyLink(resolvedSrc, dest);
}
async function copyLink(resolvedSrc, dest) {
  return await unlink(dest), symlink(resolvedSrc, dest);
}
$ = { cpFn, tryNativeFastPath };
return $

})
