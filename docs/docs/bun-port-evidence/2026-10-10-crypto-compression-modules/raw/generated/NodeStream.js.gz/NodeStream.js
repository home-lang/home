(function () {"use strict";
// zig-out/crypto-compression-port-2026-10-10/generated/NodeStream.mts
var $, exports = @getInternalField(@internalModuleRegistry, 46) || @createInternalModuleById(46);
exports.eos = @getInternalField(@internalModuleRegistry, 53) || @createInternalModuleById(53);
$ = exports;
return $

})
