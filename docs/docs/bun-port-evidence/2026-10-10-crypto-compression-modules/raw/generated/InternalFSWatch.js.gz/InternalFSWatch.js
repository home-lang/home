(function () {"use strict";
// zig-out/crypto-compression-port-2026-10-10/generated/InternalFSWatch.mts
var $, EventEmitter = @getInternalField(@internalModuleRegistry, 114) || @createInternalModuleById(114), { basename } = @getInternalField(@internalModuleRegistry, 125) || @createInternalModuleById(125), fs = @getInternalField(@internalModuleRegistry, 23) || @createInternalModuleById(23);
function makeGlobMatcher(glob) {
  return function(filename) {
    return glob.match(filename);
  };
}
function makeGlobOrBasenameMatcher(glob) {
  return function(filename) {
    return glob.match(filename) || glob.match(basename(filename));
  };
}
function makeRegexMatcher(matcher) {
  return function(filename) {
    return matcher.exec(filename) !== null;
  };
}
function createIgnoreMatcher(ignore) {
  if (ignore == null)
    return null;
  let matchers = @isArray(ignore) ? ignore : [ignore], compiled = [];
  for (let matcher of matchers)
    if (typeof matcher === "string") {
      if (matcher.length === 0)
        throw @makeErrorWithCode(120, "options.ignore", matcher, "must not be empty");
      let glob = new Bun.Glob(matcher);
      if (matcher.includes("/"))
        compiled.push(makeGlobMatcher(glob));
      else
        compiled.push(makeGlobOrBasenameMatcher(glob));
    } else if (matcher instanceof @RegExp)
      compiled.push(makeRegexMatcher(matcher));
    else if (typeof matcher === "function")
      compiled.push(matcher);
    else
      throw @makeErrorWithCode(119, "options.ignore", ["string", "RegExp", "Function"], matcher);
  return function(filename) {
    if (typeof filename !== "string")
      filename = @String(filename);
    for (let match of compiled)
      if (match(filename))
        return !0;
    return !1;
  };
}
var kFSWatchStart = Symbol("kFSWatchStart"), closeNativeWatcher, refNativeWatcher, unrefNativeWatcher;

class FSEvent {
  #owner;
  constructor(owner) {
    this.#owner = owner;
  }
  close() {
    closeNativeWatcher(this.#owner);
  }
  ref() {
    refNativeWatcher(this.#owner);
  }
  unref() {
    unrefNativeWatcher(this.#owner);
  }
}
function assertFSEventHandle(handle) {
  if (!(handle instanceof FSEvent))
    throw @makeErrorWithCode(272, `handle must be a FSEvent
This is caused by either a bug in Node.js or incorrect usage of Node.js internals.
Please open an issue with this stack trace at https://github.com/nodejs/node/issues
`);
}

class FSWatcher extends EventEmitter {
  #watcher;
  #listener;
  #ignoreMatcher;
  _handle;
  constructor(path, options, listener) {
    super();
    if (path instanceof URL)
      path = Bun.fileURLToPath(path);
    else if (typeof path === "string" && path.startsWith("file:"))
      path = Bun.fileURLToPath(path);
    if (typeof options === "function")
      listener = options, options = {};
    else if (typeof options === "string")
      options = { encoding: options };
    if (typeof listener !== "function")
      listener = () => {};
    this.#ignoreMatcher = createIgnoreMatcher(options?.ignore), this.#listener = listener;
    try {
      this.#watcher = fs.watch(path, options || {}, this.#onEvent.bind(this));
    } catch (e) {
      throw e.path = path, e.filename = path, e;
    }
    this._handle = new FSEvent(this);
  }
  #onEvent(eventType, filenameOrError) {
    if (eventType === "close") {
      queueMicrotask(() => {
        this.emit("close", filenameOrError);
      });
      return;
    } else if (eventType === "error") {
      if (filenameOrError.code === "EACCES")
        filenameOrError.code = "EPERM";
      this.emit(eventType, filenameOrError);
    } else {
      if (filenameOrError != null && this.#ignoreMatcher?.(filenameOrError))
        return;
      this.emit("change", eventType, filenameOrError), this.#listener(eventType, filenameOrError);
    }
  }
  close() {
    assertFSEventHandle(this._handle), this._handle.close();
  }
  ref() {
    let handle = this._handle;
    if (handle)
      handle.ref();
    return this;
  }
  unref() {
    let handle = this._handle;
    if (handle)
      handle.unref();
    return this;
  }
  start() {}
  [kFSWatchStart]() {
    assertFSEventHandle(this._handle);
  }
  static {
    closeNativeWatcher = function(watcher) {
      watcher.#watcher?.close(), watcher.#watcher = null;
    }, refNativeWatcher = function(watcher) {
      watcher.#watcher?.ref();
    }, unrefNativeWatcher = function(watcher) {
      watcher.#watcher?.unref();
    };
  }
}
function watch(path, options, listener) {
  return new FSWatcher(path, options, listener);
}
$ = { watch, FSWatcher, createIgnoreMatcher };
return $

})
