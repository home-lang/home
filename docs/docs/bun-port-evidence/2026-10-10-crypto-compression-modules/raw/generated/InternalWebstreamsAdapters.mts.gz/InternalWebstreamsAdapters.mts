var $;
"use strict";

const {
  SafePromiseAllReturnVoid,
  SafeSet,
  TypedArrayPrototypeGetBuffer,
  TypedArrayPrototypeGetByteOffset,
  TypedArrayPrototypeGetByteLength,
} = (__intrinsic__getInternalField(__intrinsic__internalModuleRegistry, 36) || __intrinsic__createInternalModuleById(36));

const Writable = (__intrinsic__getInternalField(__intrinsic__internalModuleRegistry, 77) || __intrinsic__createInternalModuleById(77));
const Readable = (__intrinsic__getInternalField(__intrinsic__internalModuleRegistry, 73) || __intrinsic__createInternalModuleById(73));
const Duplex = (__intrinsic__getInternalField(__intrinsic__internalModuleRegistry, 50) || __intrinsic__createInternalModuleById(50));
const { destroyer } = (__intrinsic__getInternalField(__intrinsic__internalModuleRegistry, 49) || __intrinsic__createInternalModuleById(49));
const { isDestroyed, isReadable, isWritable, isWritableEnded } = (__intrinsic__getInternalField(__intrinsic__internalModuleRegistry, 76) || __intrinsic__createInternalModuleById(76));
const { kEmptyObject } = (__intrinsic__getInternalField(__intrinsic__internalModuleRegistry, 38) || __intrinsic__createInternalModuleById(38));
const { validateBoolean, validateObject, validateOneOf } = (__intrinsic__getInternalField(__intrinsic__internalModuleRegistry, 86) || __intrinsic__createInternalModuleById(86));
const { isAnyArrayBuffer } = (__intrinsic__getInternalField(__intrinsic__internalModuleRegistry, 164) || __intrinsic__createInternalModuleById(164));
const eos = (__intrinsic__getInternalField(__intrinsic__internalModuleRegistry, 53) || __intrinsic__createInternalModuleById(53));
const { kEosNodeSynchronousCallback } = eos;

const normalizeEncoding = __intrinsic__lazy(42);

const ArrayPrototypeFilter = Array.prototype.filter;
const ArrayPrototypeMap = Array.prototype.map;
const ObjectEntries = Object.entries;
const ObjectDefineProperty = Object.defineProperty;
const StringPrototypeStartsWith = String.prototype.startsWith;
const PromiseWithResolvers = Promise.withResolvers.bind(Promise);
const PromiseResolve = Promise.__intrinsic__resolve.bind(Promise);
const PromisePrototypeThen = __intrinsic__Promise.prototype.__intrinsic__then;
const SafePromisePrototypeFinally = __intrinsic__Promise.prototype.finally;

const constants_zlib = __intrinsic__processBindingConstants.zlib;

const kValidateChunk = Symbol("kValidateChunk");
const kDestroyOnSyncError = Symbol("kDestroyOnSyncError");

function tryTransferToNativeReadable(stream, options) {
  const ptr = stream.__intrinsic__bunNativePtr;
  if (!ptr || ptr === -1) {
    return undefined;
  }
  return (__intrinsic__getInternalField(__intrinsic__internalModuleRegistry, 69) || __intrinsic__createInternalModuleById(69)).constructNativeReadable(stream, options);
}

class ReadableFromWeb extends Readable {
  #reader;
  #closed;
  #pendingChunks;
  #stream;

  constructor(options, stream) {
    const { objectMode, highWaterMark, encoding, signal } = options;
    super({
      objectMode,
      highWaterMark,
      encoding,
      signal,
    });
    this.#pendingChunks = [];
    this.#reader = undefined;
    this.#stream = stream;
    this.#closed = false;
  }

  #drainPending() {
    var pendingChunks = this.#pendingChunks,
      pendingChunksI = 0,
      pendingChunksCount = pendingChunks.length;

    for (; pendingChunksI < pendingChunksCount; pendingChunksI++) {
      const chunk = pendingChunks[pendingChunksI];
      pendingChunks[pendingChunksI] = undefined;
      if (!this.push(chunk, undefined)) {
        this.#pendingChunks = pendingChunks.slice(pendingChunksI + 1);
        return true;
      }
    }

    if (pendingChunksCount > 0) {
      this.#pendingChunks = [];
    }

    return false;
  }

  #handleDone(reader) {
    reader.releaseLock();
    this.#reader = undefined;
    this.#closed = true;
    this.push(null);
    return;
  }

  async _read() {
    (IS_BUN_DEVELOPMENT?$debug_log("ReadableFromWeb _read()", this.__id):void 0);
    var stream = this.#stream,
      reader = this.#reader;
    if (stream) {
      reader = this.#reader = stream.getReader();
      this.#stream = undefined;
    } else if (this.#drainPending()) {
      return;
    }

    var deferredError: Error | undefined;
    try {
      do {
        var done = false,
          value;
        const firstResult = reader.readMany();

        if (__intrinsic__isPromise(firstResult)) {
          ({ done, value } = await firstResult);

          if (this.#closed) {
            this.#pendingChunks.push(...value);
            return;
          }
        } else {
          ({ done, value } = firstResult);
        }

        if (done) {
          this.#handleDone(reader);
          return;
        }

        if (!this.push(value[0])) {
          this.#pendingChunks = value.slice(1);
          return;
        }

        for (let i = 1, count = value.length; i < count; i++) {
          if (!this.push(value[i])) {
            this.#pendingChunks = value.slice(i + 1);
            return;
          }
        }
      } while (!this.#closed);
    } catch (e) {
      deferredError = e as Error;
    }

    if (deferredError) throw deferredError;
  }

  _destroy(error, callback) {
    if (!this.#closed) {
      var reader = this.#reader;
      if (reader) {
        this.#reader = undefined;
        reader.cancel(error).finally(() => {
          this.#closed = true;
          callback(error);
        });
      }

      return;
    }
    try {
      callback(error);
    } catch (error) {
      globalThis.reportError(error);
    }
  }
}

const encoder = new TextEncoder();

// Collect all negative (error) ZLIB codes and Z_NEED_DICT
const ZLIB_FAILURES: Set<string> = new SafeSet([
  ...ArrayPrototypeFilter.__intrinsic__call(
    ArrayPrototypeMap.__intrinsic__call(ObjectEntries(constants_zlib), ({ 0: code, 1: value }) => (value < 0 ? code : null)),
    Boolean,
  ),
  "Z_NEED_DICT",
]);

function handleKnownInternalErrors(cause: Error | null): Error | null {
  const causeCode = cause?.code;
  switch (true) {
    case causeCode === "ERR_STREAM_PREMATURE_CLOSE": {
      return __intrinsic__makeAbortError(undefined, { cause });
    }
    case ZLIB_FAILURES.has(causeCode):
    // Brotli decoder errors carry the BrotliDecoderErrorString() name,
    // formatted as 'ERR_' + '_ERROR_...' (= 'ERR__ERROR_*').
    // Falls through
    case causeCode != null && StringPrototypeStartsWith.__intrinsic__call(causeCode, "ERR__ERROR_"): {
      // Upstream uses `new TypeError(undefined, { cause })`, but the builtins
      // codegen rewrites `new TypeError` to $makeTypeError, which only accepts
      // a message and silently drops the options bag. Pass an explicit empty
      // message (matching the `undefined` message upstream produces) and
      // define `cause` manually with the same attributes
      // `new Error(msg, { cause })` would produce: own, writable,
      // configurable, non-enumerable.
      const error = __intrinsic__makeTypeError("");
      ObjectDefineProperty(error, "cause", {
        __proto__: null,
        configurable: true,
        enumerable: false,
        value: cause,
        writable: true,
      });
      ObjectDefineProperty(error, "code", {
        __proto__: null,
        configurable: true,
        enumerable: true,
        value: causeCode,
        writable: true,
      });
      return error;
    }
    default:
      return cause;
  }
}

const noop = () => {};

function newWritableStreamFromStreamWritable(streamWritable, options = kEmptyObject) {
  // Not using the internal/streams/utils isWritableNodeStream utility
  // here because it will return false if streamWritable is a Duplex
  // whose writable option is false. For a Duplex that is not writable,
  // we want it to pass this check but return a closed WritableStream.
  // We check if the given stream is a stream.Writable or http.OutgoingMessage
  const checkIfWritableOrOutgoingMessage =
    streamWritable && typeof streamWritable?.write === "function" && typeof streamWritable?.on === "function";
  if (!checkIfWritableOrOutgoingMessage) {
    throw __intrinsic__makeErrorWithCode(119, "streamWritable", "stream.Writable", streamWritable);
  }

  if (isDestroyed(streamWritable) || !isWritable(streamWritable)) {
    const writable = new WritableStream();
    writable.close();
    return writable;
  }

  const highWaterMark = streamWritable.writableHighWaterMark;
  const strategy = streamWritable.writableObjectMode ? new CountQueuingStrategy({ highWaterMark }) : { highWaterMark };

  let controller;
  let backpressurePromise;
  let closed;

  function onDrain() {
    if (backpressurePromise !== undefined) backpressurePromise.resolve();
  }

  const cleanup = eos(streamWritable, error => {
    error = handleKnownInternalErrors(error);

    cleanup();
    // This is a protection against non-standard, legacy streams
    // that happen to emit an error event again after finished is called.
    streamWritable.on("error", () => {});
    if (error != null) {
      if (backpressurePromise !== undefined) backpressurePromise.reject(error);
      // If closed is not undefined, the error is happening
      // after the WritableStream close has already started.
      // We need to reject it here.
      if (closed !== undefined) {
        closed.reject(error);
        closed = undefined;
      }
      controller.error(error);
      controller = undefined;
      return;
    }

    if (closed !== undefined) {
      closed.resolve();
      closed = undefined;
      return;
    }
    controller.error(__intrinsic__makeAbortError());
    controller = undefined;
  });

  streamWritable.on("drain", onDrain);

  return new WritableStream(
    {
      start(c) {
        controller = c;
      },

      write(chunk) {
        try {
          options[kValidateChunk]?.(chunk);
          if (!streamWritable.writableObjectMode && isAnyArrayBuffer(chunk)) {
            chunk = new Uint8Array(chunk);
          }
          const needDrainBefore = streamWritable.writableNeedDrain;
          if (needDrainBefore || !streamWritable.write(chunk)) {
            backpressurePromise = PromiseWithResolvers();
            // write() may set writableNeedDrain; the post-write value is
            // what decides whether we resolve immediately.
            if (!streamWritable.writableNeedDrain) {
              backpressurePromise.resolve();
            }
            return SafePromisePrototypeFinally.__intrinsic__call(backpressurePromise.promise, () => {
              backpressurePromise = undefined;
            });
          }
        } catch (error) {
          // When the kDestroyOnSyncError flag is set (e.g. for
          // CompressionStream), a sync throw must also destroy the
          // stream so the readable side is errored too. Without this
          // the readable side hangs forever. This replicates the
          // TransformStream semantics: error both sides on any throw
          // in the transform path.
          if (options[kDestroyOnSyncError]) {
            destroyer(streamWritable, error);
          }
          throw error;
        }
      },

      abort(reason) {
        destroyer(streamWritable, reason);
      },

      close() {
        if (closed === undefined && !isWritableEnded(streamWritable)) {
          closed = PromiseWithResolvers();
          streamWritable.end();
          return closed.promise;
        }

        controller = undefined;
        return PromiseResolve();
      },
    },
    strategy,
  );
}

function newStreamWritableFromWritableStream(writableStream, options = kEmptyObject) {
  if (!__intrinsic__inherits(2, writableStream)) {
    throw __intrinsic__makeErrorWithCode(119, "writableStream", "WritableStream", writableStream);
  }

  validateObject(options, "options");
  const { highWaterMark, decodeStrings = true, objectMode = false, signal } = options;

  validateBoolean(objectMode, "options.objectMode");
  validateBoolean(decodeStrings, "options.decodeStrings");

  const writer = writableStream.getWriter();
  let closed = false;

  const writable = new Writable({
    highWaterMark,
    objectMode,
    decodeStrings,
    signal,

    writev(chunks, callback) {
      function done(error) {
        try {
          callback(error);
        } catch (error) {
          // In a next tick because this is happening within
          // a promise context, and if there are any errors
          // thrown we don't want those to cause an unhandled
          // rejection. Let's just escape the promise and
          // handle it separately.
          process.nextTick(() => destroyer(writable, error));
        }
      }

      PromisePrototypeThen.__intrinsic__call(
        writer.ready,
        () => {
          return PromisePrototypeThen.__intrinsic__call(
            SafePromiseAllReturnVoid(chunks, data => writer.write(data.chunk)),
            done,
            done,
          );
        },
        done,
      );
    },

    write(chunk, encoding, callback) {
      if (typeof chunk === "string" && decodeStrings && !objectMode) {
        const enc = normalizeEncoding(encoding);

        if (enc === "utf8") {
          chunk = encoder.encode(chunk);
        } else {
          chunk = Buffer.from(chunk, encoding);
          chunk = new Uint8Array(
            TypedArrayPrototypeGetBuffer(chunk),
            TypedArrayPrototypeGetByteOffset(chunk),
            TypedArrayPrototypeGetByteLength(chunk),
          );
        }
      }

      function done(error) {
        try {
          callback(error);
        } catch (error) {
          destroyer(writable, error);
        }
      }

      PromisePrototypeThen.__intrinsic__call(
        writer.ready,
        () => {
          return PromisePrototypeThen.__intrinsic__call(writer.write(chunk), done, done);
        },
        done,
      );
    },

    destroy(error, callback) {
      function done() {
        try {
          callback(error);
        } catch (error) {
          // In a next tick because this is happening within
          // a promise context, and if there are any errors
          // thrown we don't want those to cause an unhandled
          // rejection. Let's just escape the promise and
          // handle it separately.
          process.nextTick(() => {
            throw error;
          });
        }
      }

      if (!closed) {
        if (error != null) {
          PromisePrototypeThen.__intrinsic__call(writer.abort(error), done, done);
        } else {
          PromisePrototypeThen.__intrinsic__call(writer.close(), done, done);
        }
        return;
      }

      done();
    },

    final(callback) {
      function done(error) {
        try {
          callback(error);
        } catch (error) {
          // In a next tick because this is happening within
          // a promise context, and if there are any errors
          // thrown we don't want those to cause an unhandled
          // rejection. Let's just escape the promise and
          // handle it separately.
          process.nextTick(() => destroyer(writable, error));
        }
      }

      if (!closed) {
        PromisePrototypeThen.__intrinsic__call(writer.close(), done, done);
      }
    },
  });

  PromisePrototypeThen.__intrinsic__call(
    writer.closed,
    () => {
      // If the WritableStream closes before the stream.Writable has been
      // ended, we signal an error on the stream.Writable.
      closed = true;
      if (!isWritableEnded(writable)) destroyer(writable, __intrinsic__makeErrorWithCode(235, ));
    },
    error => {
      // If the WritableStream errors before the stream.Writable has been
      // destroyed, signal an error on the stream.Writable.
      closed = true;
      destroyer(writable, error);
    },
  );

  return writable;
}

const kErrorSentinelAttached = Symbol("kErrorSentinelAttached");

function newReadableStreamFromStreamReadable(streamReadable, options = kEmptyObject) {
  // Not using the internal/streams/utils isReadableNodeStream utility
  // here because it will return false if streamReadable is a Duplex
  // whose readable option is false. For a Duplex that is not readable,
  // we want it to pass this check but return a closed ReadableStream.
  if (typeof streamReadable?._readableState !== "object") {
    throw __intrinsic__makeErrorWithCode(119, "streamReadable", "stream.Readable", streamReadable);
  }
  validateObject(options, "options");
  const optionsType = options.type;
  if (optionsType !== undefined) {
    validateOneOf(optionsType, "options.type", ["bytes", undefined]);
  }

  const isBYOB = optionsType === "bytes";
  let controller;
  let wasCanceled = false;
  let strategy;

  const underlyingSource = {
    __proto__: null,
    type: isBYOB ? "bytes" : undefined,
    start(c) {
      controller = c;
    },
    cancel(reason) {
      wasCanceled = true;
      destroyer(streamReadable, reason);
    },
  };

  const readable = isReadable(streamReadable);
  const objectMode = streamReadable.readableObjectMode;
  if (readable) {
    underlyingSource.pull = function pull() {
      streamReadable.resume();
    };

    const highWaterMark = streamReadable.readableHighWaterMark;
    strategy = isBYOB
      ? { highWaterMark }
      : (options.strategy ?? new (objectMode ? CountQueuingStrategy : ByteLengthQueuingStrategy)({ highWaterMark }));
  }
  const readableStream = new ReadableStream(underlyingSource, strategy);

  // When adapting a Duplex as a ReadableStream, readable completion should not
  // wait for a half-open writable side to finish as well.
  let cleanup = noop;
  cleanup = eos(
    streamReadable,
    {
      __proto__: null,
      writable: false,
      [kEosNodeSynchronousCallback]: true,
    },
    error => {
      error = handleKnownInternalErrors(error);

      // If eos calls the callback synchronously, cleanup is still a no-op here.
      cleanup();

      if (!(kErrorSentinelAttached in streamReadable)) {
        // This is a protection against non-standard, legacy streams
        // that happen to emit an error event again after finished is called.
        streamReadable.on("error", noop);
        streamReadable[kErrorSentinelAttached] = true;
      }
      if (wasCanceled) {
        return;
      }
      wasCanceled = true;
      if (error) return controller.error(error);
      controller.close();
      if (isBYOB) controller.byobRequest?.respond(0);
    },
  );

  if (wasCanceled) {
    // `eos` called the callback synchronously
    cleanup();
  } else if (readable) {
    streamReadable.pause();

    streamReadable.on("data", function onData(chunk) {
      // Copy the Buffer to detach it from the pool.
      if (Buffer.isBuffer(chunk) && !objectMode) chunk = new Uint8Array(chunk);
      controller.enqueue(chunk);
      if (controller.desiredSize <= 0) streamReadable.pause();
    });
  }

  return readableStream;
}

function newStreamReadableFromReadableStream(readableStream, options: Record<string, unknown> = kEmptyObject) {
  if (!__intrinsic__inherits(1, readableStream)) {
    throw __intrinsic__makeErrorWithCode(119, "readableStream", "ReadableStream", readableStream);
  }

  validateObject(options, "options");
  const { highWaterMark, encoding, objectMode = false, signal } = options;

  if (encoding !== undefined && !Buffer.isEncoding(encoding))
    throw __intrinsic__makeErrorWithCode(120, "options.encoding", encoding);
  validateBoolean(objectMode, "options.objectMode");

  const nativeStream = tryTransferToNativeReadable(readableStream, options);

  return (
    nativeStream ||
    new ReadableFromWeb(
      {
        highWaterMark,
        encoding,
        objectMode,
        signal,
      },
      readableStream,
    )
  );
}

let dep0201Warned = false;
function emitDEP0201() {
  if (dep0201Warned) return;
  dep0201Warned = true;
  process.emitWarning(
    "Passing 'options.type' to Duplex.toWeb() is deprecated. " +
      "To specify the ReadableStream type, use 'options.readableType'.",
    "DeprecationWarning",
    "DEP0201",
  );
}

function newReadableWritablePairFromDuplex(duplex, options = kEmptyObject) {
  // Not using the internal/streams/utils isWritableNodeStream and
  // isReadableNodeStream utilities here because they will return false
  // if the duplex was created with writable or readable options set to
  // false. Instead, we'll check the readable and writable state after
  // and return closed WritableStream or closed ReadableStream as
  // necessary.
  if (typeof duplex?._writableState !== "object" || typeof duplex?._readableState !== "object") {
    throw __intrinsic__makeErrorWithCode(119, "duplex", "stream.Duplex", duplex);
  }

  validateObject(options, "options");

  const readableOptions = {
    __proto__: null,
    type: options.readableType,
  };

  let optionsType;
  if (options.readableType == null && (optionsType = options.type) != null) {
    // 'options.type' is a deprecated alias for 'options.readableType'
    emitDEP0201();
    readableOptions.type = optionsType;
  }

  if (isDestroyed(duplex)) {
    const writable = new WritableStream();
    const readable = new ReadableStream({ type: readableOptions.type });
    writable.close();
    readable.cancel();
    return { readable, writable };
  }

  const writableOptions = {
    __proto__: null,
    [kValidateChunk]: options[kValidateChunk],
    [kDestroyOnSyncError]: options[kDestroyOnSyncError],
  };

  const writable = isWritable(duplex)
    ? newWritableStreamFromStreamWritable(duplex, writableOptions)
    : new WritableStream();

  if (!isWritable(duplex)) writable.close();

  const readable = isReadable(duplex)
    ? newReadableStreamFromStreamReadable(duplex, readableOptions)
    : new ReadableStream({ type: readableOptions.type });

  if (!isReadable(duplex)) readable.cancel();

  return { writable, readable };
}

function newStreamDuplexFromReadableWritablePair(pair = kEmptyObject, options = kEmptyObject) {
  validateObject(pair, "pair");
  const { readable: readableStream, writable: writableStream } = pair;

  if (!__intrinsic__inherits(1, readableStream)) {
    throw __intrinsic__makeErrorWithCode(119, "pair.readable", "ReadableStream", readableStream);
  }
  if (!__intrinsic__inherits(2, writableStream)) {
    throw __intrinsic__makeErrorWithCode(119, "pair.writable", "WritableStream", writableStream);
  }

  validateObject(options, "options");
  const { allowHalfOpen = false, objectMode = false, encoding, decodeStrings = true, highWaterMark, signal } = options;

  validateBoolean(objectMode, "options.objectMode");
  if (encoding !== undefined && !Buffer.isEncoding(encoding))
    throw __intrinsic__makeErrorWithCode(120, encoding, "options.encoding");

  const writer = writableStream.getWriter();
  const reader = readableStream.getReader();
  let writableClosed = false;
  let readableClosed = false;

  const duplex = new Duplex({
    allowHalfOpen,
    highWaterMark,
    objectMode,
    encoding,
    decodeStrings,
    signal,

    writev(chunks, callback) {
      function done(error) {
        try {
          callback(error);
        } catch (error) {
          // In a next tick because this is happening within
          // a promise context, and if there are any errors
          // thrown we don't want those to cause an unhandled
          // rejection. Let's just escape the promise and
          // handle it separately.
          process.nextTick(() => destroyer(duplex, error));
        }
      }

      PromisePrototypeThen.__intrinsic__call(
        writer.ready,
        () => {
          return PromisePrototypeThen.__intrinsic__call(
            SafePromiseAllReturnVoid(chunks, data => writer.write(data.chunk)),
            done,
            done,
          );
        },
        done,
      );
    },

    write(chunk, encoding, callback) {
      if (typeof chunk === "string" && decodeStrings && !objectMode) {
        const enc = normalizeEncoding(encoding);

        if (enc === "utf8") {
          chunk = encoder.encode(chunk);
        } else {
          chunk = Buffer.from(chunk, encoding);
          chunk = new Uint8Array(
            TypedArrayPrototypeGetBuffer(chunk),
            TypedArrayPrototypeGetByteOffset(chunk),
            TypedArrayPrototypeGetByteLength(chunk),
          );
        }
      }

      function done(error) {
        try {
          callback(error);
        } catch (error) {
          destroyer(duplex, error);
        }
      }

      PromisePrototypeThen.__intrinsic__call(
        writer.ready,
        () => {
          return PromisePrototypeThen.__intrinsic__call(writer.write(chunk), done, done);
        },
        done,
      );
    },

    final(callback) {
      function done(error) {
        try {
          callback(error);
        } catch (error) {
          // In a next tick because this is happening within
          // a promise context, and if there are any errors
          // thrown we don't want those to cause an unhandled
          // rejection. Let's just escape the promise and
          // handle it separately.
          process.nextTick(() => destroyer(duplex, error));
        }
      }

      if (!writableClosed) {
        PromisePrototypeThen.__intrinsic__call(writer.close(), done, done);
      }
    },

    read() {
      PromisePrototypeThen.__intrinsic__call(
        reader.read(),
        chunk => {
          if (chunk.done) {
            duplex.push(null);
          } else {
            duplex.push(chunk.value);
          }
        },
        error => destroyer(duplex, error),
      );
    },

    destroy(error, callback) {
      function done() {
        try {
          callback(error);
        } catch (error) {
          // In a next tick because this is happening within
          // a promise context, and if there are any errors
          // thrown we don't want those to cause an unhandled
          // rejection. Let's just escape the promise and
          // handle it separately.
          process.nextTick(() => {
            throw error;
          });
        }
      }

      async function closeWriter() {
        if (!writableClosed) await writer.abort(error);
      }

      async function closeReader() {
        if (!readableClosed) await reader.cancel(error);
      }

      if (!writableClosed || !readableClosed) {
        PromisePrototypeThen.__intrinsic__call(SafePromiseAllReturnVoid([closeWriter(), closeReader()]), done, done);
        return;
      }

      done();
    },
  });

  PromisePrototypeThen.__intrinsic__call(
    writer.closed,
    () => {
      writableClosed = true;
      if (!isWritableEnded(duplex)) destroyer(duplex, __intrinsic__makeErrorWithCode(235, ));
    },
    error => {
      writableClosed = true;
      readableClosed = true;
      destroyer(duplex, error);
    },
  );

  PromisePrototypeThen.__intrinsic__call(
    reader.closed,
    () => {
      readableClosed = true;
    },
    error => {
      writableClosed = true;
      readableClosed = true;
      destroyer(duplex, error);
    },
  );

  return duplex;
}

// Shared by CompressionStream and DecompressionStream: per the Compression
// Streams spec, chunks must be BufferSource (ArrayBuffer or ArrayBufferView
// not backed by SharedArrayBuffer), and an invalid chunk must error both
// sides of the pair synchronously.
function newBufferSourceTransformPairFromDuplex(duplex) {
  const { isArrayBufferView, isSharedArrayBuffer } = (__intrinsic__getInternalField(__intrinsic__internalModuleRegistry, 164) || __intrinsic__createInternalModuleById(164));
  return newReadableWritablePairFromDuplex(duplex, {
    [kValidateChunk]: function validateBufferSourceChunk(chunk) {
      if (isSharedArrayBuffer(isArrayBufferView(chunk) ? chunk.buffer : chunk)) {
        throw __intrinsic__makeErrorWithCode(119, "chunk", ["ArrayBuffer", "Buffer", "TypedArray", "DataView"], chunk);
      }
    },
    [kDestroyOnSyncError]: true,
  });
}

$ = {
  newWritableStreamFromStreamWritable,
  newReadableStreamFromStreamReadable,
  newStreamWritableFromWritableStream,
  newStreamReadableFromReadableStream,
  newReadableWritablePairFromDuplex,
  newStreamDuplexFromReadableWritablePair,
  newBufferSourceTransformPairFromDuplex,
  kValidateChunk,
  kDestroyOnSyncError,
  _ReadableFromWeb: ReadableFromWeb,
};
;$$EXPORT$$($).$$EXPORT_END$$;
