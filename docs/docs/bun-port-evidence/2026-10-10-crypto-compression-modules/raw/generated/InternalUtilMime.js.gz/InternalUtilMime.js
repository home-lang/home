(function () {"use strict";
// zig-out/crypto-compression-port-2026-10-10/generated/InternalUtilMime.mts
var $, { MIMEParams, MIMEType } = @lazy(26);
$ = {
  MIMEParams,
  MIMEType
};
return $

})
