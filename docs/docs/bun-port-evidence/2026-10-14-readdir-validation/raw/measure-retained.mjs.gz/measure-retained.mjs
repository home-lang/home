import fs from 'node:fs'
import assert from 'node:assert/strict'
import { performance } from 'node:perf_hooks'
import { resolve } from 'node:path'
const root = resolve('packages/runtime/test/test/js/node')
const equal = globalThis.Bun ? (await import('bun:test')).expect : null
const measurements = []
for (const withFileTypes of [false, true]) {
  fs.readdirSync(root, { withFileTypes })
  const results = new Array(200)
  const begin = performance.now()
  for (let i = 0; i < results.length; i++) results[i] = fs.readdirSync(root, { recursive: true, withFileTypes })
  const traversal = performance.now()
  for (const row of results) row.sort()
  const sorting = performance.now()
  for (let i = 1; i < results.length; i++) {
    if (equal) equal(results[i]).toEqual(results[0])
    else assert.deepStrictEqual(results[i], results[0])
  }
  const end = performance.now()
  measurements.push({ withFileTypes, count: results[0].length, retainedResults: results.length, traversalMs: traversal - begin, sortMs: sorting - traversal, equalityMs: end - sorting, totalMs: end - begin })
  console.log(JSON.stringify({ runtime: process.execPath, stage: withFileTypes ? 'dirents' : 'strings', measurement: measurements.at(-1) }))
}
console.log(JSON.stringify({ runtime: process.execPath, measurements }))
