from pathlib import Path
import subprocess,os,json
p=Path(__file__).resolve().parent;root=p.parents[1];rows=[]
for name,exe in [('home',str(root/'zig-out/bin/home')),('bun','/Users/chris/.bun/bin/bun'),('node','/Users/chris/.local/share/pantry/global/packages/nodejs.org/v26.10.0/bin/node')]:
 with (p/('retained-'+name+'.log')).open('wb') as out:
  try:r=subprocess.run([exe,str(p/'measure-retained.mjs')],cwd=root,stdout=out,stderr=subprocess.STDOUT,timeout=180,env=os.environ.copy())
  except subprocess.TimeoutExpired:r=subprocess.CompletedProcess([],124)
 rows.append({'runtime':name,'exit':r.returncode});(p/'retained-results.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,r.returncode,flush=True)
raise SystemExit(any(r['exit'] for r in rows))
