Parent: #66. Related native directory ownership #878 and recursive traversal #896.

A same-filesystem Node v26.10.0 / installed Bun 1.4.2 / Home native probe on Darwin arm64 identified two directory-data gaps. Home and installed Bun both expose undefined `Dirent.name` for `fs.readdirSync` and callback/promise readdir with `{ withFileTypes: true, encoding: "buffer" }`, including recursive calls. Node returns Buffers containing the actual filename bytes. Home and installed Bun also ignore requested latin1/hex encodings in recursive asynchronous Dirent names while synchronous calls encode names.

The pinned buffer Dirent original only checks the callback error, so its passing process check does not prove name-value correctness. The unchanged opendir test itself describes the existing buffer Dirent gap. Home’s native opendir carrier already preserves raw buffer names, but the native readdir result carrier does not.

Acceptance:

- Implement native buffer name materialization with correct ownership, raw POSIX filename bytes, Windows UTF-8 conversion, and GC-safe result construction.
- Preserve parentPath/path types, values and alias behavior against actual Node controls, including recursive directories and Buffer path arguments.
- Apply requested name encoding consistently in recursive asynchronous traversal, while traversing actual filesystem names.
- Preserve real Dirent kind methods, Unicode/invalid-byte names, callback/promise/sync semantics and shutdown/error cleanup.
- Keep original corpus bytes/assertions/deadlines unchanged and validate the wider filesystem selection after the related native changes.

This probe uses installed Bun as a reference, not a rebuilt pinned-source binary. No production change or full-suite acceptance is claimed by the probe.
