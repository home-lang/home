import fs from 'node:fs'
import { readdir } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
const root=fs.mkdtempSync(join(tmpdir(),'home-dirent-encoding-'))
const rows=[]
const describe=xs=>xs.map(x=>({nameType:typeof x.name,nameBuffer:Buffer.isBuffer(x.name),name:Buffer.isBuffer(x.name)?x.name.toString('hex'):x.name,parentBuffer:Buffer.isBuffer(x.parentPath??x.path)}))
try {
 fs.mkdirSync(join(root,'é'));fs.writeFileSync(join(root,'é','日本語.txt'),'x')
 for(const recursive of [false,true]) for(const encoding of ['utf8','buffer','latin1','hex']) {
  for(const mode of ['sync','async']) {
   try {const result=mode==='sync'?fs.readdirSync(root,{recursive,withFileTypes:true,encoding}):await readdir(root,{recursive,withFileTypes:true,encoding});rows.push({recursive,encoding,mode,result:describe(result)})}
   catch(e){rows.push({recursive,encoding,mode,error:e.code??e.message})}
  }
 }
 console.log(JSON.stringify({runtime:process.execPath,rows}))
}finally{fs.rmSync(root,{recursive:true,force:true})}
