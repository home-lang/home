from pathlib import Path
import os,subprocess,json
p=Path(__file__).resolve().parent;root=p.parents[2];rows=[]
env=os.environ.copy();env.update(BUN_DEBUG_QUIET_LOGS='1',BUN_GARBAGE_COLLECTOR_LEVEL='1',BUN_FEATURE_FLAG_INTERNAL_FOR_TESTING='1',BUN_JSC_randomIntegrityAuditRate='1.0',BUN_RUNTIME_TRANSPILER_CACHE_PATH='0')
(p/'profile.json').write_text(json.dumps({k:env[k] for k in ('BUN_DEBUG_QUIET_LOGS','BUN_GARBAGE_COLLECTOR_LEVEL','BUN_FEATURE_FLAG_INTERNAL_FOR_TESTING','BUN_JSC_randomIntegrityAuditRate','BUN_RUNTIME_TRANSPILER_CACHE_PATH')},indent=2)+'\n')
for name,exe in [('home',str(root/'zig-out/bin/home')),('bun','/Users/chris/.bun/bin/bun')]:
 with (p/(name+'.log')).open('wb') as out:
  try:r=subprocess.run([exe,str(p.parent/'measure-retained.mjs')],cwd=root,stdout=out,stderr=subprocess.STDOUT,timeout=180,env=env)
  except subprocess.TimeoutExpired:r=subprocess.CompletedProcess([],124)
 rows.append({'runtime':name,'exit':r.returncode});(p/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,r.returncode,flush=True)
raise SystemExit(any(r['exit'] for r in rows))
