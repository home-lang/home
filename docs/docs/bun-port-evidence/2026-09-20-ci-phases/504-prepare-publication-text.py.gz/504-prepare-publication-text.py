from pathlib import Path
import json,subprocess
root=Path.cwd();ev=root/'zig-out/bun-ci-20260920';folder=root/'docs/docs/bun-port-evidence/2026-09-20-ci-phases';m=json.loads((folder/'manifest.json').read_text());source=m['source'];sha=m['home_sha256']
assert m['vendor_registered_cases']==dict(passed=1516,failed=0,skipped=0,todo=0)
text=f'''The ordered-phase checkpoint passes **23/23 native build steps, 21/21 native harness tests, seven launcher units, four service/child-lifetime units and 20 outcome-validator controls** with Zig `0.17.0-dev.2163+89ff10d56`. The first build compiled successfully but retained a **20-pass/one-fail harness result**: the new private service-context fixture omitted the config required by primary corpus launch. Adding that fixture input and diagnostic output corrected the control; no original corpus source or production launch behavior was changed to hide the failure. The queued corpus run stopped at its build gate before execution.

Private native CLI checks verify checkout without hooks, rejection of a changed revision before tag/install/build, and successful installation/build of the previously verified revision. The native harness also verifies that a real test child receives the live remap URL and can fetch its service. This checks propagation of the Docker socket setting, not real Docker readiness. The installed pinned remap service passes all five HTTP checks with complete captures and owned shutdown.

Fresh native Elysia checkout completes five operations without dependencies present; the separate revision-guarded install/build completes four operations. All 283 resulting source hashes match the independently verified setup, including the original package-manager lockfile normalization. On Home SHA256 `{sha}`, all **129 selected files complete once with 1,516 registered passes and zero failures, registered skips or TODOs**. The original WebSocket exclusion remains separate. The earlier build's port-3000 failure and error-object follow-up #726 remain retained; this is the first vendor execution for the new build, not a retry of that result. Preparation and service checks earn zero corpus-case credit, and repeated vendor regressions are not additional distinct coverage.

[Ordered-phase evidence](./bun-port-evidence/2026-09-20-ci-phases/manifest.json) retains both build outcomes, private controls, exact sources, complete per-file captures and JUnit reports. The 50 pinned setup inputs remain unchanged; primary root/test installs were not repeated in this batch. Default full CI orchestration, actual Linux Docker verification, crash processing, the missing optional legacy DuckDB binding under #725 and full primary-suite execution remain open under #724 and #66. Full logical parity is incomplete.
'''
p=root/'docs/docs/bun-corpus-selection.md';s=p.read_text();assert 'The ordered-phase checkpoint passes' not in s;p.write_text(s.rstrip()+'\n\n'+text)
p=root/'docs/docs/bun-corpus-outcomes-baseline.json';d=json.loads(p.read_text());d['ordered_vendor_phase_checkpoint']={k:v for k,v in m.items() if k!='files'};d['ordered_vendor_phase_checkpoint']['evidence']=str((folder/'manifest.json').relative_to(root));p.write_text(json.dumps(d,indent=2)+'\n')
issue=f'''## Current publication / remaining work (2026-09-20)

**Full logical Bun parity remains incomplete.** Native phase/context source [{source[:9]}](https://github.com/home-lang/home/commit/{source}) is committed as Chris Breuer without coauthors on origin/main. Home SHA256 `{sha}`; Zig `0.17.0-dev.2163+89ff10d56`.

Native vendor checkout and install/build are now separate phases. Checkout verifies the pinned tag without installation hooks; later preparation requires the recorded revision and refuses a changed checkout before hooks. Native child launches carry live remap and ready Docker settings through primary/vendor tests and package preparation. The default CI coordinator still needs to connect selection, services, setup and execution in the original order.

**23/23 build steps, 21/21 native harness tests, seven launcher units, four service/child-lifetime units and 20 validator controls pass.** Private CLI checks retain checkout-only success, changed-revision rejection with later operations unstarted, and guarded install/build success. Five real pinned remap HTTP checks pass. The first harness result (20 pass, one fail) is retained: the new private fixture lacked the required bunfig.toml. Its config correction changes no original corpus test or production launch behavior; the original queued runtime batch stopped before execution.

Fresh Elysia checkout completes five operations, then native install/build completes four, at unchanged deadlines. All 283 resulting source hashes match the previously verified pinned setup. **All 129 selected original Elysia files complete once with 1,516 registered passes, zero failures, registered skips or TODOs.** The original WebSocket exclusion stays separate. This is the first vendor execution on the new build; the prior binary's port-3000 failure remains retained and #726 stays open for the separate bind-error compatibility audit. Setup/service outcomes earn zero case credit, and repeated regressions are not new distinct coverage.

**Remaining:** #724 default full CI orchestration and complete applicable primary/vendor execution; actual Linux Docker startup and native platform verification; crash processing; #725 optional legacy DuckDB; independent native build ownership and remaining runtime features. The 50 pinned setup inputs still match; this batch did not repeat primary root/test installs. No full-suite or 100% parity claim.

[Implementation and verification boundary](https://github.com/home-lang/home/blob/main/docs/docs/bun-corpus-selection.md) · [Retained evidence](https://github.com/home-lang/home/blob/main/docs/docs/bun-port-evidence/2026-09-20-ci-phases/manifest.json)

'''
(ev/'issue-checkpoint.md').write_text(issue)
print('Prepared docs and issue text from verified manifest',source)
