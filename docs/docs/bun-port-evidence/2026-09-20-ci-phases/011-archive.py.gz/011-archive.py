from pathlib import Path
import gzip,hashlib,json,subprocess
root=Path.cwd();ev=root/'zig-out/bun-ci-20260920';folder=root/'docs/docs/bun-port-evidence/2026-09-20-ci-phases';folder.mkdir()
runs={n:json.loads((ev/n/'manifest.json').read_text()) for n in ['phase-cli','remap-regression','elysia-phases','elysia-execution']}
for n,m in runs.items():assert m.get('verified',m.get('verification_passed')),(n,m)
sha=runs['elysia-execution']['home_sha256'];assert all(m['home_sha256']==sha for m in runs.values())
assert 'Build Summary: 23/23 steps succeeded; 21/21 tests passed' in (ev/'native-build-fixture-corrected.log').read_text()
manifest={'kind':'separate native vendor phases and inherited service launch context','source':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'source_before_build':'0d09d38cdec8b8d8ca053db4196c8091977195aa','home_sha256':sha,'bun_pin':'4982b91e3702094330f3be3883354c52b8c01323','zig_version':'0.17.0-dev.2163+89ff10d56','zig_download_sha256':'9613b867f218a21be7760f714cfb3f18ce36fec85d2051f4c26362b495f2face','native_build_steps_passed':23,'native_harness_passed':21,'validator_controls_passed':20,'launch_units_passed':7,'service_units_passed':4,'private_phase_cli_outcomes':runs['phase-cli']['runs'],'fresh_vendor_phases':runs['elysia-phases']['runs'],'phase_and_service_case_credit':0,'real_remap_protocol_checks':5,'vendor_completed_files':129,'vendor_registered_cases':runs['elysia-execution']['counts'],'vendor_attempts_this_build':1,'vendor_sources_unchanged':283,'vendor_original_excluded_file':'test/ws/connection.test.ts','removed_generated_bytes':runs['elysia-phases']['removed_generated_bytes'],'first_native_harness_outcome':{'passed':20,'failed':1,'reason':'new private service-context fixture missing required bunfig.toml'},'full_ci_orchestration_complete':False,'full_parity_complete':False,'files':[]}
paths=[]
for n in ['phase-cli','remap-regression','elysia-phases','elysia-execution','first-source','corrected-source','service-fixture-diagnostic']:paths.extend(p for p in (ev/n).rglob('*') if p.is_file())
for p in ev.iterdir():
 if p.is_file() and p.name not in ['archive.log']:paths.append(p)
for name in ['packages/home_test/src/corpus_launch.zig','packages/home_test/src/corpus_vendor_prepare.zig','packages/home_test/src/corpus_remap.zig','packages/home_test/src/corpus_runner.zig','packages/home_test/src/corpus_setup.zig','packages/home_test/src/corpus_journal.zig','packages/home_test/src/adapters/jsc_bootstrap.zig','scripts/summarize-bun-corpus.py','scripts/test_summarize_bun_corpus.py','src/main.zig']:paths.append(root/name)
for index,p in enumerate(sorted(set(paths))):
 data=p.read_bytes();name=f'{index:03d}-{p.name}.gz';(folder/name).write_bytes(gzip.compress(data,mtime=0));manifest['files'].append({'artifact':name,'source':str(p.relative_to(root)),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
(folder/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({k:v for k,v in manifest.items() if k!='files'},indent=2));print('artifacts',len(manifest['files']))
