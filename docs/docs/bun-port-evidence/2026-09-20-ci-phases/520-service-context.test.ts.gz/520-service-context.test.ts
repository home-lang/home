import { test, expect } from 'bun:test';
test('live coordinator service context', async () => {
  expect(process.env.BUN_CRASH_REPORT_URL).toMatch(/^http:\/\/localhost:/);
  expect(await (await fetch(process.env.BUN_CRASH_REPORT_URL)).text()).toBe('ready');
  expect(process.env.BUN_DOCKER_COORDINATOR).toBe('/private/control/ready.sock');
});
