#!/usr/bin/env python3
"""Validate retained native corpus evidence without retrying or inventing cases.

Exit 0 requires complete, internally consistent, successful execution. Skipped
and TODO cases stay separate, and are never credited as passing features.
"""
import argparse
import hashlib
import json
from pathlib import Path
import sys
import xml.etree.ElementTree as ET


COUNTS = ('passed', 'failed', 'skipped', 'todo')


def digest(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(block)
    return value.hexdigest()


def summarize(directory):
    directory = Path(directory)
    errors, selected, started, completed, cases = [], {}, {}, {}, []
    finished = None
    totals = dict.fromkeys(COUNTS, 0)
    run = None
    selection = None
    setup = None
    purpose = "corpus"
    service = None
    readiness = None
    vendor_setup = None
    checkout = None

    def check(condition, message):
        if not condition:
            errors.append(message)
        return condition

    def artifact(row, kind):
        name = row.get(kind + '_file')
        if not check(isinstance(name, str) and Path(name).name == name, f"{row['id']}: invalid {kind} artifact name"):
            return None
        path = directory / name
        try:
            check(digest(path) == row.get(kind + '_sha256'), f"{row['id']}: {kind} SHA256 mismatch")
            return path
        except OSError as error:
            errors.append(f"{row['id']}: cannot read {kind}: {error}")
            return None

    try:
        data = (directory / 'events.jsonl').read_bytes()
    except OSError as error:
        return {'directory': str(directory), 'successful': False, 'errors': [str(error)]}
    check(data.endswith(b'\n'), 'journal has an incomplete final line')
    for number, line in enumerate(data.splitlines(), 1):
        try:
            row = json.loads(line)
            event = row['event']
            check(finished is None, f'line {number}: event after finished')
            if event == 'run':
                check(number == 1 and run is None and row.get('schema') in (1, 2), 'invalid run header')
                run = row
                purpose = row.get('purpose', 'corpus')
                check(purpose in ('corpus', 'setup', 'service', 'vendor_setup'), 'unknown run purpose')
                check(purpose == 'corpus' or row.get('schema') == 2, 'setup requires complete-capture schema')
            elif event == 'service_plan':
                check(purpose == 'service' and run is not None and service is None and not selected and not started, 'invalid service plan order')
                service = row
                check(row.get('contract') == 'bun-4982b91e-ci-remap' and row.get('service') == 'ci-remap-server' and row.get('setup_performed') is False, 'invalid service contract')
                check(row.get('startup_timeout_ms') == 5000 and row.get('ready_protocol') == 'port_line', 'invalid service readiness contract')
                for key, size in [('commit', 40), ('source_sha256', 64), ('package_sha256', 64)]:
                    value = row.get(key)
                    check(isinstance(value, str) and len(value) == size and all(c in '0123456789abcdef' for c in value), 'invalid service ' + key)
            elif event == 'service_readiness':
                check(purpose == 'service' and service is not None and readiness is None and row.get('id') == 0 and 0 in started and not completed, 'invalid service readiness order')
                readiness = row
                check(type(row.get('ready')) is bool, 'invalid service ready state')
                check((type(row.get('port')) is int and 0 < row['port'] < 65536) if row.get('ready') else row.get('port') is None, 'invalid service port')
            elif event == 'vendor_setup_plan':
                check(purpose == 'vendor_setup' and run is not None and vendor_setup is None and not selected and not started, 'invalid vendor preparation plan order')
                vendor_setup = row
                check(row.get('contract') == 'bun-4982b91e-explicit-vendor-preparation' and row.get('case_credit') == 0, 'invalid vendor preparation contract')
                check(type(row.get('clone_required')) is bool, 'invalid vendor clone state')
                phase = row.get('phase', 'all')
                check(phase in ('all', 'checkout', 'install_build'), 'invalid vendor preparation phase')
                steps = (['clone'] if row.get('clone_required') else []) + ['fetch', 'checkout', 'head', 'tag']
                if phase == 'install_build':
                    check(row.get('clone_required') is False, 'installation cannot clone a replacement checkout')
                    steps = ['head', 'tag']
                if phase != 'checkout':
                    steps += ['install', 'build']
                revision = row.get('expected_revision')
                if phase == 'install_build' or revision is not None:
                    check(isinstance(revision, str) and len(revision) == 40 and all(c in '0123456789abcdef' for c in revision), 'missing or invalid expected vendor revision')
                check(row.get('steps') == [dict(path=path, timeout_ms=60000 if path == 'build' else 180000) for path in steps], 'invalid vendor preparation steps')
                vendor = row['vendor']
                check(all(isinstance(vendor.get(key), str) and vendor[key] for key in ('package', 'repository', 'tag')), 'invalid vendor specification')
                check(row.get('vendor_cwd') == str(Path(run['corpus_root']) / 'vendor' / vendor['package']), 'invalid vendor working directory')
                value = row.get('vendor_sha256')
                check(isinstance(value, str) and len(value) == 64 and all(c in '0123456789abcdef' for c in value), 'invalid vendor specification hash')
            elif event == 'vendor_checkout':
                check(purpose == 'vendor_setup' and vendor_setup is not None and checkout is None, 'invalid vendor checkout record')
                checkout = row
                check(row.get('tag') == vendor_setup['vendor']['tag'], 'vendor checkout tag mismatch')
                if vendor_setup.get('expected_revision') is not None:
                    check(row.get('revision') == vendor_setup['expected_revision'], 'vendor checkout changed across preparation phases')
                for key, size in [('revision', 40), ('package_sha256', 64)]:
                    value = row.get(key)
                    check(isinstance(value, str) and len(value) == size and all(c in '0123456789abcdef' for c in value), 'invalid vendor checkout ' + key)
                for name in ('head', 'tag'):
                    matches = [identity for identity, choice in selected.items() if choice.get('path') == name]
                    check(len(matches) == 1 and matches[0] in completed, 'vendor checkout precedes revision verification')
                    if len(matches) == 1 and matches[0] in completed:
                        path = artifact(completed[matches[0]], 'stdout')
                        if path:
                            check(path.read_text().strip() == row.get('revision'), 'vendor Git revision output mismatch')
            elif event == 'setup_plan':
                check(purpose == 'setup' and run is not None and setup is None and not selected and not started, 'invalid setup plan order')
                setup = row
                check(row.get('contract') == 'bun-4982b91e-root-test-setup', 'unknown setup contract')
                for key, size in [('bun_pin', 40), ('manifest_sha256', 64)]:
                    value = row.get(key)
                    check(isinstance(value, str) and len(value) == size and all(c in '0123456789abcdef' for c in value), 'invalid setup ' + key)
                check(row.get('steps') == [dict(path=path, operation='install', timeout_ms=180000) for path in ('package.json', 'test/package.json')], 'invalid original setup steps')
                inputs = row['inputs']
                paths = []
                for entry in inputs:
                    path, sha = entry['path'], entry['sha256']
                    check(isinstance(path, str) and bool(path) and not Path(path).is_absolute() and '\\' not in path and all(part not in ('', '.', '..') for part in path.split('/')), 'invalid setup input path')
                    check(isinstance(sha, str) and len(sha) == 64 and all(c in '0123456789abcdef' for c in sha), 'invalid setup input hash')
                    paths.append(path)
                check(len(paths) == len(set(paths)) and all(path in paths for path in ('package.json', 'test/package.json')), 'missing or duplicate setup inputs')
                host, expected = row['host'], row['expected_platform']
                check(isinstance(host, dict) and isinstance(expected, dict) and all(isinstance(host.get(key), str) and host[key] for key in ('os', 'arch')), 'invalid setup platform record')
                if expected.get('os'):
                    for field in ('os', 'arch', 'abi', 'distro', 'release'):
                        wanted = expected.get(field)
                        if wanted:
                            actual = host.get('distro_version' if field == 'release' else field)
                            check(isinstance(actual, str) and isinstance(wanted, str) and (actual == wanted or (field == 'release' and actual.startswith(wanted + '.'))), 'setup platform mismatch: ' + field)
            elif event == 'setup_input_changed':
                errors.append('setup input changed: ' + str(row.get('path')))
            elif event == 'selection':
                check(run is not None and not selected and not started and selection is None, f'line {number}: invalid policy order')
                check(purpose == 'corpus', 'test selection in setup run')
                selection = row
                check(row.get('contract') in ('bun-4982b91e-primary', 'bun-4982b91e-vendor'), 'unknown selection contract')
                vendor_policy = row.get('contract') == 'bun-4982b91e-vendor'
                if vendor_policy:
                    check(row.get('execution') == 'prepared-vendor' and row.get('setup_performed') is False, 'invalid prepared vendor scope')
                if not vendor_policy and row.get('native_platform_detected') is True:
                    context, expected = row['context'], row['expected_platform']
                    valid = isinstance(context, dict) and isinstance(expected, dict)
                    check(valid, 'invalid native platform record')
                    if valid:
                        check(type(context.get('is_ci')) is bool and type(row.get('asan_step')) is bool, 'invalid native launch context')
                        if expected.get('os'):
                            for field in ('os', 'arch', 'abi', 'distro', 'release'):
                                wanted = expected.get(field)
                                if wanted:
                                    actual = context.get('distro_version' if field == 'release' else field)
                                    matches = isinstance(actual, str) and isinstance(wanted, str) and (actual == wanted or (field == 'release' and actual.startswith(wanted + '.')))
                                    check(matches, 'native platform expectation mismatch: ' + field)
                inventory, indices, excluded = row['inventory'], row['selected_indices'], row['excluded']
                check(isinstance(inventory, list) and all(isinstance(path, str) for path in inventory), 'invalid policy inventory')
                check(len(set(inventory)) == len(inventory), 'duplicate policy inventory paths')
                omitted = [entry['index'] for entry in excluded]
                all_indices = indices + omitted
                valid_indices = all(type(index) is int and 0 <= index < len(inventory) for index in all_indices)
                check(valid_indices and sorted(all_indices) == list(range(len(inventory))), 'selection does not partition the inventory')
                reasons = ('not_test', 'extension', 'all_disabled', 'skip_rule', 'positional_filter') if vendor_policy else ('node_platform', 'node_only', 'include_filter', 'exclude_filter', 'expectation', 'positional_filter', 'shard')
                for entry in excluded:
                    check(entry.get('reason') in reasons, 'unknown exclusion reason')
                    if entry.get('reason') == 'skip_rule':
                        pattern = entry.get('skip_pattern')
                        check(isinstance(pattern, str) and pattern in row['vendor']['skipTests'], 'missing original vendor skip pattern')
                    if entry.get('reason') == 'expectation':
                        rule = entry.get('rule')
                        check(type(rule) is int and 0 <= rule < len(row['home_expectations']), 'missing exclusion rule')
                start, end = row['range_start'], row['range_end']
                check(type(start) is int and type(end) is int and 0 <= start <= end <= len(indices), 'invalid execution range')
                extra = row['additional_home_coverage']
                check(len(set(extra)) == len(extra) and all(index in indices for index in extra), 'invalid additional Home coverage')
            elif event == 'selected':
                identity = row['id']
                check(not started and identity == len(selected) and identity not in selected, f'line {number}: invalid selection order')
                selected[identity] = row
            elif event == 'started':
                identity = row['id']
                check(identity in selected and identity == len(started) and len(started) == len(completed), f'line {number}: invalid start order')
                check(row.get('phase') == 'launch_attempt', f'{identity}: unknown start phase')
                check(isinstance(row.get('argv'), list) and bool(row['argv']), f'{identity}: missing argv')
                check(isinstance(row.get('timeout_ms'), int) and row['timeout_ms'] > 0, f'{identity}: missing deadline')
                for key in ('source_sha256', 'executable_sha256'):
                    value = row.get(key)
                    check(isinstance(value, str) and len(value) == 64 and all(c in '0123456789abcdef' for c in value), f'{identity}: missing {key}')
                if purpose == 'setup':
                    check(setup is not None, 'missing setup plan before launch')
                    check(row.get('mode') == 'setup_install' and row.get('timeout_ms') == 180000, 'invalid setup launch mode or deadline')
                    check(len(row.get('argv', [])) == 2 and row['argv'][1:] == ['install'], 'invalid setup argv')
                    if identity in selected and run and setup:
                        path = selected[identity]['path']
                        check(row.get('cwd') == str(Path(run['corpus_root']) / Path(path).parent), 'invalid setup cwd')
                        hashes = {entry['path']: entry['sha256'] for entry in setup['inputs']}
                        check(row.get('source_sha256') == hashes.get(path), 'setup source hash disagrees with plan')
                if purpose == 'service':
                    check(service is not None, 'missing service plan before launch')
                    check(row.get('mode') == 'ci_remap_server' and row.get('timeout_ms') == 5000, 'invalid service launch contract')
                    if service and run:
                        argv = row['argv']
                        check(len(argv) == 7 and argv[1:4] == ['run', '--silent', 'ci-remap-server'] and argv[4:] == [argv[0], run['corpus_root'], service['commit']], 'invalid service argv')
                        check(row.get('cwd') == run['corpus_root'] and row.get('source_sha256') == service['source_sha256'], 'invalid service launch source or cwd')
                if purpose == 'vendor_setup':
                    check(vendor_setup is not None, 'missing vendor preparation plan before launch')
                    if vendor_setup and run and identity in selected:
                        name, vendor, cwd = selected[identity]['path'], vendor_setup['vendor'], vendor_setup['vendor_cwd']
                        check(row.get('timeout_ms') == (60000 if name == 'build' else 180000), 'invalid vendor preparation deadline')
                        expected = {'clone': ['clone', '--depth', '1', '--single-branch', vendor['repository'], cwd],
                                    'fetch': ['fetch', '--depth', '1', 'origin', 'tag', vendor['tag']],
                                    'checkout': ['checkout', vendor['tag']],
                                    'head': ['rev-parse', '--verify', '--end-of-options', 'HEAD'],
                                    'tag': ['rev-parse', '--verify', '--end-of-options', vendor['tag'] + '^{commit}'],
                                    'install': ['install'], 'build': ['run', 'build']}
                        check(name in expected and row['argv'][1:] == expected.get(name), 'invalid vendor preparation argv')
                        check(row.get('cwd') == (run['corpus_root'] if name == 'clone' else cwd), 'invalid vendor preparation cwd')
                        native = name in ('install', 'build')
                        check(row.get('mode') == ('vendor_' + name if native else name), 'invalid vendor preparation mode')
                        if native:
                            check(checkout is not None and row.get('source_sha256') == checkout.get('package_sha256'), 'native preparation before verified checkout')
                        else:
                            check(row.get('source_sha256') == vendor_setup.get('vendor_sha256'), 'vendor preparation source hash mismatch')
                started[identity] = row
            elif event in ('completed', 'service_completed'):
                check((event == 'service_completed') == (purpose == 'service'), 'wrong completion event for run purpose')
                identity = row['id']
                check(identity in started and identity == len(completed) and len(started) == len(completed) + 1, f'line {number}: invalid completion order')
                completed[identity] = row
                for kind in ('stdout', 'stderr'):
                    artifact(row, kind)
                check(row.get('source_unchanged') is True, f'{identity}: source changed during execution')
                if run and run.get('schema') == 2:
                    check(row.get('output_complete') is True, f'{identity}: captured streams did not reach verified EOF')
                for key in ('timed_out', 'expected_failure_verified'):
                    check(type(row.get(key)) is bool, f'{identity}: invalid {key} state')
                counts = row.get('counts', {})
                for key in COUNTS:
                    check(type(counts.get(key)) is int and counts[key] >= 0, f'{identity}: invalid {key} count')
                if not all(type(counts.get(key)) is int for key in COUNTS):
                    continue
                if purpose in ('setup', 'vendor_setup', 'service'):
                    check(all(counts.get(key) == 0 for key in COUNTS) and counts.get('observed') is False, 'preparation or service cannot claim test cases')
                    check(row.get('junit') == 'not_requested' and row.get('junit_file') is None and row.get('junit_sha256') is None and row.get('expected_failure_verified') is False, 'invalid preparation or service test reporting')
                if purpose == 'service':
                    check(readiness is not None and row.get('ready') == readiness.get('ready') and row.get('port') == readiness.get('port'), 'service completion disagrees with readiness')
                    for key in ('ready', 'invalid_readiness', 'unexpected_exit', 'stopped_by_owner', 'service_successful'):
                        check(type(row.get(key)) is bool, 'invalid service lifecycle flag: ' + key)
                    success = row.get('ready') is True and row.get('stopped_by_owner') is True and row.get('invalid_readiness') is False and row.get('unexpected_exit') is False and row.get('timed_out') is False and row.get('output_complete') is True and row.get('source_unchanged') is True and row.get('error_name') is None and isinstance(row.get('term'), dict) and bool(row['term'])
                    check(row.get('service_successful') is success, 'service lifecycle success mismatch')
                    if row.get('ready'):
                        path = artifact(row, 'stdout')
                        if path:
                            first = path.read_bytes().splitlines()[0].strip()
                            check(int(first) == row.get('port'), 'service stdout port mismatch')
                if row.get('junit') == 'retained':
                    path = artifact(row, 'junit')
                    if path:
                        try:
                            xml = ET.parse(path).getroot()
                            check(xml.tag in ('testsuites', 'testsuite'), f'{identity}: unexpected XML root')
                            observed = dict.fromkeys(COUNTS, 0)
                            for case in xml.iter('testcase'):
                                skipped = case.find('skipped')
                                failed = case.find('failure') is not None or case.find('error') is not None
                                check(not (failed and skipped is not None), f'{identity}: case has failure and skip')
                                status = 'failed' if failed else ('todo' if skipped.get('message') == 'TODO' else 'skipped') if skipped is not None else 'passed'
                                observed[status] += 1
                                cases.append({'file_id': identity, 'name': case.get('name'), 'classname': case.get('classname'), 'status': status})
                            check(observed == {key: counts[key] for key in COUNTS}, f'{identity}: JUnit cases disagree with process counters: {observed} != {counts}')
                        except (ET.ParseError, OSError) as error:
                            errors.append(f'{identity}: invalid JUnit: {error}')
                elif row.get('junit') == 'missing':
                    check(sum(counts[key] for key in COUNTS) == 0, f'{identity}: missing JUnit for registered cases')
                else:
                    check(row.get('junit') == 'not_requested', f'{identity}: unknown JUnit state')
                if not row.get('expected_failure_verified'):
                    for key in COUNTS:
                        totals[key] += counts[key]
            elif event == 'preparation_failed':
                errors.append(f"{row.get('id')}: preparation failed: {row.get('error_name')}")
            elif event == 'finished':
                finished = row
                for key, collection in [('selected', selected), ('started', started), ('completed', completed)]:
                    check(row.get(key) == len(collection), f'finished {key} count mismatch')
                check(row.get('all_selected_completed') is True and len(completed) == len(selected), 'not all selected files completed')
                summary = row.get('summary', {})
                for key in COUNTS:
                    check(summary.get(key) == totals[key], f'finished {key} does not match completed counters')
                check(summary.get('files') == len(completed), 'finished file count mismatch')
            else:
                errors.append(f'line {number}: unknown event {event}')
        except (ValueError, KeyError, TypeError, AttributeError, IndexError, OSError, UnicodeDecodeError) as error:
            errors.append(f'line {number}: malformed event: {error}')
    check(run is not None, 'missing run header')
    check(finished is not None, 'run did not finish')
    check(bool(selected), 'no files selected')
    if selection:
        try:
            indices = selection['selected_indices'][selection['range_start']:selection['range_end']]
            expected_paths = [selection['inventory'][index] for index in indices]
            check([row['path'] for row in selected.values()] == expected_paths, 'executed selection does not match recorded policy and range')
        except (KeyError, TypeError, IndexError) as error:
            errors.append(f'invalid execution selection: {error}')
    failures = []
    for identity, row in completed.items():
        term = row.get('term', {})
        expected = row.get('expected_failure_verified') is True
        if row.get('event') == 'service_completed':
            if row.get('service_successful') is not True:
                failures.append(identity)
            continue
        if row.get('timed_out') or (term != {'exited': 0} and not expected) or (isinstance(row.get('counts'), dict) and row['counts'].get('failed', 0) and not expected):
            failures.append(identity)
    summary = finished.get('summary', {}) if finished else {}
    if not isinstance(summary, dict):
        errors.append('malformed final summary')
        summary = {}
    if purpose == 'setup':
        check(setup is not None, 'missing setup plan')
        check([row.get('path') for row in selected.values()] == ['package.json', 'test/package.json'], 'setup selection must retain both original installs')
        check(summary.get('process_checks_passed') == 0, 'setup cannot claim passing process checks')
        check(summary.get('setup_steps_succeeded') == len(completed) - len(failures) and summary.get('setup_steps_failed') == len(failures) and summary.get('failed_files') == len(failures), 'setup outcome counters disagree')
        check(summary.get('inputs_unchanged') is True, 'setup inputs not verified unchanged')
    if purpose in ('service', 'vendor_setup'):
        check(summary.get('process_checks_passed') == 0, 'preparation or service cannot claim process checks')
        if purpose == 'service':
            check(service is not None and readiness is not None, 'missing service plan or readiness')
            check([row.get('path') for row in selected.values()] == ['ci-remap-server'], 'invalid service selection')
            check(summary.get('services_succeeded') == len(completed) - len(failures) and summary.get('services_failed') == len(failures), 'service outcome counters disagree')
            check(summary.get('temporary_storage_removed') is True, 'service temporary cleanup incomplete')
        else:
            check(vendor_setup is not None, 'missing vendor preparation plan')
            if vendor_setup:
                steps = vendor_setup.get('steps')
                valid_steps = isinstance(steps, list) and all(isinstance(row, dict) for row in steps)
                check(valid_steps and [row.get('path') for row in selected.values()] == [row.get('path') for row in steps], 'vendor preparation selection mismatch')
            check(summary.get('preparation_steps_succeeded') == len(completed) - len(failures) and summary.get('preparation_steps_failed') == len(failures), 'vendor preparation counters disagree')
            check(isinstance(summary.get('vendor_prepared'), bool), 'missing vendor prepared outcome')
            phase = vendor_setup.get('phase', 'all') if vendor_setup else 'all'
            check(summary.get('vendor_prepared') == (phase != 'checkout' and checkout is not None and len(completed) == len(selected) and not failures), 'vendor prepared outcome disagrees with preparation')
            if vendor_setup and 'phase' in vendor_setup:
                check(summary.get('preparation_phase') == phase, 'vendor phase summary disagrees with plan')
                check(summary.get('vendor_checked_out') is (checkout is not None), 'vendor checkout outcome disagrees with evidence')
            if checkout is not None:
                check(summary.get('vendor_revision') == checkout.get('revision'), 'vendor revision summary mismatch')
            if summary.get('vendor_prepared'):
                check(checkout is not None and summary.get('vendor_revision') == checkout.get('revision') and len(completed) == len(selected) and not failures, 'vendor prepared without complete verified checkout/install/build')
            for category in ('git', 'home'):
                identities = {(row['argv'][0], row['executable_sha256']) for row in started.values() if isinstance(row.get('argv'), list) and row['argv'] and isinstance(row['argv'][0], str) and isinstance(row.get('executable_sha256'), str) and (row.get('mode') in ('vendor_install', 'vendor_build')) == (category == 'home')}
                check(len(identities) <= 1, 'vendor preparation executable identity changed: ' + category)
        check(summary.get('failed_files') == len(failures), 'preparation or service failed-file count mismatch')
    successful = not errors and not failures and summary.get('failed_files') == 0 and summary.get('unsupported') == 0
    return {'directory': str(directory), 'successful': successful, 'selected': len(selected), 'started': len(started), 'completed': len(completed),
            'unstarted': [row for identity, row in selected.items() if identity not in started],
            'incomplete': [selected[identity] for identity in started if identity in selected and identity not in completed],
            'purpose': purpose, 'setup_plan': setup, 'service_plan': service, 'service_readiness': readiness, 'vendor_preparation_plan': vendor_setup, 'vendor_checkout': checkout, 'selection_policy': selection, 'counts': totals, 'capture_completeness': {state: sum(row.get('output_complete') is value for row in completed.values()) for state, value in [('complete', True), ('incomplete', False), ('unknown', None)]}, 'summary': summary, 'failed_file_ids': failures, 'cases': cases, 'errors': errors}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('directory', type=Path)
    args = parser.parse_args()
    result = summarize(args.directory)
    print(json.dumps(result, indent=2))
    return 0 if result['successful'] else 1


if __name__ == '__main__':
    sys.exit(main())
