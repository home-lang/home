from pathlib import Path
import gzip,hashlib,importlib.util,json,subprocess,tempfile
root=Path.cwd();folder=root/'docs/docs/bun-port-evidence/2026-09-20-ci-phases';m=json.loads((folder/'manifest.json').read_text());tracked=set(subprocess.check_output(['git','ls-files'],text=True).splitlines());spec=importlib.util.spec_from_file_location('validator',root/'scripts/summarize-bun-corpus.py');validator=importlib.util.module_from_spec(spec);spec.loader.exec_module(validator)
labels={'private-checkout':'phase-cli/checkout-reports/','private-changed':'phase-cli/changed-revision-reports/','private-install':'phase-cli/install-build-reports/','remap':'remap-regression/reports/','elysia-checkout':'elysia-phases/checkout-reports/','elysia-install':'elysia-phases/install-build-reports/','elysia-tests':'elysia-execution/reports/'}
with tempfile.TemporaryDirectory(prefix='home-ci-phase-restore-') as tmp:
 target=Path(tmp)
 for item in m['files']:
  path=folder/item['artifact'];assert str(path.relative_to(root)) in tracked;data=gzip.decompress(path.read_bytes());assert hashlib.sha256(data).hexdigest()==item['sha256'] and len(data)==item['bytes']
  for label,prefix in labels.items():
   prefix='zig-out/bun-ci-20260920/'+prefix
   if item['source'].startswith(prefix):
    name=item['source'][len(prefix):];assert Path(name).name==name;(target/label).mkdir(exist_ok=True);(target/label/name).write_bytes(data)
 results={label:validator.summarize(target/label) for label in labels}
 for label,r in results.items():
  assert r['successful']==(label!='private-changed'),(label,r)
  if label!='private-changed':assert not r['errors'],(label,r['errors'])
 assert results['elysia-tests']['counts']==dict(passed=1516,failed=0,skipped=0,todo=0) and results['elysia-tests']['completed']==129
 assert results['elysia-checkout']['summary']['vendor_prepared'] is False and results['elysia-install']['summary']['vendor_prepared'] is True
 assert [row['path'] for row in results['private-changed']['unstarted']]==['tag','install','build']
 print(json.dumps({'verified_artifacts':len(m['files']),'restored':{label:{'successful':r['successful'],'completed':r['completed'],'counts':r['counts'],'unstarted':r['unstarted'],'errors':r['errors']} for label,r in results.items()}},indent=2))
