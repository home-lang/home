import hashlib,json,os,subprocess,tempfile
from pathlib import Path
root=Path.cwd();ev=root/'zig-out/bun-ci-20260920';out=ev/'phase-cli';out.mkdir();home=root/'zig-out/bin/home'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert 'Build Summary: 23/23 steps succeeded' in (ev/'native-build-fixture-corrected.log').read_text()
m={'kind':'private phase CLI controls; zero original corpus case credit','home_sha256':sha(home),'runs':[]}
def save():(out/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
with tempfile.TemporaryDirectory(prefix='home-phase-cli-') as tmp:
 cwd=Path(tmp);source=cwd/'source';(source/'test').mkdir(parents=True);project=cwd/'packages/runtime/test';(project/'test').mkdir(parents=True)
 (source/'package.json').write_text(json.dumps({'name':'phase-fixture','scripts':{'postinstall':'bun hook.js install','build':'bun hook.js build'}}))
 (source/'hook.js').write_text("const fs=require('fs'),assert=require('assert');assert.equal(fs.realpathSync(Bun.which('node')),fs.realpathSync(process.execPath));fs.writeFileSync(process.argv[2]+'.marker',process.env.BUN_INSTALL_CACHE_DIR)")
 (source/'test/fixture.test.js').write_text("throw new Error('preparation must not execute tests')")
 with (out/'git.log').open('xb') as f:
  for args in [['init'],['add','.'],['-c','user.name=Home Test Fixture','-c','user.email=fixture@example.invalid','commit','-m','test: phase CLI fixture'],['tag','v1']]:subprocess.run(['git',*args],cwd=source,stdout=f,stderr=subprocess.STDOUT,check=True)
 revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip();(project/'test/vendor.json').write_text(json.dumps([{'package':'phase-fixture','repository':source.as_uri(),'tag':'v1'}]));vendor=project/'vendor/phase-fixture'
 for name,args in [('checkout',['--bun-corpus-checkout-vendor','phase-fixture']),('changed-revision',['--bun-corpus-install-vendor','phase-fixture','a'*40]),('install-build',['--bun-corpus-install-vendor','phase-fixture',revision])]:
  env=os.environ.copy();env.update(HOME_BUN_TEST_EXECUTABLE=str(home),HOME_BUN_CORPUS_REPORT_DIR=str(out/(name+'-reports')))
  with (out/(name+'.stdout')).open('xb') as f,(out/(name+'.stderr')).open('xb') as e:code=subprocess.run([str(home),'test',*args],cwd=cwd,env=env,stdin=subprocess.DEVNULL,stdout=f,stderr=e).returncode
  with (out/(name+'-summary.json')).open('xb') as f:valid=subprocess.run(['python3',str(root/'scripts/summarize-bun-corpus.py'),str(out/(name+'-reports'))],stdout=f).returncode
  summary=json.loads((out/(name+'-summary.json')).read_text());row={'name':name,'returncode':code,'validator_returncode':valid,'completed':summary.get('completed'),'counts':summary.get('counts'),'unstarted':summary.get('unstarted'),'errors':summary['errors']};m['runs'].append(row);save()
  assert summary['counts']==dict(passed=0,failed=0,skipped=0,todo=0)
  if name=='changed-revision':assert code!=0 and valid==1 and summary['completed']==1 and [r['path'] for r in summary['unstarted']]==['tag','install','build'] and 'VendorCheckoutRevisionChanged' in (out/(name+'.stderr')).read_text()
  else:assert code==valid==0 and not summary['errors'] and summary['completed']==(5 if name=='checkout' else 4) and summary['summary']['vendor_prepared']==(name=='install-build')
  if name!='install-build':assert not (vendor/'install.marker').exists() and not (vendor/'build.marker').exists()
 for operation in ['install','build']:assert not Path((vendor/(operation+'.marker')).read_text()).exists()
m['verified']=sha(home)==m['home_sha256'];save();print(json.dumps(m,indent=2))
