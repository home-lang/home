from pathlib import Path
import subprocess,json,hashlib
root=Path.cwd();ev=root/'zig-out/bun-ci-20260920';out=ev/'service-fixture-diagnostic';out.mkdir();fixture=out/'service-context.test.ts'
s=(root/'packages/home_test/src/corpus_remap.zig').read_text();block=s.split('.sub_path = "test/service-context.test.ts", .data =',1)[1].split('\n    });',1)[0]
data='\n'.join(line.split('\\\\',1)[1] for line in block.splitlines() if '\\\\' in line)+'\n';fixture.write_text(data)
manifest={'scope':'private new harness fixture diagnosis; zero original corpus-case credit','home_sha256':hashlib.sha256((root/'zig-out/bin/home').read_bytes()).hexdigest(),'fixture_source':data,'runs':[]}
for label,config in [('missing-config',out/'absent.toml'),('present-config',out/'bunfig.toml')]:
 if label=='present-config':config.write_text('[test]\n')
 argv=[str(root/'zig-out/bin/home'),'test','--config='+str(config),str(fixture)]
 with (out/(label+'.stdout')).open('xb') as stdout,(out/(label+'.stderr')).open('xb') as stderr:r=subprocess.run(argv,cwd=out,stdout=stdout,stderr=stderr)
 manifest['runs'].append({'label':label,'argv':argv,'returncode':r.returncode})
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(manifest,indent=2))
