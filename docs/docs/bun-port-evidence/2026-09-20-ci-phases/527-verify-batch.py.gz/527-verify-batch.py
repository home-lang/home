from pathlib import Path
import subprocess,json
root=Path.cwd();ev=root/'zig-out/bun-ci-20260920';rows=[]
assert 'Build Summary: 23/23 steps succeeded' in (ev/'native-build-fixture-corrected.log').read_text()
for name in ['verify-phase-cli.py','verify-remap-regression.py','verify-elysia-phases.py','verify-elysia-execution.py']:
 with (ev/(name+'.log')).open('xb') as stream:code=subprocess.run(['python3',str(ev/name)],cwd=root,stdout=stream,stderr=subprocess.STDOUT).returncode
 rows.append({'script':name,'returncode':code});(ev/'batch.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,code,flush=True)
 if code:raise SystemExit(code)
