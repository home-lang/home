# Remaining production CI coordinator integration

The current batch adds native vendor checkout/install phases and explicit child service settings. It does not yet claim the default CI coordinator is implemented.

1. Extract primary selection from `runGateWithOptions` into an owned preparation result. Docker startup needs the original selected path list before root/test installs; execution afterward must reuse that same selection and retain its complete inventory/exclusion journal, rather than silently rediscover or switch to a plain file list.
2. Check native expected-host settings before selection. Keep native CI/ASAN context and original expectation source bytes. Explicit diagnostic file/subset commands should keep their existing scope.
3. Start the applicable Linux CI Docker coordinator with the original selected tests, stdin-owned lifetime, 15-second readiness marker, and socket environment. Publish `BUN_DOCKER_COORDINATOR` only after readiness. Verify real Docker behavior on Linux separately from private marker/lifetime tests.
4. Sort and shard vendors with the pinned runner's semantics, run the new checkout phase, then discover/filter their files before root/test installation. Initialize native JSC before vendor regex filters. Carry each verified checkout revision across the primary phase.
5. Attempt both root/test installs. Failed installation prevents primary/remap execution, while the later selected vendor phase remains applicable. A missing optional dependency remains a feature gap even when its original install process exits zero.
6. Start remap only for its original applicable CI host after the installation process gate. Carry its live port through `RunOptions.services` and vendor `Options.services`; preserve lifetime and crash trace handling. Never mutate ambient environment to switch contexts.
7. For each selected nonempty vendor, call `install_build` with the recorded checkout revision, then execute exactly its recorded selected files. Preserve the different original install/build failure behavior and every unstarted operation.
8. Add a durable top-level phase journal linking setup, service, primary and vendor journals. An interrupted or failed phase cannot become successful overall. Full applicable primary execution must follow; repeated Elysia regressions are not additional unique feature coverage.

Additional pinned control-flow boundaries rechecked while the phase batch compiled:
- `runTests` lines 676-682 condition both primary installs on `!isQuiet`; any quiet mode must preserve that explicit upstream policy and record skipped preparation rather than claim it executed.
- Docker readiness failure intentionally falls back to each test's original direct compose behavior; remap startup failure likewise does not suppress original tests. Record optional-service failure/fallback distinctly from a passing service, without inventing success or modifying the original tests.
- Original vendor install failure skips that vendor, but vendor build failure aborts with an exception. Do not flatten both into the same continuation policy.
- Serial `startGroup` invokes the vendor callback without an index; parallel `runTest` passes its incremented full-run index. Existing capture already distinguishes absent `vendor_serial_id` from a supplied value. Keep that distinction when adding orchestration.
- The default run is serial unless the original parallel option is enabled. Full parallel coordination/IPC is separately tracked; do not use concurrent setup/build tasks as proof of test-worker implementation.
