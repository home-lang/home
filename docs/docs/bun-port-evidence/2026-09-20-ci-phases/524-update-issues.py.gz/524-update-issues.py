from pathlib import Path
import json,subprocess
root=Path.cwd();ev=root/'zig-out/bun-ci-20260920';checkpoint=(ev/'issue-checkpoint.md').read_text();head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();remote=subprocess.check_output(['git','ls-remote','origin','refs/heads/main'],text=True).split()[0];assert head==remote
assert not subprocess.check_output(['git','status','--porcelain'],text=True)
checkpoint=checkpoint.replace('## Current publication / remaining work (2026-09-20)','## Current publication / remaining work (2026-09-20)',1)
checkpoint+=f'Publication commit: [{head[:9]}](https://github.com/home-lang/home/commit/{head}).\n\n'
for number in [66,724]:
 before=json.loads(subprocess.check_output(['gh','issue','view',str(number),'--repo','home-lang/home','--json','body,title,updatedAt,state'],text=True));(ev/f'issue{number}-before-publication.json').write_text(json.dumps(before,indent=2)+'\n');assert before['state']=='OPEN';body=before['body'];assert 'Current publication / remaining work (2026-09-20)' not in body
 body=body.replace('## Current publication / remaining work (2026-09-08)','## Previous publication / remaining work (2026-09-08)',1)
 prefix,rest=body.split('\n\n',1);updated=prefix+'\n\n'+checkpoint+rest;path=ev/f'issue{number}-updated.md';path.write_text(updated)
 subprocess.run(['gh','issue','edit',str(number),'--repo','home-lang/home','--body-file',str(path)],check=True)
 after=json.loads(subprocess.check_output(['gh','issue','view',str(number),'--repo','home-lang/home','--json','body,title,updatedAt,state'],text=True));(ev/f'issue{number}-after-publication.json').write_text(json.dumps(after,indent=2)+'\n');assert after['body']==updated and after['state']=='OPEN';print(number,'updated and read back',after['updatedAt'],flush=True)
