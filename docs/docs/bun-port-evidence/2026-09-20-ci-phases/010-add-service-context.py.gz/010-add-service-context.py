from pathlib import Path
p=Path('packages/home_test/src/corpus_launch.zig');s=p.read_text();at=s.index('pub fn applyEnvironment(')
s=s[:at]+'''/// Borrowed settings from services owned by the calling coordinator. Publishing
/// a Docker socket requires readiness; this value does not start a service.
pub const Services = struct {
    remap_port: ?u16 = null,
    docker_socket: ?[]const u8 = null,

    pub fn apply(self: Services, allocator: std.mem.Allocator, env: *std.process.Environ.Map) !void {
        if (self.remap_port) |port| {
            if (port == 0) return error.InvalidRemapPort;
            const url = try std.fmt.allocPrint(allocator, "http://localhost:{d}", .{port});
            defer allocator.free(url);
            // Preserve an explicitly inherited reporting setting, as the pinned
            // runner does. Only the no-remap path forces reporting off.
            try env.put("BUN_CRASH_REPORT_URL", url);
        } else try env.put("BUN_ENABLE_CRASH_REPORTING", "0");
        if (self.docker_socket) |socket| {
            if (socket.len == 0) return error.InvalidDockerSocket;
            try env.put("BUN_DOCKER_COORDINATOR", socket);
        }
    }
};

'''+s[at:]
old='''    inline for (.{ "TMPDIR", "BUN_TMPDIR", "TEST_TMPDIR", "BUN_INSTALL_CACHE_DIR" }) |key| try env.put(key, temp_path);'''
at=s.index(old)
s=s[:at]+'''    return applyEnvironmentWithServices(allocator, env, selected, temp_path, bin_path, .{});
}

pub fn applyEnvironmentWithServices(
    allocator: std.mem.Allocator,
    env: *std.process.Environ.Map,
    selected: Profile,
    temp_path: []const u8,
    bin_path: []const u8,
    services: Services,
) !void {
'''+s[at:]
s=s.replace('    try env.put("BUN_ENABLE_CRASH_REPORTING", "0");\n    try env.put("FORCE_COLOR"','    try services.apply(allocator, env);\n    try env.put("FORCE_COLOR"')
s+='''
test "service context preserves the pinned remap and coordinator environment contract" {
    const allocator = std.testing.allocator;
    var env = std.process.Environ.Map.init(allocator);
    defer env.deinit();
    const selected = SetupOperation.install.profile();
    try applyEnvironmentWithServices(allocator, &env, selected, "/tmp/owned", "/tmp/bin", .{ .remap_port = 12345, .docker_socket = "/tmp/ready.sock" });
    try std.testing.expectEqualStrings("http://localhost:12345", env.get("BUN_CRASH_REPORT_URL").?);
    try std.testing.expect(env.get("BUN_ENABLE_CRASH_REPORTING") == null);
    try std.testing.expectEqualStrings("/tmp/ready.sock", env.get("BUN_DOCKER_COORDINATOR").?);
    try env.put("BUN_ENABLE_CRASH_REPORTING", "0");
    try applyEnvironmentWithServices(allocator, &env, selected, "/tmp/owned", "/tmp/bin", .{ .remap_port = 23456 });
    try std.testing.expectEqualStrings("0", env.get("BUN_ENABLE_CRASH_REPORTING").?);
    try std.testing.expectEqualStrings("http://localhost:23456", env.get("BUN_CRASH_REPORT_URL").?);
    try applyEnvironment(allocator, &env, selected, "/tmp/owned", "/tmp/bin");
    try std.testing.expectEqualStrings("0", env.get("BUN_ENABLE_CRASH_REPORTING").?);
    try std.testing.expectEqualStrings("/tmp/ready.sock", env.get("BUN_DOCKER_COORDINATOR").?);
    try std.testing.expectError(error.InvalidRemapPort, (Services{ .remap_port = 0 }).apply(allocator, &env));
    try std.testing.expectError(error.InvalidDockerSocket, (Services{ .docker_socket = "" }).apply(allocator, &env));
}
''';p.write_text(s)
p=Path('packages/home_test/src/adapters/jsc_bootstrap.zig');s=p.read_text().replace('    setup_operation: ?corpus_launch.SetupOperation = null,','    setup_operation: ?corpus_launch.SetupOperation = null,\n    services: corpus_launch.Services = .{},').replace('try corpus_launch.applyEnvironment(allocator, &environ_map, value, storage.temp_path, runtime_path);','try corpus_launch.applyEnvironmentWithServices(allocator, &environ_map, value, storage.temp_path, runtime_path, options.services);');p.write_text(s)
p=Path('packages/home_test/src/corpus_runner.zig');s=p.read_text().replace('    selection: ?SelectionPolicy = null,','    selection: ?SelectionPolicy = null,\n    services: @import("corpus_launch.zig").Services = .{},').replace('    launch_asan_step: bool = false,','    launch_asan_step: bool = false,\n    launch_services: @import("corpus_launch.zig").Services = .{},').replace('var summary = Summary{ .on_file = options.on_file,','var summary = Summary{ .on_file = options.on_file, .launch_services = options.services,').replace('            .corpus_file = .{ .relative_path = relative,','            .services = summary.launch_services,\n            .corpus_file = .{ .relative_path = relative,');p.write_text(s)
p=Path('packages/home_test/src/corpus_setup.zig');s=p.read_text().replace('    report_directory: ?[]const u8 = null,','    report_directory: ?[]const u8 = null,\n    services: @import("corpus_launch.zig").Services = .{},',1).replace('.setup_operation = .install,', '.setup_operation = .install, .services = options.services,',1);p.write_text(s)
p=Path('packages/home_test/src/corpus_journal.zig');s=p.read_text().replace('            BUN_DEBUG_QUIET_LOGS: ?[]const u8,','            BUN_DEBUG_QUIET_LOGS: ?[]const u8,\n            BUN_CRASH_REPORT_URL: ?[]const u8,\n            BUN_ENABLE_CRASH_REPORTING: ?[]const u8,\n            BUN_DOCKER_COORDINATOR: ?[]const u8,');p.write_text(s)
