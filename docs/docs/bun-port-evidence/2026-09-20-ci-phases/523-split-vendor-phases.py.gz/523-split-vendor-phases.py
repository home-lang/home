from pathlib import Path
p=Path('packages/home_test/src/corpus_vendor_prepare.zig');s=p.read_text();at=s.index('pub const Summary = struct')
s=s[:at]+'''pub const Phase = enum { all, checkout, install_build };
pub const Options = struct {
    phase: Phase = .all,
    /// The coordinator carries this revision from checkout/discovery across
    /// primary setup. Installation must not silently consume another checkout.
    expected_revision: ?[]const u8 = null,
    services: launch.Services = .{},
    report_directory: ?[]const u8 = null,
};

'''+s[at:];s=s.replace('    completed: usize = 0,','    completed: usize = 0,\n    phase: Phase = .all,',1)
s=s.replace('.vendor_prepared = summary.successful()', '.preparation_phase = @tagName(summary.phase), .vendor_checked_out = summary.revision != null, .vendor_prepared = summary.phase != .checkout and summary.successful()')
old='''    if (!build_options.enable_jsc) return error.NativeRuntimeRequired;''';at=s.index(old)
s=s[:at]+'''    return prepareWithOptions(allocator, io, project_root, vendor, .{ .report_directory = report_directory });
}

pub fn prepareWithOptions(allocator: Allocator, io: Io, project_root: []const u8, vendor: vendor_module.Vendor, options: Options) !Summary {
'''+s[at:]
s=s.replace('    const root = try Io.Dir.cwd().realPathFileAlloc', '''    if (options.phase == .install_build and options.expected_revision == null) return error.VendorCheckoutRevisionRequired;
    if (options.expected_revision) |revision| {
        if (revision.len != 40) return error.InvalidVendorRevision;
        for (revision) |c| if (!std.ascii.isHex(c) or std.ascii.isUpper(c)) return error.InvalidVendorRevision;
    }
    const root = try Io.Dir.cwd().realPathFileAlloc''',1)
s=s.replace('    var env = try capture.inheritedEnvironmentMap', '    if (options.phase == .install_build and !present) return error.VendorCheckoutMissing;\n    var env = try capture.inheritedEnvironmentMap',1)
s=s.replace('const report = report_directory orelse', 'const report = options.report_directory orelse',1)
s=s.replace('var summary = Summary{ .allocator = allocator,', 'var summary = Summary{ .allocator = allocator, .phase = options.phase,',1)
s=s.replace('const steps = all_steps[@as(usize, if (present) 1 else 0)..];', '''const steps = switch (options.phase) {
        .all => all_steps[@as(usize, if (present) 1 else 0)..],
        .checkout => all_steps[@as(usize, if (present) 1 else 0)..5],
        .install_build => all_steps[3..],
    };''')
s=s.replace('.clone_required = !present,', '.phase = @tagName(options.phase), .expected_revision = options.expected_revision, .clone_required = !present,',1)
s=s.replace('.setup_operation = if (step == .install) .install else .build,', '.setup_operation = if (step == .install) .install else .build, .services = options.services,',1)
s=s.replace('if (step == .head) summary.revision = try allocator.dupe(u8, revision) else {', '''if (step == .head) {
                if (options.expected_revision) |expected| if (!std.mem.eql(u8, expected, revision)) return error.VendorCheckoutRevisionChanged;
                summary.revision = try allocator.dupe(u8, revision);
            } else {''')
# Extend the native private repository control to exercise ordered phase APIs.
at=s.rindex('\n}')
s=s[:at]+'''
    const phased_project = try std.fs.path.join(allocator, &.{ root, "phased-project" });
    defer allocator.free(phased_project);
    try Io.Dir.cwd().createDirPath(io, phased_project);
    const checkout_report = try std.fs.path.join(allocator, &.{ root, "checkout-reports" });
    defer allocator.free(checkout_report);
    const install_report = try std.fs.path.join(allocator, &.{ root, "install-reports" });
    defer allocator.free(install_report);
    const vendor = vendor_module.Vendor{ .package = "private-vendor", .repository = repository, .tag = "v1" };
    var checked = try prepareWithOptions(allocator, io, phased_project, vendor, .{ .phase = .checkout, .report_directory = checkout_report });
    defer checked.deinit();
    try std.testing.expect(checked.successful());
    try std.testing.expectEqual(@as(usize, 5), checked.completed);
    const installed_marker = try std.fs.path.join(allocator, &.{ phased_project, "vendor/private-vendor/install.marker" });
    defer allocator.free(installed_marker);
    try std.testing.expectError(error.FileNotFound, Io.Dir.cwd().access(io, installed_marker, .{}));
    var installed = try prepareWithOptions(allocator, io, phased_project, vendor, .{ .phase = .install_build, .expected_revision = checked.revision.?, .report_directory = install_report });
    defer installed.deinit();
    try std.testing.expectEqual(@as(usize, 4), installed.completed);
    try std.testing.expectEqual(@as(usize, 1), installed.failed);
    try std.testing.expect(!installed.successful());
    try std.testing.expectEqualStrings(checked.revision.?, installed.revision.?);
    try Io.Dir.cwd().access(io, installed_marker, .{});
    const changed_report = try std.fs.path.join(allocator, &.{ root, "changed-reports" });
    defer allocator.free(changed_report);
    try std.testing.expectError(error.VendorCheckoutRevisionChanged, prepareWithOptions(allocator, io, phased_project, vendor, .{ .phase = .install_build, .expected_revision = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", .report_directory = changed_report }));
'''+s[at:];p.write_text(s)
