set -eu
cd zig-out/toolchains
curl --fail --location --max-time 180 -o zig-aarch64-macos-0.17.0-dev.2163+89ff10d56.tar.xz https://ziglang.org/builds/zig-aarch64-macos-0.17.0-dev.2163+89ff10d56.tar.xz
curl --fail --location --max-time 30 -o zig-aarch64-macos-0.17.0-dev.2163+89ff10d56.tar.xz.minisig https://ziglang.org/builds/zig-aarch64-macos-0.17.0-dev.2163+89ff10d56.tar.xz.minisig
shasum -a 256 zig-aarch64-macos-0.17.0-dev.2163+89ff10d56.tar.xz
tar -xf zig-aarch64-macos-0.17.0-dev.2163+89ff10d56.tar.xz
./zig-aarch64-macos-0.17.0-dev.2163+89ff10d56/zig version
