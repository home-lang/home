import hashlib,json,os,subprocess,time,shutil
from pathlib import Path
root=Path.cwd();ev=root/'zig-out/bun-ci-20260920';old=root/'zig-out/bun-port-recovery';out=ev/'elysia-phases';out.mkdir();home=root/'zig-out/bin/home';vendor=root/'packages/runtime/test/vendor/elysia';pin='56310be9617b826f862c985eae95ae823d95f097'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert 'Build Summary: 23/23 steps succeeded' in (ev/'native-build-fixture-corrected.log').read_text()
protected=json.loads((old/'native-vendor-preparation-first/manifest.json').read_text())['post_setup_sources'];original=json.loads((old/'elysia-native-setup-initialized/manifest.json').read_text())['original_sources']
assert all(sha(vendor/p)==h for p,h in protected.items());assert subprocess.check_output(['git','-C',str(vendor),'rev-parse','HEAD'],text=True).strip()==pin;assert subprocess.check_output(['git','-C',str(vendor),'status','--porcelain','--untracked-files=all'],text=True)==' M bun.lock\n';assert not subprocess.check_output(['git','ls-files','--',str(vendor)])
m={'scope':'fresh explicit checkout and later install/build; not full CI phase ordering or corpus-case credit','home_sha256':sha(home),'vendor_revision':pin,'original_sources':original,'protected_post_install_sources':protected,'attempts_each_phase':1,'removed_generated_bytes':sum(p.stat().st_size for p in vendor.rglob('*') if p.is_file() and not p.is_symlink()),'runs':[]}
def save():(out/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
save();shutil.rmtree(vendor)
for name,args in [('checkout',['--bun-corpus-checkout-vendor','elysia']),('install-build',['--bun-corpus-install-vendor','elysia',pin])]:
 env=os.environ.copy();env.update(HOME_BUN_TEST_EXECUTABLE=str(home),HOME_BUN_CORPUS_REPORT_DIR=str(out/(name+'-reports')));start=time.monotonic()
 with (out/(name+'.stdout')).open('xb') as f,(out/(name+'.stderr')).open('xb') as e:code=subprocess.run([str(home),'test',*args],cwd=root,env=env,stdin=subprocess.DEVNULL,stdout=f,stderr=e).returncode
 with (out/(name+'-summary.json')).open('xb') as f:valid=subprocess.run(['python3','scripts/summarize-bun-corpus.py',str(out/(name+'-reports'))],stdout=f).returncode
 summary=json.loads((out/(name+'-summary.json')).read_text());expected=original if name=='checkout' else protected;row={'phase':name,'returncode':code,'validator_returncode':valid,'seconds':time.monotonic()-start,'sources_match':all((vendor/p).is_file() and sha(vendor/p)==h for p,h in expected.items()),'completed':summary.get('completed'),'node_modules_present':(vendor/'node_modules').exists(),'counts':summary.get('counts')};m['runs'].append(row);save()
 assert code==valid==0 and row['sources_match'] and row['completed']==(5 if name=='checkout' else 4) and row['node_modules_present']==(name=='install-build') and row['counts']==dict(passed=0,failed=0,skipped=0,todo=0)
m['verified']=sha(home)==m['home_sha256'];save();print(json.dumps({k:v for k,v in m.items() if k not in ['original_sources','protected_post_install_sources']},indent=2))
