set -eu
python3 scripts/sync-bun-test-setup.py --check
python3 scripts/test_summarize_bun_corpus.py
zig-out/toolchains/zig-aarch64-macos-0.17.0-dev.2163+89ff10d56/zig fmt --check src/main.zig packages/home_test/src/corpus_launch.zig packages/home_test/src/corpus_vendor_prepare.zig packages/home_test/src/corpus_remap.zig packages/home_test/src/corpus_runner.zig packages/home_test/src/corpus_setup.zig packages/home_test/src/corpus_journal.zig packages/home_test/src/adapters/jsc_bootstrap.zig
/Users/chris/.local/share/pantry/global/bin/bunx --bun pickier docs/docs/bun-corpus-selection.md docs/docs/bun-corpus-outcomes.md scripts/summarize-bun-corpus.py scripts/test_summarize_bun_corpus.py src/main.zig packages/home_test/src/corpus_launch.zig packages/home_test/src/corpus_vendor_prepare.zig packages/home_test/src/corpus_remap.zig packages/home_test/src/corpus_runner.zig packages/home_test/src/corpus_setup.zig packages/home_test/src/corpus_journal.zig packages/home_test/src/adapters/jsc_bootstrap.zig
git diff --check
