import vm from 'node:vm'
const rows=[]
for(const bad of ['name','origin','codeGeneration','microtaskMode','importModuleDynamically']){
 const reads=[];const marker=new Error('getter marker');const options={};const keys=['name','origin','codeGeneration','microtaskMode','importModuleDynamically'];const defaults={name:'realm',origin:'origin',codeGeneration:{},microtaskMode:undefined,importModuleDynamically:undefined};
 for(const key of keys)Object.defineProperty(options,key,{get(){reads.push(key);if(key===bad)return 17;return defaults[key]}})
 try{vm.createContext({},options);rows.push({bad,reads,created:true})}catch(e){rows.push({bad,reads,error:e.name,code:e.code})}
}
{
 const reads=[];const marker=new Error('origin getter');try{vm.createContext({}, {get name(){reads.push('name');return 17},get origin(){reads.push('origin');throw marker}})}catch(e){rows.push({name:'origin precedence',reads,marker:e===marker,error:e.name,code:e.code})}
}
console.log(JSON.stringify(rows,null,2))
