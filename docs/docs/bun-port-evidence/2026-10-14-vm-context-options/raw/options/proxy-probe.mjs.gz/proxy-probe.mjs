import vm from 'node:vm'
const rows=[]
for(const kind of ['options','codeGeneration']){
 const log=[];const target={};const proxy=new Proxy(target,{get(t,k){log.push(['get',String(k)]);return Reflect.get(t,k)},has(t,k){log.push(['has',String(k)]);return Reflect.has(t,k)}})
 try{vm.createContext({},kind==='options'?proxy:{codeGeneration:proxy});rows.push({kind,log,created:true})}catch(e){rows.push({kind,log,error:e.name,code:e.code})}
}
for(const [label,value] of [['array',[]],['function',()=>{}],['proxy-array',new Proxy([], {})],['proxy-function',new Proxy(()=>{}, {})]])for(const kind of ['options','codeGeneration']){
 try{vm.createContext({},kind==='options'?value:{codeGeneration:value});rows.push({label,kind,created:true})}catch(e){rows.push({label,kind,error:e.name,code:e.code})}
}
console.log(JSON.stringify(rows,null,2))
