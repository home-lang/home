Tracked from #66 and #885, following the completed flag-default/getter-exception scope in #889.

Native Home currently reads `microtaskMode` before the other `createContext` options and reads it twice, while validating name/origin before later getters execute. Node snapshots `name`, `origin`, `codeGeneration`, `microtaskMode`, and `importModuleDynamically` once in that order, then validates the saved values. An invalid name consequently hides a throwing origin getter in Home.

The native parser also uses has-property lookups for option values, causing observable Proxy `has` operations, and accepts arrays/functions as context options or code-generation objects that Node rejects.

Acceptance: ordinary property reads in the correct order, one snapshot for context creation, Node validation precedence and getter exception identity, strict object-type validation including Proxy-wrapped arrays/functions, and preservation of GC reachability for earlier getter results during later getter calls. Script context options must preserve their own getContextOptions read/validation sequence.

The native parser and facade changes are implemented locally, with regression coverage for getter order, Proxy operations, invalid inputs and error precedence. Build and validation are in progress. The baseline 20-file unchanged context/proxy corpus passed; the separate Node/Home diagnostic comparisons establish the uncovered gaps. Baseline main: `ec4c453823b6d737a358d1c5e8899ff3f7bd20eb`; pinned Bun source: `4982b91e3702094330f3be3883354c52b8c01323`.
