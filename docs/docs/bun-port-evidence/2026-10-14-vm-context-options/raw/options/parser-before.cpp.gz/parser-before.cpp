std::optional<JSC::EncodedJSValue> getHomeNodeVMContextOptions(JSGlobalObject* globalObject, JSC::VM& vm, JSC::ThrowScope& scope, JSValue optionsArg, NodeVMContextOptions& outOptions, ASCIILiteral codeGenerationKey, JSValue* importer, WTF::String* name, WTF::String* origin)
{
    if (importer) {
        *importer = jsUndefined();
    }

    outOptions = {};
    if (name) *name = WTF::String();
    if (origin) *origin = WTF::String();

    // If options is provided, validate name and origin properties
    if (!optionsArg.isObject()) {
        return std::nullopt;
    }

    JSObject* options = asObject(optionsArg);

    const bool scriptContextOptions = codeGenerationKey == "contextCodeGeneration"_s;
    const ASCIILiteral nameKey = scriptContextOptions ? "contextName"_s : "name"_s;
    const ASCIILiteral originKey = scriptContextOptions ? "contextOrigin"_s : "origin"_s;
    auto nameValue = options->getIfPropertyExists(globalObject, Identifier::fromString(vm, nameKey));
    RETURN_IF_EXCEPTION(scope, encodedJSUndefined());
    if (nameValue) {
        if (!nameValue.isUndefined() && !nameValue.isString()) {
            return ERR::INVALID_ARG_TYPE(scope, globalObject, makeString("options."_s, nameKey), "string"_s, nameValue);
        }
    }

    if (name && nameValue && nameValue.isString()) *name = nameValue.toWTFString(globalObject);
    RETURN_IF_EXCEPTION(scope, encodedJSUndefined());

    // Check origin property
    auto originValue = options->getIfPropertyExists(globalObject, Identifier::fromString(vm, originKey));
    RETURN_IF_EXCEPTION(scope, encodedJSUndefined());
    if (originValue) {
        if (!originValue.isUndefined() && !originValue.isString()) {
            return ERR::INVALID_ARG_TYPE(scope, globalObject, makeString("options."_s, originKey), "string"_s, originValue);
        }
    }

    if (origin && originValue && originValue.isString()) *origin = originValue.toWTFString(globalObject);
    RETURN_IF_EXCEPTION(scope, encodedJSUndefined());

    // Script execution options use the Script's own callback; only context
    // creation owns an importModuleDynamically callback in these options.
    if (!scriptContextOptions) {
        JSValue callback = options->getIfPropertyExists(globalObject, Identifier::fromString(vm, "importModuleDynamically"_s));
        RETURN_IF_EXCEPTION(scope, encodedJSUndefined());
        if (callback && !callback.isUndefined()) {
            if (!callback.isCallable() && !isUseMainContextDefaultLoaderConstant(globalObject, callback))
                return ERR::INVALID_ARG_TYPE(scope, globalObject, "options.importModuleDynamically"_s, "function"_s, callback);
            if (importer) *importer = callback;
        }
    }

    // microtaskMode: "afterEvaluate" gives the context its own microtask
    // queue. Validated here (not only in vm.ts) so native entry points like
    // script.runInNewContext reject invalid values the way Node does.
    JSValue microtaskModeValue = options->getIfPropertyExists(globalObject, Identifier::fromString(vm, "microtaskMode"_s));
    RETURN_IF_EXCEPTION(scope, encodedJSUndefined());
    if (microtaskModeValue && !microtaskModeValue.isUndefined()) {
        bool isAfterEvaluate = false;
        if (microtaskModeValue.isString()) {
            String microtaskMode = microtaskModeValue.toWTFString(globalObject);
            RETURN_IF_EXCEPTION(scope, encodedJSUndefined());
            isAfterEvaluate = microtaskMode == "afterEvaluate"_s;
        }
        if (!isAfterEvaluate) {
            static constexpr ASCIILiteral oneOf[] = { "afterEvaluate"_s, "undefined"_s };
            return ERR::INVALID_ARG_VALUE(scope, globalObject, "options.microtaskMode"_s, "must be one of: "_s, microtaskModeValue, oneOf);
        }
        outOptions.ownMicrotaskQueue = true;
    }

    JSValue codeGenerationValue = options->getIfPropertyExists(globalObject, Identifier::fromString(vm, codeGenerationKey));
    RETURN_IF_EXCEPTION(scope, encodedJSUndefined());

    if (codeGenerationValue) {
        if (codeGenerationValue.isUndefined()) {
            return std::nullopt;
        }

        if (!codeGenerationValue.isObject()) {
            return ERR::INVALID_ARG_TYPE(scope, globalObject, WTF::makeString("options."_s, codeGenerationKey), "object"_s, codeGenerationValue);
        }

        JSObject* codeGenerationObject = asObject(codeGenerationValue);

        auto allowStringsValue = codeGenerationObject->getIfPropertyExists(globalObject, Identifier::fromString(vm, "strings"_s));
        RETURN_IF_EXCEPTION(scope, encodedJSUndefined());
        // Node reads both properties before validating their defaulted values.
        // Preserve getter exceptions even when the strings value is invalid.
        auto allowWasmValue = codeGenerationObject->getIfPropertyExists(globalObject, Identifier::fromString(vm, "wasm"_s));
        RETURN_IF_EXCEPTION(scope, encodedJSUndefined());
        if (allowStringsValue && !allowStringsValue.isUndefined()) {
            if (!allowStringsValue.isBoolean()) {
                return ERR::INVALID_ARG_TYPE(scope, globalObject, WTF::makeString("options."_s, codeGenerationKey, ".strings"_s), "boolean"_s, allowStringsValue);
            }

            outOptions.allowStrings = allowStringsValue.toBoolean(globalObject);
            RETURN_IF_EXCEPTION(scope, encodedJSUndefined());
        }

        if (allowWasmValue && !allowWasmValue.isUndefined()) {
            if (!allowWasmValue.isBoolean()) {
                return ERR::INVALID_ARG_TYPE(scope, globalObject, WTF::makeString("options."_s, codeGenerationKey, ".wasm"_s), "boolean"_s, allowWasmValue);
            }

            outOptions.allowWasm = allowWasmValue.toBoolean(globalObject);
            RETURN_IF_EXCEPTION(scope, encodedJSUndefined());
        }
    }

    return std::nullopt;
}

