from pathlib import Path
import subprocess,os,json,sys,re,time
p=Path(__file__).resolve().parent;root=p.parents[1];rows=[]
for i,name in enumerate(json.loads((p/'selection.json').read_text()),1):
 f=root/'packages/runtime/test/test'/name;report=p/f'report-{i}';env=os.environ.copy();env['HOME_BUN_CORPUS_REPORT_DIR']=str(report)
 flags=re.findall(r'^// Flags: (.*)',f.read_text(),re.M);args=[a for row in flags for a in row.split()]
 with (p/f'original-{i}.log').open('wb') as log:
  try:r=subprocess.run([str(root/'zig-out/bin/home'),'test',*args,str(f)],stdout=log,stderr=subprocess.STDOUT,env=env,cwd=root,timeout=240)
  except subprocess.TimeoutExpired:r=subprocess.CompletedProcess([],124)
 with (p/f'validate-{i}.json').open('wb') as log:v=subprocess.run([sys.executable,'scripts/summarize-bun-corpus.py',str(report)],stdout=log,stderr=subprocess.STDOUT,cwd=root)
 rows.append({'file':name,'exit':r.returncode,'validation_exit':v.returncode,'flags':args});(p/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,r.returncode,v.returncode,flush=True)

raise SystemExit(any(r["exit"] or r["validation_exit"] for r in rows))
