from pathlib import Path
import subprocess,os,json
root=Path.cwd();p=root/'zig-out/native-file-transfer-2026-10-14';env=os.environ.copy();env['PATH']='/Users/chris/.bun/bin:'+env['PATH'];rows=[]
commands=[('post-corpus',['python3',str(p/'post-corpus/run-originals.py')]),('ownership',['/Users/chris/.bun/bin/bun','test','build-support/bundle-native-modules.test.ts','-t','generates owned builtins|ProcessBindingFs|rejects native class identity|rejects error and native-wrapper ABI'])]
files=['build-support/bundle-native-modules.ts','packages/runtime/upstream/src/js/node/fs.promises.ts','packages/runtime/upstream/src/js/node/worker_threads.ts','packages/runtime/upstream/src/js/internal/fs/streams.ts','tests/runtime/native-filehandle-transfer.test.mjs']
commands.extend(('lint-'+str(i),['/Users/chris/.bun/bin/bunx','--bun','pickier',f]) for i,f in enumerate(files,1))
for name,args in commands:
 with (p/(name+'.log')).open('wb') as f:
  try:r=subprocess.run(args,env=env,cwd=root,stdout=f,stderr=subprocess.STDOUT,timeout=900 if name=='post-corpus' else 180)
  except subprocess.TimeoutExpired:r=subprocess.CompletedProcess([],124)
 rows.append({'name':name,'exit':r.returncode});print(name,r.returncode,flush=True)
(p/'regression-results.json').write_text(json.dumps(rows,indent=2)+'\n');raise SystemExit(any(x['exit'] for x in rows))
