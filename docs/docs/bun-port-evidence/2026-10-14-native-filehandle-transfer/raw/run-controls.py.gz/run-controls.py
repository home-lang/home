from pathlib import Path
import subprocess,os,json,hashlib
root=Path.cwd();p=root/'zig-out/native-file-transfer-2026-10-14';rows=[]
commands=[('node',['/Users/chris/.local/share/pantry/global/packages/nodejs.org/v26.10.0/bin/node','tests/runtime/native-filehandle-transfer.test.mjs']),('home',[str(root/'zig-out/bin/home'),'tests/runtime/native-filehandle-transfer.test.mjs']),('originals',['python3',str(p/'final-filehandles/run-originals.py')])]
(p/'executable.json').write_text(json.dumps({'sha256':hashlib.sha256((root/'zig-out/bin/home').read_bytes()).hexdigest()},indent=2)+'\n')
for name,args in commands:
 with (p/(name+'.log')).open('wb') as f:
  try:r=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT,env=os.environ.copy(),cwd=root,timeout=900 if name=='originals' else 120)
  except subprocess.TimeoutExpired:r=subprocess.CompletedProcess([],124)
 rows.append({'name':name,'exit':r.returncode});print(name,r.returncode,flush=True)
 if r.returncode:break
(p/'controls-results.json').write_text(json.dumps(rows,indent=2)+'\n');raise SystemExit(any(x['exit'] for x in rows))
