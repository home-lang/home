from pathlib import Path
import subprocess,json,sys
root=Path.cwd();task=root/"zig-out/stream-graph-port-2026-10-09"
commands=[('build-home', ['zig-out/toolchains/zig-aarch64-macos-0.17.0-dev.2163+89ff10d56/zig', 'build', 'home', '-Doptimize=Debug', '-Dstrip=true', '-Denable_jsc=true', '-j1', '--summary', 'all']), ('native-stream-wrap', ['env', 'HOME_NATIVE_VM=1', 'BUN_DEBUG_QUIET_LOGS=1', '/Users/chris/Code/Home/lang-bun-port/zig-out/bin/home', 'run', '/Users/chris/Code/Home/lang-bun-port/tests/runtime/native-stream-wrap.test.mjs']), ('native-stream-cancellation', ['env', 'HOME_NATIVE_VM=1', 'BUN_DEBUG_QUIET_LOGS=1', '/Users/chris/Code/Home/lang-bun-port/zig-out/bin/home', 'run', '/Users/chris/Code/Home/lang-bun-port/tests/runtime/native-stream-cancellation.test.mjs']), ('native-diagnostics-lifecycle', ['env', 'HOME_NATIVE_VM=1', 'BUN_DEBUG_QUIET_LOGS=1', '/Users/chris/Code/Home/lang-bun-port/zig-out/bin/home', 'run', '/Users/chris/Code/Home/lang-bun-port/tests/runtime/native-diagnostics-lifecycle.test.mjs']), ('native-node-core-cli', ['env', 'HOME_NATIVE_VM=1', 'BUN_DEBUG_QUIET_LOGS=1', '/Users/chris/Code/Home/lang-bun-port/zig-out/bin/home', 'run', '/Users/chris/Code/Home/lang-bun-port/tests/runtime/native-node-core-cli.test.mjs']), ('native-spawn-sync-ipc', ['env', 'HOME_NATIVE_VM=1', 'BUN_DEBUG_QUIET_LOGS=1', '/Users/chris/Code/Home/lang-bun-port/zig-out/bin/home', 'run', '/Users/chris/Code/Home/lang-bun-port/tests/runtime/native-spawn-sync-ipc.test.mjs']), ('corpus', ['python3', '/Users/chris/Code/Home/lang-bun-port/zig-out/stream-graph-port-2026-10-09/run-corpus.py', 'first'])]
rows=[]
for name,command in commands:
 with (task/(name+".log")).open("wb") as log:result=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT)
 rows.append({"label":name,"command":command,"exit":result.returncode});print(name,result.returncode,flush=True)
 if result.returncode:break
(task/"batch-summary.json").write_text(json.dumps(rows,indent=2)+"\n")
sys.exit(0 if len(rows)==len(commands) and all(row["exit"]==0 for row in rows) else 1)
