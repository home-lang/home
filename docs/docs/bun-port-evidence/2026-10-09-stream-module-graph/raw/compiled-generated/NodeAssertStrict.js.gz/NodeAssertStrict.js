(function () {"use strict";
// .zig-cache/o/6c9e424ecc4ea2ec41e2f64fc5f27e01/native-modules/NodeAssertStrict.mts
var $;
$ = (@getInternalField(@internalModuleRegistry, 103) || @createInternalModuleById(103)).strict;
return $

})
