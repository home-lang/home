var $;
// Hardcoded module "node:stream" / "readable-stream"
const exports = (__intrinsic__getInternalField(__intrinsic__internalModuleRegistry, 46) || __intrinsic__createInternalModuleById(46));

(IS_BUN_DEVELOPMENT?$debug_log("node:stream loaded"):void 0);

exports.eos = (__intrinsic__getInternalField(__intrinsic__internalModuleRegistry, 53) || __intrinsic__createInternalModuleById(53));

$ = exports;
;$$EXPORT$$($).$$EXPORT_END$$;
