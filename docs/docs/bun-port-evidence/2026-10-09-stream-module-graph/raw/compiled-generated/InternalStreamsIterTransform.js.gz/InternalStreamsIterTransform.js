(function () {"use strict";
// .zig-cache/o/6c9e424ecc4ea2ec41e2f64fc5f27e01/native-modules/InternalStreamsIterTransform.mts
var $, { Buffer } = @getInternalField(@internalModuleRegistry, 161) || @createInternalModuleById(161), { isArrayBufferView, isAnyArrayBuffer } = @getInternalField(@internalModuleRegistry, 164) || @createInternalModuleById(164), { kValidatedTransform } = @getInternalField(@internalModuleRegistry, 65) || @createInternalModuleById(65), { checkRangesOrGetDefault, validateFiniteNumber, validateObject } = @getInternalField(@internalModuleRegistry, 86) || @createInternalModuleById(86), NativeZlib = @lazy(19), NativeBrotli = @lazy(20), NativeZstd = @lazy(21), constants = process.binding("constants").zlib, Uint8ArraySlice = @Uint8Array.prototype.slice;
function genericNodeError(message, options) {
  let error = Error(message);
  return error.errno = options.errno, error.code = options.code, error;
}
var {
  DEFLATE,
  INFLATE,
  GZIP,
  GUNZIP,
  BROTLI_ENCODE,
  BROTLI_DECODE,
  ZSTD_COMPRESS,
  ZSTD_DECOMPRESS,
  Z_NO_FLUSH,
  Z_FINISH,
  Z_DEFAULT_WINDOWBITS,
  Z_DEFAULT_STRATEGY,
  BROTLI_OPERATION_PROCESS,
  BROTLI_OPERATION_FINISH,
  Z_MIN_CHUNK,
  Z_MIN_WINDOWBITS,
  Z_MAX_WINDOWBITS,
  Z_MIN_LEVEL,
  Z_MAX_LEVEL,
  Z_MIN_MEMLEVEL,
  Z_MAX_MEMLEVEL,
  Z_FIXED,
  ZSTD_e_continue,
  ZSTD_e_end
} = constants, DEFAULT_OUTPUT_SIZE = 65536, BATCH_HWM = DEFAULT_OUTPUT_SIZE, kEmpty = Buffer.alloc(0);
function validateChunkSize(options) {
  let chunkSize = options.chunkSize;
  if (!validateFiniteNumber(chunkSize, "options.chunkSize"))
    chunkSize = DEFAULT_OUTPUT_SIZE;
  else if (chunkSize < Z_MIN_CHUNK)
    throw @makeErrorWithCode(160, "options.chunkSize", `>= ${Z_MIN_CHUNK}`, chunkSize);
  return chunkSize;
}
function validateDictionary(dictionary) {
  if (dictionary === @undefined)
    return @undefined;
  if (isArrayBufferView(dictionary))
    return dictionary;
  if (isAnyArrayBuffer(dictionary))
    return Buffer.from(dictionary);
  throw @makeErrorWithCode(119, "options.dictionary", ["Buffer", "TypedArray", "DataView", "ArrayBuffer"], dictionary);
}
function validateParams(params, maxParam, makeError) {
  if (params === @undefined)
    return;
  if (typeof params !== "object" || params === null)
    throw @makeErrorWithCode(119, "options.params", "Object", params);
  let keys = Object.keys(params);
  for (let i = 0;i < keys.length; i++) {
    let origKey = keys[i], key = +origKey;
    if (Number.isNaN(key) || key < 0 || key > maxParam)
      throw makeError(origKey);
    let value = params[origKey];
    if (typeof value !== "number" && typeof value !== "boolean")
      throw @makeErrorWithCode(119, "options.params[key]", "number", value);
  }
}
var kMaxBrotliParam = Math.max(...Object.entries(constants).map(({ 0: key, 1: value }) => key.startsWith("BROTLI_PARAM_") ? value : 0)), brotliInitParamsArray = new Uint32Array(kMaxBrotliParam + 1), kMaxZstdCParam = Math.max(...Object.keys(constants).map((key) => key.startsWith("ZSTD_c_") ? constants[key] : 0)), zstdInitCParamsArray = new Uint32Array(kMaxZstdCParam + 1), kMaxZstdDParam = Math.max(...Object.keys(constants).map((key) => key.startsWith("ZSTD_d_") ? constants[key] : 0)), zstdInitDParamsArray = new Uint32Array(kMaxZstdDParam + 1);
function createZlibHandle(mode, options, processCallback, onError) {
  let chunkSize = validateChunkSize(options), windowBits = checkRangesOrGetDefault(options.windowBits, "options.windowBits", Z_MIN_WINDOWBITS, Z_MAX_WINDOWBITS, Z_DEFAULT_WINDOWBITS), level = checkRangesOrGetDefault(options.level, "options.level", Z_MIN_LEVEL, Z_MAX_LEVEL, 4), memLevel = checkRangesOrGetDefault(options.memLevel, "options.memLevel", Z_MIN_MEMLEVEL, Z_MAX_MEMLEVEL, 9), strategy = checkRangesOrGetDefault(options.strategy, "options.strategy", Z_DEFAULT_STRATEGY, Z_FIXED, Z_DEFAULT_STRATEGY), dictionary = validateDictionary(options.dictionary), handle = new NativeZlib(mode), writeState = new Uint32Array(2);
  return handle.onerror = onError, handle.init(windowBits, level, memLevel, strategy, writeState, processCallback, dictionary), { __proto__: null, handle, writeState, chunkSize };
}
function createBrotliHandle(mode, options, processCallback, onError) {
  let chunkSize = validateChunkSize(options);
  validateDictionary(options.dictionary), validateParams(options.params, kMaxBrotliParam, (key) => @makeErrorWithCode(10, key));
  let handle = new NativeBrotli(mode), writeState = new Uint32Array(2);
  if (brotliInitParamsArray.fill(-1), mode === BROTLI_ENCODE)
    brotliInitParamsArray[constants.BROTLI_PARAM_QUALITY] = 6, brotliInitParamsArray[constants.BROTLI_PARAM_LGWIN] = 20;
  let params = options.params;
  if (params) {
    let keys = Object.keys(params);
    for (let i = 0;i < keys.length; i++) {
      let key = +keys[i];
      brotliInitParamsArray[key] = params[keys[i]];
    }
  }
  if (handle.onerror = onError, !handle.init(brotliInitParamsArray, writeState, processCallback))
    throw @makeErrorWithCode(270);
  return { __proto__: null, handle, writeState, chunkSize };
}
function createZstdHandle(mode, options, processCallback, onError) {
  let isCompress = mode === ZSTD_COMPRESS, chunkSize = validateChunkSize(options);
  validateDictionary(options.dictionary);
  let maxParam = isCompress ? kMaxZstdCParam : kMaxZstdDParam;
  validateParams(options.params, maxParam, (key) => @makeErrorWithCode(263, key));
  let pledgedSrcSize = options.pledgedSrcSize;
  if (pledgedSrcSize !== @undefined) {
    if (typeof pledgedSrcSize !== "number" || Number.isNaN(pledgedSrcSize))
      throw @makeErrorWithCode(119, "options.pledgedSrcSize", "number", pledgedSrcSize);
    if (pledgedSrcSize < 0)
      throw @makeErrorWithCode(160, "options.pledgedSrcSize", ">= 0", pledgedSrcSize);
  }
  let handle = new NativeZstd(mode), writeState = new Uint32Array(2), initArray = isCompress ? zstdInitCParamsArray : zstdInitDParamsArray;
  initArray.fill(-1);
  let params = options.params;
  if (params) {
    let keys = Object.keys(params);
    for (let i = 0;i < keys.length; i++) {
      let key = +keys[i];
      initArray[key] = params[keys[i]];
    }
  }
  return handle.onerror = onError, handle.init(initArray, pledgedSrcSize, writeState, processCallback), { __proto__: null, handle, writeState, chunkSize };
}
function makeZlibTransform(createHandleFn, processFlag, finishFlag) {
  return {
    __proto__: null,
    [kValidatedTransform]: !0,
    transform: async function* (source, options) {
      let { signal } = options;
      signal?.throwIfAborted();
      let outBuf, outOffset = 0, chunkSize, pending = [], pendingBytes = 0, resolveWrite, rejectWrite, writeInput, writeFlush, writeInOff, writeAvailIn, writeAvailOutBefore;
      function onWriteComplete() {
        let availOut = writeState[0], availInAfter = writeState[1], have = writeAvailOutBefore - availOut, bufferExhausted = availOut === 0 || outOffset + have >= chunkSize;
        if (have > 0) {
          if (bufferExhausted && outOffset === 0)
            pending.push(outBuf);
          else if (bufferExhausted)
            pending.push(outBuf.subarray(outOffset, outOffset + have));
          else
            pending.push(Uint8ArraySlice.@call(outBuf, outOffset, outOffset + have));
          pendingBytes += have, outOffset += have;
        }
        if (bufferExhausted)
          outBuf = Buffer.allocUnsafe(chunkSize), outOffset = 0;
        if (availOut === 0) {
          if (!resolveWrite)
            return;
          let consumed = writeAvailIn - availInAfter;
          writeInOff += consumed, writeAvailIn = availInAfter, writeAvailOutBefore = chunkSize - outOffset, handle.write(writeFlush, writeInput, writeInOff, writeAvailIn, outBuf, outOffset, writeAvailOutBefore);
          return;
        }
        handle.buffer = null;
        let resolve = resolveWrite;
        if (resolveWrite = @undefined, rejectWrite = @undefined, resolve)
          resolve();
      }
      function onError(message, errno, code) {
        let error = genericNodeError(message, { __proto__: null, errno, code });
        error.errno = errno, error.code = code;
        let reject = rejectWrite;
        if (resolveWrite = @undefined, rejectWrite = @undefined, reject)
          reject(error);
      }
      let result = createHandleFn(onWriteComplete, onError), handle = result.handle, writeState = result.writeState;
      chunkSize = result.chunkSize, outBuf = Buffer.allocUnsafe(chunkSize);
      let onAbort = () => {
        let reject = rejectWrite;
        if (resolveWrite = @undefined, rejectWrite = @undefined, reject)
          reject(signal.reason ?? @makeAbortError());
      };
      signal.addEventListener("abort", onAbort, { __proto__: null, once: !0 });
      function processInputAsync(input, flushFlag) {
        let { promise, resolve, reject } = @Promise.withResolvers();
        return resolveWrite = resolve, rejectWrite = reject, writeInput = input, writeFlush = flushFlag, writeInOff = 0, writeAvailIn = input.byteLength, writeAvailOutBefore = chunkSize - outOffset, handle.buffer = input, handle.write(flushFlag, input, 0, writeAvailIn, outBuf, outOffset, writeAvailOutBefore), promise;
      }
      function drainBatch() {
        if (pendingBytes <= BATCH_HWM) {
          let batch2 = pending;
          return pending = [], pendingBytes = 0, batch2;
        }
        let batch = [], batchBytes = 0;
        while (pending.length > 0 && batchBytes < BATCH_HWM) {
          let buf = pending.shift();
          batch.push(buf);
          let len = buf.byteLength;
          batchBytes += len, pendingBytes -= len;
        }
        return batch;
      }
      let finalized = !1, iter = source[Symbol.asyncIterator]();
      try {
        let nextResult = iter.next();
        while (!0) {
          let { value: chunks, done } = await nextResult;
          if (done)
            break;
          if (signal?.throwIfAborted(), chunks === null) {
            if (!finalized) {
              finalized = !0, await processInputAsync(kEmpty, finishFlag);
              while (pending.length > 0)
                yield drainBatch();
            }
            nextResult = iter.next();
            continue;
          }
          nextResult = iter.next();
          for (let i = 0;i < chunks.length; i++)
            await processInputAsync(chunks[i], processFlag);
          if (pendingBytes >= BATCH_HWM)
            while (pending.length > 0 && pendingBytes >= BATCH_HWM)
              yield drainBatch();
          if (pending.length > 0)
            yield drainBatch();
        }
        if (!finalized && !signal.aborted) {
          finalized = !0, await processInputAsync(kEmpty, finishFlag);
          while (pending.length > 0)
            yield drainBatch();
        }
      } finally {
        signal.removeEventListener("abort", onAbort), handle.close();
        try {
          await iter.return?.();
        } catch {}
      }
    }
  };
}
function makeZlibTransformSync(createHandleFn, processFlag, finishFlag) {
  return {
    __proto__: null,
    transform: function* (source) {
      let error = null;
      function onError(message, errno, code) {
        error = genericNodeError(message, { __proto__: null, errno, code }), error.errno = errno, error.code = code;
      }
      let result = createHandleFn(() => {}, onError), handle = result.handle, writeState = result.writeState, chunkSize = result.chunkSize, outBuf = Buffer.allocUnsafe(chunkSize), outOffset = 0, pending = [], pendingBytes = 0;
      function processSyncInput(input, flushFlag) {
        let inOff = 0, availIn = input.byteLength, availOutBefore = chunkSize - outOffset;
        if (handle.writeSync(flushFlag, input, inOff, availIn, outBuf, outOffset, availOutBefore), error)
          throw error;
        while (!0) {
          let availOut = writeState[0], availInAfter = writeState[1], have = availOutBefore - availOut, bufferExhausted = availOut === 0 || outOffset + have >= chunkSize;
          if (have > 0) {
            if (bufferExhausted && outOffset === 0)
              pending.push(outBuf);
            else if (bufferExhausted)
              pending.push(outBuf.subarray(outOffset, outOffset + have));
            else
              pending.push(Uint8ArraySlice.@call(outBuf, outOffset, outOffset + have));
            pendingBytes += have, outOffset += have;
          }
          if (bufferExhausted)
            outBuf = Buffer.allocUnsafe(chunkSize), outOffset = 0;
          if (availOut === 0) {
            let consumed = availIn - availInAfter;
            if (inOff += consumed, availIn = availInAfter, availOutBefore = chunkSize - outOffset, handle.writeSync(flushFlag, input, inOff, availIn, outBuf, outOffset, availOutBefore), error)
              throw error;
            continue;
          }
          break;
        }
      }
      function drainBatch() {
        if (pendingBytes <= BATCH_HWM) {
          let batch2 = pending;
          return pending = [], pendingBytes = 0, batch2;
        }
        let batch = [], batchBytes = 0;
        while (pending.length > 0 && batchBytes < BATCH_HWM) {
          let buf = pending.shift(), len = buf.byteLength;
          batch.push(buf), batchBytes += len, pendingBytes -= len;
        }
        return batch;
      }
      try {
        for (let batch of source) {
          if (batch === null) {
            processSyncInput(Buffer.alloc(0), finishFlag);
            while (pending.length > 0)
              yield drainBatch();
            continue;
          }
          for (let i = 0;i < batch.length; i++)
            processSyncInput(batch[i], processFlag);
          if (pendingBytes >= BATCH_HWM)
            while (pending.length > 0 && pendingBytes >= BATCH_HWM)
              yield drainBatch();
          if (pending.length > 0)
            yield drainBatch();
        }
      } finally {
        handle.close();
      }
    }
  };
}
var kNullPrototype = { __proto__: null };
function compressGzip(options = kNullPrototype) {
  return validateObject(options, "options"), makeZlibTransform((cb, onErr) => createZlibHandle(GZIP, options, cb, onErr), Z_NO_FLUSH, Z_FINISH);
}
function compressDeflate(options = kNullPrototype) {
  return validateObject(options, "options"), makeZlibTransform((cb, onErr) => createZlibHandle(DEFLATE, options, cb, onErr), Z_NO_FLUSH, Z_FINISH);
}
function compressBrotli(options = kNullPrototype) {
  return validateObject(options, "options"), makeZlibTransform((cb, onErr) => createBrotliHandle(BROTLI_ENCODE, options, cb, onErr), BROTLI_OPERATION_PROCESS, BROTLI_OPERATION_FINISH);
}
function compressZstd(options = kNullPrototype) {
  return validateObject(options, "options"), makeZlibTransform((cb, onErr) => createZstdHandle(ZSTD_COMPRESS, options, cb, onErr), ZSTD_e_continue, ZSTD_e_end);
}
function decompressGzip(options = kNullPrototype) {
  return validateObject(options, "options"), makeZlibTransform((cb, onErr) => createZlibHandle(GUNZIP, options, cb, onErr), Z_NO_FLUSH, Z_FINISH);
}
function decompressDeflate(options = kNullPrototype) {
  return validateObject(options, "options"), makeZlibTransform((cb, onErr) => createZlibHandle(INFLATE, options, cb, onErr), Z_NO_FLUSH, Z_FINISH);
}
function decompressBrotli(options = kNullPrototype) {
  return validateObject(options, "options"), makeZlibTransform((cb, onErr) => createBrotliHandle(BROTLI_DECODE, options, cb, onErr), BROTLI_OPERATION_PROCESS, BROTLI_OPERATION_FINISH);
}
function decompressZstd(options = kNullPrototype) {
  return validateObject(options, "options"), makeZlibTransform((cb, onErr) => createZstdHandle(ZSTD_DECOMPRESS, options, cb, onErr), ZSTD_e_continue, ZSTD_e_end);
}
function compressGzipSync(options = kNullPrototype) {
  return validateObject(options, "options"), makeZlibTransformSync((cb, onErr) => createZlibHandle(GZIP, options, cb, onErr), Z_NO_FLUSH, Z_FINISH);
}
function compressDeflateSync(options = kNullPrototype) {
  return validateObject(options, "options"), makeZlibTransformSync((cb, onErr) => createZlibHandle(DEFLATE, options, cb, onErr), Z_NO_FLUSH, Z_FINISH);
}
function compressBrotliSync(options = kNullPrototype) {
  return validateObject(options, "options"), makeZlibTransformSync((cb, onErr) => createBrotliHandle(BROTLI_ENCODE, options, cb, onErr), BROTLI_OPERATION_PROCESS, BROTLI_OPERATION_FINISH);
}
function compressZstdSync(options = kNullPrototype) {
  return validateObject(options, "options"), makeZlibTransformSync((cb, onErr) => createZstdHandle(ZSTD_COMPRESS, options, cb, onErr), ZSTD_e_continue, ZSTD_e_end);
}
function decompressGzipSync(options = kNullPrototype) {
  return validateObject(options, "options"), makeZlibTransformSync((cb, onErr) => createZlibHandle(GUNZIP, options, cb, onErr), Z_NO_FLUSH, Z_FINISH);
}
function decompressDeflateSync(options = kNullPrototype) {
  return validateObject(options, "options"), makeZlibTransformSync((cb, onErr) => createZlibHandle(INFLATE, options, cb, onErr), Z_NO_FLUSH, Z_FINISH);
}
function decompressBrotliSync(options = kNullPrototype) {
  return validateObject(options, "options"), makeZlibTransformSync((cb, onErr) => createBrotliHandle(BROTLI_DECODE, options, cb, onErr), BROTLI_OPERATION_PROCESS, BROTLI_OPERATION_FINISH);
}
function decompressZstdSync(options = kNullPrototype) {
  return validateObject(options, "options"), makeZlibTransformSync((cb, onErr) => createZstdHandle(ZSTD_DECOMPRESS, options, cb, onErr), ZSTD_e_continue, ZSTD_e_end);
}
$ = {
  compressBrotli,
  compressBrotliSync,
  compressDeflate,
  compressDeflateSync,
  compressGzip,
  compressGzipSync,
  compressZstd,
  compressZstdSync,
  decompressBrotli,
  decompressBrotliSync,
  decompressDeflate,
  decompressDeflateSync,
  decompressGzip,
  decompressGzipSync,
  decompressZstd,
  decompressZstdSync
};
return $

})
