(function () {"use strict";
// .zig-cache/o/6c9e424ecc4ea2ec41e2f64fc5f27e01/native-modules/InternalStreamsIterTypes.mts
var $, toStreamable = Symbol.for("Stream.toStreamable"), toAsyncStreamable = Symbol.for("Stream.toAsyncStreamable"), broadcastProtocol = Symbol.for("Stream.broadcastProtocol"), shareProtocol = Symbol.for("Stream.shareProtocol"), shareSyncProtocol = Symbol.for("Stream.shareSyncProtocol"), drainableProtocol = Symbol.for("Stream.drainableProtocol"), kValidatedTransform = Symbol("kValidatedTransform"), kValidatedSource = Symbol("kValidatedSource"), kSyncWriteAccepted = Symbol("kSyncWriteAccepted"), kSyncWriteAcceptedOnFalse = Symbol("kSyncWriteAcceptedOnFalse");
$ = {
  broadcastProtocol,
  drainableProtocol,
  kSyncWriteAccepted,
  kSyncWriteAcceptedOnFalse,
  kValidatedSource,
  kValidatedTransform,
  shareProtocol,
  shareSyncProtocol,
  toAsyncStreamable,
  toStreamable
};
return $

})
