(function () {"use strict";
// .zig-cache/o/6c9e424ecc4ea2ec41e2f64fc5f27e01/native-modules/NodePathPosix.mts
var $;
$ = (@getInternalField(@internalModuleRegistry, 125) || @createInternalModuleById(125)).posix;
return $

})
