(function () {"use strict";
// .zig-cache/o/6c9e424ecc4ea2ec41e2f64fc5f27e01/native-modules/NodeDNSPromises.mts
var $;
$ = (@getInternalField(@internalModuleRegistry, 112) || @createInternalModuleById(112)).promises;
return $

})
