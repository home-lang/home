(function () {"use strict";
// .zig-cache/o/6c9e424ecc4ea2ec41e2f64fc5f27e01/native-modules/InternalAsyncHooksTick.mts
var $, tickInitHooks = [], nextAsyncId = 1;
$ = {
  tickInitHooks,
  newAsyncId() {
    return ++nextAsyncId;
  }
};
return $

})
