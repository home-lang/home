(function () {"use strict";
// .zig-cache/o/6c9e424ecc4ea2ec41e2f64fc5f27e01/native-modules/InternalStreamsAddAbortSignal.mts
var $, { isNodeStream, isWebStream, kControllerErrorFunction } = @getInternalField(@internalModuleRegistry, 76) || @createInternalModuleById(76), eos = @getInternalField(@internalModuleRegistry, 53) || @createInternalModuleById(53), SymbolDispose = Symbol.dispose, addAbortListener, validateAbortSignal = (signal, name) => {
  if (typeof signal !== "object" || !("aborted" in signal))
    throw @makeErrorWithCode(119, name, "AbortSignal", signal);
};
function addAbortSignal(signal, stream) {
  if (validateAbortSignal(signal, "signal"), !isNodeStream(stream) && !isWebStream(stream))
    throw @makeErrorWithCode(119, "stream", ["ReadableStream", "WritableStream", "Stream"], stream);
  return addAbortSignalNoValidate(signal, stream);
}
function addAbortSignalNoValidate(signal, stream) {
  if (typeof signal !== "object" || !("aborted" in signal))
    return stream;
  let onAbort = isNodeStream(stream) ? () => {
    stream.destroy(@makeAbortError(@undefined, { cause: signal.reason }));
  } : () => {
    stream[kControllerErrorFunction](@makeAbortError(@undefined, { cause: signal.reason }));
  };
  if (signal.aborted)
    onAbort();
  else {
    addAbortListener ??= (@getInternalField(@internalModuleRegistry, 3) || @createInternalModuleById(3)).addAbortListener;
    let disposable = addAbortListener(signal, onAbort);
    eos(stream, disposable[SymbolDispose]);
  }
  return stream;
}
$ = {
  addAbortSignal,
  addAbortSignalNoValidate
};
return $

})
