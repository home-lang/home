from pathlib import Path
import json,gzip,hashlib,subprocess,tempfile
root=Path(__file__).resolve().parents[2];source=root/'zig-out/stream-graph-port-2026-10-09';dest=root/'docs/docs/bun-port-evidence/2026-10-09-stream-module-graph';dest.mkdir(parents=True,exist_ok=True);files=[]
def retain(data,name):
 p=dest/(name+'.gz');p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(gzip.compress(data,mtime=0));files.append({'path':str(p.relative_to(dest)),'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
for p in sorted(source.rglob('*')):
 if p.is_file() and p.suffix in ['.json','.jsonl','.log','.xml','.stdout','.stderr','.txt','.ts','.py','.mjs','.mts','.cjs','.diff','.cpp','.h','.js','.zig','.cc','.NOTICE','.before']:
  retain(p.read_bytes(),'raw/'+str(p.relative_to(source)))
tracked=['build-support/bundle-native-modules.ts','build-support/bundle-native-modules.test.ts','build-support/native_module_abi.ts','build-support/native_bindings.zig','packages/runtime/upstream/src/jsc/bindings/js_classes.ts']
tracked+=['packages/runtime/upstream/src/js/'+name for name in json.loads((source/'owned-modules.json').read_text())]
tracked+=['packages/runtime/upstream/src/jsc/bindings/webcore/'+name for name in ['ReadableStream.cpp','ReadableStream.h','JSReadableStream.cpp','JSReadableStream.h']]
tracked+=['packages/runtime/upstream/src/jsc/modules/'+name for name in ['NodeModuleModule.cpp','NodeModuleModule.h']]
for name in tracked:retain((root/name).read_bytes(),'source/'+name)
manifest={'schema':1,'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'tested_source_commit_before_rebase':'0257235147','upstream':'4982b91e3702094330f3be3883354c52b8c01323','platform':'Darwin arm64','results':json.loads((source/'combined-totals.json').read_text()),'verification':{'owned_registry_modules':68,'added_stream_graph_modules':38,'added_owned_native_sources':['NodeModuleModule.cpp','ReadableStream.cpp','JSReadableStream.cpp'],'abi_tests':70,'abi_assertions':1122,'debug_build_steps':33,'native_regression_groups':5,'ipc_controls':13,'peak_tree_mb':5692,'tree_limit_mb':8192},'scope':'252 original standalone stream scripts, two original Node stream test files, and the original Web Streams, compression and fetch-body files. All 257 original test source files and four common helper files match the Bun pin. Original assertions and deadlines are unchanged; six original TODOs receive no passing credit. The fetch-body matrix includes HTTP/1.1 and HTTP/3 with http1 disabled in the HTTP/3 row.','evidence_limitations':['Early raw/generated output predates the final native source ownership. raw/compiled-generated contains the output used by the successful native build; the three new owned native bodies are checked byte-for-byte against Home sources.','The initial ABI run failed because the unowned-literal preservation test had an incomplete ownership list. That failed result receives no passing credit. The corrected full ABI run passes all 70 tests.','37 of 38 added module sources match the pin byte-for-byte; the iterable transform source retains one existing lint-disable comment. NodeModuleModule.cpp retains three existing JSC constructor signature adaptations.','Runtime source files are byte-identical across rebase over b4985e4bd, which only adds TypeScript documentation/evidence. Full registry/native ownership, complete Bun-suite, unresolved original TODOs, Release/ASAN and all-platform parity remain unfinished.'],'files':files}
(dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for row in files:
 data=gzip.decompress((dest/row['path']).read_bytes());assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
with tempfile.TemporaryDirectory(prefix='home-stream-evidence-') as temp:
 restored=Path(temp)
 for row in files:
  for phase in ['first','web']:
   prefix='raw/'+phase+'/'
   if row['path'].startswith(prefix+'corpus-'):
    path=restored/phase/row['path'].removeprefix(prefix).removesuffix('.gz');path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(gzip.decompress((dest/row['path']).read_bytes()))
 for phase,count in [('first',254),('web',3)]:
  for index in range(1,count+1):
   r=subprocess.run(['python3',str(root/'scripts/summarize-bun-corpus.py'),str(restored/phase/f'corpus-{index}')],capture_output=True,text=True,cwd=root);assert r.returncode==0,(phase,index,r.stdout,r.stderr)
print(json.dumps({'compressed_artifacts':len(files),'restored_validated_reports':257,'destination':str(dest)}))
