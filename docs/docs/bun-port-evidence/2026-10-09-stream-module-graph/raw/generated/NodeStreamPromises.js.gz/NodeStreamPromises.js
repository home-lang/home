(function () {"use strict";
// zig-out/stream-graph-port-2026-10-09/generated/NodeStreamPromises.mts
var $;
$ = (@getInternalField(@internalModuleRegistry, 136) || @createInternalModuleById(136)).promises;
return $

})
