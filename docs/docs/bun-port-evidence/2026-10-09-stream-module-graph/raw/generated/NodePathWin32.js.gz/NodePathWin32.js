(function () {"use strict";
// zig-out/stream-graph-port-2026-10-09/generated/NodePathWin32.mts
var $;
$ = (@getInternalField(@internalModuleRegistry, 125) || @createInternalModuleById(125)).win32;
return $

})
