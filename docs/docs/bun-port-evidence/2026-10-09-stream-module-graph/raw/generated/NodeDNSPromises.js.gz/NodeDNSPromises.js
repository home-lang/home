(function () {"use strict";
// zig-out/stream-graph-port-2026-10-09/generated/NodeDNSPromises.mts
var $;
$ = (@getInternalField(@internalModuleRegistry, 112) || @createInternalModuleById(112)).promises;
return $

})
