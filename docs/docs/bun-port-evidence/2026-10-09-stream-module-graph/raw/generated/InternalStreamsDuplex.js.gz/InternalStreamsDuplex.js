(function () {"use strict";
// zig-out/stream-graph-port-2026-10-09/generated/InternalStreamsDuplex.mts
var $, Stream = (@getInternalField(@internalModuleRegistry, 68) || @createInternalModuleById(68)).Stream, Readable = @getInternalField(@internalModuleRegistry, 73) || @createInternalModuleById(73), Writable = @getInternalField(@internalModuleRegistry, 77) || @createInternalModuleById(77), { addAbortSignal } = @getInternalField(@internalModuleRegistry, 47) || @createInternalModuleById(47), destroyImpl = @getInternalField(@internalModuleRegistry, 49) || @createInternalModuleById(49), { kOnConstructed } = @getInternalField(@internalModuleRegistry, 76) || @createInternalModuleById(76), ObjectKeys = Object.keys, ObjectDefineProperties = Object.defineProperties, ObjectGetOwnPropertyDescriptor = Object.getOwnPropertyDescriptor;
function Duplex(options) {
  if (!(this instanceof Duplex))
    return new Duplex(options);
  if (this._events ??= {
    close: @undefined,
    error: @undefined,
    prefinish: @undefined,
    finish: @undefined,
    drain: @undefined,
    data: @undefined,
    end: @undefined,
    readable: @undefined
  }, this._readableState = new Readable.ReadableState(options, this, !0), this._writableState = new Writable.WritableState(options, this, !0), options) {
    if (this.allowHalfOpen = options.allowHalfOpen !== !1, options.readable === !1)
      this._readableState.readable = !1, this._readableState.ended = !0, this._readableState.endEmitted = !0;
    if (options.writable === !1)
      this._writableState.writable = !1, this._writableState.ending = !0, this._writableState.ended = !0, this._writableState.finished = !0;
    let { read, write, writev, destroy, final, construct, signal } = options;
    if (typeof read === "function")
      this._read = read;
    if (typeof write === "function")
      this._write = write;
    if (typeof writev === "function")
      this._writev = writev;
    if (typeof destroy === "function")
      this._destroy = destroy;
    if (typeof final === "function")
      this._final = final;
    if (typeof construct === "function")
      this._construct = construct;
    if (signal)
      addAbortSignal(signal, this);
  } else
    this.allowHalfOpen = !0;
  if (Stream.@call(this, options), this._construct != null)
    destroyImpl.construct(this, () => {
      this._readableState[kOnConstructed](this), this._writableState[kOnConstructed](this);
    });
}
@toClass(Duplex, "Duplex", Readable);
Duplex.prototype.destroy = Writable.prototype.destroy;
{
  let keys = ObjectKeys(Writable.prototype);
  for (let i = 0;i < keys.length; i++) {
    let method = keys[i];
    Duplex.prototype[method] ||= Writable.prototype[method];
  }
}
ObjectDefineProperties(Duplex.prototype, {
  writable: { __proto__: null, ...ObjectGetOwnPropertyDescriptor(Writable.prototype, "writable") },
  writableHighWaterMark: {
    __proto__: null,
    ...ObjectGetOwnPropertyDescriptor(Writable.prototype, "writableHighWaterMark")
  },
  writableObjectMode: { __proto__: null, ...ObjectGetOwnPropertyDescriptor(Writable.prototype, "writableObjectMode") },
  writableBuffer: { __proto__: null, ...ObjectGetOwnPropertyDescriptor(Writable.prototype, "writableBuffer") },
  writableLength: { __proto__: null, ...ObjectGetOwnPropertyDescriptor(Writable.prototype, "writableLength") },
  writableFinished: { __proto__: null, ...ObjectGetOwnPropertyDescriptor(Writable.prototype, "writableFinished") },
  writableCorked: { __proto__: null, ...ObjectGetOwnPropertyDescriptor(Writable.prototype, "writableCorked") },
  writableEnded: { __proto__: null, ...ObjectGetOwnPropertyDescriptor(Writable.prototype, "writableEnded") },
  writableNeedDrain: { __proto__: null, ...ObjectGetOwnPropertyDescriptor(Writable.prototype, "writableNeedDrain") },
  destroyed: {
    __proto__: null,
    get() {
      if (this._readableState === @undefined || this._writableState === @undefined)
        return !1;
      return this._readableState.destroyed && this._writableState.destroyed;
    },
    set(value) {
      let readableState = this._readableState, writableState;
      if (readableState && (writableState = this._writableState))
        readableState.destroyed = value, writableState.destroyed = value;
    }
  }
});
var webStreamsAdapters;
function lazyWebStreams() {
  if (webStreamsAdapters === @undefined)
    webStreamsAdapters = @getInternalField(@internalModuleRegistry, 87) || @createInternalModuleById(87);
  return webStreamsAdapters;
}
Duplex.fromWeb = function(pair, options) {
  return lazyWebStreams().newStreamDuplexFromReadableWritablePair(pair, options);
};
Duplex.toWeb = function(duplex, options) {
  return lazyWebStreams().newReadableWritablePairFromDuplex(duplex, options);
};
var duplexify;
Duplex.from = function(body) {
  return duplexify ??= @getInternalField(@internalModuleRegistry, 51) || @createInternalModuleById(51), duplexify(body, "body");
};
$ = Duplex;
return $

})
