var $;
const { MIMEParams, MIMEType } = __intrinsic__lazy(26);

$ = {
  MIMEParams,
  MIMEType,
};
;$$EXPORT$$($).$$EXPORT_END$$;
