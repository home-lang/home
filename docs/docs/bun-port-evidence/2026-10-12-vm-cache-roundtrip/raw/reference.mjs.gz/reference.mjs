import assert from 'node:assert/strict'
import vm from 'node:vm'
const context=vm.createContext({outside:7})
const extension={inside:40}
const options={parsingContext:context,contextExtensions:[extension],produceCachedData:true}
const first=vm.compileFunction('return inside+outside',[],options)
assert.equal(first(),47)
assert.equal(first.cachedDataProduced,true)
assert(Buffer.isBuffer(first.cachedData))
assert(first.cachedData.length>0)
const second=vm.compileFunction('return inside+outside',[],{...options,cachedData:first.cachedData})
assert.equal(second.cachedDataRejected,false)
assert.equal(second.cachedDataProduced,true)
assert(Buffer.isBuffer(second.cachedData))
assert.equal(second(),47)
extension.inside=50
assert.equal(first(),57)
assert.equal(second(),57)
const third=vm.compileFunction('return inside+outside',[],{...options,contextExtensions:[{inside:100}],cachedData:first.cachedData})
assert.equal(third.cachedDataRejected,false)
assert.equal(third(),107)
assert.equal(second(),57)
assert.equal(vm.runInContext('typeof inside',context),'undefined')
console.log('own generated function cache scope flags and simultaneous production/consumption passed')
const moduleSource='export const answer=42'
const originalModule=new vm.SourceTextModule(moduleSource)
const moduleCache=originalModule.createCachedData()
assert(Buffer.isBuffer(moduleCache))
assert(moduleCache.length>0)
const cachedModule=new vm.SourceTextModule(moduleSource,{cachedData:moduleCache})
await cachedModule.link(()=>{throw new Error('unexpected import')})
await cachedModule.evaluate()
assert.equal(cachedModule.namespace.answer,42)
console.log('own generated complete module cache roundtrip passed')
