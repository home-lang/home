from pathlib import Path
import json,gzip,hashlib,subprocess
root=Path(__file__).resolve().parents[2];task=Path(__file__).resolve().parent;base=root/'docs/docs/bun-port-evidence/2026-10-10-performance-monitors';base.mkdir(parents=True,exist_ok=True)
counts={};reports=[]
for path in sorted((task/'final').glob('validate-*.json')):
 data=json.loads(path.read_text());assert data['successful'],path
 for key,value in data['summary'].items():
  if isinstance(value,int):counts[key]=counts.get(key,0)+value
 reports.append(path.name)
assert len(reports)==8 and counts['failed']==0
records=[]
def add(path,name):
 data=path.read_bytes();target=base/(name+'.gz');target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(gzip.compress(data,mtime=0));assert gzip.decompress(target.read_bytes())==data;records.append({'path':str(target.relative_to(base)),'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
for p in sorted(task.rglob('*')):
 if not p.is_file() or p.name.startswith('issue-') or p.name=='archive-production.log':continue
 if p.suffix in ['.log','.json','.jsonl','.py','.mjs','.stdout','.stderr','.xml']:add(p,'raw/'+str(p.relative_to(task)))
for name in json.loads((task/'source-final-hashes.json').read_text()):add(root/name,'source/'+name)
manifest={'schema':1,'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'upstream':'4982b91e3702094330f3be3883354c52b8c01323','platform':'Darwin arm64','results':{'original_files':8,'counts':counts,'native_regression_groups':12},'features':['Independent event-loop-delay histogram state, resolutions and native timer records.','Passive weak histogram handles, collected-record sweep and VM/isolation/worker shutdown cleanup.','Actual elapsed interval sampling starts on enable and samples persist across disable/re-enable.','Safe-integer resolution transport is widened to int64; resource-timing clear delegates to the native performance API.'],'limitations':['Initial singleton identity failure, compile diagnostics and combined-scope GC assertion failures are retained without final passing credit.','Collection checks run in isolated modules: all twenty enabled monitors must collect independently at both short and maximum resolutions. The combined live-test scopes retained targets while isolated controls collected them.','Actual utilization/startup counters and complete resource/observer behavior, broader performance/native/API work, full Bun suite and Release/ASAN/all-platform verification remain open under #66/#869.'],'files':records}
(base/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(len(records),'verified archives',counts)
