import { monitorEventLoopDelay } from 'node:perf_hooks'
function make() {
  const target = monitorEventLoopDelay({ resolution: 1 })
  target.enable()
  return new WeakRef(target)
}
const refs = Array.from({ length: 20 }, make)
for (let i = 0; i < 20; i++) {
  await new Promise(resolve => setTimeout(resolve, 2))
  Bun.gc(true)
}
console.log(refs.map(ref => ref.deref() === undefined))
