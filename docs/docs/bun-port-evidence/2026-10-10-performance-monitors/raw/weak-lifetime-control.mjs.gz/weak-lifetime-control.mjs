import { monitorEventLoopDelay } from 'node:perf_hooks'
function make(kind) {
  const target = kind === 'plain' ? {} : monitorEventLoopDelay({ resolution: Number.MAX_SAFE_INTEGER })
  if (kind === 'enabled') target.enable()
  return new WeakRef(target)
}
const refs = [make('plain'), make('disabled'), make('enabled')]
for (let i = 0; i < 20; i++) {
  await new Promise(resolve => setTimeout(resolve, 2))
  Bun.gc(true)
}
console.log(refs.map(ref => ref.deref() === undefined))
