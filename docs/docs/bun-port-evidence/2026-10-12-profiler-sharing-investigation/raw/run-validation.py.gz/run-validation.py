from pathlib import Path
import subprocess,json,os,sys
root=Path.cwd();task=root/'zig-out/profiler-sharing-2026-10-12';prior=root/'zig-out/inspector-agents-2026-10-12';rows=[]
for name in ['selection.json','run-native.py']:(task/name).write_bytes((prior/name).read_bytes())
s=(prior/'run-corpus.py').read_text().replace("task=root/'zig-out/inspector-agents-2026-10-12'","task=root/'zig-out/profiler-sharing-2026-10-12'");(task/'run-corpus.py').write_text(s)
commands=[['./zig-out/bin/home','run','tests/runtime/native-profiling-cli.test.mjs'],*[[str(root/'zig-out/bin/home'),'run',str(prior/name)] for name in ['profile-sessions.mjs','session-routing.mjs','last-frontend.mjs','runtime-boundaries.mjs']], [sys.executable,str(task/'run-corpus.py'),'original-final'],[sys.executable,str(task/'run-native.py'),'native-final'],['/Users/chris/.bun/bin/bun','test','build-support/native_module_abi.test.ts','build-support/core_builtin_abi.test.ts','build-support/builtin_exports.test.ts'],[sys.executable,'-B','scripts/test_summarize_bun_corpus.py']]
for index,command in enumerate(commands,1):
 with (task/f'validation-{index}.log').open('wb') as log:
  try:r=subprocess.run(command,env=os.environ.copy(),stdout=log,stderr=subprocess.STDOUT,timeout=1200)
  except subprocess.TimeoutExpired:r=subprocess.CompletedProcess(command,124)
 rows.append({'command':command,'exit':r.returncode});(task/'validation.json').write_text(json.dumps(rows,indent=2)+'\n');print(index,r.returncode,flush=True)
 if r.returncode:sys.exit(r.returncode)
