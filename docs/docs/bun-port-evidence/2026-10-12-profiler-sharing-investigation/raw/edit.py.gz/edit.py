from pathlib import Path
p=Path('packages/runtime/upstream/src/jsc/bindings/BunCPUProfiler.cpp');s=p.read_text()
s=s.replace('struct HomeCPUProfilerState {','''// Detached records are safe across sample consumers and GC: no engine cell or
// executable pointer survives the capture's DeferGC scope.
struct HomeCPUFrame {
    WTF::String name, textName, url, textURL;
    int scriptId { 0 }, line { -1 }, column { -1 }, sampleLine { 0 }, textLine { -1 };
};
struct HomeCPUTrace {
    MonotonicTime timestamp;
    WTF::Vector<HomeCPUFrame> frames;
};
struct HomeCPUProfilerState {''')
s=s.replace('    bool running { false };','''    bool running { false };
    bool nativeOwner { false };
    std::unordered_map<const void*, int> consumers;
    WTF::Vector<HomeCPUTrace> nativeSamples;''',1)
s=s.replace('void startCPUProfiler(JSC::VM& vm)\n{','''static void updateProfilerInterval(JSC::VM& vm) {
    int interval = std::numeric_limits<int>::max();
    {
        std::lock_guard lock(profilerStateLock);
        auto& state = profilerStates[&vm];
        if (state.nativeOwner) interval = state.interval;
        for (const auto& owner : state.consumers) interval = std::min(interval, owner.second);
    }
    if (auto* profiler = vm.samplingProfiler()) {
        WTF::Locker lock { profiler->getLock() };
        profiler->setTimingInterval(WTF::Seconds::fromMicroseconds(interval));
    }
}
static void ensureCPUProfiler(JSC::VM& vm)
{''')
s=s.replace('        entry->second.startTime = MonotonicTime::now()', '        if (entry->second.running) return;\n        entry->second.startTime = MonotonicTime::now()',1)
s=s.replace('Ref<JSON::Object> captureCPUProfilerSamples(JSC::VM& vm) {','''void startCPUProfiler(JSC::VM& vm) {
    { std::lock_guard lock(profilerStateLock); profilerStates[&vm].nativeOwner = true; }
    ensureCPUProfiler(vm);
    updateProfilerInterval(vm);
}
void registerCPUProfilerConsumer(JSC::VM& vm, const void* owner, int interval) {
    { std::lock_guard lock(profilerStateLock); profilerStates[&vm].consumers[owner] = interval; }
    ensureCPUProfiler(vm);
    updateProfilerInterval(vm);
}
void unregisterCPUProfilerConsumer(JSC::VM& vm, const void* owner) {
    bool stop = false;
    {
        std::lock_guard lock(profilerStateLock);
        auto found = profilerStates.find(&vm);
        if (found == profilerStates.end()) return;
        found->second.consumers.erase(owner);
        stop = !found->second.nativeOwner && found->second.consumers.empty();
        if (stop) found->second.running = false;
    }
    if (stop) {
        if (auto* profiler = vm.samplingProfiler()) {
            WTF::Locker lock { profiler->getLock() };
            profiler->pause(); profiler->clearData();
        }
    } else updateProfilerInterval(vm);
}
static WTF::Vector<HomeCPUTrace> detachCPUProfilerSamples(JSC::VM&, WTF::Vector<JSC::SamplingProfiler::StackTrace>&&);
Ref<JSON::Object> captureCPUProfilerSamples(JSC::VM& vm) {''')
a=s.index('    auto traces = profiler->releaseStackTraces();');b=s.index('    result->setArray("traces"_s, WTF::move(tracesJSON));\n    return result;',a)
s=s[:a]+'''    auto traces = detachCPUProfilerSamples(vm, profiler->releaseStackTraces());
    for (auto& trace : traces) {
        auto encodedTrace = JSON::Object::create();
        encodedTrace->setDouble("timestamp"_s, trace.timestamp.secondsSinceEpoch().seconds());
        auto frames = JSON::Array::create();
        for (auto& frame : trace.frames) {
            auto encodedFrame = JSON::Object::create();
            encodedFrame->setString("name"_s, frame.name);
            encodedFrame->setString("scriptId"_s, WTF::String::number(frame.scriptId));
            encodedFrame->setString("sourceURL"_s, frame.url);
            encodedFrame->setInteger("line"_s, frame.line);
            encodedFrame->setInteger("column"_s, frame.column);
            frames->pushObject(WTF::move(encodedFrame));
        }
        encodedTrace->setArray("frames"_s, WTF::move(frames));
        tracesJSON->pushObject(WTF::move(encodedTrace));
    }
    {
        std::lock_guard lock(profilerStateLock);
        auto& state = profilerStates[&vm];
        if (state.nativeOwner) state.nativeSamples.appendVector(WTF::move(traces));
    }
'''+s[b:]
# Preserve original source-definition/sample remapping and Markdown naming logic
# verbatim in one capture phase, replacing only output assignments.
a=s.index('                if (frame.frameType == JSC::SamplingProfiler::FrameType::Executable',s.index('// Generate JSON format'))
b=s.index('\n                // line/column here identify',a)
json_block=s[a:b]
a=s.index('                if (frame.frameType == JSC::SamplingProfiler::FrameType::Executable',s.index('WTF::String rawFunctionName ='))
b=s.index('\n                WTF::String location =',a)
text_block=s[a:b]
helper='''static WTF::Vector<HomeCPUTrace> detachCPUProfilerSamples(JSC::VM& vm, WTF::Vector<JSC::SamplingProfiler::StackTrace>&& input) {
    WTF::Vector<HomeCPUTrace> output;
    for (auto& trace : input) {
        HomeCPUTrace detached;
        detached.timestamp = trace.timestamp;
        for (auto& frame : trace.frames) {
            HomeCPUFrame record;
            record.name = frame.displayName(vm);
            record.textName = formatFunctionName(record.name, frame);
            WTF::String url;
            int scriptId = 0, functionDefLine = -1, functionDefColumn = -1, sampleLine = 0;
'''+json_block+'''
            record.url = url; record.scriptId = scriptId;
            record.line = functionDefLine; record.column = functionDefColumn; record.sampleLine = sampleLine;
            url = WTF::String();
            int lineNumber = -1;
'''+text_block+'''
            record.textURL = url; record.textLine = lineNumber;
            detached.frames.append(WTF::move(record));
        }
        output.append(WTF::move(detached));
    }
    return output;
}

'''
pos=s.index('// Helper to format a location string');s=s[:pos]+helper+s[pos:]
# Now replace exporter processing with immutable record fields.
a=s.index('                WTF::String functionName = frame.displayName(vm);',s.index('// Generate JSON format'))
b=s.index('\n                // line/column here identify',a)
s=s[:a]+'''                WTF::String functionName = frame.name;
                WTF::String url = frame.url;
                int scriptId = frame.scriptId;
                int functionDefLine = frame.line;
                int functionDefColumn = frame.column;
                int sampleLine = frame.sampleLine;
'''+s[b:]
a=s.index('                WTF::String rawFunctionName = frame.displayName(vm);',s.index('int totalSamples ='))
b=s.index('\n                WTF::String location =',a)
s=s[:a]+'''                WTF::String functionName = frame.textName;
                WTF::String url = frame.textURL;
                int lineNumber = frame.textLine;
'''+s[b:]
s=s.replace('if (entry != profilerStates.end()) { entry->second.running = false; state = entry->second; }','''if (entry != profilerStates.end()) {
            entry->second.nativeOwner = false;
            entry->second.running = !entry->second.consumers.empty();
            state = WTF::move(entry->second);
            entry->second.startTime = state.startTime;
            entry->second.interval = state.interval;
            entry->second.running = state.running;
            entry->second.consumers = WTF::move(state.consumers);
        }''')
s=s.replace('    profiler->pause();\n\n    // releaseStackTraces()', '    if (!state.running) profiler->pause();\n\n    // releaseStackTraces()',1)
s=s.replace('    auto stackTraces = profiler->releaseStackTraces();\n    profiler->clearData();','''    auto stackTraces = WTF::move(state.nativeSamples);
    stackTraces.appendVector(detachCPUProfilerSamples(vm, profiler->releaseStackTraces()));
    if (!state.running) profiler->clearData();''')
p.write_text(s)
p=Path('packages/runtime/upstream/src/jsc/bindings/HomeCPUProfilerState.h');s=p.read_text().replace('Ref<JSON::Object> captureCPUProfilerSamples', 'void registerCPUProfilerConsumer(JSC::VM&, const void*, int);\nvoid unregisterCPUProfilerConsumer(JSC::VM&, const void*);\nRef<JSON::Object> captureCPUProfilerSamples');p.write_text(s)
p=Path('packages/runtime/upstream/src/jsc/bindings/HomeInspectorSession.h');s=p.read_text();s=s.replace('    if (--found->second.clients == 0) {\n        Bun::stopCPUProfiler(vm, nullptr, nullptr);','    Bun::unregisterCPUProfilerConsumer(vm, this);\n    if (--found->second.clients == 0) {');s=s.replace('    } else if (auto* sampler = vm.samplingProfiler()) {\n        int interval = std::numeric_limits<int>::max();\n        for (const auto& item : found->second.intervals) interval = std::min(interval, item.second);','    } else {');s=s.replace('        WTF::Locker lock { sampler->getLock() };\n        sampler->setTimingInterval(WTF::Seconds::fromMicroseconds(interval));\n','',1)
a=s.index('            if (!broker.clients && Bun::isCPUProfilerRunningForVM(vm))');b=s.index('            captureInspectorSamples',a);s=s[:a]+'            Bun::registerCPUProfilerConsumer(vm, this, samplingInterval);\n'+s[b:]
a=s.index('            if (auto* sampler = vm.samplingProfiler())',s.index('if (method == "Profiler.start"'));b=s.index('            profileStart =',a);s=s[:a]+s[b:];p.write_text(s)
