import { Session } from 'node:inspector/promises';
import { writeFileSync } from 'node:fs';
function beforeSessionWork(){let n=0;for(let i=0;i<1000;i++)n+=Math.sqrt(i);return n}
function duringSessionWork(){let n=0;for(let i=0;i<1000;i++)n+=Math.sin(i);return n}
function afterSessionWork(){let n=0;for(let i=0;i<1000;i++)n+=Math.cos(i);return n}
function work(fn){const until=performance.now()+150;while(performance.now()<until)fn()}
work(beforeSessionWork);
const session=new Session(); session.connect();
await session.post('Profiler.enable');
await session.post('Profiler.setSamplingInterval',{interval:500});
await session.post('Profiler.start'); work(duringSessionWork);
const {profile}=await session.post('Profiler.stop'); session.disconnect();
writeFileSync('session.json',JSON.stringify(profile));
work(afterSessionWork); console.log('done');
