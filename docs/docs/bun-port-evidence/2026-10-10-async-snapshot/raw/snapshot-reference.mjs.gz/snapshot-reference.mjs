import assert from 'node:assert/strict'
import { AsyncLocalStorage, AsyncResource, createHook, executionAsyncId, triggerAsyncId, executionAsyncResource } from 'node:async_hooks'
const storage = new AsyncLocalStorage()
const outer = new AsyncResource('home-snapshot-outer')
const inits=[]
const hook=createHook({init(id,type,trigger,owner){if(type==='bound-anonymous-fn')inits.push({id,type,trigger,owner})}}).enable()
let snapshot
try { outer.runInAsyncScope(()=>storage.run('captured',()=>{snapshot=AsyncLocalStorage.snapshot()})) } finally {hook.disable()}
assert.equal(snapshot.length,1)
assert.equal(inits.length,1)
assert.equal(inits[0].trigger,outer.asyncId())
assert(inits[0].owner instanceof AsyncResource)
const caller = new AsyncResource('home-snapshot-caller')
const events=[]
const scopeHook=createHook({before(id){if(id===inits[0].id)events.push('before')},after(id){if(id===inits[0].id)events.push('after')}}).enable()
const marker=new Error('ordinary snapshot callback error')
try {
 caller.runInAsyncScope(()=>storage.run('caller',()=>{
  const value=snapshot((a,b)=>({a,b,id:executionAsyncId(),trigger:triggerAsyncId(),owner:executionAsyncResource(),store:storage.getStore()}),1,2)
  assert.deepEqual(value,{a:1,b:2,id:inits[0].id,trigger:outer.asyncId(),owner:inits[0].owner,store:'captured'})
  assert.equal(executionAsyncId(),caller.asyncId())
  assert.equal(storage.getStore(),'caller')
  assert.throws(()=>snapshot(()=>{throw marker}),error=>error===marker)
  assert.equal(executionAsyncId(),caller.asyncId())
  assert.equal(storage.getStore(),'caller')
 }))
} finally {scopeHook.disable();storage.disable();outer.emitDestroy();caller.emitDestroy();inits[0].owner.emitDestroy()}
assert.deepEqual(events,['before','after','before','after'])
console.log('snapshot captures a real resource, trigger, arguments and storage, with hook scope and exception restoration')
