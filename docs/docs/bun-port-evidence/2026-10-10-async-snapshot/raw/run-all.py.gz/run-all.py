from pathlib import Path
import os,subprocess,sys,json
root=Path(__file__).resolve().parents[2];task=Path(__file__).resolve().parent
steps=[['./zig-out/bin/home','run',str(task/'snapshot-reference.mjs')],['./zig-out/bin/home','run',str(task/'callback-reference.mjs')],[sys.executable,str(task/'run-native.py'),'native-final'],[sys.executable,str(task/'run-corpus.py'),'original-final'],[sys.executable,str(task/'validate-all-reports.py')]]
rows=[]
for i,command in enumerate(steps):
 with (task/f'validation-step-{i+1}.log').open('wb') as log:
  result=subprocess.run(command,cwd=root,env=os.environ.copy(),stdout=log,stderr=subprocess.STDOUT)
 rows.append({'command':command,'exit':result.returncode});(task/'validation-summary.json').write_text(json.dumps(rows,indent=2)+'\n');print('step',i+1,result.returncode,flush=True)
 if result.returncode:sys.exit(result.returncode)
