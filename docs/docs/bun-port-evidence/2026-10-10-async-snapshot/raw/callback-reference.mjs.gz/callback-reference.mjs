import assert from 'node:assert/strict'
import { AsyncLocalStorage } from 'node:async_hooks'
const first=new AsyncLocalStorage(), second=new AsyncLocalStorage()
function callback(a,b){return {receiver:this,args:[a,b],first:first.getStore(),second:second.getStore()}}
first.run('outer',()=>second.run('other',()=>{
 assert.deepEqual(first.run('inner',callback,1,2),{receiver:null,args:[1,2],first:'inner',second:'other'})
 assert.deepEqual(first.exit(callback,3,4),{receiver:null,args:[3,4],first:undefined,second:'other'})
 assert.equal(first.getStore(),'outer')
 assert.equal(second.getStore(),'other')
}))
first.disable()
assert.deepEqual(first.exit(callback,5,6),{receiver:null,args:[5,6],first:undefined,second:undefined})
console.log('storage run/exit callbacks use null receivers, forward arguments and restore independent stores')
