import json, subprocess
from pathlib import Path
root=Path.cwd();ev=root/'zig-out/bun-port-recovery';rows=[]
assert 'Build Summary: 23/23 steps succeeded' in (ev/'build-corpus-native-setup-alias.log').read_text()
for script in ['verify-native-setup-cli-controls.py','verify-native-setup-first.py','verify-elysia-native-setup-execution-first.py']:
 with (ev/(script+'.log')).open('xb') as stream:
  result=subprocess.run(['python3',str(ev/script)],cwd=root,stdout=stream,stderr=subprocess.STDOUT)
 rows.append(dict(script=script,returncode=result.returncode));(ev/'native-setup-batch-corrected.json').write_text(json.dumps(rows,indent=2)+'\n')
 print(script,result.returncode,flush=True)
 if result.returncode:raise SystemExit(result.returncode)
