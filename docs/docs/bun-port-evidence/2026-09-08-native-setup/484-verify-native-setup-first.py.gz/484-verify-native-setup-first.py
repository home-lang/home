import hashlib, importlib.util, json, os, shutil, subprocess, time
from pathlib import Path
root=Path.cwd(); evidence=root/'zig-out/bun-port-recovery'; out=evidence/'native-setup-first'; out.mkdir()
project=root/'packages/runtime/test'; home=root/'zig-out/bin/home'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
assert 'Build Summary: 23/23 steps succeeded' in (evidence/'build-corpus-native-setup-alias.log').read_text()
setup=json.loads((project/'BUN_SETUP_FILES.json').read_text()); originals={e['path']:e['sha256'] for e in setup['files']}
assert len(originals)==50
for name,digest in originals.items(): assert sha(project/name)==digest,name
manifest={'kind':'first native root/test setup orchestration; zero corpus case credit','home_sha256':sha(home),'bun_pin':setup['bun_pin'],'original_inputs':originals,'attempts_per_install':1,'cleanup':[],'pre_install_cleanup_reference':'native-setup-dependency-pre-cleanup.json','status':'prepared'}
def save(): (out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
save()
for relative in ['node_modules','test/node_modules']:
 target=project/relative
 assert not any(subprocess.check_output(['git','ls-files','-z','--',str(target.relative_to(root))]).split(b'\0'))
 assert not target.is_symlink()
 if target.exists():
  size=sum(p.lstat().st_size for p in target.rglob('*') if not p.is_symlink() and p.is_file())
  manifest['cleanup'].append({'path':str(target),'generated_file_bytes':size});save();shutil.rmtree(target)
env=os.environ.copy()
for key in ['HOME_NATIVE_VM','HOME_CORPUS_FULL_VM','HOME_CORPUS_VENDOR_PLAN_OUTPUT','HOME_BUN_CORPUS_START','HOME_BUN_CORPUS_LIMIT']: env.pop(key,None)
env.update(CI='true',HOME_BUN_TEST_EXECUTABLE=str(home),HOME_BUN_CORPUS_REPORT_DIR=str(out/'reports'))
argv=[str(home),'test','--bun-corpus-setup'];manifest.update(argv=argv,status='started');save();start=time.monotonic()
with (out/'runner.stdout').open('xb') as stdout,(out/'runner.stderr').open('xb') as stderr:
 code=subprocess.run(argv,cwd=root,env=env,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr).returncode
manifest.update(returncode=code,seconds=time.monotonic()-start,status='completed',home_unchanged=sha(home)==manifest['home_sha256'],inputs_unchanged=all(sha(project/name)==digest for name,digest in originals.items()));save()
spec=importlib.util.spec_from_file_location('outcomes',root/'scripts/summarize-bun-corpus.py');validator=importlib.util.module_from_spec(spec);spec.loader.exec_module(validator)
result=validator.summarize(out/'reports');(out/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
events=[json.loads(line) for line in (out/'reports/events.jsonl').read_text().splitlines()]
completed=[r for r in events if r['event']=='completed'];started=[r for r in events if r['event']=='started']
manifest.update(setup_successful=result['successful'],journal_errors=result['errors'],counts=result['counts'],selected=result['selected'],completed=result['completed'],captures=result['capture_completeness'],outcomes=[{key:r[key] for key in ['id','term','timed_out','output_complete','source_unchanged']} for r in completed],temporary_storage_removed=all(not Path(r['environment']['BUN_INSTALL_CACHE_DIR']).exists() for r in started))
# A retained original install failure is a valid failure outcome, never successful setup.
manifest['verification_passed']=not result['errors'] and result['selected']==result['completed']==2 and result['counts']==dict(passed=0,failed=0,skipped=0,todo=0) and (code==0)==result['successful'] and manifest['inputs_unchanged'] and manifest['home_unchanged'] and manifest['temporary_storage_removed']
save();print(json.dumps({k:v for k,v in manifest.items() if k!='original_inputs'},indent=2));raise SystemExit(0 if manifest['verification_passed'] else 1)
