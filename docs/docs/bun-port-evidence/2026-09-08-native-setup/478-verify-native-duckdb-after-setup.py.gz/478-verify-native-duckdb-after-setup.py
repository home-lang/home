import hashlib,importlib.util,json,os,subprocess
from pathlib import Path
root=Path.cwd();ev=root/'zig-out/bun-port-recovery';out=ev/'native-duckdb-after-setup';out.mkdir();project=root/'packages/runtime/test';home=root/'zig-out/bin/home'
setup=json.loads((ev/'native-setup-first/manifest.json').read_text());assert setup['setup_successful'] and setup['verification_passed']
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
binding=project/'test/node_modules/duckdb/lib/binding/duckdb.node';assert binding.is_file()
files=['js/third_party/duckdb/duckdb-basic-usage.test.ts','js/third_party/@duckdb/node-api/duckdb.test.ts'];sources={}
for name in files:
 p=project/'test'/name;assert p.read_bytes()==subprocess.check_output(['git','-C','/Users/chris/Code/bun','show',setup['bun_pin']+':test/'+name]);sources[name]=sha(p)
manifest=dict(kind='native DuckDB binding prerequisite and two unchanged original files; not complete primary corpus',home_sha256=sha(home),bun_pin=setup['bun_pin'],binding_sha256=sha(binding),binding_bytes=binding.stat().st_size,original_sources=sources,attempts=1)
def save():(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
save();env=os.environ.copy();env.update(HOME_NATIVE_VM='1',CI='true')
code="const assert=require('node:assert');const {Database}=require('duckdb');const db=new Database(':memory:');db.all('SELECT 42 AS value',(error,rows)=>{if(error)throw error;assert.deepEqual(rows,[{value:42}]);db.close(error=>{if(error)throw error;console.log(JSON.stringify({value:rows[0].value,execPath:process.execPath,modules:process.versions.modules}));});});"
(out/'binding-control.js').write_text(code)
result=subprocess.run([str(home),'-e',code],cwd=project/'test',env=env,capture_output=True,timeout=30);(out/'binding.stdout').write_bytes(result.stdout);(out/'binding.stderr').write_bytes(result.stderr);manifest['binding_control_returncode']=result.returncode;save();assert result.returncode==0,result.stderr.decode()
for key in ['HOME_NATIVE_VM','HOME_CORPUS_FULL_VM','HOME_CORPUS_VENDOR_PLAN_OUTPUT','HOME_BUN_CORPUS_START','HOME_BUN_CORPUS_LIMIT']:env.pop(key,None)
env.update(HOME_BUN_TEST_EXECUTABLE=str(home),HOME_BUN_CORPUS_REPORT_DIR=str(out/'reports'))
argv=[str(home),'test',*[str(project/'test'/name) for name in files]];manifest['argv']=argv;save()
with (out/'runner.stdout').open('xb') as stdout,(out/'runner.stderr').open('xb') as stderr:
 result=subprocess.run(argv,cwd=root,env=env,stdout=stdout,stderr=stderr)
spec=importlib.util.spec_from_file_location('outcomes',root/'scripts/summarize-bun-corpus.py');validator=importlib.util.module_from_spec(spec);spec.loader.exec_module(validator);summary=validator.summarize(out/'reports');(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
manifest.update(returncode=result.returncode,counts=summary['counts'],completed=summary['completed'],journal_errors=summary['errors'],successful=summary['successful'],sources_unchanged=all(sha(project/'test'/name)==digest for name,digest in sources.items()),binding_unchanged=sha(binding)==manifest['binding_sha256'],deprecated_file_abi_gate='The unchanged legacy fixture exits before registration when modules ABI exceeds 137; no legacy passing case credit.')
manifest['verified']=summary['successful'] and result.returncode==0 and summary['completed']==2 and manifest['sources_unchanged'] and manifest['binding_unchanged'];save();print(json.dumps(manifest,indent=2));raise SystemExit(0 if manifest['verified'] else 1)
