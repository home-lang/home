import gzip,hashlib,importlib.util,json,subprocess,tempfile
from pathlib import Path
root=Path.cwd();folder=root/'docs/docs/bun-port-evidence/2026-09-08-native-setup';manifest=json.loads((folder/'manifest.json').read_text())
tracked=set(subprocess.check_output(['git','ls-files'],text=True).splitlines())
spec=importlib.util.spec_from_file_location('outcomes',root/'scripts/summarize-bun-corpus.py');validator=importlib.util.module_from_spec(spec);spec.loader.exec_module(validator)
with tempfile.TemporaryDirectory(prefix='home-setup-publication-') as temporary:
 target=Path(temporary)
 for entry in manifest['files']:
  path=folder/entry['artifact'];assert str(path.relative_to(root)) in tracked
  data=gzip.decompress(path.read_bytes());assert len(data)==entry['bytes'] and hashlib.sha256(data).hexdigest()==entry['sha256']
  for label,prefix in [('setup','native-setup-first/reports/'),('vendor','elysia-native-setup-execution-first/reports/'),('positive','native-setup-cli-controls/successful-reports/'),('negative','native-setup-cli-controls/failed-reports/'),('duckdb','native-duckdb-original-files/reports/')]:
   source='zig-out/bun-port-recovery/'+prefix
   if entry['source'].startswith(source):
    name=entry['source'][len(source):];assert Path(name).name==name
    (target/label).mkdir(exist_ok=True);(target/label/name).write_bytes(data)
 results={label:validator.summarize(target/label) for label in ['setup','vendor','positive','negative','duckdb']}
 for label,result in results.items():assert not result['errors'],(label,result['errors'])
 assert results['setup']['successful']==manifest['setup_successful'] and results['setup']['completed']==2
 assert results['duckdb']['successful'] and results['duckdb']['counts']==dict(passed=18,failed=0,skipped=0,todo=0) and results['duckdb']['completed']==2
 assert results['positive']['successful'] and not results['negative']['successful']
 assert results['vendor']['successful'] and results['vendor']['completed']==129 and results['vendor']['counts']['passed']==1516
 print(json.dumps(dict(tracked_artifacts_verified=len(manifest['files']),restored={label:dict(successful=r['successful'],completed=r['completed'],counts=r['counts']) for label,r in results.items()}),indent=2))
