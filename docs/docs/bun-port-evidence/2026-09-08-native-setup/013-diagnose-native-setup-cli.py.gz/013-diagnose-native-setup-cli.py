import hashlib, importlib.util, json, os, subprocess, tempfile
from pathlib import Path
root=Path.cwd(); ev=root/'zig-out/bun-port-recovery'; out=ev/'native-setup-cli-diagnostic'; out.mkdir(); home=root/'zig-out/bin/home'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
spec=importlib.util.spec_from_file_location('outcomes',root/'scripts/summarize-bun-corpus.py'); validator=importlib.util.module_from_spec(spec);spec.loader.exec_module(validator)
rows=[]
with tempfile.TemporaryDirectory(prefix='home-native-setup-controls-') as temporary:
 cwd=Path(temporary); project=cwd/'packages/runtime/test'; (project/'test').mkdir(parents=True)
 pin='a'*40; (project/'test/UPSTREAM_SHA.txt').write_text(pin)
 hook="const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert'); assert.equal(process.env.BUN_GARBAGE_COLLECTOR_LEVEL,'1'); assert.equal(process.env.BUN_JSC_randomIntegrityAuditRate,'1.0'); assert.equal(process.env.BUN_RUNTIME_TRANSPILER_CACHE_PATH,'0'); assert.equal(fs.realpathSync(Bun.which('bun')),fs.realpathSync(process.execPath)); assert.equal(fs.realpathSync(Bun.which('node')),fs.realpathSync(process.execPath)); assert.equal(fs.existsSync(path.join(process.env.BUN_INSTALL_CACHE_DIR,'bun')),false); fs.writeFileSync('marker',process.env.BUN_INSTALL_CACHE_DIR);console.log('999 pass');process.exit(Number(process.env.SETUP_CONTROL_EXIT||0));"
 (project/'hook.js').write_text(hook)
 for name,command in [('package.json','bun hook.js'),('test/package.json','bun ../hook.js')]:
  (project/name).write_text(json.dumps(dict(name='private-setup-control',private=True,scripts=dict(postinstall=command))))
 inputs=[dict(path=name,sha256=sha(project/name)) for name in ['package.json','test/package.json','hook.js']]
 (project/'BUN_SETUP_FILES.json').write_text(json.dumps(dict(bun_pin=pin,files=inputs)))
 for label,updates,args in [('successful',{},[]),('failed',dict(SETUP_CONTROL_EXIT='7'),[]),('platform-mismatch',dict(EXPECTED_PLATFORM_OS='wrong'),[]),('extra-argument',{},['extra'])]:
  env=os.environ.copy()
  for key in list(env):
   if key.startswith('EXPECTED_PLATFORM_') or key in ['HOME_NATIVE_VM','HOME_CORPUS_FULL_VM','HOME_CORPUS_VENDOR_PLAN_OUTPUT']:env.pop(key,None)
  report=out/(label+'-reports');env.update(CI='true',HOME_BUN_TEST_EXECUTABLE=str(home),HOME_BUN_CORPUS_REPORT_DIR=str(report),**updates)
  result=subprocess.run([str(home),'test','--bun-corpus-setup',*args],cwd=cwd,env=env,capture_output=True,timeout=60)
  (out/(label+'.stdout')).write_bytes(result.stdout);(out/(label+'.stderr')).write_bytes(result.stderr)
  row=dict(label=label,returncode=result.returncode)
  if label in ['successful','failed']:
   summary=validator.summarize(report);(out/(label+'-summary.json')).write_text(json.dumps(summary,indent=2)+'\n')
   row.update(successful=summary['successful'],errors=summary['errors'],completed=summary['completed'],counts=summary['counts'])
   assert not summary['errors'] and summary['completed']==2 and sum(summary['counts'].values())==0,row
   assert summary['successful']==(label=='successful') and (result.returncode==0)==(label=='successful'),row
  else:
   assert result.returncode!=0 and not report.exists(),row
  rows.append(row)
(out/'manifest.json').write_text(json.dumps(dict(kind='private CLI controls, zero corpus case credit',home_sha256=sha(home),controls=rows,verified=True),indent=2)+'\n');print(json.dumps(rows,indent=2))
