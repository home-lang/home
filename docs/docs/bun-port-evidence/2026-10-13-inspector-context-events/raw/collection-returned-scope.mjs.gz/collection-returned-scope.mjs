import vm from 'node:vm';
function createWeakContext(){const context=vm.createContext({});return new WeakRef(context)}
const weak=createWeakContext();
for(let i=0;i<20;i++){await new Promise(r=>setImmediate(r));if(globalThis.Bun)Bun.gc(true);else globalThis.gc();await new Promise(r=>setImmediate(r));}
process.stdout.write(JSON.stringify({alive:weak.deref()!==undefined})+'\n');
