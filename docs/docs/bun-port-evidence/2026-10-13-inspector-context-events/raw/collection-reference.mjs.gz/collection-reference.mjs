import vm from 'node:vm';
import { Session } from 'node:inspector/promises';
const session=new Session();session.connect();const contexts=[],destroyed=[];
session.on('Runtime.executionContextCreated',e=>contexts.push(e.params.context));session.on('Runtime.executionContextDestroyed',e=>destroyed.push(e.params.executionContextId));
let context=vm.createContext({},{name:'collection-realm'});await session.post('Runtime.enable');const realm=contexts.find(c=>c.name==='collection-realm');const weak=new WeakRef(context);context=null;
for(let i=0;i<12;i++){await new Promise(r=>setImmediate(r));if(globalThis.Bun)Bun.gc(true);else globalThis.gc();await new Promise(r=>setImmediate(r));}
const alive=weak.deref()!==undefined;session.disconnect();process.stdout.write(JSON.stringify({realmId:realm?.id,alive,destroyed})+'\n');
