import pathlib,json,subprocess,sys
p=pathlib.Path(__file__).resolve().parent;records=[]
for report in sorted(p.rglob('events.jsonl')):
 if 'control-validation' in report.parts:continue
 directory=report.parent;relative=str(directory.relative_to(p));child=subprocess.run([sys.executable,'scripts/summarize-bun-corpus.py',str(directory)],capture_output=True,text=True);result=json.loads(child.stdout);out=p/'control-validation'/(relative+'.json');out.parent.mkdir(parents=True,exist_ok=True);out.write_text(child.stdout);records.append({'path':relative,'validation':str(out.relative_to(p)),'exit':child.returncode,'successful':result.get('successful'),'counts':result.get('counts'),'errors':result.get('errors')})
(p/'all-report-validation.json').write_text(json.dumps(records,indent=2)+'\n');print('retained report outcomes',len(records))
