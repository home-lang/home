import vm from 'node:vm';import { Session } from 'node:inspector/promises';
const mode=process.argv[2];let session;const events=[];
if(mode!=='no-session'){session=new Session();session.connect();}
let context=vm.createContext({},{name:'variant-realm'});const weak=new WeakRef(context);
if(session){session.on('Runtime.executionContextCreated',e=>events.push(e.params.context));await session.post('Runtime.enable');if(mode==='evaluated'){const realm=events.find(x=>x.name==='variant-realm');await session.post('Runtime.evaluate',{expression:'1',contextId:realm.id,returnByValue:true});}if(mode==='detached')session.disconnect();}
context=null;for(let i=0;i<20;i++){await new Promise(r=>setImmediate(r));if(globalThis.Bun)Bun.gc(true);else globalThis.gc();await new Promise(r=>setImmediate(r));}
const alive=weak.deref()!==undefined;session?.disconnect();process.stdout.write(JSON.stringify({mode,alive})+'\n');
