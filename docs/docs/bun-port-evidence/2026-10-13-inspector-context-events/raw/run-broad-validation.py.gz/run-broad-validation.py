from pathlib import Path
import subprocess,json,sys,os
p=Path(__file__).resolve().parent;rows=[]
commands=[[sys.executable,str(p/'run-corpus.py'),'original-final'],[sys.executable,str(p/'run-native.py'),'native-final'],['/Users/chris/.bun/bin/bun','test','build-support/native_module_abi.test.ts','build-support/core_builtin_abi.test.ts','build-support/builtin_exports.test.ts'],[sys.executable,'-B','scripts/test_summarize_bun_corpus.py']]
for index,command in enumerate(commands,1):
 with (p/f'broad-{index}.log').open('wb') as log:
  result=subprocess.run(command,env=os.environ.copy(),stdout=log,stderr=subprocess.STDOUT,timeout=1200)
 rows.append({'command':command,'exit':result.returncode});(p/'broad-results.json').write_text(json.dumps(rows,indent=2)+'\n');print(index,result.returncode,flush=True)
 if result.returncode:sys.exit(result.returncode)
