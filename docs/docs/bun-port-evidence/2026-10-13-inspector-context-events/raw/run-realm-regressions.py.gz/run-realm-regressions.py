from pathlib import Path
import os,subprocess,json,sys
root=Path.cwd();task=Path(__file__).resolve().parent;rows=[];phase='realm-regression'
for runtime,exe in [('node','node'),('home',str(root/'zig-out/bin/home'))]:
 for name in ['reference.mjs','metadata-reference.mjs','object-reference.mjs','getter-reference.mjs','parameter-reference.mjs','cross-realm-reference.mjs','world-direction-reference.mjs']:
  with (task/(phase+'-'+runtime+'-'+name+'.log')).open('wb') as log:
   try:r=subprocess.run([exe,str(task/name)],cwd=root,env=os.environ,stdout=log,stderr=subprocess.STDOUT,timeout=30)
   except subprocess.TimeoutExpired:r=subprocess.CompletedProcess([],124)
  rows.append({'runtime':runtime,'file':name,'exit':r.returncode});(task/(phase+'-results.json')).write_text(json.dumps(rows,indent=2)+'\n');print(runtime,name,r.returncode,flush=True)
  if r.returncode:sys.exit(r.returncode)
