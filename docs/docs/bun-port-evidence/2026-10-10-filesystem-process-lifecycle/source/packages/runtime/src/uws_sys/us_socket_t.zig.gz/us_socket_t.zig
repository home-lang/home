const debug = bun.Output.scoped(.uws, .visible);
const max_i32 = std.math.maxInt(i32);

/// Zig bindings for `us_socket_t`.
///
/// TLS is per-socket (`s->ssl != NULL` in C); there is no `int ssl` selector.
/// Dispatch is by `kind()` — see `SocketKind` and `dispatch.zig`.
///
/// Higher-level wrappers (`uws.SocketTCP`/`SocketTLS`) cover named pipes,
/// upgraded duplexes, and async DNS.
pub const us_socket_t = opaque {
    pub const CloseCode = enum(i32) {
        /// TLS: send close_notify and defer fd close until peer replies. TCP: FIN.
        normal = 0,
        /// TLS: fast-shutdown (no wait). TCP: SO_LINGER{1,0} → RST, dropping any
        /// unflushed send buffer. Only for `terminate()` / GC abort.
        failure = 1,
        /// TLS: fast-shutdown (no wait). TCP: FIN. For `_handle.close()` where
        /// the JS wrapper detaches immediately so `.normal`'s deferral would
        /// orphan the `us_socket_t`, but already-written data must still drain.
        fast_shutdown = 2,
    };

    pub fn open(this: *us_socket_t, is_client: bool, ip_addr: ?[]const u8) void {
        debug("us_socket_open({p}, is_client: {})", .{ this, is_client });
        if (ip_addr) |ip| {
            bun.assert(ip.len < max_i32);
            _ = c.us_socket_open(this, @intFromBool(is_client), ip.ptr, @intCast(@min(ip.len, max_i32)));
        } else {
            _ = c.us_socket_open(this, @intFromBool(is_client), null, 0);
        }
    }

    pub fn pause(this: *us_socket_t) void {
        debug("us_socket_pause({p})", .{this});
        c.us_socket_pause(this);
    }

    pub fn @"resume"(this: *us_socket_t) void {
        debug("us_socket_resume({p})", .{this});
        c.us_socket_resume(this);
    }

    pub fn close(this: *us_socket_t, code: CloseCode) void {
        debug("us_socket_close({p}, {s})", .{ this, @tagName(code) });
        // A socket detached from its group (`s->group == NULL`) cannot be
        // closed: uSockets' `us_socket_close` → `us_internal_socket_close_raw`
        // dereferences `s->group->loop` unconditionally (guarded only by
        // `!us_socket_is_closed`), so closing a groupless socket segfaults at
        // `s->group->loop`. This is reachable from a deferred IPC close
        // (`SendQueue.closeSocketNextTick` → `_closeSocketTask`) that fires
        // after the underlying socketpair was detached from the shared
        // spawn-IPC group — the SendQueue still sees `.open` because no
        // `on_close` was dispatched for the detach. A groupless socket is
        // already out of the loop with nothing to tear down, so skip it.
        // Reading `us_socket_group` is a plain field load and is safe on any
        // live socket (the C close path itself first passes `us_socket_is_closed`).
        if (@intFromPtr(c.us_socket_group(this)) == 0) return;
        _ = c.us_socket_close(this, code, null);
    }

    pub fn shutdown(this: *us_socket_t) void {
        debug("us_socket_shutdown({p})", .{this});
        c.us_socket_shutdown(this);
    }

    pub fn shutdownRead(this: *us_socket_t) void {
        c.us_socket_shutdown_read(this);
    }

    pub fn isClosed(this: *us_socket_t) bool {
        return c.us_socket_is_closed(this) > 0;
    }

    pub fn isShutdown(this: *us_socket_t) bool {
        return c.us_socket_is_shut_down(this) > 0;
    }

    pub fn isTLS(this: *us_socket_t) bool {
        return c.us_socket_is_tls(this) > 0;
    }

    pub fn localPort(this: *us_socket_t) i32 {
        return c.us_socket_local_port(this);
    }

    pub fn remotePort(this: *us_socket_t) i32 {
        return c.us_socket_remote_port(this);
    }

    /// Returned slice is a view into `buf`.
    pub fn localAddress(this: *us_socket_t, buf: []u8) ![]const u8 {
        var length: i32 = @intCast(@min(buf.len, max_i32));
        c.us_socket_local_address(this, buf.ptr, &length);
        if (length < 0) {
            const errno = bun.sys.getErrno(length);
            bun.debugAssert(errno != .SUCCESS);
            return bun.errnoToZigErr(errno);
        }
        bun.unsafeAssert(buf.len >= length);
        return buf[0..@intCast(length)];
    }

    /// Returned slice is a view into `buf`. On error, `errno` should be set.
    pub fn remoteAddress(this: *us_socket_t, buf: []u8) ![]const u8 {
        var length: i32 = @intCast(@min(buf.len, max_i32));
        c.us_socket_remote_address(this, buf.ptr, &length);
        if (length < 0) {
            const errno = bun.sys.getErrno(length);
            bun.debugAssert(errno != .SUCCESS);
            return bun.errnoToZigErr(errno);
        }
        bun.unsafeAssert(buf.len >= length);
        return buf[0..@intCast(length)];
    }

    pub fn setTimeout(this: *us_socket_t, seconds: u32) void {
        c.us_socket_timeout(this, seconds);
    }

    pub fn setLongTimeout(this: *us_socket_t, minutes: u32) void {
        c.us_socket_long_timeout(this, minutes);
    }

    pub fn setNodelay(this: *us_socket_t, enabled: bool) void {
        c.us_socket_nodelay(this, @intFromBool(enabled));
    }

    pub fn setKeepalive(this: *us_socket_t, enabled: bool, delay: u32) i32 {
        return c.us_socket_keepalive(this, @intFromBool(enabled), delay);
    }

    /// `SSL*` if TLS, else null. Use `getFd()` for the descriptor.
    pub fn ssl(this: *us_socket_t) ?*BoringSSL.SSL {
        if (!this.isTLS()) return null;
        return @ptrCast(c.us_socket_get_native_handle(this));
    }

    /// Node-compat `_handle` shape: `SSL*` for TLS sockets, fd-as-pointer for
    /// plain TCP. Consumers that want one or the other should call `ssl()` /
    /// `getFd()` directly; this is the round-trip-to-JS form.
    pub fn getNativeHandle(this: *us_socket_t) ?*anyopaque {
        return c.us_socket_get_native_handle(this);
    }

    pub fn ext(this: *us_socket_t, comptime T: type) *T {
        @setRuntimeSafety(true);
        return @ptrCast(@alignCast(c.us_socket_ext(this)));
    }

    /// Type-erased ext storage — `LIBUS_EXT_ALIGNMENT`-aligned bytes
    /// immediately after the C struct. Prefer `ext(T)`.
    pub fn extPtr(this: *us_socket_t) [*]align(16) u8 {
        return @ptrCast(@alignCast(c.us_socket_ext(this)));
    }

    pub fn group(this: *us_socket_t) *SocketGroup {
        @setRuntimeSafety(true);
        return c.us_socket_group(this);
    }
    pub const rawGroup = group;

    pub fn kind(this: *us_socket_t) SocketKind {
        return @fromBackingInt(@intCast(c.us_socket_kind(this)));
    }

    /// Re-stamp the dispatch kind in place. Used after `Listener.onCreate`
    /// stashes the `NewSocket*` in ext so subsequent events skip the listener
    /// arm and route straight to `BunSocket`.
    pub fn setKind(this: *us_socket_t, k: SocketKind) void {
        c.us_socket_set_kind(this, @backingInt(k));
    }

    /// Resume a TLS handshake parked by the select-certificate callback.
    /// `ctx` carries one owned SSL_CTX reference which the C implementation
    /// consumes, including on late or duplicate resolutions.
    pub fn sniResolve(this: *us_socket_t, ctx: ?*uws.SslCtx, is_error: bool) void {
        c.us_socket_sni_resolve(this, ctx, @intFromBool(is_error));
    }

    /// Move this socket to a new group/kind, optionally resizing its ext.
    /// Returns the (possibly relocated) socket; `this` is invalid after.
    pub fn adopt(this: *us_socket_t, g: *SocketGroup, k: SocketKind, old_ext: i32, new_ext: i32) ?*us_socket_t {
        return c.us_socket_adopt(this, g, @backingInt(k), old_ext, new_ext);
    }

    /// `adopt` + attach a fresh `SSL*` from `ssl_ctx` (refcounted by the C
    /// side for the socket's lifetime). Does NOT kick the handshake — the
    /// caller must repoint `ext` first (so any dispatch lands in the new
    /// owner) and then call `startTLSHandshake`. Replaces
    /// `us_socket_upgrade_to_tls` / `wrapTLS`.
    pub fn adoptTLS(
        this: *us_socket_t,
        g: *SocketGroup,
        k: SocketKind,
        ssl_ctx: *uws.SslCtx,
        sni: ?[*:0]const u8,
        old_ext: i32,
        new_ext: i32,
    ) ?*us_socket_t {
        return c.us_socket_adopt_tls(this, g, @backingInt(k), ssl_ctx, sni, old_ext, new_ext);
    }

    /// Send ClientHello. Separate from `adoptTLS` so the ext slot can be
    /// repointed before any handshake/close dispatch can fire.
    pub fn startTLSHandshake(this: *us_socket_t) void {
        c.us_socket_start_tls_handshake(this);
    }

    /// Tee inbound ciphertext to `us_dispatch_ssl_raw_tap` before `SSL_read`
    /// consumes it, so the `[raw, tls]` pair from `upgradeTLS` can surface
    /// encrypted bytes to the original net.Socket `data` listener.
    pub fn setSslRawTap(this: *us_socket_t, enabled: bool) void {
        c.us_socket_set_ssl_raw_tap(this, @intFromBool(enabled));
    }

    pub fn write(this: *us_socket_t, data: []const u8) i32 {
        const rc = c.us_socket_write(this, data.ptr, @intCast(@min(data.len, max_i32)));
        debug("us_socket_write({p}, {d}) = {d}", .{ this, data.len, rc });
        return rc;
    }

    extern "c" fn HomeIPCSocketWrite(*us_socket_t, [*]const u8, c_int, *c_int) c_int;
    pub fn writeIPC(this: *us_socket_t, data: []const u8, error_code: *c_int) i32 {
        return HomeIPCSocketWrite(this, data.ptr, @intCast(@min(data.len, max_i32)), error_code);
    }

    pub fn writeFd(this: *us_socket_t, data: []const u8, file_descriptor: bun.FD) i32 {
        if (bun.Environment.isWindows) @compileError("TODO: implement writeFd on Windows");
        const rc = c.us_socket_ipc_write_fd(this, data.ptr, @intCast(@min(data.len, max_i32)), file_descriptor.native());
        debug("us_socket_ipc_write_fd({p}, {d}, {d}) = {d}", .{ this, data.len, file_descriptor.native(), rc });
        return rc;
    }

    pub fn write2(this: *us_socket_t, first: []const u8, second: []const u8) i32 {
        const rc = c.us_socket_write2(this, first.ptr, first.len, second.ptr, second.len);
        debug("us_socket_write2({p}, {d}, {d}) = {d}", .{ this, first.len, second.len, rc });
        return rc;
    }

    /// Bypass TLS — raw bytes to the fd even if `isTLS()`.
    pub fn rawWrite(this: *us_socket_t, data: []const u8) i32 {
        debug("us_socket_raw_write({p}, {d})", .{ this, data.len });
        return c.us_socket_raw_write(this, data.ptr, @intCast(@min(data.len, max_i32)));
    }

    pub fn flush(this: *us_socket_t) void {
        c.us_socket_flush(this);
    }

    pub fn sendFileNeedsMore(this: *us_socket_t) void {
        c.us_socket_sendfile_needs_more(this);
    }

    pub fn getFd(this: *us_socket_t) bun.FD {
        return .fromNative(c.us_socket_get_fd(this));
    }

    pub fn getVerifyError(this: *us_socket_t) uws.us_bun_verify_error_t {
        return c.us_socket_verify_error(this);
    }

    pub fn getError(this: *us_socket_t) i32 {
        return c.us_socket_get_error(this);
    }

    pub fn isEstablished(this: *us_socket_t) bool {
        return c.us_socket_is_established(this) > 0;
    }
};

/// Raw externs. Private — every operation has a typed method on `us_socket_t`.
const c = struct {
    // Every C-side decl takes `us_socket_r` (= `us_socket_t* nonnull_arg`), so
    // mirror that here — passing null is UB and the typed methods above never do.
    extern fn us_socket_get_native_handle(s: *us_socket_t) ?*anyopaque;

    extern fn us_socket_local_port(s: *us_socket_t) i32;
    extern fn us_socket_remote_port(s: *us_socket_t) i32;
    extern fn us_socket_remote_address(s: *us_socket_t, buf: [*]u8, length: *i32) void;
    extern fn us_socket_local_address(s: *us_socket_t, buf: [*]u8, length: *i32) void;
    extern fn us_socket_timeout(s: *us_socket_t, seconds: c_uint) void;
    extern fn us_socket_long_timeout(s: *us_socket_t, minutes: c_uint) void;
    extern fn us_socket_nodelay(s: *us_socket_t, enable: c_int) void;
    extern fn us_socket_keepalive(s: *us_socket_t, enable: c_int, delay: c_uint) c_int;

    extern fn us_socket_ext(s: *us_socket_t) *anyopaque;
    extern fn us_socket_group(s: *us_socket_t) *SocketGroup;
    extern fn us_socket_kind(s: *us_socket_t) u8;
    extern fn us_socket_set_kind(s: *us_socket_t, kind: u8) void;
    extern fn us_socket_sni_resolve(s: *us_socket_t, ctx: ?*uws.SslCtx, is_error: c_int) void;
    extern fn us_socket_set_ssl_raw_tap(s: *us_socket_t, enabled: c_int) void;
    extern fn us_socket_is_tls(s: *us_socket_t) i32;

    extern fn us_socket_write(s: *us_socket_t, data: [*]const u8, length: i32) i32;
    extern fn us_socket_ipc_write_fd(s: *us_socket_t, data: [*]const u8, length: i32, fd: i32) i32;
    extern fn us_socket_write2(*us_socket_t, header: ?[*]const u8, len: usize, payload: ?[*]const u8, usize) i32;
    extern fn us_socket_raw_write(s: *us_socket_t, data: [*]const u8, length: i32) i32;
    extern fn us_socket_flush(s: *us_socket_t) void;

    extern fn us_socket_open(s: *us_socket_t, is_client: i32, ip: ?[*]const u8, ip_length: i32) ?*us_socket_t;
    extern fn us_socket_pause(s: *us_socket_t) void;
    extern fn us_socket_resume(s: *us_socket_t) void;
    extern fn us_socket_close(s: *us_socket_t, code: us_socket_t.CloseCode, reason: ?*anyopaque) ?*us_socket_t;
    extern fn us_socket_shutdown(s: *us_socket_t) void;
    extern fn us_socket_is_closed(s: *us_socket_t) i32;
    extern fn us_socket_shutdown_read(s: *us_socket_t) void;
    extern fn us_socket_is_shut_down(s: *us_socket_t) i32;
    extern fn us_socket_sendfile_needs_more(socket: *us_socket_t) void;
    extern fn us_socket_get_fd(s: *us_socket_t) uws.LIBUS_SOCKET_DESCRIPTOR;
    extern fn us_socket_verify_error(s: *us_socket_t) uws.us_bun_verify_error_t;
    extern fn us_socket_get_error(s: *us_socket_t) c_int;
    extern fn us_socket_is_established(s: *us_socket_t) i32;

    extern fn us_socket_adopt(s: *us_socket_t, group: *SocketGroup, kind: u8, old_ext_size: i32, ext_size: i32) ?*us_socket_t;
    /// ssl_ctx is required (the whole point); sni may be null.
    extern fn us_socket_adopt_tls(s: *us_socket_t, group: *SocketGroup, kind: u8, ssl_ctx: *uws.SslCtx, sni: ?[*:0]const u8, old_ext_size: i32, ext_size: i32) ?*us_socket_t;
    extern fn us_socket_start_tls_handshake(s: *us_socket_t) void;
};

pub const us_socket_stream_buffer_t = extern struct {
    list_ptr: ?[*]u8 = null,
    list_cap: usize = 0,
    list_len: usize = 0,
    total_bytes_written: usize = 0,
    cursor: usize = 0,

    pub fn update(this: *us_socket_stream_buffer_t, stream_buffer: bun.io.StreamBuffer) void {
        if (stream_buffer.list.capacity > 0) {
            this.list_ptr = stream_buffer.list.items.ptr;
        } else {
            this.list_ptr = null;
        }
        this.list_len = stream_buffer.list.items.len;
        this.list_cap = stream_buffer.list.capacity;
        this.cursor = stream_buffer.cursor;
    }
    pub fn wrote(this: *us_socket_stream_buffer_t, written: usize) void {
        this.total_bytes_written +|= written;
    }

    pub fn toStreamBuffer(this: *us_socket_stream_buffer_t) bun.io.StreamBuffer {
        return .{
            .list = if (this.list_ptr) |buffer_ptr| .{ .allocator = bun.default_allocator, .items = buffer_ptr[0..this.list_len], .capacity = this.list_cap, .pointer_stability = .{} } else .{ .allocator = bun.default_allocator, .items = &.{}, .capacity = 0, .pointer_stability = .{} },
            .cursor = this.cursor,
        };
    }

    pub fn deinit(this: *us_socket_stream_buffer_t) void {
        if (this.list_ptr) |buffer| {
            bun.default_allocator.free(buffer[0..this.list_cap]);
        }
    }
};

export fn us_socket_free_stream_buffer(buffer: *us_socket_stream_buffer_t) void {
    buffer.deinit();
}
// us_socket_buffered_js_write moved to src/runtime/socket/uws_jsc.zig

const std = @import("std");

const bun = @import("bun");
const BoringSSL = bun.BoringSSL.c;

const uws = bun.uws;
const SocketGroup = uws.SocketGroup;
const SocketKind = uws.SocketKind;
