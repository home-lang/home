import {test} from 'bun:test'
test('capture rejected native fixture diagnostics', () => {
 const result=Bun.spawnSync([process.execPath,'build-support/bundle-native-modules.ts','zig-out/fs-process-port-2026-10-09/full-bad-class-fixture','zig-out/fs-process-port-2026-10-09/full-bad-class-fixture/output'],{cwd:process.cwd(),stdin:'ignore',stdout:'pipe',stderr:'pipe',timeout:15000})
 console.log(JSON.stringify({exec:process.execPath,exit:result.exitCode,stderr:result.stderr.toString(),stdout:result.stdout.toString(),nodeEnv:process.env.NODE_ENV}))
})

test('capture explicit sync and asynchronous errors', () => {
 for(const script of ['require("fs").writeSync(2,"SYNC_BYTES\\n");process.exitCode=1','await (async()=>{throw Error("ASYNC_ERROR")})().catch(error=>{require("fs").writeSync(2,error.stack);process.exitCode=1})','throw Error("THROWN_ERROR")']) {
  const result=Bun.spawnSync([process.execPath,'-e',script],{stdin:'ignore',stdout:'pipe',stderr:'pipe'})
  console.log(JSON.stringify({script,exit:result.exitCode,stderr:result.stderr.toString(),stdout:result.stdout.toString()}))
 }
})

test('capture test-specific environment keys',async()=>{const keys=await Bun.file('zig-out/fs-process-port-2026-10-09/parent-env-keys.json').json(); console.log(JSON.stringify({added:Object.keys(process.env).filter(key=>!keys.includes(key))}));})

test('capture successful child bytes',async()=> {
 const args=[process.execPath,'-e','console.log("STDOUT_BYTES");require("fs").writeSync(2,"STDERR_BYTES")']
 const sync=Bun.spawnSync(args,{stdin:'ignore',stdout:'pipe',stderr:'pipe'})
 const asyncProcess=Bun.spawn(args,{stdin:'ignore',stdout:'pipe',stderr:'pipe'})
 console.log(JSON.stringify({syncExit:sync.exitCode,syncOut:sync.stdout.toString(),syncErr:sync.stderr.toString(),asyncExit:await asyncProcess.exited,asyncOut:await new Response(asyncProcess.stdout).text(),asyncErr:await new Response(asyncProcess.stderr).text(),fn:Bun.spawnSync.toString()}))
})
