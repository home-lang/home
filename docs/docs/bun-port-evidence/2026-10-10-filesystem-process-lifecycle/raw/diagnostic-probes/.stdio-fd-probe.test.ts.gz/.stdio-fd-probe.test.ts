import {test} from 'bun:test'
import {fstatSync} from 'node:fs'
test('inspect stdio descriptor validity',()=> {
 for (let fd=0;fd<3;fd++) {try {const s=fstatSync(fd);console.log(JSON.stringify({fd,valid:true,mode:s.mode}))}catch(error){console.log(JSON.stringify({fd,valid:false,code:error.code}))}}
 for(const stdin of ['ignore','inherit','pipe']) {
  try {const r=Bun.spawnSync(['/bin/sh','-c','echo OUT;echo ERR >&2'],{stdin,stdout:'pipe',stderr:'pipe'});console.log(JSON.stringify({stdin,pid:r.pid,exit:r.exitCode,out:r.stdout.toString(),err:r.stderr.toString()}))}catch(error){console.log(JSON.stringify({stdin,error:error.code}))}
 }
})
