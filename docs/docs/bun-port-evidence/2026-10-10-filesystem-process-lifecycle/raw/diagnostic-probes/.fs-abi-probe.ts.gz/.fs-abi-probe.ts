import { existsSync, mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import path from 'node:path'
import { replaceModuleLiteral } from './native_module_abi'

const root = path.resolve(import.meta.dir, '..')
const nativeBuild = path.dirname(process.env.HOME_BUN_OBJ_ROOT || '/Users/chris/Code/bun/build/release/obj')
const available = existsSync(path.join(nativeBuild, 'codegen/InternalModuleRegistryConstants.h'))
const read = (file: string) => readFileSync(file, 'utf8')
const ownedBuiltinNames = ['NodeUrl', 'NodeWorkerThreads', 'NodeQuerystring', 'NodeAssert', 'NodeAssertStrict', 'NodeEvents', 'NodeAsyncHooks', 'NodeDgram', 'NodeNet', 'NodeTimers', 'NodeTimersPromises', 'InternalAsyncHooks', 'InternalAsyncHooksTick', 'NodePath', 'NodePathPosix', 'NodePathWin32', 'NodeUtil', 'NodeDomain', 'NodePunycode', 'NodeDiagnosticsChannel', 'NodeOS', 'NodeDNS', 'NodeDNSPromises', 'InternalShared', 'InternalErrors', 'InternalValidators', 'InternalUtilInspect', 'InternalUtilColors', 'InternalUtilDeprecate', 'InternalUtilMime', 'InternalPrimordials', 'InternalStreamsAddAbortSignal', 'InternalStreamsCompose', 'InternalStreamsDestroy', 'InternalStreamsDuplex', 'InternalStreamsDuplexify', 'InternalStreamsDuplexpair', 'InternalStreamsEndOfStream', 'InternalStreamsFrom', 'InternalStreamsIterBroadcast', 'InternalStreamsIterClassic', 'InternalStreamsIterConsumers', 'InternalStreamsIterDuplex', 'InternalStreamsIterFrom', 'InternalStreamsIterPull', 'InternalStreamsIterPush', 'InternalStreamsIterRingbuffer', 'InternalStreamsIterShare', 'InternalStreamsIterTransform', 'InternalStreamsIterTypes', 'InternalStreamsIterUtils', 'InternalStreamsLazyTransform', 'InternalStreamsLegacy', 'InternalStreamsNativeReadable', 'InternalStreamsOperators', 'InternalStreamsPassthrough', 'InternalStreamsPipeline', 'InternalStreamsReadable', 'InternalStreamsState', 'InternalStreamsTransform', 'InternalStreamsUtils', 'InternalStreamsWritable', 'InternalWebstreamsAdapters', 'NodeStreamConsumers', 'NodeStreamIter', 'NodeStreamPromises', 'NodeStream', 'NodeStreamWeb', 'NodeFS', 'NodeFSPromises', 'NodeChildProcess', 'NodeCluster', 'InternalFSBinding', 'InternalFSCpSync', 'InternalFSCp', 'InternalFSGlob', 'InternalFSStreams', 'InternalFSWatch', 'InternalFSWatchfile']
const units = ['UnifiedSource-src_jsc_bindings-1.cpp', 'UnifiedSource-src_jsc_bindings_webcore-3.cpp', 'UnifiedSource-src_jsc_bindings_webcore-4.cpp', 'UnifiedSource-src_jsc_bindings_webcore-5.cpp', 'UnifiedSource-src_jsc_bindings-0.cpp', 'UnifiedSource-src_jsc_bindings_webcore-2.cpp', 'UnifiedSource-src_jsc_bindings_webcore-1.cpp', 'UnifiedSource-src_jsc_bindings_webcore-0.cpp', 'UnifiedSource-src_jsc_bindings-4.cpp', 'UnifiedSource-src_jsc_bindings-3.cpp', 'UnifiedSource-src_jsc_bindings-5.cpp', 'UnifiedSource-src_jsc_modules-0.cpp']

function createNativeFixture(temporary: string) {
  const codegen = path.join(temporary, 'codegen')
  const webcore = path.join(temporary, 'webcore')
  mkdirSync(codegen)
  mkdirSync(path.join(temporary, 'js'))
  mkdirSync(webcore)
  mkdirSync(path.join(temporary, 'unified'))
  for (const file of ['InternalModuleRegistry+enum.h', 'GeneratedJS2Native.h', 'ErrorCode+List.h', 'InternalModuleRegistryConstants.h', 'NativeModuleImpl.h', 'ZigGeneratedClasses.cpp']) {
    writeFileSync(path.join(codegen, file), read(path.join(nativeBuild, 'codegen', file)))
  }
  writeFileSync(
    path.join(temporary, 'js/internal-for-testing.js'),
    read(path.join(nativeBuild, 'js/internal-for-testing.js')),
  )
  for (const name of units) {
    const unifiedPath = path.join(nativeBuild, 'unified', name)
    // Relative includes belong to the original unified directory, not this
    // temporary build root. Isolate just the selected sources and class headers
    // so ABI-drift tests never modify the external tree.
    const unified = read(unifiedPath).replace(/^#include "([^"]+)"$/gm, (_, relative) => {
      const externalSource = path.resolve(path.dirname(unifiedPath), relative)
      const basename = path.basename(relative)
      if (['MessagePort.cpp', 'MessagePortPipe.cpp', 'Worker.cpp', 'BunWorkerGlobalScope.cpp', 'JSMessagePort.cpp', 'JSWorker.cpp', 'BunAnalyzeTranspiledModule.cpp', 'JSAbortSignalCustom.cpp', 'BroadcastChannel.cpp', 'BunBroadcastChannelRegistry.cpp', 'JSBroadcastChannel.cpp', 'MessageEvent.cpp', 'JSMessageEvent.cpp', 'ScriptExecutionContext.cpp', 'NodeAsyncHooks.cpp', 'WebSocket.cpp', 'JSWebSocket.cpp', 'AsyncContextFrame.cpp', 'IPC.cpp', 'Path.cpp', 'NodeValidator.cpp', 'stringWidth.cpp', 'NodeUtilTypesModule.cpp', 'JSMIMEParams.cpp', 'sliceAnsi.cpp', 'stripANSI.cpp', 'wrapAnsi.cpp', 'napi_finalizer.cpp', 'NodeModuleModule.cpp', 'ReadableStream.cpp', 'JSReadableStream.cpp'].includes(basename)) {
        const header = basename === 'JSAbortSignalCustom.cpp' ? 'AbortSignal.h' : basename.replace(/\.cpp$/, '.h')
        writeFileSync(path.join(webcore, basename), readFileSync(externalSource))
        if (basename !== 'IPC.cpp') writeFileSync(path.join(webcore, header), readFileSync(path.join(path.dirname(externalSource), header)))
        return `#include ${JSON.stringify(path.join(webcore, basename))}`
      }
      return `#include ${JSON.stringify(externalSource)}`
    })
    writeFileSync(path.join(temporary, 'unified', name), unified)
  }
  return { codegen, webcore }
}

function generate(nativeRoot: string, output: string) {
  const result = Bun.spawnSync([process.execPath, path.join(import.meta.dir, 'bundle-native-modules.ts'), nativeRoot, output], {
    cwd: root, stdin: 'ignore', stdout: 'pipe', stderr: 'pipe', timeout: 15000,
  })
  if (result.exitCode !== 0 && result.stderr.length === 0) console.error('GENERATOR_DIAGNOSTIC', JSON.stringify({ exit: result.exitCode, signal: result.signalCode, stdout: result.stdout.toString(), nativeRoot }))
  return result
}


const temporary = path.join(root, 'zig-out/fs-process-port-2026-10-09/full-bad-class-fixture')
mkdirSync(temporary)
const {codegen} = createNativeFixture(temporary)
const source = path.join(codegen,'ZigGeneratedClasses.cpp')
writeFileSync(source,read(source).replace('case 0: return JSValue::encode(jsBoolean(dynamicDowncast<WebCore::JSBlob>', 'case 7: return JSValue::encode(jsBoolean(dynamicDowncast<WebCore::JSBlob>'))
const result=generate(temporary,path.join(temporary,'output'))
console.log(JSON.stringify({exec:process.execPath,exit:result.exitCode,stderr:result.stderr.toString(),stdout:result.stdout.toString()}))
