var $;
const { SafeArrayIterator } = (__intrinsic__getInternalField(__intrinsic__internalModuleRegistry, 36) || __intrinsic__createInternalModuleById(36));

const ArrayIsArray = Array.isArray;
const ArrayPrototypePush = Array.prototype.push;

function aggregateTwoErrors(innerError: Error | undefined, outerError: Error & { errors?: Error[] }) {
  if (innerError && outerError && innerError !== outerError) {
    const outerErrors = outerError.errors;
    if (ArrayIsArray(outerErrors)) {
      // If `outerError` is already an `AggregateError`.
      ArrayPrototypePush.__intrinsic__call(outerErrors, innerError);
      return outerError;
    }
    const err = new AggregateError(new SafeArrayIterator([outerError, innerError]), outerError.message);
    err.code = outerError.code;
    return err;
  }
  return innerError || outerError;
}

$ = {
  aggregateTwoErrors,
};
;$$EXPORT$$($).$$EXPORT_END$$;
