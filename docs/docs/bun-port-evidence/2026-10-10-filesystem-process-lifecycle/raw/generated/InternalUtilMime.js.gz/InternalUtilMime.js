(function () {"use strict";
// zig-out/fs-process-port-2026-10-09/generated/InternalUtilMime.mts
var $, { MIMEParams, MIMEType } = @lazy(26);
$ = {
  MIMEParams,
  MIMEType
};
return $

})
