(function () {"use strict";
// zig-out/fs-process-port-2026-10-09/generated/InternalFSBinding.mts
var $;
$ = @lazy(9);
return $

})
