(function () {"use strict";
// zig-out/fs-process-port-2026-10-09/generated/NodePathPosix.mts
var $;
$ = (@getInternalField(@internalModuleRegistry, 125) || @createInternalModuleById(125)).posix;
return $

})
