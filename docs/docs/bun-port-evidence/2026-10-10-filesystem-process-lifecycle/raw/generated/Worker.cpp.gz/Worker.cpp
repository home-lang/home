#line 1 "/Users/chris/Code/Home/lang-bun-port/packages/runtime/upstream/src/jsc/bindings/webcore/Worker.cpp"
/*
 * Copyright (C) 2008-2017 Apple Inc. All rights reserved.
 * Copyright (C) 2009 Google Inc. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY APPLE INC. ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL APPLE INC. OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
 * OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "config.h"
#include "Worker.h"

#include "ErrorCode.h"
#include "ErrorEvent.h"
#include "Event.h"
#include "EventNames.h"
#include "StructuredSerializeOptions.h"
#include <JavaScriptCore/IteratorOperations.h>
#include <JavaScriptCore/ScriptCallStack.h>
#include <wtf/TZoneMallocInlines.h>
#include <wtf/Scope.h>
#include "SerializedScriptValue.h"
#include "ScriptExecutionContext.h"
#include <JavaScriptCore/JSMap.h>
#include <JavaScriptCore/JSModuleLoader.h>
#include "MessageEvent.h"
#include "BunWorkerGlobalScope.h"
#include "CloseEvent.h"
#include "JSMessagePort.h"
#include "HomeMessagePortLifecycle.h"
#include "HomeWorkerSnapshots.h"
#include "JSBroadcastChannel.h"
#include "EventLoopTask.h"
#include <wtf/HashSet.h>
#include <wtf/NeverDestroyed.h>
#include <memory>

namespace WebCore {

WTF_MAKE_TZONE_ALLOCATED_IMPL(Worker);

// The virtual parent endpoint is owned by the native Worker transport. Its
// peer is a real transferable MessagePort, created on the worker thread before
// user code. Keep this state outside Worker so linked class layouts do not drift.
struct HomeParentPort {
    Ref<MessagePortPipe> pipe;
    Ref<MessagePort> port;
    bool ready { false };
};

struct HomeParentPortRegistry {
    Lock lock;
    HashMap<Worker*, std::unique_ptr<HomeParentPort>> ports;
    HashMap<MessagePortPipe*, Worker*> owners;
};

static HomeParentPortRegistry& homeParentPortRegistry()
{
    static NeverDestroyed<HomeParentPortRegistry> registry;
    return registry.get();
}

bool WorkerParentPort::send(MessagePortPipe& pipe, uint8_t side, MessageWithMessagePorts&& message)
{
    if (side != 1)
        return false;
    auto& registry = homeParentPortRegistry();
    Locker locker { registry.lock };
    auto it = registry.owners.find(&pipe);
    if (it == registry.owners.end())
        return false;
    // Registry removal precedes release of the worker's create-time reference.
    // Enqueue while holding that lifetime boundary; no JS executes here.
    it->value->enqueueToParent(WTF::move(message));
    return true;
}

void WorkerParentPort::startForGlobalListener(ScriptExecutionContext& context)
{
    auto& registry = homeParentPortRegistry();
    Locker locker { registry.lock };
    for (auto& entry : registry.ports) {
        if (entry.key->clientIdentifier() == context.identifier()) {
            entry.value->port->start();
            return;
        }
    }
}

void WorkerParentPort::forwardGlobalEvent(MessagePort& port, ScriptExecutionContext& context, MessageEvent& event)
{
    auto* global = defaultGlobalObject(context.globalObject());
    if (!global || global->isShuttingDown()
        || Zig::GlobalObject::scriptExecutionStatus(global, global) != ScriptExecutionStatus::Running
        || !global->globalEventScope->hasActiveEventListeners(event.type()))
        return;
    {
        auto& registry = homeParentPortRegistry();
        Locker locker { registry.lock };
        auto it = registry.owners.find(port.pipe());
        if (it == registry.owners.end() || it->value->clientIdentifier() != context.identifier())
            return;
    }
    // MessageEvent::create already deserialized once and rooted its cached
    // data. Share that value and the same transferred endpoints with the Web
    // Worker event surface; never deserialize the transfer list a second time.
    MessageEvent::Init init;
    init.data = event.cachedData().getValue(jsUndefined());
    init.ports = event.ports();
    auto forwarded = MessageEvent::create(event.type(), WTF::move(init), Event::IsTrusted::Yes);
    global->globalEventScope->dispatchEvent(forwarded);
}

extern "C" void Home__Worker__prepareParentPort(Worker* worker, Zig::GlobalObject* global)
{
    auto pipe = MessagePortPipe::create();
    auto port = MessagePort::entangle(*global->scriptExecutionContext(), TransferredMessagePort { pipe.copyRef(), 1 });
    {
        auto& registry = homeParentPortRegistry();
        Locker locker { registry.lock };
        RELEASE_ASSERT(!registry.ports.contains(worker));
        registry.owners.add(pipe.ptr(), worker);
        registry.ports.add(worker, std::make_unique<HomeParentPort>(HomeParentPort { WTF::move(pipe), WTF::move(port) }));
    }
    // Atomically migrate pre-start messages before admitting direct pipe sends.
    worker->drainToWorker(*global->scriptExecutionContext());
}

extern "C" void Home__Worker__closeParentPort(Worker* worker)
{
    std::unique_ptr<HomeParentPort> state;
    {
        auto& registry = homeParentPortRegistry();
        Locker locker { registry.lock };
        state = registry.ports.take(worker);
        if (state)
            registry.owners.remove(state->pipe.ptr());
    }
    // Closing transferred endpoints can post other tasks. Destruct outside the
    // registry lock, on the worker's owning thread, while its VM is still alive.
    if (state)
        state->pipe->close(0);
}

// A stopped parent drains only these native exit-cleanup tasks. Other C++
// callbacks may own thread-affine resources and are not safe to execute here.
struct HomeWorkerExitTaskRegistry {
    Lock lock;
    HashSet<EventLoopTask*> tasks;
};

static HomeWorkerExitTaskRegistry& homeWorkerExitTaskRegistry()
{
    static NeverDestroyed<HomeWorkerExitTaskRegistry> registry;
    return registry.get();
}

struct HomeWorkerExitTaskMarker {
    EventLoopTask* task { nullptr };
    ~HomeWorkerExitTaskMarker()
    {
        auto& registry = homeWorkerExitTaskRegistry();
        Locker locker { registry.lock };
        registry.tasks.remove(task);
    }
};

extern "C" bool Home__Worker__isExitTask(EventLoopTask* task)
{
    auto& registry = homeWorkerExitTaskRegistry();
    Locker locker { registry.lock };
    return registry.tasks.contains(task);
}

extern "C" void Home__Worker__performExitTask(Zig::GlobalObject* globalObject, EventLoopTask* task)
{
    RELEASE_ASSERT(globalObject->isShuttingDown());
    RELEASE_ASSERT(globalObject->scriptExecutionContext()->isContextThread());
    RELEASE_ASSERT(Home__Worker__isExitTask(task));
    // This narrowly marked callback runs no JS during shutdown. Do not route
    // through the ordinary JS exception bridge: an existing termination
    // exception must not turn native resource cleanup into a second failure.
    task->performTask(*globalObject->scriptExecutionContext());
}

// ---- Native FFI --------------------------------------------------------------------------------
// The native WebWorker struct is owned by this Worker (freed in ~Worker) and drives the worker
// thread. See src/jsc/web_worker.rs for the matching side of each entry point.
extern "C" {

// Allocate the native WebWorker, take a keep-alive on the parent event loop, and spawn the worker
// thread. Returns null (and sets errorMessage) on any failure; nothing needs cleanup in that case.
void* WebWorker__create(
    Worker* worker,
    void* parent,
    BunString name,
    BunString url,
    BunString* errorMessage,
    uint32_t parentContextId,
    uint32_t contextId,
    bool miniMode,
    bool unrefByDefault,
    bool evalMode,
    StringImpl** argvPtr,
    size_t argvLen,
    bool defaultExecArgv,
    StringImpl** execArgvPtr,
    size_t execArgvLen,
    BunString* preloadModulesPtr,
    size_t preloadModulesLen);

// worker.terminate() — set requested_terminate, raise TerminationException in the worker VM,
// wake the worker loop. Parent thread only.
void WebWorker__notifyNeedTermination(void* worker);

// worker.ref()/.unref() — toggle the keep-alive on the parent event loop. Parent thread only.
void WebWorker__setRef(void* worker, bool ref);

// Release the keep-alive on the parent event loop. Called from the close task on the parent
// thread.
void WebWorker__releaseParentPollRef(void* worker);

// Free the native WebWorker struct. Called from ~Worker.
void WebWorker__destroy(void* worker);
Zig::GlobalObject* Home__Worker__parentGlobalForExit(void* worker);

} // extern "C"
// -------------------------------------------------------------------------------------------------

Worker::Worker(ScriptExecutionContext& context, WorkerOptions&& options)
    : EventTargetWithInlineData()
    , ContextDestructionObserver(&context)
    , m_options(WTF::move(options))
    , m_parentContextId(context.identifier())
    , m_clientIdentifier(ScriptExecutionContext::generateIdentifier())
{
}

ExceptionOr<Ref<Worker>> Worker::create(ScriptExecutionContext& context, const String& urlInit, WorkerOptions&& options)
{
    auto worker = adoptRef(*new Worker(context, WTF::move(options)));

    WTF::String url = urlInit;
    if (url.startsWith("file://"_s)) {
        WTF::URL urlObject = WTF::URL(url);
        if (urlObject.isValid()) {
            url = urlObject.fileSystemPath();
        } else {
            return Exception { TypeError, makeString("Invalid file URL: \""_s, urlInit, '"') };
        }
    }
    BunString urlStr = Bun::toString(url);
    BunString errorMessage = BunStringEmpty;
    BunString nameStr = Bun::toString(worker->m_options.name);

    auto& preloadModuleStrings = worker->m_options.preloadModules;
    Vector<BunString> preloadModules;
    preloadModules.reserveInitialCapacity(preloadModuleStrings.size());
    for (auto& str : preloadModuleStrings) {
        if (str.startsWith("file://"_s)) {
            WTF::URL urlObject = WTF::URL(str);
            if (!urlObject.isValid()) {
                return Exception { TypeError, makeString("Invalid file URL: \""_s, str, '"') };
            }
            // Replace in-place so the storage outlives the BunString borrow below.
            str = urlObject.fileSystemPath();
        }
        preloadModules.append(Bun::toString(str));
    }

    // try to ensure the cast from String* to StringImpl** is sane
    static_assert(sizeof(WTF::String) == sizeof(WTF::StringImpl*));
    std::span<WTF::StringImpl*> execArgv = worker->m_options.execArgv
                                               .transform([](Vector<String>& vec) -> std::span<WTF::StringImpl*> {
                                                   return { reinterpret_cast<WTF::StringImpl**>(vec.begin()), vec.size() };
                                               })
                                               .value_or(std::span<WTF::StringImpl*> {});

    // Take the worker-thread-held ref BEFORE spawning. The spawned thread will
    // eventually call dispatchExit(), whose posted task (running back on THIS
    // thread) drops this ref. If creation fails below we drop it ourselves.
    worker->ref();

    void* impl = WebWorker__create(
        worker.ptr(),
        bunVM(context.jsGlobalObject()),
        nameStr,
        urlStr,
        &errorMessage,
        static_cast<uint32_t>(worker->m_parentContextId),
        static_cast<uint32_t>(worker->m_clientIdentifier),
        worker->m_options.mini,
        worker->m_options.unref,
        worker->m_options.evalMode,
        reinterpret_cast<WTF::StringImpl**>(worker->m_options.argv.begin()),
        worker->m_options.argv.size(),
        !worker->m_options.execArgv.has_value(),
        execArgv.data(),
        execArgv.size(),
        preloadModules.begin(),
        preloadModules.size());

    preloadModuleStrings.clear();

    if (!impl) {
        worker->m_state.store(State::Closed);
        worker->deref(); // undo the thread-held ref above
        return Exception { TypeError, errorMessage.toWTFString(BunString::ZeroCopy) };
    }

    // Parent-thread-only field; the close task can't run until we return to
    // the event loop, so it's safe to set after the thread has been spawned.
    worker->impl_ = impl;

    return worker;
}

Worker::~Worker()
{
    if (impl_) {
        WebWorker__destroy(impl_);
    }
}

bool Worker::postTaskToParent(Function<void(ScriptExecutionContext&)>&& task)
{
    // By stable identifier, not pointer — postTaskTo locks the global map and
    // returns false if the parent context is gone. Safe from any thread.
    return ScriptExecutionContext::postTaskTo(m_parentContextId, WTF::move(task));
}

// ---- Parent-thread API ------------------------------------------------------

ExceptionOr<void> Worker::postMessage(JSC::JSGlobalObject& state, JSC::JSValue messageValue, StructuredSerializeOptions&& options)
{
    if (m_state.load() == State::Closed)
        return Exception { InvalidStateError, "Worker has been terminated"_s };

    Vector<RefPtr<MessagePort>> ports;
    auto serialized = SerializedScriptValue::create(state, messageValue, WTF::move(options.transfer), ports, SerializationForStorage::No, SerializationContext::WorkerPostMessage);
    if (serialized.hasException())
        return serialized.releaseException();

    ExceptionOr<Vector<TransferredMessagePort>> disentangledPorts = MessagePort::disentanglePorts(WTF::move(ports));
    if (disentangledPorts.hasException()) {
        return disentangledPorts.releaseException();
    }

    enqueueToWorker(MessageWithMessagePorts { serialized.releaseReturnValue(), disentangledPorts.releaseReturnValue() });
    return {};
}

void Worker::enqueueToWorker(MessageWithMessagePorts&& message)
{
    {
        auto& registry = homeParentPortRegistry();
        Locker portLocker { registry.lock };
        auto channel = registry.ports.find(this);
        if (channel != registry.ports.end() && channel->value->ready) {
            channel->value->pipe->send(0, WTF::move(message));
            return;
        }
        Locker locker { m_toWorker.lock };
        const auto state = m_state.load();
        // dispatchExit seals this inbox under the same lock before taking
        // its queued messages. A post racing shutdown either joins that
        // discarded batch or returns here without retaining its transfers.
        if (state >= State::Closing)
            return;
        m_toWorker.queue.append(WTF::move(message));
        // If the worker isn't Running yet, just buffer; fireEarlyMessages()
        // drains the inbox on the worker thread once it is. If a drain is
        // already scheduled, don't double-schedule.
        // drainScheduled is only set/cleared under the lock so the
        // load/store pair is not a race.
        if (state != State::Running || m_toWorker.drainScheduled.load(std::memory_order_relaxed))
            return;
        m_toWorker.drainScheduled.store(true, std::memory_order_relaxed);
    }
    bool posted = ScriptExecutionContext::postTaskTo(m_clientIdentifier, [protectedThis = Ref { *this }](ScriptExecutionContext& context) {
        protectedThis->drainToWorker(context);
    });
    if (!posted) {
        Locker locker { m_toWorker.lock };
        m_toWorker.drainScheduled.store(false, std::memory_order_relaxed);
    }
}

void Worker::enqueueToParent(MessageWithMessagePorts&& message)
{
    {
        Locker locker { m_toParent.lock };
        m_toParent.queue.append(WTF::move(message));
        if (m_toParent.drainScheduled.load(std::memory_order_relaxed))
            return;
        m_toParent.drainScheduled.store(true, std::memory_order_relaxed);
    }
    // By stable identifier — this runs on the worker thread, so don't touch
    // the parent's ScriptExecutionContext pointer directly.
    bool posted = postTaskToParent([protectedThis = Ref { *this }](ScriptExecutionContext& context) {
        protectedThis->drainToParent(context);
    });
    if (!posted) {
        Locker locker { m_toParent.lock };
        m_toParent.drainScheduled.store(false, std::memory_order_relaxed);
    }
}

// Shared drain loop for the two inboxes. Mirrors MessagePortPipe's
// drainAndDispatch (and Node's MessagePort::OnMessage): one task drains up to
// max(initial queue size, 1000) messages, running microtasks between each so
// queueMicrotask/Promise callbacks observe messages one at a time, then
// yields and reschedules if more remain.
//
// Unlike MessagePortPipe, Worker sides never transfer, so we don't need to
// re-check port identity each iteration — which lets us swap the whole inbox
// into a local deque under the lock and dispatch without contending with the
// sender. A sustained producer (e.g. a tight postMessage loop) would otherwise
// make every per-message pop a contended acquire.
template<typename Dispatch>
static inline bool drainInbox(Worker::MessageInbox& inbox, Zig::GlobalObject* globalObject, ScriptExecutionContext& context, Dispatch&& dispatch)
{
    size_t limit;
    Deque<MessageWithMessagePorts> batch;
    {
        Locker locker { inbox.lock };
        if (inbox.queue.isEmpty()) {
            inbox.drainScheduled.store(false, std::memory_order_relaxed);
            return false;
        }
        limit = std::max<size_t>(inbox.queue.size(), 1000);
        batch = std::exchange(inbox.queue, {});
    }

    while (true) {
        while (!batch.isEmpty()) {
            if (limit-- == 0) {
                // Yield to the rest of the event loop. Return the undrained
                // tail to the front of the inbox so it stays ahead of
                // anything enqueued concurrently; caller reschedules.
                Locker locker { inbox.lock };
                while (!batch.isEmpty())
                    inbox.queue.prepend(batch.takeLast());
                return true;
            }
            auto message = batch.takeFirst();

            auto ports = MessagePort::entanglePorts(context, WTF::move(message.transferredPorts));
            auto event = MessageEvent::create(*context.jsGlobalObject(), message.message.releaseNonNull(), nullptr, WTF::move(ports));
            dispatch(event.event);

            if (globalObject->drainMicrotasks()) {
                // Termination pending. Drop the rest — dispatch is a no-op
                // once m_terminateRequested is set (drainToParent), and the
                // worker thread is tearing down (drainToWorker).
                return false;
            }
        }

        // Batch exhausted — see if more arrived while we were dispatching.
        Locker locker { inbox.lock };
        if (inbox.queue.isEmpty()) {
            inbox.drainScheduled.store(false, std::memory_order_relaxed);
            return false;
        }
        if (limit == 0)
            return true; // budget spent; caller reschedules
        batch = std::exchange(inbox.queue, {});
    }
}

void Worker::drainToWorker(ScriptExecutionContext& context)
{
    {
        auto& registry = homeParentPortRegistry();
        Locker portLocker { registry.lock };
        auto channel = registry.ports.find(this);
        if (channel != registry.ports.end()) {
            Locker inboxLocker { m_toWorker.lock };
            while (!m_toWorker.queue.isEmpty())
                channel->value->pipe->send(0, m_toWorker.queue.takeFirst());
            channel->value->ready = true;
            m_toWorker.drainScheduled.store(false, std::memory_order_relaxed);
            return;
        }
    }
    auto* globalObject = uncheckedDowncast<Zig::GlobalObject>(context.jsGlobalObject());
    if (!globalObject) {
        Locker locker { m_toWorker.lock };
        m_toWorker.drainScheduled.store(false, std::memory_order_relaxed);
        return;
    }
    bool reschedule = drainInbox(m_toWorker, globalObject, context, [&](Event& event) {
        globalObject->globalEventScope->dispatchEvent(event);
    });
    if (reschedule) {
        ScriptExecutionContext::postTaskTo(m_clientIdentifier, [protectedThis = Ref { *this }](ScriptExecutionContext& ctx) {
            protectedThis->drainToWorker(ctx);
        });
    }
}

void Worker::drainToParent(ScriptExecutionContext& context)
{
    auto* globalObject = defaultGlobalObject(context.jsGlobalObject());
    if (!globalObject) {
        Locker locker { m_toParent.lock };
        m_toParent.drainScheduled.store(false, std::memory_order_relaxed);
        return;
    }
    bool reschedule = drainInbox(m_toParent, globalObject, context, [&](Event& event) {
        dispatchEvent(event);
    });
    if (reschedule) {
        postTaskToParent([protectedThis = Ref { *this }](ScriptExecutionContext& c) {
            protectedThis->drainToParent(c);
        });
    }
}

void Worker::terminate()
{
    if (m_terminateRequested.exchange(true))
        return;
    WebWorker__notifyNeedTermination(impl_);
}

void Worker::setKeepAlive(bool keepAlive)
{
    // Once terminate() has been called or the close task has started, the
    // worker no longer participates in the parent's liveness — the close
    // task is the last thing to touch parent_poll_ref.
    if (m_terminateRequested.load() || m_state.load() >= State::Closing)
        return;
    WebWorker__setRef(impl_, keepAlive);
}

void Worker::dispatchEvent(Event& event)
{
    // Suppress user-visible events once terminate() has been called or the
    // worker has closed. The close event itself bypasses this (dispatchExit
    // calls EventTargetWithInlineData::dispatchEvent directly) so that
    // `await worker.terminate()` still resolves.
    if (m_terminateRequested.load() || m_state.load() == State::Closed)
        return;
    EventTargetWithInlineData::dispatchEvent(event);
}

bool Worker::postTaskToWorkerGlobalScope(Function<void(ScriptExecutionContext&)>&& task)
{
    {
        Locker lock(m_pendingTasksMutex);
        switch (m_state.load()) {
        case State::Pending:
            // Worker VM not up yet; queue for fireEarlyMessages().
            m_pendingTasks.append(WTF::move(task));
            return true;
        case State::Running:
            break;
        case State::Closing:
        case State::Closed:
            // Worker VM is gone; drop immediately (silent no-op).
            // postMessage() goes through enqueueToWorker(), not here — the
            // only user is getHeapSnapshot().
            return false;
        }
    }
    return ScriptExecutionContext::postTaskTo(m_clientIdentifier, WTF::move(task));
}

// ---- Worker-thread entry points ---------------------------------------------

void Worker::dispatchOnline(Zig::GlobalObject* workerGlobalObject)
{
    // Pending→Running under the same lock postTaskToWorkerGlobalScope uses, so
    // a message post racing this transition either queues (drained below by
    // fireEarlyMessages) or posts directly — never both, never neither.
    //
    // This MUST happen BEFORE the open event is posted to the parent: the
    // parent's `online` handler may immediately call getHeapSnapshot() (or
    // anything else gated on isOnline() / postTaskToWorkerGlobalScope()). If
    // the state flip happens after the post, a fast parent thread can run the
    // open task while m_state is still Pending and observe
    // ERR_WORKER_NOT_RUNNING — flaky `await once(worker, "online");
    // worker.getHeapSnapshot()` in worker_threads.test.ts.
    {
        Locker lock(m_pendingTasksMutex);
        // Shutdown is terminal. Do not let a delayed startup notification
        // reopen the inbox or accept generic tasks after dispatchExit seals it.
        if (m_state.load() != State::Pending)
            return;
        m_state.store(State::Running);
    }

    postTaskToParent([protectedThis = Ref { *this }](ScriptExecutionContext&) {
        if (protectedThis->hasEventListeners(eventNames().openEvent)) {
            auto event = Event::create(eventNames().openEvent, Event::CanBubble::No, Event::IsCancelable::No);
            protectedThis->dispatchEvent(event);
        }
    });

    auto* thisContext = workerGlobalObject->scriptExecutionContext();
    if (!thisContext) {
        return;
    }
    RELEASE_ASSERT(&thisContext->vm() == &workerGlobalObject->vm());
    RELEASE_ASSERT(thisContext == workerGlobalObject->globalEventScope->scriptExecutionContext());
}

// Kick off the first drain of messages that arrived before the worker was
// online. A parent enqueue that observed State::Running (set in
// dispatchOnline, which runs just before fireEarlyMessages) may have already
// scheduled one — drainScheduled, set under the inbox lock, arbitrates.
static inline void workerScheduleInitialDrain(Worker& worker, Worker::MessageInbox& inbox, ScriptExecutionContext& ctx)
{
    {
        Locker locker { inbox.lock };
        if (inbox.queue.isEmpty() || inbox.drainScheduled.load(std::memory_order_relaxed))
            return;
        inbox.drainScheduled.store(true, std::memory_order_relaxed);
    }
    worker.drainToWorker(ctx);
}

void Worker::fireEarlyMessages(Zig::GlobalObject* workerGlobalObject)
{
    auto tasks = [&]() {
        Locker lock(m_pendingTasksMutex);
        return std::exchange(m_pendingTasks, {});
    }();
    auto* thisContext = workerGlobalObject->scriptExecutionContext();

    if (workerGlobalObject->globalEventScope->hasActiveEventListeners(eventNames().messageEvent)) {
        for (auto& task : tasks) {
            task(*thisContext);
        }
        workerScheduleInitialDrain(*this, m_toWorker, *thisContext);
    } else {
        thisContext->postTask([tasks = WTF::move(tasks), protectedThis = Ref { *this }](auto& ctx) mutable {
            for (auto& task : tasks) {
                task(ctx);
            }
            workerScheduleInitialDrain(protectedThis.get(), protectedThis->m_toWorker, ctx);
        });
    }
}

void Worker::dispatchErrorWithMessage(WTF::String message)
{
    postTaskToParent([protectedThis = Ref { *this }, message = message.isolatedCopy()](ScriptExecutionContext&) {
        ErrorEvent::Init init;
        init.message = message;

        auto event = ErrorEvent::create(eventNames().errorEvent, init, EventIsTrusted::Yes);
        protectedThis->dispatchEvent(event);
    });
}

bool Worker::dispatchErrorWithValue(Zig::GlobalObject* workerGlobalObject, JSValue value)
{
    auto serialized = SerializedScriptValue::create(*workerGlobalObject, value, SerializationForStorage::No, SerializationErrorMode::NonThrowing);
    if (!serialized)
        return false;

    return postTaskToParent([protectedThis = Ref { *this }, serialized](ScriptExecutionContext& context) {
        auto* globalObject = context.globalObject();
        auto& vm = JSC::getVM(globalObject);
        auto scope = DECLARE_THROW_SCOPE(vm);
        ErrorEvent::Init init;
        JSValue deserialized = serialized->deserialize(*globalObject, globalObject, SerializationErrorMode::NonThrowing);
        RETURN_IF_EXCEPTION(scope, );
        init.error = deserialized;

        auto event = ErrorEvent::create(eventNames().errorEvent, init, EventIsTrusted::Yes);
        protectedThis->dispatchEvent(event);
    });
}

bool Worker::dispatchExit(int32_t exitCode)
{
    // The worker VM has stopped, so its incoming messages cannot be delivered.
    // Release their transferred endpoints even if JS retains this Worker (or
    // an uncancelled native task retains it: https://github.com/home-lang/home/issues/465).
    // The Pending/Running transition and both task-admission paths observe
    // Closing under their respective locks. No path acquires these in reverse.
    Deque<MessageWithMessagePorts> dropped;
    {
        Locker pendingLocker { m_pendingTasksMutex };
        Locker inboxLocker { m_toWorker.lock };
        m_state.store(State::Closing);
        dropped = std::exchange(m_toWorker.queue, {});
        m_toWorker.drainScheduled.store(false, std::memory_order_relaxed);
    }
    // TransferredMessagePort destruction can close other pipes and post tasks.
    // It must not run under either Worker lock or the global contexts-map lock.
    dropped.clear();

    if (auto* parentGlobal = Home__Worker__parentGlobalForExit(impl_)) {
        // Nested parents keep their VM alive until every direct child has
        // finished shutdown. This lifetime barrier permits direct publication
        // of a specifically marked task, without a generic callback wrapper.
        auto marker = std::make_unique<HomeWorkerExitTaskMarker>();
        auto* markerPointer = marker.get();
        auto* task = new EventLoopTask([exitCode, marker = WTF::move(marker), protectedThis = Ref { *this }](ScriptExecutionContext& context) {
            (void)marker; // lifetime removes the task from the private registry
            auto* globalObject = defaultGlobalObject(context.globalObject());
            WorkerSnapshots::cancelForWorker(protectedThis.get(), context);
            if (!globalObject->isShuttingDown() && !context.isJSExecutionForbidden()
                && Zig::GlobalObject::scriptExecutionStatus(globalObject, globalObject) == ScriptExecutionStatus::Running
                && protectedThis->hasEventListeners(eventNames().closeEvent)) {
                auto event = CloseEvent::create(exitCode == 0, static_cast<unsigned short>(exitCode), exitCode == 0 ? "Worker terminated normally"_s : "Worker exited abnormally"_s);
                protectedThis->EventTargetWithInlineData::dispatchEvent(event);
            }
            protectedThis->m_state.store(State::Closed);
            WebWorker__releaseParentPollRef(protectedThis->impl_);
        });
        markerPointer->task = task;
        {
            auto& registry = homeWorkerExitTaskRegistry();
            Locker locker { registry.lock };
            registry.tasks.add(task);
        }
        // Match postTaskTo's pre-enqueue hook: the task's captured Ref exists
        // before the create-time ref is released, and release happens before
        // the parent can execute/destroy that task. No `this` access follows.
        deref();
        parentGlobal->queueTaskConcurrently(task);
        return true;
    }

    // Runs on the worker thread after its JSC VM has been torn down. Post the
    // close event to the parent; that task additionally releases parent_poll_ref
    // (parent-thread-only).
    //
    // This remaining path targets a main-thread parent. If its context is
    // already gone, retain the existing failure behavior: do not drop the
    // final Worker ref on the worker thread and destroy EventTarget there.
    // General main-thread queued-task cancellation remains separate work.
    //
    // The create-time ref (taken in create() to keep `this` alive while the
    // worker thread runs) is released via the `betweenLookupAndEnqueue` hook —
    // i.e. after the parent context is found-live and the lambda's captured
    // `Ref` exists, but BEFORE the task is enqueued. Once enqueued the parent
    // can run-and-destroy the lambda (dropping `protectedThis`) and sweep the
    // JSWorker before this frame resumes; deref()ing after that point can be
    // the last ref and run ~Worker on the worker thread (the 71d7f78f5e74
    // race). Releasing inside the lambda body instead would re-introduce the
    // shutdown leak that commit closed: when global_exit() destroys queued
    // close tasks without running them, the inner deref() never fires and the
    // WebWorker box leaks.
    return ScriptExecutionContext::postTaskTo(
        m_parentContextId,
        [this] { this->deref(); },
        [exitCode, protectedThis = Ref { *this }](ScriptExecutionContext& context) {
            WorkerSnapshots::cancelForWorker(protectedThis.get(), context);
            // Closing was published when the stopped inbox was discarded.
            // Closing → dispatch 'close' → Closed lets 'close'/'exit'
            // handlers observe threadId == -1 and isOnline() == false while
            // postMessage() (gated only on Closed) still accepts and drops the
            // message, matching browser/Node and pre-refactor behaviour.
            if (protectedThis->hasEventListeners(eventNames().closeEvent)) {
                auto event = CloseEvent::create(exitCode == 0, static_cast<unsigned short>(exitCode), exitCode == 0 ? "Worker terminated normally"_s : "Worker exited abnormally"_s);
                protectedThis->EventTargetWithInlineData::dispatchEvent(event);
            }

            protectedThis->m_state.store(State::Closed);
            WebWorker__releaseParentPollRef(protectedThis->impl_);
            // protectedThis (and the JSWorker GC cell, if still rooted) keep us
            // alive across the close-event dispatch; both deref on the parent
            // thread (lambda destruction here / GC sweep), so ~Worker never runs
            // on the worker thread.
        });
}

// ---- extern "C" shims (called from native code) ------------------------------

extern "C" void WebWorker__teardownJSCVM(Zig::GlobalObject* globalObject)
{
    auto& vm = JSC::getVM(globalObject);
    vm.setHasTerminationRequest();

    {
        auto scope = DECLARE_THROW_SCOPE(vm);
        {
            auto* moduleLoader = globalObject->moduleLoader();
            // JSModuleLoader::visitChildrenImpl iterates these maps on the GC
            // thread under cellLock(); take the same lock so clearing them
            // can't race a concurrent marker.
            WTF::Locker locker { moduleLoader->cellLock() };
            moduleLoader->clearAll();
        }
        globalObject->requireMap()->clear(globalObject);
        scope.exception(); // TODO: handle or assert none?
        vm.deleteAllCode(JSC::DeleteAllCodeEffort::PreventCollectionAndDeleteAllCode);
        gcUnprotect(globalObject);
        globalObject = nullptr;
    }

    vm.heap.collectNow(JSC::Sync, JSC::CollectionScope::Full);

    // Drop the single ref taken by `Zig__GlobalObject__create`
    // (`vmPtr->refSuppressingSaferCPPChecking()`), bringing the VM refcount
    // to zero — `~VM` runs here while the API lock is still held by this
    // thread. The worker thread acquires the API lock manually with no
    // extra VM ref (see `WebWorker::thread_main`), so a second `deref` would
    // run `~VM` twice / dereference the freed VM.
    vm.derefSuppressingSaferCPPChecking(); // NOLINT
}

extern "C" void WebWorker__dispatchExit(Worker* worker, int32_t exitCode)
{
    worker->dispatchExit(exitCode);
}

extern "C" void WebWorker__dispatchOnline(Worker* worker, Zig::GlobalObject* globalObject)
{
    worker->dispatchOnline(globalObject);
}

extern "C" void WebWorker__fireEarlyMessages(Worker* worker, Zig::GlobalObject* globalObject)
{
    worker->fireEarlyMessages(globalObject);
}

extern "C" void WebWorker__dispatchError(Zig::GlobalObject* globalObject, Worker* worker, BunString* message, JSC::EncodedJSValue errorValue)
{
    JSValue error = JSC::JSValue::decode(errorValue);
    WTF::String messageStr = message->transferToWTFString();
    ErrorEvent::Init init;
    init.message = messageStr.isolatedCopy();
    init.error = error;
    init.cancelable = false;
    init.bubbles = false;

    globalObject->globalEventScope->dispatchEvent(ErrorEvent::create(eventNames().errorEvent, init, EventIsTrusted::Yes));
    switch (worker->options().kind) {
    case WorkerOptions::Kind::Web:
        return worker->dispatchErrorWithMessage(WTF::move(messageStr));
    case WorkerOptions::Kind::Node:
        if (!worker->dispatchErrorWithValue(globalObject, error)) {
            // If serialization threw an error, use the string instead
            worker->dispatchErrorWithMessage(WTF::move(messageStr));
        }
        return;
    }
}

extern "C" WebCore::Worker* WebWorker__getParentWorker(void* bunVM);

JSC_DEFINE_HOST_FUNCTION(jsReceiveMessageOnPort, (JSGlobalObject * lexicalGlobalObject, CallFrame* callFrame))
{
    auto& vm = JSC::getVM(lexicalGlobalObject);
    auto scope = DECLARE_THROW_SCOPE(vm);

    if (callFrame->argumentCount() < 1) {
        throwTypeError(lexicalGlobalObject, scope, "receiveMessageOnPort needs 1 argument"_s);
        return {};
    }

    auto port = callFrame->argument(0);

    if (!port.isObject()) {
        return Bun::throwError(lexicalGlobalObject, scope, Bun::ErrorCode::ERR_INVALID_ARG_TYPE, "The \"port\" argument must be a MessagePort instance"_s);
    }

    if (auto* messagePort = dynamicDowncast<JSMessagePort>(port)) {
        RELEASE_AND_RETURN(scope, JSC::JSValue::encode(messagePort->wrapped().tryTakeMessage(lexicalGlobalObject)));
    } else if (dynamicDowncast<JSBroadcastChannel>(port)) {
        // TODO: support broadcast channels
        return JSC::JSValue::encode(jsUndefined());
    }

    return Bun::throwError(lexicalGlobalObject, scope, Bun::ErrorCode::ERR_INVALID_ARG_TYPE, "The \"port\" argument must be a MessagePort instance"_s);
}

JSValue createNodeWorkerThreadsBinding(Zig::GlobalObject* globalObject)
{
    VM& vm = globalObject->vm();

    auto scope = DECLARE_THROW_SCOPE(globalObject->vm());
    JSValue workerData = jsNull();
    JSValue threadId = jsNumber(0);
    RefPtr<MessagePort> parentPort;
    JSMap* environmentData = nullptr;

    if (auto* worker = WebWorker__getParentWorker(globalObject->bunVM())) {
        {
            auto& registry = homeParentPortRegistry();
            Locker locker { registry.lock };
            auto channel = registry.ports.find(worker);
            RELEASE_ASSERT(channel != registry.ports.end());
            parentPort = channel->value->port.ptr();
        }
        auto& options = worker->options();
        auto ports = MessagePort::entanglePorts(*ScriptExecutionContext::getScriptExecutionContext(worker->clientIdentifier()), WTF::move(options.dataMessagePorts));
        RefPtr<WebCore::SerializedScriptValue> serialized = WTF::move(options.workerDataAndEnvironmentData);
        // `workerDataAndEnvironmentData` is moved-from on the first call. If
        // this binding is created twice (lazy-init re-entry), `serialized` is
        // null and `->deserialize` would UB → garbage → SIGTRAP at the
        // uncheckedDowncast below (#53748 darwin). Guard both: skip the
        // deserialize on second call (workerData stays jsUndefined), and use a
        // checked cast so a non-Array deserialize result doesn't trap.
        if (serialized) {
            JSValue deserialized = serialized->deserialize(*globalObject, globalObject, WTF::move(ports));
            RETURN_IF_EXCEPTION(scope, {});
            // Should always be set to an Array of length 2 in the constructor in JSWorker.cpp
            if (auto* pair = dynamicDowncast<JSArray>(deserialized)) {
                ASSERT(pair->length() == 2);
                ASSERT(pair->canGetIndexQuickly(0u));
                ASSERT(pair->canGetIndexQuickly(1u));
                workerData = pair->getIndexQuickly(0);
                RETURN_IF_EXCEPTION(scope, {});
                auto environmentDataValue = pair->getIndexQuickly(1);
                // it might not be a Map if the parent had not set up environmentData yet
                environmentData = environmentDataValue ? dynamicDowncast<JSMap>(environmentDataValue) : nullptr;
                RETURN_IF_EXCEPTION(scope, {});
            } else {
                ASSERT_NOT_REACHED_WITH_MESSAGE("createNodeWorkerThreadsBinding: deserialized is not JSArray");
            }
        }

        // Main thread starts at 1
        threadId = jsNumber(worker->clientIdentifier() - 1);
    }
    if (!environmentData) {
        environmentData = JSMap::create(vm, globalObject->mapStructure());
        RETURN_IF_EXCEPTION(scope, {});
    }
    ASSERT(environmentData);
    globalObject->setNodeWorkerEnvironmentData(environmentData);

    JSObject* array = constructEmptyArray(globalObject, nullptr, 5);
    RETURN_IF_EXCEPTION(scope, {});
    array->putDirectIndex(globalObject, 0, workerData);
    array->putDirectIndex(globalObject, 1, threadId);
    array->putDirectIndex(globalObject, 2, JSFunction::create(vm, globalObject, 1, "receiveMessageOnPort"_s, jsReceiveMessageOnPort, ImplementationVisibility::Public, NoIntrinsic));
    array->putDirectIndex(globalObject, 3, environmentData);
    array->putDirectIndex(globalObject, 4, parentPort ? toJS(globalObject, globalObject, *parentPort) : jsNull());
    return array;
}

JSC_DEFINE_HOST_FUNCTION(jsFunctionPostMessage,
    (JSC::JSGlobalObject * leixcalGlobalObject, JSC::CallFrame* callFrame))
{
    JSC::VM& vm = leixcalGlobalObject->vm();
    auto scope = DECLARE_THROW_SCOPE(vm);

    Zig::GlobalObject* globalObject = dynamicDowncast<Zig::GlobalObject>(leixcalGlobalObject);
    if (!globalObject) [[unlikely]]
        return JSValue::encode(jsUndefined());

    Worker* worker = WebWorker__getParentWorker(globalObject->bunVM());
    if (worker == nullptr)
        return JSValue::encode(jsUndefined());

    JSC::JSValue value = callFrame->argument(0);
    JSC::JSValue options = callFrame->argument(1);

    Vector<JSC::Strong<JSC::JSObject>> transferList;

    if (options.isObject()) {
        JSC::JSValue transferListValue;
        // postMessage(message, sequence<object>) overload — second argument is the transfer list itself.
        bool isSequence = hasIteratorMethod(globalObject, options);
        RETURN_IF_EXCEPTION(scope, {});
        if (isSequence) {
            transferListValue = options;
        } else {
            // postMessage(message, { transfer }) overload.
            JSC::JSObject* optionsObject = options.getObject();
            transferListValue = optionsObject->get(globalObject, vm.propertyNames->transfer);
            RETURN_IF_EXCEPTION(scope, {});
        }
        if (transferListValue.isObject()) {
            forEachInIterable(globalObject, transferListValue, [&transferList](JSC::VM& vm, JSC::JSGlobalObject*, JSC::JSValue nextValue) {
                if (nextValue.isObject()) {
                    transferList.append(JSC::Strong<JSC::JSObject>(vm, nextValue.getObject()));
                }
            });
            RETURN_IF_EXCEPTION(scope, {});
        }
    }

    Vector<RefPtr<MessagePort>> ports;
    ExceptionOr<Ref<SerializedScriptValue>> serialized = SerializedScriptValue::create(*globalObject, value, WTF::move(transferList), ports, SerializationForStorage::No, SerializationContext::WorkerPostMessage);
    if (serialized.hasException()) {
        WebCore::propagateException(*globalObject, scope, serialized.releaseException());
        RELEASE_AND_RETURN(scope, {});
    }
    scope.assertNoException();

    ExceptionOr<Vector<TransferredMessagePort>> disentangledPorts = MessagePort::disentanglePorts(WTF::move(ports));
    if (disentangledPorts.hasException()) {
        WebCore::propagateException(*globalObject, scope, disentangledPorts.releaseException());
        RELEASE_AND_RETURN(scope, {});
    }
    scope.assertNoException();

    worker->enqueueToParent(MessageWithMessagePorts { serialized.releaseReturnValue(), disentangledPorts.releaseReturnValue() });

    return JSValue::encode(jsUndefined());
}

} // namespace WebCore
