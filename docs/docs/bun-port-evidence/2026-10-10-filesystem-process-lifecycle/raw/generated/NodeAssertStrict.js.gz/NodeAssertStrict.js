(function () {"use strict";
// zig-out/fs-process-port-2026-10-09/generated/NodeAssertStrict.mts
var $;
$ = (@getInternalField(@internalModuleRegistry, 103) || @createInternalModuleById(103)).strict;
return $

})
