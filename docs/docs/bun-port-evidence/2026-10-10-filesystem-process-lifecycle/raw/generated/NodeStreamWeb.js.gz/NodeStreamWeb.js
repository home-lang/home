(function () {"use strict";
// zig-out/fs-process-port-2026-10-09/generated/NodeStreamWeb.mts
var $;
$ = {
  ReadableStream: @ReadableStream,
  ReadableStreamDefaultReader: @ReadableStreamDefaultReader,
  ReadableStreamBYOBReader: @ReadableStreamBYOBReader,
  ReadableStreamBYOBRequest: @ReadableStreamBYOBRequest,
  ReadableByteStreamController: @ReadableByteStreamController,
  ReadableStreamDefaultController: @ReadableStreamDefaultController,
  TransformStream: @TransformStream,
  TransformStreamDefaultController: @TransformStreamDefaultController,
  WritableStream: @WritableStream,
  WritableStreamDefaultWriter: @WritableStreamDefaultWriter,
  WritableStreamDefaultController: @WritableStreamDefaultController,
  ByteLengthQueuingStrategy,
  CountQueuingStrategy,
  TextEncoderStream,
  TextDecoderStream,
  CompressionStream,
  DecompressionStream
};
return $

})
