var $;
// Hardcoded module "node:stream/promises"
$ = (__intrinsic__getInternalField(__intrinsic__internalModuleRegistry, 136) || __intrinsic__createInternalModuleById(136)).promises;
;$$EXPORT$$($).$$EXPORT_END$$;
