(function () {"use strict";
// zig-out/fs-process-port-2026-10-09/generated/InternalStreamsState.mts
var $, { validateInteger } = @getInternalField(@internalModuleRegistry, 86) || @createInternalModuleById(86), NumberIsInteger = Number.isInteger, MathFloor = Math.floor, defaultHighWaterMarkBytes = 65536, defaultHighWaterMarkObjectMode = 16;
function highWaterMarkFrom(options, isDuplex, duplexKey) {
  return options.highWaterMark != null ? options.highWaterMark : isDuplex ? options[duplexKey] : null;
}
function getDefaultHighWaterMark(objectMode = !1) {
  return objectMode ? defaultHighWaterMarkObjectMode : defaultHighWaterMarkBytes;
}
function setDefaultHighWaterMark(objectMode, value) {
  if (validateInteger(value, "value", 0), objectMode)
    defaultHighWaterMarkObjectMode = value;
  else
    defaultHighWaterMarkBytes = value;
}
function getHighWaterMark(state, options, duplexKey, isDuplex) {
  let hwm = highWaterMarkFrom(options, isDuplex, duplexKey);
  if (hwm != null) {
    if (!NumberIsInteger(hwm) || hwm < 0) {
      let name = isDuplex ? `options.${duplexKey}` : "options.highWaterMark";
      throw @makeErrorWithCode(120, name, hwm);
    }
    return MathFloor(hwm);
  }
  return getDefaultHighWaterMark(state.objectMode);
}
$ = {
  getHighWaterMark,
  getDefaultHighWaterMark,
  setDefaultHighWaterMark
};
return $

})
