(function () {"use strict";
// zig-out/fs-process-port-2026-10-09/generated/InternalAsyncHooksTick.mts
var $, tickInitHooks = [], nextAsyncId = 1;
$ = {
  tickInitHooks,
  newAsyncId() {
    return ++nextAsyncId;
  }
};
return $

})
