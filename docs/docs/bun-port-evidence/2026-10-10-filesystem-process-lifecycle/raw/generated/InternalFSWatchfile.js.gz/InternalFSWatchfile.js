(function () {"use strict";
// zig-out/fs-process-port-2026-10-09/generated/InternalFSWatchfile.mts
var $, EventEmitter = @getInternalField(@internalModuleRegistry, 114) || @createInternalModuleById(114), { getValidatedPath, throwIfNullBytesInFileName } = @getInternalField(@internalModuleRegistry, 86) || @createInternalModuleById(86), fs = @getInternalField(@internalModuleRegistry, 23) || @createInternalModuleById(23);
function emitStop(self) {
  self.emit("stop");
}

class StatWatcher extends EventEmitter {
  _handle;
  constructor(path, options) {
    super();
    this._handle = fs.watchFile(path, options, this.#onChange.bind(this));
  }
  #onChange(curr, prev) {
    this.emit("change", curr, prev);
  }
  start() {}
  stop() {
    if (!this._handle)
      return;
    process.nextTick(emitStop, this), this._handle.close(), this._handle = null;
  }
  ref() {
    this._handle?.ref();
  }
  unref() {
    this._handle?.unref();
  }
}
var statWatchers = /* @__PURE__ */ new Map;
function watchFile(filename, options, listener) {
  if (filename = getValidatedPath(filename), typeof options === "function")
    listener = options, options = {};
  if (typeof listener !== "function")
    throw @makeErrorWithCode(119, "listener", "function", listener);
  var stat = statWatchers.get(filename);
  if (!stat)
    stat = new StatWatcher(filename, options), statWatchers.set(filename, stat);
  return stat.addListener("change", listener), stat;
}
function unwatchFile(filename, listener) {
  filename = getValidatedPath(filename);
  var stat = statWatchers.get(filename);
  if (!stat)
    return throwIfNullBytesInFileName(filename);
  if (listener) {
    if (stat.removeListener("change", listener), stat.listenerCount("change") !== 0)
      return;
  } else
    stat.removeAllListeners("change");
  stat.stop(), statWatchers.delete(filename);
}
$ = { watchFile, unwatchFile };
return $

})
