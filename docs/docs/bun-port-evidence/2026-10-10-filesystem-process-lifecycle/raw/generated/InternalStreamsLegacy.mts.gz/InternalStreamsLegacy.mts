var $;
"use strict";

const EE = (__intrinsic__getInternalField(__intrinsic__internalModuleRegistry, 114) || __intrinsic__createInternalModuleById(114));
const { isArrayBufferView, isUint8Array } = (__intrinsic__getInternalField(__intrinsic__internalModuleRegistry, 164) || __intrinsic__createInternalModuleById(164));

const ReflectOwnKeys = Reflect.ownKeys;
const ArrayIsArray = Array.isArray;

function Stream(opts) {
  EE.__intrinsic__call(this, opts);
}
__intrinsic__toClass(Stream, "Stream", EE);

Stream.prototype.pipe = function (dest, options) {
  const source = this;

  function ondata(chunk) {
    if (dest.writable && dest.write(chunk) === false && source.pause) {
      source.pause();
    }
  }

  source.on("data", ondata);

  function ondrain() {
    if (source.readable && source.resume) {
      source.resume();
    }
  }

  dest.on("drain", ondrain);

  // If the 'end' option is not supplied, dest.end() will be called when
  // source gets the 'end' or 'close' events.  Only dest.end() once.
  if (!dest._isStdio && (!options || options.end !== false)) {
    source.on("end", onend);
    source.on("close", onclose);
  }

  let didOnEnd = false;
  function onend() {
    if (didOnEnd) return;
    didOnEnd = true;

    dest.end();
  }

  function onclose() {
    if (didOnEnd) return;
    didOnEnd = true;

    if (typeof dest.destroy === "function") dest.destroy();
  }

  // Don't leave dangling pipes when there are errors.
  function onerror(er) {
    cleanup();
    if (EE.listenerCount(this, "error") === 0) {
      this.emit("error", er);
    }
  }

  prependListener(source, "error", onerror);
  prependListener(dest, "error", onerror);

  // Remove all the event listeners that were added.
  function cleanup() {
    source.removeListener("data", ondata);
    dest.removeListener("drain", ondrain);

    source.removeListener("end", onend);
    source.removeListener("close", onclose);

    source.removeListener("error", onerror);
    dest.removeListener("error", onerror);

    source.removeListener("end", cleanup);
    source.removeListener("close", cleanup);

    dest.removeListener("close", cleanup);
  }

  source.on("end", cleanup);
  source.on("close", cleanup);

  dest.on("close", cleanup);
  dest.emit("pipe", source);

  // Allow for unix-like usage: A.pipe(B).pipe(C)
  return dest;
};

Stream.prototype.eventNames = function eventNames() {
  const names: PropertyKey[] = [];
  for (const key of ReflectOwnKeys(this._events)) {
    if (typeof this._events[key] === "function" || (ArrayIsArray(this._events[key]) && this._events[key].length > 0)) {
      names.push(key);
    }
  }
  return names;
};

function prependListener(emitter, event, fn) {
  // Sadly this is not cacheable as some libraries bundle their own
  // event emitter implementation with them.
  if (typeof emitter.prependListener === "function") return emitter.prependListener(event, fn);

  // This is a hack to make sure that our error handler is attached before any
  // userland ones.  NEVER DO THIS. This is here only because this code needs
  // to continue to work with older versions of Node.js that do not include
  // the prependListener() method. The goal is to eventually remove this hack.
  let events, existing;
  if (!(events = emitter._events) || !(existing = events[event])) emitter.on(event, fn);
  else if (ArrayIsArray(existing)) existing.unshift(fn);
  else events[event] = [fn, existing];
}

// Add helper methods to Stream
Stream._isArrayBufferView = isArrayBufferView;
Stream._isUint8Array = isUint8Array;
Stream._uint8ArrayToBuffer = function _uint8ArrayToBuffer(chunk) {
  return new __intrinsic__Buffer(chunk.buffer, chunk.byteOffset, chunk.byteLength);
};

$ = { Stream, prependListener } as unknown as {
  Stream: typeof import("node:stream").Stream;
  prependListener: typeof prependListener;
};
;$$EXPORT$$($).$$EXPORT_END$$;
