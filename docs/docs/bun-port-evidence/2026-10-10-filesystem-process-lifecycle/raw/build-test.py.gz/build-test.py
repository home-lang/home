from pathlib import Path
import subprocess,json,sys
root=Path.cwd();task=root/"zig-out/fs-process-port-2026-10-09"
commands=[('abi', ['bun', 'test', 'build-support/bundle-native-modules.test.ts', 'build-support/native_module_abi.test.ts', 'build-support/core_builtin_abi.test.ts']), ('build-home', ['zig-out/toolchains/zig-aarch64-macos-0.17.0-dev.2163+89ff10d56/zig', 'build', 'home', '-Doptimize=Debug', '-Dstrip=true', '-Denable_jsc=true', '-j1', '--summary', 'all'])]
rows=[]
for name,command in commands:
 with (task/(name+".log")).open("wb") as log:result=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT)
 rows.append({"label":name,"command":command,"exit":result.returncode});print(name,result.returncode,flush=True)
 if result.returncode:break
(task/"build-summary.json").write_text(json.dumps(rows,indent=2)+"\n")
sys.exit(0 if len(rows)==len(commands) and all(row["exit"]==0 for row in rows) else 1)
