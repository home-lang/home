#include "/Users/chris/Code/Home/lang-bun-port/zig-out/fs-process-port-2026-10-09/full-bad-class-fixture/webcore/NodeModuleModule.cpp"
#include "/Users/chris/Code/bun/src/jsc/modules/NodeTTYModule.cpp"
#include "/Users/chris/Code/Home/lang-bun-port/zig-out/fs-process-port-2026-10-09/full-bad-class-fixture/webcore/NodeUtilTypesModule.cpp"
#include "/Users/chris/Code/bun/src/jsc/modules/ObjectModule.cpp"
