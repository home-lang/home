(function (){"use strict";// build/release/tmp_modules/internal-for-testing.ts
var $, fmtBinding = @lazy(99), highlightJavaScript = (code) => fmtBinding(code, "highlight-javascript"), highlightJavaScriptRedacted = (code) => fmtBinding(code, "highlight-javascript-redacted"), escapePowershell = (code) => fmtBinding(code, "escape-powershell"), canonicalizeIP = @lazy(81), xxHash3ForTesting = @lazy(100), SQL = @lazy(1), patchInternals = {
  parse: @lazy(101),
  apply: @lazy(102),
  makeDiff: @lazy(103)
}, internalSourceMap = {
  fromVLQ: @lazy(104),
  toVLQ: @lazy(105),
  find: @lazy(106)
}, shellLex = @lazy(107), shellParse = @lazy(108), sslCtxLiveCount = @lazy(109), escapeRegExp = @lazy(110), escapeRegExpForPackageNameMatching = @lazy(111), shellInternals = {
  lex: (a, ...b) => shellLex(a.raw, b),
  parse: (a, ...b) => shellParse(a.raw, b),
  builtinDisabled: @lazy(112)
}, subprocessInternals = {
  injectStdioReadError: @lazy(113)
}, iniInternals = {
  parse: @lazy(114),
  loadNpmrc: @lazy(115)
}, cssInternals = {
  minifyTestWithOptions: @lazy(116),
  minifyErrorTestWithOptions: @lazy(117),
  testWithOptions: @lazy(118),
  prefixTestWithOptions: @lazy(119),
  minifyTest: @lazy(120),
  prefixTest: @lazy(121),
  _test: @lazy(122),
  attrTest: @lazy(123)
}, crash_handler = @lazy(124), upgrade_test_helpers = @lazy(125), install_test_helpers = @lazy(126), jscInternals = @lazy(127), nativeFrameForTesting = @lazy(128), memfd_create = @lazy(129), createStatsForIno = @lazy(130), setSyntheticAllocationLimitForTesting = @lazy(131), npm_manifest_test_helpers = @lazy(132), npa = @lazy(133), npmTag = @lazy(134), readTarball = @lazy(135), isArchitectureMatch = @lazy(136), isOperatingSystemMatch = @lazy(137), createSocketPair = @lazy(138), isModuleResolveFilenameSlowPathEnabled = @lazy(139), frameworkRouterInternals = @lazy(140), bindgen = @lazy(141), noOpForTesting = @lazy(142), isolatedModuleCacheSourceType = @lazy(143), Dequeue = @getInternalField(@internalModuleRegistry, 20) || @createInternalModuleById(20), exposedInternals = {
  "internal/streams/add-abort-signal": @getInternalField(@internalModuleRegistry, 47) || @createInternalModuleById(47),
  "internal/async_context_frame": @getInternalField(@internalModuleRegistry, 8) || @createInternalModuleById(8),
  "internal/async_hooks": @getInternalField(@internalModuleRegistry, 9) || @createInternalModuleById(9)
}, fs = (@getInternalField(@internalModuleRegistry, 115) || @createInternalModuleById(115)).@data, fsStreamInternals = {
  writeStreamFastPath(str) {
    return str[(@getInternalField(@internalModuleRegistry, 27) || @createInternalModuleById(27)).kWriteStreamFastPath];
  }
}, arrayBufferViewHasBuffer = @lazy(144), timerInternals = {
  timerClockMs: @lazy(145)
}, decodeURIComponentSIMD = @lazy(146), getDevServerDeinitCount = @lazy(147), getCounters = @lazy(148), linearFifoOrderedRemoveProbe = @lazy(149), hasNonReifiedStatic = @lazy(150), setSocketOptions = @lazy(151), structuredCloneAdvanced = @lazy(152), lsanDoLeakCheck = @lazy(153), isASANEnabled = @lazy(154), BunString_toThreadSafeRefCountDelta = @lazy(155), lowercaseHeaderNameSIMD = @lazy(156), getEventLoopStats = @lazy(157), hostedGitInfo = {
  parseUrl: @lazy(158),
  fromUrl: @lazy(159)
}, translateUVErrorToE = @lazy(160), translateNtStatusToE = @lazy(161), sysErrorNameFromLibuv = @lazy(162), sigactionLayout = @lazy(163), stringsInternals = {
  toUTF16AllocSentinel: @lazy(164)
}, fetchH2Internals = {
  liveCounts: @lazy(165)
}, fetchH3Internals = {
  liveCounts: @lazy(166)
}, fileSinkInternals = {
  liveCount: @lazy(167)
};
return{
  xxHash3ForTesting,
  upgrade_test_helpers,
  translateUVErrorToE,
  translateNtStatusToE,
  timerInternals,
  sysErrorNameFromLibuv,
  subprocessInternals,
  structuredCloneAdvanced,
  stringsInternals,
  sslCtxLiveCount,
  sigactionLayout,
  shellInternals,
  setSyntheticAllocationLimitForTesting,
  setSocketOptions,
  readTarball,
  patchInternals,
  npm_manifest_test_helpers,
  npmTag,
  npa,
  noOpForTesting,
  nativeFrameForTesting,
  memfd_create,
  lsanDoLeakCheck,
  lowercaseHeaderNameSIMD,
  linearFifoOrderedRemoveProbe,
  jscInternals,
  isolatedModuleCacheSourceType,
  isOperatingSystemMatch,
  isModuleResolveFilenameSlowPathEnabled,
  isArchitectureMatch,
  isASANEnabled,
  internalSourceMap,
  install_test_helpers,
  iniInternals,
  hostedGitInfo,
  highlightJavaScriptRedacted,
  highlightJavaScript,
  hasNonReifiedStatic,
  getEventLoopStats,
  getDevServerDeinitCount,
  getCounters,
  fsStreamInternals,
  fs,
  frameworkRouterInternals,
  fileSinkInternals,
  fetchH3Internals,
  fetchH2Internals,
  exposedInternals,
  escapeRegExpForPackageNameMatching,
  escapeRegExp,
  escapePowershell,
  decodeURIComponentSIMD,
  cssInternals,
  createStatsForIno,
  createSocketPair,
  crash_handler,
  canonicalizeIP,
  bindgen,
  arrayBufferViewHasBuffer,
  SQL,
  Dequeue,
  BunString_toThreadSafeRefCountDelta
};})
