from pathlib import Path
import subprocess,json,sys
root=Path.cwd();task=root/"zig-out/fs-process-port-2026-10-09"
assert "Build Summary: 33/33 steps succeeded" in (task/"build-native-final.log").read_text()
commands=[('native-stream-wrap', ['env', 'HOME_NATIVE_VM=1', 'BUN_DEBUG_QUIET_LOGS=1', '/Users/chris/Code/Home/lang-bun-port/zig-out/bin/home', 'run', '/Users/chris/Code/Home/lang-bun-port/tests/runtime/native-stream-wrap.test.mjs']), ('native-stream-cancellation', ['env', 'HOME_NATIVE_VM=1', 'BUN_DEBUG_QUIET_LOGS=1', '/Users/chris/Code/Home/lang-bun-port/zig-out/bin/home', 'run', '/Users/chris/Code/Home/lang-bun-port/tests/runtime/native-stream-cancellation.test.mjs']), ('native-diagnostics-lifecycle', ['env', 'HOME_NATIVE_VM=1', 'BUN_DEBUG_QUIET_LOGS=1', '/Users/chris/Code/Home/lang-bun-port/zig-out/bin/home', 'run', '/Users/chris/Code/Home/lang-bun-port/tests/runtime/native-diagnostics-lifecycle.test.mjs']), ('native-node-core-cli', ['env', 'HOME_NATIVE_VM=1', 'BUN_DEBUG_QUIET_LOGS=1', '/Users/chris/Code/Home/lang-bun-port/zig-out/bin/home', 'run', '/Users/chris/Code/Home/lang-bun-port/tests/runtime/native-node-core-cli.test.mjs']), ('native-spawn-sync-ipc', ['env', 'HOME_NATIVE_VM=1', 'BUN_DEBUG_QUIET_LOGS=1', '/Users/chris/Code/Home/lang-bun-port/zig-out/bin/home', 'run', '/Users/chris/Code/Home/lang-bun-port/tests/runtime/native-spawn-sync-ipc.test.mjs']), ('native-worker-fs-task-shutdown', ['env', 'HOME_NATIVE_VM=1', 'BUN_DEBUG_QUIET_LOGS=1', '/Users/chris/Code/Home/lang-bun-port/zig-out/bin/home', 'run', '/Users/chris/Code/Home/lang-bun-port/tests/runtime/native-worker-fs-task-shutdown.test.mjs']), ('corpus', ['python3', '/Users/chris/Code/Home/lang-bun-port/zig-out/fs-process-port-2026-10-09/run-corpus.py', 'final'])]
rows=[]
for name,command in commands:
 with (task/(name+".log")).open("wb") as log:result=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT)
 rows.append({"label":name,"command":command,"exit":result.returncode});print(name,result.returncode,flush=True)
 if result.returncode:break
(task/"final-test-summary.json").write_text(json.dumps(rows,indent=2)+"\n")
sys.exit(0 if len(rows)==len(commands) and all(row["exit"]==0 for row in rows) else 1)
