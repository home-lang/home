(function (target, fn) {"use strict";
  var cancelled = !1, iter;
  if (iter = fn.@call(target), fn = target = @undefined, !@isAsyncGenerator(iter) && typeof iter.next !== "function")
    @throwTypeError("Expected an async generator");
  var runningAsyncIteratorPromise;
  async function runAsyncIterator(controller) {
    var closingError, value, done, immediateTask;
    try {
      while (!cancelled && !done) {
        let promise = iter.next(controller);
        if (cancelled)
          return;
        if (@isPromise(promise) && @peekPromiseStatus(promise) === 1)
          clearImmediate(immediateTask), { value, done } = @peekPromiseSettledValue(promise);
        else if (immediateTask = setImmediate(() => immediateTask && controller?.flush?.(!0)), { value, done } = await promise, cancelled)
          return;
        if (!@isUndefinedOrNull(value)) {
          if (controller.write(value) < 0)
            clearImmediate(immediateTask), immediateTask = @undefined, await controller.flush(!0);
        }
      }
    } catch (e) {
      closingError = e;
    } finally {
      if (clearImmediate(immediateTask), immediateTask = @undefined, closingError?.code === "ERR_INVALID_THIS") {
        await iter?.return?.();
        return;
      }
      if (closingError)
        try {
          await iter.throw?.(closingError);
        } finally {
          throw iter = @undefined, closingError;
        }
      else if (await controller.end(), iter)
        await iter.return?.();
      iter = @undefined;
    }
  }
  return new @ReadableStream({
    type: "direct",
    cancel(reason) {
      if (cancelled = !0, iter) {
        let thisIter = iter;
        if (iter = @undefined, reason)
          return thisIter.throw?.(reason);
        else
          return thisIter?.return?.();
      }
    },
    close() {
      cancelled = !0;
    },
    async pull(controller) {
      if (!runningAsyncIteratorPromise) {
        let asyncIteratorPromise = runAsyncIterator(controller);
        runningAsyncIteratorPromise = asyncIteratorPromise;
        try {
          return await asyncIteratorPromise;
        } catch (e) {
          if (controller.write === @onReadableStreamDirectControllerClosed)
            return;
          throw e;
        } finally {
          if (runningAsyncIteratorPromise === asyncIteratorPromise)
            runningAsyncIteratorPromise = @undefined;
        }
      }
      return runningAsyncIteratorPromise;
    }
  });
})
