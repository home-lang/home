(function (controller) {"use strict";
  var stream = controller.@controlledReadableStream;
  if (!stream || @getByIdDirectPrivate(stream, "state") !== 4)
    return;
  if (controller._deferClose === -1)
    return;
  controller._deferClose = -1, controller._deferFlush = -1;
  var deferClose, deferFlush, asyncContext = stream.@asyncContext;
  if (asyncContext) {
    var prev = @getInternalField(@asyncContext, 0);
    @putInternalField(@asyncContext, 0, asyncContext);
  }
  try {
    var result = controller.@underlyingSource.pull(controller);
    if (result && @isPromise(result)) {
      if (controller._handleError === @undefined)
        controller._handleError = @handleDirectStreamErrorReject.bind(controller);
      @markPromiseAsHandled(result.catch(controller._handleError));
    }
  } catch (e) {
    return @handleDirectStreamErrorReject.@call(controller, e);
  } finally {
    if (deferClose = controller._deferClose, deferFlush = controller._deferFlush, controller._deferFlush = controller._deferClose = 0, asyncContext)
      @putInternalField(@asyncContext, 0, prev);
  }
  if (stream.@state === 1)
    return @createFulfilledPromise({ value: @undefined, done: !0 });
  if (stream.@state === 3)
    return @Promise.@reject(stream.@storedError);
  var promiseToReturn;
  if (controller._pendingRead === @undefined)
    controller._pendingRead = promiseToReturn = @newPromise();
  else
    promiseToReturn = @readableStreamAddReadRequest(stream);
  if (deferClose === 1) {
    var reason = controller._deferCloseReason;
    return controller._deferCloseReason = @undefined, @onCloseDirectStream.@call(controller, reason), promiseToReturn;
  }
  if (deferFlush === 1)
    @onFlushDirectStream.@call(controller);
  return promiseToReturn;
})
