(function () {"use strict";
// .zig-cache/o/55c0f6cd0ba051ac3e5c6af31725a0ab/native-modules/NodeStreamWeb.mts
var $;
$ = {
  ReadableStream: @ReadableStream,
  ReadableStreamDefaultReader: @ReadableStreamDefaultReader,
  ReadableStreamBYOBReader: @ReadableStreamBYOBReader,
  ReadableStreamBYOBRequest: @ReadableStreamBYOBRequest,
  ReadableByteStreamController: @ReadableByteStreamController,
  ReadableStreamDefaultController: @ReadableStreamDefaultController,
  TransformStream: @TransformStream,
  TransformStreamDefaultController: @TransformStreamDefaultController,
  WritableStream: @WritableStream,
  WritableStreamDefaultWriter: @WritableStreamDefaultWriter,
  WritableStreamDefaultController: @WritableStreamDefaultController,
  ByteLengthQueuingStrategy,
  CountQueuingStrategy,
  TextEncoderStream,
  TextDecoderStream,
  CompressionStream,
  DecompressionStream
};
return $

})
