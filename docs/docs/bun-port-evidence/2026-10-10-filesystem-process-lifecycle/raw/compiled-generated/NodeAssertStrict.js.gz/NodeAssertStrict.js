(function () {"use strict";
// .zig-cache/o/55c0f6cd0ba051ac3e5c6af31725a0ab/native-modules/NodeAssertStrict.mts
var $;
$ = (@getInternalField(@internalModuleRegistry, 103) || @createInternalModuleById(103)).strict;
return $

})
