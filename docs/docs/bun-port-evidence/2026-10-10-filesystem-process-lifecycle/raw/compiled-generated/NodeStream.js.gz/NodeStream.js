(function () {"use strict";
// .zig-cache/o/55c0f6cd0ba051ac3e5c6af31725a0ab/native-modules/NodeStream.mts
var $, exports = @getInternalField(@internalModuleRegistry, 46) || @createInternalModuleById(46);
exports.eos = @getInternalField(@internalModuleRegistry, 53) || @createInternalModuleById(53);
$ = exports;
return $

})
