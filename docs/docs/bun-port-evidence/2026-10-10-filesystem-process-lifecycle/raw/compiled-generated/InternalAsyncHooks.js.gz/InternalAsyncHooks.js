(function () {"use strict";
// .zig-cache/o/55c0f6cd0ba051ac3e5c6af31725a0ab/native-modules/InternalAsyncHooks.mts
var $, activeHooks = 0;
function enabledHooksExist() {
  return activeHooks > 0;
}
function markHookEnabled() {
  activeHooks += 1;
}
function markHookDisabled() {
  if (activeHooks > 0)
    activeHooks -= 1;
}
$ = {
  enabledHooksExist,
  markHookEnabled,
  markHookDisabled
};
return $

})
