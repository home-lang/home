var $;
// Hardcoded module "node:assert/strict"
$ = (__intrinsic__getInternalField(__intrinsic__internalModuleRegistry, 103) || __intrinsic__createInternalModuleById(103)).strict;
;$$EXPORT$$($).$$EXPORT_END$$;
