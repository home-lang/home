var $;
"use strict";

// New Streams API - Consumers & Utilities
//
// bytes(), text(), arrayBuffer() - collect entire stream
// tap(), tapSync() - observe without modifying
// merge() - temporal combining of sources
// ondrain() - backpressure drain utility

const { validateAbortSignal, validateFunction, validateInteger, validateObject } = (__intrinsic__getInternalField(__intrinsic__internalModuleRegistry, 86) || __intrinsic__createInternalModuleById(86));

const { from, fromSync, isAsyncIterable, isSyncIterable } = (__intrinsic__getInternalField(__intrinsic__internalModuleRegistry, 59) || __intrinsic__createInternalModuleById(59));

const { concatBytes } = (__intrinsic__getInternalField(__intrinsic__internalModuleRegistry, 66) || __intrinsic__createInternalModuleById(66));

const { drainableProtocol, toAsyncStreamable, toStreamable } = (__intrinsic__getInternalField(__intrinsic__internalModuleRegistry, 65) || __intrinsic__createInternalModuleById(65));

const { isAnyArrayBuffer, isSharedArrayBuffer } = (__intrinsic__getInternalField(__intrinsic__internalModuleRegistry, 164) || __intrinsic__createInternalModuleById(164));

const SymbolAsyncIterator = Symbol.asyncIterator;

// =============================================================================
// Type Guards
// =============================================================================

function isMergeOptions(value) {
  return (
    value !== null &&
    typeof value === "object" &&
    !ArrayBuffer.isView(value) &&
    typeof value[toStreamable] !== "function" &&
    typeof value[toAsyncStreamable] !== "function" &&
    !isAsyncIterable(value) &&
    !isSyncIterable(value) &&
    !isAnyArrayBuffer(value)
  );
}

// =============================================================================
// Shared chunk collection helpers
// =============================================================================

/**
 * Collect chunks from a sync source into an array.
 * @param {Iterable<Uint8Array[]>} source
 * @param {number} [limit]
 * @returns {Uint8Array[]}
 */
function collectSync(source, limit) {
  // Normalize source via fromSync() - accepts strings, ArrayBuffers, protocols, etc.
  const normalized = fromSync(source);
  const chunks = [];
  let totalBytes = 0;

  for (const batch of normalized) {
    for (let i = 0; i < batch.length; i++) {
      const chunk = batch[i];
      if (limit !== undefined) {
        totalBytes += chunk.byteLength;
        if (totalBytes > limit) {
          throw __intrinsic__makeErrorWithCode(160, "totalBytes", `<= ${limit}`, totalBytes);
        }
      }
      chunks.push(chunk);
    }
  }

  return chunks;
}

/**
 * Collect chunks from an async or sync source into an array.
 * @param {AsyncIterable<Uint8Array[]>|Iterable<Uint8Array[]>} source
 * @param {AbortSignal} [signal]
 * @param {number} [limit]
 * @returns {Promise<Uint8Array[]>}
 */
async function collectAsync(source, signal, limit) {
  signal?.throwIfAborted();

  // Normalize source via from() - accepts strings, ArrayBuffers, protocols, etc.
  const normalized = from(source);
  const chunks = [];

  // Fast path: no signal and no limit
  if (!signal && limit === undefined) {
    for await (const batch of normalized) {
      for (let i = 0; i < batch.length; i++) {
        chunks.push(batch[i]);
      }
    }
    return chunks;
  }

  // Slow path: with signal or limit checks
  let totalBytes = 0;

  for await (const batch of normalized) {
    signal?.throwIfAborted();
    for (let i = 0; i < batch.length; i++) {
      const chunk = batch[i];
      if (limit !== undefined) {
        totalBytes += chunk.byteLength;
        if (totalBytes > limit) {
          throw __intrinsic__makeErrorWithCode(160, "totalBytes", `<= ${limit}`, totalBytes);
        }
      }
      chunks.push(chunk);
    }
  }

  return chunks;
}

/**
 * Convert a Uint8Array to its backing ArrayBuffer, slicing if necessary.
 * Handles both ArrayBuffer and SharedArrayBuffer backing stores.
 * @param {Uint8Array} data
 * @returns {ArrayBuffer|SharedArrayBuffer}
 */
function toArrayBuffer(data) {
  const byteOffset = data.byteOffset;
  const byteLength = data.byteLength;
  const buffer = data.buffer;
  if (isSharedArrayBuffer(buffer)) {
    if (byteOffset === 0 && byteLength === buffer.byteLength) {
      return buffer;
    }
    return buffer.slice(byteOffset, byteOffset + byteLength);
  }
  if (byteOffset === 0 && byteLength === buffer.byteLength) {
    return buffer;
  }
  return buffer.slice(byteOffset, byteOffset + byteLength);
}

// =============================================================================
// Shared option validation
// =============================================================================

function validateBaseConsumerOptions(options) {
  validateObject(options, "options");
  const limit = options.limit;
  if (limit !== undefined) {
    validateInteger(limit, "options.limit", 0);
  }
  const encoding = options.encoding;
  if (encoding !== undefined) {
    if (typeof encoding !== "string") {
      throw __intrinsic__makeErrorWithCode(119, "options.encoding", "string", encoding);
    }
    try {
      new TextDecoder(encoding);
    } catch {
      throw __intrinsic__makeErrorWithCode(121, "options.encoding", encoding);
    }
  }
}

function validateConsumerOptions(options) {
  validateBaseConsumerOptions(options);
  const { signal } = options;
  if (signal !== undefined) {
    validateAbortSignal(signal, "options.signal");
  }
}

function validateSyncConsumerOptions(options) {
  validateBaseConsumerOptions(options);
}

// =============================================================================
// Sync Consumers
// =============================================================================

const kNullPrototype = { __proto__: null };

/**
 * Collect all bytes from a sync source.
 * @param {Iterable<Uint8Array[]>} source
 * @param {{ limit?: number }} [options]
 * @returns {Uint8Array}
 */
function bytesSync(source, options = kNullPrototype) {
  validateSyncConsumerOptions(options);
  return concatBytes(collectSync(source, options.limit));
}

/**
 * Collect and decode text from a sync source.
 * @param {Iterable<Uint8Array[]>} source
 * @param {{ encoding?: string, limit?: number }} [options]
 * @returns {string}
 */
function textSync(source, options = kNullPrototype) {
  validateSyncConsumerOptions(options);
  const data = concatBytes(collectSync(source, options.limit));
  const decoder = new TextDecoder(options.encoding ?? "utf-8", {
    __proto__: null,
    fatal: true,
  });
  return decoder.decode(data);
}

/**
 * Collect bytes as ArrayBuffer from a sync source.
 * @param {Iterable<Uint8Array[]>} source
 * @param {{ limit?: number }} [options]
 * @returns {ArrayBuffer}
 */
function arrayBufferSync(source, options = kNullPrototype) {
  validateSyncConsumerOptions(options);
  return toArrayBuffer(concatBytes(collectSync(source, options.limit)));
}

/**
 * Collect all chunks as an array from a sync source.
 * @param {Iterable<Uint8Array[]>} source
 * @param {{ limit?: number }} [options]
 * @returns {Uint8Array[]}
 */
function arraySync(source, options = kNullPrototype) {
  validateSyncConsumerOptions(options);
  return collectSync(source, options.limit);
}

// =============================================================================
// Async Consumers
// =============================================================================

/**
 * Collect all bytes from an async or sync source.
 * @param {AsyncIterable<Uint8Array[]>|Iterable<Uint8Array[]>} source
 * @param {{ signal?: AbortSignal, limit?: number }} [options]
 * @returns {Promise<Uint8Array>}
 */
async function bytes(source, options = kNullPrototype) {
  validateConsumerOptions(options);
  const chunks = await collectAsync(source, options.signal, options.limit);
  return concatBytes(chunks);
}

/**
 * Collect and decode text from an async or sync source.
 * @param {AsyncIterable<Uint8Array[]>|Iterable<Uint8Array[]>} source
 * @param {{ encoding?: string, signal?: AbortSignal, limit?: number }} [options]
 * @returns {Promise<string>}
 */
async function text(source, options = kNullPrototype) {
  validateConsumerOptions(options);
  const chunks = await collectAsync(source, options.signal, options.limit);
  const data = concatBytes(chunks);
  const decoder = new TextDecoder(options.encoding ?? "utf-8", {
    __proto__: null,
    fatal: true,
  });
  return decoder.decode(data);
}

/**
 * Collect bytes as ArrayBuffer from an async or sync source.
 * @param {AsyncIterable<Uint8Array[]>|Iterable<Uint8Array[]>} source
 * @param {{ signal?: AbortSignal, limit?: number }} [options]
 * @returns {Promise<ArrayBuffer>}
 */
async function arrayBuffer(source, options = kNullPrototype) {
  validateConsumerOptions(options);
  const chunks = await collectAsync(source, options.signal, options.limit);
  return toArrayBuffer(concatBytes(chunks));
}

/**
 * Collect all chunks as an array from an async or sync source.
 * @param {AsyncIterable<Uint8Array[]>|Iterable<Uint8Array[]>} source
 * @param {{ signal?: AbortSignal, limit?: number }} [options]
 * @returns {Promise<Uint8Array[]>}
 */
async function array(source, options = kNullPrototype) {
  validateConsumerOptions(options);
  return collectAsync(source, options.signal, options.limit);
}

// =============================================================================
// Tap Utilities
// =============================================================================

/**
 * Create a pass-through transform that observes chunks without modifying them.
 * @param {Function} callback
 * @returns {Function}
 */
function tap(callback) {
  validateFunction(callback, "callback");
  return async (chunks, options) => {
    await callback(chunks, options);
    return chunks;
  };
}

/**
 * Create a sync pass-through transform that observes chunks.
 * @param {Function} callback
 * @returns {Function}
 */
function tapSync(callback) {
  validateFunction(callback, "callback");
  return chunks => {
    callback(chunks);
    return chunks;
  };
}

// =============================================================================
// Drain Utility
// =============================================================================

/**
 * Wait for a drainable object's backpressure to clear.
 * @param {object} drainable
 * @returns {Promise<boolean>|null}
 */
function ondrain(drainable) {
  if (drainable === null || drainable === undefined || typeof drainable !== "object") {
    return null;
  }

  if (!(drainableProtocol in drainable) || typeof drainable[drainableProtocol] !== "function") {
    return null;
  }

  return drainable[drainableProtocol]();
}

// =============================================================================
// Merge Utility
// =============================================================================

/**
 * Merge multiple async iterables by yielding values in temporal order.
 * @param {...(AsyncIterable<Uint8Array[]>|object)} args
 * @returns {AsyncIterable<Uint8Array[]>}
 */
function merge(...args) {
  let sources;
  let options;

  const argc = args.length;
  if (argc > 0 && isMergeOptions(args[argc - 1])) {
    options = args[argc - 1];
    sources = args.slice(0, -1);
  } else {
    sources = args;
  }

  if (options?.signal !== undefined) {
    validateAbortSignal(options.signal, "options.signal");
  }

  // Normalize each source via from()
  const normalized = sources.map(source => from(source));

  return {
    __proto__: null,
    async *[SymbolAsyncIterator]() {
      const signal = options?.signal;

      signal?.throwIfAborted();

      if (normalized.length === 0) return;

      if (normalized.length === 1) {
        for await (const batch of normalized[0]) {
          signal?.throwIfAborted();
          yield batch;
        }
        return;
      }

      // Multiple sources - use a ready queue so that batches that settle
      // between consumer pulls are drained synchronously without an extra
      // async tick per batch. Each source has at most one pending .next()
      // at a time. Every batch from every source is preserved.
      const ready = [];
      let activeCount = normalized.length;
      let waitResolve = null;

      // Called when a source's .next() settles. Pushes the result into
      // the ready queue and wakes the consumer if it's waiting.
      const onSettled = (iterator, result) => {
        if (result.done) {
          activeCount--;
        } else {
          ready.push(result.value);
          // Immediately request the next value from this source
          // (at most one pending .next() per source)
          iterator.next().then(
            r => onSettled(iterator, r),
            err => {
              ready.push({ __proto__: null, error: err });
              if (waitResolve) {
                waitResolve();
                waitResolve = null;
              }
            },
          );
        }
        if (waitResolve) {
          waitResolve();
          waitResolve = null;
        }
      };

      // Start one .next() per source
      const iterators = [];
      for (let i = 0; i < normalized.length; i++) {
        const iterator = normalized[i][SymbolAsyncIterator]();
        iterators.push(iterator);
        iterator.next().then(
          r => onSettled(iterator, r),
          err => {
            ready.push({ __proto__: null, error: err });
            if (waitResolve) {
              waitResolve();
              waitResolve = null;
            }
          },
        );
      }

      try {
        while (activeCount > 0 || ready.length > 0) {
          signal?.throwIfAborted();

          // Drain ready queue synchronously
          while (ready.length > 0) {
            const item = ready.shift();
            if (item?.error) {
              throw item.error;
            }
            yield item;
          }

          // If sources are still active, wait for the next settlement
          if (activeCount > 0) {
            await new Promise(resolve => {
              waitResolve = resolve;
            });
          }
        }
      } finally {
        // Clean up: return all iterators
        await Promise.all(
          iterators.map(async iterator => {
            if (iterator.return) {
              try {
                await iterator.return();
              } catch {
                // Ignore return errors
              }
            }
          }),
        );
      }
    },
  };
}

$ = {
  array,
  arrayBuffer,
  arrayBufferSync,
  arraySync,
  bytes,
  bytesSync,
  merge,
  ondrain,
  tap,
  tapSync,
  text,
  textSync,
};
;$$EXPORT$$($).$$EXPORT_END$$;
