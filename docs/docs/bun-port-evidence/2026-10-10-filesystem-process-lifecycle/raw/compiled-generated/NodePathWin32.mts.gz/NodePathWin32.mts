var $;
// Hardcoded module "node:path/win32"
$ = (__intrinsic__getInternalField(__intrinsic__internalModuleRegistry, 125) || __intrinsic__createInternalModuleById(125)).win32;
;$$EXPORT$$($).$$EXPORT_END$$;
