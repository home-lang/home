(function () {"use strict";
// .zig-cache/o/55c0f6cd0ba051ac3e5c6af31725a0ab/native-modules/InternalStreamsIterTypes.mts
var $, toStreamable = Symbol.for("Stream.toStreamable"), toAsyncStreamable = Symbol.for("Stream.toAsyncStreamable"), broadcastProtocol = Symbol.for("Stream.broadcastProtocol"), shareProtocol = Symbol.for("Stream.shareProtocol"), shareSyncProtocol = Symbol.for("Stream.shareSyncProtocol"), drainableProtocol = Symbol.for("Stream.drainableProtocol"), kValidatedTransform = Symbol("kValidatedTransform"), kValidatedSource = Symbol("kValidatedSource"), kSyncWriteAccepted = Symbol("kSyncWriteAccepted"), kSyncWriteAcceptedOnFalse = Symbol("kSyncWriteAcceptedOnFalse");
$ = {
  broadcastProtocol,
  drainableProtocol,
  kSyncWriteAccepted,
  kSyncWriteAcceptedOnFalse,
  kValidatedSource,
  kValidatedTransform,
  shareProtocol,
  shareSyncProtocol,
  toAsyncStreamable,
  toStreamable
};
return $

})
