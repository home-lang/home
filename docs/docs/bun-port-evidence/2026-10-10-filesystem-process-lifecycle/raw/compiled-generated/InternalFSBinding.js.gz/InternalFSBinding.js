(function () {"use strict";
// .zig-cache/o/55c0f6cd0ba051ac3e5c6af31725a0ab/native-modules/InternalFSBinding.mts
var $;
$ = @lazy(9);
return $

})
