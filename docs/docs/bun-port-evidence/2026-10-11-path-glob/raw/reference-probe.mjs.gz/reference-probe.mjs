import path from 'node:path'
console.log('posix',path.posix.matchesGlob('foo/bar','foo\\bar'))
console.log('win after posix',path.win32.matchesGlob('foo\\bar','foo\\bar'))
console.log('win case',path.win32.matchesGlob('FOO.JS','*.js'))
console.log('posix case',path.posix.matchesGlob('FOO.JS','*.js'))
console.log('win separators',path.win32.matchesGlob('src\\x.js','**\\*.js'))
console.log('names',path.posix.matchesGlob.name,path.posix.matchesGlob.length,path.win32.matchesGlob.name,path.win32.matchesGlob.length)
