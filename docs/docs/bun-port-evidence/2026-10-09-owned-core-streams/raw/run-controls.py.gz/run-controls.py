from pathlib import Path
import subprocess,os,sys,json,hashlib
root=Path(__file__).resolve().parents[2];task=root/'zig-out/core-stream-port-2026-10-09';phase=sys.argv[1];exe=task/'parent/home' if phase.startswith('parent') else root/'zig-out/bin/home';env=os.environ.copy();env.update(HOME_NATIVE_VM='1',BUN_DEBUG_QUIET_LOGS='1');command=[str(exe),'run',str(root/'tests/runtime/native-stream-cancellation.test.mjs')];log=task/('controls-'+phase+'.log')
with log.open('wb') as output:
 try:result=subprocess.run(command,cwd=root,env=env,stdout=output,stderr=subprocess.STDOUT,timeout=105);code=result.returncode
 except subprocess.TimeoutExpired:code=124
complete=b'native direct/default/BYOB cancellation regressions passed' in log.read_bytes()
(task/('controls-'+phase+'.json')).write_text(json.dumps({'argv':command,'exit':code,'completion_marker':complete,'executable_sha256':hashlib.sha256(exe.read_bytes()).hexdigest()},indent=2)+'\n');print(code,complete,flush=True);sys.exit(0 if code==0 and complete else 1)
