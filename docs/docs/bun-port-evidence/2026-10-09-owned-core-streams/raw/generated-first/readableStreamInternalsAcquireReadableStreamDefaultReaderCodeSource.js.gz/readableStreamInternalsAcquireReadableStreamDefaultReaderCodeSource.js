(function (stream) {"use strict";
  var start = @getByIdDirectPrivate(stream, "start");
  if (start)
    start.@call(stream);
  return new @ReadableStreamDefaultReader(stream);
})
