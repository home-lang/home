(function (view) {"use strict";
  if (!@isReadableStreamBYOBReader(this))
    return @Promise.@reject(@makeErrorWithCode(140, "ReadableStreamBYOBReader"));
  if (!@getByIdDirectPrivate(this, "ownerReadableStream"))
    return @Promise.@reject(@makeErrorWithCode(138, "The reader is not attached to a stream"));
  if (!@isObject(view))
    return @Promise.@reject(@makeErrorWithCode(119, "view", "Buffer, TypedArray, or DataView", view));
  if (!@ArrayBuffer.@isView(view))
    return @Promise.@reject(@makeErrorWithCode(119, "view", "Buffer, TypedArray, or DataView", view));
  if (view.byteLength === 0)
    return @Promise.@reject(@makeTypeError("Provided view cannot have a 0 byteLength"));
  return @readableStreamBYOBReaderRead(this, view);
})
