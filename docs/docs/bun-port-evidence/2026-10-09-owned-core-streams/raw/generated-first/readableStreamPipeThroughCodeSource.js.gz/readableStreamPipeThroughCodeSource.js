(function (streams, options) {"use strict";
  let transforms = streams, readable = transforms.readable;
  if (!@isReadableStream(readable))
    throw @makeTypeError("readable should be ReadableStream");
  let writable = transforms.writable, internalWritable = @getInternalWritableStream(writable);
  if (!@isWritableStream(internalWritable))
    throw @makeTypeError("writable should be WritableStream");
  let preventClose = !1, preventAbort = !1, preventCancel = !1, signal;
  if (!@isUndefinedOrNull(options)) {
    if (!@isObject(options))
      throw @makeTypeError("options must be an object");
    if (preventAbort = !!options.preventAbort, preventCancel = !!options.preventCancel, preventClose = !!options.preventClose, signal = options.signal, signal !== @undefined && !@isAbortSignal(signal))
      throw @makeTypeError("options.signal must be AbortSignal");
  }
  if (!@isReadableStream(this))
    throw @makeErrorWithCode(140, "ReadableStream");
  if (@isReadableStreamLocked(this))
    throw @makeErrorWithCode(138, "ReadableStream is locked");
  if (@isWritableStreamLocked(internalWritable))
    throw @makeTypeError("WritableStream is locked");
  let promise = @readableStreamPipeToWritableStream(this, internalWritable, preventClose, preventAbort, preventCancel, signal);
  return @markPromiseAsHandled(promise), readable;
})
