(function (stream) {"use strict";
  let state = @getByIdDirectPrivate(stream, "state");
  if (state === "closed" || state === "errored")
    return @Promise.@reject(@makeTypeError("Cannot close a writable stream that is closed or errored"));
  let closePromiseCapability = @newPromiseCapability(@Promise);
  @putByIdDirectPrivate(stream, "closeRequest", closePromiseCapability);
  let writer = @getByIdDirectPrivate(stream, "writer");
  if (writer !== @undefined && @getByIdDirectPrivate(stream, "backpressure") && state === "writable")
    @getByIdDirectPrivate(writer, "readyPromise").resolve.@call();
  return @writableStreamDefaultControllerClose(@getByIdDirectPrivate(stream, "controller")), closePromiseCapability.promise;
})
