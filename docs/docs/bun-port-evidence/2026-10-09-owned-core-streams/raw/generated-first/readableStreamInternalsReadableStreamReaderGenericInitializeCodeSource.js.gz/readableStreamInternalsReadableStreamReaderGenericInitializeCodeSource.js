(function (reader, stream) {"use strict";
  if (@putByIdDirectPrivate(reader, "ownerReadableStream", stream), @putByIdDirectPrivate(stream, "reader", reader), @getByIdDirectPrivate(stream, "state") === 4)
    @putByIdDirectPrivate(reader, "closedPromiseCapability", @newPromiseCapability(@Promise));
  else if (@getByIdDirectPrivate(stream, "state") === 1)
    @putByIdDirectPrivate(reader, "closedPromiseCapability", {
      promise: @Promise.@resolve()
    });
  else
    @putByIdDirectPrivate(reader, "closedPromiseCapability", {
      promise: @newHandledRejectedPromise(@getByIdDirectPrivate(stream, "storedError"))
    });
})
