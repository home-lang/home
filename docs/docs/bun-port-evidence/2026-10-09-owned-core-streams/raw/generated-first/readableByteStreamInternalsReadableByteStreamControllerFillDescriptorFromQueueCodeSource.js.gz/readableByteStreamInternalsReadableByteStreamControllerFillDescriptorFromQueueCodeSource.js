(function (controller, pullIntoDescriptor) {"use strict";
  let currentAlignedBytes = pullIntoDescriptor.bytesFilled - pullIntoDescriptor.bytesFilled % pullIntoDescriptor.elementSize, maxBytesToCopy = @getByIdDirectPrivate(controller, "queue").size < pullIntoDescriptor.byteLength - pullIntoDescriptor.bytesFilled ? @getByIdDirectPrivate(controller, "queue").size : pullIntoDescriptor.byteLength - pullIntoDescriptor.bytesFilled, maxBytesFilled = pullIntoDescriptor.bytesFilled + maxBytesToCopy, maxAlignedBytes = maxBytesFilled - maxBytesFilled % pullIntoDescriptor.elementSize, totalBytesToCopyRemaining = maxBytesToCopy, ready = !1;
  if (maxAlignedBytes > currentAlignedBytes)
    totalBytesToCopyRemaining = maxAlignedBytes - pullIntoDescriptor.bytesFilled, ready = !0;
  while (totalBytesToCopyRemaining > 0) {
    let headOfQueue = @getByIdDirectPrivate(controller, "queue").content.peek(), bytesToCopy = totalBytesToCopyRemaining < headOfQueue.byteLength ? totalBytesToCopyRemaining : headOfQueue.byteLength, destStart = pullIntoDescriptor.byteOffset + pullIntoDescriptor.bytesFilled;
    if (new @Uint8Array(pullIntoDescriptor.buffer).set(new @Uint8Array(headOfQueue.buffer, headOfQueue.byteOffset, bytesToCopy), destStart), headOfQueue.byteLength === bytesToCopy)
      @getByIdDirectPrivate(controller, "queue").content.shift();
    else
      headOfQueue.byteOffset += bytesToCopy, headOfQueue.byteLength -= bytesToCopy;
    @getByIdDirectPrivate(controller, "queue").size -= bytesToCopy, @readableByteStreamControllerInvalidateBYOBRequest(controller), pullIntoDescriptor.bytesFilled += bytesToCopy, totalBytesToCopyRemaining -= bytesToCopy;
  }
  return ready;
})
