(function (stream, error) {"use strict";
  @putByIdDirectPrivate(stream, "state", 3), @putByIdDirectPrivate(stream, "storedError", error);
  let reader = @getByIdDirectPrivate(stream, "reader");
  if (!reader)
    return;
  @getByIdDirectPrivate(reader, "closedPromiseCapability").reject.@call(@undefined, error);
  let promise = @getByIdDirectPrivate(reader, "closedPromiseCapability").promise;
  if (@markPromiseAsHandled(promise), @isReadableStreamDefaultReader(reader))
    @readableStreamDefaultReaderErrorReadRequests(reader, error);
  else {
    let requests = @getByIdDirectPrivate(reader, "readIntoRequests");
    @putByIdDirectPrivate(reader, "readIntoRequests", @createFIFO());
    for (var request = requests.shift();request; request = requests.shift())
      @rejectPromise(request, error);
  }
})
