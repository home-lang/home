(function (stream, sink) {"use strict";
  var underlyingSource = @getByIdDirectPrivate(stream, "underlyingSource");
  if (underlyingSource)
    try {
      return @readDirectStream(stream, sink, underlyingSource);
    } finally {
      underlyingSource = @undefined, stream = @undefined, sink = @undefined;
    }
  return @readStreamIntoSink(stream, sink, !0);
})
