(function (controller) {"use strict";
  let stream = @getByIdDirectPrivate(controller, "controlledReadableStream");
  if (!@readableStreamDefaultControllerCanCloseOrEnqueue(controller))
    return;
  if (@getByIdDirectPrivate(controller, "started") !== 1)
    return;
  if ((!@isReadableStreamLocked(stream) || !@getByIdDirectPrivate(@getByIdDirectPrivate(stream, "reader"), "readRequests")?.isNotEmpty()) && @readableStreamDefaultControllerGetDesiredSize(controller) <= 0)
    return;
  if (@getByIdDirectPrivate(controller, "pulling")) {
    @putByIdDirectPrivate(controller, "pullAgain", !0);
    return;
  }
  @putByIdDirectPrivate(controller, "pulling", !0), @getByIdDirectPrivate(controller, "pullAlgorithm").@call(@undefined).@then(function() {
    if (@putByIdDirectPrivate(controller, "pulling", !1), @getByIdDirectPrivate(controller, "pullAgain"))
      @putByIdDirectPrivate(controller, "pullAgain", !1), @readableStreamDefaultControllerCallPullIfNeeded(controller);
  }, function(error) {
    @readableStreamDefaultControllerError(controller, error);
  });
})
