(function (stream) {"use strict";
  if (!@isReadableStream(stream))
    throw @makeErrorWithCode(119, "stream", "ReadableStream", typeof stream);
  if (@isReadableStreamLocked(stream))
    return @Promise.@reject(@makeErrorWithCode(138, "ReadableStream is locked"));
  return @tryUseReadableStreamBufferedFastPath(stream, "blob") || @Promise.@resolve(Bun.readableStreamToArray(stream)).then((array) => new Blob(array));
})
