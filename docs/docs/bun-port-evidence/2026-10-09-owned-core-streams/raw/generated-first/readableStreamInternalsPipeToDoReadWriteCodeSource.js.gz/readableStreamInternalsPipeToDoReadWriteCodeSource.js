(function (pipeState) {"use strict";
  return pipeState.pendingReadPromiseCapability = @newPromiseCapability(@Promise), @getByIdDirectPrivate(pipeState.writer, "readyPromise").promise.@then(() => {
    if (pipeState.shuttingDown) {
      pipeState.pendingReadPromiseCapability.resolve.@call(@undefined, !1);
      return;
    }
    @readableStreamDefaultReaderRead(pipeState.reader).@then((result) => {
      let canWrite = !result.done && @getByIdDirectPrivate(pipeState.writer, "stream") !== @undefined;
      if (pipeState.pendingReadPromiseCapability.resolve.@call(@undefined, canWrite), !canWrite)
        return;
      pipeState.pendingWritePromise = @writableStreamDefaultWriterWrite(pipeState.writer, result.value).@then(@undefined, () => {});
    }, (_e) => {
      pipeState.pendingReadPromiseCapability.resolve.@call(@undefined, !1);
    });
  }, (_e) => {
    pipeState.pendingReadPromiseCapability.resolve.@call(@undefined, !1);
  }), pipeState.pendingReadPromiseCapability.promise;
})
