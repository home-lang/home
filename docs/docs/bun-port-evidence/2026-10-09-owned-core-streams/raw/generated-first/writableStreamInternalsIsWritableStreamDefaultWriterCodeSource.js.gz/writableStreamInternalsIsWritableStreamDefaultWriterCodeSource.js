(function (writer) {"use strict";
  return @isObject(writer) && !!@getByIdDirectPrivate(writer, "closedPromise");
})
