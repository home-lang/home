(function (queue) {"use strict";
  let record = queue.content.shift();
  if (queue.size -= record.size, queue.size < 0)
    queue.size = 0;
  return record.value;
})
