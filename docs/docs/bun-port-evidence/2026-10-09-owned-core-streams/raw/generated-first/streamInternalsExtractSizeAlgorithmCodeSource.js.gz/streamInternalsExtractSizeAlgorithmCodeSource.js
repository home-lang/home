(function (strategy) {"use strict";
  let sizeAlgorithm = strategy.size;
  if (sizeAlgorithm === @undefined)
    return () => 1;
  if (typeof sizeAlgorithm !== "function")
    @throwTypeError("strategy.size must be a function");
  return (chunk) => {
    return sizeAlgorithm(chunk);
  };
})
