(function (controller) {"use strict";
  if (!@readableByteStreamControllerShouldCallPull(controller))
    return;
  if (@getByIdDirectPrivate(controller, "pulling")) {
    @putByIdDirectPrivate(controller, "pullAgain", !0);
    return;
  }
  @putByIdDirectPrivate(controller, "pulling", !0), @promiseInvokeOrNoop(@getByIdDirectPrivate(controller, "underlyingByteSource"), "pull", [controller]).@then(() => {
    if (@putByIdDirectPrivate(controller, "pulling", !1), @getByIdDirectPrivate(controller, "pullAgain"))
      @putByIdDirectPrivate(controller, "pullAgain", !1), @readableByteStreamControllerCallPullIfNeeded(controller);
  }, (error) => {
    if (@getByIdDirectPrivate(@getByIdDirectPrivate(controller, "controlledReadableStream"), "state") === 4)
      @readableByteStreamControllerError(controller, error);
  });
})
