(function () {"use strict";
  return new (@getInternalField(@internalModuleRegistry, 20) || @createInternalModuleById(20));
})
