(function (reader) {"use strict";
  return @isObject(reader) && !!@getByIdDirectPrivate(reader, "readIntoRequests");
})
