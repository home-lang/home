(function (reader) {"use strict";
  if (@getByIdDirectPrivate(reader, "readRequests"))
    return reader.@bunNativePtr ? 3 : 1;
  if (@getByIdDirectPrivate(reader, "readIntoRequests"))
    return 2;
  return 0;
})
