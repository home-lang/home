(function (byobRequest) {"use strict";
  return @isObject(byobRequest) && @getByIdDirectPrivate(byobRequest, "associatedReadableByteStreamController") !== @undefined;
})
