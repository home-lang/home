(function (pipeState) {"use strict";
  @writableStreamDefaultWriterRelease(pipeState.writer), @readableStreamReaderGenericRelease(pipeState.reader);
  let signal = pipeState.signal;
  if (signal)
    @removeAbortAlgorithmFromSignal(signal, pipeState.abortAlgorithmIdentifier);
  if (arguments.length > 1)
    pipeState.promiseCapability.reject.@call(@undefined, arguments[1]);
  else
    pipeState.promiseCapability.resolve.@call();
})
