(function (e) {"use strict";
  if (!@isTransformStreamDefaultController(this))
    throw @makeErrorWithCode(140, "TransformStreamDefaultController");
  @transformStreamDefaultControllerError(this, e);
})
