(function (controller) {"use strict";
  @putByIdDirectPrivate(controller, "start", @undefined);
})
