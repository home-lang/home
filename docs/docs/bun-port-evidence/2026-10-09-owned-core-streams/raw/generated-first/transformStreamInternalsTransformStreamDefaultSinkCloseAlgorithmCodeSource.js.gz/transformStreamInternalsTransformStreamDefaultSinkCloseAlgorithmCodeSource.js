(function (stream) {"use strict";
  let readable = @getByIdDirectPrivate(stream, "readable"), controller = @getByIdDirectPrivate(stream, "controller"), readableController = @getByIdDirectPrivate(readable, "readableStreamController"), flushAlgorithm = @getByIdDirectPrivate(controller, "flushAlgorithm"), flushPromise = @getByIdDirectPrivate(controller, "flushAlgorithm").@call();
  @transformStreamDefaultControllerClearAlgorithms(controller);
  let promiseCapability = @newPromiseCapability(@Promise);
  return flushPromise.@then(() => {
    if (@getByIdDirectPrivate(readable, "state") === 3) {
      promiseCapability.reject.@call(@undefined, @getByIdDirectPrivate(readable, "storedError"));
      return;
    }
    if (@readableStreamDefaultControllerCanCloseOrEnqueue(readableController))
      @readableStreamDefaultControllerClose(readableController);
    promiseCapability.resolve();
  }, (r) => {
    @transformStreamError(@getByIdDirectPrivate(controller, "stream"), r), promiseCapability.reject.@call(@undefined, @getByIdDirectPrivate(readable, "storedError"));
  }), promiseCapability.promise;
})
