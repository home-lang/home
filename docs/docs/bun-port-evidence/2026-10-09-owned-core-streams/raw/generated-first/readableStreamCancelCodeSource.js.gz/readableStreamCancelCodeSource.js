(function (reason) {"use strict";
  if (!@isReadableStream(this))
    return @Promise.@reject(@makeErrorWithCode(140, "ReadableStream"));
  if (@isReadableStreamLocked(this))
    return @Promise.@reject(@makeErrorWithCode(138, "ReadableStream is locked"));
  return @readableStreamCancel(this, reason);
})
