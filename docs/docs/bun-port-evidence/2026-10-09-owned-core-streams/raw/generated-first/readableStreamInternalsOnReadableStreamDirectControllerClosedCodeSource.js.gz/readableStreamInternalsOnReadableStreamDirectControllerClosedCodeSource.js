(function (_reason) {"use strict";
  @throwTypeError("ReadableStreamDirectController is now closed");
})
