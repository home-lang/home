(function (reader) {"use strict";
  if (@getByIdDirectPrivate(@getByIdDirectPrivate(reader, "ownerReadableStream"), "state") === 4)
    @getByIdDirectPrivate(reader, "closedPromiseCapability").reject.@call(@undefined, @makeErrorWithCode(237, "Stream reader cancelled via releaseLock()"));
  else
    @putByIdDirectPrivate(reader, "closedPromiseCapability", {
      promise: @newHandledRejectedPromise(@makeErrorWithCode(237, "Stream reader cancelled via releaseLock()"))
    });
  let promise = @getByIdDirectPrivate(reader, "closedPromiseCapability").promise;
  @markPromiseAsHandled(promise);
  var stream = @getByIdDirectPrivate(reader, "ownerReadableStream");
  if (stream.@bunNativePtr)
    @getByIdDirectPrivate(@getByIdDirectPrivate(stream, "readableStreamController"), "underlyingSource").@resume(!1);
  @putByIdDirectPrivate(stream, "reader", @undefined), @putByIdDirectPrivate(reader, "ownerReadableStream", @undefined);
})
