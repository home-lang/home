(function (stream, underlyingByteSource, highWaterMark) {"use strict";
  if (!@isReadableStream(stream))
    @throwTypeError("ReadableByteStreamController needs a ReadableStream");
  if (@getByIdDirectPrivate(stream, "readableStreamController") !== null)
    @throwTypeError("ReadableStream already has a controller");
  @putByIdDirectPrivate(this, "controlledReadableStream", stream), @putByIdDirectPrivate(this, "underlyingByteSource", underlyingByteSource), @putByIdDirectPrivate(this, "pullAgain", !1), @putByIdDirectPrivate(this, "pulling", !1), @readableByteStreamControllerClearPendingPullIntos(this), @putByIdDirectPrivate(this, "queue", @newQueue()), @putByIdDirectPrivate(this, "started", 0), @putByIdDirectPrivate(this, "closeRequested", !1);
  let hwm = @toNumber(highWaterMark);
  if (hwm !== hwm || hwm < 0)
    @throwRangeError("highWaterMark value is negative or not a number");
  @putByIdDirectPrivate(this, "strategyHWM", hwm);
  let autoAllocateChunkSize = underlyingByteSource.autoAllocateChunkSize;
  if (autoAllocateChunkSize !== @undefined) {
    if (autoAllocateChunkSize = @toNumber(autoAllocateChunkSize), autoAllocateChunkSize <= 0 || autoAllocateChunkSize === @Infinity || autoAllocateChunkSize === -@Infinity)
      @throwRangeError("autoAllocateChunkSize value is negative or equal to positive or negative infinity");
  }
  @putByIdDirectPrivate(this, "autoAllocateChunkSize", autoAllocateChunkSize), @putByIdDirectPrivate(this, "pendingPullIntos", @createFIFO());
  let controller = this;
  return @promiseInvokeOrNoopNoCatch(@getByIdDirectPrivate(controller, "underlyingByteSource"), "start", [controller]).@then(() => {
    @putByIdDirectPrivate(controller, "started", 1), @readableByteStreamControllerCallPullIfNeeded(controller);
  }, (error) => {
    if (@getByIdDirectPrivate(stream, "state") === 4)
      @readableByteStreamControllerError(controller, error);
  }), @putByIdDirectPrivate(this, "cancel", @readableByteStreamControllerCancel), @putByIdDirectPrivate(this, "pull", @readableByteStreamControllerPull), this;
})
