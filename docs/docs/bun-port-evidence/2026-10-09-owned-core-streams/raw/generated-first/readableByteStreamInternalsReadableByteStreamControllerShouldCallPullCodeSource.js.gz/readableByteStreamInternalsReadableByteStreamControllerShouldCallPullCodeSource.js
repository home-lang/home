(function (controller) {"use strict";
  let stream = @getByIdDirectPrivate(controller, "controlledReadableStream");
  if (!stream)
    return !1;
  if (@getByIdDirectPrivate(stream, "state") !== 4)
    return !1;
  if (@getByIdDirectPrivate(controller, "closeRequested"))
    return !1;
  if (!(@getByIdDirectPrivate(controller, "started") > 0))
    return !1;
  let reader = @getByIdDirectPrivate(stream, "reader");
  if (reader && (@getByIdDirectPrivate(reader, "readRequests")?.isNotEmpty() || !!reader.@bunNativePtr))
    return !0;
  if (@readableStreamHasBYOBReader(stream) && @getByIdDirectPrivate(@getByIdDirectPrivate(stream, "reader"), "readIntoRequests")?.isNotEmpty())
    return !0;
  if (@readableByteStreamControllerGetDesiredSize(controller) > 0)
    return !0;
  return !1;
})
