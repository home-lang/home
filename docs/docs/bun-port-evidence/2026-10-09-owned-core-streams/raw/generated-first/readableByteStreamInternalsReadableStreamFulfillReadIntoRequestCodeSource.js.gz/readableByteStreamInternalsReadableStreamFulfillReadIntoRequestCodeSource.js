(function (stream, chunk, done) {"use strict";
  let readIntoRequest = @getByIdDirectPrivate(@getByIdDirectPrivate(stream, "reader"), "readIntoRequests").shift();
  @fulfillPromise(readIntoRequest, { value: chunk, done });
})
