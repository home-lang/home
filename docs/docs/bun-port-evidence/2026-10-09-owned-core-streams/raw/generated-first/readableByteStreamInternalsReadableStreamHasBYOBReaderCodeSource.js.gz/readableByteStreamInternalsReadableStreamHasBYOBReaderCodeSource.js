(function (stream) {"use strict";
  let reader = @getByIdDirectPrivate(stream, "reader");
  return reader !== @undefined && @isReadableStreamBYOBReader(reader);
})
