(function () {"use strict";
  if (!@isTransformStream(this))
    throw @makeErrorWithCode(140, "TransformStream");
  return @getByIdDirectPrivate(this, "writable");
})
