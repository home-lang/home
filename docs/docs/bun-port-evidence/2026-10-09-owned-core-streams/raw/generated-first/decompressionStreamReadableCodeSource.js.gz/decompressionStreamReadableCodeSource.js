(function () {"use strict";
  if (!@inherits(6, this))
    throw @makeGetterTypeError("DecompressionStream", "readable");
  return @getByIdDirectPrivate(this, "readable");
})
