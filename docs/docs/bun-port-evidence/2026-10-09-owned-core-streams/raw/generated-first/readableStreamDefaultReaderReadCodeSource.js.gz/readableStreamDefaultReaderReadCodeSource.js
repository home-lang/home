(function () {"use strict";
  if (!@isReadableStreamDefaultReader(this))
    return @Promise.@reject(@makeErrorWithCode(140, "ReadableStreamDefaultReader"));
  if (!@getByIdDirectPrivate(this, "ownerReadableStream"))
    return @Promise.@reject(@makeErrorWithCode(138, "The reader is not attached to a stream"));
  return @readableStreamDefaultReaderRead(this);
})
