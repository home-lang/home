(function (stream) {"use strict";
  let writeRequest = @getByIdDirectPrivate(stream, "writeRequests").shift();
  @putByIdDirectPrivate(stream, "inFlightWriteRequest", writeRequest);
})
