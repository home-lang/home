(function (controller, error) {"use strict";
  let stream = @getByIdDirectPrivate(controller, "stream");
  if (@getByIdDirectPrivate(stream, "state") === "writable")
    @writableStreamDefaultControllerError(controller, error);
})
