(function (underlyingSource, highWaterMark) {"use strict";
  var [sink, closingPromise] = @createTextStream(highWaterMark), controller = {
    @underlyingSource: underlyingSource,
    @pull: @onPullDirectStream,
    @controlledReadableStream: this,
    @sink: sink,
    close: @onCloseDirectStream,
    write: sink.write,
    error: @handleDirectStreamError,
    end: @onCloseDirectStream,
    @close: @onCloseDirectStream,
    flush: @onFlushDirectStream,
    _pendingRead: @undefined,
    _deferClose: 0,
    _deferFlush: 0,
    _deferCloseReason: @undefined,
    _handleError: @undefined
  };
  return @putByIdDirectPrivate(this, "readableStreamController", controller), @putByIdDirectPrivate(this, "underlyingSource", null), @putByIdDirectPrivate(this, "start", @undefined), closingPromise;
})
