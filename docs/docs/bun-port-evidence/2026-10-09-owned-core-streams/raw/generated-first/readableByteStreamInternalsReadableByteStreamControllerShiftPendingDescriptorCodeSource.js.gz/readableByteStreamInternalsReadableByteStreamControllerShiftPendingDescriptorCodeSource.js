(function (controller) {"use strict";
  let descriptor = @getByIdDirectPrivate(controller, "pendingPullIntos").shift();
  return @readableByteStreamControllerInvalidateBYOBRequest(controller), descriptor;
})
