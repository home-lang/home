(function (prototype) {"use strict";
  var asyncIterator = globalThis.Symbol.asyncIterator, ReadableStreamAsyncIterator = async function* ReadableStreamAsyncIterator2(stream, preventCancel) {
    var reader = stream.getReader(), deferredError;
    try {
      while (!0) {
        var done, value;
        let firstResult = reader.readMany();
        if (@isPromise(firstResult))
          ({ done, value } = await firstResult);
        else
          ({ done, value } = firstResult);
        if (done)
          return;
        yield* value;
      }
    } catch (e) {
      throw deferredError = e, e;
    } finally {
      if (reader.releaseLock(), !preventCancel && !@isReadableStreamLocked(stream)) {
        let promise = stream.cancel(deferredError);
        if (Bun.peek.status(promise) === "rejected")
          @markPromiseAsHandled(promise);
      }
    }
  }, createAsyncIterator = function asyncIterator2() {
    return ReadableStreamAsyncIterator(this, !1);
  }, createValues = function values({ preventCancel = !1 } = { preventCancel: !1 }) {
    return ReadableStreamAsyncIterator(this, preventCancel);
  };
  return @Object.@defineProperty(prototype, asyncIterator, { value: createAsyncIterator }), @Object.@defineProperty(prototype, "values", { value: createValues }), prototype;
})
