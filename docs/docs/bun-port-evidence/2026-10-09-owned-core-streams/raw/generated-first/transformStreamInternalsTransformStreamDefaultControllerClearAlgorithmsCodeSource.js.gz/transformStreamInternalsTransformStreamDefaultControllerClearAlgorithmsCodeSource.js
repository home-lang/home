(function (controller) {"use strict";
  @putByIdDirectPrivate(controller, "transformAlgorithm", !0), @putByIdDirectPrivate(controller, "flushAlgorithm", @undefined);
})
