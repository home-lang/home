(function (stream, contentType) {"use strict";
  if (!@isReadableStream(stream))
    throw @makeErrorWithCode(119, "stream", "ReadableStream", typeof stream);
  if (@isReadableStreamLocked(stream))
    return @Promise.@reject(@makeErrorWithCode(138, "ReadableStream is locked"));
  return Bun.readableStreamToBlob(stream).then((blob) => {
    return FormData.from(blob, contentType);
  });
})
