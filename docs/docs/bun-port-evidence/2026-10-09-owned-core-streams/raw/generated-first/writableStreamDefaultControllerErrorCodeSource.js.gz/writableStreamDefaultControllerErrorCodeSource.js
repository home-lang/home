(function (e) {"use strict";
  if (@getByIdDirectPrivate(this, "abortSteps") === @undefined)
    throw @makeErrorWithCode(140, "WritableStreamDefaultController");
  let stream = @getByIdDirectPrivate(this, "stream");
  if (@getByIdDirectPrivate(stream, "state") !== "writable")
    return;
  @writableStreamDefaultControllerError(this, e);
})
