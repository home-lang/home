(function (source, destination, preventClose, preventAbort, preventCancel, signal) {"use strict";
  if (@getByIdDirectPrivate(source, "underlyingByteSource") !== @undefined)
    return @Promise.@reject("Piping to a readable bytestream is not supported");
  let pipeState = {
    source,
    destination,
    preventAbort,
    preventCancel,
    preventClose,
    signal
  };
  if (pipeState.reader = @acquireReadableStreamDefaultReader(source), pipeState.writer = @acquireWritableStreamDefaultWriter(destination), source.@disturbed = !0, pipeState.shuttingDown = !1, pipeState.promiseCapability = @newPromiseCapability(@Promise), pipeState.pendingReadPromiseCapability = @newPromiseCapability(@Promise), pipeState.pendingReadPromiseCapability.resolve.@call(), pipeState.pendingWritePromise = @Promise.@resolve(), signal !== @undefined) {
    let algorithm = (reason) => {
      @pipeToShutdownWithAction(pipeState, () => {
        let promiseDestination = !pipeState.preventAbort && @getByIdDirectPrivate(pipeState.destination, "state") === "writable" ? @writableStreamAbort(pipeState.destination, reason) : @Promise.@resolve(), promiseSource = !pipeState.preventCancel && @getByIdDirectPrivate(pipeState.source, "state") === 4 ? @readableStreamCancel(pipeState.source, reason) : @Promise.@resolve(), promiseCapability = @newPromiseCapability(@Promise), shouldWait = !0, handleResolvedPromise = () => {
          if (shouldWait) {
            shouldWait = !1;
            return;
          }
          promiseCapability.resolve.@call();
        }, handleRejectedPromise = (e) => {
          promiseCapability.reject.@call(@undefined, e);
        };
        return promiseDestination.@then(handleResolvedPromise, handleRejectedPromise), promiseSource.@then(handleResolvedPromise, handleRejectedPromise), promiseCapability.promise;
      }, reason);
    };
    if (!(pipeState.abortAlgorithmIdentifier = @addAbortAlgorithmToSignal(signal, algorithm)))
      return pipeState.promiseCapability.promise;
    pipeState.signal = signal;
  }
  return @pipeToErrorsMustBePropagatedForward(pipeState), @pipeToErrorsMustBePropagatedBackward(pipeState), @pipeToClosingMustBePropagatedForward(pipeState), @pipeToClosingMustBePropagatedBackward(pipeState), @pipeToLoop(pipeState), pipeState.promiseCapability.promise;
})
