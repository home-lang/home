(function (stream, reason) {"use strict";
  return @transformStreamError(stream, reason), @Promise.@resolve();
})
