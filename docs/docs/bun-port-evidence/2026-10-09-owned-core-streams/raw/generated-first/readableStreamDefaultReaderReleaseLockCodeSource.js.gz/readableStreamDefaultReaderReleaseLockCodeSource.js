(function () {"use strict";
  if (!@isReadableStreamDefaultReader(this))
    throw @makeErrorWithCode(140, "ReadableStreamDefaultReader");
  if (!@getByIdDirectPrivate(this, "ownerReadableStream"))
    return;
  @readableStreamDefaultReaderRelease(this);
})
