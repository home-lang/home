(function () {"use strict";
  function callClose(controller) {
    try {
      var source = controller.@underlyingSource;
      if (!@readableStreamDefaultControllerCanCloseOrEnqueue(controller))
        return;
      controller.close();
    } catch (e) {
      globalThis.reportError(e);
    } finally {
      if (source?.@stream)
        source.@stream = @undefined;
      if (source)
        source.@data = @undefined;
    }
  }

  class NativeReadableStreamSource {
    constructor(handle, autoAllocateChunkSize, drainValue) {
      if (@putByIdDirectPrivate(this, "stream", handle), this.pull = this.#pull.bind(this), this.cancel = this.#cancel.bind(this), this.autoAllocateChunkSize = autoAllocateChunkSize, drainValue !== @undefined)
        this.start = (controller) => {
          this.start = @undefined, this.#controller = new WeakRef(controller), controller.enqueue(drainValue);
        };
      handle.onClose = this.#onClose.bind(this), handle.onDrain = this.#onDrain.bind(this);
    }
    #onDrain(chunk) {
      var controller = this.#controller?.deref?.();
      if (controller)
        controller.enqueue(chunk);
    }
    #hasResized = !1;
    #adjustHighWaterMark(result) {
      let autoAllocateChunkSize = this.autoAllocateChunkSize;
      if (result >= autoAllocateChunkSize && !this.#hasResized)
        this.#hasResized = !0, this.autoAllocateChunkSize = Math.min(autoAllocateChunkSize * 2, 2097152);
    }
    #controller;
    pull;
    cancel;
    start;
    autoAllocateChunkSize = 0;
    #closed = !1;
    #closer = [!1];
    @data;
    @stream;
    #onClose() {
      this.#closed = !0;
      var controller = this.#controller?.deref?.();
      if (this.#controller = @undefined, this.@data = @undefined, @putByIdDirectPrivate(this, "stream", @undefined), controller)
        @enqueueJob(callClose, controller);
    }
    #getInternalBuffer(chunkSize) {
      var chunk = this.@data;
      if (!chunk || chunk.buffer.byteLength < chunkSize)
        this.@data = chunk = new @Uint8Array(chunkSize);
      return chunk;
    }
    #handleArrayBufferViewResult(result, view, isClosed, controller) {
      if (result.byteLength > 0)
        controller.enqueue(result);
      if (isClosed)
        return @enqueueJob(callClose, controller), @undefined;
      return view;
    }
    #handleNumberResult(result, view, isClosed, controller) {
      if (result > 0) {
        let remaining = view.length - result, toEnqueue = view;
        if (remaining > 0)
          toEnqueue = view.subarray(0, result), view = view.subarray(result);
        else
          view = @undefined;
        controller.enqueue(toEnqueue);
      }
      if (isClosed)
        return @enqueueJob(callClose, controller), @undefined;
      return view;
    }
    #onNativeReadableStreamResult(result, view, isClosed, controller) {
      if (typeof result === "number") {
        if (!isClosed)
          this.#adjustHighWaterMark(result);
        return this.#handleNumberResult(result, view, isClosed, controller);
      } else if (typeof result === "boolean")
        return @enqueueJob(callClose, controller), @undefined;
      else if (@isTypedArrayView(result)) {
        if (!isClosed)
          this.#adjustHighWaterMark(result.byteLength);
        return this.#handleArrayBufferViewResult(result, view, isClosed, controller);
      }
      throw @makeErrorWithCode(137, "Internal error: invalid result from pull. This is a bug in Bun. Please report it.");
    }
    #pull(controller) {
      var handle = @getByIdDirectPrivate(this, "stream");
      if (!handle || this.#closed) {
        this.#controller = @undefined, this.#closed = !0, @putByIdDirectPrivate(this, "stream", @undefined), @enqueueJob(callClose, controller), this.@data = @undefined;
        return;
      }
      if (!this.#controller)
        this.#controller = new WeakRef(controller);
      let closer = this.#closer;
      if (closer[0] = !1, this.@data) {
        let drainResult = handle.drain();
        if (drainResult) {
          this.@data = this.#onNativeReadableStreamResult(drainResult, this.@data, closer[0], controller);
          return;
        }
      }
      let view = this.#getInternalBuffer(this.autoAllocateChunkSize), result = handle.pull(view, closer);
      if (@isPromise(result))
        return result.@then((result2) => {
          if (this.@data = this.#onNativeReadableStreamResult(result2, view, closer[0], controller), this.#closed)
            this.@data = @undefined;
        }, (err) => {
          this.@data = @undefined, this.#closed = !0, this.#controller = @undefined, controller.error(err), this.#onClose();
        });
      if (this.@data = this.#onNativeReadableStreamResult(result, view, closer[0], controller), this.#closed)
        this.@data = @undefined;
    }
    #cancel(reason) {
      var handle = @getByIdDirectPrivate(this, "stream");
      if (this.@data = @undefined, handle)
        handle.updateRef(!1), handle.cancel(reason), @putByIdDirectPrivate(this, "stream", @undefined);
    }
  }
  return NativeReadableStreamSource.prototype.@resume = function(has_ref) {
    var handle = @getByIdDirectPrivate(this, "stream");
    if (handle)
      handle.updateRef(has_ref);
  }, NativeReadableStreamSource;
})
