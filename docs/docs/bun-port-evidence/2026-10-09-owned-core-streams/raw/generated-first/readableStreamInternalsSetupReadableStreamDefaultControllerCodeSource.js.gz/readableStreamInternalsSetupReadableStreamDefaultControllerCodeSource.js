(function (stream, underlyingSource, size, highWaterMark, startMethod, pullMethod, cancelMethod) {"use strict";
  let controller = new @ReadableStreamDefaultController(stream, underlyingSource, size, highWaterMark, @isReadableStream);
  var asyncContext = stream.@asyncContext;
  let pullAlgorithm = () => @promiseInvokeOrNoopMethod(underlyingSource, pullMethod, [controller]), cancelAlgorithm = asyncContext ? (reason) => {
    var prev = @getInternalField(@asyncContext, 0);
    @putInternalField(@asyncContext, 0, asyncContext);
    var result = @promiseInvokeOrNoopMethod(underlyingSource, cancelMethod, [reason]);
    return @putInternalField(@asyncContext, 0, prev), result;
  } : (reason) => @promiseInvokeOrNoopMethod(underlyingSource, cancelMethod, [reason]);
  @putByIdDirectPrivate(controller, "pullAlgorithm", pullAlgorithm), @putByIdDirectPrivate(controller, "cancelAlgorithm", cancelAlgorithm), @putByIdDirectPrivate(controller, "pull", @readableStreamDefaultControllerPull), @putByIdDirectPrivate(controller, "cancel", @readableStreamDefaultControllerCancel), @putByIdDirectPrivate(stream, "readableStreamController", controller), @readableStreamDefaultControllerStart(controller);
})
