(function (stream, reason) {"use strict";
  let state = @getByIdDirectPrivate(stream, "state");
  if (state === "closed" || state === "errored")
    return @Promise.@resolve();
  let pendingAbortRequest = @getByIdDirectPrivate(stream, "pendingAbortRequest");
  if (pendingAbortRequest !== @undefined)
    return pendingAbortRequest.promise.promise;
  let wasAlreadyErroring = !1;
  if (state === "erroring")
    wasAlreadyErroring = !0, reason = @undefined;
  let abortPromiseCapability = @newPromiseCapability(@Promise);
  if (@putByIdDirectPrivate(stream, "pendingAbortRequest", {
    promise: abortPromiseCapability,
    reason,
    wasAlreadyErroring
  }), !wasAlreadyErroring)
    @writableStreamStartErroring(stream, reason);
  return abortPromiseCapability.promise;
})
