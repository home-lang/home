(function (stream, method) {"use strict";
  let ptr = stream.@bunNativePtr;
  if (ptr && !@isReadableStreamDisturbed(stream) && @isCallable(ptr[method])) {
    let promise = ptr[method]();
    if (stream.@disturbed = !0, @putByIdDirectPrivate(stream, "start", @undefined), @putByIdDirectPrivate(stream, "reader", {}), Bun.peek.status(promise) === "fulfilled")
      return stream.@reader = @undefined, @readableStreamCloseIfPossible(stream), promise;
    return promise.catch((e) => {
      return stream.@reader = @undefined, @readableStreamCancel(stream, e), @Promise.@reject(e);
    }).finally(() => {
      stream.@reader = @undefined, @readableStreamCloseIfPossible(stream);
    });
  }
})
