(function (queue) {"use strict";
  return queue.content.peek()?.value;
})
