(function (stream, error) {"use strict";
  if (@getByIdDirectPrivate(stream, "state") === "writable") {
    @writableStreamStartErroring(stream, error);
    return;
  }
  @writableStreamFinishErroring(stream);
})
