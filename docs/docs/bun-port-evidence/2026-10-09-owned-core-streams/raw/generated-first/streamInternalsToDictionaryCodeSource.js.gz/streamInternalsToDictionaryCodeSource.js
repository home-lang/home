(function (value, defaultValue, errorMessage) {"use strict";
  if (@isUndefinedOrNull(value))
    return defaultValue;
  if (!@isObject(value))
    throw @makeErrorWithCode(119, errorMessage);
  return value;
})
