(function () {"use strict";
  if (!@isReadableStreamDefaultController(this))
    throw @makeGetterTypeError("ReadableStreamDefaultController", "desiredSize");
  return @readableStreamDefaultControllerGetDesiredSize(this);
})
