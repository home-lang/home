(function (bytesWritten) {"use strict";
  if (!@isReadableStreamBYOBRequest(this))
    throw @makeErrorWithCode(140, "ReadableStreamBYOBRequest");
  if (@getByIdDirectPrivate(this, "associatedReadableByteStreamController") == null)
    throw @makeErrorWithCode(138, "This BYOB request has been invalidated");
  return @readableByteStreamControllerRespond(@getByIdDirectPrivate(this, "associatedReadableByteStreamController"), bytesWritten);
})
