(function () {"use strict";
  var stream = this.@controlledReadableStream;
  if (!stream)
    return;
  var sink = this.@sink;
  if (!sink)
    return;
  var reader = @getByIdDirectPrivate(stream, "reader");
  if (!reader || !@isReadableStreamDefaultReader(reader))
    return;
  var _pendingRead = this._pendingRead;
  if (this._pendingRead = @undefined, _pendingRead && @isPromise(_pendingRead)) {
    var flushed = sink.flush();
    if (flushed?.byteLength)
      this._pendingRead = @getByIdDirectPrivate(stream, "readRequests")?.shift(), @fulfillPromise(_pendingRead, { value: flushed, done: !1 });
    else
      this._pendingRead = _pendingRead;
  } else if (@getByIdDirectPrivate(stream, "readRequests")?.isNotEmpty()) {
    var flushed = sink.flush();
    if (flushed?.byteLength)
      @readableStreamFulfillReadRequest(stream, flushed, !1);
  } else if (this._deferFlush === -1)
    this._deferFlush = 1;
})
