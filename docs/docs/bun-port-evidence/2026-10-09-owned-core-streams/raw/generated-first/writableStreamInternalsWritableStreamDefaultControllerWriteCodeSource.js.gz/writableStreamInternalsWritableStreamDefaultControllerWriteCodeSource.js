(function (controller, chunk, chunkSize) {"use strict";
  try {
    @enqueueValueWithSize(@getByIdDirectPrivate(controller, "queue"), chunk, chunkSize);
    let stream = @getByIdDirectPrivate(controller, "stream"), state = @getByIdDirectPrivate(stream, "state");
    if (!@writableStreamCloseQueuedOrInFlight(stream) && state === "writable") {
      let backpressure = @writableStreamDefaultControllerGetBackpressure(controller);
      @writableStreamUpdateBackpressure(stream, backpressure);
    }
    @writableStreamDefaultControllerAdvanceQueueIfNeeded(controller);
  } catch (e) {
    @writableStreamDefaultControllerErrorIfNeeded(controller, e);
  }
})
