(function (controller, view) {"use strict";
  let stream = @getByIdDirectPrivate(controller, "controlledReadableStream"), elementSize = 1, bytesPerElement = view.BYTES_PER_ELEMENT;
  if (bytesPerElement !== @undefined)
    elementSize = bytesPerElement;
  let ctor = view.constructor, pullIntoDescriptor = {
    buffer: view.buffer,
    byteOffset: view.byteOffset,
    byteLength: view.byteLength,
    bytesFilled: 0,
    elementSize,
    ctor,
    readerType: "byob"
  };
  var pending = @getByIdDirectPrivate(controller, "pendingPullIntos");
  if (pending?.isNotEmpty())
    return pullIntoDescriptor.buffer = @transferBufferToCurrentRealm(pullIntoDescriptor.buffer), pending.push(pullIntoDescriptor), @readableStreamAddReadIntoRequest(stream);
  if (@getByIdDirectPrivate(stream, "state") === 1) {
    let emptyView = new ctor(pullIntoDescriptor.buffer, pullIntoDescriptor.byteOffset, 0);
    return @createFulfilledPromise({ value: emptyView, done: !0 });
  }
  if (@getByIdDirectPrivate(controller, "queue").size > 0) {
    if (@readableByteStreamControllerFillDescriptorFromQueue(controller, pullIntoDescriptor)) {
      let filledView = @readableByteStreamControllerConvertDescriptor(pullIntoDescriptor);
      return @readableByteStreamControllerHandleQueueDrain(controller), @createFulfilledPromise({ value: filledView, done: !1 });
    }
    if (@getByIdDirectPrivate(controller, "closeRequested")) {
      let e = @makeTypeError("Closing stream has been requested");
      return @readableByteStreamControllerError(controller, e), @Promise.@reject(e);
    }
  }
  pullIntoDescriptor.buffer = @transferBufferToCurrentRealm(pullIntoDescriptor.buffer), @getByIdDirectPrivate(controller, "pendingPullIntos").push(pullIntoDescriptor);
  let promise = @readableStreamAddReadIntoRequest(stream);
  return @readableByteStreamControllerCallPullIfNeeded(controller), promise;
})
