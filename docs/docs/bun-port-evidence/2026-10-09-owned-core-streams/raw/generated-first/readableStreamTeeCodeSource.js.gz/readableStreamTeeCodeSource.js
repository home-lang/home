(function () {"use strict";
  if (!@isReadableStream(this))
    throw @makeErrorWithCode(140, "ReadableStream");
  return @readableStreamTee(this, !1);
})
