(function (stream, e) {"use strict";
  @transformStreamDefaultControllerClearAlgorithms(@getByIdDirectPrivate(stream, "controller"));
  let writable = @getByIdDirectPrivate(stream, "internalWritable");
  if (@writableStreamDefaultControllerErrorIfNeeded(@getByIdDirectPrivate(writable, "controller"), e), @getByIdDirectPrivate(stream, "backpressure"))
    @transformStreamSetBackpressure(stream, !1);
})
