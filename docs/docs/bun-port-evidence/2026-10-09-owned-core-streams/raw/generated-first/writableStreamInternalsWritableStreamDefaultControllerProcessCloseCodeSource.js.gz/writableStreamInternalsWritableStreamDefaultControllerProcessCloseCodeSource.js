(function (controller) {"use strict";
  let stream = @getByIdDirectPrivate(controller, "stream");
  @writableStreamMarkCloseRequestInFlight(stream), @dequeueValue(@getByIdDirectPrivate(controller, "queue"));
  let sinkClosePromise = @getByIdDirectPrivate(controller, "closeAlgorithm").@call();
  @writableStreamDefaultControllerClearAlgorithms(controller), sinkClosePromise.@then(() => {
    @writableStreamFinishInFlightClose(stream);
  }, (reason) => {
    @writableStreamFinishInFlightCloseWithError(stream, reason);
  });
})
