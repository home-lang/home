(function (object, key, args) {"use strict";
  try {
    return @promiseInvokeOrNoopNoCatch(object, key, args);
  } catch (error) {
    return @Promise.@reject(error);
  }
})
