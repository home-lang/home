(function (stream, chunk, done) {"use strict";
  let readRequest = @getByIdDirectPrivate(@getByIdDirectPrivate(stream, "reader"), "readRequests").shift();
  @fulfillPromise(readRequest, { value: chunk, done });
})
