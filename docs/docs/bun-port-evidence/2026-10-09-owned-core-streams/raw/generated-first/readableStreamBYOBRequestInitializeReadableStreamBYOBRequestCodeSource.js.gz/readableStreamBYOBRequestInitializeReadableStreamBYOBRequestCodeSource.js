(function (controller, view) {"use strict";
  if (arguments.length !== 3 && arguments[2] !== @isReadableStream)
    @throwTypeError("ReadableStreamBYOBRequest constructor should not be called directly");
  return @privateInitializeReadableStreamBYOBRequest.@call(this, controller, view);
})
