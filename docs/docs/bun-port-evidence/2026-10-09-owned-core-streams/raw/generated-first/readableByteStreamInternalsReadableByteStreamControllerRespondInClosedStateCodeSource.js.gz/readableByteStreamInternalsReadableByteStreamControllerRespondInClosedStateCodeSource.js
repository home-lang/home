(function (controller, firstDescriptor) {"use strict";
  if (firstDescriptor.buffer = @transferBufferToCurrentRealm(firstDescriptor.buffer), @readableStreamHasBYOBReader(@getByIdDirectPrivate(controller, "controlledReadableStream")))
    while (@getByIdDirectPrivate(@getByIdDirectPrivate(@getByIdDirectPrivate(controller, "controlledReadableStream"), "reader"), "readIntoRequests")?.isNotEmpty()) {
      let pullIntoDescriptor = @readableByteStreamControllerShiftPendingDescriptor(controller);
      @readableByteStreamControllerCommitDescriptor(@getByIdDirectPrivate(controller, "controlledReadableStream"), pullIntoDescriptor);
    }
})
