(function (controller, chunk) {"use strict";
  let promiseCapability = @newPromiseCapability(@Promise);
  return @getByIdDirectPrivate(controller, "transformAlgorithm").@call(@undefined, chunk).@then(() => {
    promiseCapability.resolve();
  }, (r) => {
    @transformStreamError(@getByIdDirectPrivate(controller, "stream"), r), promiseCapability.reject.@call(@undefined, r);
  }), promiseCapability.promise;
})
