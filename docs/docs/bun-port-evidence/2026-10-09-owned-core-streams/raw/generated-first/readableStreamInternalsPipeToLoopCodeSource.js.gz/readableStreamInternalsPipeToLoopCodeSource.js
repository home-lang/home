(function (pipeState) {"use strict";
  if (pipeState.shuttingDown)
    return;
  @pipeToDoReadWrite(pipeState).@then((result) => {
    if (result)
      @pipeToLoop(pipeState);
  });
})
