(function (reader, reason) {"use strict";
  let stream = @getByIdDirectPrivate(reader, "ownerReadableStream");
  return @readableStreamCancel(stream, reason);
})
