(function (writer) {"use strict";
  let stream = @getByIdDirectPrivate(writer, "stream"), state = @getByIdDirectPrivate(stream, "state");
  if (state === "errored" || state === "erroring")
    return null;
  if (state === "closed")
    return 0;
  return @writableStreamDefaultControllerGetDesiredSize(@getByIdDirectPrivate(stream, "controller"));
})
