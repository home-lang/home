(function (controller, e) {"use strict";
  @transformStreamError(@getByIdDirectPrivate(controller, "stream"), e);
})
