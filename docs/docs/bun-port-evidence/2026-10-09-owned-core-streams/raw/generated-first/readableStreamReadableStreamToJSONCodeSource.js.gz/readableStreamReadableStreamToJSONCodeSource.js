(function (stream) {"use strict";
  if (!@isReadableStream(stream))
    throw @makeErrorWithCode(119, "stream", "ReadableStream", typeof stream);
  if (@isReadableStreamLocked(stream))
    return @Promise.@reject(@makeErrorWithCode(138, "ReadableStream is locked"));
  let result = @tryUseReadableStreamBufferedFastPath(stream, "json");
  if (result)
    return result;
  let text = Bun.readableStreamToText(stream), peeked = Bun.peek(text);
  if (peeked !== text)
    try {
      return @createFulfilledPromise(globalThis.JSON.parse(peeked));
    } catch (e) {
      return @Promise.@reject(e);
    }
  return text.then(globalThis.JSON.parse);
})
