(function (view) {"use strict";
  if (!@isReadableStreamBYOBRequest(this))
    throw @makeErrorWithCode(140, "ReadableStreamBYOBRequest");
  if (@getByIdDirectPrivate(this, "associatedReadableByteStreamController") == null)
    throw @makeErrorWithCode(138, "This BYOB request has been invalidated");
  if (!@isObject(view))
    throw @makeErrorWithCode(119, "view", "Buffer, TypedArray, or DataView", view);
  if (!@ArrayBuffer.@isView(view))
    throw @makeErrorWithCode(119, "view", "Buffer, TypedArray, or DataView", view);
  return @readableByteStreamControllerRespondWithNewView(@getByIdDirectPrivate(this, "associatedReadableByteStreamController"), view);
})
