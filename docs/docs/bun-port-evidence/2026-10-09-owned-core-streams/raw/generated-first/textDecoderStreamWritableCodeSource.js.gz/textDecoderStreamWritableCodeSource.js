(function () {"use strict";
  let transform = @getByIdDirectPrivate(this, "textDecoderStreamTransform");
  if (!transform)
    throw @makeErrorWithCode(140, "TextDecoderStream");
  return @getByIdDirectPrivate(transform, "writable");
})
