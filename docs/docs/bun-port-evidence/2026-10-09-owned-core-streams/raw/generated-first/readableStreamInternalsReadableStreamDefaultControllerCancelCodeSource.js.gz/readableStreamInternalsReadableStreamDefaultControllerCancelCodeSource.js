(function (controller, reason) {"use strict";
  return @putByIdDirectPrivate(controller, "queue", @newQueue()), @getByIdDirectPrivate(controller, "cancelAlgorithm").@call(@undefined, reason);
})
