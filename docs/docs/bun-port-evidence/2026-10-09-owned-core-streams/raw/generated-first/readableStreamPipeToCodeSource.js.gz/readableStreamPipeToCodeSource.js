(function (destination) {"use strict";
  if (!@isReadableStream(this))
    return @Promise.@reject(@makeErrorWithCode(140, "ReadableStream"));
  if (@isReadableStreamLocked(this))
    return @Promise.@reject(@makeErrorWithCode(138, "ReadableStream is locked"));
  let options = @argument(1), preventClose = !1, preventAbort = !1, preventCancel = !1, signal;
  if (!@isUndefinedOrNull(options)) {
    if (!@isObject(options))
      return @Promise.@reject(@makeTypeError("options must be an object"));
    try {
      preventAbort = !!options.preventAbort, preventCancel = !!options.preventCancel, preventClose = !!options.preventClose, signal = options.signal;
    } catch (e) {
      return @Promise.@reject(e);
    }
    if (signal !== @undefined && !@isAbortSignal(signal))
      return @Promise.@reject(@makeTypeError("options.signal must be AbortSignal"));
  }
  let internalDestination = @getInternalWritableStream(destination);
  if (!@isWritableStream(internalDestination))
    return @Promise.@reject(@makeTypeError("ReadableStream pipeTo requires a WritableStream"));
  if (@isWritableStreamLocked(internalDestination))
    return @Promise.@reject(@makeTypeError("WritableStream is locked"));
  return @readableStreamPipeToWritableStream(this, internalDestination, preventClose, preventAbort, preventCancel, signal);
})
