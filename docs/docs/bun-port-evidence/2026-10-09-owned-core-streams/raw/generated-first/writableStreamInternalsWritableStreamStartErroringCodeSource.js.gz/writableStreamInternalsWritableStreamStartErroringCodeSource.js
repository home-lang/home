(function (stream, reason) {"use strict";
  let controller = @getByIdDirectPrivate(stream, "controller");
  @putByIdDirectPrivate(stream, "state", "erroring"), @putByIdDirectPrivate(stream, "storedError", reason);
  let writer = @getByIdDirectPrivate(stream, "writer");
  if (writer !== @undefined)
    @writableStreamDefaultWriterEnsureReadyPromiseRejected(writer, reason);
  if (!@writableStreamHasOperationMarkedInFlight(stream) && @getByIdDirectPrivate(controller, "started") === 1)
    @writableStreamFinishErroring(stream);
})
