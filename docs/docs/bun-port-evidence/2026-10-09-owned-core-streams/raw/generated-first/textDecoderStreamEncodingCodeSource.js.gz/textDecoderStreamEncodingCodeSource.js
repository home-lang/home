(function () {"use strict";
  if (!@getByIdDirectPrivate(this, "textDecoderStreamTransform"))
    throw @makeErrorWithCode(140, "TextDecoderStream");
  return @getByIdDirectPrivate(this, "encoding");
})
