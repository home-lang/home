(function (stream) {"use strict";
  if (!@isReadableStream(stream))
    throw @makeErrorWithCode(119, "stream", "ReadableStream", typeof stream);
  var underlyingSource = @getByIdDirectPrivate(stream, "underlyingSource");
  if (underlyingSource != null)
    return @readableStreamToArrayBufferDirect(stream, underlyingSource, !0);
  if (@isReadableStreamLocked(stream))
    return @Promise.@reject(@makeErrorWithCode(138, "ReadableStream is locked"));
  let result = @tryUseReadableStreamBufferedFastPath(stream, "bytes");
  if (result)
    return result;
  result = Bun.readableStreamToArray(stream);
  function toBytes(result2) {
    switch (result2.length) {
      case 0:
        return new @Uint8Array(0);
      case 1: {
        let view = result2[0];
        if (view instanceof @Uint8Array)
          return view;
        if (@ArrayBuffer.isView(view))
          return new @Uint8Array(view.buffer, view.byteOffset, view.byteLength);
        if (view instanceof @ArrayBuffer || view instanceof SharedArrayBuffer)
          return new @Uint8Array(view);
        if (typeof view === "string")
          return (/* @__PURE__ */ new TextEncoder()).encode(view);
      }
      default: {
        let anyStrings = !1;
        for (let chunk of result2)
          if (typeof chunk === "string") {
            anyStrings = !0;
            break;
          }
        if (!anyStrings)
          return Bun.concatArrayBuffers(result2, !0);
        let sink = new Bun.ArrayBufferSink;
        sink.start({ asUint8Array: !0 });
        for (let chunk of result2)
          sink.write(chunk);
        return sink.end();
      }
    }
  }
  if (@isPromise(result)) {
    let completedResult = Bun.peek(result);
    if (completedResult !== result)
      result = completedResult;
    else
      return result.then(toBytes);
  }
  return @createFulfilledPromise(toBytes(result));
})
