(function (stream) {"use strict";
  if (!@isReadableStream(stream))
    @throwTypeError("ReadableStreamBYOBReader needs a ReadableStream");
  if (!@isReadableByteStreamController(@getByIdDirectPrivate(stream, "readableStreamController")))
    @throwTypeError("ReadableStreamBYOBReader needs a ReadableByteStreamController");
  if (@isReadableStreamLocked(stream))
    @throwTypeError("ReadableStream is locked");
  return @readableStreamReaderGenericInitialize(this, stream), @putByIdDirectPrivate(this, "readIntoRequests", @createFIFO()), this;
})
