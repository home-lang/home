(function () {"use strict";
  if (!@isReadableByteStreamController(this))
    throw @makeGetterTypeError("ReadableByteStreamController", "desiredSize");
  return @readableByteStreamControllerGetDesiredSize(this);
})
