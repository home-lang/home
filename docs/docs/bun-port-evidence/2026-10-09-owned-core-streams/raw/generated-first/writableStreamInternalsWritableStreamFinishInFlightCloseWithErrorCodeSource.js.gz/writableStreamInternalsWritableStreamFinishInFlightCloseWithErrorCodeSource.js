(function (stream, error) {"use strict";
  @getByIdDirectPrivate(stream, "inFlightCloseRequest").reject.@call(@undefined, error), @putByIdDirectPrivate(stream, "inFlightCloseRequest", @undefined);
  let state = @getByIdDirectPrivate(stream, "state"), abortRequest = @getByIdDirectPrivate(stream, "pendingAbortRequest");
  if (abortRequest !== @undefined)
    abortRequest.promise.reject.@call(@undefined, error), @putByIdDirectPrivate(stream, "pendingAbortRequest", @undefined);
  @writableStreamDealWithRejection(stream, error);
})
