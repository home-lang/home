(function (controller) {"use strict";
  let stream = @getByIdDirectPrivate(controller, "controlledReadableStream");
  if (!stream)
    return null;
  let state = @getByIdDirectPrivate(stream, "state");
  if (state === 3)
    return null;
  if (state === 1)
    return 0;
  return @getByIdDirectPrivate(controller, "strategy").highWaterMark - @getByIdDirectPrivate(controller, "queue").size;
})
