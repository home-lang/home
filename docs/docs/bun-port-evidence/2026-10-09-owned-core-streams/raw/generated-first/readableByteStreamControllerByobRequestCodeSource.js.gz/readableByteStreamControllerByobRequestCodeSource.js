(function () {"use strict";
  if (!@isReadableByteStreamController(this))
    throw @makeGetterTypeError("ReadableByteStreamController", "byobRequest");
  var request = @getByIdDirectPrivate(this, "byobRequest");
  if (request === @undefined) {
    var pending = @getByIdDirectPrivate(this, "pendingPullIntos");
    let firstDescriptor = pending.peek();
    if (firstDescriptor) {
      let view = new @Uint8Array(firstDescriptor.buffer, firstDescriptor.byteOffset + firstDescriptor.bytesFilled, firstDescriptor.byteLength - firstDescriptor.bytesFilled);
      @putByIdDirectPrivate(this, "byobRequest", new @ReadableStreamBYOBRequest(this, view, @isReadableStream));
    }
  }
  return @getByIdDirectPrivate(this, "byobRequest");
})
