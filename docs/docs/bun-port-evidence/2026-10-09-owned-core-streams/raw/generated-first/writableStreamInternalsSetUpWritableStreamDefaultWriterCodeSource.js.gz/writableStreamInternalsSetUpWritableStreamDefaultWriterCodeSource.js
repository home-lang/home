(function (writer, stream) {"use strict";
  if (@isWritableStreamLocked(stream))
    @throwTypeError("WritableStream is locked");
  @putByIdDirectPrivate(writer, "stream", stream), @putByIdDirectPrivate(stream, "writer", writer);
  let readyPromiseCapability = @newPromiseCapability(@Promise), closedPromiseCapability = @newPromiseCapability(@Promise);
  @putByIdDirectPrivate(writer, "readyPromise", readyPromiseCapability), @putByIdDirectPrivate(writer, "closedPromise", closedPromiseCapability);
  let state = @getByIdDirectPrivate(stream, "state");
  if (state === "writable") {
    if (@writableStreamCloseQueuedOrInFlight(stream) || !@getByIdDirectPrivate(stream, "backpressure"))
      readyPromiseCapability.resolve.@call();
  } else if (state === "erroring")
    readyPromiseCapability.reject.@call(@undefined, @getByIdDirectPrivate(stream, "storedError")), @markPromiseAsHandled(readyPromiseCapability.promise);
  else if (state === "closed")
    readyPromiseCapability.resolve.@call(), closedPromiseCapability.resolve.@call();
  else {
    let storedError = @getByIdDirectPrivate(stream, "storedError");
    readyPromiseCapability.reject.@call(@undefined, storedError), @markPromiseAsHandled(readyPromiseCapability.promise), closedPromiseCapability.reject.@call(@undefined, storedError), @markPromiseAsHandled(closedPromiseCapability.promise);
  }
})
