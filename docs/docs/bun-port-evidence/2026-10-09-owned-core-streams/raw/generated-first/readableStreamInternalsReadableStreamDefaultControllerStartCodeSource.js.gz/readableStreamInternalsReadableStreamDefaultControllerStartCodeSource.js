(function (controller) {"use strict";
  if (@getByIdDirectPrivate(controller, "started") !== -1)
    return;
  let underlyingSource = @getByIdDirectPrivate(controller, "underlyingSource"), startMethod = underlyingSource.start;
  @putByIdDirectPrivate(controller, "started", 0), @promiseInvokeOrNoopMethodNoCatch(underlyingSource, startMethod, [controller]).@then(() => {
    @putByIdDirectPrivate(controller, "started", 1), @readableStreamDefaultControllerCallPullIfNeeded(controller);
  }, (error) => {
    @readableStreamDefaultControllerError(controller, error);
  });
})
