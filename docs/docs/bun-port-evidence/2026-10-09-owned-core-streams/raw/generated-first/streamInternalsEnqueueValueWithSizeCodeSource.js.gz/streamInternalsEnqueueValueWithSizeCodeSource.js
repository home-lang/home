(function (queue, value, size) {"use strict";
  if (size = @toNumber(size), !@isFinite(size) || size < 0)
    @throwRangeError("size has an incorrect value");
  queue.content.push({ value, size }), queue.size += size;
})
