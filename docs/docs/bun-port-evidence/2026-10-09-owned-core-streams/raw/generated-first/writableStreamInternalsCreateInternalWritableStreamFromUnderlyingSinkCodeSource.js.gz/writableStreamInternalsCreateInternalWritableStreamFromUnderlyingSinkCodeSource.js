(function (underlyingSink, strategy) {"use strict";
  let stream = {};
  if (underlyingSink === @undefined)
    underlyingSink = {};
  if (strategy === @undefined)
    strategy = {};
  if (!@isObject(underlyingSink))
    @throwTypeError("WritableStream constructor takes an object as first argument");
  if ("type" in underlyingSink)
    @throwRangeError("Invalid type is specified");
  let sizeAlgorithm = @extractSizeAlgorithm(strategy), highWaterMark = @extractHighWaterMark(strategy, 1), underlyingSinkDict = {};
  if ("start" in underlyingSink) {
    if (underlyingSinkDict.start = underlyingSink.start, typeof underlyingSinkDict.start !== "function")
      @throwTypeError("underlyingSink.start should be a function");
  }
  if ("write" in underlyingSink) {
    if (underlyingSinkDict.write = underlyingSink.write, typeof underlyingSinkDict.write !== "function")
      @throwTypeError("underlyingSink.write should be a function");
  }
  if ("close" in underlyingSink) {
    if (underlyingSinkDict.close = underlyingSink.close, typeof underlyingSinkDict.close !== "function")
      @throwTypeError("underlyingSink.close should be a function");
  }
  if ("abort" in underlyingSink) {
    if (underlyingSinkDict.abort = underlyingSink.abort, typeof underlyingSinkDict.abort !== "function")
      @throwTypeError("underlyingSink.abort should be a function");
  }
  return @initializeWritableStreamSlots(stream, underlyingSink), @setUpWritableStreamDefaultControllerFromUnderlyingSink(stream, underlyingSink, underlyingSinkDict, highWaterMark, sizeAlgorithm), stream;
})
