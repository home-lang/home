(function () {"use strict";
  if (!@isWritableStreamDefaultWriter(this))
    return @Promise.@reject(@makeGetterTypeError("WritableStreamDefaultWriter", "closed"));
  return @getByIdDirectPrivate(this, "closedPromise").promise;
})
