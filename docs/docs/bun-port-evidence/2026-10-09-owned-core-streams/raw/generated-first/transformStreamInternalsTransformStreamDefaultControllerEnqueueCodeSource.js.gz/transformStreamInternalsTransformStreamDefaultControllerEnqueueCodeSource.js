(function (controller, chunk) {"use strict";
  let stream = @getByIdDirectPrivate(controller, "stream"), readable = @getByIdDirectPrivate(stream, "readable"), readableController = @getByIdDirectPrivate(readable, "readableStreamController");
  if (!@readableStreamDefaultControllerCanCloseOrEnqueue(readableController))
    @throwTypeError("TransformStream.readable cannot close or enqueue");
  try {
    @readableStreamDefaultControllerEnqueue(readableController, chunk);
  } catch (e) {
    throw @transformStreamErrorWritableAndUnblockWrite(stream, e), @getByIdDirectPrivate(readable, "storedError");
  }
  if (!@readableStreamDefaultControllerShouldCallPull(readableController) !== @getByIdDirectPrivate(stream, "backpressure"))
    @transformStreamSetBackpressure(stream, !0);
})
