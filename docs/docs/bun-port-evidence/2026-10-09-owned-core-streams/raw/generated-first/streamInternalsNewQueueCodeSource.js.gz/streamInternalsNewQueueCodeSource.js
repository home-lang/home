(function () {"use strict";
  return { content: @createFIFO(), size: 0 };
})
