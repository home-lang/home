(function (controller, bytesWritten) {"use strict";
  let firstDescriptor = @getByIdDirectPrivate(controller, "pendingPullIntos").peek(), stream = @getByIdDirectPrivate(controller, "controlledReadableStream");
  if (@getByIdDirectPrivate(stream, "state") === 1)
    @readableByteStreamControllerRespondInClosedState(controller, firstDescriptor);
  else
    @readableByteStreamControllerRespondInReadableState(controller, bytesWritten, firstDescriptor);
})
