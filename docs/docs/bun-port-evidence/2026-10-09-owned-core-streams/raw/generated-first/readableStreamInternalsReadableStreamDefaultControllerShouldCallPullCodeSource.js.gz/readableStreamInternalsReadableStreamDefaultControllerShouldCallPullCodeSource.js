(function (controller) {"use strict";
  if (!@readableStreamDefaultControllerCanCloseOrEnqueue(controller))
    return !1;
  if (@getByIdDirectPrivate(controller, "started") !== 1)
    return !1;
  let stream = @getByIdDirectPrivate(controller, "controlledReadableStream");
  if ((!@isReadableStreamLocked(stream) || !@getByIdDirectPrivate(@getByIdDirectPrivate(stream, "reader"), "readRequests")?.isNotEmpty()) && @readableStreamDefaultControllerGetDesiredSize(controller) <= 0)
    return !1;
  return @readableStreamDefaultControllerGetDesiredSize(controller) > 0;
})
