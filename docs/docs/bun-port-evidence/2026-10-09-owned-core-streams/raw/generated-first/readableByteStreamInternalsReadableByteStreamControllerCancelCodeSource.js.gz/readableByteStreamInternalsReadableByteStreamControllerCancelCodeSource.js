(function (controller, reason) {"use strict";
  var pendingPullIntos = @getByIdDirectPrivate(controller, "pendingPullIntos"), first = pendingPullIntos.peek();
  if (first)
    first.bytesFilled = 0;
  return @putByIdDirectPrivate(controller, "queue", @newQueue()), @promiseInvokeOrNoop(@getByIdDirectPrivate(controller, "underlyingByteSource"), "cancel", [reason]);
})
