(function (controller) {"use strict";
  if (@putByIdDirectPrivate(controller, "closeRequested", !0), @getByIdDirectPrivate(controller, "queue")?.content?.isEmpty())
    @readableStreamCloseIfPossible(@getByIdDirectPrivate(controller, "controlledReadableStream"));
})
