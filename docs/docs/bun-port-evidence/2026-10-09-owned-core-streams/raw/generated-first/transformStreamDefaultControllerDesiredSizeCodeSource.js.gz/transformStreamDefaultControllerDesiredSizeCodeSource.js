(function () {"use strict";
  if (!@isTransformStreamDefaultController(this))
    throw @makeErrorWithCode(140, "TransformStreamDefaultController");
  let stream = @getByIdDirectPrivate(this, "stream"), readable = @getByIdDirectPrivate(stream, "readable"), readableController = @getByIdDirectPrivate(readable, "readableStreamController");
  return @readableStreamDefaultControllerGetDesiredSize(readableController);
})
