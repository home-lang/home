(function (stream) {"use strict";
  return @transformStreamSetBackpressure(stream, !1), @getByIdDirectPrivate(stream, "backpressureChangePromise").promise;
})
