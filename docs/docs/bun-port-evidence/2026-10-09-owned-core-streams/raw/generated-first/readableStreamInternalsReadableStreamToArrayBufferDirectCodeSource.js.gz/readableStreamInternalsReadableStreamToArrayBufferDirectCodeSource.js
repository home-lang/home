(function (stream, underlyingSource, asUint8Array) {"use strict";
  var sink = new Bun.ArrayBufferSink;
  @putByIdDirectPrivate(stream, "underlyingSource", null), @putByIdDirectPrivate(stream, "start", @undefined), @putByIdDirectPrivate(stream, "reader", {}), stream.@disturbed = !0;
  var highWaterMark = @getByIdDirectPrivate(stream, "highWaterMark");
  sink.start({ highWaterMark, asUint8Array });
  var capability = @newPromiseCapability(@Promise), ended = !1, pull = underlyingSource.pull, close = underlyingSource.close, controller = {
    start() {},
    close(_reason) {
      if (!ended) {
        if (ended = !0, close)
          close();
        @fulfillPromise(capability.promise, sink.end());
      }
    },
    end() {
      if (!ended) {
        if (ended = !0, close)
          close();
        @fulfillPromise(capability.promise, sink.end());
      }
    },
    flush() {
      return 0;
    },
    write: sink.write.bind(sink)
  }, didError = !1;
  try {
    var firstPull = pull(controller);
  } catch (e) {
    return didError = !0, @putByIdDirectPrivate(stream, "reader", @undefined), @readableStreamError(stream, e), @Promise.@reject(e);
  } finally {
    if (!@isPromise(firstPull) && !didError) {
      if (stream)
        @putByIdDirectPrivate(stream, "reader", @undefined), @readableStreamCloseIfPossible(stream);
      return controller = close = sink = pull = stream = @undefined, capability.promise;
    }
  }
  return firstPull.then(() => {
    if (!didError && stream)
      @putByIdDirectPrivate(stream, "reader", @undefined), @readableStreamCloseIfPossible(stream);
    return controller = close = sink = pull = stream = @undefined, capability.promise;
  }, (e) => {
    if (didError = !0, @putByIdDirectPrivate(stream, "reader", @undefined), @getByIdDirectPrivate(stream, "state") === 4)
      @readableStreamError(stream, e);
    return @Promise.@reject(e);
  });
})
