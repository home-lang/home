(function (controller, bytesWritten) {"use strict";
  if (bytesWritten = @toNumber(bytesWritten), bytesWritten !== bytesWritten || bytesWritten === @Infinity || bytesWritten < 0)
    @throwRangeError("bytesWritten has an incorrect value");
  @readableByteStreamControllerRespondInternal(controller, bytesWritten);
})
