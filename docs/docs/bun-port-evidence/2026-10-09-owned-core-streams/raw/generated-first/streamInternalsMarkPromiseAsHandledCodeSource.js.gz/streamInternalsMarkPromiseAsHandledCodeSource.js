(function (promise) {"use strict";
  @pokePromiseAsHandled(promise);
})
