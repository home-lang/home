(function (stream) {"use strict";
  let readRequest = @newPromise();
  return @getByIdDirectPrivate(@getByIdDirectPrivate(stream, "reader"), "readIntoRequests").push(readRequest), readRequest;
})
