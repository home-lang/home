(function () {"use strict";
  if (!@getByIdDirectPrivate(this, "textEncoderStreamTransform"))
    throw @makeErrorWithCode(140, "TextEncoderStream");
  return "utf-8";
})
