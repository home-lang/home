(function (controller) {"use strict";
  if (@getByIdDirectPrivate(controller, "started") !== -1)
    return;
  @putByIdDirectPrivate(controller, "started", 0);
  let startAlgorithm = @getByIdDirectPrivate(controller, "startAlgorithm");
  @putByIdDirectPrivate(controller, "startAlgorithm", @undefined);
  let stream = @getByIdDirectPrivate(controller, "stream");
  return @Promise.@resolve(startAlgorithm.@call()).@then(() => {
    let state = @getByIdDirectPrivate(stream, "state");
    @putByIdDirectPrivate(controller, "started", 1), @writableStreamDefaultControllerAdvanceQueueIfNeeded(controller);
  }, (error) => {
    let state = @getByIdDirectPrivate(stream, "state");
    @putByIdDirectPrivate(controller, "started", 1), @writableStreamDealWithRejection(stream, error);
  });
})
