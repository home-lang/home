(function (stream) {"use strict";
  let writePromiseCapability = @newPromiseCapability(@Promise);
  return @getByIdDirectPrivate(stream, "writeRequests").push(writePromiseCapability), writePromiseCapability.promise;
})
