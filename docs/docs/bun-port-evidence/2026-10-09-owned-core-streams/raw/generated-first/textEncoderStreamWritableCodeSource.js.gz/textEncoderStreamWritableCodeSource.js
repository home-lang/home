(function () {"use strict";
  let transform = @getByIdDirectPrivate(this, "textEncoderStreamTransform");
  if (!transform)
    throw @makeErrorWithCode(140, "TextEncoderStream");
  return @getByIdDirectPrivate(transform, "writable");
})
