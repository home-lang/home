(function (stream, backpressure) {"use strict";
  let writer = @getByIdDirectPrivate(stream, "writer");
  if (writer !== @undefined && backpressure !== @getByIdDirectPrivate(stream, "backpressure"))
    if (backpressure)
      @putByIdDirectPrivate(writer, "readyPromise", @newPromiseCapability(@Promise));
    else
      @getByIdDirectPrivate(writer, "readyPromise").resolve.@call();
  @putByIdDirectPrivate(stream, "backpressure", backpressure);
})
