(function () {"use strict";
  let transformer = arguments[0];
  if (@isObject(transformer) && @getByIdDirectPrivate(transformer, "TransformStream"))
    return this;
  let writableStrategy = arguments[1], readableStrategy = arguments[2];
  if (transformer === @undefined)
    transformer = null;
  if (readableStrategy === @undefined)
    readableStrategy = {};
  if (writableStrategy === @undefined)
    writableStrategy = {};
  let transformerDict = {};
  if (transformer !== null) {
    if ("start" in transformer) {
      if (transformerDict.start = transformer.start, typeof transformerDict.start !== "function")
        @throwTypeError("transformer.start should be a function");
    }
    if ("transform" in transformer) {
      if (transformerDict.transform = transformer.transform, typeof transformerDict.transform !== "function")
        @throwTypeError("transformer.transform should be a function");
    }
    if ("flush" in transformer) {
      if (transformerDict.flush = transformer.flush, typeof transformerDict.flush !== "function")
        @throwTypeError("transformer.flush should be a function");
    }
    if ("readableType" in transformer)
      @throwRangeError("TransformStream transformer has a readableType");
    if ("writableType" in transformer)
      @throwRangeError("TransformStream transformer has a writableType");
  }
  let readableHighWaterMark = @extractHighWaterMark(readableStrategy, 0), readableSizeAlgorithm = @extractSizeAlgorithm(readableStrategy), writableHighWaterMark = @extractHighWaterMark(writableStrategy, 1), writableSizeAlgorithm = @extractSizeAlgorithm(writableStrategy), startPromiseCapability = @newPromiseCapability(@Promise);
  if (@initializeTransformStream(this, startPromiseCapability.promise, writableHighWaterMark, writableSizeAlgorithm, readableHighWaterMark, readableSizeAlgorithm), @setUpTransformStreamDefaultControllerFromTransformer(this, transformer, transformerDict), "start" in transformerDict) {
    let controller = @getByIdDirectPrivate(this, "controller");
    (() => @promiseInvokeOrNoopMethodNoCatch(transformer, transformerDict.start, [controller]))().@then(() => {
      startPromiseCapability.resolve.@call();
    }, (error) => {
      startPromiseCapability.reject.@call(@undefined, error);
    });
  } else
    startPromiseCapability.resolve.@call();
  return this;
})
