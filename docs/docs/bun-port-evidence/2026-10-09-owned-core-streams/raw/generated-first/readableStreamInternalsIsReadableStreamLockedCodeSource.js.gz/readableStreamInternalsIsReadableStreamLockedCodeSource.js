(function (stream) {"use strict";
  return !!@getByIdDirectPrivate(stream, "reader") || stream.@bunNativePtr === -1;
})
