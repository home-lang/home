(function (controller) {"use strict";
  return @isObject(controller) && !!@getByIdDirectPrivate(controller, "transformAlgorithm");
})
