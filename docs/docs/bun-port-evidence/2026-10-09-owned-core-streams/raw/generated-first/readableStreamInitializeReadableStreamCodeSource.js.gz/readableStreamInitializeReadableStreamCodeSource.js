(function (underlyingSource, strategy) {"use strict";
  if (underlyingSource === @undefined)
    underlyingSource = { @bunNativePtr: @undefined, @lazy: !1 };
  if (strategy === @undefined)
    strategy = {};
  if (!@isObject(underlyingSource))
    @throwTypeError("ReadableStream constructor takes an object as first argument");
  if (strategy !== @undefined && !@isObject(strategy))
    @throwTypeError("ReadableStream constructor takes an object as second argument, if any");
  @putByIdDirectPrivate(this, "state", 4), @putByIdDirectPrivate(this, "reader", @undefined), @putByIdDirectPrivate(this, "storedError", @undefined), this.@disturbed = !1, @putByIdDirectPrivate(this, "readableStreamController", null), this.@bunNativePtr = @getByIdDirectPrivate(underlyingSource, "bunNativePtr") ?? @undefined, @putByIdDirectPrivate(this, "asyncContext", @getInternalField(@asyncContext, 0));
  let isDirect = underlyingSource.type === "direct", isUnderlyingSourceLazy = !!underlyingSource.@lazy, isLazy = isDirect || isUnderlyingSourceLazy, pullFn;
  if (!isLazy && (pullFn = @getByIdDirectPrivate(underlyingSource, "pull")) !== @undefined) {
    let size = @getByIdDirectPrivate(strategy, "size"), highWaterMark = @getByIdDirectPrivate(strategy, "highWaterMark");
    return @putByIdDirectPrivate(this, "highWaterMark", highWaterMark), @putByIdDirectPrivate(this, "underlyingSource", @undefined), @setupReadableStreamDefaultController(this, underlyingSource, size, highWaterMark !== @undefined ? highWaterMark : 1, @getByIdDirectPrivate(underlyingSource, "start"), pullFn, @getByIdDirectPrivate(underlyingSource, "cancel")), this;
  }
  if (isDirect)
    @putByIdDirectPrivate(this, "underlyingSource", underlyingSource), @putByIdDirectPrivate(this, "highWaterMark", @getByIdDirectPrivate(strategy, "highWaterMark")), @putByIdDirectPrivate(this, "start", () => @createReadableStreamController(this, underlyingSource, strategy));
  else if (isLazy) {
    let autoAllocateChunkSize = underlyingSource.autoAllocateChunkSize;
    @putByIdDirectPrivate(this, "highWaterMark", @undefined), @putByIdDirectPrivate(this, "underlyingSource", @undefined), @putByIdDirectPrivate(this, "highWaterMark", autoAllocateChunkSize || @getByIdDirectPrivate(strategy, "highWaterMark")), @putByIdDirectPrivate(this, "start", () => {
      let instance = @lazyLoadStream(this, autoAllocateChunkSize);
      if (instance)
        @createReadableStreamController(this, instance, strategy);
    });
  } else
    @putByIdDirectPrivate(this, "underlyingSource", @undefined), @putByIdDirectPrivate(this, "highWaterMark", @getByIdDirectPrivate(strategy, "highWaterMark")), @putByIdDirectPrivate(this, "start", @undefined), @createReadableStreamController(this, underlyingSource, strategy);
  return this;
})
