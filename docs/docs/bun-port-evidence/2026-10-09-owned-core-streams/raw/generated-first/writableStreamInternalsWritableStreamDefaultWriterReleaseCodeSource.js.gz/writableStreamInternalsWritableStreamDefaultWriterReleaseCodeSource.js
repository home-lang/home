(function (writer) {"use strict";
  let stream = @getByIdDirectPrivate(writer, "stream"), releasedError = @makeTypeError("writableStreamDefaultWriterRelease");
  @writableStreamDefaultWriterEnsureReadyPromiseRejected(writer, releasedError), @writableStreamDefaultWriterEnsureClosedPromiseRejected(writer, releasedError), @putByIdDirectPrivate(stream, "writer", @undefined), @putByIdDirectPrivate(writer, "stream", @undefined);
})
