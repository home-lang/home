(function () {"use strict";
  if (!@isReadableStreamDefaultReader(this))
    @throwTypeError("ReadableStreamDefaultReader.readMany() should not be called directly");
  let stream = @getByIdDirectPrivate(this, "ownerReadableStream");
  if (!stream)
    throw @makeErrorWithCode(138, "The reader is not attached to a stream");
  let state = @getByIdDirectPrivate(stream, "state");
  if (stream.@disturbed = !0, state === 3)
    throw @getByIdDirectPrivate(stream, "storedError");
  var controller = @getByIdDirectPrivate(stream, "readableStreamController");
  if (controller)
    var queue = @getByIdDirectPrivate(controller, "queue");
  if (!queue && state !== 1)
    return controller.@pull(controller).@then(function({ done, value }) {
      return done ? { done: !0, value: value ? [value] : [], size: 0 } : { value: [value], size: 1, done: !1 };
    });
  else if (!queue)
    return { done: !0, value: [], size: 0 };
  let content = queue.content;
  var size = queue.size, values = content.toArray(!1), length = values.length;
  if (length > 0) {
    var outValues = @newArrayWithSize(length);
    if (@isReadableByteStreamController(controller)) {
      {
        let buf = values[0];
        if (!(@ArrayBuffer.@isView(buf) || buf instanceof @ArrayBuffer))
          @putByValDirect(outValues, 0, new @Uint8Array(buf.buffer, buf.byteOffset, buf.byteLength));
        else
          @putByValDirect(outValues, 0, buf);
      }
      for (var i = 1;i < length; i++) {
        let buf = values[i];
        if (!(@ArrayBuffer.@isView(buf) || buf instanceof @ArrayBuffer))
          @putByValDirect(outValues, i, new @Uint8Array(buf.buffer, buf.byteOffset, buf.byteLength));
        else
          @putByValDirect(outValues, i, buf);
      }
    } else {
      @putByValDirect(outValues, 0, values[0].value);
      for (var i = 1;i < length; i++)
        @putByValDirect(outValues, i, values[i].value);
    }
    if (state !== 1) {
      if (@getByIdDirectPrivate(controller, "closeRequested"))
        @readableStreamCloseIfPossible(@getByIdDirectPrivate(controller, "controlledReadableStream"));
      else if (@isReadableStreamDefaultController(controller))
        @readableStreamDefaultControllerCallPullIfNeeded(controller);
      else if (@isReadableByteStreamController(controller))
        @readableByteStreamControllerCallPullIfNeeded(controller);
    }
    return @resetQueue(@getByIdDirectPrivate(controller, "queue")), { value: outValues, size, done: !1 };
  }
  var onPullMany = (result) => {
    let resultValue = result.value;
    if (result.done)
      return { value: resultValue ? [resultValue] : [], size: 0, done: !0 };
    var controller2 = @getByIdDirectPrivate(stream, "readableStreamController"), queue2 = @getByIdDirectPrivate(controller2, "queue"), value = [resultValue].concat(queue2.content.toArray(!1)), length2 = value.length;
    if (@isReadableByteStreamController(controller2))
      for (var i2 = 0;i2 < length2; i2++) {
        let buf = value[i2];
        if (!(@ArrayBuffer.@isView(buf) || buf instanceof @ArrayBuffer)) {
          let { buffer, byteOffset, byteLength } = buf;
          @putByValDirect(value, i2, new @Uint8Array(buffer, byteOffset, byteLength));
        }
      }
    else
      for (var i2 = 1;i2 < length2; i2++)
        @putByValDirect(value, i2, value[i2].value);
    var size2 = queue2.size;
    if (@getByIdDirectPrivate(controller2, "closeRequested"))
      @readableStreamCloseIfPossible(@getByIdDirectPrivate(controller2, "controlledReadableStream"));
    else if (@isReadableStreamDefaultController(controller2))
      @readableStreamDefaultControllerCallPullIfNeeded(controller2);
    else if (@isReadableByteStreamController(controller2))
      @readableByteStreamControllerCallPullIfNeeded(controller2);
    return @resetQueue(@getByIdDirectPrivate(controller2, "queue")), { value, size: size2, done: !1 };
  };
  if (state === 1)
    return { value: [], size: 0, done: !0 };
  var pullResult = controller.@pull(controller);
  if (pullResult && @isPromise(pullResult))
    return pullResult.then(onPullMany);
  return onPullMany(pullResult);
})
