(function (stream) {"use strict";
  let highWaterMark = @getByIdDirectPrivate(stream, "highWaterMark"), [textStream, closer] = @createTextStream(highWaterMark), prom = @readStreamIntoSink(stream, textStream, !1);
  if (prom && @isPromise(prom))
    return @Promise.@resolve(prom).@then(closer.promise).@then(@withoutUTF8BOM);
  return closer.promise.@then(@withoutUTF8BOM);
})
