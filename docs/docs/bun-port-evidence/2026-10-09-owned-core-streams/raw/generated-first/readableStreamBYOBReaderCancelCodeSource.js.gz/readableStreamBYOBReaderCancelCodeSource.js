(function (reason) {"use strict";
  if (!@isReadableStreamBYOBReader(this))
    return @Promise.@reject(@makeErrorWithCode(140, "ReadableStreamBYOBReader"));
  if (!@getByIdDirectPrivate(this, "ownerReadableStream"))
    return @Promise.@reject(@makeErrorWithCode(138, "The reader is not attached to a stream"));
  return @readableStreamReaderGenericCancel(this, reason);
})
