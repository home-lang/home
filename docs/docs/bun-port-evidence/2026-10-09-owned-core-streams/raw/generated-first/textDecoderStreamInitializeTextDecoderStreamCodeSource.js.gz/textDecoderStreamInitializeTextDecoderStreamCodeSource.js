(function () {"use strict";
  let label = arguments.length >= 1 ? arguments[0] : "utf-8", options = arguments.length >= 2 ? arguments[1] : {}, startAlgorithm = () => {
    return @Promise.@resolve();
  }, transformAlgorithm = (chunk) => {
    let decoder2 = @getByIdDirectPrivate(this, "textDecoder"), buffer;
    try {
      buffer = decoder2.decode(chunk, { stream: !0 });
    } catch (e) {
      return @Promise.@reject(e);
    }
    if (buffer) {
      let transformStream = @getByIdDirectPrivate(this, "textDecoderStreamTransform"), controller = @getByIdDirectPrivate(transformStream, "controller");
      @transformStreamDefaultControllerEnqueue(controller, buffer);
    }
    return @Promise.@resolve();
  }, flushAlgorithm = () => {
    let decoder2 = @getByIdDirectPrivate(this, "textDecoder"), buffer;
    try {
      buffer = decoder2.decode(@undefined, { stream: !1 });
    } catch (e) {
      return @Promise.@reject(e);
    }
    if (buffer) {
      let transformStream = @getByIdDirectPrivate(this, "textDecoderStreamTransform"), controller = @getByIdDirectPrivate(transformStream, "controller");
      @transformStreamDefaultControllerEnqueue(controller, buffer);
    }
    return @Promise.@resolve();
  }, transform = @createTransformStream(startAlgorithm, transformAlgorithm, flushAlgorithm);
  @putByIdDirectPrivate(this, "textDecoderStreamTransform", transform);
  let fatal = !!options.fatal, ignoreBOM = !!options.ignoreBOM, decoder = new TextDecoder(label, { fatal, ignoreBOM });
  return @putByIdDirectPrivate(this, "fatal", fatal), @putByIdDirectPrivate(this, "ignoreBOM", ignoreBOM), @putByIdDirectPrivate(this, "encoding", decoder.encoding), @putByIdDirectPrivate(this, "textDecoder", decoder), this;
})
