(function (underlyingSource, _highWaterMark) {"use strict";
  var array = [], closingPromise = @newPromiseCapability(@Promise), calledDone = !1;
  function fulfill() {
    return calledDone = !0, closingPromise.resolve.@call(@undefined, array), array;
  }
  var sink = {
    start() {},
    write(chunk) {
      return @arrayPush(array, chunk), chunk.byteLength || chunk.length;
    },
    flush() {
      return 0;
    },
    end() {
      if (calledDone)
        return [];
      return fulfill();
    },
    close() {
      if (!calledDone)
        fulfill();
    }
  }, controller = {
    @underlyingSource: underlyingSource,
    @pull: @onPullDirectStream,
    @controlledReadableStream: this,
    @sink: sink,
    close: @onCloseDirectStream,
    write: sink.write,
    error: @handleDirectStreamError,
    end: @onCloseDirectStream,
    @close: @onCloseDirectStream,
    flush: @onFlushDirectStream,
    _pendingRead: @undefined,
    _deferClose: 0,
    _deferFlush: 0,
    _deferCloseReason: @undefined,
    _handleError: @undefined
  };
  return @putByIdDirectPrivate(this, "readableStreamController", controller), @putByIdDirectPrivate(this, "underlyingSource", null), @putByIdDirectPrivate(this, "start", @undefined), closingPromise;
})
