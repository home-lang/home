(function () {"use strict";
  if (!@isReadableStreamDefaultReader(this))
    return @Promise.@reject(@makeGetterTypeError("ReadableStreamDefaultReader", "closed"));
  return @getByIdDirectPrivate(this, "closedPromiseCapability").promise;
})
