(function (stream) {"use strict";
  if (@isWritableStreamLocked(stream))
    return @Promise.@reject(@makeTypeError("WritableStream.close method can only be used on non locked WritableStream"));
  if (@writableStreamCloseQueuedOrInFlight(stream))
    return @Promise.@reject(@makeTypeError("WritableStream.close method can only be used on a being close WritableStream"));
  return @writableStreamClose(stream);
})
