(function (stream, sink, underlyingSource) {"use strict";
  @putByIdDirectPrivate(stream, "underlyingSource", null), @putByIdDirectPrivate(stream, "start", @undefined);
  function close(stream2, reason) {
    let cancelFn = underlyingSource?.cancel;
    if (cancelFn) {
      try {
        var prom = cancelFn.@call(underlyingSource, reason);
        if (@isPromise(prom))
          @markPromiseAsHandled(prom);
      } catch {}
      underlyingSource = @undefined;
    }
    if (stream2) {
      if (@putByIdDirectPrivate(stream2, "readableStreamController", @undefined), @putByIdDirectPrivate(stream2, "reader", @undefined), reason)
        @putByIdDirectPrivate(stream2, "state", 3), @putByIdDirectPrivate(stream2, "storedError", reason);
      else
        @putByIdDirectPrivate(stream2, "state", 1);
      stream2 = @undefined;
    }
  }
  if (!underlyingSource.pull) {
    close();
    return;
  }
  if (!@isCallable(underlyingSource.pull)) {
    close(), @throwTypeError("pull is not a function");
    return;
  }
  @putByIdDirectPrivate(stream, "readableStreamController", sink);
  let highWaterMark = @getByIdDirectPrivate(stream, "highWaterMark");
  sink.start({
    highWaterMark: !highWaterMark || highWaterMark < 64 ? 64 : highWaterMark
  }), @startDirectStream.@call(sink, stream, underlyingSource.pull, close, stream.@asyncContext), @putByIdDirectPrivate(stream, "reader", {});
  var maybePromise = underlyingSource.pull(sink);
  if (sink = @undefined, maybePromise && @isPromise(maybePromise)) {
    if (maybePromise.@then)
      return maybePromise.@then(() => {});
    return maybePromise.then(() => {});
  }
})
