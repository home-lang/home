(function (controller) {"use strict";
  @enqueueValueWithSize(@getByIdDirectPrivate(controller, "queue"), @isCloseSentinel, 0), @writableStreamDefaultControllerAdvanceQueueIfNeeded(controller);
})
