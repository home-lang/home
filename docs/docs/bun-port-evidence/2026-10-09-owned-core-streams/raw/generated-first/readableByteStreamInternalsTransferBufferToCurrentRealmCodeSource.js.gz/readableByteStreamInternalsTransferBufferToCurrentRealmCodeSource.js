(function (buffer) {"use strict";
  return buffer;
})
