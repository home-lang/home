(function (stream, underlyingByteSource, highWaterMark) {"use strict";
  if (arguments.length !== 4 && arguments[3] !== @isReadableStream)
    @throwTypeError("ReadableByteStreamController constructor should not be called directly");
  return @privateInitializeReadableByteStreamController.@call(this, stream, underlyingByteSource, highWaterMark);
})
