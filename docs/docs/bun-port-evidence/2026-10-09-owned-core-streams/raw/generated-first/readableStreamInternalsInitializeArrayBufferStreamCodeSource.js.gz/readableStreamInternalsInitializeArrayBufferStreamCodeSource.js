(function (underlyingSource, highWaterMark) {"use strict";
  var opts = highWaterMark && typeof highWaterMark === "number" ? { highWaterMark, stream: !0, asUint8Array: !0 } : { stream: !0, asUint8Array: !0 }, sink = new Bun.ArrayBufferSink;
  sink.start(opts);
  var controller = {
    @underlyingSource: underlyingSource,
    @pull: @onPullDirectStream,
    @controlledReadableStream: this,
    @sink: sink,
    close: @onCloseDirectStream,
    write: sink.write.bind(sink),
    error: @handleDirectStreamError,
    end: @onCloseDirectStream,
    @close: @onCloseDirectStream,
    flush: @onFlushDirectStream,
    _pendingRead: @undefined,
    _deferClose: 0,
    _deferFlush: 0,
    _deferCloseReason: @undefined,
    _handleError: @undefined
  };
  @putByIdDirectPrivate(this, "readableStreamController", controller), @putByIdDirectPrivate(this, "underlyingSource", null), @putByIdDirectPrivate(this, "start", @undefined);
})
