(function (controller) {"use strict";
  let stream = @getByIdDirectPrivate(controller, "stream");
  if (@getByIdDirectPrivate(controller, "started") !== 1)
    return;
  if (@getByIdDirectPrivate(stream, "inFlightWriteRequest") !== @undefined)
    return;
  if (@getByIdDirectPrivate(stream, "state") === "erroring") {
    @writableStreamFinishErroring(stream);
    return;
  }
  let queue = @getByIdDirectPrivate(controller, "queue");
  if (queue.content?.isEmpty() ?? !1)
    return;
  let value = @peekQueueValue(queue);
  if (value === @isCloseSentinel)
    @writableStreamDefaultControllerProcessClose(controller);
  else
    @writableStreamDefaultControllerProcessWrite(controller, value);
})
