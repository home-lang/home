(function (controller, chunk) {"use strict";
  let stream = @getByIdDirectPrivate(controller, "controlledReadableStream");
  switch (@getByIdDirectPrivate(stream, "reader") ? @readableStreamReaderKind(@getByIdDirectPrivate(stream, "reader")) : 0) {
    case 1: {
      if (!@getByIdDirectPrivate(@getByIdDirectPrivate(stream, "reader"), "readRequests")?.isNotEmpty())
        @readableByteStreamControllerEnqueueChunk(controller, @transferBufferToCurrentRealm(chunk.buffer), chunk.byteOffset, chunk.byteLength);
      else {
        let transferredView = chunk.constructor === @Uint8Array ? chunk : new @Uint8Array(chunk.buffer, chunk.byteOffset, chunk.byteLength);
        @readableStreamFulfillReadRequest(stream, transferredView, !1);
      }
      break;
    }
    case 2: {
      @readableByteStreamControllerEnqueueChunk(controller, @transferBufferToCurrentRealm(chunk.buffer), chunk.byteOffset, chunk.byteLength), @readableByteStreamControllerProcessPullDescriptors(controller);
      break;
    }
    case 3:
      break;
    default: {
      @readableByteStreamControllerEnqueueChunk(controller, @transferBufferToCurrentRealm(chunk.buffer), chunk.byteOffset, chunk.byteLength);
      break;
    }
  }
})
