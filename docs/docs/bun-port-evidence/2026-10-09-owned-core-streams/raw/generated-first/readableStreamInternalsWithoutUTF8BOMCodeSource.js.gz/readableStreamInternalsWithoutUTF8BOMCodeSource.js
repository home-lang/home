(function (result) {"use strict";
  if (result.charCodeAt(0) === 65279)
    return result.slice(1);
  return result;
})
