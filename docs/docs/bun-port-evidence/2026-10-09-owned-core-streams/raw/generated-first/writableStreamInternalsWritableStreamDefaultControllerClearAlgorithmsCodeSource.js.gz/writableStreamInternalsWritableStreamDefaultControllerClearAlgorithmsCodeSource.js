(function (controller) {"use strict";
  @putByIdDirectPrivate(controller, "writeAlgorithm", @undefined), @putByIdDirectPrivate(controller, "closeAlgorithm", @undefined), @putByIdDirectPrivate(controller, "abortAlgorithm", @undefined), @putByIdDirectPrivate(controller, "strategySizeAlgorithm", @undefined);
})
