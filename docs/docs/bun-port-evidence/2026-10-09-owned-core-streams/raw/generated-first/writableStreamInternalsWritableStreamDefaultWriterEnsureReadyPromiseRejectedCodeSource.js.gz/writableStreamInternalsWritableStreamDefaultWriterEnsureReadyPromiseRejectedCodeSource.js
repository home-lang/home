(function (writer, error) {"use strict";
  let readyPromiseCapability = @getByIdDirectPrivate(writer, "readyPromise"), readyPromise = readyPromiseCapability.promise;
  if (@peekPromiseStatus(readyPromise) !== 0)
    readyPromiseCapability = @newPromiseCapability(@Promise), readyPromise = readyPromiseCapability.promise, @putByIdDirectPrivate(writer, "readyPromise", readyPromiseCapability);
  readyPromiseCapability.reject.@call(@undefined, error), @markPromiseAsHandled(readyPromise);
})
