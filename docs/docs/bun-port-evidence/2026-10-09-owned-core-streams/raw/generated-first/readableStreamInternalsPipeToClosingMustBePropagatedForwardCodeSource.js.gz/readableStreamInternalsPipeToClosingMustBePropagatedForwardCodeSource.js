(function (pipeState) {"use strict";
  let action = () => {
    if (pipeState.pendingReadPromiseCapability.resolve.@call(@undefined, !1), !pipeState.preventClose) {
      @pipeToShutdownWithAction(pipeState, () => @writableStreamDefaultWriterCloseWithErrorPropagation(pipeState.writer));
      return;
    }
    @pipeToShutdown(pipeState);
  };
  if (@getByIdDirectPrivate(pipeState.source, "state") === 1) {
    action();
    return;
  }
  @getByIdDirectPrivate(pipeState.reader, "closedPromiseCapability").promise.@then(action, () => {});
})
