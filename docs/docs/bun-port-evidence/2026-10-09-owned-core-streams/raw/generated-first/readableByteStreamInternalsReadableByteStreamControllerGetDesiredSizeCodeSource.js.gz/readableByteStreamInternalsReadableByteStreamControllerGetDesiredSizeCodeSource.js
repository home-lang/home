(function (controller) {"use strict";
  let stream = @getByIdDirectPrivate(controller, "controlledReadableStream"), state = @getByIdDirectPrivate(stream, "state");
  if (state === 3)
    return null;
  if (state === 1)
    return 0;
  return @getByIdDirectPrivate(controller, "strategyHWM") - @getByIdDirectPrivate(controller, "queue").size;
})
