(function (controller, e) {"use strict";
  @readableByteStreamControllerClearPendingPullIntos(controller), @putByIdDirectPrivate(controller, "queue", @newQueue()), @readableStreamError(@getByIdDirectPrivate(controller, "controlledReadableStream"), e);
})
