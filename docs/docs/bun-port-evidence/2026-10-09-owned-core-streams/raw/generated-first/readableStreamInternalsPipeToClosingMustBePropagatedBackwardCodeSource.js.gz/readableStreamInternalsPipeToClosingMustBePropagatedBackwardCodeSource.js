(function (pipeState) {"use strict";
  if (!@writableStreamCloseQueuedOrInFlight(pipeState.destination) && @getByIdDirectPrivate(pipeState.destination, "state") !== "closed")
    return;
  let error = @makeTypeError("closing is propagated backward");
  if (!pipeState.preventCancel) {
    @pipeToShutdownWithAction(pipeState, () => @readableStreamCancel(pipeState.source, error), error);
    return;
  }
  @pipeToShutdown(pipeState, error);
})
