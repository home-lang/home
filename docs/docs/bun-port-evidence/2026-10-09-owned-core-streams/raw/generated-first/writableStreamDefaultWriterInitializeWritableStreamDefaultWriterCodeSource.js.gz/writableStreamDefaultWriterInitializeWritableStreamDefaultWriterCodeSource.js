(function (stream) {"use strict";
  let internalStream = @getInternalWritableStream(stream);
  if (internalStream)
    stream = internalStream;
  if (!@isWritableStream(stream))
    @throwTypeError("WritableStreamDefaultWriter constructor takes a WritableStream");
  return @setUpWritableStreamDefaultWriter(this, stream), this;
})
