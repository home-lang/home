(function (stream) {"use strict";
  return @isObject(stream) && !!@getByIdDirectPrivate(stream, "readable");
})
