(function (error) {"use strict";
  if (!@isReadableByteStreamController(this))
    throw @makeErrorWithCode(140, "ReadableByteStreamController");
  if (@getByIdDirectPrivate(@getByIdDirectPrivate(this, "controlledReadableStream"), "state") !== 4)
    throw @makeErrorWithCode(138, "Controller is already closed");
  @readableByteStreamControllerError(this, error);
})
