(function () {"use strict";
  if (!@inherits(5, this))
    throw @makeGetterTypeError("CompressionStream", "readable");
  return @getByIdDirectPrivate(this, "readable");
})
