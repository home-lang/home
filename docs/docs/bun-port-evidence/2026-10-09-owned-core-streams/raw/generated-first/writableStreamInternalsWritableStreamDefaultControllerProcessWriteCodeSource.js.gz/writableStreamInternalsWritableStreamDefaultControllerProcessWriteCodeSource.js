(function (controller, chunk) {"use strict";
  let stream = @getByIdDirectPrivate(controller, "stream");
  @writableStreamMarkFirstWriteRequestInFlight(stream), @getByIdDirectPrivate(controller, "writeAlgorithm").@call(@undefined, chunk).@then(() => {
    @writableStreamFinishInFlightWrite(stream);
    let state = @getByIdDirectPrivate(stream, "state");
    if (@dequeueValue(@getByIdDirectPrivate(controller, "queue")), !@writableStreamCloseQueuedOrInFlight(stream) && state === "writable") {
      let backpressure = @writableStreamDefaultControllerGetBackpressure(controller);
      @writableStreamUpdateBackpressure(stream, backpressure);
    }
    @writableStreamDefaultControllerAdvanceQueueIfNeeded(controller);
  }, (reason) => {
    if (@getByIdDirectPrivate(stream, "state") === "writable")
      @writableStreamDefaultControllerClearAlgorithms(controller);
    @writableStreamFinishInFlightWriteWithError(stream, reason);
  });
})
