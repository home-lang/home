(function (writer) {"use strict";
  let stream = @getByIdDirectPrivate(writer, "stream");
  return @writableStreamClose(stream);
})
