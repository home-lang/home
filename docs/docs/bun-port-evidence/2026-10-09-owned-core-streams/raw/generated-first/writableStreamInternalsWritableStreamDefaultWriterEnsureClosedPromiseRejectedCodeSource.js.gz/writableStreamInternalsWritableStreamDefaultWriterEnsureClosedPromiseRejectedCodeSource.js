(function (writer, error) {"use strict";
  let closedPromiseCapability = @getByIdDirectPrivate(writer, "closedPromise"), closedPromise = closedPromiseCapability.promise;
  if (@peekPromiseStatus(closedPromise) !== 0)
    closedPromiseCapability = @newPromiseCapability(@Promise), closedPromise = closedPromiseCapability.promise, @putByIdDirectPrivate(writer, "closedPromise", closedPromiseCapability);
  closedPromiseCapability.reject.@call(@undefined, error), @markPromiseAsHandled(closedPromise);
})
