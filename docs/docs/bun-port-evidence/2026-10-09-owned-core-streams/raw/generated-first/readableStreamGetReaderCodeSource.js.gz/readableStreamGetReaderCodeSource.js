(function (options) {"use strict";
  if (!@isReadableStream(this))
    throw @makeErrorWithCode(140, "ReadableStream");
  let mode = @toDictionary(options, {}, "ReadableStream.getReader takes an object as first argument").mode;
  if (mode === @undefined) {
    var start_ = @getByIdDirectPrivate(this, "start");
    if (start_)
      @putByIdDirectPrivate(this, "start", @undefined), start_();
    return new @ReadableStreamDefaultReader(this);
  }
  if (mode == "byob")
    return new @ReadableStreamBYOBReader(this);
  throw @makeErrorWithCode(120, "mode", mode, "byob");
})
