(function (stream, sink) {"use strict";
  let highWaterMark = @getByIdDirectPrivate(stream, "highWaterMark") || 0, error = null, reading = !1, closed = !1, reader;
  function releaseReader() {
    if (reader) {
      try {
        reader.releaseLock();
      } catch {}
      reader = @undefined;
    }
    if (sink = @undefined, stream) {
      var streamState = @getByIdDirectPrivate(stream, "state"), readableStreamController = @getByIdDirectPrivate(stream, "readableStreamController");
      if (readableStreamController) {
        if (@getByIdDirectPrivate(readableStreamController, "underlyingSource"))
          @putByIdDirectPrivate(readableStreamController, "underlyingSource", null);
        if (@getByIdDirectPrivate(readableStreamController, "controlledReadableStream"))
          @putByIdDirectPrivate(readableStreamController, "controlledReadableStream", null);
        if (@putByIdDirectPrivate(stream, "readableStreamController", null), @getByIdDirectPrivate(stream, "underlyingSource"))
          @putByIdDirectPrivate(stream, "underlyingSource", null);
        readableStreamController = @undefined;
      }
      if (stream && !error && streamState !== 1 && streamState !== 3)
        @readableStreamCloseIfPossible(stream);
      stream = @undefined;
    }
  }
  function endSink(...args) {
    try {
      sink?.end(...args);
    } catch {}
    releaseReader();
  }
  try {
    let cancelStream2 = function(_, reason) {
      if (closed)
        return;
      let wasClosed = closed;
      if (closed = !0, stream && !error && !wasClosed && stream.@state !== 1)
        @readableStreamCancel(stream, reason);
      releaseReader();
    };
    var cancelStream = cancelStream2;
    sink.start({ highWaterMark }), reader = stream.getReader();
    async function drainReaderIntoSink() {
      if (error || closed || reading)
        return;
      reading = !0;
      try {
        while (!0) {
          var { value, done } = await reader.read();
          if (closed)
            break;
          if (done) {
            if (closed = !0, value)
              sink.write(value);
            return endSink();
          }
          if (value) {
            if (!sink.write(value))
              break;
          }
        }
      } catch (e) {
        error = e, closed = !0;
        try {
          let prom = stream?.cancel(e);
          if (@isPromise(prom))
            @markPromiseAsHandled(prom);
        } catch {}
        queueMicrotask(endSink.bind(null, e));
      } finally {
        reading = !1;
      }
    }
    sink.setHandlers(drainReaderIntoSink, cancelStream2), drainReaderIntoSink();
  } catch (e) {
    error = e, closed = !0, queueMicrotask(endSink.bind(null, e));
  }
})
