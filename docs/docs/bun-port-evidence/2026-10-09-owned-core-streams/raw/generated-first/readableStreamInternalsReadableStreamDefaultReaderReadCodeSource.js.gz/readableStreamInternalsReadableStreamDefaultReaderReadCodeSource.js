(function (reader) {"use strict";
  let stream = @getByIdDirectPrivate(reader, "ownerReadableStream"), state = @getByIdDirectPrivate(stream, "state");
  if (stream.@disturbed = !0, state === 1)
    return @createFulfilledPromise({ value: @undefined, done: !0 });
  if (state === 3)
    return @Promise.@reject(@getByIdDirectPrivate(stream, "storedError"));
  return @getByIdDirectPrivate(stream, "readableStreamController").@pull(@getByIdDirectPrivate(stream, "readableStreamController"));
})
