(function (stream, reason) {"use strict";
  if (@isWritableStreamLocked(stream))
    return @Promise.@reject(@makeTypeError("WritableStream.abort method can only be used on non locked WritableStream"));
  return @writableStreamAbort(stream, reason);
})
