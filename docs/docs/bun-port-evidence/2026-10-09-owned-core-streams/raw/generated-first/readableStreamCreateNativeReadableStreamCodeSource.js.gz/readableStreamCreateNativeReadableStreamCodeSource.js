(function (nativePtr, autoAllocateChunkSize) {"use strict";
  return new @ReadableStream({
    @lazy: !0,
    @bunNativePtr: nativePtr,
    autoAllocateChunkSize
  });
})
