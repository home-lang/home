(function (stream) {"use strict";
  if (!@isReadableStream(stream))
    @throwTypeError("ReadableStreamDefaultReader needs a ReadableStream");
  if (@isReadableStreamLocked(stream))
    @throwTypeError("ReadableStream is locked");
  return @readableStreamReaderGenericInitialize(this, stream), @putByIdDirectPrivate(this, "readRequests", @createFIFO()), this;
})
