(function (controller) {"use strict";
  let stream = @getByIdDirectPrivate(controller, "stream"), readable = @getByIdDirectPrivate(stream, "readable"), readableController = @getByIdDirectPrivate(readable, "readableStreamController");
  if (@readableStreamDefaultControllerCanCloseOrEnqueue(readableController))
    @readableStreamDefaultControllerClose(readableController);
  let error = @makeTypeError("the stream has been terminated");
  @transformStreamErrorWritableAndUnblockWrite(stream, error);
})
