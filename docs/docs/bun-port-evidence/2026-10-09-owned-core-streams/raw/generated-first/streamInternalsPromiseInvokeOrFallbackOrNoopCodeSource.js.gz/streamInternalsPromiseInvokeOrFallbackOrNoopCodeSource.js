(function (object, key1, args1, key2, args2) {"use strict";
  try {
    let method = object[key1];
    if (method === @undefined)
      return @promiseInvokeOrNoopNoCatch(object, key2, args2);
    return @shieldingPromiseResolve(method.@apply(object, args1));
  } catch (error) {
    return @Promise.@reject(error);
  }
})
