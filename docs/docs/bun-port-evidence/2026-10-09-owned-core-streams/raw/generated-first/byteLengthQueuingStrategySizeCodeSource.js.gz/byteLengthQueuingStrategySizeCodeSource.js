(function (chunk) {"use strict";
  return chunk.byteLength;
})
