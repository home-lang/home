(function (teeState, stream) {"use strict";
  return function(r) {
    if (teeState.flags |= 1 /* canceled1 */, teeState.reason1 = r, teeState.flags & 2 /* canceled2 */)
      @readableStreamCancel(stream, [teeState.reason1, teeState.reason2]).@then(teeState.cancelPromiseCapability.resolve, teeState.cancelPromiseCapability.reject);
    return teeState.cancelPromiseCapability.promise;
  };
})
