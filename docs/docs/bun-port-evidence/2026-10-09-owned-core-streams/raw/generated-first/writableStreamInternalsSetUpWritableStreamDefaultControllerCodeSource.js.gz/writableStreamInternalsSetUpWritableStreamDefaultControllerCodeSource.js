(function (stream, controller, startAlgorithm, writeAlgorithm, closeAlgorithm, abortAlgorithm, highWaterMark, sizeAlgorithm) {"use strict";
  @putByIdDirectPrivate(controller, "stream", stream), @putByIdDirectPrivate(stream, "controller", controller), @resetQueue(@getByIdDirectPrivate(controller, "queue")), @putByIdDirectPrivate(controller, "started", -1), @putByIdDirectPrivate(controller, "startAlgorithm", startAlgorithm), @putByIdDirectPrivate(controller, "strategySizeAlgorithm", sizeAlgorithm), @putByIdDirectPrivate(controller, "strategyHWM", highWaterMark), @putByIdDirectPrivate(controller, "writeAlgorithm", writeAlgorithm), @putByIdDirectPrivate(controller, "closeAlgorithm", closeAlgorithm), @putByIdDirectPrivate(controller, "abortAlgorithm", abortAlgorithm);
  let backpressure = @writableStreamDefaultControllerGetBackpressure(controller);
  @writableStreamUpdateBackpressure(stream, backpressure), @writableStreamDefaultControllerStart(controller);
})
