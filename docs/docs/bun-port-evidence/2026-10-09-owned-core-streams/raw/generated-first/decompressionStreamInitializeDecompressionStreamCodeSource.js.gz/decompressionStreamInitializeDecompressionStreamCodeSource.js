(function (format) {"use strict";
  let zlib = @getInternalField(@internalModuleRegistry, 151) || @createInternalModuleById(151), { newBufferSourceTransformPairFromDuplex } = @getInternalField(@internalModuleRegistry, 87) || @createInternalModuleById(87), builders = {
    deflate: zlib.createInflate,
    "deflate-raw": zlib.createInflateRaw,
    gzip: zlib.createGunzip,
    brotli: zlib.createBrotliDecompress,
    zstd: zlib.createZstdDecompress
  };
  if (!(format in builders))
    throw @makeErrorWithCode(120, "format", format, "must be one of: " + Object.keys(builders).join(", "));
  let transform = newBufferSourceTransformPairFromDuplex(builders[format]());
  return @putByIdDirectPrivate(this, "readable", transform.readable), @putByIdDirectPrivate(this, "writable", transform.writable), this;
})
