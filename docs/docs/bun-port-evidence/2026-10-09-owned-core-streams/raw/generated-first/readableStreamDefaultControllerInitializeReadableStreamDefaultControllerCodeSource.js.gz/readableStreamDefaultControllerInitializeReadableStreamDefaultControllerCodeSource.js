(function (stream, underlyingSource, size, highWaterMark) {"use strict";
  if (arguments.length !== 5 && arguments[4] !== @isReadableStream)
    @throwTypeError("ReadableStreamDefaultController constructor should not be called directly");
  return @privateInitializeReadableStreamDefaultController.@call(this, stream, underlyingSource, size, highWaterMark);
})
