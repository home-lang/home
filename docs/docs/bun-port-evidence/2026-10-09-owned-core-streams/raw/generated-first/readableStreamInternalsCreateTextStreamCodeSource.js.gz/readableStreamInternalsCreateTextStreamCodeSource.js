(function (_highWaterMark) {"use strict";
  var sink, array = [], hasString = !1, hasBuffer = !1, rope = "", estimatedLength = @toLength(0), capability = @newPromiseCapability(@Promise), calledDone = !1;
  return sink = {
    start() {},
    write(chunk) {
      if (typeof chunk === "string") {
        var chunkLength = @toLength(chunk.length);
        if (chunkLength > 0)
          rope += chunk, hasString = !0, estimatedLength += chunkLength;
        return chunkLength;
      }
      if (!chunk || !(@ArrayBuffer.@isView(chunk) || chunk instanceof @ArrayBuffer))
        @throwTypeError("Expected text, ArrayBuffer or ArrayBufferView");
      let byteLength = @toLength(chunk.byteLength);
      if (byteLength > 0)
        if (hasBuffer = !0, rope.length > 0)
          @arrayPush(array, rope), @arrayPush(array, chunk), rope = "";
        else
          @arrayPush(array, chunk);
      return estimatedLength += byteLength, byteLength;
    },
    flush() {
      return 0;
    },
    end() {
      if (calledDone)
        return "";
      return sink.fulfill();
    },
    fulfill() {
      calledDone = !0;
      let result = sink.finishInternal();
      return @fulfillPromise(capability.promise, result), result;
    },
    finishInternal() {
      if (!hasString && !hasBuffer)
        return "";
      if (hasString && !hasBuffer) {
        if (rope.charCodeAt(0) === 65279)
          rope = rope.slice(1);
        return rope;
      }
      if (hasBuffer && !hasString)
        return new globalThis.TextDecoder("utf-8", { ignoreBOM: !0 }).decode(Bun.concatArrayBuffers(array));
      var arrayBufferSink = new Bun.ArrayBufferSink;
      arrayBufferSink.start({
        highWaterMark: estimatedLength,
        asUint8Array: !0
      });
      for (let item of array)
        arrayBufferSink.write(item);
      if (array.length = 0, rope.length > 0) {
        if (rope.charCodeAt(0) === 65279)
          rope = rope.slice(1);
        arrayBufferSink.write(rope), rope = "";
      }
      return new globalThis.TextDecoder("utf-8", { ignoreBOM: !0 }).decode(arrayBufferSink.end());
    },
    close() {
      try {
        if (!calledDone)
          calledDone = !0, sink.fulfill();
      } catch {}
    }
  }, [sink, capability];
})
