(function (controller) {"use strict";
  if (!@getByIdDirectPrivate(controller, "queue").size && @getByIdDirectPrivate(controller, "closeRequested"))
    @readableStreamCloseIfPossible(@getByIdDirectPrivate(controller, "controlledReadableStream"));
  else
    @readableByteStreamControllerCallPullIfNeeded(controller);
})
