(function (stream) {"use strict";
  if (@getByIdDirectPrivate(stream, "inFlightCloseRequest").resolve.@call(), @putByIdDirectPrivate(stream, "inFlightCloseRequest", @undefined), @getByIdDirectPrivate(stream, "state") === "erroring") {
    @putByIdDirectPrivate(stream, "storedError", @undefined);
    let abortRequest = @getByIdDirectPrivate(stream, "pendingAbortRequest");
    if (abortRequest !== @undefined)
      abortRequest.promise.resolve.@call(), @putByIdDirectPrivate(stream, "pendingAbortRequest", @undefined);
  }
  @putByIdDirectPrivate(stream, "state", "closed");
  let writer = @getByIdDirectPrivate(stream, "writer");
  if (writer !== @undefined)
    @getByIdDirectPrivate(writer, "closedPromise").resolve.@call();
})
