(function (queue) {"use strict";
  queue.content.clear(), queue.size = 0;
})
