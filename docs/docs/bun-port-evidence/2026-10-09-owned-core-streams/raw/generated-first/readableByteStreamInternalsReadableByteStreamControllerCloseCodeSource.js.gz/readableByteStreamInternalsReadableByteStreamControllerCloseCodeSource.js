(function (controller) {"use strict";
  if (@getByIdDirectPrivate(controller, "queue").size > 0) {
    @putByIdDirectPrivate(controller, "closeRequested", !0);
    return;
  }
  var first = @getByIdDirectPrivate(controller, "pendingPullIntos")?.peek();
  if (first) {
    if (first.bytesFilled > 0) {
      let e = @makeTypeError("Close requested while there remain pending bytes");
      throw @readableByteStreamControllerError(controller, e), e;
    }
  }
  @readableStreamCloseIfPossible(@getByIdDirectPrivate(controller, "controlledReadableStream"));
})
