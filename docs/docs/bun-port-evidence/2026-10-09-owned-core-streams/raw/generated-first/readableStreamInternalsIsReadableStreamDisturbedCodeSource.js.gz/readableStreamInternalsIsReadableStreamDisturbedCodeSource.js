(function (stream) {"use strict";
  return stream.@disturbed;
})
