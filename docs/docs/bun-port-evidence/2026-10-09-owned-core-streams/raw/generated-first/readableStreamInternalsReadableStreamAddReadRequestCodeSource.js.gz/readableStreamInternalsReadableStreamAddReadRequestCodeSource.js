(function (stream) {"use strict";
  let readRequest = @newPromise();
  return @getByIdDirectPrivate(@getByIdDirectPrivate(stream, "reader"), "readRequests").push(readRequest), readRequest;
})
