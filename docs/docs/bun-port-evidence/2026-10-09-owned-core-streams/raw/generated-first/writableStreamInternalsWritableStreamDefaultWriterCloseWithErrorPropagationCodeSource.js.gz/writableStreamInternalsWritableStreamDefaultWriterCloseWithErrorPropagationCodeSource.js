(function (writer) {"use strict";
  let stream = @getByIdDirectPrivate(writer, "stream"), state = @getByIdDirectPrivate(stream, "state");
  if (@writableStreamCloseQueuedOrInFlight(stream) || state === "closed")
    return @Promise.@resolve();
  if (state === "errored")
    return @Promise.@reject(@getByIdDirectPrivate(stream, "storedError"));
  return @writableStreamDefaultWriterClose(writer);
})
