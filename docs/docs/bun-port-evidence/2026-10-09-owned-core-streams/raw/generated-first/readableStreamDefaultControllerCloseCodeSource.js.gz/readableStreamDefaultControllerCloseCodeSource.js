(function () {"use strict";
  if (!@isReadableStreamDefaultController(this))
    throw @makeErrorWithCode(140, "ReadableStreamDefaultController");
  if (!@readableStreamDefaultControllerCanCloseOrEnqueue(this))
    throw @makeErrorWithCode(138, "Controller is already closed");
  @readableStreamDefaultControllerClose(this);
})
