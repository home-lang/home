(function (teeState, stream) {"use strict";
  return function(r) {
    if (teeState.flags |= 2 /* canceled2 */, teeState.reason2 = r, teeState.flags & 1 /* canceled1 */)
      @readableStreamCancel(stream, [teeState.reason1, teeState.reason2]).@then(teeState.cancelPromiseCapability.resolve, teeState.cancelPromiseCapability.reject);
    return teeState.cancelPromiseCapability.promise;
  };
})
