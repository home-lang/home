(function (writer, reason) {"use strict";
  let stream = @getByIdDirectPrivate(writer, "stream");
  return @writableStreamAbort(stream, reason);
})
