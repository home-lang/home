(function (reader) {"use strict";
  @readableStreamReaderGenericRelease(reader), @readableStreamDefaultReaderErrorReadRequests(reader, @makeErrorWithCode(237, "Stream reader cancelled via releaseLock()"));
})
