(function (stream, pullIntoDescriptor) {"use strict";
  let done = !1;
  if (@getByIdDirectPrivate(stream, "state") === 1)
    done = !0;
  let filledView = @readableByteStreamControllerConvertDescriptor(pullIntoDescriptor);
  if (pullIntoDescriptor.readerType === "default")
    @readableStreamFulfillReadRequest(stream, filledView, done);
  else
    @readableStreamFulfillReadIntoRequest(stream, filledView, done);
})
