(function (teeState, reader, shouldClone) {"use strict";
  let pullAlgorithm = function() {
    if (teeState.flags & 4 /* reading */)
      return teeState.flags |= 16 /* readAgain */, @Promise.@resolve();
    return teeState.flags |= 4 /* reading */, @Promise.prototype.@then.@call(@readableStreamDefaultReaderRead(reader), function(result) {
      let { done, value } = result;
      if (done) {
        if (teeState.flags &= -5, !(teeState.flags & 1 /* canceled1 */))
          @readableStreamDefaultControllerClose(teeState.branch1.@readableStreamController);
        if (!(teeState.flags & 2 /* canceled2 */))
          @readableStreamDefaultControllerClose(teeState.branch2.@readableStreamController);
        if (!(teeState.flags & 1 /* canceled1 */) || !(teeState.flags & 2 /* canceled2 */))
          teeState.cancelPromiseCapability.resolve.@call();
        return;
      }
      teeState.flags &= -17;
      let chunk1 = value, chunk2 = value;
      if (!(teeState.flags & 2 /* canceled2 */) && shouldClone)
        try {
          chunk2 = @structuredCloneForStream(value);
        } catch (e) {
          @readableStreamDefaultControllerError(teeState.branch1.@readableStreamController, e), @readableStreamDefaultControllerError(teeState.branch2.@readableStreamController, e), @readableStreamCancel(teeState.stream, e).@then(teeState.cancelPromiseCapability.resolve, teeState.cancelPromiseCapability.reject);
          return;
        }
      if (!(teeState.flags & 1 /* canceled1 */))
        @readableStreamDefaultControllerEnqueue(teeState.branch1.@readableStreamController, chunk1);
      if (!(teeState.flags & 2 /* canceled2 */))
        @readableStreamDefaultControllerEnqueue(teeState.branch2.@readableStreamController, chunk2);
      teeState.flags &= -5, @Promise.@resolve().@then(() => {
        if (teeState.flags & 16 /* readAgain */)
          pullAlgorithm();
      });
    }, () => {
      teeState.flags &= -5;
    }), @Promise.@resolve();
  };
  return pullAlgorithm;
})
