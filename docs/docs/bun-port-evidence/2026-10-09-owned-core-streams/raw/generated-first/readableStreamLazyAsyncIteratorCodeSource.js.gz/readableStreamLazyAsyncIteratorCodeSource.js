(function () {"use strict";
  var prototype = @ReadableStream.prototype;
  return @readableStreamDefineLazyIterators(prototype), prototype[globalThis.Symbol.asyncIterator].@call(this);
})
