(function (controller) {"use strict";
  if (@getByIdDirectPrivate(controller, "closeRequested"))
    return !1;
  let controlledReadableStream = @getByIdDirectPrivate(controller, "controlledReadableStream");
  if (!@isObject(controlledReadableStream))
    return !1;
  return @getByIdDirectPrivate(controlledReadableStream, "state") === 4;
})
