(function (stream) {"use strict";
  var reader = stream.getReader(), manyResult = reader.readMany();
  async function processManyResult(result) {
    let { done, value } = result;
    var chunks = value || [];
    while (!done) {
      var thisResult = reader.readMany();
      if (@isPromise(thisResult))
        thisResult = await thisResult;
      ({ done, value = [] } = thisResult);
      let length = value.length || 0;
      if (length > 1)
        chunks = chunks.concat(value);
      else if (length === 1)
        chunks.push(value[0]);
    }
    return chunks;
  }
  if (manyResult && @isPromise(manyResult))
    return manyResult.@then(processManyResult);
  return processManyResult(manyResult);
})
