(function (controller, chunk) {"use strict";
  let stream = @getByIdDirectPrivate(controller, "controlledReadableStream");
  if (@isReadableStreamLocked(stream) && @getByIdDirectPrivate(@getByIdDirectPrivate(stream, "reader"), "readRequests")?.isNotEmpty()) {
    @readableStreamFulfillReadRequest(stream, chunk, !1), @readableStreamDefaultControllerCallPullIfNeeded(controller);
    return;
  }
  try {
    let chunkSize = 1;
    if (@getByIdDirectPrivate(controller, "strategy").size !== @undefined)
      chunkSize = @getByIdDirectPrivate(controller, "strategy").size(chunk);
    @enqueueValueWithSize(@getByIdDirectPrivate(controller, "queue"), chunk, chunkSize);
  } catch (error) {
    throw @readableStreamDefaultControllerError(controller, error), error;
  }
  @readableStreamDefaultControllerCallPullIfNeeded(controller);
})
