(function () {"use strict";
  if (!@inherits(6, this))
    throw @makeGetterTypeError("DecompressionStream", "writable");
  return @getByIdDirectPrivate(this, "writable");
})
