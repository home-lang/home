(function (reason) {"use strict";
  var stream = this.@controlledReadableStream;
  if (!stream || @getByIdDirectPrivate(stream, "state") !== 4)
    return;
  if (this._deferClose !== 0) {
    this._deferClose = 1, this._deferCloseReason = reason;
    return;
  }
  var sink = this.@sink;
  if (!sink)
    return;
  @putByIdDirectPrivate(stream, "state", 2);
  let underlyingSource = this.@underlyingSource, underlyingClose = underlyingSource.close;
  if (typeof underlyingClose === "function")
    try {
      underlyingClose.@call(underlyingSource, reason);
    } catch {}
  var flushed;
  try {
    flushed = sink.end(), @putByIdDirectPrivate(this, "sink", @undefined);
  } catch (e) {
    if (this._pendingRead) {
      var read = this._pendingRead;
      this._pendingRead = @undefined, @rejectPromise(read, e);
    } else
      throw e;
    return;
  }
  this.error = this.flush = this.write = this.close = this.end = @onReadableStreamDirectControllerClosed;
  var reader = @getByIdDirectPrivate(stream, "reader");
  if (reader && @isReadableStreamDefaultReader(reader)) {
    var _pendingRead = this._pendingRead;
    if (_pendingRead && @isPromise(_pendingRead) && flushed?.byteLength) {
      this._pendingRead = @undefined, @fulfillPromise(_pendingRead, { value: flushed, done: !1 }), @readableStreamCloseIfPossible(stream);
      return;
    }
  }
  if (flushed?.byteLength) {
    var requests = @getByIdDirectPrivate(reader, "readRequests");
    if (requests?.isNotEmpty()) {
      @readableStreamFulfillReadRequest(stream, flushed, !1), @readableStreamCloseIfPossible(stream);
      return;
    }
    @putByIdDirectPrivate(stream, "state", 4), this.@pull = () => {
      var thisResult = @createFulfilledPromise({
        value: flushed,
        done: !1
      });
      return flushed = @undefined, @readableStreamCloseIfPossible(stream), stream = @undefined, thisResult;
    };
    return;
  }
  if (this._pendingRead) {
    var read = this._pendingRead;
    this._pendingRead = @undefined, @putByIdDirectPrivate(this, "pull", @noopDoneFunction), @fulfillPromise(read, { value: @undefined, done: !0 });
  }
  @readableStreamCloseIfPossible(stream);
})
