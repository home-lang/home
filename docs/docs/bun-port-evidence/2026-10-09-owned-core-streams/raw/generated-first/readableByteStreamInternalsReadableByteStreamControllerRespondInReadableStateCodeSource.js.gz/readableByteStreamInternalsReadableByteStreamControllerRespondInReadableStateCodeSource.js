(function (controller, bytesWritten, pullIntoDescriptor) {"use strict";
  if (pullIntoDescriptor.bytesFilled + bytesWritten > pullIntoDescriptor.byteLength)
    @throwRangeError("bytesWritten value is too great");
  if (@readableByteStreamControllerInvalidateBYOBRequest(controller), pullIntoDescriptor.bytesFilled += bytesWritten, pullIntoDescriptor.bytesFilled < pullIntoDescriptor.elementSize)
    return;
  @readableByteStreamControllerShiftPendingDescriptor(controller);
  let remainderSize = pullIntoDescriptor.bytesFilled % pullIntoDescriptor.elementSize;
  if (remainderSize > 0) {
    let end = pullIntoDescriptor.byteOffset + pullIntoDescriptor.bytesFilled, remainder = @cloneArrayBuffer(pullIntoDescriptor.buffer, end - remainderSize, remainderSize);
    @readableByteStreamControllerEnqueueChunk(controller, remainder, 0, remainder.byteLength);
  }
  pullIntoDescriptor.buffer = @transferBufferToCurrentRealm(pullIntoDescriptor.buffer), pullIntoDescriptor.bytesFilled -= remainderSize, @readableByteStreamControllerCommitDescriptor(@getByIdDirectPrivate(controller, "controlledReadableStream"), pullIntoDescriptor), @readableByteStreamControllerProcessPullDescriptors(controller);
})
