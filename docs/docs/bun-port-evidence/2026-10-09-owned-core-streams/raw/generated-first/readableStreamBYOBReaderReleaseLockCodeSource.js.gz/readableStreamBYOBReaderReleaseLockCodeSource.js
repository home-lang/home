(function () {"use strict";
  if (!@isReadableStreamBYOBReader(this))
    throw @makeErrorWithCode(140, "ReadableStreamBYOBReader");
  if (!@getByIdDirectPrivate(this, "ownerReadableStream"))
    return;
  if (@getByIdDirectPrivate(this, "readIntoRequests")?.isNotEmpty())
    @throwTypeError("There are still pending read requests, cannot release the lock");
  @readableStreamReaderGenericRelease(this);
})
