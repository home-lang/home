(function (stream, transformer, transformerDict) {"use strict";
  let controller = new @TransformStreamDefaultController, transformAlgorithm = (chunk) => {
    try {
      @transformStreamDefaultControllerEnqueue(controller, chunk);
    } catch (e) {
      return @Promise.@reject(e);
    }
    return @Promise.@resolve();
  }, flushAlgorithm = () => {
    return @Promise.@resolve();
  };
  if ("transform" in transformerDict)
    transformAlgorithm = (chunk) => {
      return @promiseInvokeOrNoopMethod(transformer, transformerDict.transform, [chunk, controller]);
    };
  if ("flush" in transformerDict)
    flushAlgorithm = () => {
      return @promiseInvokeOrNoopMethod(transformer, transformerDict.flush, [controller]);
    };
  @setUpTransformStreamDefaultController(stream, controller, transformAlgorithm, flushAlgorithm);
})
