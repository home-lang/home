(function (startAlgorithm, transformAlgorithm, flushAlgorithm, writableHighWaterMark, writableSizeAlgorithm, readableHighWaterMark, readableSizeAlgorithm) {"use strict";
  if (writableHighWaterMark === @undefined)
    writableHighWaterMark = 1;
  if (writableSizeAlgorithm === @undefined)
    writableSizeAlgorithm = () => 1;
  if (readableHighWaterMark === @undefined)
    readableHighWaterMark = 0;
  if (readableSizeAlgorithm === @undefined)
    readableSizeAlgorithm = () => 1;
  let transform = {};
  @putByIdDirectPrivate(transform, "TransformStream", !0);
  let stream = new @TransformStream(transform), startPromiseCapability = @newPromiseCapability(@Promise);
  @initializeTransformStream(stream, startPromiseCapability.promise, writableHighWaterMark, writableSizeAlgorithm, readableHighWaterMark, readableSizeAlgorithm);
  let controller = new @TransformStreamDefaultController;
  return @setUpTransformStreamDefaultController(stream, controller, transformAlgorithm, flushAlgorithm), startAlgorithm().@then(() => {
    startPromiseCapability.resolve.@call();
  }, (error) => {
    startPromiseCapability.reject.@call(@undefined, error);
  }), stream;
})
