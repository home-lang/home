(function (stream) {"use strict";
  return new @WritableStreamDefaultWriter(stream);
})
