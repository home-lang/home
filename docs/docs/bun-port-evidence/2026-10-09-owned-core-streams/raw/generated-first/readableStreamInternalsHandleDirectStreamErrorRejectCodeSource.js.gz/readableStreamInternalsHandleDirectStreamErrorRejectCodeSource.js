(function (e) {"use strict";
  return @handleDirectStreamError.@call(this, e), @Promise.@reject(e);
})
