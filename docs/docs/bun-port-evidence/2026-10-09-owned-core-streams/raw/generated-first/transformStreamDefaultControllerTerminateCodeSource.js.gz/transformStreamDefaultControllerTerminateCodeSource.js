(function () {"use strict";
  if (!@isTransformStreamDefaultController(this))
    throw @makeErrorWithCode(140, "TransformStreamDefaultController");
  @transformStreamDefaultControllerTerminate(this);
})
