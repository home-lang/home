(function (stream) {"use strict";
  if (!@isReadableStream(stream))
    throw @makeErrorWithCode(119, "stream", "ReadableStream", typeof stream);
  var underlyingSource = @getByIdDirectPrivate(stream, "underlyingSource");
  if (underlyingSource != null)
    return @readableStreamToArrayDirect(stream, underlyingSource);
  if (@isReadableStreamLocked(stream))
    return @Promise.@reject(@makeErrorWithCode(138, "ReadableStream is locked"));
  return @readableStreamIntoArray(stream);
})
