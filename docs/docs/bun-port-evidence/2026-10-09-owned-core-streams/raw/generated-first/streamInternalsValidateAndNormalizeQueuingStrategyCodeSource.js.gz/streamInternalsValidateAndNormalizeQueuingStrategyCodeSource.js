(function (size, highWaterMark) {"use strict";
  if (size !== @undefined && typeof size !== "function")
    @throwTypeError("size parameter must be a function");
  let newHighWaterMark = @toNumber(highWaterMark);
  if (newHighWaterMark !== newHighWaterMark || newHighWaterMark < 0)
    @throwRangeError("highWaterMark value is negative or not a number");
  return { size, highWaterMark: newHighWaterMark };
})
