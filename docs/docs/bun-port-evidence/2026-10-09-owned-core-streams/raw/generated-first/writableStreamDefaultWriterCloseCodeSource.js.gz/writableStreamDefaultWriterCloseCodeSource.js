(function () {"use strict";
  if (!@isWritableStreamDefaultWriter(this))
    return @Promise.@reject(@makeErrorWithCode(140, "WritableStreamDefaultWriter"));
  let stream = @getByIdDirectPrivate(this, "stream");
  if (stream === @undefined)
    return @Promise.@reject(@makeTypeError("WritableStreamDefaultWriter has no stream"));
  if (@writableStreamCloseQueuedOrInFlight(stream))
    return @Promise.@reject(@makeTypeError("WritableStreamDefaultWriter is being closed"));
  return @writableStreamDefaultWriterClose(this);
})
