(function () {"use strict";
  return @Promise.@resolve({ value: @undefined, done: !0 });
})
