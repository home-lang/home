(function (controller, error) {"use strict";
  let stream = @getByIdDirectPrivate(controller, "controlledReadableStream");
  if (!@isObject(stream) || @getByIdDirectPrivate(stream, "state") !== 4)
    return;
  @putByIdDirectPrivate(controller, "queue", @newQueue()), @readableStreamError(stream, error);
})
