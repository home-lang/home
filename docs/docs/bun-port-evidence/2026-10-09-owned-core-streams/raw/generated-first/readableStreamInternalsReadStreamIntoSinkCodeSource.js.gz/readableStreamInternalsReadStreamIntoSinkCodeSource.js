(async function (stream, sink, isNative) {"use strict";
  var started = !1;
  let highWaterMark = @getByIdDirectPrivate(stream, "highWaterMark") || 0;
  var state = { __proto__: null, didThrow: !1, didClose: !1 }, onSinkClose = isNative ? @readStreamIntoSinkOnClose.bind(state) : @undefined;
  try {
    var reader = stream.getReader(), many = reader.readMany();
    if (many && @isPromise(many)) {
      if (isNative)
        @startDirectStream.@call(sink, stream, @undefined, onSinkClose, stream.@asyncContext);
      sink.start({ highWaterMark }), started = !0, many = await many;
    }
    if (many.done)
      return state.didClose = !0, sink.end();
    if (!started) {
      if (isNative)
        @startDirectStream.@call(sink, stream, @undefined, onSinkClose, stream.@asyncContext);
      sink.start({ highWaterMark });
    }
    for (var i = 0, values = many.value, length = many.value.length;i < length; i++)
      if (sink.write(values[i]) < 0) {
        if (await sink.flush(!0), state.didClose)
          break;
      }
    values = many = @undefined;
    var streamState = @getByIdDirectPrivate(stream, "state");
    if (state.didClose || streamState === 1)
      return state.didClose = !0, sink.end();
    while (!0) {
      var { value, done } = await reader.read();
      if (done)
        return state.didClose = !0, sink.end();
      if (sink.write(value) < 0) {
        if (await sink.flush(!0), state.didClose)
          return sink.end();
      }
    }
  } catch (e) {
    state.didThrow = !0;
    try {
      reader = @undefined;
      let prom = stream.cancel(e);
      if (@isPromise(prom))
        @markPromiseAsHandled(prom);
    } catch {}
    if (sink && !state.didClose) {
      state.didClose = !0;
      try {
        sink.close(e);
      } catch (j) {
        throw new globalThis.AggregateError([e, j]);
      }
    }
    throw e;
  } finally {
    if (reader) {
      try {
        reader.releaseLock();
      } catch {}
      reader = @undefined;
    }
    if (sink = @undefined, stream) {
      var streamState = @getByIdDirectPrivate(stream, "state"), readableStreamController = @getByIdDirectPrivate(stream, "readableStreamController");
      if (readableStreamController) {
        if (@getByIdDirectPrivate(readableStreamController, "underlyingSource"))
          @putByIdDirectPrivate(readableStreamController, "underlyingSource", null);
        if (@getByIdDirectPrivate(readableStreamController, "controlledReadableStream"))
          @putByIdDirectPrivate(readableStreamController, "controlledReadableStream", null);
        if (@putByIdDirectPrivate(stream, "readableStreamController", null), @getByIdDirectPrivate(stream, "underlyingSource"))
          @putByIdDirectPrivate(stream, "underlyingSource", null);
        readableStreamController = @undefined;
      }
      if (stream && !state.didThrow && streamState !== 1 && streamState !== 3)
        @readableStreamCloseIfPossible(stream);
      stream = @undefined;
    }
  }
})
