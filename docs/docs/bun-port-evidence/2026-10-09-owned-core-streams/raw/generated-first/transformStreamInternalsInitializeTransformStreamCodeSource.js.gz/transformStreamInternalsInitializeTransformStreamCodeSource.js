(function (stream, startPromise, writableHighWaterMark, writableSizeAlgorithm, readableHighWaterMark, readableSizeAlgorithm) {"use strict";
  let startAlgorithm = () => {
    return startPromise;
  }, writeAlgorithm = (chunk) => {
    return @transformStreamDefaultSinkWriteAlgorithm(stream, chunk);
  }, abortAlgorithm = (reason) => {
    return @transformStreamDefaultSinkAbortAlgorithm(stream, reason);
  }, closeAlgorithm = () => {
    return @transformStreamDefaultSinkCloseAlgorithm(stream);
  }, writable = @createWritableStream(startAlgorithm, writeAlgorithm, closeAlgorithm, abortAlgorithm, writableHighWaterMark, writableSizeAlgorithm), pullAlgorithm = () => {
    return @transformStreamDefaultSourcePullAlgorithm(stream);
  }, cancelAlgorithm = (reason) => {
    return @transformStreamErrorWritableAndUnblockWrite(stream, reason), @Promise.@resolve();
  }, underlyingSource = {};
  @putByIdDirectPrivate(underlyingSource, "start", startAlgorithm), @putByIdDirectPrivate(underlyingSource, "pull", pullAlgorithm), @putByIdDirectPrivate(underlyingSource, "cancel", cancelAlgorithm);
  let options = {};
  @putByIdDirectPrivate(options, "size", readableSizeAlgorithm), @putByIdDirectPrivate(options, "highWaterMark", readableHighWaterMark);
  let readable = new @ReadableStream(underlyingSource, options);
  @putByIdDirectPrivate(stream, "writable", writable), @putByIdDirectPrivate(stream, "internalWritable", @getInternalWritableStream(writable)), @putByIdDirectPrivate(stream, "readable", readable), @putByIdDirectPrivate(stream, "backpressure", @undefined), @putByIdDirectPrivate(stream, "backpressureChangePromise", @undefined), @transformStreamSetBackpressure(stream, !0), @putByIdDirectPrivate(stream, "controller", @undefined);
})
