(function (controller) {"use strict";
  return @isObject(controller) && @getByIdDirectPrivate(controller, "underlyingSource") !== @undefined;
})
