(function () {"use strict";
  let highWaterMark = @getByIdDirectPrivate(this, "highWaterMark");
  if (highWaterMark === @undefined)
    @throwTypeError("CountQueuingStrategy.highWaterMark getter called on incompatible |this| value.");
  return highWaterMark;
})
