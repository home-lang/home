(function (stream, backpressure) {"use strict";
  let backpressureChangePromise = @getByIdDirectPrivate(stream, "backpressureChangePromise");
  if (backpressureChangePromise !== @undefined)
    backpressureChangePromise.resolve.@call();
  @putByIdDirectPrivate(stream, "backpressureChangePromise", @newPromiseCapability(@Promise)), @putByIdDirectPrivate(stream, "backpressure", backpressure);
})
