(function (stream) {"use strict";
  @putByIdDirectPrivate(stream, "state", 1);
  let reader = @getByIdDirectPrivate(stream, "reader");
  if (!reader)
    return;
  if (@isReadableStreamDefaultReader(reader)) {
    let requests = @getByIdDirectPrivate(reader, "readRequests");
    if (requests.isNotEmpty()) {
      @putByIdDirectPrivate(reader, "readRequests", @createFIFO());
      for (var request = requests.shift();request; request = requests.shift())
        @fulfillPromise(request, { value: @undefined, done: !0 });
    }
  }
  let closedPromiseCapability = @getByIdDirectPrivate(reader, "closedPromiseCapability");
  if (closedPromiseCapability)
    closedPromiseCapability.resolve.@call();
})
