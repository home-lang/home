(function (controller) {"use strict";
  while (@getByIdDirectPrivate(controller, "pendingPullIntos").isNotEmpty()) {
    if (@getByIdDirectPrivate(controller, "queue").size === 0)
      return;
    let pullIntoDescriptor = @getByIdDirectPrivate(controller, "pendingPullIntos").peek();
    if (@readableByteStreamControllerFillDescriptorFromQueue(controller, pullIntoDescriptor))
      @readableByteStreamControllerShiftPendingDescriptor(controller), @readableByteStreamControllerCommitDescriptor(@getByIdDirectPrivate(controller, "controlledReadableStream"), pullIntoDescriptor);
  }
})
