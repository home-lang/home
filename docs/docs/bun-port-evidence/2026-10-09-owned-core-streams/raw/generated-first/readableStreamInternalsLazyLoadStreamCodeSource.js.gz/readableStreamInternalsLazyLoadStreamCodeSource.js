(function (stream, autoAllocateChunkSize) {"use strict";
  var handle = stream.@bunNativePtr;
  if (handle === -1)
    return;
  var Prototype = @lazyStreamPrototypeMap.@get(@getPrototypeOf(handle));
  if (Prototype === @undefined)
    @lazyStreamPrototypeMap.@set(@getPrototypeOf(handle), Prototype = @createLazyLoadedStreamPrototype());
  if (stream.@disturbed = !0, autoAllocateChunkSize === @undefined)
    autoAllocateChunkSize = 262144;
  let chunkSizeOrCompleteBuffer = handle.start(autoAllocateChunkSize), chunkSize, drainValue;
  if (@isTypedArrayView(chunkSizeOrCompleteBuffer))
    chunkSize = 0, drainValue = chunkSizeOrCompleteBuffer;
  else
    chunkSize = chunkSizeOrCompleteBuffer, drainValue = handle.drain();
  if (chunkSize === 0) {
    if ((drainValue?.byteLength ?? 0) > 0)
      return {
        start(controller) {
          controller.enqueue(drainValue), controller.close();
        },
        pull(controller) {
          controller.close();
        }
      };
    return {
      start(controller) {
        controller.close();
      },
      pull(controller) {
        controller.close();
      }
    };
  }
  return new Prototype(handle, Math.max(chunkSize, autoAllocateChunkSize), drainValue);
})
