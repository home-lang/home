(function (controller) {"use strict";
  var queue = @getByIdDirectPrivate(controller, "queue");
  let content = queue.content;
  if (content.isNotEmpty()) {
    let chunk = @dequeueValue(queue);
    if (@getByIdDirectPrivate(controller, "closeRequested") && content.isEmpty())
      @readableStreamCloseIfPossible(@getByIdDirectPrivate(controller, "controlledReadableStream"));
    else
      @readableStreamDefaultControllerCallPullIfNeeded(controller);
    return @createFulfilledPromise({ value: chunk, done: !1 });
  }
  let pendingPromise = @readableStreamAddReadRequest(@getByIdDirectPrivate(controller, "controlledReadableStream"));
  return @readableStreamDefaultControllerCallPullIfNeeded(controller), pendingPromise;
})
