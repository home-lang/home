(function (startAlgorithm, writeAlgorithm, closeAlgorithm, abortAlgorithm, highWaterMark, sizeAlgorithm) {"use strict";
  let internalStream = {};
  @initializeWritableStreamSlots(internalStream, {});
  let controller = new @WritableStreamDefaultController;
  return @setUpWritableStreamDefaultController(internalStream, controller, startAlgorithm, writeAlgorithm, closeAlgorithm, abortAlgorithm, highWaterMark, sizeAlgorithm), @createWritableStreamFromInternal(internalStream);
})
