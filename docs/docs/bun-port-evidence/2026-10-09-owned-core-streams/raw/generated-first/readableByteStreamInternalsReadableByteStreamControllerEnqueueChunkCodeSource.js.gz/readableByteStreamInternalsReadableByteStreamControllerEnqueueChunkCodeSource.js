(function (controller, buffer, byteOffset, byteLength) {"use strict";
  @getByIdDirectPrivate(controller, "queue").content.push({
    buffer,
    byteOffset,
    byteLength
  }), @getByIdDirectPrivate(controller, "queue").size += byteLength;
})
