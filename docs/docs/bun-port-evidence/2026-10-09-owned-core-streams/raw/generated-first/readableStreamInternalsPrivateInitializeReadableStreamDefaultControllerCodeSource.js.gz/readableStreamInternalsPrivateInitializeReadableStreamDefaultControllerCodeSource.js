(function (stream, underlyingSource, size, highWaterMark) {"use strict";
  if (!@isReadableStream(stream))
    @throwTypeError("ReadableStreamDefaultController needs a ReadableStream");
  if (@getByIdDirectPrivate(stream, "readableStreamController") !== null)
    @throwTypeError("ReadableStream already has a controller");
  return @putByIdDirectPrivate(this, "controlledReadableStream", stream), @putByIdDirectPrivate(this, "underlyingSource", underlyingSource), @putByIdDirectPrivate(this, "queue", @newQueue()), @putByIdDirectPrivate(this, "started", -1), @putByIdDirectPrivate(this, "closeRequested", !1), @putByIdDirectPrivate(this, "pullAgain", !1), @putByIdDirectPrivate(this, "pulling", !1), @putByIdDirectPrivate(this, "strategy", @validateAndNormalizeQueuingStrategy(size, highWaterMark)), this;
})
