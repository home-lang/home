(function (e) {"use strict";
  var controller = this, sink = controller.@sink;
  if (sink) {
    @putByIdDirectPrivate(controller, "sink", @undefined);
    try {
      sink.close(e);
    } catch {}
  }
  this.error = this.flush = this.write = this.close = this.end = @onReadableStreamDirectControllerClosed;
  let underlyingSource = this.@underlyingSource, underlyingClose = underlyingSource.close;
  if (typeof underlyingClose === "function")
    try {
      underlyingClose.@call(underlyingSource, e);
    } catch {}
  try {
    var pend = controller._pendingRead;
    if (pend)
      controller._pendingRead = @undefined, @rejectPromise(pend, e);
  } catch {}
  var stream = controller.@controlledReadableStream;
  if (stream)
    @readableStreamError(stream, e);
})
