(function () {"use strict";
  let startAlgorithm = () => {
    return @Promise.@resolve();
  }, transformAlgorithm = (chunk) => {
    let encoder = @getByIdDirectPrivate(this, "textEncoderStreamEncoder");
    try {
      var buffer = encoder.encode(chunk);
    } catch (e) {
      return @Promise.@reject(e);
    }
    if (buffer.length) {
      let transformStream = @getByIdDirectPrivate(this, "textEncoderStreamTransform"), controller = @getByIdDirectPrivate(transformStream, "controller");
      @transformStreamDefaultControllerEnqueue(controller, buffer);
    }
    return @Promise.@resolve();
  }, flushAlgorithm = () => {
    let buffer = @getByIdDirectPrivate(this, "textEncoderStreamEncoder").flush();
    if (buffer.length) {
      let transformStream = @getByIdDirectPrivate(this, "textEncoderStreamTransform"), controller = @getByIdDirectPrivate(transformStream, "controller");
      @transformStreamDefaultControllerEnqueue(controller, buffer);
    }
    return @Promise.@resolve();
  }, transform = @createTransformStream(startAlgorithm, transformAlgorithm, flushAlgorithm);
  return @putByIdDirectPrivate(this, "textEncoderStreamTransform", transform), @putByIdDirectPrivate(this, "textEncoderStreamEncoder", new @TextEncoderStreamEncoder), this;
})
