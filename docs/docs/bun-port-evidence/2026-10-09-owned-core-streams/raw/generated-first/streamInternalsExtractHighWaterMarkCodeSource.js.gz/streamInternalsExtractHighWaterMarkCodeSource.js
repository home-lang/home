(function (strategy, defaultHWM) {"use strict";
  let highWaterMark = strategy.highWaterMark;
  if (highWaterMark === @undefined)
    return defaultHWM;
  if (highWaterMark !== highWaterMark || highWaterMark < 0)
    @throwRangeError("highWaterMark value is negative or not a number");
  return @toNumber(highWaterMark);
})
