(function (stream, reason) {"use strict";
  stream.@disturbed = !0;
  let state = @getByIdDirectPrivate(stream, "state");
  if (state === 1)
    return @Promise.@resolve();
  if (state === 3)
    return @Promise.@reject(@getByIdDirectPrivate(stream, "storedError"));
  @readableStreamClose(stream);
  let reader = @getByIdDirectPrivate(stream, "reader");
  if (reader && @isReadableStreamBYOBReader(reader)) {
    let readIntoRequests = @getByIdDirectPrivate(reader, "readIntoRequests");
    if (readIntoRequests?.isNotEmpty()) {
      @putByIdDirectPrivate(reader, "readIntoRequests", @createFIFO());
      for (var request = readIntoRequests.shift();request; request = readIntoRequests.shift())
        @fulfillPromise(request, { value: @undefined, done: !0 });
    }
  }
  let controller = @getByIdDirectPrivate(stream, "readableStreamController");
  if (controller === null)
    return @Promise.@resolve();
  let cancel = controller.@cancel;
  if (cancel)
    return cancel(controller, reason).@then(function() {});
  if (controller.close)
    return @Promise.@resolve(controller.close(reason));
  @throwTypeError("ReadableStreamController has no cancel or close method");
})
