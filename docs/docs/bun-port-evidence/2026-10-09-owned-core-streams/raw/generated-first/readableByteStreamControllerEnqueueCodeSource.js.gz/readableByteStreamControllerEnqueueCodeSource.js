(function (chunk) {"use strict";
  if (!@isReadableByteStreamController(this))
    throw @makeErrorWithCode(140, "ReadableByteStreamController");
  if (@getByIdDirectPrivate(this, "closeRequested"))
    throw @makeErrorWithCode(138, "Controller is already closed");
  if (@getByIdDirectPrivate(@getByIdDirectPrivate(this, "controlledReadableStream"), "state") !== 4)
    throw @makeErrorWithCode(138, "Controller is already closed");
  if (!@isObject(chunk) || !@ArrayBuffer.@isView(chunk))
    throw @makeErrorWithCode(119, "buffer", "Buffer, TypedArray, or DataView", chunk);
  return @readableByteStreamControllerEnqueue(this, chunk);
})
