(function () {"use strict";
  var stream = new @ReadableStream({
    pull() {}
  });
  return stream.getReader(), stream;
})
