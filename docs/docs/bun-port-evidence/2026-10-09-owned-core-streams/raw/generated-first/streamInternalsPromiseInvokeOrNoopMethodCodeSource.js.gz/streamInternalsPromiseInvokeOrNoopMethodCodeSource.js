(function (object, method, args) {"use strict";
  try {
    return @promiseInvokeOrNoopMethodNoCatch(object, method, args);
  } catch (error) {
    return @Promise.@reject(error);
  }
})
