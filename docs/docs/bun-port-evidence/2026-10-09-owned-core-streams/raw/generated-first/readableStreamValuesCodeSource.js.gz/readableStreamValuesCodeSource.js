(function (options) {"use strict";
  var prototype = @ReadableStream.prototype;
  return @readableStreamDefineLazyIterators(prototype), prototype.values.@call(this, options);
})
