(function (stream, underlyingSource, strategy) {"use strict";
  let type = underlyingSource.type, typeString = @toString(type);
  if (typeString === "bytes") {
    if (strategy.highWaterMark === @undefined)
      strategy.highWaterMark = 0;
    if (strategy.size !== @undefined)
      @throwRangeError("Strategy for a ReadableByteStreamController cannot have a size");
    @putByIdDirectPrivate(stream, "readableStreamController", new @ReadableByteStreamController(stream, underlyingSource, strategy.highWaterMark, @isReadableStream));
  } else if (typeString === "direct") {
    var highWaterMark = strategy?.highWaterMark;
    @initializeArrayBufferStream.@call(stream, underlyingSource, highWaterMark);
  } else if (type === @undefined) {
    if (strategy.highWaterMark === @undefined)
      strategy.highWaterMark = 1;
    @setupReadableStreamDefaultController(stream, underlyingSource, strategy.size, strategy.highWaterMark, underlyingSource.start, underlyingSource.pull, underlyingSource.cancel);
  } else
    @throwRangeError("Invalid type for underlying source");
})
