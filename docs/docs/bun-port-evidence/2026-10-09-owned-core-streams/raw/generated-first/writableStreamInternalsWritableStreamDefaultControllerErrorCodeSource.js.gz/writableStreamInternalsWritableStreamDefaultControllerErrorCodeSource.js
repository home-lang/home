(function (controller, error) {"use strict";
  let stream = @getByIdDirectPrivate(controller, "stream");
  @writableStreamDefaultControllerClearAlgorithms(controller), @writableStreamStartErroring(stream, error);
})
