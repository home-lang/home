(function () {"use strict";
  if (!@isWritableStreamDefaultWriter(this))
    return @Promise.@reject(@makeErrorWithCode(140, "WritableStreamDefaultWriter"));
  return @getByIdDirectPrivate(this, "readyPromise").promise;
})
