(function (chunk) {"use strict";
  if (!@isTransformStreamDefaultController(this))
    throw @makeErrorWithCode(140, "TransformStreamDefaultController");
  @transformStreamDefaultControllerEnqueue(this, chunk);
})
