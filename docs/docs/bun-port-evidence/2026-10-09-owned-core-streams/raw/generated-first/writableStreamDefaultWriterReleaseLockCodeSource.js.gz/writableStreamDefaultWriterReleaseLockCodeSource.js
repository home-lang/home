(function () {"use strict";
  if (!@isWritableStreamDefaultWriter(this))
    throw @makeErrorWithCode(140, "WritableStreamDefaultWriter");
  if (@getByIdDirectPrivate(this, "stream") === @undefined)
    return;
  @writableStreamDefaultWriterRelease(this);
})
