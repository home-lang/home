(function (stream, controller, transformAlgorithm, flushAlgorithm) {"use strict";
  @putByIdDirectPrivate(controller, "stream", stream), @putByIdDirectPrivate(stream, "controller", controller), @putByIdDirectPrivate(controller, "transformAlgorithm", transformAlgorithm), @putByIdDirectPrivate(controller, "flushAlgorithm", flushAlgorithm);
})
