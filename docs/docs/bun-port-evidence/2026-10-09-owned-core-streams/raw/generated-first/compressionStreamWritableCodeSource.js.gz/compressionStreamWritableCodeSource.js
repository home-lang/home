(function () {"use strict";
  if (!@inherits(5, this))
    throw @makeGetterTypeError("CompressionStream", "writable");
  return @getByIdDirectPrivate(this, "writable");
})
