(function (stream) {"use strict";
  return @getByIdDirectPrivate(stream, "writer") !== @undefined;
})
