(function (stream) {"use strict";
  let storedError = @getByIdDirectPrivate(stream, "storedError"), closeRequest = @getByIdDirectPrivate(stream, "closeRequest");
  if (closeRequest !== @undefined)
    closeRequest.reject.@call(@undefined, storedError), @putByIdDirectPrivate(stream, "closeRequest", @undefined);
  let writer = @getByIdDirectPrivate(stream, "writer");
  if (writer !== @undefined) {
    let closedPromise = @getByIdDirectPrivate(writer, "closedPromise");
    closedPromise.reject.@call(@undefined, storedError), @markPromiseAsHandled(closedPromise.promise);
  }
})
