(function () {"use strict";
  if (!@isReadableStreamBYOBReader(this))
    return @Promise.@reject(@makeGetterTypeError("ReadableStreamBYOBReader", "closed"));
  return @getByIdDirectPrivate(this, "closedPromiseCapability").promise;
})
