(function (reason) {"use strict";
  if (!@isWritableStreamDefaultWriter(this))
    return @Promise.@reject(@makeErrorWithCode(140, "WritableStreamDefaultWriter"));
  if (@getByIdDirectPrivate(this, "stream") === @undefined)
    return @Promise.@reject(@makeTypeError("WritableStreamDefaultWriter has no stream"));
  return @writableStreamDefaultWriterAbort(this, reason);
})
