(function (stream, shouldClone) {"use strict";
  var start_ = @getByIdDirectPrivate(stream, "start");
  if (start_)
    @putByIdDirectPrivate(stream, "start", @undefined), start_();
  let reader = new @ReadableStreamDefaultReader(stream), teeState = {
    stream,
    flags: 0,
    reason1: @undefined,
    reason2: @undefined,
    branch1Source: @undefined,
    branch2Source: @undefined,
    branch1: @undefined,
    branch2: @undefined,
    cancelPromiseCapability: @newPromiseCapability(@Promise)
  }, pullFunction = @readableStreamTeePullFunction(teeState, reader, shouldClone), branch1Source = {
    @pull: pullFunction,
    @cancel: @readableStreamTeeBranch1CancelFunction(teeState, stream)
  }, branch2Source = {
    @pull: pullFunction,
    @cancel: @readableStreamTeeBranch2CancelFunction(teeState, stream)
  }, branch1 = new @ReadableStream(branch1Source), branch2 = new @ReadableStream(branch2Source);
  return @getByIdDirectPrivate(reader, "closedPromiseCapability").promise.@then(@undefined, function(e) {
    if (teeState.flags & 8 /* closedOrErrored */)
      return;
    if (@readableStreamDefaultControllerError(branch1.@readableStreamController, e), @readableStreamDefaultControllerError(branch2.@readableStreamController, e), teeState.flags |= 8 /* closedOrErrored */, teeState.flags & 3)
      teeState.cancelPromiseCapability.resolve.@call();
  }), teeState.branch1 = branch1, teeState.branch2 = branch2, [branch1, branch2];
})
