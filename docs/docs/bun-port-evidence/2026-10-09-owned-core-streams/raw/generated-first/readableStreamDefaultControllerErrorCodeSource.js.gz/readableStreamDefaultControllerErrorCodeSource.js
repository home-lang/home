(function (err) {"use strict";
  if (!@isReadableStreamDefaultController(this))
    throw @makeErrorWithCode(140, "ReadableStreamDefaultController");
  @readableStreamDefaultControllerError(this, err);
})
