(function (stream, underlyingSink, underlyingSinkDict, highWaterMark, sizeAlgorithm) {"use strict";
  let controller = new @WritableStreamDefaultController, startAlgorithm = () => {}, writeAlgorithm = () => {
    return @Promise.@resolve();
  }, closeAlgorithm = () => {
    return @Promise.@resolve();
  }, abortAlgorithm = () => {
    return @Promise.@resolve();
  };
  if ("start" in underlyingSinkDict) {
    let startMethod = underlyingSinkDict.start;
    startAlgorithm = () => @promiseInvokeOrNoopMethodNoCatch(underlyingSink, startMethod, [controller]);
  }
  if ("write" in underlyingSinkDict) {
    let writeMethod = underlyingSinkDict.write;
    writeAlgorithm = (chunk) => @promiseInvokeOrNoopMethod(underlyingSink, writeMethod, [chunk, controller]);
  }
  if ("close" in underlyingSinkDict) {
    let closeMethod = underlyingSinkDict.close;
    closeAlgorithm = () => @promiseInvokeOrNoopMethod(underlyingSink, closeMethod, []);
  }
  if ("abort" in underlyingSinkDict) {
    let abortMethod = underlyingSinkDict.abort;
    abortAlgorithm = (reason) => @promiseInvokeOrNoopMethod(underlyingSink, abortMethod, [reason]);
  }
  @setUpWritableStreamDefaultController(stream, controller, startAlgorithm, writeAlgorithm, closeAlgorithm, abortAlgorithm, highWaterMark, sizeAlgorithm);
})
