(function (stream) {"use strict";
  let closeRequest = @getByIdDirectPrivate(stream, "closeRequest");
  @putByIdDirectPrivate(stream, "inFlightCloseRequest", closeRequest), @putByIdDirectPrivate(stream, "closeRequest", @undefined);
})
