(async function (stream, underlyingSource) {"use strict";
  let capability = @initializeArrayStream.@call(stream, underlyingSource, @undefined);
  underlyingSource = @undefined;
  var reader = stream.getReader();
  try {
    while (@getByIdDirectPrivate(stream, "state") === 4) {
      var thisResult = await reader.read();
      if (thisResult.done)
        break;
    }
    try {
      reader.releaseLock();
    } catch {}
    return reader = @undefined, @Promise.@resolve(capability.promise);
  } finally {
    stream = @undefined, reader = @undefined;
  }
})
