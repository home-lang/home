(function () {"use strict";
  return @putByIdDirectPrivate(this, "queue", @newQueue()), @putByIdDirectPrivate(this, "abortSteps", (reason) => {
    let result = @getByIdDirectPrivate(this, "abortAlgorithm").@call(@undefined, reason);
    return @writableStreamDefaultControllerClearAlgorithms(this), result;
  }), @putByIdDirectPrivate(this, "errorSteps", () => {
    @resetQueue(@getByIdDirectPrivate(this, "queue"));
  }), this;
})
