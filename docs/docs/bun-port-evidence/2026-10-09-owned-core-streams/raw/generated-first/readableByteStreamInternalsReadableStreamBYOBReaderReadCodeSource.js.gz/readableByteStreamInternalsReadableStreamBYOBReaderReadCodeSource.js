(function (reader, view) {"use strict";
  let stream = @getByIdDirectPrivate(reader, "ownerReadableStream");
  if (@putByIdDirectPrivate(stream, "disturbed", !0), @getByIdDirectPrivate(stream, "state") === 3)
    return @Promise.@reject(@getByIdDirectPrivate(stream, "storedError"));
  return @readableByteStreamControllerPullInto(@getByIdDirectPrivate(stream, "readableStreamController"), view);
})
