(function () {"use strict";
  if (!@isReadableStreamBYOBRequest(this))
    throw @makeErrorWithCode(140, "ReadableStreamBYOBRequest");
  return @getByIdDirectPrivate(this, "view");
})
