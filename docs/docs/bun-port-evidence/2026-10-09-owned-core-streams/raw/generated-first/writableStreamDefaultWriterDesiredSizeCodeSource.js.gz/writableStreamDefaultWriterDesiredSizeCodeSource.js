(function () {"use strict";
  if (!@isWritableStreamDefaultWriter(this))
    throw @makeErrorWithCode(140, "WritableStreamDefaultWriter");
  if (@getByIdDirectPrivate(this, "stream") === @undefined)
    @throwTypeError("WritableStreamDefaultWriter has no stream");
  return @writableStreamDefaultWriterGetDesiredSize(this);
})
