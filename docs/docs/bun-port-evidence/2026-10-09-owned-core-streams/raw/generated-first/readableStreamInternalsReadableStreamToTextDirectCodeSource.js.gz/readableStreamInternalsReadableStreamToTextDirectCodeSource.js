(async function (stream, underlyingSource) {"use strict";
  let capability = @initializeTextStream.@call(stream, underlyingSource, @undefined);
  var reader = stream.getReader();
  while (@getByIdDirectPrivate(stream, "state") === 4) {
    var thisResult = await reader.read();
    if (thisResult.done)
      break;
  }
  try {
    reader.releaseLock();
  } catch {}
  return reader = @undefined, stream = @undefined, capability.promise;
})
