(function (pipeState) {"use strict";
  if (pipeState.shuttingDown)
    return;
  pipeState.shuttingDown = !0;
  let hasError = arguments.length > 1, error = arguments[1], finalize = () => {
    if (hasError)
      @pipeToFinalize(pipeState, error);
    else
      @pipeToFinalize(pipeState);
  };
  if (@getByIdDirectPrivate(pipeState.destination, "state") === "writable" && !@writableStreamCloseQueuedOrInFlight(pipeState.destination)) {
    pipeState.pendingReadPromiseCapability.promise.@then(() => {
      pipeState.pendingWritePromise.@then(finalize, finalize);
    }, (e) => @pipeToFinalize(pipeState, e));
    return;
  }
  finalize();
})
