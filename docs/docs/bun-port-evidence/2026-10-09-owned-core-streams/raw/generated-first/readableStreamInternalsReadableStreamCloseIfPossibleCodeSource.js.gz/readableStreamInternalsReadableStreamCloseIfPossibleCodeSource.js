(function (stream) {"use strict";
  switch (@getByIdDirectPrivate(stream, "state")) {
    case 4:
    case 2: {
      @readableStreamClose(stream);
      break;
    }
  }
})
