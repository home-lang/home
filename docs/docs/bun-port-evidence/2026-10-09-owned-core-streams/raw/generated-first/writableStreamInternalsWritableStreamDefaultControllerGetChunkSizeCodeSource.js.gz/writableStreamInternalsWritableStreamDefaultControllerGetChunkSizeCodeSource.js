(function (controller, chunk) {"use strict";
  try {
    return @getByIdDirectPrivate(controller, "strategySizeAlgorithm").@call(@undefined, chunk);
  } catch (e) {
    return @writableStreamDefaultControllerErrorIfNeeded(controller, e), 1;
  }
})
