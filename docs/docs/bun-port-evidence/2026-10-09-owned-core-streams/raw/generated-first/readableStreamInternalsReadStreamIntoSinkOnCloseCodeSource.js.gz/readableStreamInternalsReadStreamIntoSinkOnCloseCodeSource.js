(function (stream, reason) {"use strict";
  if (!this.didThrow && !this.didClose && stream && stream.@state !== 1)
    @readableStreamCancel(stream, reason);
  this.didClose = !0;
})
