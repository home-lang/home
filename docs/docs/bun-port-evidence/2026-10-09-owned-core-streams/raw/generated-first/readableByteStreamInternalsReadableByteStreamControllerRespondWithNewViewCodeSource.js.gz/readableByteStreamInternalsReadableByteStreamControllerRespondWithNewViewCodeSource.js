(function (controller, view) {"use strict";
  let firstDescriptor = @getByIdDirectPrivate(controller, "pendingPullIntos").peek();
  if (firstDescriptor.byteOffset + firstDescriptor.bytesFilled !== view.byteOffset)
    @throwRangeError("Invalid value for view.byteOffset");
  if (firstDescriptor.byteLength < view.byteLength)
    throw @makeErrorWithCode(120, "view", view);
  firstDescriptor.buffer = view.buffer, @readableByteStreamControllerRespondInternal(controller, view.byteLength);
})
