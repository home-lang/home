(function (stream) {"use strict";
  @putByIdDirectPrivate(stream, "state", "errored");
  let controller = @getByIdDirectPrivate(stream, "controller");
  @getByIdDirectPrivate(controller, "errorSteps").@call();
  let storedError = @getByIdDirectPrivate(stream, "storedError"), requests = @getByIdDirectPrivate(stream, "writeRequests");
  for (var request = requests.shift();request; request = requests.shift())
    request.reject.@call(@undefined, storedError);
  @putByIdDirectPrivate(stream, "writeRequests", @createFIFO());
  let abortRequest = @getByIdDirectPrivate(stream, "pendingAbortRequest");
  if (abortRequest === @undefined) {
    @writableStreamRejectCloseAndClosedPromiseIfNeeded(stream);
    return;
  }
  if (@putByIdDirectPrivate(stream, "pendingAbortRequest", @undefined), abortRequest.wasAlreadyErroring) {
    abortRequest.promise.reject.@call(@undefined, storedError), @writableStreamRejectCloseAndClosedPromiseIfNeeded(stream);
    return;
  }
  @getByIdDirectPrivate(controller, "abortSteps").@call(@undefined, abortRequest.reason).@then(() => {
    abortRequest.promise.resolve.@call(), @writableStreamRejectCloseAndClosedPromiseIfNeeded(stream);
  }, (reason) => {
    abortRequest.promise.reject.@call(@undefined, reason), @writableStreamRejectCloseAndClosedPromiseIfNeeded(stream);
  });
})
