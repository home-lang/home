(function (stream, sink) {"use strict";
  let reader = new @ReadableStreamDefaultReader(stream);
  @getByIdDirectPrivate(reader, "closedPromiseCapability").promise.@then(() => {}, (e) => {
    sink.error(e);
  });
  function doPipe() {
    @readableStreamDefaultReaderRead(reader).@then(function(result) {
      if (result.done) {
        sink.close();
        return;
      }
      try {
        sink.enqueue(result.value);
      } catch {
        sink.error("ReadableStream chunk enqueueing in the sink failed");
        return;
      }
      doPipe();
    }, function(e) {
      sink.error(e);
    });
  }
  doPipe();
})
