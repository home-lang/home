(function (result) {"use strict";
  let promise = @Promise.@resolve(result);
  if (promise.@then === @undefined)
    promise.@then = @Promise.prototype.@then;
  return promise;
})
