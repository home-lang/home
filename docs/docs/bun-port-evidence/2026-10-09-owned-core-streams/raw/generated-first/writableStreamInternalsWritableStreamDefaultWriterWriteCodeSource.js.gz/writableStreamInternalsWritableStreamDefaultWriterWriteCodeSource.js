(function (writer, chunk) {"use strict";
  let stream = @getByIdDirectPrivate(writer, "stream"), controller = @getByIdDirectPrivate(stream, "controller"), chunkSize = @writableStreamDefaultControllerGetChunkSize(controller, chunk);
  if (stream !== @getByIdDirectPrivate(writer, "stream"))
    return @Promise.@reject(@makeTypeError("writer is not stream's writer"));
  let state = @getByIdDirectPrivate(stream, "state");
  if (state === "errored")
    return @Promise.@reject(@getByIdDirectPrivate(stream, "storedError"));
  if (@writableStreamCloseQueuedOrInFlight(stream) || state === "closed")
    return @Promise.@reject(@makeTypeError("stream is closing or closed"));
  if (@writableStreamCloseQueuedOrInFlight(stream) || state === "closed")
    return @Promise.@reject(@makeTypeError("stream is closing or closed"));
  if (state === "erroring")
    return @Promise.@reject(@getByIdDirectPrivate(stream, "storedError"));
  let promise = @writableStreamAddWriteRequest(stream);
  return @writableStreamDefaultControllerWrite(controller, chunk, chunkSize), promise;
})
