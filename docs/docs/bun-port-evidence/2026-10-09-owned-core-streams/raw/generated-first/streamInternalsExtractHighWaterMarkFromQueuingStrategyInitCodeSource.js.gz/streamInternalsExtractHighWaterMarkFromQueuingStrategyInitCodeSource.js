(function (init) {"use strict";
  if (!@isObject(init))
    @throwTypeError("QueuingStrategyInit argument must be an object.");
  let { highWaterMark } = init;
  if (highWaterMark === @undefined)
    @throwTypeError("QueuingStrategyInit.highWaterMark member is required.");
  return @toNumber(highWaterMark);
})
