(function (controller) {"use strict";
  if (@getByIdDirectPrivate(controller, "byobRequest") === @undefined)
    return;
  let byobRequest = @getByIdDirectPrivate(controller, "byobRequest");
  @putByIdDirectPrivate(byobRequest, "associatedReadableByteStreamController", null), @putByIdDirectPrivate(byobRequest, "view", @undefined), @putByIdDirectPrivate(controller, "byobRequest", @undefined);
})
