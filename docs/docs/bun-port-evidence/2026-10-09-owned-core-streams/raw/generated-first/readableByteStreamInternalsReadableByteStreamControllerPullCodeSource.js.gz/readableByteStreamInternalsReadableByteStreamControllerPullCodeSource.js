(function (controller) {"use strict";
  let stream = @getByIdDirectPrivate(controller, "controlledReadableStream");
  if (@getByIdDirectPrivate(controller, "queue").content?.isNotEmpty()) {
    let entry = @getByIdDirectPrivate(controller, "queue").content.shift();
    @getByIdDirectPrivate(controller, "queue").size -= entry.byteLength, @readableByteStreamControllerHandleQueueDrain(controller);
    let view;
    try {
      view = new @Uint8Array(entry.buffer, entry.byteOffset, entry.byteLength);
    } catch (error) {
      return @Promise.@reject(error);
    }
    return @createFulfilledPromise({ value: view, done: !1 });
  }
  if (@getByIdDirectPrivate(controller, "autoAllocateChunkSize") !== @undefined) {
    let buffer;
    try {
      buffer = new @ArrayBuffer(@getByIdDirectPrivate(controller, "autoAllocateChunkSize"));
    } catch (error) {
      return @Promise.@reject(error);
    }
    let pullIntoDescriptor = {
      buffer,
      byteOffset: 0,
      byteLength: @getByIdDirectPrivate(controller, "autoAllocateChunkSize"),
      bytesFilled: 0,
      elementSize: 1,
      ctor: @Uint8Array,
      readerType: "default"
    };
    @getByIdDirectPrivate(controller, "pendingPullIntos").push(pullIntoDescriptor);
  }
  let promise = @readableStreamAddReadRequest(stream);
  return @readableByteStreamControllerCallPullIfNeeded(controller), promise;
})
