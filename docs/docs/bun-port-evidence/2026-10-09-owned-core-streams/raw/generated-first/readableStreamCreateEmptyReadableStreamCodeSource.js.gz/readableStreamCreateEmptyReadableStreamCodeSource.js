(function () {"use strict";
  var stream = new @ReadableStream({
    pull() {}
  });
  return @readableStreamClose(stream), stream;
})
