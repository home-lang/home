(function (stream) {"use strict";
  @getByIdDirectPrivate(stream, "inFlightWriteRequest").resolve.@call(), @putByIdDirectPrivate(stream, "inFlightWriteRequest", @undefined);
})
