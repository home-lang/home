(function (reader, error) {"use strict";
  let requests = @getByIdDirectPrivate(reader, "readRequests");
  @putByIdDirectPrivate(reader, "readRequests", @createFIFO());
  for (var request = requests.shift();request; request = requests.shift())
    @rejectPromise(request, error);
})
