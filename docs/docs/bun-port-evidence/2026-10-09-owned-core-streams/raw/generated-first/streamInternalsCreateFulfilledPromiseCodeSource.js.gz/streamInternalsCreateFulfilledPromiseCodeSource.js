(function (value) {"use strict";
  let promise = @newPromise();
  return @fulfillPromise(promise, value), promise;
})
