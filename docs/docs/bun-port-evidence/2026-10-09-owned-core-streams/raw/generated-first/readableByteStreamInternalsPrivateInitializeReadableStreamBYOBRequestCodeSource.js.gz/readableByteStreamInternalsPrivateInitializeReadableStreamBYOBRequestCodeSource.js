(function (controller, view) {"use strict";
  @putByIdDirectPrivate(this, "associatedReadableByteStreamController", controller), @putByIdDirectPrivate(this, "view", view);
})
