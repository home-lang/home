(function () {"use strict";
  if (!@isReadableStream(this))
    throw @makeGetterTypeError("ReadableStream", "locked");
  return @isReadableStreamLocked(this);
})
