(function (stream, error) {"use strict";
  @getByIdDirectPrivate(stream, "inFlightWriteRequest").reject.@call(@undefined, error), @putByIdDirectPrivate(stream, "inFlightWriteRequest", @undefined);
  let state = @getByIdDirectPrivate(stream, "state");
  @writableStreamDealWithRejection(stream, error);
})
