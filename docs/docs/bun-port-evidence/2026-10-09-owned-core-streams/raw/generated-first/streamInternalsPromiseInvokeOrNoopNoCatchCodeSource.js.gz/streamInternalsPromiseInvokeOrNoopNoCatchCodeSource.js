(function (object, key, args) {"use strict";
  return @promiseInvokeOrNoopMethodNoCatch(object, object[key], args);
})
