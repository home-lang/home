(function (stream, e) {"use strict";
  let readable = @getByIdDirectPrivate(stream, "readable"), readableController = @getByIdDirectPrivate(readable, "readableStreamController");
  @readableStreamDefaultControllerError(readableController, e), @transformStreamErrorWritableAndUnblockWrite(stream, e);
})
