(function (pipeState, action) {"use strict";
  if (pipeState.shuttingDown)
    return;
  pipeState.shuttingDown = !0;
  let hasError = arguments.length > 2, error = arguments[2], finalize = () => {
    action().@then(() => {
      if (hasError)
        @pipeToFinalize(pipeState, error);
      else
        @pipeToFinalize(pipeState);
    }, (e) => {
      @pipeToFinalize(pipeState, e);
    });
  };
  if (@getByIdDirectPrivate(pipeState.destination, "state") === "writable" && !@writableStreamCloseQueuedOrInFlight(pipeState.destination)) {
    pipeState.pendingReadPromiseCapability.promise.@then(() => {
      pipeState.pendingWritePromise.@then(finalize, finalize);
    }, (e) => @pipeToFinalize(pipeState, e));
    return;
  }
  finalize();
})
