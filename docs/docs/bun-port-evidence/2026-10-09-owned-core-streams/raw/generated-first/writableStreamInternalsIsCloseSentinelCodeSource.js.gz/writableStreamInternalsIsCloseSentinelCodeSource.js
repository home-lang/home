(function () {"use strict";})
