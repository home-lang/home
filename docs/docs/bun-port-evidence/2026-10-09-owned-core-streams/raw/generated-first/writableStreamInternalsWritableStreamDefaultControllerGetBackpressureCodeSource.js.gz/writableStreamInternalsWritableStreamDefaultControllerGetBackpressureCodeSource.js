(function (controller) {"use strict";
  return @writableStreamDefaultControllerGetDesiredSize(controller) <= 0;
})
