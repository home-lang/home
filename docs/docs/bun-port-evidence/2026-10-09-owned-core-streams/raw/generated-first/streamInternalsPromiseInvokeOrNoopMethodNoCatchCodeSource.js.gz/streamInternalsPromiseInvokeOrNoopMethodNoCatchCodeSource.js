(function (object, method, args) {"use strict";
  if (method === @undefined)
    return @Promise.@resolve();
  return @shieldingPromiseResolve(method.@apply(object, args));
})
