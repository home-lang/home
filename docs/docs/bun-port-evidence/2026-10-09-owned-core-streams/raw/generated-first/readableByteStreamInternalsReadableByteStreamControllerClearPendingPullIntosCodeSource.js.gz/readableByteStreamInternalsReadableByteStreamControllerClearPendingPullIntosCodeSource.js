(function (controller) {"use strict";
  @readableByteStreamControllerInvalidateBYOBRequest(controller);
  var existing = @getByIdDirectPrivate(controller, "pendingPullIntos");
  if (existing !== @undefined)
    existing.clear();
  else
    @putByIdDirectPrivate(controller, "pendingPullIntos", @createFIFO());
})
