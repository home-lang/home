(function (stream) {"use strict";
  if (!@isReadableStream(stream))
    throw @makeErrorWithCode(119, "stream", "ReadableStream", typeof stream);
  var underlyingSource = @getByIdDirectPrivate(stream, "underlyingSource");
  if (underlyingSource != null)
    return @readableStreamToArrayBufferDirect(stream, underlyingSource, !1);
  if (@isReadableStreamLocked(stream))
    return @Promise.@reject(@makeErrorWithCode(138, "ReadableStream is locked"));
  let result = @tryUseReadableStreamBufferedFastPath(stream, "arrayBuffer");
  if (result)
    return result;
  result = Bun.readableStreamToArray(stream);
  function toArrayBuffer(result2) {
    switch (result2.length) {
      case 0:
        return new @ArrayBuffer(0);
      case 1: {
        let view = result2[0];
        if (view instanceof @ArrayBuffer || view instanceof SharedArrayBuffer)
          return view;
        if (@ArrayBuffer.isView(view)) {
          let { buffer, byteOffset, byteLength } = view;
          if (byteOffset === 0 && byteLength === buffer.byteLength)
            return buffer;
          return buffer.slice(byteOffset, byteOffset + byteLength);
        }
        if (typeof view === "string")
          return (/* @__PURE__ */ new TextEncoder()).encode(view);
      }
      default: {
        let anyStrings = !1;
        for (let chunk of result2)
          if (typeof chunk === "string") {
            anyStrings = !0;
            break;
          }
        if (!anyStrings)
          return Bun.concatArrayBuffers(result2, !1);
        let sink = new Bun.ArrayBufferSink;
        sink.start();
        for (let chunk of result2)
          sink.write(chunk);
        return sink.end();
      }
    }
  }
  if (@isPromise(result)) {
    let completedResult = Bun.peek(result);
    if (completedResult !== result)
      result = completedResult;
    else
      return result.then(toArrayBuffer);
  }
  return @createFulfilledPromise(toArrayBuffer(result));
})
