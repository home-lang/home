(function (pipeState) {"use strict";
  let action = () => {
    pipeState.pendingReadPromiseCapability.resolve.@call(@undefined, !1);
    let error = @getByIdDirectPrivate(pipeState.source, "storedError");
    if (!pipeState.preventAbort) {
      @pipeToShutdownWithAction(pipeState, () => @writableStreamAbort(pipeState.destination, error), error);
      return;
    }
    @pipeToShutdown(pipeState, error);
  };
  if (@getByIdDirectPrivate(pipeState.source, "state") === 3) {
    action();
    return;
  }
  @getByIdDirectPrivate(pipeState.reader, "closedPromiseCapability").promise.@then(@undefined, action);
})
