(function (stream, chunk) {"use strict";
  let writable = @getByIdDirectPrivate(stream, "internalWritable"), controller = @getByIdDirectPrivate(stream, "controller");
  if (@getByIdDirectPrivate(stream, "backpressure")) {
    let promiseCapability = @newPromiseCapability(@Promise);
    return @getByIdDirectPrivate(stream, "backpressureChangePromise").promise.@then(() => {
      if (@getByIdDirectPrivate(writable, "state") === "erroring") {
        promiseCapability.reject.@call(@undefined, @getByIdDirectPrivate(writable, "storedError"));
        return;
      }
      @transformStreamDefaultControllerPerformTransform(controller, chunk).@then(() => {
        promiseCapability.resolve();
      }, (e) => {
        promiseCapability.reject.@call(@undefined, e);
      });
    }, (e) => {
      promiseCapability.reject.@call(@undefined, e);
    }), promiseCapability.promise;
  }
  return @transformStreamDefaultControllerPerformTransform(controller, chunk);
})
