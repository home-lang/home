import assert from 'node:assert/strict'
import * as fs from 'node:fs'
import {getEventListeners} from 'node:events'
import {setTimeout as delay,setImmediate as immediate,setInterval as interval} from 'node:timers/promises'
import {tmpdir} from 'node:os'
import {join} from 'node:path'
assert.equal(delay.length,2);assert.equal(interval.length,2);assert.equal(immediate.length,1)
const directory=fs.mkdtempSync(join(tmpdir(),'home-protected-abort-'))
try {
 const reason=new Error('ordinary cancellation')
 for(const make of [signal=>delay(30,'timeout',{signal}),signal=>immediate('immediate',{signal}),signal=>interval(30,'interval',{signal}).next()]){
  const controller=new AbortController();controller.signal.addEventListener('abort',event=>event.stopImmediatePropagation())
  const baseline=getEventListeners(controller.signal,'abort').length
  const promise=make(controller.signal);controller.abort(reason)
  await assert.rejects(promise,error=>error.name==='AbortError'&&error.cause===reason)
  assert.equal(getEventListeners(controller.signal,'abort').length,baseline)
 }
 const controller=new AbortController();controller.signal.addEventListener('abort',event=>event.stopImmediatePropagation())
 const baseline=getEventListeners(controller.signal,'abort').length
 const watcher=fs.promises.watch(directory,{signal:controller.signal,persistent:false});const next=watcher.next();controller.abort(reason)
 let timer
 try {await assert.rejects(Promise.race([next,new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Error('watch abort did not settle')),300)})]),error=>error.name==='AbortError'&&error.cause===reason)}finally{clearTimeout(timer)}
 assert.equal(getEventListeners(controller.signal,'abort').length,baseline)
 const seq=interval(5,'tick');assert.strictEqual(seq[Symbol.asyncIterator](),seq)
 const first=seq.next(),second=seq.next();assert.deepEqual(await first,{value:'tick',done:false});assert.deepEqual(await second,{value:'tick',done:false});assert.deepEqual(await seq.return(),{value:undefined,done:true});assert.deepEqual(await seq.next(),{value:undefined,done:true})
 console.log('protected watcher and timer cancellation, listener cleanup and terminal interval iteration passed')
}finally{fs.rmSync(directory,{recursive:true,force:true})}
