import assert from 'node:assert/strict'
import {spawnSync} from 'node:child_process'
import * as fs from 'node:fs'
import {tmpdir} from 'node:os'
import {join} from 'node:path'
const directory=fs.realpathSync(fs.mkdtempSync(join(tmpdir(),'home-filehandle-gc-'))),path=join(directory,'file');fs.writeFileSync(path,'ordinary')
const warnings=[];const onWarning=warning=>{if(warning.message.includes('FileHandle'))warnings.push(warning.message)}
process.on('warning',onWarning)
const descriptors=()=>(()=>{const result=spawnSync('/usr/sbin/lsof',['-a','-p',String(process.pid),'-Fn',path],{encoding:'utf8'});assert.equal(result.signal,null);assert.ok(result.status===0||result.status===1);return result.stdout.split('\n').filter(line=>line==='n'+path)})()
try {
 async function abandon(){await fs.promises.open(path,'r')}
 await abandon();assert.equal(descriptors().length,1)
 const gc=globalThis.Bun?.gc??globalThis.gc;assert.equal(typeof gc,'function')
 for(let i=0;i<5&&descriptors().length;i++){await new Promise(resolve=>setImmediate(resolve));gc(true);await new Promise(resolve=>setImmediate(resolve))}
 assert.equal(descriptors().length,0)
 await new Promise(resolve=>setImmediate(resolve));assert.equal(warnings.length,1)
 console.log('unreferenced native FileHandle descriptor closes during GC and reports one warning')
}finally{process.removeListener('warning',onWarning);fs.rmSync(directory,{recursive:true,force:true})}
