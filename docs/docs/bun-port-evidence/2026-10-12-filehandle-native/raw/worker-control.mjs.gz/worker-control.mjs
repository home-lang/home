import assert from 'node:assert/strict'
import {spawnSync} from 'node:child_process'
import * as fs from 'node:fs'
import {Worker} from 'node:worker_threads'
import {tmpdir} from 'node:os'
import {join} from 'node:path'
const directory=fs.realpathSync(fs.mkdtempSync(join(tmpdir(),'home-filehandle-worker-'))),path=join(directory,'file');fs.writeFileSync(path,'ordinary')
const descriptors=()=>(()=>{const result=spawnSync('/usr/sbin/lsof',['-a','-p',String(process.pid),'-Fn',path],{encoding:'utf8'});assert.equal(result.signal,null);assert.ok(result.status===0||result.status===1);return result.stdout.split('\n').filter(line=>line==='n'+path)})()
try {
 const worker=new Worker(`const fs=require('node:fs');const {parentPort,workerData}=require('node:worker_threads');(async()=>{globalThis.handle=await fs.promises.open(workerData,'r');parentPort.on('message',()=>{});parentPort.postMessage({id:handle.getAsyncId(),fd:handle.fd})})()`,{eval:true,workerData:path})
 const message=await new Promise((resolve,reject)=>{worker.once('message',resolve);worker.once('error',reject)})
 assert.ok(Number.isSafeInteger(message.id)&&message.id>0);assert.ok(message.fd>=0);assert.equal(descriptors().length,1)
 await worker.terminate();assert.equal(descriptors().length,0)
 console.log('worker shutdown retires its retained native FileHandle descriptor')
}finally{fs.rmSync(directory,{recursive:true,force:true})}
