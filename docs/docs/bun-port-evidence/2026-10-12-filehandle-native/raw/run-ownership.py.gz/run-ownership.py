from pathlib import Path
import subprocess,os,json,sys
root=Path.cwd();p=root/'zig-out/filehandle-native-port-2026-10-12'
assert 'Build Summary: 54/54 steps succeeded' in (p/'build-owned-open.log').read_text()
rows=[]
for file in ['gc-control.mjs','worker-control.mjs']:
 with (p/(file+'.log')).open('wb') as log:r=subprocess.run([str(root/'zig-out/bin/home'),'run',str(p/file)],cwd=root,env=os.environ.copy(),stdout=log,stderr=subprocess.STDOUT,timeout=240)
 rows.append({'file':file,'exit':r.returncode});print(file,r.returncode,flush=True)
(p/'ownership-summary.json').write_text(json.dumps(rows,indent=2)+'\n');sys.exit(0 if all(x['exit']==0 for x in rows) else 1)
