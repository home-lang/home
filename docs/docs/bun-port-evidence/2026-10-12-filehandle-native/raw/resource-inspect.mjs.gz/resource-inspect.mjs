import {createHook,AsyncResource} from 'node:async_hooks'
import * as fs from 'node:fs'
import {tmpdir} from 'node:os'
import {join} from 'node:path'
const dir=fs.mkdtempSync(join(tmpdir(),'home-filehandle-resource-')),path=join(dir,'file');fs.writeFileSync(path,'abc')
const records=[];const objects=new Map();const hook=createHook({init(id,type,trigger,resource){if(type==='FILEHANDLE'||type==='FILEHANDLECLOSEREQ'){records.push(['init',id,type,trigger,resource.constructor.name]);objects.set(id,resource)}},before(id){if(objects.has(id))records.push(['before',id])},after(id){if(objects.has(id))records.push(['after',id])},destroy(id){if(objects.has(id))records.push(['destroy',id])}}).enable()
try {
 const outer=new AsyncResource('open-owner');const handle=await outer.runInAsyncScope(()=>fs.promises.open(path,'r'))
 const id=handle.getAsyncId();records.push(['handle',id,'sameResource',objects.get(id)===handle,'fd',objects.get(id)?.fd,'triggerExpected',outer.asyncId()])
 await handle.read(Buffer.alloc(1));records.push(['idAfterRead',handle.getAsyncId()]);await handle.close();records.push(['idAfterClose',handle.getAsyncId()]);await new Promise(resolve=>setImmediate(resolve));outer.emitDestroy()
}finally{hook.disable();fs.rmSync(dir,{recursive:true,force:true});console.log(JSON.stringify(records,null,2))}
