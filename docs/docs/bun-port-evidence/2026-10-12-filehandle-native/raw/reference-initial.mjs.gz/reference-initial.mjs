import assert from 'node:assert/strict'
import {createHook,AsyncResource} from 'node:async_hooks'
import * as fs from 'node:fs'
import {tmpdir} from 'node:os'
import {join} from 'node:path'
const dir=fs.mkdtempSync(join(tmpdir(),'home-filehandle-native-')),path=join(dir,'file');fs.writeFileSync(path,'abc')
const handles=new Map(),closes=new Map(),before=new Set(),after=new Set(),destroyed=new Set()
const hook=createHook({init(id,type,trigger,resource){if(type==='FILEHANDLE')handles.set(id,{trigger,resource});if(type==='FILEHANDLECLOSEREQ')closes.set(id,resource)},before(id){if(closes.has(id))before.add(id)},after(id){if(closes.has(id))after.add(id)},destroy(id){if(closes.has(id))destroyed.add(id)}}).enable()
try {
 const outer=new AsyncResource('open-owner')
 const handle=await outer.runInAsyncScope(()=>fs.promises.open(path,'r'))
 const id=handle.getAsyncId();assert.ok(Number.isSafeInteger(id)&&id>0)
 assert.equal(handles.get(id).trigger,0);assert.notEqual(handles.get(id).resource,handle);assert.equal(handles.get(id).resource.fd,handle.fd)
 await handle.read(Buffer.alloc(1));assert.equal(handle.getAsyncId(),id)
 await handle.close();assert.equal(handle.getAsyncId(),id);assert.equal(handles.get(id).resource.fd,-1)
 await new Promise(resolve=>setImmediate(resolve))
 assert.equal(closes.size,1);const closeId=[...closes.keys()][0];assert(before.has(closeId));assert(after.has(closeId));assert(destroyed.has(closeId))
 const second=await fs.promises.open(path,'r');assert.notEqual(second.getAsyncId(),id);await second.close();outer.emitDestroy()
 console.log('owned FileHandle identity, descriptor retirement and native close lifecycle passed')
}finally{hook.disable();fs.rmSync(dir,{recursive:true,force:true})}
