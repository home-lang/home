from pathlib import Path
import json,gzip,hashlib,subprocess,sys,re
root=Path(__file__).resolve().parents[2];task=Path(__file__).resolve().parent;base=root/'docs/docs/bun-port-evidence/2026-10-10-sqlite-sql-ffi';base.mkdir(parents=True,exist_ok=True)
counts={};reports=[]
for path in sorted((task/'final').glob('validate-*.json')):
 data=json.loads(path.read_text());assert data['successful'],path
 for key,value in data['summary'].items():
  if isinstance(value,int):counts[key]=counts.get(key,0)+value
 reports.append(path.name)
assert len(reports)==9
records=[]
def add(path,name):
 data=path.read_bytes();target=base/(name+'.gz');target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(gzip.compress(data,mtime=0));assert gzip.decompress(target.read_bytes())==data;records.append({'path':str(target.relative_to(base)),'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
for p in sorted(task.rglob('*')):
 if not p.is_file() or (p.name.startswith('issue-') or p.name=='archive-production.log') or 'manual-fixture' in p.parts or 'obsolete-cache-manifests' in p.parts:continue
 if p.suffix in ['.log','.json','.jsonl','.py','.stdout','.stderr','.xml']:
  add(p,'raw/'+str(p.relative_to(task)))
for name in json.loads((task/'ported-files.json').read_text()):add(root/'packages/runtime/upstream/src'/name,'source/packages/runtime/upstream/src/'+name)
for name in ['build-support/bundle-native-modules.ts','build-support/bundle-native-modules.test.ts','build-support/native_bindings.zig','build.zig','src/main.zig','tests/runtime/native-node-core-cli.test.mjs']:add(root/name,'source/'+name)
manifest={'schema':1,'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'upstream':'4982b91e3702094330f3be3883354c52b8c01323','platform':'Darwin arm64','results':{'original_files':9,'counts':counts,'native_regression_groups':8,'debug_steps':35,'debug_peak_tree_mb':5641,'conformance_peak_tree_mb':793},'features':['Nine connected SQL/SQLite/FFI registry modules execute from Home-owned generation.','SQLite statement binding compiles as a Home-owned standalone object; native FFI class compiles in the owned unity graph. Both headers participate in exact ABI and cache validation.','Fifteen selected implementation/header files match the Bun source pin exactly.','Obsolete corpus filename bypass is removed: corpus files execute through the full-VM coordinator with complete journals; explicit child VM dispatch remains intact.'],'limitations':['The initial SQLite files exited successfully through the legacy direct-VM route but produced no journal; those attempts receive no verified corpus credit.','Disk-guard stops/refusals, obsolete-cache cleanup, and the test-side environment mistake are retained without final passing credit.','Ten upstream FFI skips remain separate. PostgreSQL/MySQL live-service, wider SQL/FFI behavior, remaining native/module ownership, full Bun suite and Release/ASAN/all-platform parity are not established by this checkpoint.'],'files':records}
(base/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(len(records),'verified archives',counts)
