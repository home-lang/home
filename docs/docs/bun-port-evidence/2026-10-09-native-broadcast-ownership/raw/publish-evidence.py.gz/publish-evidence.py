from pathlib import Path
import gzip,hashlib,json,subprocess
root=Path(__file__).resolve().parents[2]
source=root/'zig-out/broadcast-port-2026-10-09'
dest=root/'docs/docs/bun-port-evidence/2026-10-09-native-broadcast-ownership'
dest.mkdir(parents=True,exist_ok=True)
files=[]
def retain(data,relative):
 target=dest/(relative+'.gz');target.parent.mkdir(parents=True,exist_ok=True)
 target.write_bytes(gzip.compress(data,mtime=0))
 files.append({'path':str(target.relative_to(dest)),'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
for p in sorted(source.rglob('*')):
 if p.is_file() and p.name not in ('home-parent','home-before-main-update') and p.suffix in ('.log','.json','.jsonl','.xml','.txt','.py','.stdout','.stderr'):
  retain(p.read_bytes(),'raw/'+str(p.relative_to(source)))
tracked=['build.zig','build-support/native_bindings.zig','build-support/bundle-native-modules.ts','build-support/bundle-native-modules.test.ts']
for name in ['BroadcastChannel','BunBroadcastChannelRegistry','JSBroadcastChannel','MessageEvent','JSMessageEvent']:
 for ext in ['cpp','h']: tracked.append('packages/runtime/upstream/src/jsc/bindings/webcore/'+name+'.'+ext)
for relative in tracked:
 retain((root/relative).read_bytes(),'source/'+relative)
manifest={'schema':1,'upstream':'4982b91e3702094330f3be3883354c52b8c01323','source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'platform':'Darwin arm64','description':'Native binding ownership and scoped runtime execution evidence. Original failed attempts and case/process accounting remain separate. This is not whole-suite parity or independent ownership of all native dependencies.','results':json.loads((source/'rebased/validated-totals.json').read_text()),'files':files}
(dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for row in files:
 data=gzip.decompress((dest/row['path']).read_bytes());assert hashlib.sha256(data).hexdigest()==row['sha256']
print(json.dumps({'files':len(files),'destination':str(dest)}))
