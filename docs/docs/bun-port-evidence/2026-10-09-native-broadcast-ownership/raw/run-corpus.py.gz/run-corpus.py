from pathlib import Path
import hashlib,json,os,subprocess,sys,time
root=Path(__file__).resolve().parents[2]
out=root/'zig-out/broadcast-port-2026-10-09'
if len(sys.argv)>1: out=out/sys.argv[1]
out.mkdir(parents=True,exist_ok=True)
files=['js/web/atomics.test.ts','regression/issue/atomics-waitasync-wtftimer-uaf.test.ts','js/node/test/parallel/test-atomics-wake.js','js/web/broadcastchannel/broadcast-channel.test.ts','js/web/broadcastchannel/broadcast-channel-worker-gc.test.ts','js/web/broadcastchannel/message-event-init-gc.test.ts']
exe=root/'zig-out/bin/home'
records=[]
for index,name in enumerate(files):
 env=os.environ.copy()
 for key in ('HOME_NATIVE_VM','HOME_CORPUS_FULL_VM','HOME_NATIVE_RUN'):
  env.pop(key,None)
 env['BUN_DEBUG_QUIET_LOGS']='1'
 report=out/f'corpus-{index+1}'
 env['HOME_BUN_CORPUS_REPORT_DIR']=str(report)
 cmd=[str(exe),'test',str(root/'packages/runtime/test/test'/name)]
 begin=time.monotonic()
 with (out/f'corpus-{index+1}.log').open('wb') as log:
  result=subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 with (out/f'validate-{index+1}.json').open('wb') as log:
  validation=subprocess.run([sys.executable,str(root/'scripts/summarize-bun-corpus.py'),str(report)],cwd=root,stdout=log,stderr=subprocess.STDOUT)
 records.append({'file':name,'command':cmd,'exit_code':result.returncode,'validation_exit_code':validation.returncode,'seconds':round(time.monotonic()-begin,3),'report':str(report)})
 print(name,result.returncode,validation.returncode,flush=True)
(out/'corpus-summary.json').write_text(json.dumps({'executable_sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'records':records},indent=2)+'\n')
sys.exit(0 if all(r['exit_code']==0 and r['validation_exit_code']==0 for r in records) else 1)
