from pathlib import Path
import json,os,subprocess,sys,time
root=Path(__file__).resolve().parents[2]
out=root/'zig-out/broadcast-port-2026-10-09'
if len(sys.argv)>1: out=out/sys.argv[1]
out.mkdir(parents=True,exist_ok=True)
zig=root/'zig-out/toolchains/zig-aarch64-macos-0.17.0-dev.2163+89ff10d56/zig'
commands=[('binding-tests',[str(zig),'test','build-support/native_bindings.zig','-fstrip','-OReleaseFast']),('generator-final',['bun','test','build-support/bundle-native-modules.test.ts','build-support/native_module_abi.test.ts'])]
files=['native-worker-message-presence.test.mjs','native-worker-inbox-shutdown.test.mjs','native-worker-close-events.test.mjs','native-worker-pending-close.test.mjs','native-worker-parent-port.test.mjs','native-worker-nested-shutdown.test.mjs']
commands += [(name,[str(root/'zig-out/bin/home'),'run',str(root/'tests/runtime'/name)]) for name in files]
records=[]
env=os.environ.copy();env.update(HOME_NATIVE_VM='1',BUN_DEBUG_QUIET_LOGS='1')
for label,command in commands:
 begin=time.monotonic()
 with (out/(label+'.log')).open('wb') as log:
  result=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 records.append({'label':label,'command':command,'exit_code':result.returncode,'seconds':round(time.monotonic()-begin,3)})
 print(label,result.returncode,flush=True)
(out/'checks-summary.json').write_text(json.dumps(records,indent=2)+'\n')
sys.exit(0 if all(r['exit_code']==0 for r in records) else 1)
