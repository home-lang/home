import assert from 'node:assert/strict';
import {AsyncLocalStorage} from 'node:async_hooks';
import {EventEmitter,EventEmitterAsyncResource} from 'node:events';
const captureEmitter = new EventEmitter({ captureRejections: true })
const capturedErrors = []
captureEmitter.on('error', error => capturedErrors.push(error))
const getterError = new Error('ordinary then getter failure')
captureEmitter.on('getter', () => ({ get then() { throw getterError } }))
assert.equal(captureEmitter.emit('getter'), true)
assert.deepEqual(capturedErrors, [getterError])
captureEmitter.on('value', () => ({ then: 42 }))
assert.equal(captureEmitter.emit('value'), true)
assert.deepEqual(capturedErrors, [getterError])
let thenReads = 0
let thenReceiver
const thenableError = new Error('ordinary thenable rejection')
const thenable = { get then() { thenReads++; return function (fulfilled, rejected) { thenReceiver = this; rejected(thenableError) } } }
captureEmitter.on('thenable', () => thenable)
assert.equal(captureEmitter.emit('thenable'), true)
await new Promise(resolve => setImmediate(resolve))
assert.equal(thenReads, 1)
assert.equal(thenReceiver, thenable)
assert.deepEqual(capturedErrors, [getterError, thenableError])
const emitterStore = new AsyncLocalStorage()
const scopedEmitter = emitterStore.run('emitter-created', () => new EventEmitterAsyncResource({ name: 'home-event-resource' }))
scopedEmitter.on('ordinary', function (value) {
  assert.equal(this, scopedEmitter)
  assert.equal(emitterStore.getStore(), 'emitter-created')
  assert.equal(value, 7)
})
assert.equal(emitterStore.run('caller', () => scopedEmitter.emit('ordinary', 7)), true)
assert.equal(scopedEmitter.emit('missing'), false)
assert.equal(emitterStore.getStore(), undefined)
scopedEmitter.emitDestroy()
emitterStore.disable()
console.log('native event thenable capture and async resource emit results passed')
