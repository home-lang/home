from pathlib import Path
import os,subprocess,json,sys
root=Path.cwd();task=root/'zig-out/ipc-adoption-port-2026-10-09';commands=[
('native-first',['env','HOME_NATIVE_VM=1','BUN_DEBUG_QUIET_LOGS=1',str(root/'zig-out/bin/home'),'run',str(root/'tests/runtime/native-spawn-sync-ipc.test.mjs')]),
('corpus-first',[sys.executable,str(task/'run-corpus.py'),'first']),
('abi-first',['bun','test','build-support/bundle-native-modules.test.ts','build-support/native_module_abi.test.ts','build-support/core_builtin_abi.test.ts']),
]
results=[]
for label,command in commands:
 with (task/(label+'.log')).open('wb') as log:result=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT)
 results.append({'label':label,'command':command,'exit':result.returncode});print(label,result.returncode,flush=True)
 if result.returncode!=0:break
(task/'verification-first-summary.json').write_text(json.dumps(results,indent=2)+'\n')
sys.exit(0 if len(results)==len(commands) and all(row['exit']==0 for row in results) else 1)
