from pathlib import Path
import subprocess,json,os
root=Path.cwd();task=root/'zig-out/ipc-adoption-port-2026-10-09';results=[]
for mode in ['native-udp','dgram-fd','ipc-udp','tcp-zero','tcp-getter']:
 with (task/f'candidate-first-{mode}.log').open('wb') as log:
  result=subprocess.run(['node',str(root/'tests/runtime/fixtures/fd-adoption-peer.js'),str(task/'candidate-first/home'),mode],stdout=log,stderr=subprocess.STDOUT,cwd=root)
 results.append({'mode':mode,'exit':result.returncode});print(mode,result.returncode,flush=True)
(task/'candidate-first-summary.json').write_text(json.dumps(results,indent=2)+'\n')
