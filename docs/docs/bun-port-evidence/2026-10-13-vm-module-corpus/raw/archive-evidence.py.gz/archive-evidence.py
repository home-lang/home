from pathlib import Path
import json,hashlib,gzip,subprocess
src=Path(__file__).resolve().parent;root=src.parents[1];dst=root/'docs/docs/bun-port-evidence/2026-10-13-vm-module-corpus';artifacts=[]
for f in sorted(src.rglob('*')):
 if not f.is_file() or f.suffix=='.ips':continue
 rel=f.relative_to(src);data=f.read_bytes();target=dst/'raw'/Path(str(rel)+'.gz');target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(gzip.compress(data,mtime=0));artifacts.append({'path':str(target.relative_to(dst)),'source':str(rel),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
phases={}
for phase in ['', 'expanded','errors','first-build-results','verified','merged']:
 p=src/phase;rows=json.loads((p/'results.json').read_text());total={}
 for i in range(1,len(rows)+1):
  j=json.loads((p/f'validate-{i}.json').read_text())
  for k,v in j.get('summary',{}).items():
   if isinstance(v,int):total[k]=total.get(k,0)+v
 phases[phase or 'initial']={'rows':rows,'summary':total}
assert len(phases['verified']['rows'])==24 and all(r['exit']==0 and r['validation_exit']==0 for r in phases['verified']['rows'])
focused=json.loads((src/'merged/focused-results.json').read_text());assert all(r['exit']==0 for r in focused)
assert len(phases['merged']['rows'])==24 and all(r['exit']==0 and r['validation_exit']==0 for r in phases['merged']['rows'])
source_hashes=json.loads((src/'options/source-hashes.json').read_text());assert all(hashlib.sha256((root/n).read_bytes()).hexdigest()==h for n,h in source_hashes.items())
manifest={'schema':1,'source_base':'de6aea2393c626d9edeea9784d9c302f542741b7','implementation_commit':json.loads((src/'options/implementation.json').read_text())['commit'],'source_commit':json.loads((src/'merged/source.json').read_text())['source_commit'],'upstream':'4982b91e3702094330f3be3883354c52b8c01323','platform':'Darwin arm64','baseline_executable':json.loads((src/'baseline-identity.json').read_text()),'verified_executable':json.loads((src/'merged/executable.json').read_text()),'implementation_executable':json.loads((src/'verified/executable.json').read_text()),'source_hashes':source_hashes,'original_identities':json.loads((src/'pin-identities.json').read_text()),'first_build_focused':json.loads((src/'first-build-results/focused-results.json').read_text()),'phases':phases,'focused':focused,'callback_probe':json.loads((src/'lifetime/results.json').read_text()),'artifacts':artifacts,'limits':{'max_mb':3840,'build_max_mb':8192,'min_free_mb':1536,'critical_free_mb':512,'per_file_timeout_seconds':240},'full_suite_verified':False}
(dst/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for row in artifacts:
 data=gzip.decompress((dst/row['path']).read_bytes());assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
print('verified',len(artifacts),'artifact identities',phases['merged']['summary'])
