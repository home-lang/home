Tracked from #66 and #885.

The unchanged upstream `test-vm-codegen.js` fails in native Home because a partial `contextCodeGeneration` object becomes `{ strings: false, wasm: undefined }`, and the native parser rejects the undefined property instead of applying the enabled default. The same mismatch affects explicit undefined flags in `createContext` and `Script.runInNewContext`.

A Node v26.10.0 comparison also found a getter-order difference: Node reads both `strings` and `wasm` before validating their values. When `strings` returns an invalid value and the `wasm` getter throws, Home currently raises the strings type error before reading wasm.

Acceptance:
- Apply the enabled default for absent or undefined strings/wasm flags across all three VM entry points.
- Preserve false flags and reject other invalid types.
- Preserve both getter order and exception identity.
- Pass the unchanged upstream code-generation test and related module/options tests with complete native corpus reports.

The native parser fix and regression coverage are implemented locally; build and validation are in progress. Baseline executable SHA-256: `226aeb563f7a01309cdedc836e04bd23d31cbc0714025e3bdb5380d13b23cf14`, source checkpoint `de6aea2393c626d9edeea9784d9c302f542741b7`, upstream pin `4982b91e3702094330f3be3883354c52b8c01323`.
