import vm from 'node:vm'
const rows=[]
function check(name,fn){try{rows.push({name,result:fn()})}catch(e){rows.push({name,error:e.name,code:e.code,message:e.message})}}
for(const [label,run] of [['createContext',(opts)=>vm.runInContext('eval("6*7")',vm.createContext({}, {codeGeneration:opts}))],['runInNewContext',(opts)=>vm.runInNewContext('eval("6*7")',{}, {contextCodeGeneration:opts})],['Script.runInNewContext',(opts)=>new vm.Script('eval("6*7")').runInNewContext({}, {contextCodeGeneration:opts})]]){
 check(label+' undefined',()=>run({strings:undefined,wasm:undefined}))
 check(label+' strings disabled',()=>run({strings:false,wasm:undefined}))
}
const reads=[];const marker=new Error('wasm getter marker');check('getter precedence',()=>{try{vm.createContext({}, {codeGeneration:{get strings(){reads.push('strings');return 0},get wasm(){reads.push('wasm');throw marker}}})}catch(e){return {reads,marker:e===marker,error:e.name,code:e.code}}})
console.log(JSON.stringify(rows,null,2))
