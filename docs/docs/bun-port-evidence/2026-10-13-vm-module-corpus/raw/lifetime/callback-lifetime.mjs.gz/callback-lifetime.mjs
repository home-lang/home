import vm from 'node:vm'
import assert from 'node:assert/strict'
async function collect(){for(let i=0;i<20;i++){await new Promise(r=>setImmediate(r));if(globalThis.Bun)Bun.gc(true);else globalThis.gc();await new Promise(r=>setImmediate(r))}}
function droppedScript(){let script;script=new vm.Script('6*7',{importModuleDynamically:()=>{assert(script);return import('node:fs')}});script.runInThisContext();return new WeakRef(script)}
async function droppedModule(){let mod;mod=new vm.SourceTextModule('export default 42',{importModuleDynamically:()=>mod});await mod.link(()=>{});await mod.evaluate();return new WeakRef(mod)}
const script=droppedScript();const module=await droppedModule();await collect();process.stdout.write('DROPPED='+JSON.stringify({script:script.deref()!==undefined,module:module.deref()!==undefined})+'\n')
async function escaped(){let calls=0;let script=new vm.Script('()=>import("node:fs")',{importModuleDynamically:()=>{calls++;return import('node:fs')}});const fn=script.runInThisContext();script=undefined;await collect();const result=await fn();assert.equal(typeof result.readFileSync,'function');assert.equal(calls,1)}
await escaped();process.stdout.write('CALLBACK_LIFETIME_COMPLETE\n')
