import { monitorEventLoopDelay } from 'node:perf_hooks'
function create(kind) {
  let object
  if (kind === 'plain') object = {}
  else { object = monitorEventLoopDelay({ resolution: 1 }); if (kind === 'enabled') object.enable() }
  return new WeakRef(object)
}
const references = {}
for (const kind of ['plain', 'inactive', 'enabled']) references[kind] = Array.from({ length: 3 }, () => create(kind))
for (let i = 0; i < 20; i++) { await new Promise(resolve => setTimeout(resolve, 2)); Bun.gc(true) }
for (const kind of Object.keys(references)) console.log(kind, references[kind].filter(reference => reference.deref() !== undefined).length)
