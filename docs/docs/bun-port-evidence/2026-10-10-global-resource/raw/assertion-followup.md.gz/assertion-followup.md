The pinned Bun file `test/js/node/perf_hooks/perf_hooks.test.ts` asserts that global `performance.markResourceTiming()` does not throw with no arguments. The pinned native implementation was a TODO returning undefined.

Home now routes that call to actual resource creation and validates the cache mode before constructing an entry. The valid manual/global API and shared timeline conformance pass; a zero-argument call raises ERR_INTERNAL_ASSERTION, matching the local Node control. The unchanged broad Bun file therefore retains one registered failure. The call cannot both create a valid resource from absent timing/cache inputs and preserve the legacy no-op expectation.

Acceptance requires reconciling the upstream contract/assertion with real resource creation, without an argument-specific no-op, filename-dependent behavior or weakening assertions to hide a failure. Retain the existing failure until the contract is resolved.

Parents: #66, #869 and #873. This is a verification contradiction, not complete resource/fetch parity.
