A valid local control passes `ALPNProtocols: ['http/1.1']` to `node:https.createServer`, but the server constructor in `_http_server.ts` drops that option before the Bun server TLS config receives it. A trusted TLS fetch succeeds with no negotiated ALPN. The generic `node:tls` listener negotiates the same protocol, and Home now records the actual negotiated bytes in resource timing. Source checkpoint: https://github.com/home-lang/home/commit/2dd946c6a87b00d7b8dc45e5aa259b1277c1b3d9.

Complete HTTPS option normalization/forwarding and its native server ALPN selection path. Verify valid protocol lists, callback/selection behavior, reconfiguration and connection reuse with ordinary local TLS conformance. Do not fabricate an ALPN result or disable certificate verification to make the control pass.

Parents: #873, #869, #532 and #66. Current resource timing correctly leaves `nextHopProtocol` unset when no protocol is negotiated.
