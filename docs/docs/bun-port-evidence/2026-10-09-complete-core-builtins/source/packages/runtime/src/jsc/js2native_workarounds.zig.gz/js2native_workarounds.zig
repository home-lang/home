// Real implementations for the `$zig(...)`/`@lazy(id)` JS2Native bindings that
// the embedded node/bun JS modules call. Bun's codegen normally emits these
// C-ABI thunks (generated_js2native.rs); Home links Bun's compiled JS + the C++
// dispatch (GeneratedJS2Native / callJS2Native), which declares each thunk as an
// `extern "C"` the Zig side must provide. `native_stubs.zig` satisfies the rest
// with `noop` — so e.g. `fs = @lazy(53)` (→ callJS2Native(53) →
// node_fs_binding.createBinding) returned undefined and node:fs/node:fs.promises
// crashed at `fs.readFile.bind(fs)`. These export the real functions.
//
// SCOPE: only binding modules that currently compile in Home are wired here
// (fs/util/net/assert/zlib/types/Stat). os/crypto/cluster/http need the bindgen
// `bun.gen` subsystem and/or have unported gaps, so they stay noop in
// native_stubs.zig until those land. Gated behind enable_jsc (imported from
// home.zig's enable_jsc block) — the dispatch only exists in the JSC build.
//
// Two thunk shapes (see GeneratedJS2Native.h):
//   * Lazy bindings  — `..._workaround(*GlobalObject) -> EncodedJSValue`
//   * Host functions — `...(*GlobalObject, *CallFrame) -> EncodedJSValue`
//     (the standard JSHostFn shape; wrapped via toJSHostFn for JSError handling)

const bun = @import("home");
const jsc = bun.jsc;
const JSGlobalObject = jsc.JSGlobalObject;
const JSValue = jsc.JSValue;
const host_fn = @import("./host_fn.zig");
const headers_jsc = @import("../http_jsc/headers_jsc.zig");
const vm_exports = @import("./virtual_machine_exports.zig");
const FileSink = @import("../runtime/webcore/FileSink.zig");
const event_loop = @import("./event_loop.zig");
const ipc = @import("./ipc.zig");

const node_os = @import("../runtime/node/node_os.zig");
const node_fs_binding = @import("../runtime/node/node_fs_binding.zig");
const node_assert_binding = @import("../runtime/node/node_assert_binding.zig");
const node_net_binding = @import("../runtime/node/node_net_binding.zig");
const node_zlib_binding = @import("../runtime/node/node_zlib_binding.zig");
const node_util_binding = @import("../runtime/node/node_util_binding.zig");
const node_crypto_binding = @import("../runtime/node/node_crypto_binding.zig");
const node_http_binding = @import("../runtime/node/node_http_binding.zig");
const node_parse_args = @import("../runtime/node/util/parse_args.zig");
const Timer = @import("../runtime/timer/Timer.zig");
const dns = @import("../runtime/dns_jsc/dns.zig");
const node_cluster_binding = @import("../runtime/node/node_cluster_binding.zig");
const socket = @import("../runtime/socket/socket.zig");
const udp_socket = @import("../runtime/socket/udp_socket.zig");
const h2_frame_parser = @import("../runtime/api/bun/h2_frame_parser.zig");
const Listener = @import("../runtime/socket/Listener.zig");
const ffi = @import("../runtime/ffi/ffi.zig");
const fetch = @import("../runtime/webcore/fetch.zig");
const sql_postgres = @import("../sql_jsc/postgres.zig");
const sql_mysql = @import("../sql_jsc/mysql.zig");
const node_types = @import("../runtime/node/types.zig");
const Stat = @import("../runtime/node/Stat.zig");
const error_jsc = @import("../sys_jsc/error_jsc.zig");
const secure_context = @import("../runtime/api/bun/SecureContext.zig");
const BunObject = @import("../runtime/api/BunObject.zig");
const shell = @import("../runtime/shell/shell.zig");
const NodeModuleModule = @import("NodeModuleModule.zig");
const escapeRegExp = @import("../string/escapeRegExp.zig");
const bun_string_jsc = @import("bun_string_jsc.zig");
const IniTestingAPIs = @import("../install_jsc/ini_jsc.zig").IniTestingAPIs;
const InternalSourceMapTestingAPIs = @import("../sourcemap_jsc/internal_jsc.zig").TestingAPIs;
const hosted_git_info_jsc = @import("../install_jsc/hosted_git_info_jsc.zig");
const npm_jsc = @import("../install_jsc/npm_jsc.zig");
const PatchTestingAPIs = @import("../patch_jsc/testing.zig").TestingAPIs;
const css_internals = @import("../css_jsc/css_internals.zig");
const FrameworkRouter = @import("../runtime/bake/FrameworkRouter.zig");
const DevServer = @import("../runtime/bake/DevServer.zig");
const pack_command = @import("../runtime/cli/pack_command.zig");
const upgrade_command = @import("../runtime/cli/upgrade_command.zig");

/// Real Zig dispatch for `$.braces(...)`. The pinned-obj C++ wrapper
/// `bindgen_BunObject_jsBraces` marshals JS args, then calls this. native_stubs
/// had noop-stubbed it, so `$.braces(...)` returned garbage (the noop leaves the
/// return register holding globalThis). Mirrors the pin's generated dispatch
/// (GeneratedBindings.zig): forward to `BunObject.braces` via `toJSHostCall`,
/// which turns a thrown JSError into `.zero`. `BracesOptions` layout is the
/// hand-mirror in runtime/node/GeneratedBindings.zig (`bun.gen.BunObject`).
fn bindgen_BunObject_dispatchBraces1_impl(
    global: *JSGlobalObject,
    input: *const bun.String,
    options: *const bun.gen.BunObject.BracesOptions,
) callconv(.c) JSValue {
    return jsc.toJSHostCall(global, @src(), BunObject.braces, .{ global, input.*, options.* });
}

/// Real Zig dispatch for `Bun.gc(force)`. The pinned-obj C++ wrapper
/// `bindgen_BunObject_jsGc` passes `&force` in and `&out` for the heap size,
/// then encodes `out` as the JS return. native_stubs noop-stubbed this, so the
/// out-param was never written — `Bun.gc()` returned uninitialized stack garbage
/// (a pointer-sized number) instead of the reported heap size. Mirrors the pin.
fn bindgen_BunObject_dispatchGc1_impl(
    global: *JSGlobalObject,
    arg_force: *const bool,
    out: *usize,
) callconv(.c) bool {
    out.* = BunObject.gc(global.bunVM(), arg_force.*);
    return true;
}

/// Real Bake teardown counter used by the pinned dev-server harness. The C++
/// bindgen wrapper passes an out pointer for the usize result.
fn bindgen_DevServer_dispatchGetDeinitCountForTesting1_impl(
    _: *JSGlobalObject,
    out: *usize,
) callconv(.c) bool {
    out.* = DevServer.getDeinitCountForTesting();
    return true;
}

/// Real Zig dispatch for `Module._stat(path)` (node:module). The pinned-obj C++
/// wrapper `bindgen_NodeModuleModule_js_stat` passes `&path` in and `&out` (i32)
/// for the result (0=file, 1=dir, -1=missing). native_stubs noop-stubbed this,
/// so the out-param was never written — `Module._stat(...)` returned garbage,
/// which the CJS resolver reads as a bogus file/dir kind. Mirrors the pin.
fn bindgen_NodeModuleModule_dispatch_stat1_impl(
    _: *JSGlobalObject,
    arg_str: *const bun.String,
    out: *i32,
) callconv(.c) bool {
    const utf8 = arg_str.toUTF8(bun.default_allocator);
    defer utf8.deinit();
    out.* = NodeModuleModule._stat(utf8.slice());
    return true;
}

// The bindgen `Formatter` string-enum. VALUES must match the pin's generated
// GeneratedBindings.zig `Formatter` exactly, because the linked pin C++
// (`bindgen_Fmt_jsc_jsFmtString`) marshals the JS string arg to those numeric
// values before calling the dispatch below:
//
//     pub const Formatter = enum(u8) {
//         escape_powershell,             // 0
//         highlight_javascript,          // 1
//         highlight_javascript_redacted, // 2
//     };
//
// confirmed against both ~/Code/bun/src/jsc/bindings/GeneratedBindings.zig and
// the Rust mirror in src/jsc/fmt_jsc.rs. Note the declaration order in
// src/jsc/fmt_jsc.bind.ts differs from the generated order — the generated one
// is what the ABI uses.
//
// `highlight_javascript_redacted` was missing here, so `escapePowershell`
// (which marshals to 2) switched on a value outside the enum and killed the
// process with "panic: switch on corrupt value". (Home's jsc/fmt_jsc.zig
// declares its own Formatter for name-locking tests — do NOT reuse it here;
// only the C-ABI value matters.)
const FmtFormatter = enum(u8) {
    escape_powershell = 0,
    highlight_javascript = 1,
    highlight_javascript_redacted = 2,
};

fn fmtStringImpl(global: *JSGlobalObject, code: []const u8, formatter: FmtFormatter) bun.JSError!bun.String {
    var buffer = bun.MutableString.initEmpty(bun.default_allocator);
    defer buffer.deinit();
    var w = buffer.bufferedWriter();
    switch (formatter) {
        .highlight_javascript => {
            const f = bun.fmt.fmtJavaScript(code, .{ .enable_colors = true });
            w.writer().print("{f}", .{f}) catch |err| return global.throwError(err, "while formatting");
        },
        // Same highlighter with redaction requested, mirroring the pin's
        // `Formatter::HighlightJavascriptRedacted` arm.
        .highlight_javascript_redacted => {
            const f = bun.fmt.fmtJavaScript(code, .{ .enable_colors = true, .redact_sensitive_information = true });
            w.writer().print("{f}", .{f}) catch |err| return global.throwError(err, "while formatting");
        },
        // Inlined `bun_core/fmt.zig`'s escapePowershellImpl (prefix `"` and `` ` ``
        // with a backtick) — self-contained, avoids importing the whole file.
        .escape_powershell => {
            var remain = code;
            while (bun.strings.indexOfAny(remain, "\"`")) |i| {
                w.writer().print("{s}`{s}", .{ remain[0..i], remain[i .. i + 1] }) catch |err| return global.throwError(err, "while formatting");
                remain = remain[i + 1 ..];
            }
            w.writer().print("{s}", .{remain}) catch |err| return global.throwError(err, "while formatting");
        },
    }
    w.flush() catch |err| return global.throwError(err, "while formatting");
    return bun.String.cloneUTF8(buffer.list.items);
}

/// Real Zig dispatch for `fmtString` (bun:internal-for-testing `highlightJavaScript`
/// / `escapePowershell`). The pinned-obj C++ wrapper `bindgen_Fmt_jsc_jsFmtString`
/// marshals (code, formatter) and calls this. native_stubs noop-stubbed it, so the
/// out-param was never written. Mirrors the pin's generated dispatch.
fn bindgen_Fmt_jsc_dispatchFmtString1_impl(
    arg_global: *JSGlobalObject,
    arg_code: *const bun.String,
    arg_formatter: *const FmtFormatter,
    out: *bun.String,
) callconv(.c) bool {
    const code_utf8 = arg_code.toUTF8(bun.default_allocator);
    defer code_utf8.deinit();
    // On error the pending JS exception is already set (fmtStringImpl routes every
    // failure through global.throwError / throwOutOfMemory); signal failure via the
    // bool return, matching the pin's dispatch contract.
    out.* = fmtStringImpl(arg_global, code_utf8.slice(), arg_formatter.*) catch {
        return false;
    };
    return true;
}

const jsFmtString = @extern(*const host_fn.JSHostFn, .{ .name = "bindgen_Fmt_jsc_jsFmtString" });
const jsGetDevServerDeinitCount = @extern(*const host_fn.JSHostFn, .{ .name = "bindgen_DevServer_jsGetDeinitCountForTesting" });

/// Lazy binding for `$bindgenFn("fmt_jsc.bind.ts", "fmtString")` — returns the
/// `fmtString` host function. native_stubs noop-stubbed this so the JS side got
/// globalThis back ("fmtBinding is not a function"). Mirrors the pin's
/// `createFmtStringCallback`.
fn js2native_bindgen_fmt_jsc_fmtString_impl(global: *JSGlobalObject) callconv(jsc.conv) JSValue {
    return host_fn.NewRuntimeFunction(global, jsc.ZigString.static("fmtString"), 3, jsFmtString, false, null);
}

/// Creates the JavaScript function for the DevServer teardown counter. This is
/// the `$bindgenFn` factory layer above the dispatch thunk.
fn js2native_bindgen_DevServer_getDeinitCountForTesting_impl(global: *JSGlobalObject) callconv(jsc.conv) JSValue {
    return host_fn.NewRuntimeFunction(global, jsc.ZigString.static("getDeinitCountForTesting"), 0, jsGetDevServerDeinitCount, false, null);
}

/// Wrap a `fn(*GlobalObject) JSValue` lazy binding as a C-ABI thunk.
fn lazy(comptime f: fn (*JSGlobalObject) callconv(.auto) JSValue) fn (*JSGlobalObject) callconv(jsc.conv) JSValue {
    return struct {
        fn call(global: *JSGlobalObject) callconv(jsc.conv) JSValue {
            return f(global);
        }
    }.call;
}

/// Wrap a `fn(*GlobalObject) JSError!JSValue` lazy binding, surfacing a thrown
/// exception as `.zero` (faithful to toJSHostFnResult).
fn lazyErr(comptime f: fn (*JSGlobalObject) callconv(.auto) bun.JSError!JSValue) fn (*JSGlobalObject) callconv(jsc.conv) JSValue {
    return struct {
        fn call(global: *JSGlobalObject) callconv(jsc.conv) JSValue {
            return host_fn.toJSHostFnResult(global, f(global));
        }
    }.call;
}

comptime {
    @export(&host_fn.toJSHostFn(@import("./Counters.zig").createCountersObject), .{ .name = "JS2Zig___src_jsc_Counters_zig__createCountersObject" });

    // ---- bindgen dispatches (real, replacing native_stubs no-ops) -------
    @export(&bindgen_BunObject_dispatchBraces1_impl, .{ .name = "bindgen_BunObject_dispatchBraces1" });
    @export(&bindgen_BunObject_dispatchGc1_impl, .{ .name = "bindgen_BunObject_dispatchGc1" });
    @export(&bindgen_DevServer_dispatchGetDeinitCountForTesting1_impl, .{ .name = "bindgen_DevServer_dispatchGetDeinitCountForTesting1" });
    @export(&bindgen_NodeModuleModule_dispatch_stat1_impl, .{ .name = "bindgen_NodeModuleModule_dispatch_stat1" });

    // ---- fmt_jsc fmtString (bun:internal-for-testing highlightJavaScript) ----
    @export(&bindgen_Fmt_jsc_dispatchFmtString1_impl, .{ .name = "bindgen_Fmt_jsc_dispatchFmtString1" });
    @export(&js2native_bindgen_fmt_jsc_fmtString_impl, .{ .name = "js2native_bindgen_fmt_jsc_fmtString" });
    @export(&js2native_bindgen_DevServer_getDeinitCountForTesting_impl, .{ .name = "js2native_bindgen_DevServer_getDeinitCountForTesting" });

    // ---- shell TestingAPIs (bun:internal-for-testing shellInternals) ----
    // Real exports for the shell lexer/parser test hooks. native_stubs had
    // these noop-stubbed, so `shellInternals.lex/parse/disabledOnPosix` in
    // lex.test.ts / parse.test.ts returned garbage and the files were skipped.
    @export(&host_fn.toJSHostFn(shell.TestingAPIs.shellLex), .{ .name = "JS2Zig___src_runtime_shell_shell_zig__TestingAPIs_shellLex" });
    @export(&host_fn.toJSHostFn(shell.TestingAPIs.shellParse), .{ .name = "JS2Zig___src_runtime_shell_shell_zig__TestingAPIs_shellParse" });
    @export(&host_fn.toJSHostFn(shell.TestingAPIs.disabledOnThisPlatform), .{ .name = "JS2Zig___src_runtime_shell_shell_zig__TestingAPIs_disabledOnThisPlatform" });

    // ---- H2/H3 client live-count TestingAPIs (bun:internal-for-testing) --
    // Real exports for fetchH{2,3}Internals.liveCounts. native_stubs had these
    // noop-stubbed, so `liveCounts().sessions/.streams` came back undefined
    // (printed as NaN) and every h3 Alt-Svc/session-count assertion failed. The
    // real impls live in headers_jsc (moved there to keep JSC out of src/http/);
    // the JS binding still resolves the old H{2,3}Client symbol names.
    @export(&host_fn.toJSHostFn(headers_jsc.H2TestingAPIs.liveCounts), .{ .name = "JS2Zig___src_http_H_Client_zig__TestingAPIs_liveCounts" });
    @export(&host_fn.toJSHostFn(headers_jsc.H3TestingAPIs.quicLiveCounts), .{ .name = "JS2Zig___src_http_H_Client_zig__TestingAPIs_quicLiveCounts" });

    // ---- setSyntheticAllocationLimitForTesting (bun:internal-for-testing) --
    // Real impl in virtual_machine_exports; native_stubs noop'd it, so the OOM
    // tests (blob-oom, fs-oom, FormData) set no limit and never hit the
    // synthetic OOM they assert on (`.json()/.text()/.bytes() should throw`).
    @export(&host_fn.toJSHostFn(vm_exports.Bun__setSyntheticAllocationLimitForTesting), .{ .name = "JS2Zig___src_jsc_virtual_machine_exports_zig__Bun__setSyntheticAllocationLimitForTesting" });

    // ---- FileSink live-count + event-loop stats (bun:internal-for-testing) --
    // Both had real impls but were noop-stubbed: fileSinkInternals.liveCount()
    // and getEventLoopStats().activeTasks came back non-numeric, so the FileSink
    // and node:http activeTasks leak tests couldn't assert on the counts.
    @export(&host_fn.toJSHostFn(FileSink.TestingAPIs.fileSinkLiveCount), .{ .name = "JS2Zig___src_runtime_webcore_FileSink_zig__TestingAPIs_fileSinkLiveCount" });
    @export(&host_fn.toJSHostFn(event_loop.getActiveTasks), .{ .name = "JS2Zig___src_jsc_event_loop_zig__getActiveTasks" });
    @export(&host_fn.toJSHostFn(ipc.emitHandleIPCMessage), .{ .name = "JS2Zig___src_jsc_ipc_zig__emitHandleIPCMessage" });

    // ---- InternalSourceMap TestingAPIs (bun:internal-for-testing) --------
    // Real exports for the VLQ round-trip / find test hooks. native_stubs had
    // these noop-stubbed, so fromVLQ/toVLQ/find returned garbage (byteLength /
    // generatedLine came back undefined) and the roundtrip file was 0/3.
    @export(&host_fn.toJSHostFn(InternalSourceMapTestingAPIs.fromVLQ), .{ .name = "JS2Zig___src_sourcemap_InternalSourceMap_zig__TestingAPIs_fromVLQ" });
    @export(&host_fn.toJSHostFn(InternalSourceMapTestingAPIs.toVLQ), .{ .name = "JS2Zig___src_sourcemap_InternalSourceMap_zig__TestingAPIs_toVLQ" });
    @export(&host_fn.toJSHostFn(InternalSourceMapTestingAPIs.find), .{ .name = "JS2Zig___src_sourcemap_InternalSourceMap_zig__TestingAPIs_find" });

    // ---- hostedGitInfo TestingAPIs (bun:internal-for-testing) -----------
    // fromUrl/parseUrl for the npm-style git-URL parser. native_stubs noop'd
    // these, so `hostedGitInfo.fromUrl(...)` returned globalThis (from-url.test.ts
    // was 0/649).
    @export(&host_fn.toJSHostFn(hosted_git_info_jsc.jsFromUrl), .{ .name = "JS2Zig___src_install_hosted_git_info_zig__TestingAPIs_jsFromUrl" });
    @export(&host_fn.toJSHostFn(hosted_git_info_jsc.jsParseUrl), .{ .name = "JS2Zig___src_install_hosted_git_info_zig__TestingAPIs_jsParseUrl" });

    // ---- npm os/arch match TestingAPIs (bun:internal-for-testing) --------
    // isArchitectureMatch/isOperatingSystemMatch — noop'd → returned globalThis
    // (architecture-match.test.ts was 0/30).
    @export(&host_fn.toJSHostFn(npm_jsc.architectureIsMatch), .{ .name = "JS2Zig___src_install_npm_zig__Architecture_jsFunctionArchitectureIsMatch" });
    @export(&host_fn.toJSHostFn(npm_jsc.operatingSystemIsMatch), .{ .name = "JS2Zig___src_install_npm_zig__OperatingSystem_jsFunctionOperatingSystemIsMatch" });

    // ---- patch TestingAPIs (bun:internal-for-testing patchInternals) ----
    // The patch corpus exercises the real parser, applier, and `git diff
    // --no-index` generator through these host functions.
    @export(&host_fn.toJSHostFn(PatchTestingAPIs.makeDiff), .{ .name = "JS2Zig___src_patch_patch_zig__TestingAPIs_makeDiff" });
    @export(&host_fn.toJSHostFn(PatchTestingAPIs.apply), .{ .name = "JS2Zig___src_patch_patch_zig__TestingAPIs_apply" });
    @export(&host_fn.toJSHostFn(PatchTestingAPIs.parse), .{ .name = "JS2Zig___src_patch_patch_zig__TestingAPIs_parse" });

    // ---- pack tarball TestingAPI (bun:internal-for-testing readTarball) --
    // The pack corpus inspects the real archive through this host function.
    // The no-op export returned globalThis, leaving entries and digests absent.
    @export(&host_fn.toJSHostFn(pack_command.bindings.jsReadTarball), .{ .name = "JS2Zig___src_runtime_cli_pack_command_zig__bindings_jsReadTarball" });

    // ---- css_internals TestingAPIs (bun:internal-for-testing cssInternals) --
    @export(&host_fn.toJSHostFn(css_internals.minifyTest), .{ .name = "JS2Zig___src_css_jsc_css_internals_zig__minifyTest" });
    @export(&host_fn.toJSHostFn(css_internals.minifyTestWithOptions), .{ .name = "JS2Zig___src_css_jsc_css_internals_zig__minifyTestWithOptions" });
    @export(&host_fn.toJSHostFn(css_internals.minifyErrorTestWithOptions), .{ .name = "JS2Zig___src_css_jsc_css_internals_zig__minifyErrorTestWithOptions" });
    @export(&host_fn.toJSHostFn(css_internals.prefixTest), .{ .name = "JS2Zig___src_css_jsc_css_internals_zig__prefixTest" });
    @export(&host_fn.toJSHostFn(css_internals.prefixTestWithOptions), .{ .name = "JS2Zig___src_css_jsc_css_internals_zig__prefixTestWithOptions" });
    @export(&host_fn.toJSHostFn(css_internals.testWithOptions), .{ .name = "JS2Zig___src_css_jsc_css_internals_zig__testWithOptions" });
    @export(&host_fn.toJSHostFn(css_internals._test), .{ .name = "JS2Zig___src_css_jsc_css_internals_zig___test" });
    @export(&host_fn.toJSHostFn(css_internals.attrTest), .{ .name = "JS2Zig___src_css_jsc_css_internals_zig__attrTest" });

    // ---- string escapeRegExp TestingAPIs (bun:internal-for-testing) -----
    @export(&host_fn.toJSHostFn(escapeRegExp.jsEscapeRegExp), .{ .name = "JS2Zig___src_string_escapeRegExp_zig__jsEscapeRegExp" });
    @export(&host_fn.toJSHostFn(escapeRegExp.jsEscapeRegExpForPackageNameMatching), .{ .name = "JS2Zig___src_string_escapeRegExp_zig__jsEscapeRegExpForPackageNameMatching" });

    // ---- strings.toUTF16AllocSentinel TestingAPI (stringsInternals) -----
    @export(&host_fn.toJSHostFn(bun_string_jsc.UnicodeTestingAPIs.toUTF16AllocSentinel), .{ .name = "JS2Zig___src_bun_core_string_immutable_unicode_zig__TestingAPIs_toUTF__AllocSentinel" });

    // ---- ini IniTestingAPIs (iniInternals.parse / loadNpmrc) ------------
    @export(&host_fn.toJSHostFn(IniTestingAPIs.parse), .{ .name = "JS2Zig___src_ini_ini_zig__IniTestingAPIs_parse" });
    @export(&host_fn.toJSHostFn(IniTestingAPIs.loadNpmrcFromJS), .{ .name = "JS2Zig___src_ini_ini_zig__IniTestingAPIs_loadNpmrcFromJS" });

    // ---- Lazy bindings (`..._workaround`) -------------------------------
    // PackageManifest.bindings.generate backs
    // bun:internal-for-testing.npm_manifest_test_helpers. The no-op returned
    // globalThis, leaving parseManifest undefined in the real install harness.
    @export(&lazy(npm_jsc.ManifestBindings.generate), .{ .name = "JS2Zig___src_install_npm_zig__PackageManifest_bindings_generate_workaround" });
    // Bun's upgrade corpus calls these helpers on every platform. They hold an
    // exclusive temp-directory handle on Windows and are intentional no-ops on
    // POSIX; the no-op symbol stub returned no object at all on either platform.
    @export(&lazy(upgrade_command.upgrade_js_bindings.generate), .{ .name = "JS2Zig___src_runtime_cli_upgrade_command_zig__upgrade_js_bindings_generate_workaround" });
    @export(&lazyErr(node_os.createNodeOsBinding), .{ .name = "JS2Zig___src_runtime_node_node_os_zig__createNodeOsBinding_workaround" });
    // Bake's internal test API. The generated bun:internal-for-testing module
    // resolves this as a lazy binding; a no-op here made
    // `frameworkRouterInternals` undefined even though the router binding is
    // fully linked into Home.
    @export(&lazyErr(FrameworkRouter.JSFrameworkRouter.getBindings), .{ .name = "JS2Zig___src_runtime_bake_FrameworkRouter_zig__JSFrameworkRouter_getBindings_workaround" });
    @export(&lazy(node_fs_binding.createBinding), .{ .name = "JS2Zig___src_runtime_node_node_fs_binding_zig__createBinding_workaround" });
    @export(&lazy(node_assert_binding.generate), .{ .name = "JS2Zig___src_runtime_node_node_assert_binding_zig__generate_workaround" });
    @export(&lazy(node_net_binding.getDefaultAutoSelectFamily), .{ .name = "JS2Zig___src_runtime_node_node_net_binding_zig__getDefaultAutoSelectFamily_workaround" });
    @export(&lazy(node_net_binding.setDefaultAutoSelectFamily), .{ .name = "JS2Zig___src_runtime_node_node_net_binding_zig__setDefaultAutoSelectFamily_workaround" });
    @export(&lazy(node_net_binding.getDefaultAutoSelectFamilyAttemptTimeout), .{ .name = "JS2Zig___src_runtime_node_node_net_binding_zig__getDefaultAutoSelectFamilyAttemptTimeout_workaround" });
    @export(&lazy(node_net_binding.setDefaultAutoSelectFamilyAttemptTimeout), .{ .name = "JS2Zig___src_runtime_node_node_net_binding_zig__setDefaultAutoSelectFamilyAttemptTimeout_workaround" });
    @export(&lazy(node_net_binding.SocketAddress), .{ .name = "JS2Zig___src_runtime_node_node_net_binding_zig__SocketAddress_workaround" });
    @export(&lazy(node_net_binding.BlockList), .{ .name = "JS2Zig___src_runtime_node_node_net_binding_zig__BlockList_workaround" });
    @export(&lazy(node_zlib_binding.NativeZlib), .{ .name = "JS2Zig___src_runtime_node_node_zlib_binding_zig__NativeZlib_workaround" });
    @export(&lazy(node_zlib_binding.NativeBrotli), .{ .name = "JS2Zig___src_runtime_node_node_zlib_binding_zig__NativeBrotli_workaround" });
    @export(&lazy(node_zlib_binding.NativeZstd), .{ .name = "JS2Zig___src_runtime_node_node_zlib_binding_zig__NativeZstd_workaround" });
    // node:crypto binding — the embedded crypto.ts reads pbkdf2/pbkdf2Sync/
    // randomBytes/randomInt/randomFill/scrypt/timingSafeEqual/getHashes/etc.
    // from here. Was noop in native_stubs.zig, leaving them all `undefined`.
    @export(&lazy(node_crypto_binding.createNodeCryptoBindingZig), .{ .name = "JS2Zig___src_runtime_node_node_crypto_binding_zig__createNodeCryptoBindingZig_workaround" });
    // Bun.sql drivers (Postgres/MySQL) + http2 frame-parser class constructor.
    @export(&lazy(sql_postgres.createBinding), .{ .name = "JS2Zig___src_sql_jsc_postgres_zig__createBinding_workaround" });
    @export(&lazy(sql_mysql.createBinding), .{ .name = "JS2Zig___src_sql_jsc_mysql_zig__createBinding_workaround" });
    @export(&lazy(h2_frame_parser.H2FrameParserConstructor), .{ .name = "JS2Zig___src_runtime_api_bun_h__frame_parser_zig__H_FrameParserConstructor_workaround" });

    // ---- Host functions (no suffix) -------------------------------------
    @export(&host_fn.toJSHostFn(node_util_binding.normalizeEncoding), .{ .name = "JS2Zig___src_runtime_node_node_util_binding_zig__normalizeEncoding" });
    @export(&host_fn.toJSHostFn(node_util_binding.parseEnv), .{ .name = "JS2Zig___src_runtime_node_node_util_binding_zig__parseEnv" });
    @export(&host_fn.toJSHostFn(node_util_binding.internalErrorName), .{ .name = "JS2Zig___src_runtime_node_node_util_binding_zig__internalErrorName" });
    @export(&host_fn.toJSHostFn(node_util_binding.enobufsErrorCode), .{ .name = "JS2Zig___src_runtime_node_node_util_binding_zig__enobufsErrorCode" });
    @export(&host_fn.toJSHostFn(node_util_binding.etimedoutErrorCode), .{ .name = "JS2Zig___src_runtime_node_node_util_binding_zig__etimedoutErrorCode" });
    @export(&host_fn.toJSHostFn(node_util_binding.extractedSplitNewLinesFastPathStringsOnly), .{ .name = "JS2Zig___src_runtime_node_node_util_binding_zig__extractedSplitNewLinesFastPathStringsOnly" });
    @export(&host_fn.toJSHostFn(node_net_binding.newDetachedSocket), .{ .name = "JS2Zig___src_runtime_node_node_net_binding_zig__newDetachedSocket" });
    @export(&host_fn.toJSHostFn(node_net_binding.doConnect), .{ .name = "JS2Zig___src_runtime_node_node_net_binding_zig__doConnect" });
    @export(&host_fn.toJSHostFn(node_types.jsAssertEncodingValid), .{ .name = "JS2Zig___src_runtime_node_types_zig__jsAssertEncodingValid" });
    @export(&host_fn.toJSHostFn(Stat.createStatsForIno), .{ .name = "JS2Zig___src_runtime_node_Stat_zig__createStatsForIno" });
    // node:util.parseArgs + node:http maxHeaderSize get/set (were noop, so
    // util.parseArgs threw "not a function" and http.maxHeaderSize was undefined).
    @export(&host_fn.toJSHostFn(node_parse_args.parseArgs), .{ .name = "JS2Zig___src_runtime_node_util_parse_args_zig__parseArgs" });
    @export(&host_fn.toJSHostFn(node_http_binding.getMaxHTTPHeaderSize), .{ .name = "JS2Zig___src_runtime_node_node_http_binding_zig__getMaxHTTPHeaderSize" });
    @export(&host_fn.toJSHostFn(node_http_binding.setMaxHTTPHeaderSize), .{ .name = "JS2Zig___src_runtime_node_node_http_binding_zig__setMaxHTTPHeaderSize" });
    // node:http's server close path awaits this promise; without the real export
    // it was a native_stubs noop (returned undefined) and `.@then` threw, failing
    // ~60 node-http.test.ts cases at once.
    @export(&host_fn.toJSHostFn(node_http_binding.getBunServerAllClosedPromise), .{ .name = "JS2Zig___src_runtime_node_node_http_binding_zig__getBunServerAllClosedPromise" });
    // Self-contained pure-function bindings (were noop).
    @export(&host_fn.toJSHostFn(bun.String.jsGetStringWidth), .{ .name = "JS2Zig___src_string_string_zig__String_jsGetStringWidth" });
    @export(&host_fn.toJSHostFn(Timer.internal_bindings.timerClockMs), .{ .name = "JS2Zig___src_runtime_timer_Timer_zig__internal_bindings_timerClockMs" });
    // node:dns Resolver constructor + default result-order (were noop).
    @export(&host_fn.toJSHostFn(dns.Resolver.newResolver), .{ .name = "JS2Zig___src_runtime_dns_jsc_dns_zig__Resolver_newResolver" });
    @export(&host_fn.toJSHostFn(dns.Resolver.getRuntimeDefaultResultOrderOption), .{ .name = "JS2Zig___src_runtime_dns_jsc_dns_zig__Resolver_getRuntimeDefaultResultOrderOption" });
    // node:cluster IPC helpers (were noop).
    @export(&host_fn.toJSHostFn(node_cluster_binding.sendHelperChild), .{ .name = "JS2Zig___src_runtime_node_node_cluster_binding_zig__sendHelperChild" });
    @export(&host_fn.toJSHostFn(node_cluster_binding.onInternalMessageChild), .{ .name = "JS2Zig___src_runtime_node_node_cluster_binding_zig__onInternalMessageChild" });
    @export(&host_fn.toJSHostFn(node_cluster_binding.sendHelperPrimary), .{ .name = "JS2Zig___src_runtime_node_node_cluster_binding_zig__sendHelperPrimary" });
    @export(&host_fn.toJSHostFn(node_cluster_binding.onInternalMessagePrimary), .{ .name = "JS2Zig___src_runtime_node_node_cluster_binding_zig__onInternalMessagePrimary" });
    @export(&host_fn.toJSHostFn(node_cluster_binding.setRef), .{ .name = "JS2Zig___src_runtime_node_node_cluster_binding_zig__setRef" });
    @export(&host_fn.toJSHostFn(node_cluster_binding.channelIgnoreOneDisconnectEventListener), .{ .name = "JS2Zig___src_runtime_node_node_cluster_binding_zig__channelIgnoreOneDisconnectEventListener" });
    // Bun socket helpers (were noop).
    @export(&host_fn.toJSHostFn(socket.jsCreateSocketPair), .{ .name = "JS2Zig___src_runtime_socket_socket_zig__jsCreateSocketPair" });
    @export(&host_fn.toJSHostFn(socket.jsGetBufferedAmount), .{ .name = "JS2Zig___src_runtime_socket_socket_zig__jsGetBufferedAmount" });
    @export(&host_fn.toJSHostFn(socket.jsIsNamedPipeSocket), .{ .name = "JS2Zig___src_runtime_socket_socket_zig__jsIsNamedPipeSocket" });
    @export(&host_fn.toJSHostFn(socket.jsUpgradeDuplexToTLS), .{ .name = "JS2Zig___src_runtime_socket_socket_zig__jsUpgradeDuplexToTLS" });
    @export(&host_fn.toJSHostFn(socket.jsSetSocketOptions), .{ .name = "JS2Zig___src_runtime_socket_socket_zig__jsSetSocketOptions" });
    @export(&host_fn.toJSHostFn(udp_socket.UDPSocket.jsConnect), .{ .name = "JS2Zig___src_runtime_socket_udp_socket_zig__UDPSocket_jsConnect" });
    @export(&host_fn.toJSHostFn(udp_socket.UDPSocket.jsDisconnect), .{ .name = "JS2Zig___src_runtime_socket_udp_socket_zig__UDPSocket_jsDisconnect" });
    @export(&host_fn.toJSHostFn(h2_frame_parser.jsAssertSettings), .{ .name = "JS2Zig___src_runtime_api_bun_h__frame_parser_zig__jsAssertSettings" });
    @export(&host_fn.toJSHostFn(Listener.jsAddServerName), .{ .name = "JS2Zig___src_runtime_socket_Listener_zig__jsAddServerName" });
    @export(&host_fn.toJSHostFn(ffi.Bun__FFI__cc), .{ .name = "JS2Zig___src_runtime_ffi_ffi_zig__Bun__FFI__cc" });
    @export(&host_fn.toJSHostFn(fetch.nodeHttpClient), .{ .name = "JS2Zig___src_runtime_webcore_fetch_zig__nodeHttpClient" });
    @export(&host_fn.toJSHostFn(node_zlib_binding.crc32), .{ .name = "JS2Zig___src_runtime_node_node_zlib_binding_zig__crc__" });
    @export(&host_fn.toJSHostFn(node_fs_binding.createMemfdForTesting), .{ .name = "JS2Zig___src_runtime_node_node_fs_binding_zig__createMemfdForTesting" });
    // bun:internal-for-testing sys helpers. Were noop in native_stubs.zig, so
    // calling them returned `.zero` WITHOUT a pending exception — which trips
    // `toJSHostCall`'s `assertExceptionPresenceMatches` and PANICS the process
    // (translate-uv-error-windows.test.ts crashed on the first call). The real
    // impls live in error_jsc.TestingAPIs (off-Windows no-ops return undefined).
    @export(&host_fn.toJSHostFn(error_jsc.TestingAPIs.translateUVErrorToE), .{ .name = "JS2Zig___src_sys_sys_zig__TestingAPIs_translateUVErrorToE" });
    @export(&host_fn.toJSHostFn(error_jsc.TestingAPIs.sysErrorNameFromLibuv), .{ .name = "JS2Zig___src_sys_Error_zig__TestingAPIs_sysErrorNameFromLibuv" });
    // node:tls SecureContext: `NativeSecureContext = $zig("SecureContext.zig",
    // "js.getConstructor")` + the jsLiveCount churn-test helper. Were noop in
    // native_stubs → NativeSecureContext undefined → `.intern` undefined → ~80
    // node-tls tests failed.
    @export(&lazy(secure_context.js.getConstructor), .{ .name = "JS2Zig___src_runtime_api_bun_SecureContext_zig__js_getConstructor_workaround" });
    @export(&host_fn.toJSHostFn(secure_context.jsLiveCount), .{ .name = "JS2Zig___src_runtime_api_bun_SecureContext_zig__jsLiveCount" });
    // NOTE: sigactionLayout stays a native_stubs noop — its POSIX body uses
    // `home.sys.sigemptyset`, which isn't ported yet, so @export-ing it would
    // force that path to compile and fail. It has no crashing test depending on
    // it (its own test would just see undefined), unlike translateUVErrorToE.
}
