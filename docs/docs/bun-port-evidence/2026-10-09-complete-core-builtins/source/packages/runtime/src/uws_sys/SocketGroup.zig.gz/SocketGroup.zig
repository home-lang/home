// Copied from bun/src/uws_sys/SocketGroup.zig at upstream
// SHA fd0b6f1a271fca0b8124b69f230b100f4d636af6. MIT — see ../cli/LICENSE.bun.md.
//
// Imports rewritten: upstream resolves `Loop` / `SslCtx` / `us_socket_t` /
// `ListenSocket` / `us_bun_verify_error_t` / `LIBUS_SOCKET_DESCRIPTOR` via
// `bun.uws`. Home's uws_sys aggregator only exposes the QUIC subtree +
// SocketKind + ConnectingSocket today; the still-unported deps are
// forward-declared as local opaques (same pattern as ConnectingSocket.zig
// uses for `SocketGroup` and `Loop`). `ConnectingSocket` is imported as a
// sibling. `LIBUS_SOCKET_DESCRIPTOR` is a `c_int` on POSIX (`uintptr_t` on
// Windows) — Home is POSIX-only for now, so we alias to `c_int` here. The
// VTable layout is the source of truth (asserted via `comptime`), and
// matches `uws_sys/vtable.zig`'s mirror; once the broader uws surface
// lands, the two converge on the same type.

//! Zig mirror of `struct us_socket_group_t`. Embedded by value in its owner
//! (Listener, VirtualMachine, uWS App, HTTPThread) — never heap-allocated on
//! its own. The loop links it lazily on first socket and unlinks on last, so
//! unused kinds cost nothing.
//!
//! `extern struct` so field order/padding match the C definition exactly — Zig
//! is free to reorder non-extern struct fields, and this is read/written
//! directly by C (loop.c walks `head_sockets`/`iterator`, context.c flips
//! `linked`).

pub const SocketGroup = extern struct {
    loop: ?*Loop = null,
    vtable: ?*const VTable = null,
    /// Embedding owner — typed access via `owner(T)`. `?*anyopaque` only
    /// because the C ABI slot is heterogenous (Listener / uWS App / RareData /
    /// null); never read this field directly. Upstream spells this `#ext`
    /// (newer Zig private-field syntax); Home's Zig 0.17 pre-release doesn't
    /// accept the `#` prefix yet, so we keep the field name plain and rely on
    /// the doc-comment + the `owner(T)` accessor to keep callers honest.
    ext_owner: ?*anyopaque = null,
    head_sockets: ?*us_socket_t = null,
    head_connecting_sockets: ?*ConnectingSocket = null,
    head_listen_sockets: ?*ListenSocket = null,
    iterator: ?*us_socket_t = null,
    prev: ?*SocketGroup = null,
    next: ?*SocketGroup = null,
    global_tick: u32 = 0,
    /// Sockets currently parked in `loop.data.low_prio_head` with
    /// `s->group == this`. They are NOT in `head_sockets` while queued, so
    /// `closeAll`/`deinit` must account for them separately.
    low_prio_count: u16 = 0,
    timestamp: u8 = 0,
    long_timestamp: u8 = 0,
    linked: u8 = 0,

    pub const VTable = extern struct {
        on_open: ?*const fn (*us_socket_t, c_int, [*c]u8, c_int) callconv(.c) ?*us_socket_t = null,
        on_data: ?*const fn (*us_socket_t, [*c]u8, c_int) callconv(.c) ?*us_socket_t = null,
        on_fd: ?*const fn (*us_socket_t, c_int) callconv(.c) ?*us_socket_t = null,
        on_writable: ?*const fn (*us_socket_t) callconv(.c) ?*us_socket_t = null,
        on_close: ?*const fn (*us_socket_t, c_int, ?*anyopaque) callconv(.c) ?*us_socket_t = null,
        on_timeout: ?*const fn (*us_socket_t) callconv(.c) ?*us_socket_t = null,
        on_long_timeout: ?*const fn (*us_socket_t) callconv(.c) ?*us_socket_t = null,
        on_end: ?*const fn (*us_socket_t) callconv(.c) ?*us_socket_t = null,
        on_connect_error: ?*const fn (*us_socket_t, c_int) callconv(.c) ?*us_socket_t = null,
        on_connecting_error: ?*const fn (*ConnectingSocket, c_int) callconv(.c) ?*ConnectingSocket = null,
        on_handshake: ?*const fn (*us_socket_t, c_int, us_bun_verify_error_t, ?*anyopaque) callconv(.c) void = null,
    };

    comptime {
        // Must match `struct us_socket_group_t` in libusockets.h.
        // 9 ptrs + u32 + u16 + 3×u8, padded to 8-byte alignment.
        if (@sizeOf(SocketGroup) != 9 * @sizeOf(*anyopaque) + 16)
            @compileError("SocketGroup layout drifted from us_socket_group_t");
        if (@sizeOf(VTable) != 11 * @sizeOf(*anyopaque))
            @compileError("VTable layout drifted from us_socket_vtable_t");
    }

    /// Initialise an embedded group. `owner_ptr` (any single-item pointer or
    /// `null`) is what `group.owner(T)` recovers inside handlers — pass the
    /// embedding struct so dispatch can find it from a raw `*us_socket_t`.
    pub fn init(self: *SocketGroup, loop_: *Loop, vt: ?*const VTable, owner_ptr: anytype) void {
        const P = @TypeOf(owner_ptr);
        const erased: ?*anyopaque = if (P == @TypeOf(null)) null else switch (@typeInfo(P)) {
            .pointer => |p| if (p.size == .one) @ptrCast(@constCast(owner_ptr)) else @compileError("SocketGroup.init owner must be a single-item pointer"),
            .optional => if (owner_ptr) |o| @ptrCast(@constCast(o)) else null,
            else => @compileError("SocketGroup.init owner must be a pointer or null"),
        };
        c.us_socket_group_init(self, loop_, vt, erased);
    }

    pub fn deinit(self: *SocketGroup) void {
        c.us_socket_group_deinit(self);
    }

    pub fn closeAll(self: *SocketGroup) void {
        c.us_socket_group_close_all(self);
    }

    /// Non-null after `init`. The fields stay `?*T` only because the struct is
    /// zero-init'd by default and read directly by C; these accessors encode
    /// the post-init invariant.
    pub fn getLoop(self: *const SocketGroup) *Loop {
        return self.loop.?;
    }

    /// Recover the embedding owner. Only valid for groups whose `init` passed a
    /// non-null owner (Listener, uWS App/Context). Per-kind VM groups in
    /// `RareData` pass `null`, so callers must know which they have.
    pub fn owner(self: *const SocketGroup, comptime T: type) *T {
        return @ptrCast(@alignCast(self.ext_owner.?));
    }

    pub fn isEmpty(self: *const SocketGroup) bool {
        return self.head_sockets == null and
            self.head_connecting_sockets == null and
            self.head_listen_sockets == null and
            self.low_prio_count == 0;
    }

    pub fn listen(
        self: *SocketGroup,
        kind: SocketKind,
        ssl_ctx: ?*SslCtx,
        host: ?[*:0]const u8,
        port: c_int,
        options: c_int,
        socket_ext_size: c_int,
        err: *c_int,
    ) ?*ListenSocket {
        return c.us_socket_group_listen(self, @backingInt(kind), ssl_ctx, host, port, options, socket_ext_size, err);
    }

    pub fn listenUnix(
        self: *SocketGroup,
        kind: SocketKind,
        ssl_ctx: ?*SslCtx,
        path: [*]const u8,
        pathlen: usize,
        options: c_int,
        socket_ext_size: c_int,
        err: *c_int,
    ) ?*ListenSocket {
        return c.us_socket_group_listen_unix(self, @backingInt(kind), ssl_ctx, path, pathlen, options, socket_ext_size, err);
    }

    pub fn listenFD(self: *SocketGroup, kind: SocketKind, ssl_ctx: ?*SslCtx, fd: LIBUS_SOCKET_DESCRIPTOR, options: c_int, socket_ext_size: c_int, err: *c_int) ?*ListenSocket {
        return c.HomeSocketGroupListenFD(self, @backingInt(kind), ssl_ctx, fd, options, socket_ext_size, err);
    }

    pub const ConnectResult = union(enum) {
        socket: *us_socket_t,
        connecting: *ConnectingSocket,
        failed,
    };

    pub fn connect(
        self: *SocketGroup,
        kind: SocketKind,
        ssl_ctx: ?*SslCtx,
        host: [*:0]const u8,
        port: c_int,
        options: c_int,
        socket_ext_size: c_int,
    ) ConnectResult {
        return self.connectWithLocalAddress(kind, ssl_ctx, host, port, null, 0, options, socket_ext_size);
    }

    /// Connect while binding the client socket to an optional literal local IP
    /// and port. The caller owns `local_host`; the C layer parses it before this
    /// function returns, including on the asynchronous DNS path.
    pub fn connectWithLocalAddress(
        self: *SocketGroup,
        kind: SocketKind,
        ssl_ctx: ?*SslCtx,
        host: [*:0]const u8,
        port: c_int,
        local_host: ?[*:0]const u8,
        local_port: c_int,
        options: c_int,
        socket_ext_size: c_int,
    ) ConnectResult {
        // context.c writes 1 here on the synchronous path (DNS already resolved
        // → real `us_socket_t*` returned), 0 when it hands back a
        // `us_connecting_socket_t*` placeholder. Named to match the C side so
        // the branches read the right way round — see PR review #3161005603.
        var has_dns_resolved: c_int = 0;
        const ptr = c.us_socket_group_connect(self, @backingInt(kind), ssl_ctx, host, port, local_host, local_port, options, socket_ext_size, &has_dns_resolved) orelse return .failed;
        return if (has_dns_resolved != 0)
            .{ .socket = @ptrCast(@alignCast(ptr)) }
        else
            .{ .connecting = @ptrCast(@alignCast(ptr)) };
    }

    pub fn connectUnix(
        self: *SocketGroup,
        kind: SocketKind,
        ssl_ctx: ?*SslCtx,
        path: [*]const u8,
        pathlen: usize,
        options: c_int,
        socket_ext_size: c_int,
    ) ?*us_socket_t {
        return c.us_socket_group_connect_unix(self, @backingInt(kind), ssl_ctx, path, pathlen, options, socket_ext_size);
    }

    pub fn fromFd(
        self: *SocketGroup,
        kind: SocketKind,
        ssl_ctx: ?*SslCtx,
        socket_ext_size: c_int,
        fd: LIBUS_SOCKET_DESCRIPTOR,
        ipc: bool,
    ) ?*us_socket_t {
        return c.us_socket_from_fd(self, @backingInt(kind), ssl_ctx, socket_ext_size, fd, @intFromBool(ipc));
    }

    pub fn pair(self: *SocketGroup, kind: SocketKind, ext_size: c_int, fds: *[2]LIBUS_SOCKET_DESCRIPTOR) ?*us_socket_t {
        return c.us_socket_pair(self, @backingInt(kind), ext_size, fds);
    }

    pub fn nextInLoop(self: *SocketGroup) ?*SocketGroup {
        return c.us_socket_group_next(self);
    }
};

const c = struct {
    extern fn us_socket_group_init(*SocketGroup, *Loop, ?*const SocketGroup.VTable, ?*anyopaque) void;
    extern fn us_socket_group_deinit(*SocketGroup) void;
    extern fn us_socket_group_close_all(*SocketGroup) void;
    extern fn us_socket_group_timestamp(*SocketGroup) c_ushort;
    extern fn us_socket_group_loop(*SocketGroup) *Loop;
    extern fn us_socket_group_next(*SocketGroup) ?*SocketGroup;
    extern fn us_socket_group_listen(*SocketGroup, u8, ?*SslCtx, ?[*:0]const u8, c_int, c_int, c_int, *c_int) ?*ListenSocket;
    extern fn HomeSocketGroupListenFD(*SocketGroup, u8, ?*SslCtx, LIBUS_SOCKET_DESCRIPTOR, c_int, c_int, *c_int) ?*ListenSocket;
    extern fn us_socket_group_listen_unix(*SocketGroup, u8, ?*SslCtx, [*]const u8, usize, c_int, c_int, *c_int) ?*ListenSocket;
    /// Returns `us_socket_t*` (fast path) OR `us_connecting_socket_t*` (slow
    /// path), discriminated by `*is_connecting`. The public `connect()` method
    /// turns this into the typed `ConnectResult` union — call that, not this.
    extern fn us_socket_group_connect(*SocketGroup, u8, ?*SslCtx, [*:0]const u8, c_int, ?[*:0]const u8, c_int, c_int, c_int, *c_int) ?*anyopaque;
    extern fn us_socket_group_connect_unix(*SocketGroup, u8, ?*SslCtx, [*]const u8, usize, c_int, c_int) ?*us_socket_t;
    extern fn us_socket_from_fd(*SocketGroup, u8, ?*SslCtx, c_int, LIBUS_SOCKET_DESCRIPTOR, c_int) ?*us_socket_t;
    extern fn us_socket_pair(*SocketGroup, u8, c_int, *[2]LIBUS_SOCKET_DESCRIPTOR) ?*us_socket_t;
};

const ConnectingSocket = @import("./ConnectingSocket.zig").ConnectingSocket;
const SocketKind = @import("./SocketKind.zig").SocketKind;
const bun = @import("bun");

/// uSockets loop handle.
pub const Loop = @import("./Loop.zig").PosixLoop;

/// Shared usockets socket wrapper.
pub const us_socket_t = @import("./us_socket_t.zig").us_socket_t;

pub const ListenSocket = @import("./ListenSocket.zig").ListenSocket;

/// TLS context pointer owned by BoringSSL/libusockets.
pub const SslCtx = @import("../boringssl_sys/boringssl.zig").SSL_CTX;

/// Canonical `us_bun_verify_error_t` lives in `uws.zig`; alias it so
/// `VTable.on_handshake` shares one type identity with `vtable.zig`'s
/// trampolines (which reference `uws.us_bun_verify_error_t`).
pub const us_bun_verify_error_t = @import("../uws/uws.zig").us_bun_verify_error_t;

/// `LIBUS_SOCKET_DESCRIPTOR` is `int` on POSIX and `SOCKET` (`uintptr_t`) on
/// Windows. Home is POSIX-only for now; widen this once Windows support
/// lands (mirrors the upstream `if (Environment.isWindows)` switch).
pub const LIBUS_SOCKET_DESCRIPTOR = c_int;

test "SocketGroup layout matches us_socket_group_t" {
    const std = @import("std");
    // The `comptime` block above already asserts this, but mirroring it as a
    // test surfaces the constants in `zig test` output and catches drift if
    // someone disables UBSAN or runs under a different ABI.
    try std.testing.expectEqual(@as(usize, 9 * @sizeOf(*anyopaque) + 16), @sizeOf(SocketGroup));
    try std.testing.expectEqual(@as(usize, 11 * @sizeOf(*anyopaque)), @sizeOf(SocketGroup.VTable));
}

test "SocketGroup zero-initialises to an empty group" {
    const std = @import("std");
    const g: SocketGroup = .{};
    try std.testing.expect(g.isEmpty());
    try std.testing.expect(g.loop == null);
    try std.testing.expect(g.vtable == null);
    try std.testing.expectEqual(@as(u32, 0), g.global_tick);
    try std.testing.expectEqual(@as(u16, 0), g.low_prio_count);
    try std.testing.expectEqual(@as(u8, 0), g.linked);
}

test "SocketGroup.ConnectResult is a tagged union of the two success paths" {
    const std = @import("std");
    // Compile-time sanity — `connect` builds these from extern returns; the
    // test just verifies the union shape stays stable so dispatch.zig can
    // exhaustive-switch on it.
    const Tag = @typeInfo(SocketGroup.ConnectResult).@"union".tag_type.?;
    const tags = bun.meta.fieldsOf(Tag);
    try std.testing.expectEqual(@as(usize, 3), tags.len);
}

test "bun-usockets connect declaration matches the local-bind C ABI" {
    const std = @import("std");
    // Must match us_socket_group_connect in context.c / libusockets.h:
    //   (group, kind, ssl_ctx, host, port, local_host, local_port,
    //    options, socket_ext_size, is_connecting)
    // A wrong arg count shifts the C params, landing `is_connecting` on an int
    // value; the C side then writes `*is_connecting = 1` through a bogus
    // pointer → segfault on connect() to an IP literal.
    const fn_info = @typeInfo(@TypeOf(c.us_socket_group_connect)).@"fn";
    try std.testing.expectEqual(@as(usize, 10), fn_info.param_types.len);
    try std.testing.expect(fn_info.param_types[5].? == ?[*:0]const u8);
    try std.testing.expect(fn_info.param_types[9].? == *c_int);
}

test "SocketGroup local-bind entry point preserves host and port parameter types" {
    const std = @import("std");
    const fn_info = @typeInfo(@TypeOf(SocketGroup.connectWithLocalAddress)).@"fn";
    try std.testing.expectEqual(@as(usize, 9), fn_info.param_types.len);
    try std.testing.expect(fn_info.param_types[5].? == ?[*:0]const u8);
    try std.testing.expect(fn_info.param_types[6].? == c_int);
}
