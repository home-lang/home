import hashlib,json,os,subprocess,tempfile,time
from pathlib import Path
root=Path.cwd(); evidence=(root/'zig-out/bun-port-recovery').resolve();out=evidence/'native-patch-entrypoints';out.mkdir(exist_ok=False)
source=root/'packages/runtime/test/test/cli/install/bun-patch.test.ts'
manifest={'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'filter':'^error messages','results':[]}
for runtime,exe in [('home',root/'zig-out/bin/home'),('bun',Path('/Users/chris/Code/bun/build/release/bun'))]:
 env=os.environ.copy()
 for key in ['HOME_NATIVE_VM','HOME_CORPUS_FULL_VM','HOME_BUN_TEST_EXECUTABLE']:env.pop(key,None)
 env.update(NO_COLOR='1',BUN_DEBUG_QUIET_LOGS='1',BUN_FEATURE_FLAG_INTERNAL_FOR_TESTING='1',BUN_GARBAGE_COLLECTOR_LEVEL='0')
 if runtime=='home':env.update(HOME_NATIVE_VM='1',HOME_CORPUS_FULL_VM='1')
 with tempfile.TemporaryDirectory(prefix='home-patch-entry-') as directory:
  env.update(BUN_INSTALL=directory+'/install',BUN_INSTALL_GLOBAL_DIR=directory+'/global',BUN_INSTALL_BIN=directory+'/bin',BUN_INSTALL_CACHE_DIR=directory+'/cache')
  args=[str(exe),'test','--config='+str(root/'packages/runtime/test/bunfig.toml'),str(source),'--test-name-pattern','^error messages']
  row={'runtime':runtime,'argv':args,'executable_sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'status':'started'};manifest['results'].append(row)
  (out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
  start=time.monotonic();log=out/(runtime+'.log')
  with log.open('xb') as stream:code=subprocess.run(['perl',str(root/'scripts/run-bounded.pl'),'240',*args],cwd=root/'packages/runtime/test',env=env,stdout=stream,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL).returncode
  row.update(status='completed',exit_code=code,seconds=time.monotonic()-start,source_unchanged=hashlib.sha256(source.read_bytes()).hexdigest()==manifest['source_sha256'],log_sha256=hashlib.sha256(log.read_bytes()).hexdigest())
  (out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(row),flush=True)
