import assert from 'node:assert/strict'
import vm from 'node:vm'
const context=vm.createContext({outside:7})
const extension={inside:40}
const compiled=vm.compileFunction('return inside+outside',[],{parsingContext:context,contextExtensions:[extension]})
assert.equal(compiled(),47)
assert.equal(Object.getPrototypeOf(compiled),vm.runInContext('Function.prototype',context))
assert.equal(vm.runInContext('typeof inside',context),'undefined')
assert.equal(vm.compileFunction('return typeof inside',[],{parsingContext:context})(),'undefined')
assert.equal(compiled(),47)
extension.inside=50
assert.equal(compiled(),57)
const special=vm.createContext(vm.constants.DONT_CONTEXTIFY)
special.value=42
assert.equal(vm.compileFunction('return value',[],{parsingContext:special})(),42)
assert.throws(()=>vm.compileFunction('return 1',[],{importModuleDynamically:17}),{code:'ERR_INVALID_ARG_TYPE'})
assert.throws(()=>vm.compileFunction('return 1',[],'filename.js'),{code:'ERR_INVALID_ARG_TYPE'})
console.log('function-only extension scope, retained bindings, special contexts and options validation passed')
