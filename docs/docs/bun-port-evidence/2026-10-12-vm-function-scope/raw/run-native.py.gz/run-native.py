from pathlib import Path
import subprocess,os,json,sys
root=Path(__file__).resolve().parents[2];task=Path(__file__).resolve().parent / (sys.argv[1] if len(sys.argv)>1 else '.')
task.mkdir(parents=True,exist_ok=True)
names=['native-vm-memory.test.mjs','native-directory-handle.test.mjs','native-async-context.test.mjs','native-corpus-suite.test.mjs','native-corpus-outcomes.test.mjs','native-https-alpn-callback.test.mjs','native-https-alpn-storage.test.mjs','native-fetch-connection-timing.test.mjs','native-fetch-resource-timing.test.mjs','native-global-resource-timing.test.mjs','native-resource-timing.test.mjs','native-performance-observer.test.mjs','native-poll-lifecycle.test.mjs','native-test-discovery.test.mjs','native-stream-wrap.test.mjs','native-stream-cancellation.test.mjs','native-diagnostics-lifecycle.test.mjs','native-node-core-cli.test.mjs','native-worker-fs-task-shutdown.test.mjs','native-h2-settings-window.test.mjs','native-abort-listener.test.mjs','native-wasi-valid.test.mjs','native-async-storage-lifecycle.test.mjs','native-async-exit-continuations.test.mjs','native-performance-monitors.test.mjs','native-factory-exports.test.mjs','native-process-binding-state.test.mjs']
rows=[]
for name in names:
 source=root/'tests/runtime'/name
 if not source.exists():
  print('missing',name);sys.exit(1)
 env=os.environ.copy();env['BUN_DEBUG_QUIET_LOGS']='1'
 if name=='native-corpus-outcomes.test.mjs':env['HOME_CORPUS_EVIDENCE_DIR']=str(task/'outcomes-reports')
 if name=='native-corpus-suite.test.mjs':env['HOME_CORPUS_SUITE_EVIDENCE_DIR']=str(task/'suite-reports')
 with (task/('regression-'+name+'.log')).open('wb') as log:
  result=subprocess.run([str(root/'zig-out/bin/home'),'run',str(source)],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=240)
 rows.append({'file':str(source.relative_to(root)),'exit':result.returncode});print(name,result.returncode,flush=True)
(task/'native-summary.json').write_text(json.dumps(rows,indent=2)+'\n')
sys.exit(0 if all(r['exit']==0 for r in rows) else 1)
