import gzip, hashlib, importlib.util, json, subprocess, tempfile
from pathlib import Path
root = Path.cwd()
folder = root / 'docs/docs/bun-port-evidence/2026-09-08-vendor-execution'
manifest = json.loads((folder / 'manifest.json').read_text())
tracked = set(subprocess.check_output(['git', 'ls-files'], text=True).splitlines())
prefix = 'zig-out/bun-port-recovery/elysia-native-execution-first/reports/'
spec = importlib.util.spec_from_file_location('validator', root / 'scripts/summarize-bun-corpus.py')
validator = importlib.util.module_from_spec(spec)
spec.loader.exec_module(validator)
with tempfile.TemporaryDirectory(prefix='home-vendor-publication-') as name:
    destination = Path(name)
    for entry in manifest['files']:
        artifact = folder / entry['artifact']
        assert str(artifact.relative_to(root)) in tracked
        data = gzip.decompress(artifact.read_bytes())
        assert len(data) == entry['bytes']
        assert hashlib.sha256(data).hexdigest() == entry['sha256']
        if entry['source'].startswith(prefix):
            filename = entry['source'][len(prefix):]
            assert Path(filename).name == filename
            (destination / filename).write_bytes(data)
    result = validator.summarize(destination)
    assert result['successful'], result['errors']
    assert result['selected'] == result['completed'] == 129
    assert result['counts'] == {'passed': 1516, 'failed': 0, 'skipped': 0, 'todo': 0}
    print(json.dumps({'tracked_artifacts_verified': len(manifest['files']), 'restored_selected': result['selected'], 'restored_completed': result['completed'], 'counts': result['counts'], 'successful': result['successful']}, indent=2))
