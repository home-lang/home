import hashlib,json,os,subprocess
from pathlib import Path
root=Path.cwd();ev=root/'zig-out/bun-port-recovery';out=ev/'platform-parity-first';out.mkdir()
upstream=Path('/Users/chris/Code/bun');pin='4982b91e3702094330f3be3883354c52b8c01323'
utils=subprocess.check_output(['git','-C',str(upstream),'show',pin+':scripts/utils.mjs']).decode()
runner=subprocess.check_output(['git','-C',str(upstream),'show',pin+':scripts/runner.node.mjs']).decode()
def extract(source,name):
 start=source.index('function '+name+'(');end=source.index('\n}',start)+2
 return source[start:end]
functions='\n'.join(extract(utils,n) for n in ['parseOs','parseArch','getOs','getArch','getAbi','getAbiVersion','getDistro','getDistroVersion'])
check=extract(runner,'assertExpectedPlatform')
scenarios=[
 ('darwin','aarch64',[],[(['sw_vers','-productVersion'],'27.0\n')]),
 ('darwin','x64',[],[(['sw_vers','-productVersion'],None)]),
 ('windows','x64',[],[(['cmd','/c','ver'],'\r\nMicrosoft Windows [Version 10.0.26100.1]\r\n')]),
 ('windows','aarch64',[],[(['cmd','/c','ver'],None)]),
 ('linux','x64',[('/etc/alpine-release','3.23.0_alpha20260101\n'),('/etc/os-release','ID=ignored\n'),('/lib/ld-linux-x86_64.so.2','')],[(['ldd','--version'],'musl libc\nVersion 1.2.5\n')]),
 ('linux','aarch64',[('/lib/ld-musl-aarch64.so.1',''),('/lib/ld-linux-aarch64.so.2',''),('/etc/os-release','ID="alpine"\nVERSION_ID="3.22"\n')],[(['ldd','--version'],None)]),
 ('linux','x64',[('/lib/ld-linux-x86_64.so.2',''),('/etc/os-release','NOT_ID=bad\nID="ubuntu"\r\nVERSION_ID="25.04"\r\n')],[(['ldd','--version'],'ldd (Ubuntu GLIBC 2.42-4ubuntu2) 2.42\n')]),
 ('linux','aarch64',[('/etc/os-release','ID=debian\nVERSION_ID=13\n')],[(['ldd','--version'],'ldd (GNU libc) 2.41\n')]),
 ('linux','x64',[],[(['ldd','--version'],'musl libc\nVersion 1.2\n'),(['lsb_release','-is'],'  ExampleLinux\n'),(['lsb_release','-rs'],'1.2.3\n')]),
 ('linux','x64',[('/etc/os-release','ID=\nVERSION_ID=\n')],[(['lsb_release','-is'],'should-not-be-used'),(['lsb_release','-rs'],'should-not-be-used')]),
 ('linux','aarch64',[],[]),
 ('linux','x64',[('/etc/os-release','ID="test\\u002ddistro"\nVERSION_ID="5.4.3"\n')],[(['ldd','--version'],'unknown ABI version 7.8.9.10')]),
]
cases=[]
for os_name,arch,files,commands in scenarios:
 obs={'files':[{'path':p,'contents':v} for p,v in files],'commands':[{'argv':a,'stdout':v} for a,v in commands]}
 for expected in [{},{'arch':'wrong'},{'os':os_name,'arch':arch},{'os':'wrong','arch':'wrong','abi':'wrong','distro':'wrong','release':'999'},{'os':os_name,'release':'25'},{'os':os_name,'release':'25.04'},{'os':os_name,'release':'25.0'},{'os':os_name,'abi':'musl'}]:cases.append({'os':os_name,'arch':arch,'observations':obs,'expected':expected})
(out/'input.json').write_text(json.dumps({'cases':cases},indent=2)+'\n')
program=r'''import fs from 'node:fs';
import * as actual from '__UTILS__';
const input=JSON.parse(fs.readFileSync(process.argv[2],'utf8'));
const evaluate = new Function('record', `
const isMacOS=record.os==='darwin', isLinux=record.os==='linux', isWindows=record.os==='windows';
const names={os:'OS',arch:'ARCH',abi:'ABI',distro:'DISTRO',release:'RELEASE'};
const process={platform:isWindows?'win32':record.os,arch:record.arch==='aarch64'?'arm64':record.arch,env:Object.fromEntries(Object.entries(record.expected).map(([k,v])=>['EXPECTED_PLATFORM_'+names[k],v])),exit:()=>{throw new Error('mismatch')}};
const existsSync=path=>record.observations.files.some(f=>f.path===path);
const readFile=path=>record.observations.files.find(f=>f.path===path).contents;
const spawnSync=argv=>{const c=record.observations.commands.find(c=>JSON.stringify(c.argv)===JSON.stringify(argv));return c&&c.stdout!==null?{stdout:c.stdout}:{error:true}};
const isQuiet=true; const console={error:()=>{}};
__FUNCTIONS__
__CHECK__
const host={os:getOs(),arch:getArch(),distro:getDistro()??null,distro_version:getDistroVersion()??null,abi:getAbi()??null,abi_version:getAbiVersion()??null};
let successful=true;try {assertExpectedPlatform()}catch{successful=false}
return {host,successful};`);
const live={os:actual.getOs(),arch:actual.getArch(),distro:actual.getDistro()??null,distro_version:actual.getDistroVersion()??null,abi:actual.getAbi()??null,abi_version:actual.getAbiVersion()??null};
fs.writeFileSync(process.argv[3],JSON.stringify({cases:input.cases.map(evaluate),live,is_ci:actual.isCI},null,2));
'''.replace('__UTILS__',str(upstream/'scripts/utils.mjs')).replace('__FUNCTIONS__',functions.replace('`','\\`').replace('${','\\${')).replace('__CHECK__',check.replace('`','\\`').replace('${','\\${'))
(out/'reference.mjs').write_text(program)
# The live import must still match the referenced pin.
assert (upstream/'scripts/utils.mjs').read_text()==utils
for label,argv in [('native',[str(ev/'corpus-platform-probe'),str(out/'input.json'),str(out/'native.json')]),('reference',[str(upstream/'build/release/bun'),str(out/'reference.mjs'),str(out/'input.json'),str(out/'reference.json')])]:
 result=subprocess.run(argv,capture_output=True,timeout=30);(out/(label+'.stdout')).write_bytes(result.stdout);(out/(label+'.stderr')).write_bytes(result.stderr);assert result.returncode==0,(label,result.stderr.decode())
native=json.loads((out/'native.json').read_text());ref=json.loads((out/'reference.json').read_text());differences=[]
for i,(a,b) in enumerate(zip(native['cases'],ref['cases'])):
 if a['host']!=b['host'] or a['successful']!=b['successful']:differences.append({'index':i,'native':a,'reference':b})
summary={'kind':'platform probes and expected-agent comparisons; no corpus case credit','cases':len(cases),'differences':differences,'native_live':native['live'],'reference_live':ref['live'],'live_equal':native['live']['host']==ref['live'] and native['live']['is_ci']==ref['is_ci'],'source_sha256':{name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in ['packages/home_test/src/corpus_platform.zig','packages/home_test/src/corpus_platform_probe.zig']}}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2));assert not differences and summary['live_equal']
