import hashlib,json,os,subprocess,time
from pathlib import Path
root=Path.cwd();evidence=root/'zig-out/bun-port-recovery';out=evidence/'elysia-native-platform-execution-first';out.mkdir()
home=root/'zig-out/bin/home';vendor=root/'packages/runtime/test/vendor/elysia';build=evidence/'build-corpus-native-platform-first.log'
assert 'Build Summary: 23/23 steps succeeded' in build.read_text()
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
previous=json.loads((evidence/'elysia-native-setup-initialized/manifest.json').read_text());lock_control=json.loads((evidence/'elysia-lock-control/manifest.json').read_text());assert lock_control['verified']
protected={name:sha(vendor/name) for name in previous['original_sources']}
for name,digest in previous['original_sources'].items():assert protected[name]==(lock_control['home_lock_sha256'] if name=='bun.lock' else digest),name+' changed before execution'
assert subprocess.check_output(['git','-C',str(vendor),'rev-parse','HEAD'],text=True).strip()=='56310be9617b826f862c985eae95ae823d95f097'
inputs=['packages/home_test/src/corpus_platform.zig','packages/home_test/src/home_test.zig','packages/home_test/src/test_root.zig','packages/home_test/src/corpus_runner.zig','packages/home_test/src/corpus_vendor.zig','packages/home_test/src/corpus_journal.zig','packages/home_test/src/adapters/jsc_bootstrap.zig','src/main.zig','scripts/summarize-bun-corpus.py']
manifest={'scope':'complete prepared Elysia vendor execution, primary suite and CI orchestration remain unfinished','source_commit_before_build':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'runtime_source_sha256':{p:sha(root/p) for p in inputs},'home_sha256':sha(home),'protected_vendor_sources':protected,'vendor_revision':'56310be9617b826f862c985eae95ae823d95f097','setup_reference':'elysia-native-setup-initialized/manifest.json + elysia-lock-control/manifest.json','original_deadlines':True,'attempts':1,'argv':[str(home),'test','--bun-corpus-prepared-vendor','elysia'],'status':'started'}
def save():(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
save();env=os.environ.copy()
for key in ['HOME_NATIVE_VM','HOME_CORPUS_FULL_VM','HOME_BUN_CORPUS_START','HOME_BUN_CORPUS_LIMIT','HOME_CORPUS_VENDOR_PLAN_OUTPUT']:env.pop(key,None)
env.update(CI='1',HOME_BUN_TEST_EXECUTABLE=str(home),HOME_BUN_CORPUS_REPORT_DIR=str(out/'reports'),HOME_BUN_CORPUS_PROGRESS='1')
start=time.monotonic()
with (out/'runner.stdout').open('xb') as stdout,(out/'runner.stderr').open('xb') as stderr:
 code=subprocess.run(manifest['argv'],cwd=root,env=env,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr).returncode
manifest.update(status='completed',returncode=code,seconds=time.monotonic()-start,stdout_sha256=sha(out/'runner.stdout'),stderr_sha256=sha(out/'runner.stderr'),sources_unchanged=all((vendor/name).is_file() and sha(vendor/name)==digest for name,digest in protected.items()),home_unchanged=sha(home)==manifest['home_sha256']);save()
with (out/'summary.json').open('xb') as stdout,(out/'validator.stderr').open('xb') as stderr:
 validated=subprocess.run(['python3',str(root/'scripts/summarize-bun-corpus.py'),str(out/'reports')],cwd=root,stdout=stdout,stderr=stderr).returncode
summary=json.loads((out/'summary.json').read_text());policy=summary.get('selection_policy') or {};reference=json.loads((evidence/'elysia-native-selection-initialized.json').read_text());expected=['test/'+path for path in reference['selected']]
actual=[policy['inventory'][i] for i in policy.get('selected_indices',[])]
manifest.update(validator_returncode=validated,selection_matches_pinned_reference=actual==expected,all_selected_completed=summary.get('completed')==129 and summary.get('selected')==129,counts=summary.get('counts'),failed_file_ids=summary.get('failed_file_ids'),verification_passed=code==0 and validated==0 and actual==expected and summary.get('completed')==129 and manifest['sources_unchanged'] and manifest['home_unchanged']);save();print(json.dumps({k:v for k,v in manifest.items() if k not in ['protected_vendor_sources','runtime_source_sha256']},indent=2));raise SystemExit(0 if manifest['verification_passed'] else 1)
