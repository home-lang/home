import fs from 'node:fs';
import * as actual from '/Users/chris/Code/bun/scripts/utils.mjs';
const input=JSON.parse(fs.readFileSync(process.argv[2],'utf8'));
const evaluate = new Function('record', `
const isMacOS=record.os==='darwin', isLinux=record.os==='linux', isWindows=record.os==='windows';
const names={os:'OS',arch:'ARCH',abi:'ABI',distro:'DISTRO',release:'RELEASE'};
const process={platform:isWindows?'win32':record.os,arch:record.arch==='aarch64'?'arm64':record.arch,env:Object.fromEntries(Object.entries(record.expected).map(([k,v])=>['EXPECTED_PLATFORM_'+names[k],v])),exit:()=>{throw new Error('mismatch')}};
const existsSync=path=>record.observations.files.some(f=>f.path===path);
const readFile=path=>record.observations.files.find(f=>f.path===path).contents;
const spawnSync=argv=>{const c=record.observations.commands.find(c=>JSON.stringify(c.argv)===JSON.stringify(argv));return c&&c.stdout!==null?{stdout:c.stdout}:{error:true}};
const isQuiet=true; const console={error:()=>{}};
function parseOs(string) {
  if (/darwin|apple|mac/i.test(string)) {
    return "darwin";
  }
  if (/linux/i.test(string)) {
    return "linux";
  }
  if (/win/i.test(string)) {
    return "windows";
  }
  throw new Error(\`Unsupported operating system: \${string}\`);
}
function parseArch(string) {
  if (/x64|amd64|x86_64/i.test(string)) {
    return "x64";
  }
  if (/arm64|aarch64/i.test(string)) {
    return "aarch64";
  }
  throw new Error(\`Unsupported architecture: \${string}\`);
}
function getOs() {
  return parseOs(process.platform);
}
function getArch() {
  return parseArch(process.arch);
}
function getAbi() {
  if (!isLinux) {
    return;
  }

  if (existsSync("/etc/alpine-release")) {
    return "musl";
  }

  const arch = getArch() === "x64" ? "x86_64" : "aarch64";
  const muslLibPath = \`/lib/ld-musl-\${arch}.so.1\`;
  if (existsSync(muslLibPath)) {
    return "musl";
  }

  const gnuLibPath = \`/lib/ld-linux-\${arch}.so.2\`;
  if (existsSync(gnuLibPath)) {
    return "gnu";
  }

  const { error, stdout } = spawnSync(["ldd", "--version"]);
  if (!error) {
    if (/musl/i.test(stdout)) {
      return "musl";
    }
    if (/gnu|glibc/i.test(stdout)) {
      return "gnu";
    }
  }
}
function getAbiVersion() {
  if (!isLinux) {
    return;
  }

  const { error, stdout } = spawnSync(["ldd", "--version"]);
  if (!error) {
    const match = /(\d+)\.(\d+)(?:\.(\d+))?/.exec(stdout);
    if (match) {
      const [, major, minor, patch] = match;
      if (patch) {
        return \`\${major}.\${minor}.\${patch}\`;
      }
      return \`\${major}.\${minor}\`;
    }
  }
}
function getDistro() {
  if (isMacOS) {
    return "macOS";
  }

  if (isLinux) {
    const alpinePath = "/etc/alpine-release";
    if (existsSync(alpinePath)) {
      return "alpine";
    }

    const releasePath = "/etc/os-release";
    if (existsSync(releasePath)) {
      const releaseFile = readFile(releasePath, { cache: true });
      const match = releaseFile.match(/^ID=(.*)/m);
      if (match) {
        const [, id] = match;
        return id.includes('"') ? JSON.parse(id) : id;
      }
    }

    const { error, stdout } = spawnSync(["lsb_release", "-is"]);
    if (!error) {
      return stdout.trim().toLowerCase();
    }
  }

  if (isWindows) {
    const { error, stdout } = spawnSync(["cmd", "/c", "ver"]);
    if (!error) {
      return stdout.trim();
    }
  }
}
function getDistroVersion() {
  if (isMacOS) {
    const { error, stdout } = spawnSync(["sw_vers", "-productVersion"]);
    if (!error) {
      return stdout.trim();
    }
  }

  if (isLinux) {
    const alpinePath = "/etc/alpine-release";
    if (existsSync(alpinePath)) {
      const release = readFile(alpinePath, { cache: true }).trim();
      if (release.includes("_")) {
        const [version] = release.split("_");
        return \`\${version}-edge\`;
      }
      return release;
    }

    const releasePath = "/etc/os-release";
    if (existsSync(releasePath)) {
      const releaseFile = readFile(releasePath, { cache: true });
      const match = releaseFile.match(/^VERSION_ID=(.*)/m);
      if (match) {
        const [, release] = match;
        return release.includes('"') ? JSON.parse(release) : release;
      }
    }

    const { error, stdout } = spawnSync(["lsb_release", "-rs"]);
    if (!error) {
      return stdout.trim();
    }
  }

  if (isWindows) {
    const { error, stdout } = spawnSync(["cmd", "/c", "ver"]);
    if (!error) {
      return stdout.trim();
    }
  }
}
function assertExpectedPlatform() {
  const expectedOs = process.env["EXPECTED_PLATFORM_OS"];
  if (!expectedOs) {
    return; // step does not declare expectations (e.g. local runs)
  }

  const checks = [
    ["os", expectedOs, getOs()],
    ["arch", process.env["EXPECTED_PLATFORM_ARCH"], getArch()],
    ["abi", process.env["EXPECTED_PLATFORM_ABI"], getAbi()],
    ["distro", process.env["EXPECTED_PLATFORM_DISTRO"], getDistro()],
  ];

  const expectedRelease = process.env["EXPECTED_PLATFORM_RELEASE"];
  if (expectedRelease) {
    // Major-version prefix match: "26" accepts "26.4", "25.04" accepts "25.04.1".
    const actualRelease = getDistroVersion();
    const ok = actualRelease === expectedRelease || \`\${actualRelease}.\`.startsWith(\`\${expectedRelease}.\`);
    checks.push(["release", expectedRelease, ok ? expectedRelease : actualRelease]);
  }

  // Fail closed: a declared expectation with no detectable actual value is a
  // mismatch (e.g. a musl step on a box where the ABI probe fails).
  const mismatches = checks.filter(([, expected, actual]) => expected && expected !== actual);
  if (mismatches.length) {
    const details = mismatches
      .map(([k, e, a]) => \`\${k}: step expects "\${e}", agent is \${a ? \`"\${a}"\` : "(undetected)"}\`)
      .join("\n  ");
    console.error(\`Platform smoke check FAILED, this job landed on the wrong agent:\n  \${details}\`);
    process.exit(1);
  }

  !isQuiet &&
    console.log(
      "Platform check:",
      checks
        .filter(([, e]) => e)
        .map(([k, e]) => \`\${k}=\${e}\`)
        .join(" "),
      "(ok)",
    );
}
const host={os:getOs(),arch:getArch(),distro:getDistro()??null,distro_version:getDistroVersion()??null,abi:getAbi()??null,abi_version:getAbiVersion()??null};
let successful=true;try {assertExpectedPlatform()}catch{successful=false}
return {host,successful};`);
const live={os:actual.getOs(),arch:actual.getArch(),distro:actual.getDistro()??null,distro_version:actual.getDistroVersion()??null,abi:actual.getAbi()??null,abi_version:actual.getAbiVersion()??null};
fs.writeFileSync(process.argv[3],JSON.stringify({cases:input.cases.map(evaluate),live,is_ci:actual.isCI},null,2));
