import hashlib,json,os,subprocess
from pathlib import Path
root=Path.cwd();ev=root/'zig-out/bun-port-recovery';out=ev/'native-platform-cli-first';out.mkdir()
assert 'Build Summary: 23/23 steps succeeded' in (ev/'build-corpus-native-platform-first.log').read_text()
home=root/'zig-out/bin/home';host=json.loads((ev/'platform-parity-corrected/summary.json').read_text())['native_live']['host']
base=os.environ.copy()
for key in ['HOME_NATIVE_VM','HOME_CORPUS_FULL_VM','CI','BUILDKITE','GITHUB_ACTIONS','EXPECTED_PLATFORM_OS','EXPECTED_PLATFORM_ARCH','EXPECTED_PLATFORM_ABI','EXPECTED_PLATFORM_DISTRO','EXPECTED_PLATFORM_RELEASE']:base.pop(key,None)
manifest={'kind':'actual Home platform command controls, no corpus case credit','home_sha256':hashlib.sha256(home.read_bytes()).hexdigest(),'controls':[]}
major=host['distro_version'].split('.')[0]
controls=[('undeclared',{},True,False),('matching-ci',{'CI':'true','EXPECTED_PLATFORM_OS':host['os'],'EXPECTED_PLATFORM_ARCH':host['arch'],'EXPECTED_PLATFORM_DISTRO':host['distro'],'EXPECTED_PLATFORM_RELEASE':major},True,True),('wrong-os',{'CI':'1','EXPECTED_PLATFORM_OS':'wrong-os'},False,False),('undetected-abi',{'EXPECTED_PLATFORM_OS':host['os'],'EXPECTED_PLATFORM_ABI':'not-the-detected-abi'},False,False),('no-os-disables-check',{'EXPECTED_PLATFORM_ARCH':'wrong-arch'},True,False),('wrong-release-component',{'EXPECTED_PLATFORM_OS':host['os'],'EXPECTED_PLATFORM_RELEASE':major+'0'},False,False)]
for label,extra,expected,ci in controls:
 env=base.copy();env.update(extra);argv=[str(home),'test','--bun-corpus-platform'];result=subprocess.run(argv,cwd=root,env=env,capture_output=True,timeout=20)
 (out/(label+'.stdout')).write_bytes(result.stdout);(out/(label+'.stderr')).write_bytes(result.stderr)
 data=json.loads(result.stdout);verified=(result.returncode==0)==expected and data['successful']==expected and data['host']==host and data['is_ci']==ci
 manifest['controls'].append({'label':label,'argv':argv,'environment_changes':extra,'returncode':result.returncode,'result':data,'verified':verified});(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');assert verified,(label,data,result.returncode)
manifest['home_unchanged']=hashlib.sha256(home.read_bytes()).hexdigest()==manifest['home_sha256'];manifest['verification_passed']=all(c['verified'] for c in manifest['controls']) and manifest['home_unchanged'];(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(manifest,indent=2))
