from pathlib import Path
import subprocess,json,os,sys
root=Path(__file__).resolve().parents[2];task=Path(__file__).resolve().parent
name='js/node/fs/promises.test.js';pattern='^rm and promises.rm report ERR_FS_EISDIR for directories like rmSync$';report=task/'compound-original'
env=os.environ.copy();env['HOME_BUN_CORPUS_REPORT_DIR']=str(report);env['BUN_DEBUG_QUIET_LOGS']='1'
for key in ['HOME_NATIVE_VM','HOME_CORPUS_FULL_VM','HOME_NATIVE_RUN']:env.pop(key,None)
command=[str(root/'zig-out/bin/home'),'test',str(root/'packages/runtime/test/test'/name),'-t',pattern]
with (task/'compound-original.log').open('wb') as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=240)
with (task/'compound-original-validate.json').open('wb') as log:v=subprocess.run([sys.executable,'scripts/summarize-bun-corpus.py',str(report)],cwd=root,stdout=log,stderr=subprocess.STDOUT)
result=json.loads((task/'compound-original-validate.json').read_text());passing=[c for c in result.get('cases',[]) if c['status']=='passed'];scope=len(passing)==1 and passing[0]['name']==pattern[1:-1]
(task/'compound-original-scope.json').write_text(json.dumps({'file':name,'pattern':pattern,'exit':r.returncode,'validation_exit':v.returncode,'scope_matches':scope,'command':command},indent=2)+'\n');print(r.returncode,v.returncode,scope);sys.exit(0 if r.returncode==0 and v.returncode==0 and scope else 1)
