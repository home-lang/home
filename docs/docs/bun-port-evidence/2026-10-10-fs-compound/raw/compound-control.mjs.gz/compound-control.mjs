import assert from 'node:assert/strict';
import {mkdtempSync,mkdirSync,writeFileSync,rmSync} from 'node:fs';
import * as callbackFs from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {AsyncResource,AsyncLocalStorage,createHook,executionAsyncId,executionAsyncResource} from 'node:async_hooks';
const compoundDirectory = mkdtempSync(join(tmpdir(), 'home-fs-compound-hooks-'))
mkdirSync(join(compoundDirectory, 'child'))
writeFileSync(join(compoundDirectory, 'child', 'entry.txt'), 'x')
const compoundContext = new AsyncLocalStorage()
const compoundOrigin = compoundContext.run('compound-creation', () => new AsyncResource('home-compound-origin', { requireManualDestroy: true }))
const compoundOwners = new Map()
const compoundRows = []
const compoundHook = createHook({
  init(id, type, trigger, owner) { if (type === 'FSREQCALLBACK') { compoundOwners.set(id, owner); compoundRows.push(['init', id, trigger]) } },
  before(id) { if (compoundOwners.has(id)) compoundRows.push(['before', id]) },
  after(id) { if (compoundOwners.has(id)) compoundRows.push(['after', id]) },
  destroy(id) { if (compoundOwners.has(id)) compoundRows.push(['destroy', id]) },
})
function invokeCompound(operation) {
  return new Promise((resolve, reject) => compoundOrigin.runInAsyncScope(() => operation((error, value) => {
    assert.equal(compoundContext.getStore(), 'compound-creation')
    assert(compoundOwners.has(executionAsyncId()))
    assert.equal(executionAsyncResource(), compoundOwners.get(executionAsyncId()))
    if (error) reject(error)
    else resolve(value)
  })))
}
try {
  compoundHook.enable()
  await assert.rejects(invokeCompound(done => callbackFs.rm(join(compoundDirectory, 'child'), done)), { code: 'ERR_FS_EISDIR' })
  const opened = await invokeCompound(done => callbackFs.opendir(join(compoundDirectory, 'child'), done))
  assert.equal(opened.path, join(compoundDirectory, 'child'))
  const entry = await new Promise((resolve, reject) => opened.read((error, value) => error ? reject(error) : resolve(value)))
  assert.equal(entry.name, 'entry.txt')
  await new Promise((resolve, reject) => opened.close(error => error ? reject(error) : resolve()))
  await invokeCompound(done => callbackFs.rm(join(compoundDirectory, 'child'), { recursive: true }, done))
  await new Promise(resolve => setImmediate(resolve))
  compoundHook.disable()
  assert(compoundOwners.size >= 3)
  for (const id of compoundOwners.keys()) {
    assert.equal(compoundRows.filter(row => row[0] === 'before' && row[1] === id).length, 1)
    assert.equal(compoundRows.filter(row => row[0] === 'after' && row[1] === id).length, 1)
    assert.equal(compoundRows.filter(row => row[0] === 'destroy' && row[1] === id).length, 1)
  }
} finally {
  compoundHook.disable()
  compoundOrigin.emitDestroy()
  compoundContext.disable()
  rmSync(compoundDirectory, { recursive: true, force: true })
}
console.log('native compound rm/opendir callback validation and lifecycle passed')
