import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';
for (const operation of ['close']) {
  const result = spawnSync(process.execPath, ['-e', `
    const fs=require('node:fs');const os=require('node:os');const path=require('node:path');
    const dirPath=fs.mkdtempSync(path.join(os.tmpdir(),'home-dir-callback-error-'));
    fs.writeFileSync(path.join(dirPath,'entry'),'x');
    const marker=new Error('directory callback marker');
    let rejection=false;process.once('unhandledRejection',()=>{rejection=true;process.exitCode=1});
    process.once('uncaughtException',error=>{
      if(error!==marker||rejection)process.exitCode=1;
      else console.log('directory callback uncaught marker');
      fs.rmSync(dirPath,{recursive:true,force:true});
    });
    fs.opendir(dirPath,(error,dir)=>{if(error)throw error;dir.${operation}(()=>{throw marker})});
  `], { encoding: 'utf8', timeout: 60000, env: { ...process.env, BUN_DEBUG_QUIET_LOGS: '1' } })
  assert.equal(result.error, undefined)
  assert.equal(result.signal, null)
  assert.equal(result.stdout.trim(), 'directory callback uncaught marker', result.stderr)
  assert.equal(result.status, 0, result.stderr)
}
console.log('native Dir close callback throws use uncaught exception delivery passed')
