from pathlib import Path
import subprocess,os,json,sys
root=Path(__file__).resolve().parents[2];task=Path(__file__).resolve().parent
specs=[('js/node/fs/promises.test.js',r'^(?:should exist|should be enumerable|access should work|open should (?:work|return an object|be closable)|more (?:is an object|stat)|writing to file in append mode works)$'),('js/node/fs/cp.test.ts',r'^fs\.cp(?:Sync)? (?:single file|recursive directory structure - no destination|recursive directory structure - overwrite existing files by default)$')]
rows=[]
for i,(name,pattern) in enumerate(specs,1):
 report=task/f'fs-original-{i}';env=os.environ.copy();env['HOME_BUN_CORPUS_REPORT_DIR']=str(report);env['BUN_DEBUG_QUIET_LOGS']='1'
 for key in ['HOME_NATIVE_VM','HOME_CORPUS_FULL_VM','HOME_NATIVE_RUN']:env.pop(key,None)
 command=[str(root/'zig-out/bin/home'),'test',str(root/'packages/runtime/test/test'/name),'-t',pattern]
 with (task/f'fs-original-{i}.log').open('wb') as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=240)
 with (task/f'fs-original-{i}-validate.json').open('wb') as log:v=subprocess.run([sys.executable,'scripts/summarize-bun-corpus.py',str(report)],cwd=root,stdout=log,stderr=subprocess.STDOUT)
 result=json.loads((task/f'fs-original-{i}-validate.json').read_text());passing=[c for c in result.get('cases',[]) if c['status']=='passed'];scope=bool(passing) and all(__import__('re').search(pattern,c['classname']+' '+c['name'] if c['classname'] else c['name']) or __import__('re').search(pattern,c['name']) for c in passing)
 rows.append({'file':name,'pattern':pattern,'command':command,'exit':r.returncode,'validation_exit':v.returncode,'passing':len(passing),'scope_matches':scope});print(name,r.returncode,v.returncode,len(passing),scope,flush=True)
(task/'fs-original-scope.json').write_text(json.dumps(rows,indent=2)+'\n');sys.exit(0 if all(r['exit']==0 and r['validation_exit']==0 and r['scope_matches'] for r in rows) else 1)
