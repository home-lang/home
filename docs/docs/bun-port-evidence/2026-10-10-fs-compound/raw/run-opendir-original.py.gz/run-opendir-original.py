from pathlib import Path
import subprocess,os,json,sys
root=Path(__file__).resolve().parents[2];task=Path(__file__).resolve().parent;report=task/'opendir-original';name='js/node/test/parallel/test-fs-opendir.js'
env=os.environ.copy();env['HOME_BUN_CORPUS_REPORT_DIR']=str(report);env['BUN_DEBUG_QUIET_LOGS']='1'
for key in ['HOME_NATIVE_VM','HOME_CORPUS_FULL_VM','HOME_NATIVE_RUN']:env.pop(key,None)
command=[str(root/'zig-out/bin/home'),'test',str(root/'packages/runtime/test/test'/name)]
with (task/'opendir-original.log').open('wb') as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=240)
with (task/'opendir-original-validate.json').open('wb') as log:v=subprocess.run([sys.executable,'scripts/summarize-bun-corpus.py',str(report)],cwd=root,stdout=log,stderr=subprocess.STDOUT)
(task/'opendir-original-scope.json').write_text(json.dumps({'file':name,'command':command,'exit':r.returncode,'validation_exit':v.returncode},indent=2)+'\n');print(r.returncode,v.returncode);sys.exit(0 if r.returncode==0 and v.returncode==0 else 1)
