from pathlib import Path
import json,gzip,hashlib,subprocess,sys,re
root=Path(__file__).resolve().parents[2];task=Path(__file__).resolve().parent;base=root/'docs/docs/bun-port-evidence/2026-10-10-adapters-cluster-assert';base.mkdir(parents=True,exist_ok=True)
counts={};reports=[]
for path in sorted([*(task/'final').glob('validate-*.json'),*(task/'event-final').glob('validate-*.json')]):
 data=json.loads(path.read_text());assert data['successful'],path
 for key,value in data['summary'].items():
  if isinstance(value,int):counts[key]=counts.get(key,0)+value
 reports.append(path.name)
assert len(reports)==56
records=[]
def add(path,name):
 data=path.read_bytes();target=base/(name+'.gz');target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(gzip.compress(data,mtime=0));assert gzip.decompress(target.read_bytes())==data;records.append({'path':str(target.relative_to(base)),'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
for p in sorted(task.rglob('*')):
 if not p.is_file() or (p.name.startswith('issue-') or p.name=='archive-production.log') or 'manual-fixture' in p.parts or 'obsolete-cache-manifests' in p.parts:continue
 if p.suffix in ['.log','.json','.jsonl','.py','.stdout','.stderr','.xml']:
  add(p,'raw/'+str(p.relative_to(task)))
for name in json.loads((task/'ported-files.json').read_text()):add(root/'packages/runtime/upstream/src'/name,'source/packages/runtime/upstream/src/'+name)
for name in ['build-support/bundle-native-modules.ts','build-support/bundle-native-modules.test.ts','build-support/native_bindings.zig','packages/runtime/upstream/src/js/node/events.ts','packages/runtime/upstream/src/jsc/bindings/webcore/HomeAbortListenerState.h','tests/runtime/native-abort-listener.test.mjs']:add(root/name,'source/'+name)
manifest={'schema':1,'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'upstream':'4982b91e3702094330f3be3883354c52b8c01323','platform':'Darwin arm64','results':{'original_files':56,'counts':counts,'native_regression_groups':8,'debug_steps':34,'debug_peak_tree_mb':5641},'features':['Eighteen connected fetch/WebSocket, assertion, abort-listener, cluster and queue modules execute from Home-owned generation.','NodeFetch and Undici factories and native event registration/dispatch/removal compile from Home with exact header ABI/cache validation.', 'Node addAbortListener opts into native registration-level propagation resistance, removed with once/disposal/destruction; ordinary DOM propagation retains its behavior.','Twenty-five of twenty-eight selected implementation/header files match the Bun source pin exactly; three native event sources implement propagation resistance.'],'limitations':['The initial host ABI run has an incorrect test-side ThirdpartyWs enum spelling; the generator uses the correct ThirdpartyWS identity. Corrected final Home verification is retained separately.','The initial 51-file run retains an abort-listener process failure even though seven registered cases were reported passed. Final native propagation resistance clears the original mustCall mismatch. Source-path fixture failures, interrupted ABI runs and native compile failures remain without final passing credit.', 'Cluster SCHED_NONE is unfinished in the pin; adapter/native ownership is not complete API credit.','Full Bun-suite parity, remaining native/module dependencies and Release/ASAN/all-platform verification remain open under #66.'],'files':records}
(base/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(len(records),'verified archives',counts)
