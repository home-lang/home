from pathlib import Path
import json,gzip,hashlib,subprocess,tempfile,sys
root=Path(__file__).resolve().parents[2];base=root/'docs/docs/bun-port-evidence/2026-10-10-adapters-cluster-assert';m=json.loads((base/'manifest.json').read_text());rows=[]
with tempfile.TemporaryDirectory(prefix='home-adapters-evidence-') as name:
 out=Path(name)
 for r in m['files']:
  data=gzip.decompress((base/r['path']).read_bytes());assert len(data)==r['bytes'];assert hashlib.sha256(data).hexdigest()==r['sha256']
  if r['path'].startswith(('raw/final/','raw/event-final/')):
   p=out/r['path'][4:-3];p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
 for p in sorted([*(out/'final').glob('corpus-*'),*(out/'event-final').glob('corpus-*')]):
  if not p.is_dir():continue
  result=subprocess.run([sys.executable,str(root/'scripts/summarize-bun-corpus.py'),str(p)],capture_output=True,text=True);assert result.returncode==0,result.stdout;rows.append(p.name)
 assert len(rows)==56
print(json.dumps({'archives_verified':len(m['files']),'restored_reports':len(rows),'all_successful':True},indent=2))
