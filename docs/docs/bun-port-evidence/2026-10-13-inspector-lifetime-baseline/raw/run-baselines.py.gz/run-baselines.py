from pathlib import Path
import subprocess,sys,json,os
p=Path(__file__).resolve().parent;rows=[]
for name in ['notification-reference.mjs','collection-reference.mjs']:
 for runtime,command in [('node',['node','--expose-gc']),('home',['./zig-out/bin/home'])]:
  with (p/(runtime+'-'+name+'.log')).open('wb') as log:
   result=subprocess.run(command+[str(p/name)],env=os.environ.copy(),stdout=log,stderr=subprocess.STDOUT,timeout=30)
  rows.append({'runtime':runtime,'file':name,'exit':result.returncode});print(runtime,name,result.returncode,flush=True)
(p/'results.json').write_text(json.dumps(rows,indent=2)+'\n')
