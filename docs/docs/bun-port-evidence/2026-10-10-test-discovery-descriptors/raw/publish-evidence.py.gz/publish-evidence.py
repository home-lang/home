from pathlib import Path
import json,gzip,hashlib,subprocess,tempfile
root=Path.cwd();src=root/'zig-out/host-spawn-audit-2026-10-10';dest=root/'docs/docs/bun-port-evidence/2026-10-10-test-discovery-descriptors';dest.mkdir(parents=True,exist_ok=True)
batch=json.loads((src/'test-summary.json').read_text());assert all(r['exit']==0 for r in batch['records'])
assert '70 pass' in (src/'home-relative-abi.log').read_text()
assert 'EBADF' in (src/'scanner-baseline-executed.log').read_text()
assert 'Build Summary: 33/33 steps succeeded' in (src/'build-scanner.log').read_text()
counts={k:0 for k in ['passed','failed','skipped','todo','process_checks_passed','skipped_files']}
for i in range(1,4):
 result=json.loads((src/'final'/f'validate-{i}.json').read_text());assert result['successful']
 for key in counts:counts[key]+=result['summary'][key]
files=[]
def retain(data,name):
 p=dest/(name+'.gz');p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(gzip.compress(data,mtime=0));files.append({'path':str(p.relative_to(dest)),'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
for p in sorted(src.rglob('*')):
 if p.is_file() and p.suffix in ['.json','.jsonl','.log','.xml','.stdout','.stderr','.txt','.ts','.py','.mjs','.lldb']:retain(p.read_bytes(),'raw/'+str(p.relative_to(src)))
for name in ['packages/runtime/src/runtime/cli/test/Scanner.zig','tests/runtime/native-test-discovery.test.mjs']:retain((root/name).read_bytes(),'source/'+name)
audit=[]
for name in json.loads((src/'selection.json').read_text()):
 p=root/'packages/runtime/test/test'/name;original=Path('/Users/chris/Code/bun/test')/name
 assert p.read_bytes()==original.read_bytes(),name
 audit.append({'file':name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
manifest={'schema':1,'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'upstream':'4982b91e3702094330f3be3883354c52b8c01323','platform':'Darwin arm64','verification':{'debug_build_steps':33,'native_regression_groups':7,'abi_tests':70,'abi_assertions':1158,'directory_stress_count':11000,'original_files':3,'counts':counts,'build_peak_tree_mb':5684,'build_limit_mb':8192,'test_limit_mb':3840,'test_peak_tree_mb':545},'test_batch':batch,'original_source_audit':audit,'scope':'Discovery retains queued paths instead of directory descriptors. Cached directory traversal resets per read and preserves deduplication. Existing path filters, excludes, deadlines and ABI assertions are unchanged.','limitations':['The saved parent fails the 11,000-directory regression with EBADF; the failed relative-path ABI run is retained. An absolute-path parent ABI control passes all 70 tests but avoids the broad scan and is diagnostic evidence only.','Installed Bun and the selected Bun artifact are external tools, not rebuilt by this Home change. Their broad-scanner behavior is not claimed fixed.','Full Bun-suite parity, registry/native dependency ownership, original pending outcomes and Release/ASAN/all-platform verification remain unfinished.'],'files':files}
(dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for row in files:
 data=gzip.decompress((dest/row['path']).read_bytes());assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
with tempfile.TemporaryDirectory(prefix='home-scanner-evidence-') as temp:
 restored=Path(temp)
 for row in files:
  if row['path'].startswith('raw/final/corpus-'):
   p=restored/row['path'].removeprefix('raw/final/').removesuffix('.gz');p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(gzip.decompress((dest/row['path']).read_bytes()))
 for i in range(1,4):
  r=subprocess.run(['python3',str(root/'scripts/summarize-bun-corpus.py'),str(restored/f'corpus-{i}')],capture_output=True,text=True);assert r.returncode==0,(i,r.stdout,r.stderr)
print(json.dumps({'archives':len(files),'restored_reports':3,'counts':counts}))
