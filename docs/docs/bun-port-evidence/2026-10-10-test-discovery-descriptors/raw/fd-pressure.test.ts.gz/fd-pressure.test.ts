import {test,expect} from 'bun:test';
import {resolve} from 'node:path';
import {readdirSync} from 'node:fs';
test('native spawn options',()=>{const fds=readdirSync('/dev/fd').map(Number);console.log(JSON.stringify({fd_count:fds.length,max_fd:Math.max(...fds)}));
for(const executable of ['/bin/sh',process.execPath]) for(const timeout of [undefined,15000,60000]) {
 const argv=executable==='/bin/sh'?['-c','echo OUT;echo ERR >&2']:['-e','console.log("OUT");console.error("ERR")'];
 try {const r=Bun.spawnSync([executable,...argv],{cwd:resolve(import.meta.dir,'../..'),stdin:'ignore',stdout:'pipe',stderr:'pipe',...(timeout?{timeout}:{})});console.log(JSON.stringify({executable,timeout,exit:r.exitCode,out:r.stdout.toString(),err:r.stderr.toString()}));expect(r.exitCode).toBe(0);expect(r.stdout.toString()).toBe('OUT\n');expect(r.stderr.toString()).toBe('ERR\n')}catch(error){console.error(JSON.stringify({executable,timeout,error:String(error)}));throw error}
}
});
