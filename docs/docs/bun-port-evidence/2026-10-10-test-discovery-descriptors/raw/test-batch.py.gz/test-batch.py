from pathlib import Path
import subprocess,json,sys,os,hashlib
root=Path.cwd(); task=root/'zig-out/host-spawn-audit-2026-10-10'
assert 'Build Summary: 33/33 steps succeeded' in (task/'build-scanner.log').read_text()
exe=root/'zig-out/bin/home';env=os.environ.copy();env.update(HOME_NATIVE_VM='1',BUN_DEBUG_QUIET_LOGS='1')
commands=[('native-'+name,[str(exe),'run',str(root/'tests/runtime'/('native-'+name+'.test.mjs'))]) for name in ['test-discovery','stream-wrap','stream-cancellation','diagnostics-lifecycle','node-core-cli','spawn-sync-ipc','worker-fs-task-shutdown']]
commands += [('home-relative-abi',[str(exe),'test','build-support/bundle-native-modules.test.ts','build-support/native_module_abi.test.ts','build-support/core_builtin_abi.test.ts']),('corpus',[sys.executable,str(task/'run-corpus.py'),'final'])]
rows=[]
for name,command in commands:
 with (task/(name+'.log')).open('wb') as log:result=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=600)
 rows.append({'label':name,'command':command,'exit':result.returncode});print(name,result.returncode,flush=True)
(task/'test-summary.json').write_text(json.dumps({'executable_sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'records':rows},indent=2)+'\n')
sys.exit(0 if all(r['exit']==0 for r in rows) else 1)
