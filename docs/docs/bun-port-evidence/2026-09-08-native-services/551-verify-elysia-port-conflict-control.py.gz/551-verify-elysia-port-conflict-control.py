import hashlib,json,os,subprocess
from pathlib import Path
root=Path.cwd();ev=root/'zig-out/bun-port-recovery';out=ev/'elysia-port-conflict-control';out.mkdir();home=root/'zig-out/bin/home';bun=Path('/Users/chris/Code/bun/build/release/bun');vendor=root/'packages/runtime/test/vendor/elysia';source=vendor/'test/validator/response.test.ts'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(bun)=='47a87c1dea30da59c2733cce80118ea59bd338c616c6378f1c7f55e5f2b92c87'
first=json.loads((ev/'elysia-native-service-execution-first/manifest.json').read_text());assert first['counts']==dict(passed=1515,failed=1,skipped=0,todo=0) and first['sources_unchanged'] and first['home_unchanged']
manifest={'scope':'one unchanged original file on pinned Bun under the same occupied-port condition; diagnostic only, not full-suite or Home pass credit','bun_sha256':sha(bun),'home_coordinator_sha256':sha(home),'source_sha256':sha(source),'attempts':1,'home_first_full_run_counts':first['counts']}
for phase in ['before']:(out/(phase+'-listener.txt')).write_bytes(subprocess.check_output(['lsof','-nP','-iTCP:3000','-sTCP:LISTEN']))
assert b'28404' in (out/'before-listener.txt').read_bytes()
env=os.environ.copy();env.update(CI='1',HOME_BUN_TEST_EXECUTABLE=str(bun),HOME_BUN_CORPUS_REPORT_DIR=str(out/'reports'))
argv=[str(home),'test','--bun-corpus-prepared-vendor','elysia','validator/response.test.ts'];manifest['argv']=argv
with (out/'stdout').open('xb') as f,(out/'stderr').open('xb') as e:code=subprocess.run(argv,cwd=root,env=env,stdin=subprocess.DEVNULL,stdout=f,stderr=e).returncode
with (out/'summary.json').open('xb') as f:valid=subprocess.run(['python3','scripts/summarize-bun-corpus.py',str(out/'reports')],stdout=f).returncode
summary=json.loads((out/'summary.json').read_text());(out/'after-listener.txt').write_bytes(subprocess.check_output(['lsof','-nP','-iTCP:3000','-sTCP:LISTEN']))
error=(out/'reports/000000.stderr').read_text();events=[json.loads(s) for s in (out/'reports/events.jsonl').read_text().splitlines()];started=next(x for x in events if x['event']=='started')
manifest.update(returncode=code,validator_returncode=valid,counts=summary['counts'],errors=summary['errors'],source_unchanged=sha(source)==manifest['source_sha256'],executables_unchanged=sha(bun)==manifest['bun_sha256'] and sha(home)==manifest['home_coordinator_sha256'],same_listener_present=b'28404' in (out/'after-listener.txt').read_bytes(),eaddrinuse='EADDRINUSE' in error,pinned_bun_executed=started['executable_sha256']==manifest['bun_sha256'])
manifest['verified']=code==1 and valid==1 and summary['counts']==dict(passed=27,failed=1,skipped=0,todo=0) and not summary['errors'] and all(manifest[x] for x in ['source_unchanged','executables_unchanged','same_listener_present','eaddrinuse','pinned_bun_executed'])
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(manifest,indent=2));raise SystemExit(0 if manifest['verified'] else 1)
