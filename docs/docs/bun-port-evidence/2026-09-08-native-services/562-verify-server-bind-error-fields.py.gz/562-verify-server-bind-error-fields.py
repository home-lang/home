import hashlib,json,os,subprocess
from pathlib import Path
root=Path.cwd();ev=root/'zig-out/bun-port-recovery';out=ev/'server-bind-error-fields';out.mkdir()
source="try{const s=Bun.serve({port:3000,fetch(){return new Response('probe')}});s.stop(true);console.log(JSON.stringify({unexpectedly_listened:true}));process.exitCode=1}catch(e){const result={};for(const k of ['name','message','code','errno','syscall','address','port'])result[k]=e[k]??null;console.log(JSON.stringify(result))}"
(out/'probe.js').write_text(source);manifest={'scope':'private occupied-port error-object comparison, no corpus-case credit','port':3000,'runs':[]}
for name,binary in [('home',root/'zig-out/bin/home'),('bun',Path('/Users/chris/Code/bun/build/release/bun'))]:
 listeners=subprocess.check_output(['lsof','-nP','-iTCP:3000','-sTCP:LISTEN']);assert b'28404' in listeners;(out/(name+'-listener.txt')).write_bytes(listeners)
 env=os.environ.copy();env['HOME_NATIVE_VM']='1';r=subprocess.run([str(binary),'-e',source],env=env,cwd=root,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE);(out/(name+'.stdout')).write_bytes(r.stdout);(out/(name+'.stderr')).write_bytes(r.stderr);fields=json.loads(r.stdout);assert r.returncode==0 and not fields.get('unexpectedly_listened')
 manifest['runs'].append({'runtime':name,'executable':str(binary),'sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'returncode':r.returncode,'fields':fields})
manifest['different_fields']={key:{r['runtime']:r['fields'][key] for r in manifest['runs']} for key in manifest['runs'][0]['fields'] if manifest['runs'][0]['fields'][key]!=manifest['runs'][1]['fields'][key]};(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(manifest,indent=2))
