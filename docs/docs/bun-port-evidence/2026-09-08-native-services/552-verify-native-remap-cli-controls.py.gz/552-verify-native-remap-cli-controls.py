import hashlib,json,os,subprocess,tempfile,time
from pathlib import Path
root=Path.cwd();ev=root/'zig-out/bun-port-recovery';out=ev/'native-remap-cli-controls';out.mkdir();home=root/'zig-out/bin/home'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert 'Build Summary: 23/23 steps succeeded' in (ev/'build-service-vendor-preparation-space-verified.log').read_text()
manifest={'scope':'private native CLI failure/lifetime controls; zero original corpus cases','home_sha256':sha(home),'runs':[]}
def save():(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tempfile.TemporaryDirectory(prefix='home-remap-controls-') as temporary:
 for name,source,flag in [('invalid-port',"console.log('invalid');setInterval(()=>{},1000)",'invalid_readiness'),('eof-deadline',"require('fs').closeSync(1);require('fs').closeSync(2);setInterval(()=>{},1000)",'timed_out'),('unexpected-exit',"console.log('54321');setTimeout(()=>process.exit(7),250)",'unexpected_exit')]:
  cwd=Path(temporary)/name;project=cwd/'packages/runtime/test';package=project/'node_modules/bun-tracestrings';(package/'bin').mkdir(parents=True);(project/'test').mkdir()
  (project/'test/UPSTREAM_SHA.txt').write_text('a'*40+'\n');(project/'package.json').write_text(json.dumps({'name':'private-remap','scripts':{'ci-remap-server':'bun node_modules/bun-tracestrings/bin/ci-remap-server.ts'}}));(package/'package.json').write_text('{"name":"bun-tracestrings"}');entry=package/'bin/ci-remap-server.ts';entry.write_text(source)
  env=os.environ.copy();env.update(HOME_BUN_TEST_EXECUTABLE=str(home),HOME_BUN_CORPUS_REPORT_DIR=str(out/(name+'-reports')))
  start=time.monotonic();child=subprocess.Popen([str(home),'test','--bun-corpus-remap'],cwd=cwd,env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  # Keep stdin open throughout: EOF must not manufacture owner shutdown.
  try:code=child.wait(timeout=15)
  except subprocess.TimeoutExpired:child.kill();child.wait();raise
  stdout,stderr=child.communicate();(out/(name+'.stdout')).write_bytes(stdout);(out/(name+'.stderr')).write_bytes(stderr)
  elapsed=time.monotonic()-start
  with (out/(name+'-summary.json')).open('xb') as f:valid=subprocess.run(['python3',str(root/'scripts/summarize-bun-corpus.py'),str(out/(name+'-reports'))],stdout=f).returncode
  summary=json.loads((out/(name+'-summary.json')).read_text());events=[json.loads(line) for line in (out/(name+'-reports/events.jsonl')).read_text().splitlines()];done=next(x for x in events if x['event']=='service_completed')
  result={'name':name,'returncode':code,'seconds':elapsed,'validator_returncode':valid,'outcome':done,'verified':code!=0 and valid==1 and not summary['errors'] and done[flag] and not done['stopped_by_owner'] and done['output_complete'] and done['source_unchanged'] and summary['counts']==dict(passed=0,failed=0,skipped=0,todo=0)}
  if name=='eof-deadline':result['verified'] &= elapsed>=4.9
  if name=='unexpected-exit':result['verified'] &= done['term']==dict(exited=7) and done['ready']
  manifest['runs'].append(result);save();assert result['verified'],result
manifest['verified']=len(manifest['runs'])==3 and all(r['verified'] for r in manifest['runs']) and sha(home)==manifest['home_sha256'];save();print(json.dumps(manifest,indent=2))
