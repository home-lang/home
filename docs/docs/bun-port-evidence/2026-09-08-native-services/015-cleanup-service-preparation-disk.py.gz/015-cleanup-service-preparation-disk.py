from pathlib import Path
import json,hashlib,shutil,subprocess,shlex
root=Path.cwd();ev=root/'zig-out/bun-port-recovery';out=ev/'service-preparation-disk-recovery-cleanup.json';assert not out.exists()
args=shlex.split((root/'.zig-cache/args/0f6aacecb822969a441912bb4277318cf69143fdf2040818a960a50a1309a213').read_text())
paths=[Path('/Users/chris/.bun/install/cache'),Path('/Users/chris/Code/bun/build/release/rust-target'),Path('/Users/chris/Code/bun/build/release/bun-profile.dSYM'),root/'.zig-cache/o/652f2bd1fe9b490e09b3fb02e8adda8f',root/'.zig-cache/o/2e5758fd1fe481b4652bbe98f398ab84']
protected=[root/'zig-out/bin/home',Path('/Users/chris/Code/bun/build/release/bun'),root/'.native/liblolhtml.a']
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
manifest={'protected':{str(p):sha(p) for p in protected},'removed':[],'reason':'generated package cache and unused Rust build/profile outputs; source, current binaries and linked native inputs retained','first_cleanup_preflight':'stopped before deletion because bun-profile.dSYM is a regular file, not a directory; subsequent build admission was refused'}
for p in paths:
 assert p.exists() and not p.is_symlink()
 assert not any(str(p) in arg for arg in args)
 if str(p).startswith(str(root)):assert not subprocess.check_output(['git','ls-files','--',str(p)])
 if str(p).startswith('/Users/chris/Code/bun/'):assert not subprocess.check_output(['git','-C','/Users/chris/Code/bun','ls-files','--',str(p)])
 files=[f for f in p.rglob('*') if f.is_file() and not f.is_symlink()] if p.is_dir() else [p]
 manifest['removed'].append({'path':str(p),'bytes':sum(f.stat().st_size for f in files),'files':len(files),'kind':'directory' if p.is_dir() else 'file'})
manifest['bytes_removed']=sum(x['bytes'] for x in manifest['removed']);out.write_text(json.dumps(manifest,indent=2)+'\n')
for p in paths:
 if p.is_dir():shutil.rmtree(p)
 else:p.unlink()
for p in protected:assert sha(p)==manifest['protected'][str(p)]
print(json.dumps(manifest,indent=2))
