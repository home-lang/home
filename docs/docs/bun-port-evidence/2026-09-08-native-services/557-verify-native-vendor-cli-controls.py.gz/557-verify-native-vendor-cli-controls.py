import hashlib,json,os,subprocess,tempfile
from pathlib import Path
root=Path.cwd();ev=root/'zig-out/bun-port-recovery';out=ev/'native-vendor-cli-controls';out.mkdir();home=root/'zig-out/bin/home'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert 'Build Summary: 23/23 steps succeeded' in (ev/'build-service-vendor-preparation-space-verified.log').read_text()
manifest={'scope':'private native vendor CLI installation/build failure controls; zero original test cases','home_sha256':sha(home),'runs':[]}
def save():(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tempfile.TemporaryDirectory(prefix='home-vendor-cli-controls-') as temporary:
 for failing in ['install','build']:
  cwd=Path(temporary)/failing;source=cwd/'source';(source/'test').mkdir(parents=True);project=cwd/'packages/runtime/test';(project/'test').mkdir(parents=True)
  (source/'package.json').write_text(json.dumps({'name':'private-vendor','scripts':{'postinstall':'bun hook.js install','build':'bun hook.js build'}}))
  (source/'test/control.test.js').write_text("throw new Error('preparation must not execute tests')")
  (source/'hook.js').write_text("const fs=require('fs'),assert=require('assert');assert.equal(fs.realpathSync(Bun.which('node')),fs.realpathSync(process.execPath));const operation=process.argv[2];fs.writeFileSync(operation+'.marker',process.env.BUN_INSTALL_CACHE_DIR);if(operation==="+json.dumps(failing)+")process.exit(7);")
  with (out/(failing+'-git.log')).open('xb') as f:
   for args in [['init'],['add','.'],['-c','user.name=Home Test Fixture','-c','user.email=fixture@example.invalid','commit','-m','test: native vendor CLI control'],['tag','v1']]:subprocess.run(['git',*args],cwd=source,stdout=f,stderr=subprocess.STDOUT,check=True)
  (project/'test/vendor.json').write_text(json.dumps([{'package':'private-vendor','repository':source.as_uri(),'tag':'v1'}]))
  report=out/(failing+'-reports');env=os.environ.copy();env.update(HOME_BUN_TEST_EXECUTABLE=str(home),HOME_BUN_CORPUS_REPORT_DIR=str(report))
  with (out/(failing+'.stdout')).open('xb') as f,(out/(failing+'.stderr')).open('xb') as e:code=subprocess.run([str(home),'test','--bun-corpus-prepare-vendor','private-vendor'],cwd=cwd,env=env,stdin=subprocess.DEVNULL,stdout=f,stderr=e).returncode
  with (out/(failing+'-summary.json')).open('xb') as f:valid=subprocess.run(['python3',str(root/'scripts/summarize-bun-corpus.py'),str(report)],stdout=f).returncode
  summary=json.loads((out/(failing+'-summary.json')).read_text());events=[json.loads(line) for line in (report/'events.jsonl').read_text().splitlines()];completed=[x for x in events if x['event']=='completed'];assert completed[-1]['term']==dict(exited=7)
  expected_completed=6 if failing=='install' else 7
  vendor=project/'vendor/private-vendor';markers=[]
  for name in ['install'] if failing=='install' else ['install','build']:
   cache=Path((vendor/(name+'.marker')).read_text());markers.append({'operation':name,'temporary_cache':str(cache),'removed':not cache.exists()});assert not cache.exists()
  if failing=='install':assert not (vendor/'build.marker').exists() and [x['path'] for x in summary['unstarted']]==['build']
  else:assert not summary['errors'] and summary['unstarted']==[]
  result={'failing_operation':failing,'returncode':code,'validator_returncode':valid,'completed':len(completed),'unstarted':summary['unstarted'],'validation_errors':summary['errors'],'markers':markers,'verified':code!=0 and valid==1 and len(completed)==expected_completed and all(x['output_complete'] and x['source_unchanged'] for x in completed) and summary['counts']==dict(passed=0,failed=0,skipped=0,todo=0)}
  manifest['runs'].append(result);save();assert result['verified']
manifest['verified']=len(manifest['runs'])==2 and all(r['verified'] for r in manifest['runs']) and sha(home)==manifest['home_sha256'];save();print(json.dumps(manifest,indent=2))
