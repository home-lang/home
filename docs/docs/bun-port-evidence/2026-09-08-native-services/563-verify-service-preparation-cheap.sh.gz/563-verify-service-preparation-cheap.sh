set -eu
python3 scripts/test_summarize_bun_corpus.py
/Users/chris/Code/Home/lang/pantry/.bin/zig test packages/home_test/src/corpus_journal.zig
python3 scripts/sync-bun-test-setup.py --check > zig-out/bun-port-recovery/service-preparation-pin-check.log
/Users/chris/.local/share/pantry/global/bin/bunx --bun pickier docs/docs/bun-corpus-selection.md docs/docs/bun-corpus-outcomes.md scripts/summarize-bun-corpus.py scripts/test_summarize_bun_corpus.py src/main.zig packages/home_test/src/corpus_service.zig packages/home_test/src/corpus_remap.zig packages/home_test/src/corpus_vendor_prepare.zig packages/home_test/src/corpus_child_wait.zig packages/home_test/src/corpus_journal.zig packages/home_test/src/corpus_setup.zig packages/home_test/src/adapters/jsc_bootstrap.zig packages/home_test/src/home_test.zig packages/home_test/src/test_root.zig > zig-out/bun-port-recovery/service-preparation-pickier.log 2>&1
/Users/chris/Code/Home/lang/pantry/.bin/zig fmt --check src/main.zig packages/home_test/src/corpus_service.zig packages/home_test/src/corpus_remap.zig packages/home_test/src/corpus_vendor_prepare.zig packages/home_test/src/corpus_child_wait.zig packages/home_test/src/corpus_journal.zig packages/home_test/src/corpus_setup.zig packages/home_test/src/adapters/jsc_bootstrap.zig packages/home_test/src/home_test.zig packages/home_test/src/test_root.zig
git diff --check
