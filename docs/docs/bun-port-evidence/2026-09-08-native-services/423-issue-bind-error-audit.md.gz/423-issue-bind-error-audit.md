Parent #66; discovered during the native service/vendor preparation work in #724.

A private error-object comparison on macOS 27 arm64, with an existing listener on port 3000, shows an observable difference between Home and pinned Bun. Both reject the bind with `code: "EADDRINUSE"`, `name: "Error"`, and `syscall: "listen"`.

| Field | Home | Pinned Bun |
| --- | --- | --- |
| message | EADDRINUSE: address already in use, listen | Failed to start server. Is port 3000 in use? |
| errno | -48 | 0 |
| address | 0.0.0.0 | absent |
| port | 3000 | absent |

Home SHA256: `91d6b1024f9d4c02c6b7f9089b476d8a0646294f4ed7392e5e3ce549e52db763`. Pinned Bun source: `4982b91e3702094330f3be3883354c52b8c01323`; executable SHA256: `47a87c1dea30da59c2733cce80118ea59bd338c616c6378f1c7f55e5f2b92c87`.

The existing Home implementation in `packages/runtime/src/runtime/server/server.zig:onListenFailed` deliberately preserves the OS errno and adds TCP address/port metadata. Its `normalizeListenErrno` regression preserves ACCES and uses ADDRINUSE only when the OS did not supply an error. Audit the pinned API contract and original bind-error fixtures before changing this behavior; do not regress concrete permission/address errors merely to copy a generic message.

The original Elysia `test/validator/response.test.ts` case `handle distinct union` calls `.listen(3000)`. It fails in both runtimes while the unrelated PredictHQ development server owns that port. Home's complete 129-file run retained 1,515 passes and one failure; pinned Bun's separate original-file diagnostic retained 27 passes and one failure. The listener and test were not modified, and these results are not a passing full-suite claim. The field comparison is a separate API compatibility audit, not a workaround for the occupied-port failure.

- [ ] Audit pinned Bun's occupied TCP, invalid address, permission and Unix socket failure contracts.
- [ ] Resolve and test the intended error-object compatibility while preserving real OS failures.
- [ ] Revalidate applicable unchanged upstream error fixtures and retain native platform boundaries.

Evidence will be linked from the native service/preparation checkpoint under #724.
