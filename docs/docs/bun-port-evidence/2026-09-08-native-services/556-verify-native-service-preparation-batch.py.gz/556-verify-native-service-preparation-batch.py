import json,subprocess
from pathlib import Path
root=Path.cwd();ev=root/'zig-out/bun-port-recovery';rows=[]
assert 'Build Summary: 23/23 steps succeeded' in (ev/'build-service-vendor-preparation-space-verified.log').read_text()
for name in ['verify-native-vendor-cli-controls.py','verify-native-remap-cli-controls.py','verify-native-remap-cli-first.py','verify-native-vendor-preparation-first.py','verify-elysia-native-service-execution-first.py']:
 with (ev/(name+'.log')).open('xb') as f:code=subprocess.run(['python3',str(ev/name)],cwd=root,stdout=f,stderr=subprocess.STDOUT).returncode
 rows.append({'script':name,'returncode':code});(ev/'native-service-preparation-batch.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,code,flush=True)
 if code:raise SystemExit(code)
