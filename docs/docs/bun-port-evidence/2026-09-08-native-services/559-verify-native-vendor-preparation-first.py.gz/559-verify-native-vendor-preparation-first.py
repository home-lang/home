import hashlib,json,os,subprocess,time,shutil
from pathlib import Path
root=Path.cwd();ev=root/'zig-out/bun-port-recovery';out=ev/'native-vendor-preparation-first';out.mkdir()
home=root/'zig-out/bin/home';vendor=root/'packages/runtime/test/vendor/elysia'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert 'Build Summary: 23/23 steps succeeded' in (ev/'build-service-vendor-preparation-space-verified.log').read_text()
previous=json.loads((ev/'elysia-native-setup-execution-first/manifest.json').read_text());protected=previous['protected_vendor_sources'];pin='56310be9617b826f862c985eae95ae823d95f097'
assert all(sha(vendor/p)==h for p,h in protected.items())
assert subprocess.check_output(['git','-C',str(vendor),'rev-parse','HEAD'],text=True).strip()==pin
assert subprocess.check_output(['git','-C',str(vendor),'status','--porcelain','--untracked-files=all'],text=True)==' M bun.lock\n'
assert not subprocess.check_output(['git','ls-files','--',str(vendor)])
manifest={'scope':'fresh native clone, pinned checkout, install and build; zero corpus case credit','home_sha256':sha(home),'attempts':1,'vendor_revision':pin,'protected_prior_sources':protected,'cleanup':{'path':str(vendor),'bytes':sum(p.stat().st_size for p in vendor.rglob('*') if p.is_file() and not p.is_symlink())}}
def save():(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
save();shutil.rmtree(vendor);assert not vendor.exists()
argv=[str(home),'test','--bun-corpus-prepare-vendor','elysia'];env=os.environ.copy();env.update(HOME_BUN_TEST_EXECUTABLE=str(home),HOME_BUN_CORPUS_REPORT_DIR=str(out/'reports'))
manifest.update(status='started',argv=argv);save();start=time.monotonic()
with (out/'stdout').open('xb') as f,(out/'stderr').open('xb') as e:code=subprocess.run(argv,cwd=root,env=env,stdin=subprocess.DEVNULL,stdout=f,stderr=e).returncode
manifest.update(status='completed',returncode=code,seconds=time.monotonic()-start,home_unchanged=sha(home)==manifest['home_sha256']);save()
with (out/'summary.json').open('xb') as f,(out/'validator.stderr').open('xb') as e:valid=subprocess.run(['python3','scripts/summarize-bun-corpus.py',str(out/'reports')],stdout=f,stderr=e).returncode
summary=json.loads((out/'summary.json').read_text());actual={p:sha(vendor/p) for p in protected if (vendor/p).is_file()};manifest.update(validator_returncode=valid,post_setup_sources=actual,post_setup_matches_previous_native_and_pinned_bun_lock_control=actual==protected,verified=code==0 and valid==0 and summary['completed']==7 and summary['counts']==dict(passed=0,failed=0,skipped=0,todo=0) and actual==protected and manifest['home_unchanged']);save();print(json.dumps({k:v for k,v in manifest.items() if k not in ['protected_prior_sources','post_setup_sources']},indent=2));raise SystemExit(0 if manifest['verified'] else 1)
