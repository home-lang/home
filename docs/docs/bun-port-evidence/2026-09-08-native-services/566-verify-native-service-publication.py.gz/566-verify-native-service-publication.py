import gzip,hashlib,importlib.util,json,subprocess,tempfile
from pathlib import Path
root=Path.cwd();folder=root/'docs/docs/bun-port-evidence/2026-09-08-native-services';manifest=json.loads((folder/'manifest.json').read_text());tracked=set(subprocess.check_output(['git','ls-files'],text=True).splitlines())
spec=importlib.util.spec_from_file_location('outcomes',root/'scripts/summarize-bun-corpus.py');validator=importlib.util.module_from_spec(spec);spec.loader.exec_module(validator)
labels={'remap':'native-remap-cli-first/reports/','preparation':'native-vendor-preparation-first/reports/','vendor':'elysia-native-service-execution-first/reports/','pinned-bun':'elysia-port-conflict-control/reports/'}
for name in ['invalid-port','eof-deadline','unexpected-exit']:labels[name]='native-remap-cli-controls/'+name+'-reports/'
for name in ['install','build']:labels[name+'-failure']='native-vendor-cli-controls/'+name+'-reports/'
with tempfile.TemporaryDirectory(prefix='home-service-publication-') as tmp:
 target=Path(tmp)
 for entry in manifest['files']:
  path=folder/entry['artifact'];assert str(path.relative_to(root)) in tracked;data=gzip.decompress(path.read_bytes());assert len(data)==entry['bytes'] and hashlib.sha256(data).hexdigest()==entry['sha256']
  for label,prefix in labels.items():
   prefix='zig-out/bun-port-recovery/'+prefix
   if entry['source'].startswith(prefix):
    name=entry['source'][len(prefix):];assert Path(name).name==name;(target/label).mkdir(exist_ok=True);(target/label/name).write_bytes(data)
 results={label:validator.summarize(target/label) for label in labels}
 for label,r in results.items():
  if label!='install-failure':assert not r['errors'],(label,r['errors'])
  assert r['successful']==(label in ['remap','preparation']),label
 assert results['vendor']['counts']==dict(passed=1515,failed=1,skipped=0,todo=0) and results['vendor']['completed']==129
 assert results['pinned-bun']['counts']==dict(passed=27,failed=1,skipped=0,todo=0) and results['pinned-bun']['completed']==1
 assert results['preparation']['completed']==7 and results['remap']['completed']==1
 assert [x['path'] for x in results['install-failure']['unstarted']]==['build']
 print(json.dumps({'tracked_artifacts_verified':len(manifest['files']),'restored':{label:{'successful':r['successful'],'completed':r['completed'],'counts':r['counts'],'unstarted':r['unstarted'],'errors':r['errors']} for label,r in results.items()}},indent=2))
