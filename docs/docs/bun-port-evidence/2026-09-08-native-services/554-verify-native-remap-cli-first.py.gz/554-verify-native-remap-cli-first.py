import hashlib,json,os,selectors,signal,subprocess,time,urllib.request,urllib.error
from pathlib import Path
root=Path.cwd();ev=root/'zig-out/bun-port-recovery';out=ev/'native-remap-cli-first';out.mkdir()
home=root/'zig-out/bin/home';project=root/'packages/runtime/test';package=project/'node_modules/bun-tracestrings'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
build=ev/'build-service-vendor-preparation-space-verified.log'
assert 'Build Summary: 23/23 steps succeeded' in build.read_text()
files={str(p.relative_to(package)):sha(p) for p in package.rglob('*') if p.is_file() and 'node_modules' not in p.relative_to(package).parts}
assert files
owned_db=[project/name for name in ['bun-remap.db','bun-remap.db-wal','bun-remap.db-shm','bun-remap.db-journal']];assert not any(p.exists() for p in owned_db)
manifest={'scope':'native remap CLI lifetime and original dependency protocol; zero corpus cases','home_sha256':sha(home),'dependency_source_sha256':files,'attempts':1,'checks':[],'preparation_reference':'native-setup-first/manifest.json','startup_deadline_ms':5000}
def save():(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
env=os.environ.copy();env.update(CI='1',HOME_BUN_TEST_EXECUTABLE=str(home),HOME_BUN_CORPUS_REPORT_DIR=str(out/'reports'))
argv=[str(home),'test','--bun-corpus-remap'];manifest.update(argv=argv,status='started');save()
child=subprocess.Popen(argv,cwd=root,env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
selector=selectors.DefaultSelector();selector.register(child.stdout,selectors.EVENT_READ,'stdout');selector.register(child.stderr,selectors.EVENT_READ,'stderr');stdout=b'';stderr=b'';port=None;start=time.monotonic()
try:
 # CLI initialization and executable hashing precede the journaled original
 # five-second child startup deadline. This outer bound is a driver bound.
 while port is None and time.monotonic()-start<15 and child.poll() is None:
  for key,_ in selector.select(max(0,15-(time.monotonic()-start))):
   data=os.read(key.fileobj.fileno(),65536)
   if not data:selector.unregister(key.fileobj);continue
   if key.data=='stdout':stdout+=data
   else:stderr+=data
  for line in stdout.splitlines():
   if line.isdigit():port=int(line);break
 manifest.update(port=port,cli_ready_seconds=time.monotonic()-start);save();assert port is not None and 0<port<65536,'native remap did not become ready'
 def request(path):
  try:
   with urllib.request.urlopen(f'http://127.0.0.1:{port}'+path,timeout=5) as response:return response.status,response.read().decode()
  except urllib.error.HTTPError as error:return error.code,error.read().decode()
 for path,expected in [('/traces',(200,'[]')),('/unknown',(404,'Not found')),('/invalid-trace/ack',(200,'ok'))]:
  actual=request(path);manifest['checks'].append({'path':path,'actual':actual,'passed':actual==expected});save();assert actual==expected
 status,body=request('/traces');assert status==200 and json.loads(body)==[{'failed_parse':'invalid-trace'}]
 manifest['checks'].append({'path':'/traces','body':json.loads(body),'passed':True});assert request('/traces')==(200,'[]');manifest['checks'].append({'path':'/traces','consumed_once':True,'passed':True});manifest['protocol_succeeded']=True
except Exception as error:manifest.update(protocol_succeeded=False,error=str(error))
finally:
 selector.close();child.stdin.close();child.stdin=None
 try:extra_out,extra_err=child.communicate(timeout=10)
 except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);extra_out,extra_err=child.communicate();manifest['forced_parent_cleanup']=True
 stdout+=extra_out;stderr+=extra_err;(out/'stdout').write_bytes(stdout);(out/'stderr').write_bytes(stderr)
 manifest.update(status='completed',returncode=child.returncode,home_unchanged=sha(home)==manifest['home_sha256'],sources_unchanged=all(sha(package/p)==h for p,h in files.items()),owned_generated_cleanup=[])
 for p in owned_db:
  if p.exists():manifest['owned_generated_cleanup'].append({'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)});p.unlink()
 save()
with (out/'summary.json').open('xb') as f,(out/'validator.stderr').open('xb') as e:valid=subprocess.run(['python3','scripts/summarize-bun-corpus.py',str(out/'reports')],stdout=f,stderr=e).returncode
summary=json.loads((out/'summary.json').read_text());manifest.update(validator_returncode=valid,verified=valid==0 and child.returncode==0 and manifest.get('protocol_succeeded') and manifest['sources_unchanged'] and manifest['home_unchanged'] and not manifest.get('forced_parent_cleanup') and summary['counts']==dict(passed=0,failed=0,skipped=0,todo=0));save();print(json.dumps({k:v for k,v in manifest.items() if k!='dependency_source_sha256'},indent=2));raise SystemExit(0 if manifest['verified'] else 1)
