from pathlib import Path
import base64,json,sys,xml.etree.ElementTree as ET
p=Path(sys.argv[1]);cases=list(ET.parse(p/'control.xml').getroot().iter('testcase'));meta=[json.loads(l) for l in (p/'control.cases.jsonl').read_text().splitlines() if json.loads(l).get('event')!='terminal'];assert len(cases)==len(meta)==5
for case,row in zip(cases,meta):
 for key in ['name','classname','file']:
  value=case.get('bun-'+key+'-base64');original=base64.b64decode(value,validate=True).decode() if value is not None else case.get(key);assert original==row[key],(key,original,row[key])
assert sum(c.find('skipped') is None for c in cases)==3
assert sum(c.find('skipped') is not None for c in cases)==2
print(json.dumps({'cases':5,'passed':3,'skipped_or_todo':2,'identities_exact':True,'xml_valid':True}))
