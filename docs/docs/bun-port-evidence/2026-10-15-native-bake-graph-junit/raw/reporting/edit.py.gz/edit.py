from pathlib import Path
p=Path('packages/runtime/src/runtime/cli/test_command.zig');s=p.read_text()
s=s.replace('''        const c = str[i];
        switch (c) {''','''        const c = str[i];
        // XML 1.0 also forbids the Unicode noncharacters U+FFFE/U+FFFF.
        if (i + 2 < len and c == 0xef and str[i + 1] == 0xbf and (str[i + 2] == 0xbe or str[i + 2] == 0xbf)) {
            if (i > last) try writer.writeAll(str[last..i]);
            try writer.writeAll("&#xFFFD;");
            i += 2;
            last = i + 1;
            continue;
        }
        switch (c) {''',1)
s=s.replace('''                try writer.print("&#{d};", .{c});''','''                if (c == '\\t' or c == '\\n' or c == '\\r') {
                    try writer.print("&#{d};", .{c});
                } else {
                    // Numeric references cannot make forbidden XML chars legal.
                    try writer.writeAll("&#xFFFD;");
                }''',1)
needle='fn appendPrint(list: *std.ArrayListUnmanaged(u8), comptime fmt: []const u8, args: anytype) !void {'
helper='''fn hasInvalidXmlChar(value: string) bool {
    for (value) |byte| if (byte < 0x20 and byte != '\\t' and byte != '\\n' and byte != '\\r') return true;
    return std.mem.indexOf(u8, value, "\\xef\\xbf\\xbe") != null or std.mem.indexOf(u8, value, "\\xef\\xbf\\xbf") != null;
}

// Exact identities remain recoverable when their display form cannot be XML.
// The JSON case journal keeps the same original bytes; its validator compares
// this capsule, the XML display name, and the journal independently.
fn appendRawXmlIdentity(list: *std.ArrayListUnmanaged(u8), comptime key: []const u8, value: string) !void {
    if (!hasInvalidXmlChar(value)) return;
    const encoder = std.base64.standard.Encoder;
    const buffer = try bun.default_allocator.alloc(u8, encoder.calcSize(value.len));
    defer bun.default_allocator.free(buffer);
    const encoded = encoder.encode(buffer, value);
    try list.appendSlice(bun.default_allocator, " bun-" ++ key ++ "-base64=\\\"");
    try list.appendSlice(bun.default_allocator, encoded);
    try list.appendSlice(bun.default_allocator, "\\\"");
}

'''
assert needle in s;s=s.replace(needle,helper+needle,1)
a=s.index('    pub fn writeTestCase(');b=s.index('\n    pub fn ',a+25);chunk=s[a:b];needle='''        try appendEscapedXml(&this.contents, file);
        try this.contents.appendSlice(bun.default_allocator, "\\\"");''';assert needle in chunk;chunk=chunk.replace(needle,needle+'''
        try appendRawXmlIdentity(&this.contents, "name", name);
        try appendRawXmlIdentity(&this.contents, "classname", class_name);
        try appendRawXmlIdentity(&this.contents, "file", file);''',1);s=s[:a]+chunk+s[b:];p.write_text(s)
p=Path('scripts/summarize-bun-corpus.py');s=p.read_text().replace('import argparse\n','import argparse\nimport base64\nimport binascii\n',1);anchor='def digest(path):';helper='''def xml_identity_display(value):
    return ''.join(character if (character in '\\t\\n\\r' or
                   0x20 <= ord(character) <= 0xD7FF or
                   0xE000 <= ord(character) <= 0xFFFD or
                   0x10000 <= ord(character) <= 0x10FFFF) else '\\ufffd'
                   for character in value)


''';s=s.replace(anchor,helper+anchor,1)
old='''                                    for key in ('name', 'classname', 'file'):
                                        check(detail.get(key) == case.get(key), f'{identity}: case metadata {key} mismatch')'''
new='''                                    for key in ('name', 'classname', 'file'):
                                        encoded_identity = case.get('bun-' + key + '-base64')
                                        if encoded_identity is None:
                                            check(detail.get(key) == case.get(key), f'{identity}: case metadata {key} mismatch')
                                            continue
                                        try:
                                            raw_identity = base64.b64decode(encoded_identity, validate=True)
                                            original_identity = raw_identity.decode('utf-8')
                                            check(base64.b64encode(raw_identity).decode('ascii') == encoded_identity,
                                                  f'{identity}: noncanonical encoded {key}')
                                            check(xml_identity_display(original_identity) != original_identity,
                                                  f'{identity}: unnecessary encoded {key}')
                                            check(original_identity == detail.get(key), f'{identity}: encoded case metadata {key} mismatch')
                                            check(xml_identity_display(original_identity) == case.get(key),
                                                  f'{identity}: encoded {key} display mismatch')
                                        except (ValueError, UnicodeError, binascii.Error):
                                            check(False, f'{identity}: invalid encoded {key}')''';assert old in s;s=s.replace(old,new,1);p.write_text(s)
