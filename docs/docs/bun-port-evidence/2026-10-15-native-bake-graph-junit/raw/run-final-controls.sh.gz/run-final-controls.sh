#!/bin/sh
set -u
p=zig-out/bake-native-2026-10-15
export BUN_DEBUG_QUIET_LOGS=1 BUN_GARBAGE_COLLECTOR_LEVEL=1 BUN_FEATURE_FLAG_INTERNAL_FOR_TESTING=1 BUN_JSC_randomIntegrityAuditRate=1.0 BUN_RUNTIME_TRANSPILER_CACHE_PATH=0
export HOME_BUN_CORPUS_JUNIT="$PWD/$p/reporting/control.xml"
export HOME_BUN_CORPUS_CASE_METADATA="$PWD/$p/reporting/control.cases.jsonl"
HOME_NATIVE_VM=1 zig-out/bin/home test --home-corpus-report="$PWD/$p/reporting/control.xml" --reporter=junit --reporter-outfile="$PWD/$p/reporting/control.xml" "$PWD/tests/runtime/native-junit-identities.test.ts" > "$p/reporting/control-native.log" 2>&1
junit_status=$?
unset HOME_BUN_CORPUS_CASE_METADATA HOME_BUN_CORPUS_JUNIT
python3 scripts/verify-native-junit-identities.py "$p/reporting" > "$p/reporting/control-validate.log" 2>&1
junit_validation=$?
python3 packages/runtime/test/bake-development/run.py zig-out/bin/home > "$p/development-final.log" 2>&1
dev_status=$?
bash packages/runtime/test/bake-production/run.sh "$PWD/zig-out/bin/home" > "$p/production-final.log" 2>&1
prod_status=$?
python3 scripts/test_summarize_bun_corpus.py > "$p/reporting/validator-controls-final.log" 2>&1
validator_status=$?
/Users/chris/.bun/bin/bun test build-support/native_module_abi.test.ts > "$p/abi.log" 2>&1
abi_status=$?
bunx --bun pickier tests/runtime/native-junit-identities.test.ts > "$p/lint.log" 2>&1
lint_status=$?
printf '{"junit":%d,"junit_validation":%d,"development":%d,"production":%d,"validator":%d,"abi":%d,"lint":%d}\n' "$junit_status" "$junit_validation" "$dev_status" "$prod_status" "$validator_status" "$abi_status" "$lint_status" > "$p/final-controls-status.json"
test "$junit_status" = 0 && test "$junit_validation" = 0 && test "$dev_status" = 0 && test "$prod_status" = 0 && test "$validator_status" = 0 && test "$abi_status" = 0 && test "$lint_status" = 0
