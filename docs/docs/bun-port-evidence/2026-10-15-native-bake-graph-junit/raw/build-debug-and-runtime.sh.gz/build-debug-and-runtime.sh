#!/bin/sh
set -u
p=zig-out/bake-native-2026-10-15
z=zig-out/toolchains/zig-aarch64-macos-0.17.0-dev.2163+89ff10d56/zig
"$z" build test-bake-graph --cache-dir .home-native-console-cache -Doptimize=Debug -Dstrip=true -Denable_jsc=true -j1 --summary all > "$p/packed-graph-debug.log" 2>&1
graph_status=$?
"$z" build home --cache-dir .home-native-console-cache -Doptimize=Debug -Dstrip=true -Denable_jsc=true -j1 --summary all > "$p/build-debug.log" 2>&1
build_status=$?
printf '{"debug_graph":%d,"runtime_build":%d}\n' "$graph_status" "$build_status" > "$p/debug-build-status.json"
test "$graph_status" = 0 && test "$build_status" = 0
