from pathlib import Path
import subprocess,hashlib,json
root=Path.cwd();file=root/'packages/runtime/src/runtime/bake/DevServer/IncrementalGraph.zig';original=file.read_bytes();needle=b'if (@sizeOf(@This()) != @sizeOf(u64) * 4)';assert original.count(needle)==1
try:
 file.write_bytes(original.replace(needle,b'if (@sizeOf(@This()) != @sizeOf(u64) * 4 + 1)',1))
 result=subprocess.run(['python3','zig-out/bake-native-2026-10-15/run-release-semantic.py'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 Path('zig-out/bake-native-2026-10-15/release-invariant-negative.log').write_bytes(result.stdout)
 assert result.returncode!=0 and b'Bake ClientFile.Packed must occupy exactly 32 bytes' in result.stdout,(result.returncode,result.stdout[-500:])
 print(json.dumps({'negative_exit':result.returncode,'actual_release_layout_check_enforced':True,'mutation':'required size changed to 33 only for negative control'}))
finally:
 file.write_bytes(original)
 assert hashlib.sha256(file.read_bytes()).digest()==hashlib.sha256(original).digest()
