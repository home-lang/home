from pathlib import Path
import subprocess,os,json
root=Path.cwd();task=root/'zig-out/vm-retention-port-2026-10-12';rows=[]
for path in [task/'payload-lifetime.mjs',root/'zig-out/vm-memory-port-2026-10-12/collection-without-measure.mjs',root/'zig-out/vm-memory-port-2026-10-12/lifetime-reference.mjs']:
 with (task/(path.stem+'-probe.log')).open('wb') as log:
  r=subprocess.run([str(root/'zig-out/bin/home'),'run',str(path)],cwd=root,env=os.environ.copy(),stdout=log,stderr=subprocess.STDOUT,timeout=60)
 rows.append({'file':str(path.relative_to(root)),'exit':r.returncode});print(path.name,r.returncode,flush=True)
(task/'more-controls.json').write_text(json.dumps(rows,indent=2)+'\n')
