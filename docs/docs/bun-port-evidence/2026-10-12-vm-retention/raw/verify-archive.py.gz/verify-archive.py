from pathlib import Path
import json,subprocess,gzip,hashlib
root=Path.cwd();folder='docs/docs/bun-port-evidence/2026-10-12-vm-retention/'
manifest=json.loads(subprocess.check_output(['/usr/bin/git','show','HEAD:'+folder+'manifest.json']))
for row in manifest['files']:
 data=gzip.decompress(subprocess.check_output(['/usr/bin/git','show','HEAD:'+folder+row['path']]))
 assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256'],row['path']
print('Verified',len(manifest['files']),'committed evidence artifacts')
