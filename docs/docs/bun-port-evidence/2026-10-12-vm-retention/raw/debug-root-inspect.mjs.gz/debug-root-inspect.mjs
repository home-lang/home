import vm from 'node:vm'
function create(){const context=vm.createContext({});vm.runInContext('globalThis.payload=new Array(8000).fill(9);undefined',context);return new WeakRef(context)}
const weak=create();await new Promise(resolve=>setImmediate(resolve));Bun.gc(true);await new Promise(resolve=>setImmediate(resolve))
const snapshot=Bun.generateHeapSnapshot('jsc')
const stride=snapshot.type==='GCDebugging'?7:4,nodes=new Map(),back=new Map(),roots=new Set(),targets=[]
for(let i=0;i<snapshot.nodes.length;i+=stride){const id=snapshot.nodes[i],name=snapshot.nodeClassNames[snapshot.nodes[i+2]];nodes.set(id,name);if(name.includes('NodeVM')&&name.includes('Global'))targets.push(id)}
for(let i=0;i<snapshot.edges.length;i+=4){const from=snapshot.edges[i],to=snapshot.edges[i+1],type=snapshot.edgeTypes[snapshot.edges[i+2]],name=(type==='Property'||type==='Variable')?snapshot.edgeNames[snapshot.edges[i+3]]:type;let list=back.get(to);if(!list)back.set(to,list=[]);list.push({from,name});if(from===0)roots.add(to)}

const rootReasons=new Map()
for(let i=0;i<snapshot.roots.length;i+=3)rootReasons.set(snapshot.roots[i],snapshot.labels[snapshot.roots[i+1]])
for(let i=0;i<snapshot.nodes.length;i+=stride){const id=snapshot.nodes[i],name=nodes.get(id);if(rootReasons.has(id)&&(name==='NodeVMGlobalObject'||name==='FunctionCodeBlock'||name==='ProgramExecutable'||name==='FunctionExecutable'))console.log('root',name,'reason',rootReasons.get(id),'label',snapshot.labels[snapshot.nodes[i+4]])}
