import vm from 'node:vm'
function create(){const context=vm.createContext({});vm.runInContext('globalThis.payload=new Array(8000).fill(9);undefined',context);return new WeakRef(context)}
const weak=create()
for(const delay of [0,6000,10000,6000]){await new Promise(resolve=>setTimeout(resolve,delay));Bun.gc(true);console.log('delay',delay,'cleared',weak.deref()===undefined)}
