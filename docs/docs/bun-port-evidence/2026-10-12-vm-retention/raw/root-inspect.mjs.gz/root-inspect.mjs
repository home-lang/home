import vm from 'node:vm'
function create(){const context=vm.createContext({});vm.runInContext('globalThis.__homeRetentionMarker=true;undefined',context);return new WeakRef(context)}
const weak=create();await new Promise(resolve=>setImmediate(resolve));Bun.gc(true);await new Promise(resolve=>setImmediate(resolve))
const snapshot=Bun.generateHeapSnapshot('jsc')
const stride=snapshot.type==='GCDebugging'?7:4,nodes=new Map(),back=new Map(),roots=new Set(),targets=[]
for(let i=0;i<snapshot.nodes.length;i+=stride){const id=snapshot.nodes[i],name=snapshot.nodeClassNames[snapshot.nodes[i+2]];nodes.set(id,name);if(name.includes('NodeVM')&&name.includes('Global'))targets.push(id)}
for(let i=0;i<snapshot.edges.length;i+=4){const from=snapshot.edges[i],to=snapshot.edges[i+1],type=snapshot.edgeTypes[snapshot.edges[i+2]],name=(type==='Property'||type==='Variable')?snapshot.edgeNames[snapshot.edges[i+3]]:type;let list=back.get(to);if(!list)back.set(to,list=[]);list.push({from,name});if(from===0)roots.add(to)}
console.log('snapshot type',snapshot.type,'VM global targets',targets.length,'weak cleared',weak.deref()===undefined)
for(const target of targets){const q=[{id:target,path:[]}],seen=new Set();let found=0;while(q.length&&found<4){const item=q.shift();if(seen.has(item.id))continue;seen.add(item.id);if(item.id===0||roots.has(item.id)){console.log('retention path',JSON.stringify(item.path));found++;continue}if(item.path.length>=12)continue;for(const edge of back.get(item.id)||[]){q.push({id:edge.from,path:[{from:nodes.get(edge.from)||'Root',edge:edge.name,to:nodes.get(item.id)},...item.path]})}}}
