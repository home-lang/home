from pathlib import Path
import subprocess,json,os
root=Path.cwd();task=root/'zig-out/vm-retention-port-2026-10-12'
rows=[]
for name in ['root-reason','ordinary-lifetime-controls']:
 command=[str(root/'zig-out/bin/home'),'run',str(task/(name+'.mjs'))]
 with (task/(name+'.log')).open('wb') as log:
  result=subprocess.run(command,cwd=root,env=os.environ.copy(),stdout=log,stderr=subprocess.STDOUT,timeout=60)
 rows.append({'name':name,'exit':result.returncode});print(name,result.returncode,flush=True)
(task/'controls.json').write_text(json.dumps(rows,indent=2)+'\n')
