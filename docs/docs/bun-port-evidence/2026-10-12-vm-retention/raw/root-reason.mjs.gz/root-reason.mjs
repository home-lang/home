import vm from 'node:vm'
function create(){ const context=vm.createContext({}); vm.runInContext('globalThis.marker=true;undefined',context); return new WeakRef(context) }
const weak=create()
await new Promise(resolve=>setImmediate(resolve))
const result=await vm.measureMemory({mode:'detailed',execution:'eager'})
console.log('live contexts',result.other.length,'weak cleared',weak.deref()===undefined)
