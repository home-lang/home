from pathlib import Path
import subprocess,os,json
root=Path.cwd();task=root/'zig-out/vm-retention-port-2026-10-12';rows=[]
for name in ['root-reason','payload-lifetime','operator-matrix','timed-retirement']:
 with (task/(name+'-code.log')).open('wb') as log:
  r=subprocess.run([str(root/'zig-out/bin/home'),'run',str(task/(name+'.mjs'))],cwd=root,env=os.environ.copy(),stdout=log,stderr=subprocess.STDOUT,timeout=90)
 rows.append({'name':name,'exit':r.returncode});print(name,r.returncode,flush=True)
(task/'code-controls.json').write_text(json.dumps(rows,indent=2)+'\n')
