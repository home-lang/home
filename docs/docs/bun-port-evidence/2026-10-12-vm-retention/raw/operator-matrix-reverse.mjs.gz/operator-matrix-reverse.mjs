import vm from 'node:vm'
const operations=[['array','globalThis.payload=new Array(8000);undefined'],['fill','globalThis.payload=new Array(8000).fill(9);undefined'],['map','globalThis.payload=[1,2,3].map(x=>x+1);undefined'],['math','globalThis.payload=Math.max(1,2);undefined']]
function create(source){const context=vm.createContext({});vm.runInContext(source,context);return new WeakRef(context)}
operations.reverse()
const refs=operations.map(([name,source])=>({name,weak:create(source)}))
for(let i=0;i<4;i++){await new Promise(resolve=>setImmediate(resolve));Bun.gc(true)}
for(const row of refs)console.log(row.name,'cleared',row.weak.deref()===undefined)
