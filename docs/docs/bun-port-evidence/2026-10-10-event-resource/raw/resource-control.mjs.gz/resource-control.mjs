import assert from 'node:assert/strict';
import {AsyncResource,AsyncLocalStorage} from 'node:async_hooks';
import {EventEmitterAsyncResource} from 'node:events';
assert.throws(() => new EventEmitterAsyncResource(), { code: 'ERR_INVALID_ARG_TYPE' })
assert.throws(() => new EventEmitterAsyncResource({}), { code: 'ERR_INVALID_ARG_TYPE' })
const namedEmitter = new EventEmitterAsyncResource('home-string-resource')
assert(namedEmitter.asyncResource instanceof AsyncResource)
assert.equal(namedEmitter.asyncResource.eventEmitter, namedEmitter)
assert.equal(namedEmitter.asyncId, namedEmitter.asyncResource.asyncId())
assert.equal(namedEmitter.triggerAsyncId, namedEmitter.asyncResource.triggerAsyncId())
assert.equal(Object.hasOwn(namedEmitter, 'asyncResource'), false)
assert.equal(Object.hasOwn(namedEmitter, 'triggerAsyncId'), false)
class ResourceChild extends EventEmitterAsyncResource {}
const resourceChild = new ResourceChild()
assert(resourceChild.asyncResource instanceof AsyncResource)
assert.equal(resourceChild.asyncResource.eventEmitter, resourceChild)
const capturedStore = new AsyncLocalStorage()
const capturedEmitter = capturedStore.run('resource-context', () => new EventEmitterAsyncResource({ name: 'home-capture-resource', captureRejections: true }))
assert.equal(Object.hasOwn(capturedEmitter, 'emit'), false)
const capturedFailure = new Error('resource rejection')
let resolveCapture
const captureReady = new Promise(resolve => { resolveCapture = resolve })
capturedEmitter.on('ordinary', function (value) {
  assert.equal(this, capturedEmitter)
  assert.equal(capturedStore.getStore(), 'resource-context')
  assert.equal(value, 11)
  return Promise.reject(capturedFailure)
})
capturedEmitter.on('error', function (error) {
  assert.equal(this, capturedEmitter)
  assert.equal(error, capturedFailure)
  assert.equal(capturedStore.getStore(), 'resource-context')
  resolveCapture()
})
assert.equal(capturedStore.run('caller-context', () => capturedEmitter.emit('ordinary', 11)), true)
await captureReady
assert.equal(capturedStore.getStore(), undefined)
capturedEmitter.emitDestroy()
namedEmitter.emitDestroy()
resourceChild.emitDestroy()
capturedStore.disable()
console.log('native event resource constructor, association and capture context passed')
