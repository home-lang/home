from pathlib import Path
p=Path('packages/runtime/upstream/src/jsc/bindings/HomeInspectorRealms.h');s=p.read_text().replace('std::unordered_map<JSC::JSGlobalObject*,WebCore::ScriptExecutionContextIdentifier>','std::unordered_map<JSC::JSGlobalObject*,std::pair<WebCore::ScriptExecutionContextIdentifier,int>>').replace('inspectorRetirementRoutes()[realm]=ownerContext;','inspectorRetirementRoutes()[realm]={ownerContext,id};')
s=s.replace('    WebCore::ScriptExecutionContextIdentifier context;','    WebCore::ScriptExecutionContextIdentifier context;\n    int identity;').replace('context=found->second;','context=found->second.first;identity=found->second.second;').replace('[realm](WebCore::ScriptExecutionContext&)','[realm,identity](WebCore::ScriptExecutionContext&)').replace('if(found==inspectorRealms().end())return;\n        auto* owner','if(found==inspectorRealms().end() || found->second->id!=identity)return;\n        auto* owner')
pos=s.index('\n}\n\nnamespace Bun');s=s[:pos]+'''\ninline void cancelInspectorRealms(JSC::JSGlobalObject* owner) {
    for(auto found=inspectorRealms().begin();found!=inspectorRealms().end();) {
        if(found->second->owner!=owner) {++found;continue;}
        {std::lock_guard lock(inspectorRetirementLock());inspectorRetirementRoutes().erase(found->first);}
        found=inspectorRealms().erase(found);
    }
}
'''+s[pos:];p.write_text(s)
p=Path('packages/runtime/upstream/src/jsc/bindings/HomeInspectorSession.h');s=p.read_text();s=s.replace('    void disconnectRealms();','    void disconnectRealms();\n    void releaseRealmGroups(const WTF::String&);')
s=s.replace('inline bool dispatchInspectorRealm(LocalInspectorChannel& channel,JSON::Object& request) {','''inline void unwrapInspectorObjects(LocalInspectorChannel& channel,JSON::Value& value) {
    if(auto object=value.asObject()) {
        auto exposed=object->getString("objectId"_s);auto native=channel.nativeRealmObjects.find(exposed);
        if(native!=channel.nativeRealmObjects.end()) object->setString("objectId"_s,native->value);
        for(auto& entry:*object) unwrapInspectorObjects(channel,entry.value.get());
    } else if(auto array=value.asArray()) for(size_t i=0;i<array->length();++i) unwrapInspectorObjects(channel,*array->get(i));
}
inline void LocalInspectorChannel::releaseRealmGroups(const WTF::String& group) {
    for(auto& entry:realmFrontends) if(auto* realm=entry.second->global.get()) {
        auto params=JSON::Object::create();params->setString("objectGroup"_s,group);
        auto request=JSON::Object::create();request->setInteger("id"_s,0);request->setString("method"_s,"Runtime.releaseObjectGroup"_s);request->setObject("params"_s,WTF::move(params));
        realm->inspectorController().dispatchMessageFromFrontend(request->toJSONString());
    }
}
inline bool dispatchInspectorRealm(LocalInspectorChannel& channel,JSON::Object& request) {''')
s=s.replace('    auto params=request.getObject("params"_s);\n    if(!params) return false;','''    auto params=request.getObject("params"_s);
    if(!params) return false;
    if(request.getString("method"_s)=="Runtime.releaseObjectGroup"_s) {channel.releaseRealmGroups(params->getString("objectGroup"_s));return false;}''',1)
s=s.replace('    auto exposed=params->getString("objectId"_s);\n    auto native=channel.nativeRealmObjects.find(exposed);\n    if(native!=channel.nativeRealmObjects.end()) params->setString("objectId"_s,native->value);','    unwrapInspectorObjects(channel,*params);',1)
s=s.replace('    for (auto& channel : channels) { channel->disconnect(); channel->handle.clear(); }','    for (auto& channel : channels) { channel->disconnect(); channel->handle.clear(); }\n    cancelInspectorRealms(global);',1)
p.write_text(s)
