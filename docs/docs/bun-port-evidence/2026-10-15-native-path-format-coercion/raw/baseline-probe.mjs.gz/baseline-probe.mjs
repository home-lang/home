import { posix, win32 } from 'node:path'
const results = []
for (const [platform, api] of [['posix', posix], ['win32', win32]]) {
  for (const value of ['txt', '.txt', 1, true, { 0: '.', toString() { return 'txt' } }, { toString() { return '.txt' } }]) {
    const events = []
    const object = { dir: '/root', name: 'file', get ext() { events.push('ext'); return value } }
    try { results.push({ platform, type: typeof value, value: api.format(object), events }) }
    catch (error) { results.push({ platform, type: typeof value, error: error.name, code: error.code, events }) }
  }
}
console.log(JSON.stringify({ versions: process.versions, results }))
