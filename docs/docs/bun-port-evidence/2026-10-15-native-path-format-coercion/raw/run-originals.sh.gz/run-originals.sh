#!/bin/sh
set -u
p=zig-out/path-format-2026-10-15
export BUN_DEBUG_QUIET_LOGS=1 BUN_GARBAGE_COLLECTOR_LEVEL=1 BUN_FEATURE_FLAG_INTERNAL_FOR_TESTING=1 BUN_JSC_randomIntegrityAuditRate=1.0 BUN_RUNTIME_TRANSPILER_CACHE_PATH=0
python3 "$p/originals/run-originals.py" > "$p/originals.log" 2>&1
original_status=$?
zig-out/bin/home tests/runtime/native-readdir-encoding.test.mjs > "$p/readdir-control.log" 2>&1
readdir_status=$?
python3 scripts/audit-bun-corpus-integrity.py --source /Users/chris/Code/bun --git /usr/bin/git --output "$p/integrity.json" > "$p/integrity.log" 2>&1
integrity_status=$?
printf '{"originals":%d,"readdir":%d,"integrity":%d}\n' "$original_status" "$readdir_status" "$integrity_status" > "$p/regression-status.json"
test "$original_status" = 0 && test "$readdir_status" = 0 && test "$integrity_status" = 0
