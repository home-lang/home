from pathlib import Path
import json,gzip,hashlib,subprocess,sys,re
root=Path(__file__).resolve().parents[2];task=Path(__file__).resolve().parent;base=root/'docs/docs/bun-port-evidence/2026-10-10-registry-completion';base.mkdir(parents=True,exist_ok=True)
counts={};reports=[]
for path in sorted((task/'final').glob('validate-*.json')):
 data=json.loads(path.read_text());assert data['successful'],path
 for key,value in data['summary'].items():
  if isinstance(value,int):counts[key]=counts.get(key,0)+value
 reports.append(path.name)
assert len(reports)==9
records=[]
def add(path,name):
 data=path.read_bytes();target=base/(name+'.gz');target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(gzip.compress(data,mtime=0));assert gzip.decompress(target.read_bytes())==data;records.append({'path':str(target.relative_to(base)),'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
for p in sorted(task.rglob('*')):
 if not p.is_file() or (p.name.startswith('issue-') or p.name=='archive-production.log') or 'manual-fixture' in p.parts or 'obsolete-cache-manifests' in p.parts:continue
 if p.suffix in ['.log','.json','.jsonl','.py','.stdout','.stderr','.xml']:
  add(p,'raw/'+str(p.relative_to(task)))
for name in json.loads((task/'ported-files.json').read_text()):add(root/'packages/runtime/upstream/src'/name,'source/packages/runtime/upstream/src/'+name)
for name in ['build-support/bundle-native-modules.ts','build-support/bundle-native-modules.test.ts','build-support/native_bindings.zig','build-support/native_module_abi.ts','build-support/native_module_abi.test.ts','tests/runtime/native-wasi-valid.test.mjs']:add(root/name,'source/'+name)
manifest={'schema':1,'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'upstream':'4982b91e3702094330f3be3883354c52b8c01323','platform':'Darwin arm64','results':{'original_files':9,'counts':counts,'native_regression_groups':9,'registry_owned':157,'registry_pinned':157},'features':['All 157 pinned JS registry modules have explicit Home ownership; the internal test adapter has its separate contract.','The complete linked registry inventory is validated before artifacts, rejecting missing, extra and duplicate identities.','Native X509 implementation/constructor/prototype compile together under exact linked-header validation.','WASI memory refresh follows actual buffer identity when replacing or growing WebAssembly.Memory.'],'limitations':['Registry ownership does not prove API completion or whole-native ownership. The pinned async-frame module is an incomplete facade; current() returns undefined, tracked by #871.','The initial valid WASI replacement-memory test failure is retained without passing credit; the repaired test checks both correct new-memory writes and unchanged old memory.','This verifies ordinary X509/TLS/HTML/async context and valid WASI operations; broader WASI/debugger/HTML, remaining native dependencies, complete suite and Release/ASAN/all-platform verification remain open under #66.'],'files':records}
(base/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(len(records),'verified archives',counts)
