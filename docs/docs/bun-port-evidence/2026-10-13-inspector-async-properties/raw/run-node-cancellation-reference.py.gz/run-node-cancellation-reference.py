from pathlib import Path
import subprocess,os,json,sys,hashlib,shutil
root=Path.cwd();task=Path(__file__).resolve().parent;source=root/'tests/runtime/native-inspector-async-properties.test.mjs'
with (task/'node-cancellation-reference.log').open('wb') as log:
 r=subprocess.run([shutil.which('node'),str(source)],cwd=root,env=os.environ,stdout=log,stderr=subprocess.STDOUT,timeout=60)
(task/'node-cancellation-reference.json').write_text(json.dumps({'exit':r.returncode,'sourceSha256':hashlib.sha256(source.read_bytes()).hexdigest()},indent=2)+'\n');print('node maintained regression',r.returncode,flush=True);sys.exit(r.returncode)
