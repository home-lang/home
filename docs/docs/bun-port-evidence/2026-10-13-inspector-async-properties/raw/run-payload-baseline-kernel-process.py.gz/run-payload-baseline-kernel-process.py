from pathlib import Path
import os,subprocess,json,hashlib,shutil,sys
root=Path.cwd();task=Path(__file__).resolve().parent;rows=[]
for runtime,exe in [('node',shutil.which('node')),('home',str(task/'home-baseline'))]:
 path=task/'object-payload.mjs'
 with (task/('payload-baseline-kernel-process-'+runtime+'.log')).open('wb') as log:
  try:r=subprocess.run([exe,str(path)],cwd=root,env=os.environ,stdout=log,stderr=subprocess.STDOUT,timeout=30)
  except subprocess.TimeoutExpired:r=subprocess.CompletedProcess([],124)
 rows.append({'runtime':runtime,'exit':r.returncode,'sourceSha256':hashlib.sha256(path.read_bytes()).hexdigest(),'executableSha256':hashlib.sha256(Path(exe).read_bytes()).hexdigest()});print(runtime,r.returncode,flush=True)
(task/'payload-baseline-kernel-process-results.json').write_text(json.dumps(rows,indent=2)+'\n')
with (task/'node-maintained-regression-kernel-process.log').open('wb') as log:
 r=subprocess.run([shutil.which('node'),str(root/'tests/runtime/native-inspector-async-properties.test.mjs')],cwd=root,env=os.environ,stdout=log,stderr=subprocess.STDOUT,timeout=30)
print('node maintained regression',r.returncode,flush=True);sys.exit(r.returncode)
