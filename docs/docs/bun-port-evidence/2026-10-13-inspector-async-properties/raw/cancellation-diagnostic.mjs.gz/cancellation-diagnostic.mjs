import {Session} from 'node:inspector';
const session=new Session();session.connect();
const post=(method,params)=>new Promise((resolve,reject)=>session.post(method,params,(error,result)=>error?reject(error):resolve(result)));
const promise=(await post('Runtime.evaluate',{expression:'new Promise(() => {})'})).result;const events=[];
const pending=new Promise(resolve=>session.post('Runtime.awaitPromise',{promiseObjectId:promise.objectId},error=>{events.push({event:'callback',code:error?.code,message:error?.message});try{session.connect();events.push({event:'reconnect',result:'connected'});session.disconnect()}catch(error){events.push({event:'reconnect',code:error.code})}resolve()}));
events.push({event:'before-disconnect'});session.disconnect();events.push({event:'after-disconnect'});await pending;console.log(JSON.stringify(events));
