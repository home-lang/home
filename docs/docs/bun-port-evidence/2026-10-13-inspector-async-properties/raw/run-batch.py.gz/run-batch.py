from pathlib import Path
import os,subprocess,json,sys
root=Path.cwd();task=Path(__file__).resolve().parent;rows=[]
commands=[['./zig-out/bin/home','run','tests/runtime/native-profiling-cli.test.mjs'],[sys.executable,str(task/'run-realm-regressions.py')],[sys.executable,str(task/'run-corpus.py'),'original-final'],[sys.executable,str(task/'run-native.py'),'native-final'],['/Users/chris/.bun/bin/bun','test','build-support/native_module_abi.test.ts','build-support/core_builtin_abi.test.ts','build-support/builtin_exports.test.ts'],[sys.executable,'-B','scripts/test_summarize_bun_corpus.py']]
for index,command in enumerate(commands,1):
 with (task/f'batch-{index}.log').open('wb') as log:
  try:r=subprocess.run(command,env=os.environ.copy(),stdout=log,stderr=subprocess.STDOUT,timeout=1200)
  except subprocess.TimeoutExpired:r=subprocess.CompletedProcess(command,124)
 rows.append({'command':command,'exit':r.returncode});(task/'batch-results.json').write_text(json.dumps(rows,indent=2)+'\n');print(index,r.returncode,flush=True)
 if r.returncode:sys.exit(r.returncode)
