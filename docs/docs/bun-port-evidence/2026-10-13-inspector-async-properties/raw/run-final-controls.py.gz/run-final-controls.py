from pathlib import Path
import subprocess,os,json,sys,hashlib
root=Path.cwd();task=Path(__file__).resolve().parent;phase=sys.argv[1];rows=[]
for runtime,exe in [('node','node'),('home',str(root/'zig-out/bin/home'))]:
 for name in ['await-promise.mjs','accessor-properties.mjs','object-payload.mjs']:
  with (task/(phase+'-'+runtime+'-'+name+'.log')).open('wb') as log:
   try:r=subprocess.run([exe,str(task/name)],cwd=root,env=os.environ,stdout=log,stderr=subprocess.STDOUT,timeout=30)
   except subprocess.TimeoutExpired:r=subprocess.CompletedProcess([],124)
  rows.append({'runtime':runtime,'file':name,'exit':r.returncode,'sourceSha256':hashlib.sha256((task/name).read_bytes()).hexdigest(),'executableSha256':hashlib.sha256(Path(exe if runtime=='home' else __import__('shutil').which(exe)).read_bytes()).hexdigest()});(task/(phase+'-results.json')).write_text(json.dumps(rows,indent=2)+'\n');print(runtime,name,r.returncode,flush=True)
sys.exit(0 if all(row['exit']==0 for row in rows) else 1)
