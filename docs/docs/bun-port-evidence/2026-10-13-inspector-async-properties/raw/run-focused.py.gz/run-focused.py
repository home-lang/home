from pathlib import Path
import subprocess,os,json,sys
root=Path.cwd();task=Path(__file__).resolve().parent;rows=[]
commands=[[sys.executable,str(task/'run-final-controls.py'),'repaired']]
commands += [[exe,str(task/'cancellation-diagnostic.mjs')] for exe in ['node',str(task/'home-repair')]]
for index,command in enumerate(commands,1):
 with (task/f'focused-{index}.log').open('wb') as log:
  try:r=subprocess.run(command,cwd=root,env=os.environ,stdout=log,stderr=subprocess.STDOUT,timeout=240)
  except subprocess.TimeoutExpired:r=subprocess.CompletedProcess([],124)
 rows.append({'command':command,'exit':r.returncode});(task/'focused-results.json').write_text(json.dumps(rows,indent=2)+'\n');print(index,r.returncode,flush=True)
 if r.returncode:sys.exit(r.returncode)
