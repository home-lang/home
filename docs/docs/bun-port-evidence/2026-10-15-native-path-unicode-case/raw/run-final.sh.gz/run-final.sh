#!/bin/sh
set -u
p=zig-out/path-unicode-2026-10-15
export BUN_DEBUG_QUIET_LOGS=1 BUN_GARBAGE_COLLECTOR_LEVEL=1 BUN_FEATURE_FLAG_INTERNAL_FOR_TESTING=1 BUN_JSC_randomIntegrityAuditRate=1.0 BUN_RUNTIME_TRANSPILER_CACHE_PATH=0
/Users/chris/.bun/bin/bun test build-support/native_module_abi.test.ts > "$p/abi-final.log" 2>&1
abi_status=$?
/Users/chris/.bun/bin/bun test build-support/bundle-native-modules.test.ts -t 'generates owned builtins and the stream adapter' > "$p/bundler-recheck.log" 2>&1
bundler_status=$?
python3 "$p/originals/run-originals.py" > "$p/originals.log" 2>&1
original_status=$?
zig-out/bin/home tests/runtime/native-readdir-encoding.test.mjs > "$p/readdir-control.log" 2>&1
readdir_status=$?
python3 scripts/audit-bun-corpus-integrity.py --source /Users/chris/Code/bun --git /usr/bin/git --output "$p/integrity.json" > "$p/integrity.log" 2>&1
integrity_status=$?
bunx --bun pickier build-support/bundle-native-modules.ts build-support/bundle-native-modules.test.ts tests/runtime/native-path-unicode-case.test.mjs > "$p/lint-final.log" 2>&1
lint_status=$?
printf '{"abi":%d,"bundler_recheck":%d,"originals":%d,"readdir":%d,"integrity":%d,"lint":%d}\n' "$abi_status" "$bundler_status" "$original_status" "$readdir_status" "$integrity_status" "$lint_status" > "$p/final-status.json"
test "$abi_status" = 0 && test "$bundler_status" = 0 && test "$original_status" = 0 && test "$readdir_status" = 0 && test "$integrity_status" = 0 && test "$lint_status" = 0
