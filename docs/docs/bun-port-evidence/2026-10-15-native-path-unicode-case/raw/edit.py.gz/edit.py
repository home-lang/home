from pathlib import Path
p=Path('build-support/bundle-native-modules.ts');s=p.read_text();needle="['jsc/bindings/Path.cpp', 'Path.h'],";assert needle in s;s=s.replace(needle,needle+" ['../../src/native/PathUnicode.cpp', null],",1);p.write_text(s)
p=Path('packages/runtime/src/runtime/node/path.zig');s=p.read_text();a=s.index('fn eqlIgnoreCaseT(');b=s.index('\n/// Taken from Zig',a)
s=s[:a]+'''extern fn HomePath__lowercase(input: *const bun.String, output: *bun.String) void;

fn lowercasePath(comptime T: type, path: []const T) bun.String {
    var input = if (T == u16) bun.String.cloneUTF16(path) else bun.String.cloneUTF8(path);
    defer input.deref();
    var output: bun.String = undefined;
    HomePath__lowercase(&input, &output);
    return output;
}

fn isAsciiPath(comptime T: type, path: []const T) bool {
    for (path) |unit| if (unit >= 128) return false;
    return true;
}

fn eqlIgnoreCaseT(comptime T: type, a: []const T, b: []const T) bool {
    if (isAsciiPath(T, a) and isAsciiPath(T, b)) {
        if (a.len != b.len) return false;
        for (a, b) |left, right| {
            if (toLowerT(T, left) != toLowerT(T, right)) return false;
        }
        return true;
    }
    var left = lowercasePath(T, a);
    defer left.deref();
    var right = lowercasePath(T, b);
    defer right.deref();
    if (left.length() != right.length()) return false;
    for (0..left.length()) |i| if (left.charAt(i) != right.charAt(i)) return false;
    return true;
}

fn lowercasePathSlice(comptime T: type, path: []const T) []const T {
    var lowered = lowercasePath(T, path);
    defer lowered.deref();
    if (T == u8) return bun.handleOom(lowered.toOwnedSlice(bun.default_allocator));
    const result = bun.handleOom(bun.default_allocator.alloc(u16, lowered.length()));
    for (result, 0..) |*unit, i| unit.* = lowered.charAt(i);
    return result;
}

// Node compares original components when Unicode lowercase expands the path.
// Component slices keep offsets in the original string and preserve spelling.
fn relativeWindowsExpandedT(comptime T: type, from: [:0]const T, to: [:0]const T, buf: []T) MaybeSlice(T) {
    const allocator = bun.default_allocator;
    const from_parts = bun.handleOom(allocator.alloc([]const T, std.mem.count(T, from, comptime L(T, "\\\\")) + 1));
    defer allocator.free(from_parts);
    const to_parts = bun.handleOom(allocator.alloc([]const T, std.mem.count(T, to, comptime L(T, "\\\\")) + 1));
    defer allocator.free(to_parts);
    var from_count: usize = 0;
    var from_split = std.mem.splitScalar(T, from, CHAR_BACKWARD_SLASH);
    while (from_split.next()) |part| {
        from_parts[from_count] = part;
        from_count += 1;
    }
    var to_count: usize = 0;
    var to_split = std.mem.splitScalar(T, to, CHAR_BACKWARD_SLASH);
    while (to_split.next()) |part| {
        to_parts[to_count] = part;
        to_count += 1;
    }
    if (from_count > 0 and from_parts[from_count - 1].len == 0) from_count -= 1;
    if (to_count > 0 and to_parts[to_count - 1].len == 0) to_count -= 1;
    var common: usize = 0;
    while (common < @min(from_count, to_count) and eqlIgnoreCaseT(T, from_parts[common], to_parts[common])) : (common += 1) {}
    if (common == 0) return .{ .result = to };
    var size: usize = 0;
    for (common..from_count) |_| {
        if (size > 0) {
            buf[size] = CHAR_BACKWARD_SLASH;
            size += 1;
        }
        buf[size] = CHAR_DOT;
        buf[size + 1] = CHAR_DOT;
        size += 2;
    }
    for (to_parts[common..to_count]) |part| {
        if (size > 0) {
            buf[size] = CHAR_BACKWARD_SLASH;
            size += 1;
        }
        bun.copy(T, buf[size .. size + part.len], part);
        size += part.len;
    }
    buf[size] = 0;
    return .{ .result = buf[0..size :0] };
}
''' +s[b:]
# Comparison buffers are separate from resolved originals and output storage.
a=s.index('pub fn relativeWindowsT(');b=s.index('\npub fn relativePosixJS_T',a);chunk=s[a:b]
needle='    const toOrigLen = toOrig.len;';assert needle in chunk
chunk=chunk.replace(needle,needle+'''
    const ascii = isAsciiPath(T, fromOrig) and isAsciiPath(T, toOrig);
    const from_lower = if (ascii) fromOrig else lowercasePathSlice(T, fromOrig);
    defer if (!ascii) bun.default_allocator.free(from_lower);
    const to_lower = if (ascii) toOrig else lowercasePathSlice(T, toOrig);
    defer if (!ascii) bun.default_allocator.free(to_lower);
    if (from_lower.len != fromOrig.len or to_lower.len != toOrig.len)
        return relativeWindowsExpandedT(T, fromOrig, toOrig, buf3);
''')
chunk=chunk.replace('const fromByte = fromOrig[fromStart + i];','const fromByte = from_lower[fromStart + i];').replace('toLowerT(T, toOrig[toStart + i])','toLowerT(T, to_lower[toStart + i])')
s=s[:a]+chunk+s[b:]
# Windows API comparisons must index JS code units, including Latin1 strings.
a=s.index('pub fn relative(globalObject:');b=s.index('\n}',a);chunk=s[a:b].replace('if (fromZigStr.is16Bit() or toZigStr.is16Bit())','if (isWindows or fromZigStr.is16Bit() or toZigStr.is16Bit())');s=s[:a]+chunk+s[b:]
p.write_text(s)
