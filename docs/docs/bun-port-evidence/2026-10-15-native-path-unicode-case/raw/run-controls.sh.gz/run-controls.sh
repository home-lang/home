#!/bin/sh
set -u
p=zig-out/path-unicode-2026-10-15
export BUN_DEBUG_QUIET_LOGS=1 BUN_GARBAGE_COLLECTOR_LEVEL=1 BUN_FEATURE_FLAG_INTERNAL_FOR_TESTING=1 BUN_JSC_randomIntegrityAuditRate=1.0 BUN_RUNTIME_TRANSPILER_CACHE_PATH=0
zig-out/bin/home tests/runtime/native-path-unicode-case.test.mjs "$p/node-snapshot.json" > "$p/home-control.log" 2>&1
unicode_status=$?
zig-out/bin/home tests/runtime/native-path-code-units.test.mjs zig-out/path-native-2026-10-15/node-snapshot.json > "$p/code-unit-control.log" 2>&1
unit_status=$?
/Users/chris/.bun/bin/bun tests/runtime/native-path-unicode-case.test.mjs "$p/node-snapshot.json" > "$p/installed-bun-control.log" 2>&1
baseline_status=$?
/Users/chris/.bun/bin/bun test build-support/native_module_abi.test.ts build-support/bundle-native-modules.test.ts > "$p/abi-bundler.log" 2>&1
abi_status=$?
bunx --bun pickier build-support/bundle-native-modules.ts tests/runtime/native-path-unicode-case.test.mjs > "$p/lint.log" 2>&1
lint_status=$?
printf '{"unicode":%d,"code_units":%d,"installed_bun_baseline":%d,"abi_bundler":%d,"lint":%d}\n' "$unicode_status" "$unit_status" "$baseline_status" "$abi_status" "$lint_status" > "$p/control-status.json"
test "$unicode_status" = 0 && test "$unit_status" = 0 && test "$abi_status" = 0 && test "$lint_status" = 0
