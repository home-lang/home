import assert from 'node:assert/strict'
import * as fs from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
const base=fs.mkdtempSync(join(tmpdir(),'home-directory-callback-errors-'))
for(const name of ['a','b','c'])fs.writeFileSync(join(base,name),name)
try {
 for(const operation of ['cached-read','close']){
  const dir=fs.opendirSync(base,{bufferSize:32})
  if(operation==='cached-read')assert(dir.readSync())
  const marker=new Error(operation+' callback marker')
  const events=[];let calls=0;let finish
  const done=new Promise(resolve=>{finish=resolve})
  function uncaught(error){assert.equal(error,marker);events.push('uncaught');if(operation==='cached-read')dir.closeSync();finish()}
  function rejection(error){events.push('rejection');if(operation==='cached-read')dir.closeSync();finish()}
  process.once('uncaughtException',uncaught);process.once('unhandledRejection',rejection)
  const cb=function(){calls++;throw marker}
  if(operation==='cached-read')dir.read(cb);else dir.close(cb)
  await done
  process.removeListener('uncaughtException',uncaught);process.removeListener('unhandledRejection',rejection)
  assert.deepEqual(events,['uncaught']);assert.equal(calls,1)
  assert.throws(()=>dir.readSync(),{code:'ERR_DIR_CLOSED'})
 }
 console.log('cached read and native close callback exceptions reach uncaughtException exactly once')
} finally {fs.rmSync(base,{recursive:true,force:true})}
