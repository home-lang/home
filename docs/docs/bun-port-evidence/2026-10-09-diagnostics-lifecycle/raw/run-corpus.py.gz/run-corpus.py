from pathlib import Path
import os,subprocess,sys,json,time,hashlib
root=Path(__file__).resolve().parents[2];task=root/'zig-out/diagnostics-port-2026-10-09';phase=sys.argv[1];out=task/phase;out.mkdir(parents=True,exist_ok=True)
exe=root/'zig-out/bin/home';files=json.loads((task/'selection.json').read_text());records=[]
for index,name in enumerate(files):
 env=os.environ.copy()
 for key in ['HOME_NATIVE_VM','HOME_CORPUS_FULL_VM','HOME_NATIVE_RUN']:env.pop(key,None)
 env['BUN_DEBUG_QUIET_LOGS']='1';report=out/f'corpus-{index+1}';env['HOME_BUN_CORPUS_REPORT_DIR']=str(report)
 command=[str(exe),'test',str(root/'packages/runtime/test/test'/name)];start=time.monotonic()
 with (out/f'corpus-{index+1}.log').open('wb') as log:result=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 with (out/f'validate-{index+1}.json').open('wb') as log:validation=subprocess.run([sys.executable,str(root/'scripts/summarize-bun-corpus.py'),str(report)],cwd=root,stdout=log,stderr=subprocess.STDOUT)
 records.append({'file':name,'command':command,'exit':result.returncode,'validation_exit':validation.returncode,'seconds':round(time.monotonic()-start,3)})
 print(name,result.returncode,validation.returncode,flush=True)
(out/'summary.json').write_text(json.dumps({'executable_sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'records':records},indent=2)+'\n')
sys.exit(0 if all(r['exit']==0 and r['validation_exit']==0 for r in records) else 1)
