import fs from 'node:fs'
import {executionAsyncResource} from 'node:async_hooks'
import {tmpdir} from 'node:os'
import {join} from 'node:path'
const root=fs.mkdtempSync(join(tmpdir(),'home-mkdir-probe-'));const rows=[]
async function create(label,path,options){return new Promise((resolve,reject)=>{fs.mkdir(path,options,function(error,result){rows.push({label,args:arguments.length,receiver:this?.constructor?.name??null,resourceSame:this===executionAsyncResource(),error:error?.code??null,result:result===undefined?null:result.replace(root,'ROOT')});resolve()})})}
try{
 await create('recursive new',join(root,'new','child'),{recursive:true});await create('recursive existing',join(root,'new','child'),{recursive:true});await create('nonrecursive',join(root,'single'),{});await create('existing error',join(root,'single'),{});
 rows.push({label:'promise recursive',result:(await fs.promises.mkdir(join(root,'promise','child'),{recursive:true}))?.replace(root,'ROOT')??null});console.log(JSON.stringify(rows,null,2))
}finally{fs.rmSync(root,{recursive:true,force:true})}
