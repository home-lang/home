import fs from 'node:fs'
import {tmpdir} from 'node:os'
import {join} from 'node:path'
const root=fs.mkdtempSync(join(tmpdir(),'home-dir-errors-'));for(let i=0;i<4;i++)fs.writeFileSync(join(root,'file'+i),'x')
const mode=process.argv[2]??'throw-twice';const trace=[];process.on('uncaughtException',e=>trace.push(['uncaught',e.code??e.message]));process.on('unhandledRejection',e=>trace.push(['rejection',e.code??e.message]));const d=fs.opendirSync(root,{bufferSize:1});let firstCalls=0
if(mode==='throw-twice'){
 d.read((e,v)=>{trace.push(['first',++firstCalls,e?.message??null,v?.name??null]);throw new Error('callback-'+firstCalls)})
 d.read((e,v)=>trace.push(['second',e?.code??null,v?.name??null]));d.close(e=>trace.push(['close',e?.code??null]))
}else{
 d.read((e,v)=>trace.push(['first',e?.code??null,v?.name??null]));d.close(e=>trace.push(['close',e?.code??null]));d.read((e,v)=>trace.push(['after-close',e?.code??null,v?.name??null]));d.close(e=>trace.push(['second-close',e?.code??null]))
}
setTimeout(()=>{try{d.closeSync()}catch{}fs.rmSync(root,{recursive:true,force:true});console.log(JSON.stringify({mode,trace}));},200)
