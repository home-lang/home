import fs from 'node:fs'
import {tmpdir} from 'node:os'
import {join} from 'node:path'
const root=fs.mkdtempSync(join(tmpdir(),'home-mkdir-throw-'));const marker=new Error('mkdir callback marker');const trace=[];let calls=0
process.once('uncaughtException',e=>{trace.push(['uncaught',e===marker]);finish()});process.once('unhandledRejection',e=>{trace.push(['rejection',e===marker]);finish()})
function finish(){setImmediate(()=>{fs.rmSync(root,{recursive:true,force:true});console.log(JSON.stringify({calls,trace}))})}
fs.mkdir(join(root,'parent','child'),{recursive:true},function(e,result){calls++;trace.push(['callback',arguments.length,e===null,result===join(root,'parent'),this===undefined]);throw marker})
