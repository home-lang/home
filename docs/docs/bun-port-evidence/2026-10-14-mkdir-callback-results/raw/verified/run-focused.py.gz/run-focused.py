from pathlib import Path
import os,json,subprocess,hashlib
p=Path(__file__).resolve().parent;root=p.parents[2];env=os.environ.copy();env['BUN_DEBUG_QUIET_LOGS']='1';rows=[]
commands=[('home-directory',['zig-out/bin/home','tests/runtime/native-directory-handle.test.mjs']),('home-async-storage',['zig-out/bin/home','tests/runtime/native-async-storage-lifecycle.test.mjs']),('home-mkdir-probe',['zig-out/bin/home',str(p.parent/'probe/mkdir.mjs')])]
for name,args in commands:
 with (p/(name+'.log')).open('wb') as log:
  try:r=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,cwd=root,env=env,timeout=240)
  except subprocess.TimeoutExpired:r=subprocess.CompletedProcess(args,124)
 rows.append({'name':name,'argv':args,'exit':r.returncode});(p/'focused-results.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,r.returncode,flush=True)
(p/'executable.json').write_text(json.dumps({'sha256':hashlib.sha256((root/'zig-out/bin/home').read_bytes()).hexdigest(),'bytes':(root/'zig-out/bin/home').stat().st_size},indent=2)+'\n');assert all(r['exit']==0 for r in rows),rows
