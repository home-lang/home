Tracked from #66 and #878.

The unchanged fs-mkdir.test.ts fails two recursive callback cases: the native operation returns the first-created directory, but the public node:fs wrapper forwards only the error and discards that result. Promise mkdir already preserves the native result.

The corrected wrapper passes (null, firstPathCreated) when a directory was created and one error argument otherwise, preserving the undefined callback receiver and the actual native FSREQCALLBACK execution scope.

Acceptance: recursive all-new/partly-existing paths, existing recursive paths, nonrecursive success/errors, callback argument counts/receiver/async resource, promise results, callback exception delivery and unchanged original mkdir/directory tests. Baseline Node v26.10.0/Home comparisons and original failures are retained. Build and validation are in progress.

Directory callback throw/queue probes also produced different complete traces: Node does not deliver the same repeated-throw/queued-closed-read errors as Home. These unresolved results remain #878 evidence and must not be normalized into pass credit.
