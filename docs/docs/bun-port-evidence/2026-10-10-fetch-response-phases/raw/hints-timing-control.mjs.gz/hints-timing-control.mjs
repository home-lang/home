import { createServer } from 'node:http'
import { once } from 'node:events'
const server = createServer((req, res) => { res.writeEarlyHints({ link: '</a>; rel=preload' }); setTimeout(() => res.end('ok'), 10) })
server.listen(0,'127.0.0.1');await once(server,'listening')
const url=`http://127.0.0.1:${server.address().port}`
const response=await fetch(url);console.log(await response.text());console.log(performance.getEntriesByType('resource').map(entry=>entry.toJSON()))
const closed=once(server,'close');server.close();await closed
