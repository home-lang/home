import { createServer } from 'node:http'
import { once } from 'node:events'
const server = createServer((req, res) => { if(req.url === '/plain'){res.end('plain');return} res.writeEarlyHints({ link: '</a>; rel=preload' }); setTimeout(() => res.end('ok'), 10) })
server.listen(0,'127.0.0.1');await once(server,'listening')
const url=`http://127.0.0.1:${server.address().port}`
for(let i=0;i<3;i++){const plain=await fetch(url+'/plain');await plain.text()}
const response=await fetch(url);console.log(await response.text());console.log(performance.getEntriesByType('resource').map(entry=>entry.toJSON()))
const closed=once(server,'close');server.close();await closed
