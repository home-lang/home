import { createServer, request } from 'node:http'
import { once } from 'node:events'
const server = createServer((req, res) => {
  if(req.url === '/plain'){res.end('plain');return}
  res.writeEarlyHints({ link: '</style.css>; rel=preload; as=style' })
  setTimeout(() => res.end('ok'), 10)
})
server.listen(0, '127.0.0.1'); await once(server, 'listening')
await new Promise((resolve, reject) => {
  const req = request(`http://127.0.0.1:${server.address().port}/plain`, res => { res.resume(); res.on('end', resolve) })
  req.on('information', info => console.log('information', info.statusCode))
  req.on('error', reject); req.end()
})
await new Promise((resolve, reject) => {
  const req = request(`http://127.0.0.1:${server.address().port}`, res => { res.resume(); res.on('end', resolve) })
  req.on('information', info => console.log('information', info.statusCode))
  req.on('error', reject); req.end()
})
const closed = once(server, 'close'); server.close(); await closed
