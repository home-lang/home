from pathlib import Path
import subprocess,os,json
p=Path(__file__).resolve().parent;root=p.parents[1];env=os.environ.copy();env.update(HOME_NATIVE_VM='1',BUN_DEBUG_QUIET_LOGS='1',BUN_GARBAGE_COLLECTOR_LEVEL='1',BUN_FEATURE_FLAG_INTERNAL_FOR_TESTING='1',BUN_JSC_randomIntegrityAuditRate='1.0',BUN_RUNTIME_TRANSPILER_CACHE_PATH='0');env.pop('GITHUB_ACTIONS',None)
args=[str(root/'zig-out/bin/home'),'test','--config='+str(root/'packages/runtime/test/bunfig.toml'),str(root/'packages/runtime/test/test/js/node/fs/fs.test.ts')]
with (p/'fs-verbose.log').open('wb') as out:r=subprocess.run(args,cwd=root/'packages/runtime/test',env=env,stdout=out,stderr=subprocess.STDOUT,timeout=240)
(p/'fs-verbose-result.json').write_text(json.dumps({'command':args,'exit':r.returncode,'diagnostic':'native direct runner, verbose output; no original assertion/workload/deadline changes; not corpus pass credit'},indent=2)+'\n');print(r.returncode)
raise SystemExit(r.returncode)
