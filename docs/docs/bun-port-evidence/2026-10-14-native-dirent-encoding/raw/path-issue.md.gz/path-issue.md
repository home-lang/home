Parent #66. Found while verifying #897’s native readdir UTF-16 parent strings.

On Darwin arm64, Node v26.10.0 preserves the input `a\ud861b` through `node:path` join, normalize and resolve. Home’s native runtime and installed Bun 1.4.2 replace the lone high surrogate with U+FFFD. A direct probe records input and outputs as JSON, without filesystem access. The readdir implementation now preserves the code unit in string parent results; using Home path.join to construct the control expectation exposed this independent path-string gap.

Acceptance:

- Preserve JS UTF-16 code units in native path-string operations rather than round-tripping through lossy UTF-8.
- Audit join/normalize/resolve and the related dirname/basename/extname/relative operations, including POSIX and Windows behavior, paired surrogates, lone high/low surrogates and separator normalization.
- Keep filesystem byte/path conversion separate from the pure string API; preserve argument validation, return identity/value semantics and ABI ownership.
- Verify against actual Node controls and unchanged pinned path corpus files; retain the installed Bun baseline separately from a rebuilt pinned-source comparison.

No production fix or full-suite acceptance is claimed for this gap. Probe and the #897 control failure are retained for publication.
