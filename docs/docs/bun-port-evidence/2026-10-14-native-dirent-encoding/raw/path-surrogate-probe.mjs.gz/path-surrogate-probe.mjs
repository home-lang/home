import {join,normalize,resolve} from 'node:path'
const s='a\ud861b'
console.log(JSON.stringify({runtime:process.execPath,input:s,joined:join('/tmp',s),normalized:normalize('/tmp/'+s),resolved:resolve('/tmp',s)}))
