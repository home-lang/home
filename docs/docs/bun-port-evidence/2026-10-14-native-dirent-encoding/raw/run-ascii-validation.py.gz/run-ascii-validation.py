from pathlib import Path
import subprocess,sys,json
p=Path(__file__).resolve().parent;root=p.parents[1];rows=[]
for name,file in [('controls',p/'controls-ascii/run-controls.py'),('original',p/'originals-ascii/run-originals.py')]:
 with (p/('ascii-'+name+'.log')).open('wb') as out:r=subprocess.run([sys.executable,str(file)],cwd=root,stdout=out,stderr=subprocess.STDOUT)
 rows.append({'name':name,'exit':r.returncode});(p/'ascii-results.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,r.returncode,flush=True)
 if r.returncode:break
raise SystemExit(any(r['exit'] for r in rows))
