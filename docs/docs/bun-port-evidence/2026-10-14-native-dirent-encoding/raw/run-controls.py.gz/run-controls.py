from pathlib import Path
import subprocess,os,json,hashlib
p=Path(__file__).resolve().parent;root=p.parents[1];rows=[]
exe=root/'zig-out/bin/home';digest=hashlib.sha256(exe.read_bytes()).hexdigest();(p/'executable.json').write_text(json.dumps({'sha256':digest},indent=2)+'\n')
env=os.environ.copy();env.update(BUN_DEBUG_QUIET_LOGS='1',BUN_GARBAGE_COLLECTOR_LEVEL='1',BUN_FEATURE_FLAG_INTERNAL_FOR_TESTING='1',BUN_JSC_randomIntegrityAuditRate='1.0')
commands=[('node',['/Users/chris/.local/share/pantry/global/packages/nodejs.org/v26.10.0/bin/node','--expose-gc','tests/runtime/native-readdir-encoding.test.mjs']),('home',[str(exe),'tests/runtime/native-readdir-encoding.test.mjs']),('traversal',[str(exe),'tests/runtime/native-readdir-traversal.test.mjs'])]
for name,args in commands:
 with (p/(name+'.log')).open('wb') as out:
  try:r=subprocess.run(args,cwd=root,stdout=out,stderr=subprocess.STDOUT,timeout=120,env=env)
  except subprocess.TimeoutExpired:r=subprocess.CompletedProcess([],124)
 rows.append({'name':name,'exit':r.returncode});(p/'control-results.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,r.returncode,flush=True)
 if r.returncode:break
raise SystemExit(any(r['exit'] for r in rows))
