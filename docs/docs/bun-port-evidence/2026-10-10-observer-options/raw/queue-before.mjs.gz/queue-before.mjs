import assert from 'node:assert/strict';
import {performance,PerformanceObserver} from 'node:perf_hooks';
const observer=new PerformanceObserver(()=>{});
observer.observe({entryTypes:['mark','resource']});
performance.mark('queued-before-replacement');
observer.observe({entryTypes:['resource']});
assert.deepEqual(observer.takeRecords().map(entry=>entry.name),['queued-before-replacement']);
observer.disconnect();performance.clearMarks();
