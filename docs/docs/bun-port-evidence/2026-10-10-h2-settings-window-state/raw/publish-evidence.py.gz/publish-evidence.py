from pathlib import Path
import json,gzip,hashlib,subprocess,tempfile,re
r=Path.cwd();t=r/'zig-out/h2-window-control-port-2026-10-10';dest=r/'docs/docs/bun-port-evidence/2026-10-10-h2-settings-window-state';dest.mkdir(parents=True,exist_ok=True)
checks=json.loads((t/'regression-summary.json').read_text());assert all(row['exit']==0 for row in checks['records'])
assert '81 pass' in (t/'abi.log').read_text()
assert 'Build Summary: 34/34 steps succeeded' in (t/'build-lifetime.log').read_text()
rows=json.loads((t/'lifetime-complete/summary.json').read_text())['records'];assert len(rows)==9 and all(row['exit']==0 and row['validation_exit']==0 for row in rows)
counts={k:0 for k in ['passed','failed','skipped','todo','process_checks_passed','skipped_files','comment_only_files']}
for i in range(1,10):
 d=json.loads((t/'lifetime-complete'/f'validate-{i}.json').read_text());assert d['successful']
 for k in counts:counts[k]+=d['summary'][k]
(t/'lifetime-complete/validated-totals.json').write_text(json.dumps(counts,indent=2)+'\n')
files=[]
def retain(data,name):
 p=dest/(name+'.gz');p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(gzip.compress(data,mtime=0));files.append({'path':str(p.relative_to(dest)),'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
for p in sorted(t.rglob('*')):
 if p.is_file() and p.suffix in ['.json','.jsonl','.xml','.log','.txt','.mjs','.js','.ts','.zig','.py','.stdout','.stderr']:retain(p.read_bytes(),'raw/'+str(p.relative_to(t)))
for n,d in json.loads((t/'tested-source-current.json').read_text()).items():
 data=(r/n).read_bytes();assert hashlib.sha256(data).hexdigest()==d,n;retain(data,'source/'+n)
for row in json.loads((t/'source-audit.json').read_text()):
 p=r/'packages/runtime/test/test'/row['file'];assert hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256'];assert p.read_bytes()==(Path('/Users/chris/Code/bun/test')/row['file']).read_bytes()
manifest={'schema':1,'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'upstream':'4982b91e3702094330f3be3883354c52b8c01323','platform':'Darwin arm64','results':{'original_files':9,'counts':counts,'native_regression_groups':7,'source_state_tests':4,'abi_tests':81,'abi_assertions':1332,'debug_steps':34,'debug_peak_tree_mb':5659,'conformance_peak_tree_mb':175},'features':['Bounded, rebased connection/stream flow credit with retained negative debt after stream settings reductions.','Connection window API remains separate from stream initial-window settings.','FIFO settings snapshots and per-update callbacks, with pending-state tracking and explicit cancellation.','Encoded/retained custom settings and requested peer identifiers, using actual numeric JavaScript properties.','Acknowledged receive limits retain valid in-flight allowances; graceful close waits for outstanding settings work.'],'verification_scope':'Valid protocol conformance and source-level defensive bounds. No adversarial wire reproduction was performed. Original assertions, fixtures, allocations and case deadlines are unchanged.','limitations':['Initial valid conformance passed eight of nine files; custom settings and ordered callback/lifetime failures were retained. Superseded generated output with an unknown cancellation intrinsic was not credited as final verification.','Disk-guard refusals and cache cleanups are retained without test credit. Cleanup removed only verified duplicate evidence or obsolete cache outputs after terminal builds, preserving current source/executable outputs.','This is a nine-file conformance checkpoint, not proof that the previous 893-entry or complete Bun suite passes. Remaining internal HTTP2/Undici, wire/state, TLS, conflicting assertions (#868), whole-suite and Release/ASAN/all-platform scope remain open under #66/#867.'],'reference':'https://www.rfc-editor.org/rfc/rfc9113.html#section-6.9.2','files':files}
(dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for row in files:
 data=gzip.decompress((dest/row['path']).read_bytes());assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
with tempfile.TemporaryDirectory(prefix='home-h2-state-evidence-') as temp:
 restored=Path(temp)
 for row in files:
  if row['path'].startswith('raw/lifetime-complete/corpus-'):
   p=restored/row['path'].removeprefix('raw/lifetime-complete/').removesuffix('.gz');p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(gzip.decompress((dest/row['path']).read_bytes()))
 for i in range(1,10):
  result=subprocess.run(['python3',str(r/'scripts/summarize-bun-corpus.py'),str(restored/f'corpus-{i}')],capture_output=True,text=True);assert result.returncode==0,(i,result.stdout,result.stderr)
print(json.dumps({'archives':len(files),'restored_reports':9,'counts':counts}))
