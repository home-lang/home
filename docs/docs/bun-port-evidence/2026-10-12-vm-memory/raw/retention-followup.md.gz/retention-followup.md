The independent control now confirms retention in both Home and installed Bun 1.4.2 without invoking measureMemory: an unused context clears, while an evaluated context remains reachable across four event-loop turns/full collections. The Node memory/lifetime reference retires its dropped context.

Native graph attribution must continue reporting the marked evaluated context. The lifetime assertion remains failed and is preserved alongside passing unequal-allocation, collection timing, overlapping-request and shutdown controls. #870 remains open for complete memory/lifetime proof.
