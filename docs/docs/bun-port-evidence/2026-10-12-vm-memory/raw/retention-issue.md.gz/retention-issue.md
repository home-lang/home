Evaluated VM contexts remain reachable after their application references are dropped. In an ordinary control, an unused context's WeakRef clears while a context that evaluated `globalThis.payload = new Array(8000).fill(9); undefined` remains live across four event-loop turns/full collections. The same comparison runs without calling measureMemory, so measurement result construction is not needed to reproduce the retention.

The installed Bun 1.4.2 reference also retains the evaluated context in the control that never measures memory.

The new native memory graph correctly reports the remaining live context; suppressing that row would hide the lifetime gap. Node's equivalent memory/lifetime control retires the context. Retain the failing lifetime assertion separately from passing allocation/shape tests.

Acceptance:

- Identify and retire the actual strong owner of an evaluated context when no reachable user object requires it.
- Preserve retained Script, compiled function, module, callback and exported-value lifetimes.
- Verify ordinary dropped-context collection and memory graph membership without filtering live contexts or weakening assertions.
- Cover native owner-thread shutdown and test-realm retirement alongside ordinary VM conformance.

Parents: #66 and #870. Related inspector lifecycle: #428. This remains incomplete VM lifetime work, distinct from native memory attribution.
