import assert from 'node:assert/strict'
import {mkdtempSync,mkdirSync,writeFileSync,rmSync} from 'node:fs'
import {join,relative} from 'node:path'
import {tmpdir} from 'node:os'
import {spawnSync} from 'node:child_process'
const root=mkdtempSync(join(tmpdir(),'home-mixed-root-reference-'))
try {
 const primary=join(root,'packages/runtime/test/test/js/bun/test/suite'),secondary=join(root,'secondary/packages/runtime/test/test/js/bun/test/suite');mkdirSync(primary,{recursive:true});mkdirSync(secondary,{recursive:true})
 const a=join(primary,'a.test.js');writeFileSync(a,"import {test} from 'bun:test';test('primary',()=>console.log('PRIMARY'));")
 writeFileSync(join(primary,'b.test.js'),"import {test,expect} from 'bun:test';test('unselected',()=>expect(false).toBe(true));")
 writeFileSync(join(secondary,'second.test.js'),"import {test} from 'bun:test';test('secondary',()=>console.log('SECONDARY'));")
 for(const mode of ['filters','paths']){
  const args=[relative(root,a),relative(root,secondary)].map(p=>mode==='paths'?'./'+p:p)
  const result=spawnSync('/Users/chris/.bun/bin/bun',['test',...args],{cwd:root,encoding:'utf8',timeout:10000})
  console.log(mode,'status',result.status,'stderr',result.stderr)
  if(mode==='paths'){assert.equal(result.status,0);assert.match(result.stdout,/PRIMARY/);assert.match(result.stdout,/SECONDARY/)}
 }
}finally{rmSync(root,{recursive:true,force:true})}
