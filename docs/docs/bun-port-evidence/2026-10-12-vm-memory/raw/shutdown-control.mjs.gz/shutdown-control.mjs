import assert from 'node:assert/strict'
import {spawnSync} from 'node:child_process'
import {Worker} from 'node:worker_threads'
const child=spawnSync(process.execPath,['-e',"require('node:vm').measureMemory();process.exit(0)"],{encoding:'utf8',timeout:10000,env:{...process.env,BUN_DESTRUCT_VM_ON_EXIT:'1'}})
assert.equal(child.error,undefined);assert.equal(child.signal,null);assert.equal(child.status,0,child.stderr)
const worker=new Worker(`const {parentPort}=require('node:worker_threads');require('node:vm').measureMemory();parentPort.on('message',()=>{});parentPort.postMessage('pending')`,{eval:true})
await new Promise((resolve,reject)=>{worker.once('message',resolve);worker.once('error',reject)})
const exit=await worker.terminate();assert.equal(typeof exit,'number')
console.log('pending VM measurement requests retire on explicit VM destruction and worker shutdown')
