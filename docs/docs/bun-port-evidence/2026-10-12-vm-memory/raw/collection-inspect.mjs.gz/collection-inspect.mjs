import vm from 'node:vm'
const tick=()=>new Promise(resolve=>setImmediate(resolve))
function make(run){const context=vm.createContext({});if(run)vm.runInContext('globalThis.payload=new Array(8000).fill(9);undefined',context);return new WeakRef(context)}
const empty=make(false),evaluated=make(true)
for(let i=0;i<4;i++){await tick();const m=await vm.measureMemory({mode:'detailed',execution:'eager'});console.log(i,'other',m.other.length,'empty',empty.deref()===undefined,'evaluated',evaluated.deref()===undefined)}
