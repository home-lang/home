from pathlib import Path
import os,subprocess,sys,json
root=Path(__file__).resolve().parents[2];task=Path(__file__).resolve().parent
build_log=(task/'build-integrated-repair.log').read_text()
if 'Build Summary: 54/54 steps succeeded' not in build_log:
 print('refusing validation without completed final-source build',flush=True)
 sys.exit(1)
steps=[['./zig-out/bin/home','run',str(task/'reference.mjs')],[sys.executable,str(task/'run-native.py'),'native-integrated'],[sys.executable,str(task/'run-corpus.py'),'original-integrated'],['/Users/chris/.bun/bin/bun','test','build-support/native_module_abi.test.ts','build-support/core_builtin_abi.test.ts','build-support/builtin_exports.test.ts'],[sys.executable,'-B','scripts/test_summarize_bun_corpus.py'],[sys.executable,str(task/'validate-all-reports.py')]]
rows=[]
for i,command in enumerate(steps,1):
 with (task/f'validation-integrated-step-{i}.log').open('wb') as log:result=subprocess.run(command,cwd=root,env=os.environ.copy(),stdout=log,stderr=subprocess.STDOUT)
 rows.append({'command':command,'exit':result.returncode});(task/'validation-integrated-summary.json').write_text(json.dumps(rows,indent=2)+'\n');print('step',i,result.returncode,flush=True)
 if result.returncode:sys.exit(result.returncode)
