import assert from 'node:assert/strict'
import vm from 'node:vm'
const tick=()=>new Promise(resolve=>setImmediate(resolve))
const collect=()=>globalThis.Bun?Bun.gc(true):globalThis.gc()
let synchronous=true
const eager=vm.measureMemory({execution:'eager'}).then(result=>{assert.equal(synchronous,false);return result})
synchronous=false;await eager
const lazy=vm.measureMemory({mode:'detailed'});collect();assert.equal((await lazy).other.length,0)
const together=[vm.measureMemory({execution:'eager'}),vm.measureMemory({mode:'detailed',execution:'eager'}),vm.measureMemory()];collect();const all=await Promise.all(together);assert.equal(all.length,3)
function releaseContext(){const context=vm.createContext({});vm.runInContext('globalThis.payload=new Array(8000).fill(9)',context);return new WeakRef(context)}
const weak=releaseContext();await tick()
let final
for(let i=0;i<3;i++){final=await vm.measureMemory({mode:'detailed',execution:'eager'});if(final.other.length===0)break;await tick()}
assert.equal(final.other.length,0);assert.equal(weak.deref(),undefined)
console.log('VM measurement async delivery, lazy/full collection, overlapping requests and dead-context retirement passed')
