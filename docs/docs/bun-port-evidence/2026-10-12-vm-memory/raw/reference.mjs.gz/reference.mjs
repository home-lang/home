import assert from 'node:assert/strict'
import vm from 'node:vm'
function check(range){assert.equal(typeof range.jsMemoryEstimate,'number');assert(range.jsMemoryEstimate>=0);assert(range.jsMemoryRange[0]<=range.jsMemoryEstimate);assert(range.jsMemoryEstimate<=range.jsMemoryRange[1])}
const small=vm.createContext({}),large=vm.createContext({})
vm.runInContext('globalThis.payload=new Array(2000).fill(7)',small)
vm.runInContext('globalThis.payload=new Array(8000).fill(11)',large)
const measured=await vm.measureMemory({mode:'detailed',execution:'eager'})
check(measured.total);check(measured.current);assert.equal(measured.other.length,2)
for(const range of measured.other)check(range)
const sizes=measured.other.map(range=>range.jsMemoryEstimate).sort((a,b)=>a-b)
assert(sizes[1]>sizes[0]+10000,JSON.stringify(measured))
assert(measured.other.every(range=>range.jsMemoryEstimate<measured.total.jsMemoryEstimate))
assert.equal(small.payload.length,2000);assert.equal(large.payload.length,8000)
console.log('native VM memory attributes unequal context allocations and reports bounded shared estimates')
