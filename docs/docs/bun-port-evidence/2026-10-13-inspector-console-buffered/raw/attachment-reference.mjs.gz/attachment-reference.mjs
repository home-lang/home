import vm from 'node:vm'
import { Session } from 'node:inspector/promises'
const context=vm.createContext({}, {name:'attachment-reference'})
console.count('before-count'); console.time('before-time')
vm.runInContext("console.count('before-count'); console.time('before-time')",context)
const session=new Session();session.connect();const events=[],contexts=[]
session.on('Runtime.consoleAPICalled',e=>events.push(e.params));session.on('Runtime.executionContextCreated',e=>contexts.push(e.params.context))
await session.post('Runtime.enable');const realm=contexts.find(c=>c.name==='attachment-reference')
const rows=[]
for(const contextId of [undefined,realm.id]){const start=events.length;await session.post('Runtime.evaluate',{contextId,expression:"console.count('before-count'); console.timeEnd('before-time')"});rows.push({phase:'before-attachment',realm:contextId!==undefined,events:events.slice(start)})}
await session.post('Runtime.disable');vm.runInContext("console.count('disabled-count'); console.time('disabled-time')",context)
await session.post('Runtime.enable');const start=events.length;vm.runInContext("console.count('disabled-count'); console.timeEnd('disabled-time')",context);rows.push({phase:'runtime-disabled',events:events.slice(start)})
session.disconnect();process.stdout.write('ATTACHMENT_RESULT='+JSON.stringify(rows)+'\n');process.stdout.write(String(vm.runInContext('6*7',context))+'\n')
