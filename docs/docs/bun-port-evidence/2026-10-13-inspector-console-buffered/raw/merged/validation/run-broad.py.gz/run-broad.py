from pathlib import Path
import subprocess,sys,os,json
p=Path(__file__).resolve().parent;rows=[]
commands=[['./zig-out/bin/home',str(p/'console-callback-gc.mjs')],[sys.executable,str(p/'run-realm-regressions.py')],[sys.executable,str(p/'run-corpus.py'),'original-final'],[sys.executable,str(p/'run-native.py'),'native-final'],['/Users/chris/.bun/bin/bun','test','build-support/native_module_abi.test.ts','build-support/core_builtin_abi.test.ts','build-support/builtin_exports.test.ts'],[sys.executable,'-B','scripts/test_summarize_bun_corpus.py']]
for i,c in enumerate(commands,1):
 with (p/f'broad-{i}.log').open('wb') as log:r=subprocess.run(c,env=os.environ.copy(),stdout=log,stderr=subprocess.STDOUT,timeout=1200)
 rows.append({'command':c,'exit':r.returncode});(p/'broad-results.json').write_text(json.dumps(rows,indent=2)+'\n');print(i,r.returncode,flush=True)
 if r.returncode:sys.exit(r.returncode)
