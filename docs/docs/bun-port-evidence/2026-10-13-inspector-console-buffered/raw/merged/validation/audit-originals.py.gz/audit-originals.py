from pathlib import Path
import json,hashlib,subprocess
p=Path(__file__).resolve().parent;root=p.parents[3];selection=json.loads((p/'selection.json').read_text());counts={k:0 for k in ['passed','failed','skipped','todo','filtered','retry_attempts']};failed=[];process=0;identities=[]
for index,name in enumerate(selection,1):
 d=json.loads((p/'original-final'/f'validate-{index}.json').read_text());assert not d['errors'];assert d['capture_completeness']['incomplete']==0
 for key in counts:counts[key]+=d['counts'].get(key,0)
 failed.extend(c['name'] for c in d['cases'] if c['status']=='failed');process+=d['summary']['process_checks_passed']
 original=Path('/Users/chris/Code/bun/test')/name;copy=root/'packages/runtime/test/test'/name;assert original.read_bytes()==copy.read_bytes();identities.append({'file':name,'sha256':hashlib.sha256(copy.read_bytes()).hexdigest()})
assert counts=={'passed':53,'failed':1,'skipped':0,'todo':0,'filtered':0,'retry_attempts':0},counts
assert process==17 and failed==['unsupported method throws'],(process,failed)
(p/'original-conflict-audit.json').write_text(json.dumps({'counts':counts,'process_checks_passed':process,'unchanged_failed_cases':failed,'pass_credit_for_conflict':False,'original_file_hashes':identities},indent=2)+'\n');print(counts,'process checks',process,'retained conflict',failed)
