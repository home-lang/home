import vm from 'node:vm'
import { Session } from 'node:inspector/promises'
const session = new Session(); session.connect()
const contexts = []; const events = []
session.on('Runtime.executionContextCreated', e => contexts.push(e.params.context))
session.on('Runtime.consoleAPICalled', e => events.push(e.params))
await session.post('Runtime.enable')
const sandbox = vm.createContext({}, {name: 'console-method-realm'})
const realm = contexts.find(c => c.name === 'console-method-realm')
const methods = [ ['debug','console.debug("marker-debug", 1)'], ['info','console.info("marker-info", 2)'], ['error','console.error("marker-error", 3)'], ['trace','console.trace("marker-trace", 4)'], ['dir','console.dir({answer:42})'], ['dirxml','console.dirxml({answer:43})'], ['table','console.table([{answer:44}])'], ['assert','console.assert(false, "marker-assert", 5)'], ['group','console.group("marker-group")'], ['groupCollapsed','console.groupCollapsed("marker-collapsed")'], ['groupEnd','console.groupEnd()'], ['clear','console.clear()'], ['count','console.count("marker-count"); console.count("marker-count"); console.countReset("marker-count"); console.count("marker-count")'], ['timer','console.time("marker-time"); console.timeLog("marker-time", {answer:45}); console.timeEnd("marker-time")'] ]
const results=[]
for(const contextId of [undefined,realm.id]) {
 for(const [method,expression] of methods) {
  const start=events.length
  const result=await session.post('Runtime.evaluate',{contextId,expression})
  await new Promise(r=>setImmediate(r))
  results.push({realm:contextId!==undefined,method,exception:result.exceptionDetails,events:events.slice(start)})
 }
}
if(vm.runInContext('6*7',sandbox)!==42) throw new Error('retained context unavailable')
session.disconnect()
process.stdout.write('PROBE_RESULT='+JSON.stringify(results)+'\n')
