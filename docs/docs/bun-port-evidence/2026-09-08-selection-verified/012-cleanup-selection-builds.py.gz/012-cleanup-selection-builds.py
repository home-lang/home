from pathlib import Path
import hashlib,json,subprocess
root=Path.cwd();out=root/'zig-out/bun-port-recovery/selection-build-cleanup.json'
assert not out.exists()
folders=['26fc05a449245e12c1fcb4273662a835','6bb7f93553c0a2e725389e1c232eaae0','c65b8ea181931ff36eb6f2855cab4b7f','1a865a955ba7c1ff15c14db13156ac05','9e37bf06759981f9fe7c5a8fd1a3bc00','af0b1e54c033e4d5a033bb78ebc3d4a6','87353da1c21c66560d8c9826ab5500bd','1214e81d43226846eda133d727c2c002']
commands=subprocess.check_output(['ps','-Ao','command'],text=True)
# The cleanup's command line contains only this script path, never these hashes.
assert not any(folder in commands for folder in folders), 'an old artifact is in use'
def sha(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
 return h.hexdigest()
preserved={str(p.relative_to(root)):sha(p) for p in [root/'zig-out/bin/home',root/'.native/liblolhtml.a',root/'.zig-cache/o/ebce37bd4f0f7f60fc28eeaca4e9171b/test']}
assert preserved['.native/liblolhtml.a']=='ab5b97ecad7fe4527a870cb42d7aea5ec0ce05fd2a8a02acd9a6b67cc4fe0648'
rows=[]
for folder in folders:
 directory=root/'.zig-cache/o'/folder
 if not directory.exists():continue
 for p in directory.iterdir():
  assert p.is_file() and p.name in ['home','home_zcu.o','test','test_zcu.o'],str(p)
  rows.append({'path':str(p.relative_to(root)),'bytes':p.stat().st_size,'sha256':sha(p),'deleted':False})
manifest={'scope':'obsolete generated compiler outputs in this owned worktree only','preserved':preserved,'files':rows}
def save():out.write_text(json.dumps(manifest,indent=2)+'\n')
save()
for row in rows:(root/row['path']).unlink();row['deleted']=True;save()
for folder in folders:
 directory=root/'.zig-cache/o'/folder
 if directory.exists():directory.rmdir()
manifest['preserved_unchanged']=all(sha(root/path)==digest for path,digest in preserved.items());manifest['bytes_deleted']=sum(row['bytes'] for row in rows);save();assert manifest['preserved_unchanged'];print(manifest['bytes_deleted'])
