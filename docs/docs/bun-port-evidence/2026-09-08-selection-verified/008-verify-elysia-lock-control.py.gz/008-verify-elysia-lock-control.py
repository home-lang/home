import hashlib,json,os,signal,subprocess,tempfile,time,shutil
from pathlib import Path
root=Path.cwd();evidence=root/'zig-out/bun-port-recovery';out=evidence/'elysia-lock-control';out.mkdir()
vendor=root/'packages/runtime/test/vendor/elysia';bun=Path('/Users/chris/Code/bun/build/release/bun')
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
assert sha(bun)=='47a87c1dea30da59c2733cce80118ea59bd338c616c6378f1c7f55e5f2b92c87'
original=subprocess.check_output(['git','-C',str(vendor),'show','HEAD:bun.lock']);native=(vendor/'bun.lock').read_bytes()
(out/'original.bun.lock').write_bytes(original);(out/'home.bun.lock').write_bytes(native)
manifest={'scope':'pinned Bun installation control; no corpus passes','bun_sha256':sha(bun),'original_lock_sha256':hashlib.sha256(original).hexdigest(),'home_lock_sha256':hashlib.sha256(native).hexdigest(),'timeout_ms':180000}
with tempfile.TemporaryDirectory(prefix='home-elysia-lock-control-') as temporary:
 base=Path(temporary);project=base/'project';project.mkdir();cache=base/'tmp';cache.mkdir();aliases=base/'bin';aliases.mkdir()
 for name in ['bun','node']:(aliases/name).symlink_to(bun)
 for name in ['package.json','bun.lock','.npmrc']:(project/name).write_bytes(subprocess.check_output(['git','-C',str(vendor),'show','HEAD:'+name]))
 env=os.environ.copy();env.update(CI='1',FORCE_COLOR='1',BUN_FEATURE_FLAG_INTERNAL_FOR_TESTING='1',BUN_DEBUG_QUIET_LOGS='1',BUN_GARBAGE_COLLECTOR_LEVEL='1',BUN_JSC_randomIntegrityAuditRate='1.0',BUN_RUNTIME_TRANSPILER_CACHE_PATH='0',BUN_ENABLE_CRASH_REPORTING='0',PATH=str(aliases)+os.pathsep+env.get('PATH',''))
 for name in ['TMPDIR','BUN_TMPDIR','BUN_INSTALL_CACHE_DIR','TEST_TMPDIR']:env[name]=str(cache)
 start=time.monotonic();child=subprocess.Popen([str(bun),'install'],cwd=project,env=env,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True);timed_out=False
 try:stdout,stderr=child.communicate(timeout=180)
 except subprocess.TimeoutExpired:
  timed_out=True;os.killpg(child.pid,signal.SIGKILL);stdout,stderr=child.communicate()
 (out/'install.stdout').write_bytes(stdout);(out/'install.stderr').write_bytes(stderr);control=(project/'bun.lock').read_bytes();(out/'control.bun.lock').write_bytes(control)
 manifest.update(returncode=child.returncode,timed_out=timed_out,seconds=time.monotonic()-start,control_lock_sha256=hashlib.sha256(control).hexdigest(),home_lock_matches_control=control==native,only_change_is_manifest_peer_range=original.replace(b'"exact-mirror": "^0.2.6"',b'"exact-mirror": ">= 0.0.9"',1)==native,manifest_peer_range=json.loads((project/'package.json').read_text())['peerDependencies']['exact-mirror'])
setup=json.loads((evidence/'elysia-native-setup-initialized/manifest.json').read_text());manifest['all_original_tests_and_sources_unchanged']=setup['changed_original_sources']==['bun.lock'];manifest['home_install_and_build_succeeded']=setup['install_succeeded'] and setup['build_succeeded'];manifest['bun_unchanged']=sha(bun)==manifest['bun_sha256'];manifest['verified']=manifest['returncode']==0 and not timed_out and all(manifest[k] for k in ['home_lock_matches_control','only_change_is_manifest_peer_range','all_original_tests_and_sources_unchanged','home_install_and_build_succeeded','bun_unchanged'])
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(manifest,indent=2));raise SystemExit(0 if manifest['verified'] else 1)
