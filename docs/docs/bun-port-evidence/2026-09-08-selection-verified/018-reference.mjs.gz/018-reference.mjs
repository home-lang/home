
import {readFileSync, writeFileSync, readdirSync, existsSync} from 'node:fs';
import {basename, extname, dirname, join, sep} from 'node:path';
const runner = readFileSync(process.argv[2], 'utf8');
const corpusRoot = process.argv[3];
const out = process.argv[4];
const mirror = process.argv[5];
const vendorRoot = process.argv[6];
const definitions = ['getTestExpectations', 'getTestModifiers', 'isJavaScript', 'isJavaScriptTest', 'isNodeTest', 'isClusterTest', 'isTest', 'isTestStrict', 'isHidden', 'getTests', 'getRelevantTests'];
let code = '';
for (const name of definitions) {
  const expression = new RegExp('^function ' + name + '\\([^]*?^}', 'm');
  const match = runner.match(expression);
  if (!match) throw new Error('missing pinned function ' + name);
  code += match[0] + '\n';
}
let context = {executable:'home',os:'linux',arch:'x64',is_ci:true};
let isCI=true, isMacOS=false, isX64=true, isQuiet=true, options={}, filters=[], allFiles=[];
let cwd=corpusRoot.slice(0, -5);
const getOs=()=>context.os, getArch=()=>context.arch, getDistro=()=>context.distro,
  getDistroVersion=()=>context.distro_version, getAbi=()=>context.abi, getAbiVersion=()=>context.abi_version;
const functions = eval(code + '; ({getTestExpectations,getTestModifiers,getTests,getRelevantTests})');
const files=functions.getTests(corpusRoot);
const expectations=functions.getTestExpectations();
const upstream=readFileSync(join(corpusRoot,'expectations.txt'),'utf8');
cwd=mirror.slice(0,-5);
const homeExpectations=functions.getTestExpectations();
const homeSource=readFileSync(join(mirror,'expectations.txt'),'utf8');
const contexts=[
 {executable:'home',os:'darwin',arch:'aarch64',distro:'macOS',distro_version:'26.0'},
 {executable:'home-asan',os:'darwin',arch:'x64',distro:'macOS',distro_version:'15.6'},
 {executable:'home',os:'darwin',arch:'x64',is_ci:false},
 {executable:'bun-linux-x64-baseline',os:'linux',arch:'x64',distro:'ubuntu',distro_version:'24.04',abi:'gnu',abi_version:'2.39'},
 {executable:'home-asan',os:'linux',arch:'x64',distro:'alpine',distro_version:'3.23',abi:'musl',abi_version:'1.2.5'},
 {executable:'home',os:'linux',arch:'aarch64',distro:'debian',distro_version:'13',abi:'gnu',abi_version:'2.41'},
 {executable:'home.exe',os:'windows',arch:'aarch64',distro:'Microsoft Windows [Version 10.0.26100]',distro_version:'Microsoft Windows [Version 10.0.26100]'},
 {executable:'bun-windows-x64-baseline-asan.exe',os:'windows',arch:'x64'},
];
const configurations=[{}, {node_only:true}, {includes:[' ,js/node, js/bun, '],excludes:['http2,fs/']}, {shard:0,max_shards:3}, {shard:1,max_shards:3}, {shard:2,max_shards:3}, {filters:['html','expect.test'],shard:2,max_shards:3}, {includes:[' , '],modified_tests:['js/bun/test/expect.test.js','js/web/html/html-rewriter-doctype.test.ts']}];
const runs=[], reference=[];
for (const current of contexts) for(const config of configurations) {
 context={is_ci:true,...current}; isCI=context.is_ci; isMacOS=context.os==='darwin'; isX64=context.arch==='x64';
 options={'node-tests':config.node_only,include:config.includes,exclude:config.excludes,shard:String(config.shard??0),'max-shards':String(config.max_shards??1)};
 filters=config.filters??[]; allFiles=(config.modified_tests??[]).map(x=>'test/'+x);
 const modifiers=functions.getTestModifiers(context.executable);
 const selected=functions.getRelevantTests(corpusRoot,modifiers,homeExpectations);
 const savedOptions=options; options={...options, "max-shards":"1"};
 const upstreamSelected=new Set(functions.getRelevantTests(corpusRoot,modifiers,expectations)); options=savedOptions;
 runs.push({context,options:config});
 reference.push({modifiers,selected:selected.map(x=>files.indexOf(x)),additional_home_coverage:selected.filter(x=>!upstreamSelected.has(x)).map(x=>files.indexOf(x))});
}
writeFileSync(join(out,'input.json'),JSON.stringify({files,upstream_expectations:upstream,home_expectations:homeSource,runs}));
writeFileSync(join(out,'reference.json'),JSON.stringify({definitions:code,runs:reference}));
const vendor=JSON.parse(readFileSync(join(mirror,'vendor.json'),'utf8'))[0];
const begin=runner.indexOf('        const isTest = path => {',runner.indexOf('async function getVendorTests'));
const end=runner.indexOf('\n        return {',begin);
const block=runner.slice(begin,end);
const vendorSelection=new Function('vendorPath','testParentPath','testPathPrefix','testExtensions','skipTests','filters','readdirSync','join','isJavaScriptTest',block+'\nreturn testPaths;');
const isJavaScriptTest=new Function('basename',code+';return isJavaScriptTest;')(basename);
const entries=readdirSync(join(vendorRoot,'test'),{encoding:'utf8',recursive:true});
const selected=vendorSelection(vendorRoot,join(vendorRoot,'test'),'test',vendor.testExtensions,vendor.skipTests,[],readdirSync,join,isJavaScriptTest);
writeFileSync(join(out,'vendor-reference.json'),JSON.stringify({block,entries,selected:selected.map(x=>x.slice(5))}));
