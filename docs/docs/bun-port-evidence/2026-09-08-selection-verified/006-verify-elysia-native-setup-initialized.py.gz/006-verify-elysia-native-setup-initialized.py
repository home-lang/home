import hashlib,json,os,signal,subprocess,tempfile,time
from pathlib import Path
root=Path.cwd(); evidence=root/'zig-out/bun-port-recovery'; out=evidence/'elysia-native-setup-initialized';out.mkdir()
home=root/'zig-out/bin/home';vendor=root/'packages/runtime/test/vendor/elysia'
assert 'Build Summary: 23/23 steps succeeded' in (evidence/'build-corpus-selection-vendor-initialized.log').read_text()
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
files=subprocess.check_output(['git','-C',str(vendor),'ls-files','-z']).decode().split('\0')
originals={path:sha(vendor/path) for path in files if path and (vendor/path).is_file()}
sources=['packages/home_test/src/corpus_selection.zig','packages/home_test/src/corpus_vendor.zig','packages/home_test/src/corpus_runner.zig','packages/home_test/src/home_test.zig','packages/home_test/src/test_root.zig']
manifest={'runtime_source_sha256':{name:sha(root/name) for name in sources},'kind':'native vendor setup; no test-case credit','source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'home_sha256':sha(home),'vendor_revision':subprocess.check_output(['git','-C',str(vendor),'rev-parse','HEAD'],text=True).strip(),'original_sources':originals,'runs':[]}
def save():(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
save()
base=os.environ.copy()
for key in ['HOME_BUN_TEST_EXECUTABLE','HOME_CORPUS_FULL_VM','HOME_BUN_CORPUS_REPORT_DIR','HOME_CORPUS_VENDOR_PLAN_OUTPUT']:
 base.pop(key,None)
base.update(HOME_NATIVE_VM='1',CI='1',FORCE_COLOR='1',BUN_FEATURE_FLAG_INTERNAL_FOR_TESTING='1',BUN_DEBUG_QUIET_LOGS='1',BUN_GARBAGE_COLLECTOR_LEVEL='1',BUN_JSC_randomIntegrityAuditRate='1.0',BUN_RUNTIME_TRANSPILER_CACHE_PATH='0',BUN_ENABLE_CRASH_REPORTING='0')
def execute(label,args,timeout):
 with tempfile.TemporaryDirectory(prefix='home-elysia-setup-') as temporary:
  temporary=Path(temporary);aliases=temporary/'bin';aliases.mkdir();cache=temporary/'tmp';cache.mkdir()
  for alias in ['bun','node','home']:(aliases/alias).symlink_to(home)
  env=base.copy();env['PATH']=str(aliases)+os.pathsep+base.get('PATH','')
  for key in ['TMPDIR','BUN_TMPDIR','TEST_TMPDIR','BUN_INSTALL_CACHE_DIR']:env[key]=str(cache)
  argv=[str(home),*args]
  row={'label':label,'argv':argv,'cwd':str(vendor),'timeout_ms':timeout*1000,'status':'started','aliases':{alias:sha(aliases/alias) for alias in ['bun','node','home']}}
  manifest['runs'].append(row);save();start=time.monotonic()
  child=subprocess.Popen(argv,cwd=vendor,env=env,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
  timed_out=False
  try:stdout,stderr=child.communicate(timeout=timeout)
  except subprocess.TimeoutExpired:
   timed_out=True;os.killpg(child.pid,signal.SIGKILL);stdout,stderr=child.communicate()
  (out/(label+'.stdout')).write_bytes(stdout);(out/(label+'.stderr')).write_bytes(stderr)
  row.update(status='completed',returncode=child.returncode,timed_out=timed_out,seconds=time.monotonic()-start,stdout_sha256=sha(out/(label+'.stdout')),stderr_sha256=sha(out/(label+'.stderr')))
  save();print(json.dumps(row),flush=True)
  return child.returncode==0 and not timed_out
installed=execute('install',['install'],180)
built=execute('build',['run','build'],60) if installed else False
changed=[path for path,digest in originals.items() if not (vendor/path).is_file() or sha(vendor/path)!=digest]
manifest.update(original_sources_unchanged=not changed,changed_original_sources=changed,home_unchanged=sha(home)==manifest['home_sha256'],install_succeeded=installed,build_succeeded=built)
(out/'vendor-status.txt').write_bytes(subprocess.check_output(['git','-C',str(vendor),'status','--short']))
if changed:(out/'vendor-source-diff.patch').write_bytes(subprocess.check_output(['git','-C',str(vendor),'diff']))
save()
raise SystemExit(0 if installed and built and not changed and manifest['home_unchanged'] else 1)
