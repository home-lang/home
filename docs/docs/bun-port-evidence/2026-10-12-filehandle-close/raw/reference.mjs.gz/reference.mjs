import assert from 'node:assert/strict'
import * as fs from 'node:fs'
import { join } from 'node:path'
import { tmpdir } from 'node:os'
const dir=fs.mkdtempSync(join(tmpdir(),'home-filehandle-positions-'))
try {
 const path=join(dir,'data');fs.writeFileSync(path,'abcdef')
 const handle=await fs.promises.open(path,'r+')
 try {
  const read=await handle.read(Buffer.alloc(2),0,2,2n)
  assert.equal(read.bytesRead,2);assert.equal(read.buffer.toString(),'cd')
  console.log('bigint read position passed')
  const written=await handle.write(Buffer.from('XY'),0,2,2n)
  console.log('bigint write bytes',written.bytesWritten,'contents',fs.readFileSync(path,'utf8'))
  const empty=await handle.write(Buffer.alloc(0))
  console.log('empty write result prototype',Object.getPrototypeOf(empty)===Object.prototype?'Object':Object.getPrototypeOf(empty)===null?'null':'other')
  await handle.close()
  for (const [method,args] of [['read',[Buffer.alloc(1)]],['appendFile',['x']]]) {
   try {await handle[method](...args)}catch(error){console.log('closed',method,error.code,error.syscall)}
  }
 } finally {await handle.close()}
}finally{fs.rmSync(dir,{recursive:true,force:true})}
