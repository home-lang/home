import assert from 'node:assert/strict'
import * as fs from 'node:fs'
import {join} from 'node:path'
import {tmpdir} from 'node:os'
const dir=fs.mkdtempSync(join(tmpdir(),'home-filehandle-close-'))
try {
 const path=join(dir,'data');fs.writeFileSync(path,'abc\ndef\n')
 const handle=await fs.promises.open(path,'r')
 const close=handle.close
 await close();assert.equal(handle.fd,-1);await close()
 console.log('detached close passed')
 await assert.rejects(handle.read(Buffer.alloc(1)),{code:'EBADF',syscall:'read'})
 console.log('closed read syscall passed')
 const lines=await fs.promises.open(path,'r')
 try {assert.deepEqual(await Array.fromAsync(lines.readLines({autoClose:false})),['abc','def']);assert.ok(lines.fd>=0)}finally{await lines.close()}
 console.log('readLines retained ownership passed')
}finally{fs.rmSync(dir,{recursive:true,force:true})}
