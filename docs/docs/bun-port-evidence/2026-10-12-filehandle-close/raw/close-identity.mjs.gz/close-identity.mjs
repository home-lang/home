import assert from 'node:assert/strict'
import * as fs from 'node:fs'
import {tmpdir} from 'node:os'
import {join} from 'node:path'
const dir=fs.mkdtempSync(join(tmpdir(),'home-close-identity-'))
try {
 const path=join(dir,'data');fs.writeFileSync(path,'abc')
 const handle=await fs.promises.open(path,'r')
 const stream=handle.readableWebStream()
 const close=handle.close
 const first=close(),second=close()
 assert.strictEqual(first,second)
 await stream.cancel();await first;assert.equal(handle.fd,-1)
 console.log('deferred close retains one promise and bound receiver')
}finally{fs.rmSync(dir,{recursive:true,force:true})}
