from pathlib import Path
import subprocess,os,json,hashlib
p=Path('zig-out/readdir-performance-2026-10-14');rows=[]
commands=[('node-control',['/Users/chris/.local/share/pantry/global/packages/nodejs.org/v26.10.0/bin/node','tests/runtime/native-readdir-traversal.test.mjs']),('home-control',['zig-out/bin/home','tests/runtime/native-readdir-traversal.test.mjs']),('home-post',['zig-out/bin/home',str(p/'measure.mjs')]),('node-post',['/Users/chris/.local/share/pantry/global/packages/nodejs.org/v26.10.0/bin/node',str(p/'measure.mjs')]),('bun-post',['/Users/chris/.bun/bin/bun',str(p/'measure.mjs')])]
(p/'executable-post.json').write_text(json.dumps({'sha256':hashlib.sha256(Path('zig-out/bin/home').read_bytes()).hexdigest()},indent=2)+'\n')
for name,args in commands:
 with (p/(name+'.log')).open('wb') as out:
  try:r=subprocess.run(args,stdout=out,stderr=subprocess.STDOUT,timeout=180,env=os.environ.copy())
  except subprocess.TimeoutExpired:r=subprocess.CompletedProcess([],124)
 rows.append({'name':name,'exit':r.returncode});print(name,r.returncode,flush=True)
 if r.returncode:break
(p/'post-results.json').write_text(json.dumps(rows,indent=2)+'\n');raise SystemExit(any(x['exit'] for x in rows))
