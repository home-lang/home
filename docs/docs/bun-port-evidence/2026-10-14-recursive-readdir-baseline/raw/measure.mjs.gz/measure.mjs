import fs from 'node:fs'
import { performance } from 'node:perf_hooks'
import { resolve } from 'node:path'
const root = resolve('packages/runtime/test/test/js/node')
const measurements = []
for (const withFileTypes of [false, true]) {
  const before = performance.now()
  let result
  for (let i = 0; i < 200; i++) result = fs.readdirSync(root, { recursive: true, withFileTypes })
  const traversalMs = performance.now() - before
  const results = Array.from({ length: 200 }, () => result.slice())
  const sorting = performance.now()
  for (const row of results) row.sort()
  measurements.push({ withFileTypes, count: result.length, traversalMs, sortMs: performance.now() - sorting })
}
console.log(JSON.stringify({ runtime: process.execPath, measurements }))
