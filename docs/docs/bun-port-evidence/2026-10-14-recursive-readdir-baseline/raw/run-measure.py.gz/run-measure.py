from pathlib import Path
import subprocess,os,json
p=Path('zig-out/readdir-performance-2026-10-14');rows=[]
for name,binary in [('home','zig-out/bin/home'),('bun','/Users/chris/.bun/bin/bun'),('node','/Users/chris/.local/share/pantry/global/packages/nodejs.org/v26.10.0/bin/node')]:
 with (p/(name+'-baseline.log')).open('wb') as out:
  try:r=subprocess.run([binary,str(p/'measure.mjs')],stdout=out,stderr=subprocess.STDOUT,timeout=180,env=os.environ.copy())
  except subprocess.TimeoutExpired:r=subprocess.CompletedProcess([],124)
 rows.append({'name':name,'exit':r.returncode});print(name,r.returncode,flush=True)
(p/'baseline-results.json').write_text(json.dumps(rows,indent=2)+'\n')
