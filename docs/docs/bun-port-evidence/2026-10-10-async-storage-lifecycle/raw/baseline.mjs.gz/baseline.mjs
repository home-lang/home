import { AsyncLocalStorage } from 'node:async_hooks'
const a = new AsyncLocalStorage()
const b = new AsyncLocalStorage()
const rows = []
a.disable()
a.run('first', () => rows.push(['first', a.getStore()]))
rows.push(['after-disabled-run', a.getStore()])
a.run('outer', () => {
  a.disable()
  rows.push(['disabled-in-run', a.getStore()])
})
rows.push(['after-disable-in-run', a.getStore()])
a.run('outer', () => {
  a.enterWith('replacement')
  rows.push(['enter-in-run', a.getStore()])
})
rows.push(['after-enter-in-run', a.getStore()])
a.run('outer', () => b.run('other', () => {
  a.exit(() => rows.push(['exit', a.getStore(), b.getStore()]))
  rows.push(['after-exit', a.getStore(), b.getStore()])
}))
console.log(JSON.stringify(rows))
