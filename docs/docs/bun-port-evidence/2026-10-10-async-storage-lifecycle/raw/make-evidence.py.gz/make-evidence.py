from pathlib import Path
import json,gzip,hashlib,subprocess
root=Path(__file__).resolve().parents[2];task=Path(__file__).resolve().parent;base=root/'docs/docs/bun-port-evidence/2026-10-10-async-storage-lifecycle';base.mkdir(parents=True,exist_ok=True)
counts={};reports=[]
for path in sorted((task/'first').glob('validate-*.json')):
 data=json.loads(path.read_text());assert data['successful'],path
 for key,value in data['summary'].items():
  if isinstance(value,int):counts[key]=counts.get(key,0)+value
 reports.append(path.name)
assert len(reports)==14 and counts['failed']==0
records=[]
def add(path,name):
 data=path.read_bytes();target=base/(name+'.gz');target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(gzip.compress(data,mtime=0));assert gzip.decompress(target.read_bytes())==data;records.append({'path':str(target.relative_to(base)),'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
for p in sorted(task.rglob('*')):
 if not p.is_file() or p.name.startswith('issue-') or p.name=='archive-production.log':continue
 if p.suffix in ['.log','.json','.jsonl','.py','.mjs','.stdout','.stderr','.xml']:add(p,'raw/'+str(p.relative_to(task)))
for name in ['packages/runtime/upstream/src/js/node/async_hooks.ts','tests/runtime/native-async-storage-lifecycle.test.mjs']:add(root/name,'source/'+name)
manifest={'schema':1,'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'upstream':'4982b91e3702094330f3be3883354c52b8c01323','platform':'Darwin arm64','results':{'original_files':14,'counts':counts,'native_regression_groups':10,'generation_tests':2,'generation_assertions':596,'debug_steps':35,'debug_peak_tree_mb':5645,'conformance_peak_tree_mb':185},'features':['AsyncLocalStorage.run restores the actual outer snapshot even when a callback disables storage or replaces its context.','AsyncLocalStorage.exit preserves disabled status and other storage instances, with callback validation before mutation.','Native regression verifies prior store leak/crash, nested exit and exceptions, promise/snapshot/resource propagation and disable behavior.'],'limitations':['Two upstream TODOs are retained separately, without passing credit.','The old Home baseline crashes after disable within run; the new regression also fails on the prior first-run store leak.','Node controls differ by async-context backend: its async-hooks mode passes the native regression, while its newer frame mode retains captured stores after disable. Controls are retained without claiming universal equivalence.','Actual frame materialization remains #871; createHook/native API gaps, complete Bun suite and Release/ASAN/all-platform verification remain open under #66.'],'files':records}
(base/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(len(records),'verified archives',counts)
