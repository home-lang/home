#!/bin/sh
set -eu
export HOME_BIN="$PWD/zig-out/bin/home"
export BUN_DEV_SERVER_CLIENT_EXECUTABLE=/Users/chris/.local/share/pantry/global/packages/nodejs.org/v26.10.0/bin/node
export NPM_BIN=/Users/chris/.local/share/pantry/global/bin/npm
export BUN_DEBUG_QUIET_LOGS=1 KEEP_BAKE_TEMP=1
export HOME_BUN_CORPUS_REPORT_DIR="$PWD/zig-out/bake-corpus-2026-10-15/final-report"
export PATH="/Users/chris/.bun/bin:$PATH"
bash scripts/run-bake-corpus.sh
