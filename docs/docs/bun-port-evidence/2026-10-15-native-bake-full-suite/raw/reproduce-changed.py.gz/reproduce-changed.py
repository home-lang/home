from pathlib import Path
import tempfile,subprocess,json,os
r=Path(tempfile.mkdtemp(prefix='home-changed-repro.')); f=r/'packages/runtime/test/test/js/bun/test/suite';f.mkdir(parents=True);files=[]
for i in range(3):
 p=f/f'{i}.test.js';p.write_text(f"import {{test,expect}} from 'bun:test';import {{value}} from './dep{i}.js';test('changed {i}',()=>{{console.log('CHANGED:{i}');expect(value).toBeGreaterThanOrEqual(0);}});");(f/f'dep{i}.js').write_text(f'export const value={i};');files.append(str(p))
for args in (['init','-q'],['config','user.name','Fixture'],['config','user.email','fixture@home.invalid'],['add','.'],['commit','-qm','fixture']):subprocess.run(['/usr/bin/git',*args],cwd=r,check=True)
(f/'dep1.js').write_text('export const value=11;')
work=Path.cwd()/'zig-out/bake-corpus-2026-10-15';(work/'changed-repro-root.txt').write_text(str(r)+'\n')
for name,exe,paths in [('home-alias',Path.cwd()/'zig-out/bin/home',files),('home-realpath',Path.cwd()/'zig-out/bin/home',[str(Path(x).resolve()) for x in files]),('bun-alias',Path('/Users/chris/.bun/bin/bun'),files)]:
 env={**os.environ,'HOME_NATIVE_VM':'1','PATH':'/usr/bin:/bin:'+os.environ['PATH']};c=subprocess.run([str(exe),'test',*paths,'--changed=HEAD'],cwd=r,env=env,capture_output=True);(work/(name+'.stdout')).write_bytes(c.stdout);(work/(name+'.stderr')).write_bytes(c.stderr);print(name,c.returncode,c.stdout.decode(),c.stderr.decode()[:450])
