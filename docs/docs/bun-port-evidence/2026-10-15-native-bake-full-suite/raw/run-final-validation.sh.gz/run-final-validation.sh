#!/bin/sh
set -u
p=zig-out/bake-corpus-2026-10-15
export BUN_DEBUG_QUIET_LOGS=1 BUN_GARBAGE_COLLECTOR_LEVEL=1 BUN_FEATURE_FLAG_INTERNAL_FOR_TESTING=1 BUN_JSC_randomIntegrityAuditRate=1.0 BUN_RUNTIME_TRANSPILER_CACHE_PATH=0
HOME_CORPUS_SUITE_EVIDENCE_DIR="$PWD/$p/suite-controls" HOME_NATIVE_VM=1 zig-out/bin/home tests/runtime/native-corpus-suite.test.mjs > "$p/suite-controls.log" 2>&1
suite_status=$?
python3 packages/runtime/test/bake-development/run.py zig-out/bin/home > "$p/development-final.log" 2>&1
dev_status=$?
bash packages/runtime/test/bake-production/run.sh "$PWD/zig-out/bin/home" > "$p/production-final.log" 2>&1
prod_status=$?
printf '{"suite":%d,"development":%d,"production":%d}\n' "$suite_status" "$dev_status" "$prod_status" > "$p/final-controls-status.json"
test "$suite_status" = 0 && test "$dev_status" = 0 && test "$prod_status" = 0
