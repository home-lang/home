#!/bin/sh
set -u
p=zig-out/bake-corpus-2026-10-15
export BUN_DEBUG_QUIET_LOGS=1 BUN_GARBAGE_COLLECTOR_LEVEL=1 BUN_FEATURE_FLAG_INTERNAL_FOR_TESTING=1 BUN_JSC_randomIntegrityAuditRate=1.0 BUN_RUNTIME_TRANSPILER_CACHE_PATH=0
python3 packages/runtime/test/bake-development/run.py zig-out/bin/home > "$p/development-control.log" 2>&1
dev_status=$?
bash packages/runtime/test/bake-production/run.sh "$PWD/zig-out/bin/home" > "$p/production-control.log" 2>&1
prod_status=$?
python3 scripts/test_summarize_bun_corpus.py > "$p/validator-tests.log" 2>&1
validator_status=$?
/Users/chris/.bun/bin/bun test build-support/native_module_abi.test.ts > "$p/abi.log" 2>&1
abi_status=$?
bunx --bun pickier packages/runtime/test/bake-dependencies/README.md > "$p/lint.log" 2>&1
lint_status=$?
printf '{"development":%d,"production":%d,"validator":%d,"abi":%d,"lint":%d}\n' "$dev_status" "$prod_status" "$validator_status" "$abi_status" "$lint_status" > "$p/regression-status.json"
test "$dev_status" = 0 && test "$prod_status" = 0 && test "$validator_status" = 0 && test "$abi_status" = 0 && test "$lint_status" = 0
