import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import tarfile

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
command = json.loads((root / 'lint-command.json').read_text())
assert command['exit'] in (0, 1)
matches = re.findall(r'([\d,]+) problems \(([\d,]+) errors, ([\d,]+) warnings\)', (root / 'lint.log').read_text())
assert matches or command['exit'] == 0
errors, warnings = (tuple(int(value.replace(',', '')) for value in matches[-1][1:]) if matches else (0, 0))
assert (errors, warnings) == (11461, 10613), 'New publication finding must be repaired, not relabeled as baseline'
metadata = {
    'source_at_lint': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip(),
    'primary_evidence_sha256': json.loads((root / 'archive.json').read_text())['sha256'],
    'lint_status': {'status': 'terminal', 'exit': command['exit']},
    'lint_session': {'session': 90332, 'status': 'terminal', 'exit': command['exit']},
    'lint_scope': 'repository-wide read-only Pickier, no automatic fixes',
    'reported_errors': errors, 'reported_warnings': warnings,
    'changed_files': subprocess.check_output(['git', 'diff', '--name-only'], cwd=repo).decode().splitlines(),
    'publication_file_sha256': {name: hashlib.sha256((repo / name).read_bytes()).hexdigest() for name in ('README.md', 'docs/docs/TS_PERFORMANCE.md')},
    'lint_phase': 'post-documentation, read-only repository-wide run; original pre-documentation log remains in the primary archive',
    'semantic_and_benchmark_gates': 'all pass; existing repository lint findings are not a semantic gate failure'
}
(root / 'lint-context.json').write_text(json.dumps(metadata, indent=2) + '\n')
entries = {name: (root / name).read_bytes() for name in ('lint.py', 'lint.log', 'lint-command.json', 'lint-context.json', 'package_lint_context.py', 'initial-post-docs-lint.log', 'initial-post-docs-lint-command.json', 'initial-post-docs-performance.md', 'failed-publication-lint.json')}
payload_count = len(entries)
checksums = ''.join(hashlib.sha256(data).hexdigest() + '  ' + name + '\n' for name, data in sorted(entries.items()))
entries['SHA256SUMS'] = checksums.encode()
name = '20261009-jsdoc-ancestor-prefix-lint-context-854'
path = repo / 'bench/vs_tsgo/evidence' / (name + '.tar.gz')
assert not path.exists()
with path.open('wb') as output:
    with gzip.GzipFile(filename='', mode='wb', fileobj=output, mtime=0) as gz:
        with tarfile.open(fileobj=gz, mode='w') as tar:
            for filename, data in sorted(entries.items()):
                item = tarfile.TarInfo(name + '/' + filename)
                item.size, item.mode, item.mtime = len(data), 0o644, 0
                tar.addfile(item, io.BytesIO(data))
with tarfile.open(path) as tar:
    for row in checksums.splitlines():
        expected, filename = row.split('  ', 1)
        assert hashlib.sha256(tar.extractfile(name + '/' + filename).read()).hexdigest() == expected
report = {'archive': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'payload_checksums': payload_count}
(root / 'lint-archive.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report))
