import hashlib
import json
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
parent = '88a8c2d39c5608be367e75f8379d572b4f571c29'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip() == parent
assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=repo).decode().splitlines() == [' M packages/ts_checker/src/check.zig']
patch = subprocess.check_output(['git', 'diff', '--', 'packages/ts_checker/src/check.zig'], cwd=repo)
assert not (root / 'final-draft.patch').exists()
(root / 'final-draft.patch').write_bytes(patch)
record = {'source_parent': parent, 'final_draft_patch_sha256': hashlib.sha256(patch).hexdigest(),
    'parent_binary_sha256': hashlib.sha256((root / 'home-tsc-parent').read_bytes()).hexdigest(),
    'protocol_sha256': hashlib.sha256((root / 'protocol.json').read_bytes()).hexdigest(),
    'mapped_profile_source': 'b6608b14c631db91be6099e78c957ab67a3b5266',
    'initial_draft_retained': True, 'added_controls': 8, 'expected_full_checker_tests': 4561,
    'timing_status': 'not started; every full gate still required',
    'evolution': 'Initial five controls pass4558; seven controls pass4560; eighth adversarial source/malformed-binding control added. Runtime unchanged during these test additions.'}
(root / 'final-source-freeze.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))
