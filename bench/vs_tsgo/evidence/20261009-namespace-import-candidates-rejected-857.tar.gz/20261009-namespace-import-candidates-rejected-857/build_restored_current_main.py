import hashlib
import json
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
source = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip()
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=repo).decode()
assert subprocess.run(['git', 'diff', '--quiet', '88a8c2d39c5608be367e75f8379d572b4f571c29', source, '--',
    'packages/ts_checker', 'packages/ts_driver', 'packages/ts_cli', 'packages/ts_program', 'packages/hir', 'bench/vs_tsgo'], cwd=repo).returncode == 0
subprocess.run(['python3', str(root / 'logged.py'), 'restored-build'], check=True)
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=repo).decode()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip() == source
digest = hashlib.sha256((repo / 'zig-out/bin/home-tsc').read_bytes()).hexdigest()
assert digest == '68c6ed517f9125ae1b570ff2e585c5b368745389af828258f6621fe5e6e0311c'
record = {'restored_source': source, 'binary_sha256': digest, 'source_clean_before_and_after': True,
    'rejected_candidate_in_production': False, 'original_parent_source': '88a8c2d39c5608be367e75f8379d572b4f571c29',
    'candidate_source_and_all_eight_controls_removed': True, 'newer_runtime_work_preserved': True,
    'method': 'Exact owned source/test patch reversed with apply_patch, original native restored, clean fast-forward and matching standalone rebuild'}
(root / 'restored-current-main.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record), flush=True)
