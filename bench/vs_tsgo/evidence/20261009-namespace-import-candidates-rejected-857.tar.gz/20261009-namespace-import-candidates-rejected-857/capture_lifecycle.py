import datetime
import hashlib
import json
from pathlib import Path
import re
import subprocess

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
labels = ['parent-build', 'checker-first', 'checker-seven-controls', 'checker-final-first', 'checker',
    'program', 'driver', 'cli', 'entrypoint', 'build', 'zod-parent', 'zod-candidate', 'harness',
    'screen', 'confirmation', 'families', 'recheck', 'interface-risk', 'restored-build']
labels += [f'confirmation_large-{n}' for n in range(5)]
commands = {}
for name in labels:
    command = json.loads((root / (name + '-command.json')).read_text())
    assert command['exit'] == 0
    log = (root / (name + '.log')).read_text()
    peaks = [int(value) for value in re.findall(r'peak tree footprint (\d+) MB', log)]
    lows = [int(value) for value in re.findall(r'host low-water (\d+)%', log)]
    commands[name] = {'status': 'terminal', **command, 'peak_tree_mb': max(peaks) if peaks else None,
        'host_low_water_percent': min(lows) if lows else None,
        'shared_lock_wait_logged': 'waiting up to 900s for the machine lock' in log}
verified = json.loads((root / 'verified-pairs.json').read_text())
decision = json.loads((root / 'decision.json').read_text())
restored = json.loads((root / 'restored-current-main.json').read_text())
assert verified['complete'] and verified['rounds'] == 592 and verified['admissions'] == 660
assert decision['status'] == 'rejected' and set(decision['independent_confirmed_regressions']) == {'recheck/destructuring'}
assert restored['source_clean_before_and_after'] and not restored['rejected_candidate_in_production']
assert hashlib.sha256((repo / 'zig-out/bin/home-tsc').read_bytes()).hexdigest() == restored['binary_sha256']
record = {'observed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'source_at_restoration': restored['restored_source'], 'native_sha256': restored['binary_sha256'],
    'commands': commands, 'gate_session': {'session': 68959, 'status': 'terminal', 'exit': 0},
    'measurement_session': {'session': 84718, 'status': 'terminal', 'exit': 0},
    'restoration_session': {'session': 73798, 'status': 'terminal', 'exit': 0},
    'candidate_committed_or_pushed': False, 'rounds': 592, 'admissions': 660,
    'exclusions': 0, 'repeat_until_pass': False, 'alignment_tuning': False,
    'guard': {'timeout_seconds': 600, 'tree_mb': 3840, 'disk_admission_mb': 1024, 'disk_continuation_mb': 512},
    'interpretation': 'All completed phases, warnings and shared-lock waits retained; candidate fully rejected/restored. No universal, equivalence, Zod, C++ or other-platform completion claim.'}
(root / 'final-job-lifecycle.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({key: record[key] for key in ('source_at_restoration', 'native_sha256', 'rounds', 'admissions', 'candidate_committed_or_pushed')}))
