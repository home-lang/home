import hashlib
import json
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
patch = subprocess.check_output(['git', 'diff', '--', 'packages/ts_checker/src/check.zig'], cwd=repo)
commands = {name: json.loads((root / (name + '-command.json')).read_text()) if (root / (name + '-command.json')).exists() else None
    for name in ('parent-build', 'checker-first', 'checker', 'program', 'driver', 'cli', 'entrypoint', 'build', 'zod-parent', 'zod-candidate', 'harness')}
processes = subprocess.check_output(['ps', '-axo', 'pid,ppid,etime,command']).decode().splitlines()
state = {'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip(),
    'status': subprocess.check_output(['git', 'status', '--short'], cwd=repo).decode(),
    'current_patch_sha256': hashlib.sha256(patch).hexdigest(),
    'initial_draft_sha256': json.loads((root / 'initial-provenance.json').read_text())['first_draft_patch_sha256'],
    'initial_checker_session': {'session': 78149, 'status': 'terminal', 'exit': 0, 'tests': 4558},
    'seven_control_checker_session': {'session': 12465, 'status': 'terminal', 'exit': 0, 'tests': 4560},
    'final_control_checker_session': {'session': 46271, 'status': 'terminal', 'exit': 0, 'tests': 4561},
    'updated_controls': 8,
    'current_full_checker_expected_count': 4561,
    'complete_gates_session': {'session': 68959, 'status': 'terminal', 'exit': 0},
    'measurement_session': {'session': 84718, 'status': 'terminal', 'exit': 0},
    'restoration_session': {'session': 73798, 'status': 'terminal', 'exit': 0},
    'completed_timing_phases': [path.parent.name for path in sorted(root.glob('paired-*/summary.json'))],
    'commands': commands,
    'observed_processes': [line for line in processes if str(root) in line and 'current_state.py' not in line],
    'acceptance': 'rejected for independently confirmed destructuring regression; candidate source/tests removed and native68c6ed51 restored, newer runtime main preserved. Clean matching restoration build73798 passed; docs/evidence publication pending.',
    'final_source_freeze': json.loads((root / 'final-source-freeze.json').read_text()),
    'decision': json.loads((root / 'decision.json').read_text())['status'],
    'verified_rounds': 592,
    'verified_admissions': 660,
    'restoration': json.loads((root / 'restored-current-main.json').read_text()),
    'next_step': 'All jobs terminal: measurement84718 exit0 and restoration73798 exit0. Final rejection decision complete; package every raw observation, all controls and restoration, then update detailed docs/brief README table and issues, read-only Pickier, small Chris-only conventional docs main push. No candidate runtime push/retest/layout tuning; independent destructuring interval [-0.237,-0.029]ms rejects despite target gains. Current clean HEAD1d50e7997 matches native68c6ed51 and preserves newer runtime work.'}
(root / 'current-state.json').write_text(json.dumps(state, indent=2) + '\n')
print(json.dumps(state))
