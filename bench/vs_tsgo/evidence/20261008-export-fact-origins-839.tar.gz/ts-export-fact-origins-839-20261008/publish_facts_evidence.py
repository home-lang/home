import hashlib
import json
from pathlib import Path
import re
import statistics
import sys
import tarfile

repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
sys.path.insert(0, str(repo / 'bench/vs_tsgo'))
import run
import compare

root = Path(__file__).resolve().parent
result = repo / 'bench/vs_tsgo/results/20261008T031844Z'
matrix = repo / 'bench/vs_tsgo/evidence/20261008T031844Z.tar.gz'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def verify(path):
    with tarfile.open(path) as tar:
        data = {member.name: tar.extractfile(member).read() for member in tar.getmembers() if member.isfile()}
    checksum_path = next(name for name in data if name.endswith('/SHA256SUMS'))
    prefix = checksum_path.rsplit('/', 1)[0]
    lines = data[checksum_path].decode().splitlines()
    assert len(lines) == len(data) - 1
    for line in lines:
        digest, name = line.split('  ', 1)
        assert sha(data[prefix + '/' + name]) == digest, name
    return data, prefix, len(lines)

data, prefix, checksums = verify(matrix)
assert checksums == 603
raws = [name for name in data if '-round-' in name and name.endswith('.json')]
assert len(raws) == 600
metadata = json.loads(data[prefix + '/metadata.json'])
assert metadata['provenance']['status'] == 'verified'
assert metadata['provenance']['before'] == metadata['provenance']['after']
admission = json.loads(data[prefix + '/admission.jsonl'])
assert len(admission['records']) == 140 and all(row['passed'] for row in admission['records'])
assert admission['passed'] is True
assert admission['before'] == metadata['provenance']['before'] == admission['after']
assert sha(data[prefix + '/admission.jsonl']) == metadata['admission']['sha256']
compare.validate_interleaved_rounds(result, json.loads((result / 'metadata.json').read_text()))
samples = {}
for name in raws:
    filename = name.rsplit('/', 1)[1]
    assert (result / filename).read_bytes() == data[name]
    workload = filename.split('-round-')[0]
    for record in json.loads(data[name])['results']:
        compiler, command_workload = record['command'].split(' ', 1)
        assert command_workload == workload and record['exit_codes'] == [0] and len(record['times']) == 1
        samples.setdefault(workload, {}).setdefault(compiler, []).extend(record['times'])
assert sum(len(times) for group in samples.values() for times in group.values()) == 3000
medians = {workload: {name: statistics.median(times) for name, times in group.items()} for workload, group in samples.items()}
matrix_summary = {
    'home_wins': sum(values['home'] < min(time for name, time in values.items() if name != 'home') for values in medians.values()),
    'home_vs_native_go_wins': sum(values['home'] < values['tsgo'] for values in medians.values()),
    'sha256': sha(matrix.read_bytes()), 'medians': medians,
}

stage_summaries = {}
round_count = 0
for stage in ('screen', 'confirmation', 'families', 'regression_confirmation'):
    directory = root / ('facts-paired-' + stage)
    summary = json.loads((directory / 'summary.json').read_text())
    assert summary['before'] == summary['after']
    admissions = json.loads((directory / 'admission.json').read_text())
    assert len(admissions['records']) == 56 and all(row['passed'] for row in admissions['records'])
    assert admissions['fingerprints'] == summary['before']
    for workload, group in summary['summaries'].items():
        samples = {'parent': [], 'candidate': []}
        rounds = sorted(directory.glob(workload + '-round-*.json'))
        round_count += len(rounds)
        for index, path in enumerate(rounds):
            records = json.loads(path.read_text())['results']
            assert [row['command'] for row in records] == (['parent', 'candidate'] if index % 2 == 0 else ['candidate', 'parent'])
            for row in records:
                assert row['exit_codes'] == [0] and len(row['times']) == 1
                samples[row['command']].extend(row['times'])
        assert samples == group['samples']
        assert statistics.median(samples['parent']) == group['parent_median']
        assert statistics.median(samples['candidate']) == group['candidate_median']
        differences = [old - new for old, new in zip(samples['parent'], samples['candidate'])]
        n = len(differences)
        mean = statistics.mean(differences)
        half = {6: 2.571, 10: 2.262, 20: 2.093, 30: 2.045}[n] * statistics.stdev(differences) / n ** 0.5
        assert group['candidate_wins'] == sum(delta > 0 for delta in differences)
        assert group['paired_mean_saving_seconds'] == mean
        assert group['paired_mean_95pct_t_interval_seconds'] == [mean - half, mean + half]
    stage_summaries[stage] = summary
assert round_count == 356

def identities(side):
    pattern = re.compile(r'^(.+?)\((\d+),(\d+)\): (?:error|warning) (TS\d+|HM\d+):')
    result = []
    for line in (root / ('facts-zod-' + side + '-diagnostics.log')).read_text().splitlines():
        match = pattern.match(line)
        if match:
            path, row, column, code = match.groups()
            assert '/package/' in path
            result.append((path.split('/package/', 1)[1], int(row), int(column), code))
    assert len(result) == 199 and sum(item[3] == 'HM9002' for item in result) == 3
    return sorted(result)

zod = identities('parent')
assert zod == identities('candidate')
for name, expected in [('home-tsc-facts-parent-3318885fb', 'fae92032c458c63252118fc04455cfa3d1a32713b627f793253cd06e0fb11608'), ('home-tsc-export-facts-candidate-3318885fb', '4b4af24fdb57dcfdba69de49a460014a1800cacdda7164a4fc8614e727e9ec2d')]:
    assert sha((root / name).read_bytes()) == expected

prefix = 'ts-export-fact-origins-839-20261008'
members = {}
files = ['export-facts-candidate.patch', 'facts-candidate-build.log', 'facts-current-parent-build.log', 'facts-current-parent-build-recovered.log', 'facts-full-program.log', 'facts-full-program-recovered.log', 'facts-full-checker.log', 'facts-full-cli.log', 'facts-full-cli-core.log', 'facts_module_tests.py', 'facts_paired.py', 'facts_paired_original.py', 'facts-paired-screen.log', 'facts-paired-confirmation.log', 'facts-paired-families.log', 'facts-paired-regression-confirmation.log', 'facts-zod-parent.json', 'facts-zod-candidate.json', 'facts-zod-parent-diagnostics.log', 'facts-zod-candidate-diagnostics.log', 'facts-zod-parent-guard.log', 'facts-zod-candidate-guard.log', 'facts-pickier.log', 'facts-five-compiler.log', 'publish_facts_evidence.py']
for name in files:
    members[prefix + '/' + name] = (root / name).read_bytes()
for directory in ('facts-paired-screen', 'facts-paired-confirmation', 'facts-paired-families', 'facts-paired-regression_confirmation', 'reexport-scale-4096'):
    for path in sorted((root / directory).rglob('*')):
        if path.is_file():
            members[prefix + '/' + str(path.relative_to(root))] = path.read_bytes()
members[prefix + '/verified-summary.json'] = (json.dumps({'source_parent': '3318885fb6a286e145c9d5d77a4373981e343dd3', 'source_commit': '69c3d28ee6469bf89816a45bba9290d919805085', 'matrix': matrix_summary, 'paired_results': stage_summaries, 'zod_diagnostic_multiset': zod}, indent=2) + '\n').encode()
members[prefix + '/README.txt'] = b'''Export-fact origin-query reuse evidence (#839), source 69c3d28ee.
Exact source parent: 3318885fb; retained patch matches the accepted source commit without intervening upstream source changes. Compiler builds share Zig 2163 / ReleaseFast / strip flags.
All 356 paired round JSON files and all logs/admissions are retained, including unfavorable observations and refusals before execution. Every stage retains 56 successful admission records and before/after binary/input/harness/tool fingerprints. Full five-compiler raw evidence is separately published as 20261008T031844Z.tar.gz.
Official graph stays 64 leaves / eight per barrel; secondary scale uses the unchanged generator at 4096 leaves. The initial screen has 20/6 pairs, independent confirmation 30/10, all-20-family screen 10 each. A further independent 30-pair startup/many-files/import confirmation follows the explicit >3% slower-median family screen rule. Overlapping intervals are not equivalence. All intervals are recomputed two-sided 95% paired t intervals.
facts_paired_original.py reconstructs the exact runner used for the first three stages; facts_paired.py adds the targeted confirmation stage without changing the earlier stages. Compiler test logs record complete explicit module/import argv without named filters. facts-full-cli.log is the tsc_main entrypoint (33 tests); facts-full-cli-core.log is the separate ts_cli core module (74 tests).
Zod retains the complete unchanged 106-file graph and equal 196 TS + 3 HM9002 identity multisets. Observed footprint: parent 887 MiB / candidate 991 MiB, a documented memory tradeoff, not production admission.
facts-candidate-build.log preserves the terminal live exec result and explicitly labels that transcription; other logs are byte-for-byte redirected process output. Local reproducibility paths are retained. Compiler binaries are not redistributed here.
'''
members[prefix + '/SHA256SUMS'] = ''.join(f'{sha(content)}  {name.removeprefix(prefix + "/")}\n' for name, content in sorted(members.items())).encode()
destination = repo / 'bench/vs_tsgo/evidence/20261008-export-fact-origins-839.tar.gz'
run.write_evidence_archive(destination, members)
_, _, paired_checksums = verify(destination)
print(json.dumps({'matrix': matrix_summary, 'matrix_checksums': checksums, 'paired_archive': str(destination), 'paired_sha256': sha(destination.read_bytes()), 'paired_checksums': paired_checksums, 'paired_rounds': round_count}))
