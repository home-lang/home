import json
import shlex
import subprocess
import sys

BUILD_COMMAND = "/Users/chris/Code/Home/lang-bun-port/zig-out/toolchains/zig-aarch64-macos-0.17.0-dev.2163+89ff10d56/zig build-exe -fstrip -Ofast --dep ts_cli --dep ts_program --dep ts_resolver --dep ts_driver --dep ts_diagnostics --dep ts_emit --dep tsconfig --dep ts_watch --dep d_hm --dep ts_lsp --dep ts_lsp_server -Mroot=packages/ts_cli/src/tsc_main.zig -Ofast --dep ts_diagnostics --dep ts_driver --dep ts_program --dep ts_resolver --dep tsconfig -Mts_cli=packages/ts_cli/src/ts_cli.zig -Ofast --dep hir --dep ts_driver --dep ts_resolver --dep tsconfig --dep binder --dep ts_cache -Mts_program=packages/ts_program/src/ts_program.zig -Ofast -Mts_resolver=packages/ts_resolver/src/ts_resolver.zig -Ofast --dep hir --dep string_interner --dep ts_lexer --dep ts_parser --dep binder --dep ts_emit --dep tsconfig --dep ts_checker --dep ts_cache -Mts_driver=packages/ts_driver/src/ts_driver.zig -Ofast -Mts_diagnostics=packages/ts_diagnostics/src/ts_diagnostics.zig -Ofast --dep hir --dep string_interner --dep ts_lexer --dep ts_parser --dep zig_dtsx --dep ts_checker -Mts_emit=packages/ts_emit/src/ts_emit.zig -Ofast --dep jsonc -Mtsconfig=packages/tsconfig/src/tsconfig.zig -Ofast -Mts_watch=packages/ts_watch/src/ts_watch.zig -Ofast --dep hir --dep string_interner --dep ts_lexer --dep ts_parser -Md_hm=packages/d_hm/src/d_hm.zig -Ofast --dep hir --dep ts_program --dep ts_driver --dep ts_diagnostics --dep ts_resolver --dep ts_checker --dep ts_lexer --dep string_interner -Mts_lsp=packages/ts_lsp/src/ts_lsp.zig -Ofast --dep ts_lsp --dep ts_program --dep ts_resolver --dep ts_diagnostics -Mts_lsp_server=packages/ts_lsp_server/src/ts_lsp_server.zig -Ofast --dep string_interner -Mhir=packages/hir/src/hir.zig -Ofast --dep hir --dep string_interner --dep ts_lexer --dep ts_parser -Mbinder=packages/binder/src/binder.zig -Ofast -Mts_cache=packages/ts_cache/src/ts_cache.zig -Ofast -Mstring_interner=packages/string_interner/src/string_interner.zig -Ofast -Mts_lexer=packages/ts_lexer/src/ts_lexer.zig -Ofast --dep ts_lexer --dep hir --dep string_interner -Mts_parser=packages/ts_parser/src/ts_parser.zig -Ofast --dep hir --dep string_interner --dep ts_lexer --dep ts_parser --dep binder -Mts_checker=packages/ts_checker/src/ts_checker.zig -Ofast -Mzig_dtsx=packages/ts_emit/vendor/zig_dtsx_stub.zig -Ofast -Mjsonc=packages/tsconfig/src/jsonc.zig --cache-dir .zig-cache --global-cache-dir /Users/chris/.cache/zig --build-root . --name home-tsc --zig-lib-dir /Users/chris/Code/Home/lang-bun-port/zig-out/toolchains/zig-aarch64-macos-0.17.0-dev.2163+89ff10d56/lib/ --listen=-"
argv = shlex.split(BUILD_COMMAND)
modules = {}
deps = []
index = 2
while index < len(argv):
    token = argv[index]
    if token == '--dep':
        index += 1
        deps.append(argv[index])
    elif token.startswith('-M'):
        name, path = token[2:].split('=', 1)
        modules[name] = {'path': path, 'deps': deps}
        deps = []
    index += 1
target = {'program': 'ts_program', 'checker': 'ts_checker', 'cli': 'ts_cli', 'entrypoint': 'root'}[sys.argv[1]]
reachable = {target}
pending = [target]
while pending:
    for name in modules[pending.pop()]['deps']:
        if name not in reachable:
            reachable.add(name)
            pending.append(name)
order = [target] + [name for name in modules if name in reachable and name != target]
command = [argv[0], 'test', '-fstrip']
for name in order:
    command += ['-OReleaseFast']
    for dep in modules[name]['deps']:
        command += ['--dep', dep]
    command += ['-M' + ('root' if name == target else name) + '=' + modules[name]['path']]
for flag in ['--cache-dir', '--global-cache-dir', '--zig-lib-dir']:
    command += [flag, argv[argv.index(flag) + 1]]
print(json.dumps({'target': target, 'command': command, 'named_test_filters': []}), flush=True)
sys.exit(subprocess.run(command).returncode)
