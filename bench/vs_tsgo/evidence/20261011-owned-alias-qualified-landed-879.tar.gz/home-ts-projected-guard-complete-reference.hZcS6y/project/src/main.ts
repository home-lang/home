interface BaseIssue { readonly code?: string; readonly path: PropertyKey[] }
interface TooBig extends BaseIssue { readonly code: "too_big"; maximum: number }
interface TooSmall extends BaseIssue { readonly code: "too_small"; minimum: number }
interface UnionEmpty extends BaseIssue { readonly code: "invalid_union"; errors: [] }
interface UnionErrors extends BaseIssue { readonly code: "invalid_union"; errors: Issue[][] }
interface InvalidKey extends BaseIssue { readonly code: "invalid_key"; issues: Issue[] }
interface InvalidElement extends BaseIssue { readonly code: "invalid_element"; issues: Issue[] }
interface Custom extends BaseIssue { readonly code: "custom"; params?: object }
type Issue = TooBig | TooSmall | UnionEmpty | UnionErrors | InvalidKey | InvalidElement | Custom;
declare const issues: Issue[];
for (const issue of issues) {
  if (issue.code === "invalid_union" && issue.errors.length) {
    void issue.errors;
  } else if (issue.code === "invalid_key") {
    void issue.issues;
  } else if (issue.code === "invalid_element") {
    void issue.issues;
  }
}
declare const keys: (string | symbol)[];
for (const key of keys) {
  if (key === "__proto__") continue;
  const preserved: string | symbol = key;
  void (key as string); void preserved;
}
