import hashlib
import json
from pathlib import Path
import shutil
import subprocess

root=Path(__file__).resolve().parent
target=Path('/Users/chris/.codex/worktrees/ts863-qualification-docs/lang/.zig-cache')
assert target.is_dir() and not target.is_symlink() and target.resolve()==target
assert not subprocess.check_output(['git','ls-files','--','.zig-cache'],cwd=target.parent)
assert subprocess.run(['ps','-p','32644,32659,32664,32665'],capture_output=True).returncode!=0
protected=set()
for relative in ['packages/ts_checker/src/check.zig','packages/ts_program/src/ts_program.zig','zig-out/bin/home-tsc']:
    protected.add(target.parent/relative)
for name in ['home-ts-owned-alias-prototype.wVgnmk','home-ts-owned-alias-hardened.Y3mOcP',
             'home-ts-owned-alias-resolved-guards.Idqxcg','home-ts-owned-alias-full-regressions.3zmqMo',
             'home-ts-owned-alias-regressions-syntax-fixed.3pPBmo']:
    protected.update(path for path in (Path('/Users/chris/.cache')/name).rglob('*') if path.is_file())
protected.update(path for path in (target.parent/'bench/vs_tsgo/evidence').glob('*.tar.gz') if path.is_file())
def hashes():
    result={}
    for path in sorted(protected):
        value=hashlib.sha256()
        with path.open('rb') as stream:
            for block in iter(lambda:stream.read(1024*1024),b''):value.update(block)
        result[str(path)]=value.hexdigest()
    return result
before=hashes()
size=sum(path.stat().st_size for path in target.rglob('*') if path.is_file())
shutil.rmtree(target)
after=hashes()
assert before==after
content=json.dumps({'deleted_generated_cache':str(target),'bytes':size,'protected_checksums':before,
    'all_protected_checksums_unchanged':True,'shared_caches_modified':False,'unrelated_jobs_modified':False},indent=2)+'\n'
patch='*** Begin Patch\n*** Add File: '+str(root/'cleanup-outcome.json')+'\n'+''.join('+'+line+'\n' for line in content.splitlines())+'*** End Patch\n'
subprocess.run(['apply_patch'],input=patch,text=True,check=True,capture_output=True)
print(json.dumps({'bytes_deleted':size,'protected_files_verified':len(before),'unchanged':True}),flush=True)
