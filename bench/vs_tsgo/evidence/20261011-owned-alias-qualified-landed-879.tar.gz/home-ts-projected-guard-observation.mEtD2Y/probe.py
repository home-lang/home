import json
from pathlib import Path
import subprocess

root=Path(__file__).resolve().parent
repo=Path('/Users/chris/.codex/worktrees/ts863-qualification-docs/lang')
seed=Path('/Users/chris/.cache/home-ts-callable-intersection-facts.34PC25/collection-factory-positive')

def save(path,content):
    assert not path.exists(),path
    path.parent.mkdir(parents=True,exist_ok=True)
    patch='*** Begin Patch\n*** Add File: '+str(path)+'\n'+''.join('+'+line+'\n' for line in content.splitlines())+'*** End Patch\n'
    subprocess.run(['apply_patch'],input=patch,text=True,check=True,capture_output=True)

source=(repo/'packages/ts_checker/src/check.zig').read_text()
start=source.index('test "checker: negative member guards subtract from projected union properties"')
end=source.index('    );',start)
typescript='\n'.join(line.split('\\\\',1)[1] for line in source[start:end].splitlines() if '\\\\' in line)+'\n'
save(root/'project/src/main.ts',typescript)
for relative in ['tsconfig.json','src/lib.d.ts']:
    save(root/'project'/relative,(seed/relative).read_text())
commands={
 'tsc':['/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang/bench/vs_tsgo/.tools/tsc/node_modules/.bin/tsc','--noEmit','-p',str(root/'project/tsconfig.json')],
 'tsgo':['/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang/bench/vs_tsgo/.tools/tsgo/node_modules/@typescript/typescript-darwin-arm64/lib/tsc','--noEmit','-p',str(root/'project/tsconfig.json')],
 'prior-diagnostic':['/Users/chris/.cache/home-ts-owned-alias-resolved-guards.Idqxcg/prototype-surface',str(root/'project/tsconfig.json')],
}
records=[]
for name,command in commands.items():
    result=subprocess.run(command,capture_output=True,text=True)
    records.append({'compiler':name,'command':command,'exit':result.returncode,'stdout':result.stdout,'stderr':result.stderr,
                    'diagnostic_only':True,'timings_taken':False})
    print(name,result.returncode,result.stdout,result.stderr,flush=True)
save(root/'results.json',json.dumps(records,indent=2)+'\n')
