"""Frozen exact-parent correctness-feature regression qualification; no measurement repeats."""
import hashlib
import json
import math
from pathlib import Path
import shlex
import subprocess
import sys

root=Path(__file__).resolve().parent
compiler_repo=Path('/Users/chris/.codex/worktrees/ts863-qualification-docs/lang')
runner=Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
sys.path.insert(0,str(runner/'bench/vs_tsgo'))
import run
import competitors
def save(path,content):
    assert not path.exists(),path
    patch='*** Begin Patch\n*** Add File: '+str(path)+'\n'+''.join('+'+s+'\n' for s in content.splitlines())+'*** End Patch\n'
    subprocess.run(['apply_patch'],input=patch,text=True,check=True,capture_output=True)

phase=sys.argv[1]
protocol=json.loads((root/'performance-protocol.json').read_text())
build=json.loads((root/'candidate-build.json').read_text())
assert json.loads((root/'checker-outcome.json').read_text())['exit']==0
assert 'All 4568 tests passed.' in (root/'checker.log').read_text()
assert json.loads((root/'program-outcome.json').read_text())['exit']==0
assert 'All 265 tests passed.' in (root/'program.log').read_text()
gates=json.loads((root/'remaining-outcome.json').read_text())
assert len(gates['records'])==3 and all(r['exit']==0 for r in gates['records'])
assert json.loads((root/'harness-outcome.json').read_text())['tests']==147
assert json.loads((root/'extended-admission.json').read_text())['passed']
assert json.loads((root/'verified-protocol.json').read_text())['passed']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=compiler_repo).decode().strip()==protocol['source_parent']
def source_hash():
    return hashlib.sha256(subprocess.check_output(['git','diff','--','packages/ts_checker/src/check.zig','packages/ts_program/src/ts_program.zig'],cwd=compiler_repo)).hexdigest()
assert source_hash()==protocol['source_patch_sha256']
commands={'parent':[protocol['parent_native_path']],'candidate':[protocol['candidate_native_path']]}
for name in commands:
    assert hashlib.sha256(Path(commands[name][0]).read_bytes()).hexdigest()==protocol[name+'_native_sha256']
if phase=='screen':
    workloads=run.selected_workloads(None);pairs=protocol['screen_pairs_per_workload']
elif phase.startswith('risk-'):
    name=phase[len('risk-'):]
    additional=json.loads((root/'screen-statistics.json').read_text())['additional_adverse_workloads']
    assert name in protocol['independent_regression_workloads'] or name in additional
    workloads=[name];pairs=protocol['independent_regression_pairs']
else:raise ValueError('Unknown phase')
output=root/phase;output.mkdir(exist_ok=False)
profiles=competitors.load_profiles(runner/'bench/vs_tsgo/profiles/darwin-arm64.json')
all_commands=run.compiler_commands(profiles);all_commands['home']=commands['candidate']
def provenance():
    result=run.benchmark_provenance(all_commands,profiles)
    result['compilers']['parent']={'command':commands['parent'],'executable':run.artifact_provenance(Path(commands['parent'][0]))}
    return result
before=provenance()
assert before==json.loads((root/'image-admission.jsonl').read_text())['after']
trace=[]
metadata={'phase':phase,'workloads':workloads,'pairs':pairs,'warmups':protocol['warmups'],
    'schedule':'Alternating parent/candidate pair order','source_parent':protocol['source_parent'],
    'source_patch_sha256':protocol['source_patch_sha256'],'parent_sha256':protocol['parent_native_sha256'],
    'candidate_sha256':protocol['candidate_native_sha256'],'protocol_sha256':hashlib.sha256((root/'performance-protocol.json').read_bytes()).hexdigest(),
    'runner_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'before':before,'after':None,'status':'running','admissions':trace}
save(output/'started.json',json.dumps(metadata,indent=2)+'\n')
try:
    for workload in workloads:
        run.validate(commands,workload,trace=trace)
        config=run.CORPUS/workload/'tsconfig.json'
        argv={name:command+['--noEmit','-p',str(config)] for name,command in commands.items()}
        names=list(argv)
        for index in range(protocol['warmups']):
            order=names[index%2:]+names[:index%2]
            for name in order:
                result=subprocess.run(argv[name],capture_output=True,text=True)
                save(output/f'{workload}-warmup-{index:03d}-{name}.json',json.dumps({'command':argv[name],'exit':result.returncode,'stdout':result.stdout,'stderr':result.stderr},indent=2)+'\n')
                assert result.returncode==0 and result.stdout=='' and result.stderr==''
        for index in range(pairs):
            order=names[index%2:]+names[:index%2]
            path=output/f'{workload}-pair-{index:03d}.json'
            timer=['hyperfine','--shell=none','--runs','1','--style','none','--export-json',str(path)]
            for name in order:timer+=['--command-name',name+' '+workload,shlex.join(argv[name])]
            subprocess.run(timer,check=True)
            data=json.loads(path.read_text())
            assert [r['command'] for r in data['results']]==[name+' '+workload for name in order]
            for record in data['results']:
                assert record['exit_codes']==[0] and len(record['times'])==1
                assert math.isfinite(record['times'][0]) and record['times'][0]>0
        print(phase,workload,pairs,'original pairs completed',flush=True)
    after=provenance();assert after==before and source_hash()==protocol['source_patch_sha256']
    metadata.update(after=after,status='complete')
except BaseException as error:
    metadata.update(status='incomplete',error={'type':type(error).__name__,'message':str(error)})
    raise
finally:
    save(output/'metadata.json',json.dumps(metadata,indent=2)+'\n')
