import json
import os
from pathlib import Path
import subprocess

root=Path(__file__).resolve().parent
repo=Path('/Users/chris/.codex/worktrees/ts863-qualification-docs/lang')
protocol=json.loads((root/'performance-protocol.json').read_text())
screen=json.loads((root/'screen-statistics.json').read_text())
assert screen['verified'] and screen['pairs']==200
names=protocol['independent_regression_workloads']+screen['additional_adverse_workloads']
assert len(names)==len(set(names))
state=root/'risk-run-started.json';assert not state.exists()
def save(path,content):
    assert not path.exists(),path
    patch='*** Begin Patch\n*** Add File: '+str(path)+'\n'+''.join('+'+s+'\n' for s in content.splitlines())+'*** End Patch\n'
    subprocess.run(['apply_patch'],input=patch,text=True,check=True,capture_output=True)
save(state,json.dumps({'phases':['risk-'+name for name in names],'source_adopted':False,'measurement_reruns_allowed':False},indent=2)+'\n')
records=[]
for name in names:
    phase='risk-'+name
    command=['perl','scripts/run-bounded.pl','600','python3',str(root/'paired.py'),phase]
    environment=dict(os.environ,HOME_RUN_MAX_MB='3840',HOME_RUN_LABEL='ts879-'+phase)
    with (root/(phase+'.run.log')).open('w') as output:
        result=subprocess.run(command,cwd=repo,env=environment,stdout=output,stderr=subprocess.STDOUT)
    records.append({'phase':phase,'command':command,'exit':result.returncode})
    print(phase,'terminal',result.returncode,flush=True)
    if result.returncode:break
    verify=subprocess.run(['python3',str(root/'paired_statistics.py'),phase],cwd=repo,capture_output=True,text=True)
    save(root/(phase+'.verification.log'),verify.stdout+verify.stderr)
    records[-1]['verification_exit']=verify.returncode
    if verify.returncode:break
    summary=json.loads((root/(phase+'-statistics.json')).read_text())['rows'][name]
    print(name,summary['conclusion'],summary['paired_mean_saving_95_interval'],flush=True)
save(root/'risk-run-outcome.json',json.dumps({'records':records,'all_required_phases':names,
    'source_adopted':False,'no_reruns':True,'all_observations_retained':True},indent=2)+'\n')
raise SystemExit(next((r['exit'] or r.get('verification_exit',0) for r in records if r['exit'] or r.get('verification_exit',0)),0))
