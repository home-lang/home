import hashlib
import json
from pathlib import Path
import shutil
import subprocess

root=Path(__file__).resolve().parent
repo=Path('/Users/chris/.codex/worktrees/ts863-qualification-docs/lang')
def save(path,content):
    assert not path.exists(),path
    patch='*** Begin Patch\n*** Add File: '+str(path)+'\n'+''.join('+'+line+'\n' for line in content.splitlines())+'*** End Patch\n'
    subprocess.run(['apply_patch'],input=patch,text=True,check=True,capture_output=True)

source=subprocess.check_output(['git','diff','--','packages/ts_checker/src/check.zig','packages/ts_program/src/ts_program.zig'],cwd=repo)
assert hashlib.sha256(source).hexdigest()=='d3d99aa127a89f9ec9d62caf470a792feb745357902fa6e8be6567baa2283532'
assert json.loads((root/'checker-outcome.json').read_text())['exit']==0
assert json.loads((root/'program-outcome.json').read_text())['exit']==0
remaining=json.loads((root/'remaining-outcome.json').read_text())
assert [row['target'] for row in remaining['records']]==['driver','cli','entrypoint']
assert all(row['exit']==0 for row in remaining['records'])
assert remaining['source_patch_sha256']==hashlib.sha256(source).hexdigest()
retained=Path('/Users/chris/.cache/home-ts-main-flow-proof-integration.dYlSre/candidate-home-tsc')
retained_hash='754926fd350062fac7094768b6adb2f1a5e808b21c37a59ec151b31ac46d59af'
assert hashlib.sha256(retained.read_bytes()).hexdigest()==retained_hash
assert hashlib.sha256((repo/'zig-out/bin/home-tsc').read_bytes()).hexdigest()==retained_hash
command=['/Users/chris/Code/Home/lang-bun-port/zig-out/toolchains/zig-aarch64-macos-0.17.0-dev.2163+89ff10d56/zig',
    'build','home-tsc','-Doptimize=ReleaseFast','-Dhome-tsc-strip=true','-Denable_jsc=false','-j1','--summary','all']
with (root/'native-build.log').open('w') as output:
    result=subprocess.run(command,cwd=repo,stdout=output,stderr=subprocess.STDOUT)
record={'command':command,'exit':result.returncode,'source_parent':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo).decode().strip(),
    'source_patch_sha256':hashlib.sha256(source).hexdigest(),'timings_taken':False,'source_adopted':False}
if result.returncode==0:
    native=repo/'zig-out/bin/home-tsc'
    frozen=root/'candidate-home-tsc'
    assert not frozen.exists()
    shutil.copy2(native,frozen)
    record['native_sha256']=hashlib.sha256(frozen.read_bytes()).hexdigest()
    assert hashlib.sha256(native.read_bytes()).hexdigest()==record['native_sha256']
    shutil.copy2(retained,native)
    record['installed_native_restored_sha256']=hashlib.sha256(native.read_bytes()).hexdigest()
    assert record['installed_native_restored_sha256']==retained_hash
save(root/'candidate-build.json',json.dumps(record,indent=2)+'\n')
print(json.dumps(record),flush=True)
print((root/'native-build.log').read_text()[-3000:],flush=True)
raise SystemExit(result.returncode)
