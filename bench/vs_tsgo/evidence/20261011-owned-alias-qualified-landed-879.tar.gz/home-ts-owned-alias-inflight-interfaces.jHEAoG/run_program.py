import hashlib
import json
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts863-qualification-docs/lang')

def save(path, content):
    assert not path.exists(), path
    patch = '*** Begin Patch\n*** Add File: ' + str(path) + '\n'
    patch += ''.join('+' + line + '\n' for line in content.splitlines()) + '*** End Patch\n'
    subprocess.run(['apply_patch'], input=patch, text=True, check=True, capture_output=True)

source = subprocess.check_output(['git', 'diff', '--', 'packages/ts_checker/src/check.zig', 'packages/ts_program/src/ts_program.zig'], cwd=repo)
assert source.decode() == (root / 'source.patch').read_text()
command = ['python3', '/Users/chris/.cache/home-ts-843.3BeUMH/module_tests.py', 'program']
with (root / 'program.log').open('w') as output:
    result = subprocess.run(command, cwd=repo, stdout=output, stderr=subprocess.STDOUT)
record = {'command': command, 'exit': result.returncode, 'test_filters': [],
    'source_patch_sha256': hashlib.sha256(source).hexdigest(),
    'timings_taken': False, 'source_adopted': False,
    'scope': 'Declaration-owned non-generic alias prototype plus direct forward/unknown/productive-cycle Program regression'}
save(root / 'program-outcome.json', json.dumps(record, indent=2) + '\n')
print(json.dumps(record), flush=True)
print((root / 'program.log').read_text()[-5000:], flush=True)
raise SystemExit(result.returncode)
