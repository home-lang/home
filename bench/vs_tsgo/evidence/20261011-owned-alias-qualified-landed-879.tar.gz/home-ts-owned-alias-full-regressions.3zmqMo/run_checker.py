import hashlib
import json
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts863-qualification-docs/lang')
source = subprocess.check_output(['git','diff','--','packages/ts_checker/src/check.zig','packages/ts_program/src/ts_program.zig'],cwd=repo)
assert not (root / 'source.patch').exists()
source_content=source.decode()
source_patch='*** Begin Patch\n*** Add File: '+str(root/'source.patch')+'\n'+''.join('+'+line+'\n' for line in source_content.splitlines())+'*** End Patch\n'
subprocess.run(['apply_patch'],input=source_patch,text=True,check=True,capture_output=True)
assert not (root / 'checker-outcome.json').exists()
command = ['python3','/Users/chris/.cache/home-ts-843.3BeUMH/module_tests.py','checker']
with (root / 'checker.log').open('w') as output:
    result = subprocess.run(command,cwd=repo,stdout=output,stderr=subprocess.STDOUT)
content = json.dumps({'command':command,'exit':result.returncode,'test_filters':[],
    'source_patch_sha256':hashlib.sha256(source).hexdigest(),'timings_taken':False,'source_adopted':False},indent=2)+'\n'
patch='*** Begin Patch\n*** Add File: '+str(root/'checker-outcome.json')+'\n'+''.join('+'+line+'\n' for line in content.splitlines())+'*** End Patch\n'
subprocess.run(['apply_patch'],input=patch,text=True,check=True,capture_output=True)
print(content,flush=True)
print((root/'checker.log').read_text()[-6000:],flush=True)
raise SystemExit(result.returncode)
