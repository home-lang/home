import json
from pathlib import Path
import subprocess
import sys

root=Path(__file__).resolve().parent
seed=Path('/Users/chris/.cache/home-ts-projected-guard-complete-reference.hZcS6y/project')
runner=Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
sys.path.insert(0,str(runner/'bench/vs_tsgo'))
import run
import competitors
def save(path,content):
    assert not path.exists(),path
    path.parent.mkdir(parents=True,exist_ok=True)
    patch='*** Begin Patch\n*** Add File: '+str(path)+'\n'+''.join('+'+line+'\n' for line in content.splitlines())+'*** End Patch\n'
    subprocess.run(['apply_patch'],input=patch,text=True,check=True,capture_output=True)
assert not (root/'results.json').exists()
trace=[];before={}
for bad in [False,True]:
    name='projected-negative' if bad else 'projected-positive'
    project=root/name
    for relative in ['tsconfig.json','src/lib.d.ts']:
        save(project/relative,(seed/relative).read_text())
    source=(seed/'src/main.ts').read_text()
    if bad:
        assert source.count('void issue.issues;')==2
        source=source.replace('void issue.issues;', 'const wrong: string = issue.issues; issue.missing; void wrong;')
    save(project/'src/main.ts',source)
    before[name]=competitors.inventory_hash(competitors.payload_inventory(project))
    commands=run.compiler_commands()
    commands['home']=['/Users/chris/.cache/home-ts-main-flow-proof-integration.dYlSre/candidate-home-tsc']
    commands['parent']=['/Users/chris/.cache/home-ts-main-flow-proof-integration.dYlSre/baseline-home-tsc']
    for compiler,command in commands.items():
        result,passed=run.admission_process(compiler,command+['--noEmit','-p',str(project/'tsconfig.json')],
            name,expected_codes=['2322','2339','2322','2339'] if bad else None,trace=trace)
        print(name,compiler,result.returncode,passed,trace[-1]['codes'],flush=True)
after={name:competitors.inventory_hash(competitors.payload_inventory(root/name)) for name in before}
assert before==after
record={'records':trace,'before':before,'after':after,'reference_controls_valid':all(row['passed'] for row in trace if row['compiler'] in ['tsc','tsgo']),
    'timings_taken':False,'source_adopted':False}
save(root/'results.json',json.dumps(record,indent=2)+'\n')
