import hashlib
import json
from pathlib import Path
import subprocess

root=Path(__file__).resolve().parent
repo=Path('/Users/chris/.codex/worktrees/ts863-qualification-docs/lang')
source=subprocess.check_output(['git','diff','--','packages/ts_checker/src/check.zig','packages/ts_program/src/ts_program.zig'],cwd=repo)
assert hashlib.sha256(source).hexdigest()=='94e265d509a65fd4368491980d574dab86734ccceb9ff43d244d2cfa81a51202'
assert not (root/'remaining-outcome.json').exists()
records=[]
for target in ['driver','cli','entrypoint']:
    command=['perl','scripts/run-bounded.pl','600','python3','/Users/chris/.cache/home-ts-843.3BeUMH/module_tests.py',target]
    with (root/(target+'.log')).open('w') as output:
        result=subprocess.run(command,cwd=repo,stdout=output,stderr=subprocess.STDOUT,
            env=None)
    records.append({'target':target,'command':command,'exit':result.returncode,'test_filters':[]})
    print(target,result.returncode,flush=True)
    if result.returncode: break
content=json.dumps({'records':records,'source_patch_sha256':hashlib.sha256(source).hexdigest(),
    'timings_taken':False,'source_adopted':False},indent=2)+'\n'
patch='*** Begin Patch\n*** Add File: '+str(root/'remaining-outcome.json')+'\n'+''.join('+'+line+'\n' for line in content.splitlines())+'*** End Patch\n'
subprocess.run(['apply_patch'],input=patch,text=True,check=True,capture_output=True)
raise SystemExit(next((row['exit'] for row in records if row['exit']),0))
