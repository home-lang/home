import { Model127, make127 } from "./module-0127";
export const result: Model127<string> = make127("home");

export const invalidImportedProperty: number = result.current;
result.missing;
