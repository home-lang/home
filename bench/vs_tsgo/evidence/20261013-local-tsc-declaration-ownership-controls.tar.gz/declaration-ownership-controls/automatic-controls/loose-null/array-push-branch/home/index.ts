declare const b:boolean; let x=[]; if(b) x.push(1); const s:string=x[0];
