let x; class C { value = x; }
