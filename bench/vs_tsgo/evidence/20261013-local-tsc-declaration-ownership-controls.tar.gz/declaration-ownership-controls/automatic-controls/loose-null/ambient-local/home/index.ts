declare namespace N { let x; }
