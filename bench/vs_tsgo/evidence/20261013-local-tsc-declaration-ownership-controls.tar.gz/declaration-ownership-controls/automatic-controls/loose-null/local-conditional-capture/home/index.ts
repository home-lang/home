declare const b: boolean; function f() { let x; if(b) x=1; function g() { return x; } }
