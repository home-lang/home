let x=[]; x.length;
