let x=[]; function f() { return x; }
