let x=[]; x.push(...[1,2]); const s:string=x[0];
