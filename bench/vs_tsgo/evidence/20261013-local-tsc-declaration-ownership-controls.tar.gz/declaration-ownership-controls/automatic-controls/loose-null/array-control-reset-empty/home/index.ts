let x=[]; x.push(1); x=[]; x;
