function f(){ const x=[]; x.push(1); const g=()=>x; }
