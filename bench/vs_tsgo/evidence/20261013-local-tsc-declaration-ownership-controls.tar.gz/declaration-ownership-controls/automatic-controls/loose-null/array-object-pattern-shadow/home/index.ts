let x=[]; function f(){ const {x}={x:[1]}; const s:string=x[0]; }
