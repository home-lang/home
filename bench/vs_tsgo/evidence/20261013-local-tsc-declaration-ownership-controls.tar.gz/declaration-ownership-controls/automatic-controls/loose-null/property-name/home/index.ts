let x; const obj = { x: 1 }; obj.x;
