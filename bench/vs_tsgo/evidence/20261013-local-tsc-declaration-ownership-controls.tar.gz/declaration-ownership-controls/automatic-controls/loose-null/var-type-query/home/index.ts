let x; type X = typeof x;
