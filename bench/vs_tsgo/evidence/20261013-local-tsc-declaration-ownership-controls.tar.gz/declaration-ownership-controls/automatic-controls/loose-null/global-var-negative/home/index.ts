var x; const n: number = x;
