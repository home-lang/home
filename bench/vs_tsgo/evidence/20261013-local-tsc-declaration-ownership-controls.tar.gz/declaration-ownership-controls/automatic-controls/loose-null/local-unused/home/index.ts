function f() { let x; }
