namespace N { let x; }
