const n:number=x; let x=[];
