let x=[]; x[0]=1; const s:string=x[0];
