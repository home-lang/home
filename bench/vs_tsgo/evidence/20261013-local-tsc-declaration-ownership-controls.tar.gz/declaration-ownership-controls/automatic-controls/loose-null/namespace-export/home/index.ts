namespace N { export let x; }
