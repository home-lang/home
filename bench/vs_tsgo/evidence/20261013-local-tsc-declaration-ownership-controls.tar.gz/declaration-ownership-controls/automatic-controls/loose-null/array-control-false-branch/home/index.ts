let x=[]; if(false) x.push(1); x;
