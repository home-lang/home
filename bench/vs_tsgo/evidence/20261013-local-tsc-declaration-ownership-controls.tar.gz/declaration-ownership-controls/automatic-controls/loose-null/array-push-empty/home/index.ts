let x=[]; x.push(); x;
