declare const b:boolean; let x=[]; if(b) x.push(1); else x.push("s"); const n:boolean=x[0];
