declare const flag: boolean; let x; if (flag) x = 1; const n: number = x;
