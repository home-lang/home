let x=[]; x.push(1); function f(){ return x; }
