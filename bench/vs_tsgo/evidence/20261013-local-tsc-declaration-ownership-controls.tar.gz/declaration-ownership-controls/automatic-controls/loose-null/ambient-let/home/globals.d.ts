interface Array<T> {}
interface Boolean {}
interface CallableFunction {}
interface Function {}
interface IArguments {}
interface NewableFunction {}
interface Number {}
interface Object {}
interface RegExp {}
interface String {}
interface Array<T> { [n:number]:T; length:number; push(...items:T[]):number; unshift(...items:T[]):number; }
