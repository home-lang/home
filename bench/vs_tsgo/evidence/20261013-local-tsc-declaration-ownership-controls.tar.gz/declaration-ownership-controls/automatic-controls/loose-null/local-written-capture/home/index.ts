function f() { let x; x=1; function g() { return x; } }
