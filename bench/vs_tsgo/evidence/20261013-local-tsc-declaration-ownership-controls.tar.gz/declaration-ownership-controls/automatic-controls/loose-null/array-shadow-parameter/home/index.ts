let x=[]; function f(x:number[]){ return x; }
