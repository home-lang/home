let x; const obj = { [x]: 1 };
