let x=[]; for(let i=0;i<2;i++){ x.push(1); const s:string=x[0]; }
