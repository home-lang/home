function f() { return x; } let x;
