function f() { let x; const n: number = x; }
