export let x; x=1;
