let x; function f() { x = 1; }
