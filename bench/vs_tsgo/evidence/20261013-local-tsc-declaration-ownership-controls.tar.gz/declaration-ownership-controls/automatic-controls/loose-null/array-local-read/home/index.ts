function f(){ let x=[]; return x; }
