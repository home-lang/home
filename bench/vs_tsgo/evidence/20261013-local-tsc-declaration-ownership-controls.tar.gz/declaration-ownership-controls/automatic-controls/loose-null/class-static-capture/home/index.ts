let x; class C { static value = x; }
