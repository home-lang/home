let x; const f = function x() { return x; };
