let x=[]; x.push(1); class C { static value=x; }
