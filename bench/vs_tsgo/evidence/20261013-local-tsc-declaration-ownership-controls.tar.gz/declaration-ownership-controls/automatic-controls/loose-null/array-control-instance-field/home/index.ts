let x=[]; x.push(1); class C { value=x; }
