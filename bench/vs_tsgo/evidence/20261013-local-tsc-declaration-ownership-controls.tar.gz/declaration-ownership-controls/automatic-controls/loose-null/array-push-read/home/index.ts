let x=[]; x.push(1); const n:number=x[0];
