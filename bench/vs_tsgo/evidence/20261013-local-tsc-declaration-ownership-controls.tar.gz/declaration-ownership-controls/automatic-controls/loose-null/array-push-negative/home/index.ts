let x=[]; x.push(1); const s:string=x[0];
