let x; class C { m() { return x; } }
