let x; class C { x: number = 1; }
