const x=[]; x;
