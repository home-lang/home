let x; const n: number = x;
