let x; const obj = { x };
