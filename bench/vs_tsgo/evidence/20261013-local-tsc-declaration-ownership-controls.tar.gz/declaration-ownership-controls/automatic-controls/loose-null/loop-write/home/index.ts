let x; for(let i=0; i<2; i++) x = i;
