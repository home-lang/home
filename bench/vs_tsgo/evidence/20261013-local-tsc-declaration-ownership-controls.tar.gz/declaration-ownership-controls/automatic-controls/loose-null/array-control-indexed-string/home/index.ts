let x=[]; x["hello"]=1; x;
