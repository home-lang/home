let x; { let x = 1; x; }
