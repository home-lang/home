let x; function f(x: string) { return x; }
