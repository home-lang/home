function f(){ let x=[]; const g=()=>x; x=[1]; }
