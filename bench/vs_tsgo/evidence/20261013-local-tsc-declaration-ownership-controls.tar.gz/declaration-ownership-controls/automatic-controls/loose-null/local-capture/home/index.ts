function f() { let x; function g() { return x; } }
