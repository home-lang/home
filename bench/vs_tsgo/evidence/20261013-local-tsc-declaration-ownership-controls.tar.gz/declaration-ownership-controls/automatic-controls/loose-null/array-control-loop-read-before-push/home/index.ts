let x=[]; for(let i=0;i<2;i++){ const s:string=x[0]; x.push(1); }
