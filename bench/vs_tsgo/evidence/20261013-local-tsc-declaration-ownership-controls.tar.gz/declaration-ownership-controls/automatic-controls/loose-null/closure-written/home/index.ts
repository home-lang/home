let x; x=1; function f() { return x; }
