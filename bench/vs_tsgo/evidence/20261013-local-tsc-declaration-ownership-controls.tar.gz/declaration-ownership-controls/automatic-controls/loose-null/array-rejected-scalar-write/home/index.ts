let x=[]; x=1; const n:number=x[0];
