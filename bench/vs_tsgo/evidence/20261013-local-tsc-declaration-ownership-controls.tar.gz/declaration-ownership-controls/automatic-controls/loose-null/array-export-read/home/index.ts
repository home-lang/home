export let x=[]; x;
