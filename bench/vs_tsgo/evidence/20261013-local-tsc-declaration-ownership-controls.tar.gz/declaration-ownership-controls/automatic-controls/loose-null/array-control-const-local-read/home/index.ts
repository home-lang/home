function f(){ const x=[]; return x; }
