function f() { let x=[]; }
