function f(){ let x=[]; x.push(1); const g=()=>x; }
