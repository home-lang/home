let x=[]; function f(){ x; let x=[1]; }
