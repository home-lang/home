let x=[]; x=[1]; x.push("s");
