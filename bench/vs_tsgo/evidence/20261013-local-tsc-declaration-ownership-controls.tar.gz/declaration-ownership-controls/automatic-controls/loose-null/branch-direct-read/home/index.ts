declare const flag: boolean; let x; if (flag) x;
