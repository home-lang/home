let value=[];
function inspect(){ value; let value=[1]; }
type Query=typeof later;
let later=1;
class Deferred { field=eventual; }
let eventual=1;
