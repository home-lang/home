let x=[]; try {} catch(x) { x; }
