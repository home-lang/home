function f(){ let x=[]; x.push(1); function g(){ return x; }}
