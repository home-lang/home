function f(){ let x=[]; type X=typeof x; }
