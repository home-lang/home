export let x=[]; x.push(1);
