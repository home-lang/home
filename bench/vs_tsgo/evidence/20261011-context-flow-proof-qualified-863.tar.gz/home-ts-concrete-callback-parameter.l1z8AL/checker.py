import json
from pathlib import Path
import subprocess
import sys
root=Path(__file__).resolve().parent
command=[sys.executable,'/Users/chris/.cache/home-ts-843.3BeUMH/module_tests.py','checker']
with (root/'checker.log').open('w') as output:
 result=subprocess.run(command,stdout=output,stderr=subprocess.STDOUT)
(root/'checker.json').write_text(json.dumps({'command':command,'exit':result.returncode,'test_filters':[]},indent=2)+'\n')
print((root/'checker.log').read_text()[-6000:],flush=True)
sys.exit(result.returncode)
