import hashlib
import io
import json
from pathlib import Path
import tarfile

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
archive = repo / 'bench/vs_tsgo/evidence/20261011-context-flow-proof-qualified-863.tar.gz'
assert not archive.exists()
gates = json.loads((root / 'remaining-gates.json').read_text())
assert [row['target'] for row in gates] == ['driver', 'cli', 'entrypoint'] and all(row['exit'] == 0 for row in gates)
assert json.loads((root / 'program.json').read_text())['exit'] == 0
assert json.loads((root / 'checker.json').read_text())['exit'] == 0
admission = json.loads((root / 'diagnostic-admission.json').read_text())
assert len(admission['records']) == 168 and admission['passed'] and admission['before'] == admission['after']
images = json.loads((root / 'verified-image-admission.json').read_text())
assert images['admissions'] == 180 and images['passed'] and not images['timings_taken']
assert 'Ran 147 tests' in (root / 'harness.log').read_text() and '\nOK\n' in (root / 'harness.log').read_text()
directories = [root] + [Path('/Users/chris/.cache') / name for name in [
    'home-ts-this-context-diagnostic.pbhRmV', 'home-ts-this-context-resolved.qaSAag',
    'home-ts-this-context-source-exports.BQqDJl', 'home-ts-this-context-qualified-setup.hAhaF9',
    'home-ts-this-context-resumed.n5B0Zy', 'home-ts-this-context-type-graph.tQVn8w',
    'home-ts-nested-this-access.mQw7MG', 'home-ts-nested-this-access-fixed.YeC88B',
    'home-ts-concrete-nested-context.0mE3wR', 'home-ts-concrete-nested-coercion.D3Xi2n',
    'home-ts-deferred-graph-audit.u1vHgb', 'home-ts-concrete-callback-parameter.l1z8AL',
    'home-ts-concrete-object-context.L2c1Ps', 'home-ts-callback-member-audit.xZfEha',
    'home-ts-concrete-indexed-member.oBSab1', 'home-ts-compact-read-observer.SgCH0Q',
    'home-ts-assignment-diagnostic-audit.yUkjcX', 'home-ts-reporting-branch-audit.TA4q4H',
    'home-ts-reporter-return-audit.I6Wgc6', 'home-ts-diagnostic-boundary-audit.ZVaIYV',
    'home-ts-diagnostic-boundary-coercion.I5hMuu', 'home-ts-driver-diagnostic-audit.GVy1qF',
    'home-ts-explicit-diagnostic-counts.3Ae7He',
    'home-ts-collection-isolation.5ew7jA', 'home-ts-collection-context.HqtTR3',
]]
payloads = {}
for directory in directories:
    assert directory.is_dir(), str(directory)
    for path in sorted(directory.rglob('*')):
        if path.is_file() and path.suffix in ['.json', '.jsonl', '.log', '.py', '.ts', '.md', '.txt', '.patch']:
            payloads[directory.name + '/' + str(path.relative_to(directory))] = path.read_bytes()
checksums = ''.join(hashlib.sha256(data).hexdigest() + '  ' + name + '\n' for name, data in sorted(payloads.items()))
payloads['SHA256SUMS'] = checksums.encode()
with tarfile.open(archive, 'w:gz') as output:
    for name, data in sorted(payloads.items()):
        info = tarfile.TarInfo(name)
        info.size = len(data)
        output.addfile(info, io.BytesIO(data))
with tarfile.open(archive) as retained:
    for line in checksums.splitlines():
        expected, name = line.split('  ', 1)
        assert hashlib.sha256(retained.extractfile(name).read()).hexdigest() == expected
outcome = {'archive': str(archive), 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
           'payload_checksums_verified': len(payloads) - 1, 'candidate_adopted': False,
           'timings_taken': False, 'zod_admitted': False, 'assertion_ambiguity_correction_retained': True}
(root / 'archive-outcome.json').write_text(json.dumps(outcome, indent=2) + '\n')
print(json.dumps(outcome), flush=True)
