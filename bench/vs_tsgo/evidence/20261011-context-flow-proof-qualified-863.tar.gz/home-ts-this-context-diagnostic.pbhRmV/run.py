import json
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
helper = Path('/Users/chris/.cache/home-ts-843.3BeUMH/module_tests.py').read_text()
namespace = {'__name__': 'diagnostic', 'sys': sys}
sys.argv = ['module_tests.py', 'program']
helper = helper.replace('sys.exit(subprocess.run(command).returncode)', '')
exec(compile(helper, 'module_tests.py', 'exec'), namespace)
command = namespace['command'] + ['--test-filter', 'collection polymorphic this does not erase']
with (root / 'diagnostic.log').open('w') as output:
    result = subprocess.run(command, stdout=output, stderr=subprocess.STDOUT)
(root / 'diagnostic.json').write_text(json.dumps({'command': command, 'exit': result.returncode, 'diagnostic_only_not_qualification': True}, indent=2) + '\n')
print((root / 'diagnostic.log').read_text()[-12000:], flush=True)
sys.exit(result.returncode)
