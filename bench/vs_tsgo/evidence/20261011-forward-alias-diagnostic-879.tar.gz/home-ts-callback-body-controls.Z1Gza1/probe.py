import hashlib
import json
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
integration = Path('/Users/chris/.cache/home-ts-main-flow-proof-integration.dYlSre')
original = Path('/Users/chris/.cache/home-ts-callable-intersection-facts.34PC25')
runner = Path('/Users/chris/.codex/worktrees/ts863-qualification-docs/lang')
sys.path.insert(0, str(runner / 'bench/vs_tsgo'))
import run
import competitors

def save(path, content):
    assert not path.exists(), path
    path.parent.mkdir(parents=True, exist_ok=True)
    patch = '*** Begin Patch\n*** Add File: ' + str(path) + '\n'
    patch += ''.join('+' + line + '\n' for line in content.splitlines())
    patch += '*** End Patch\n'
    subprocess.run(['apply_patch', patch], check=True, capture_output=True)

assert not (root / 'results.json').exists()
candidate = integration / 'candidate-home-tsc'
parent = integration / 'baseline-home-tsc'
assert hashlib.sha256(candidate.read_bytes()).hexdigest() == json.loads((integration / 'candidate-build.json').read_text())['native_sha256']
trace = []
before = {}
variants = {
    'repeated-reads': 'const first:string=part.state.label;const second:string=part.state.label;void first;void second;',
    'nested-throw': 'if(!part.state.label)throw "missing";const value:string=part.state.label;void value;',
    'conditional-read': 'const value:string=part.state.label?part.state.label:part.state.alternate;void value;',
    'tail-contextual': 'const value:string=part.state.label;void value;',
}
for variant, body in variants.items():
    for negative in [False, True]:
        name = variant + ('-negative' if negative else '-positive')
        project = root / name
        prior = original / 'collection-factory-positive'
        for relative in ['tsconfig.json', 'src/util.d.ts', 'src/factory.ts', 'src/lib.d.ts']:
            save(project / relative, (prior / relative).read_text())
        source = (prior / 'src/main.ts').read_text()
        source = source.replace('label:string;', 'label:string;alternate:string;')
        source = source.replace('def:ModelDef;', 'def:ModelDef;parse:(payload:{value:string})=>{value:string};')
        if negative:
            body_here = body + 'const wrong:number=part.state.label;part.missing;void wrong;'
        else:
            body_here = body
        source = source.replace('const text:string=part.state.label;void text;', body_here)
        if variant == 'tail-contextual':
            source = source.replace(' void instance;', ' instance.state.parse=(payload)=>{const value:string=payload.value;return {value};};\n void instance;')
        save(project / 'src/main.ts', source)
        before[name] = competitors.inventory_hash(competitors.payload_inventory(project))
        commands = run.compiler_commands()
        commands['home'] = [str(candidate)]
        commands['parent'] = [str(parent)]
        for compiler, command in commands.items():
            result, passed = run.admission_process(compiler, command + ['--noEmit', '-p', str(project / 'tsconfig.json')],
                name, expected_codes=['2322', '2339'] if negative else None, trace=trace)
            print(name, compiler, result.returncode, passed, trace[-1]['codes'], flush=True)
after = {name: competitors.inventory_hash(competitors.payload_inventory(root / name)) for name in before}
assert before == after
save(root / 'results.json', json.dumps({'records': trace, 'before': before, 'after': after,
    'reference_controls_valid': all(row['passed'] for row in trace if row['compiler'] in ['tsc', 'tsgo']),
    'timings_taken': False, 'source_parent': '65a0332fe01d0b60a7a3387c9ebbc0aebaa789b2'}, indent=2) + '\n')
