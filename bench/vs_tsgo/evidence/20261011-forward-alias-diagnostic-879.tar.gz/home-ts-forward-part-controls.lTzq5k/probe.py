import collections
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

root = Path(__file__).resolve().parent
integration = Path('/Users/chris/.cache/home-ts-main-flow-proof-integration.dYlSre')
original = Path('/Users/chris/.cache/home-ts-callable-intersection-facts.34PC25')
runner = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
sys.path.insert(0, str(runner / 'bench/vs_tsgo'))
import run
import competitors

def save(path, content):
    assert not path.exists(), path
    path.parent.mkdir(parents=True, exist_ok=True)
    patch = '*** Begin Patch\n*** Add File: ' + str(path) + '\n'
    patch += ''.join('+' + line + '\n' for line in content.splitlines()) + '*** End Patch\n'
    subprocess.run(['apply_patch'], input=patch, text=True, check=True, capture_output=True)

def locations(output):
    return collections.Counter(re.findall(r'^(.+)\((\d+),(\d+)\): (?:error|warning) ((?:TS|HM)\d+):', output, re.M))

assert not (root / 'results.json').exists()
candidate = integration / 'candidate-home-tsc'
parent = integration / 'baseline-home-tsc'
diagnostic = Path('/Users/chris/.cache/home-ts-project-surface-diagnostic.AFdbFb/surface-diagnostic')
assert hashlib.sha256(candidate.read_bytes()).hexdigest() == '754926fd350062fac7094768b6adb2f1a5e808b21c37a59ec151b31ac46d59af'
assert hashlib.sha256(diagnostic.read_bytes()).hexdigest() == 'c67038e1876bc21ad260b8229639ab5337d219693432d104f741d47c2054fe4b'
trace = []
observations = []
before = {}
for variant in ['part-forward', 'schema-forward', 'both-forward', 'literal-forward']:
    for negative in [False, True]:
        name = variant + ('-negative' if negative else '-positive')
        project = root / name
        prior = original / ('collection-factory-negative' if negative else 'collection-factory-positive')
        for relative in ['tsconfig.json', 'src/util.d.ts', 'src/factory.ts', 'src/lib.d.ts']:
            save(project / relative, (prior / relative).read_text())
        lines = (prior / 'src/main.ts').read_text().splitlines(True)
        moved = []
        kept = []
        for line in lines:
            moving = (variant in ['part-forward', 'both-forward'] and line.startswith('type Part=')) or (variant in ['schema-forward', 'both-forward'] and line.startswith(('interface NestedState', 'interface Nested '))) or (variant == 'literal-forward' and line.startswith('type LiteralPart='))
            (moved if moving else kept).append(line)
        assert moved
        source = ''.join(kept)
        needle = 'const result:'
        assert source.count(needle) == 1
        source = source.replace(needle, ''.join(moved) + needle)
        save(project / 'src/main.ts', source)
        before[name] = competitors.inventory_hash(competitors.payload_inventory(project))
        commands = run.compiler_commands()
        commands['home'] = [str(candidate)]
        commands['parent'] = [str(parent)]
        candidate_output = None
        for compiler, command in commands.items():
            result, passed = run.admission_process(compiler, command + ['--noEmit', '-p', str(project / 'tsconfig.json')],
                name, expected_codes=['2322', '2339'] if negative else None, trace=trace)
            if compiler == 'home': candidate_output = result.stdout
            print(name, compiler, result.returncode, passed, trace[-1]['codes'], flush=True)
        result = subprocess.run([str(diagnostic), str(project / 'tsconfig.json')], capture_output=True, text=True)
        observations.append({'workload': name, 'exit': result.returncode, 'stdout': result.stdout,
            'stderr': result.stderr, 'diagnostic_locations_identical': locations(result.stdout) == locations(candidate_output),
            'timings_taken': False, 'scope': 'Diagnostic observations only; not an additional benchmark compiler'})
after = {name: competitors.inventory_hash(competitors.payload_inventory(root / name)) for name in before}
assert before == after
save(root / 'results.json', json.dumps({'records': trace, 'diagnostic_observations': observations,
    'before': before, 'after': after,
    'reference_controls_valid': all(row['passed'] for row in trace if row['compiler'] in ['tsc', 'tsgo']),
    'timings_taken': False, 'source_adopted': False}, indent=2) + '\n')
