import * as factory from "./factory";
declare class Collection<T>{add(value:T):this;has(value:T):boolean;}
type Literal=string|number|bigint|boolean|null|undefined;
type LiteralPart=Exclude<Literal,symbol>;
interface BaseDef{kind:string;}
interface BaseState<O=unknown,I=unknown>{def:BaseDef;output:O;input:I;traits:Collection<string>;bag:Record<string,unknown>;}
interface Base<O=unknown,I=unknown,S extends BaseState<O,I>=BaseState<O,I>>{state:S;}
interface NestedState extends BaseState<LiteralPart,LiteralPart>{label:string;alternate:string;}
interface Nested extends Base{state:NestedState;}
type Part=LiteralPart|Nested;
interface ModelDef extends BaseDef{kind:"model";parts:Part[];}
interface ModelState<T extends string=string>extends BaseState<T,T>{def:ModelDef;parse:(payload:{value:string})=>{value:string};}
interface Model<T extends string=string>extends Base{state:ModelState<T>;}
const result:factory.Creator<Model>=factory.create("model",(instance,def)=>{
 for(const part of def.parts)if(typeof part==="object"&&part!==null){const value:string=part.state.label?part.state.label:part.state.alternate;void value;const wrong:number=part.state.label;part.missing;void wrong;}
 void instance;
});void result;
