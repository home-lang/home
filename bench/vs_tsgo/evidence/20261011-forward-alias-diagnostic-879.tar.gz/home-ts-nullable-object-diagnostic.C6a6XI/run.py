import collections
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts863-qualification-docs/lang')
qualified = Path('/Users/chris/.cache/home-ts-main-flow-proof-integration.dYlSre')
assert not (root / 'outcome.json').exists()
assert subprocess.check_output(['git', 'diff'], cwd=repo).decode() == (root / 'source.patch').read_text()
command = ['/Users/chris/Code/Home/lang-bun-port/zig-out/toolchains/zig-aarch64-macos-0.17.0-dev.2163+89ff10d56/zig',
           'build', 'home-tsc', '-Doptimize=ReleaseFast', '-Dhome-tsc-strip=true', '-Denable_jsc=false', '-j1', '--summary', 'all']
with (root / 'build.log').open('w') as output:
    build = subprocess.run(command, cwd=repo, stdout=output, stderr=subprocess.STDOUT)
record = {'build_command': command, 'build_exit': build.returncode, 'diagnostic_only': True, 'timings_taken': False,
          'instrumentation': 'Generic nullable-object narrowing and all object-guard type identities; no library or filename predicates'}
if build.returncode == 0:
    binary = root / 'diagnostic-home-tsc'
    shutil.copy2(repo / 'zig-out/bin/home-tsc', binary)
    record['native_sha256'] = hashlib.sha256(binary.read_bytes()).hexdigest()
    command = [str(binary), '--noEmit', '-p', '/Users/chris/.cache/home-ts-zod-admission.RzJCwi/source/package/tsconfig.benchmark.json', '--home-list-unmodeled-any']
    result = subprocess.run(command, capture_output=True, text=True)
    (root / 'zod.stdout.log').write_text(result.stdout)
    (root / 'zod.stderr.log').write_text(result.stderr)
    prior = next(row for row in json.loads((qualified / 'zod-image-audit.json').read_text()) if row['image'] == 'candidate')
    pattern = r'^(.+)\((\d+),(\d+)\): (?:error|warning) ((?:TS|HM)\d+):'
    before = collections.Counter(re.findall(pattern, prior['stdout'], re.M))
    after = collections.Counter(re.findall(pattern, result.stdout, re.M))
    record.update(command=command, exit=result.returncode, diagnostic_locations_identical=before == after,
                  qualified_native_sha256=json.loads((qualified / 'candidate-build.json').read_text())['native_sha256'],
                  diagnostic_count=sum(after.values()), stderr_bytes=len(result.stderr.encode()),
                  interpretation='Only interpret type observations if complete diagnostic location multiset matches the qualified image')
(root / 'outcome.json').write_text(json.dumps(record, indent=2) + '\n')
print((root / 'build.log').read_text()[-2000:], flush=True)
print(json.dumps(record), flush=True)
raise SystemExit(build.returncode)
