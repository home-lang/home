const std = @import("std");
const entrypoint = @import("entrypoint");

pub fn main(init: std.process.Init) !void {
    var arena = std.heap.ArenaAllocator.init(std.heap.page_allocator);
    defer arena.deinit();
    const args = try init.minimal.args.toSlice(arena.allocator());
    if (args.len != 2) return error.ExpectedProjectConfigPath;
    if (try entrypoint.auditProjectNoEmit(std.heap.smp_allocator, args[1])) std.process.exit(1);
}
