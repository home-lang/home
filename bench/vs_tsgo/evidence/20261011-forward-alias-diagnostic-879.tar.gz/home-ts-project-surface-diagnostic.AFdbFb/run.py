import ast
import collections
import difflib
import hashlib
import json
from pathlib import Path
import re
import shlex
import subprocess
import sys

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts863-qualification-docs/lang')
qualified = Path('/Users/chris/.cache/home-ts-main-flow-proof-integration.dYlSre')
package = Path('/Users/chris/.cache/home-ts-zod-admission.RzJCwi/source/package')
sys.path.insert(0, '/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang/bench/vs_tsgo')
import competitors

def save(path, content):
    assert not path.exists(), path
    patch = '*** Begin Patch\n*** Add File: ' + str(path) + '\n'
    patch += ''.join('+' + line + '\n' for line in content.splitlines()) + '*** End Patch\n'
    subprocess.run(['apply_patch'], input=patch, text=True, check=True, capture_output=True)

def edit(path, before, after):
    delta = ''.join(difflib.unified_diff(before.splitlines(True), after.splitlines(True)))
    delta = re.sub(r'^@@.*@@.*$', '@@', ''.join(delta.splitlines(True)[2:]), flags=re.M)
    patch = '*** Begin Patch\n*** Update File: ' + str(path) + '\n' + delta + '*** End Patch\n'
    subprocess.run(['apply_patch'], input=patch, text=True, check=True, capture_output=True)

def source_patch():
    return subprocess.check_output(['git', 'diff', '--', 'packages/ts_checker/src/check.zig', 'packages/ts_program/src/ts_program.zig'], cwd=repo)

assert not (root / 'outcome.json').exists()
assert hashlib.sha256(source_patch()).hexdigest() == '0e43dc49e16c4c7714bfe25ba1e33cd19840476407403e36919b624bcb9e33bd'
installed_before = hashlib.sha256((repo / 'zig-out/bin/home-tsc').read_bytes()).hexdigest()
assert installed_before == '754926fd350062fac7094768b6adb2f1a5e808b21c37a59ec151b31ac46d59af'
library_before = competitors.inventory_hash(competitors.payload_inventory(package))
checker = repo / 'packages/ts_checker/src/check.zig'
before = checker.read_text()
after = before
needle = '            if (std.mem.eql(u8, lit_str, "object") and self.typeIncludesNull(current)) {\n'
assert after.count(needle) == 1
after = after.replace(needle, needle + '''                const audit_flags = self.interner.pool.flagsOf(current);
                std.debug.print("nullable-object file={s} type={d} union={any} instance={any} object={any} parameter={any}\\n", .{ self.importer_path, current, audit_flags.is_union, audit_flags.is_instantiation, audit_flags.is_object_type, audit_flags.is_type_parameter });
''')
needle = '                    for (members) |member| {\n                        if (member == types.Primitive.null_t or\n'
assert after.count(needle) == 1
after = after.replace(needle, '''                    for (members) |member| {
                        const audit_member_flags = self.interner.pool.flagsOf(member);
                        std.debug.print("nullable-member type={d} instance={any} object={any} parameter={any}\\n", .{ member, audit_member_flags.is_instantiation, audit_member_flags.is_object_type, audit_member_flags.is_type_parameter });
                        for (self.interner.objectMembers(member)) |audit_member| std.debug.print("nullable-field {s}={d}\\n", .{ self.string_interner.get(audit_member.name), audit_member.type });
                        if (member == types.Primitive.null_t or
''')
needle = '        const current = self.lookupNarrow(id.name) orelse declared;\n'
assert after.count(needle) == 1
after = after.replace(needle, needle + '''        if (std.mem.eql(u8, lit_str, "object")) std.debug.print("object-guard file={s} position={d} name={s} declared={d} current={d} positive={any}\\n", .{ self.importer_path, self.hir.spanOf(operand).start, self.string_interner.get(id.name), declared, current, positive });
''')
edit(checker, before, after)
save(root / 'instrumented-source.patch', source_patch().decode())
record = {'diagnostic_only': True, 'timings_taken': False, 'source_adopted': False,
          'entrypoint': 'Snapshot of production tsc_main project admission, resolver adapter, checking and rendering; only its diagnostic project wrapper is reachable',
          'interpretation_condition': 'Full diagnostic location multiset must match the qualified native; no workload/body/diagnostic filtering'}
try:
    module_script = Path('/Users/chris/.cache/home-ts-843.3BeUMH/module_tests.py').read_text()
    tree = ast.parse(module_script)
    build_command = next(ast.literal_eval(node.value) for node in tree.body if isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and target.id == 'BUILD_COMMAND' for target in node.targets))
    argv = shlex.split(build_command)
    modules = []
    deps = []
    index = 2
    while index < len(argv):
        token = argv[index]
        if token == '--dep':
            index += 1
            deps.append(argv[index])
        elif token.startswith('-M'):
            name, path = token[2:].split('=', 1)
            modules.append((name, path, deps))
            deps = []
        index += 1
    binary = root / 'surface-diagnostic'
    command = [argv[0], 'build-exe', '-fstrip', '-OReleaseFast', '--dep', 'entrypoint', '-Mroot=' + str(root / 'main.zig')]
    for name, path, deps in modules:
        command += ['-OReleaseFast']
        for dep in deps:
            command += ['--dep', dep]
        command += ['-M' + ('entrypoint' if name == 'root' else name) + '=' + (str(root / 'tsc_main_snapshot.zig') if name == 'root' else path)]
    for flag in ['--cache-dir', '--global-cache-dir', '--zig-lib-dir']:
        command += [flag, argv[argv.index(flag) + 1]]
    command += ['-femit-bin=' + str(binary)]
    save(root / 'command.json', json.dumps(command, indent=2) + '\n')
    with (root / 'build.log').open('w') as output:
        build = subprocess.run(command, cwd=repo, stdout=output, stderr=subprocess.STDOUT)
    record['build_exit'] = build.returncode
    if build.returncode == 0:
        record['diagnostic_native_sha256'] = hashlib.sha256(binary.read_bytes()).hexdigest()
        result = subprocess.run([str(binary), str(package / 'tsconfig.benchmark.json')], cwd=repo, capture_output=True, text=True)
        save(root / 'zod.stdout.log', result.stdout)
        save(root / 'zod.stderr.log', result.stderr)
        prior = next(row for row in json.loads((qualified / 'zod-image-audit.json').read_text()) if row['image'] == 'candidate')
        pattern = r'^(.+)\((\d+),(\d+)\): (?:error|warning) ((?:TS|HM)\d+):'
        expected = collections.Counter(re.findall(pattern, prior['stdout'], re.M))
        actual = collections.Counter(re.findall(pattern, result.stdout, re.M))
        record.update(exit=result.returncode, diagnostic_locations_identical=expected == actual,
                      diagnostic_count=sum(actual.values()), stderr_bytes=len(result.stderr.encode()))
finally:
    assert checker.read_text() == after
    edit(checker, after, before)
    record['restored_source_patch_sha256'] = hashlib.sha256(source_patch()).hexdigest()
    record['installed_native_sha256'] = hashlib.sha256((repo / 'zig-out/bin/home-tsc').read_bytes()).hexdigest()
    record['library_before'] = library_before
    record['library_after'] = competitors.inventory_hash(competitors.payload_inventory(package))
    assert record['restored_source_patch_sha256'] == '0e43dc49e16c4c7714bfe25ba1e33cd19840476407403e36919b624bcb9e33bd'
    assert record['installed_native_sha256'] == installed_before
    assert record['library_after'] == library_before
    save(root / 'outcome.json', json.dumps(record, indent=2) + '\n')
print(json.dumps(record), flush=True)
print((root / 'build.log').read_text()[-2500:], flush=True)
raise SystemExit(record.get('build_exit', 1))
