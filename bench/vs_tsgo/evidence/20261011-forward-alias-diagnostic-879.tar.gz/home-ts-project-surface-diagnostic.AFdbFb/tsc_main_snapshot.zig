//! `home tsc` binary entry point.
//!
//! Wraps `ts_cli.parseArgs` + `ts_cli.dispatch` (pure-decision layer)
//! with the actual disk I/O: read source files, compile through
//! `ts_program.Program`, and write `.js` (and optionally `.d.ts` /
//! `.js.map`) outputs to disk.
//!
//! This is the binary the CI matrix runs against tsc/tsgo for parity
//! checks. The pure-decision layer in `ts_cli.zig` is exercised by
//! unit tests; this main keeps stdio + filesystem code minimal so
//! the bulk of the logic remains testable.

const std = @import("std");
const builtin = @import("builtin");
const ts_cli = @import("ts_cli");
const ts_program = @import("ts_program");
const ts_resolver = @import("ts_resolver");
const ts_driver = @import("ts_driver");
const ts_diagnostics = @import("ts_diagnostics");
const ts_emit = @import("ts_emit");
const tsconfig_mod = @import("tsconfig");
const ts_watch = @import("ts_watch");
const d_hm = @import("d_hm");
const ts_lsp = @import("ts_lsp");
const ts_lsp_server = @import("ts_lsp_server");
const config_diagnostics = @import("config_diagnostics.zig");

const ts_empty_files_list_in_config: u32 = 18002;

/// tsc writes its normal output (diagnostics, summaries, status messages,
/// help, `--showConfig`) to stdout: typescript-go routes all of it through
/// `sys.Writer()` and uses `ErrorWriter()` only for an env-gated debug
/// logger. Like `std.debug.print`, each call is serialized and flushed
/// before returning, so output survives the `std.process.exit` calls below.
/// Home-internal failures with no tsc counterpart stay on stderr.
fn printStdout(comptime fmt: []const u8, args: anytype) void {
    const io = std.Options.debug_io;
    stdout_mutex.lockUncancelable(io);
    defer stdout_mutex.unlock(io);
    var buffer: [256]u8 = undefined;
    var writer = std.Io.File.stdout().writerStreaming(io, &buffer);
    writer.interface.print(fmt, args) catch return;
    writer.interface.flush() catch {};
}

var stdout_mutex: std.Io.Mutex = .init;

/// tsc's default for `--pretty` when it isn't set: off under `NO_COLOR`, on
/// under `FORCE_COLOR`, otherwise on only when stdout is a terminal, so piped
/// CI output keeps the `file(line,col): error TSxxxx: ...` form problem
/// matchers parse (typescript-go `defaultIsPretty`).
fn defaultIsPretty(environ: *const std.process.Environ.Map, stdout_is_tty: bool) bool {
    if (nonEmptyEnv(environ, "NO_COLOR")) return false;
    if (nonEmptyEnv(environ, "FORCE_COLOR")) return true;
    return stdout_is_tty;
}

fn stdoutIsTty() bool {
    return std.Io.File.stdout().isTty(std.Options.debug_io) catch false;
}

fn nonEmptyEnv(environ: *const std.process.Environ.Map, name: []const u8) bool {
    const value = environ.get(name) orelse return false;
    return value.len > 0;
}

const RealFs = struct {
    fn read(gpa: std.mem.Allocator, path: []const u8) ![]const u8 {
        var threaded = std.Io.Threaded.init(gpa, .{});
        defer threaded.deinit();
        return readWithIo(gpa, threaded.io(), path);
    }

    fn readWithIo(gpa: std.mem.Allocator, io: std.Io, path: []const u8) ![]const u8 {
        const cwd = std.Io.Dir.cwd();
        var file = try cwd.openFile(io, path, .{});
        defer file.close(io);
        const stat = try file.stat(io);
        const size: usize = @intCast(stat.size);
        const buf = try gpa.alloc(u8, size);
        errdefer gpa.free(buf);
        var read_total: usize = 0;
        while (read_total < size) {
            const n = try file.readPositionalAll(io, buf[read_total..], read_total);
            if (n == 0) break;
            read_total += n;
        }
        return buf;
    }

    fn write(gpa: std.mem.Allocator, path: []const u8, bytes: []const u8) !void {
        var threaded = std.Io.Threaded.init(gpa, .{});
        defer threaded.deinit();
        const io = threaded.io();
        const cwd = std.Io.Dir.cwd();
        // Make parent directories first.
        if (std.fs.path.dirname(path)) |parent| {
            cwd.createDirPath(io, parent) catch {};
        }
        var file = try cwd.createFile(io, path, .{ .truncate = true });
        defer file.close(io);
        if (bytes.len > 0) try file.writeStreamingAll(io, bytes);
    }
};

/// Expand `@response-file` arguments in place, mirroring tsc's
/// `parseResponseFile`: a `@file` arg is replaced by the whitespace/
/// quote-tokenized contents of `file` (recursively). A file that can't be
/// read or is empty emits TS5083; an unterminated quoted span emits
/// TS6045. `arena` owns the file contents (the appended args borrow into
/// them, so it must outlive `out`). `depth` guards against cycles.
fn expandResponseFiles(
    gpa: std.mem.Allocator,
    arena: std.mem.Allocator,
    raw: []const []const u8,
    out: *std.ArrayListUnmanaged([]const u8),
    depth: usize,
) void {
    for (raw) |a| {
        if (a.len > 1 and a[0] == '@' and depth <= 32) {
            const fname = a[1..];
            const contents = RealFs.read(arena, fname) catch "";
            if (contents.len == 0) {
                const msg = ts_cli.cannotReadFileDiagnostic(gpa, fname) catch continue;
                defer gpa.free(msg);
                printStdout("{s}\n", .{msg});
                continue;
            }
            const toks = ts_cli.tokenizeResponseFile(gpa, contents) catch continue;
            defer gpa.free(toks.args);
            if (toks.unterminated) {
                const msg = ts_cli.unterminatedResponseFileStringDiagnostic(gpa, fname) catch null;
                if (msg) |m| {
                    defer gpa.free(m);
                    printStdout("{s}\n", .{m});
                }
            }
            expandResponseFiles(gpa, arena, toks.args, out, depth + 1);
        } else {
            out.append(gpa, a) catch {};
        }
    }
}

/// Resolve a project reference (a `references[].path`, or the `tsc -b`
/// project argument) to a canonical `tsconfig.json` path. Per tsc: a path
/// ending in `.json` is the config file itself; otherwise it's a directory
/// holding `tsconfig.json`. `arena`-owned.
fn resolveConfigPath(arena: std.mem.Allocator, base_dir: []const u8, ref: []const u8) ![]u8 {
    if (std.mem.endsWith(u8, ref, ".json")) {
        return std.fs.path.resolve(arena, &.{ base_dir, ref });
    }
    return std.fs.path.resolve(arena, &.{ base_dir, ref, "tsconfig.json" });
}

/// Built project-reference graph: parallel `nodes` (for `topoSortProjects`)
/// and canonical config `paths`.
const LoadedGraph = struct {
    nodes: []ts_cli.ProjectNode,
    paths: [][]const u8,
    diagnostics: []const []const u8 = &.{},
};

/// Load the `tsc --build` project graph starting from `root_config` (a
/// canonical tsconfig path), following `references` recursively. Builds the
/// node/dep structure `topoSortProjects` consumes. Unreadable/unparseable
/// referenced configs are treated as leaf nodes (no deps). `arena`-owned.
fn loadBuildGraph(gpa: std.mem.Allocator, arena: std.mem.Allocator, root_config: []const u8) !LoadedGraph {
    // Everything is arena-owned (freed with the caller's arena) so the
    // temporary lists don't need their own cleanup.
    var paths: std.ArrayListUnmanaged([]const u8) = .empty;
    var dep_lists: std.ArrayListUnmanaged(std.ArrayListUnmanaged(usize)) = .empty;
    var diagnostics: std.ArrayListUnmanaged([]const u8) = .empty;

    const ensure = struct {
        fn idx(a: std.mem.Allocator, ps: *std.ArrayListUnmanaged([]const u8), ds: *std.ArrayListUnmanaged(std.ArrayListUnmanaged(usize)), p: []const u8) !usize {
            for (ps.items, 0..) |existing, i| {
                if (std.mem.eql(u8, existing, p)) return i;
            }
            try ps.append(a, p);
            try ds.append(a, .empty);
            return ps.items.len - 1;
        }
    };

    _ = try ensure.idx(arena, &paths, &dep_lists, root_config);
    var i: usize = 0;
    while (i < paths.items.len) : (i += 1) {
        const cfg_path = paths.items[i];
        const src = RealFs.read(arena, cfg_path) catch continue; // leaf on read error
        const cfg = tsconfig_mod.parseString(gpa, arena, src) catch continue;
        const base = std.fs.path.dirname(cfg_path) orelse ".";
        const parent_has_inputs = projectConfigHasInputFiles(gpa, cfg_path, cfg) catch false;
        const parent_buildinfo = projectBuildInfoFilePath(arena, cfg_path, cfg) catch null;
        for (cfg.references) |ref| {
            const ref_path = resolveConfigPath(arena, base, ref) catch continue;
            const dep_idx = try ensure.idx(arena, &paths, &dep_lists, ref_path);
            try dep_lists.items[i].append(arena, dep_idx);
            const ref_src = RealFs.read(arena, ref_path) catch continue;
            const ref_cfg = tsconfig_mod.parseString(gpa, arena, ref_src) catch continue;
            if (parent_buildinfo) |parent_bi| {
                if (try projectBuildInfoFilePath(arena, ref_path, ref_cfg)) |ref_bi| {
                    if (std.mem.eql(u8, parent_bi, ref_bi)) {
                        try diagnostics.append(arena, try referencedProjectBuildInfoOverwriteDiagnostic(arena, parent_bi, ref));
                    }
                }
            }
            if (parent_has_inputs) {
                if (ref_cfg.compiler_options.composite != true) {
                    try diagnostics.append(arena, try referencedProjectMustBeCompositeDiagnostic(arena, ref));
                }
                if (ref_cfg.compiler_options.no_emit == true) {
                    try diagnostics.append(arena, try referencedProjectMayNotDisableEmitDiagnostic(arena, ref));
                }
            }
        }
    }

    const nodes = try arena.alloc(ts_cli.ProjectNode, paths.items.len);
    for (paths.items, 0..) |p, k| {
        nodes[k] = .{ .name = p, .deps = dep_lists.items[k].items };
    }
    return .{ .nodes = nodes, .paths = paths.items, .diagnostics = diagnostics.items };
}

fn projectConfigHasInputFiles(gpa: std.mem.Allocator, cfg_path: []const u8, cfg: tsconfig_mod.TsConfig) !bool {
    if (cfg.files) |files| return files.len > 0;

    const project_dir = std.fs.path.dirname(cfg_path) orelse ".";
    var input_files: std.ArrayListUnmanaged([]const u8) = .empty;
    defer input_files.deinit(gpa);
    var owned: std.ArrayListUnmanaged([]u8) = .empty;
    defer {
        for (owned.items) |p| gpa.free(p);
        owned.deinit(gpa);
    }
    var exclude_storage: [2][]const u8 = undefined;
    try expandProjectGlobs(
        gpa,
        project_dir,
        effectiveIncludePatterns(cfg),
        cfg.effectiveExcludePatterns(&exclude_storage),
        tsconfig_mod.effectiveAllowJs(cfg.compiler_options),
        &input_files,
        &owned,
    );
    return input_files.items.len > 0;
}

fn projectBuildInfoFilePath(arena: std.mem.Allocator, cfg_path: []const u8, cfg: tsconfig_mod.TsConfig) !?[]const u8 {
    const co = cfg.compiler_options;
    if (co.composite != true and co.incremental != true and co.ts_buildinfo_file == null) return null;

    const project_dir = std.fs.path.dirname(cfg_path) orelse ".";
    if (co.ts_buildinfo_file) |p| {
        if (std.fs.path.isAbsolute(p)) return try arena.dupe(u8, p);
        return try std.fs.path.resolve(arena, &.{ project_dir, p });
    }

    if (co.out_dir) |out_dir| {
        if (std.fs.path.isAbsolute(out_dir)) {
            return try std.fs.path.resolve(arena, &.{ out_dir, "tsconfig.tsbuildinfo" });
        }
        return try std.fs.path.resolve(arena, &.{ project_dir, out_dir, "tsconfig.tsbuildinfo" });
    }

    const cfg_basename = std.fs.path.basename(cfg_path);
    const stem_len = std.mem.lastIndexOfScalar(u8, cfg_basename, '.') orelse cfg_basename.len;
    const buildinfo_basename = try std.fmt.allocPrint(arena, "{s}.tsbuildinfo", .{cfg_basename[0..stem_len]});
    return try std.fs.path.resolve(arena, &.{ project_dir, buildinfo_basename });
}

fn referencedProjectMustBeCompositeDiagnostic(gpa: std.mem.Allocator, ref_path: []const u8) ![]const u8 {
    const code: u32 = 6306;
    return try std.fmt.allocPrint(
        gpa,
        "error TS{d}: Referenced project '{s}' must have setting \"composite\": true.",
        .{ code, ref_path },
    );
}

fn referencedProjectMayNotDisableEmitDiagnostic(gpa: std.mem.Allocator, ref_path: []const u8) ![]const u8 {
    const code: u32 = 6310;
    return try std.fmt.allocPrint(
        gpa,
        "error TS{d}: Referenced project '{s}' may not disable emit.",
        .{ code, ref_path },
    );
}

fn referencedProjectBuildInfoOverwriteDiagnostic(gpa: std.mem.Allocator, output_path: []const u8, ref_path: []const u8) ![]const u8 {
    const code: u32 = 6377;
    return try std.fmt.allocPrint(
        gpa,
        "error TS{d}: Cannot write file '{s}' because it will overwrite '.tsbuildinfo' file generated by referenced project '{s}'.",
        .{ code, output_path, ref_path },
    );
}

fn printConfigValidationDiagnostics(
    gpa: std.mem.Allocator,
    cfg: tsconfig_mod.TsConfig,
    source: []const u8,
    diagnostics: []const tsconfig_mod.ValidationDiagnostic,
    pretty: bool,
    color: bool,
) !void {
    for (diagnostics) |d| {
        const formatted = try config_diagnostics.format(gpa, cfg, source, d, pretty, color);
        defer gpa.free(formatted);
        printStdout("{s}\n", .{formatted});
    }
}

fn printResolvedConfig(loaded_cfg: ?tsconfig_mod.TsConfig, input_files: []const []const u8) void {
    printStdout("{{\n", .{});
    printStdout("  \"compileOnSave\": false,\n", .{});
    printStdout("  \"compilerOptions\": {{\n", .{});
    if (loaded_cfg) |c| {
        const co = c.compiler_options;
        var option_count: usize = 0;
        if (co.target != null) option_count += 1;
        if (co.module != null) option_count += 1;
        if (co.out_dir != null) option_count += 1;
        if (co.strict != null) option_count += 1;
        if (co.declaration != null) option_count += 1;
        var option_index: usize = 0;
        if (co.target) |t| {
            option_index += 1;
            printStdout("    \"target\": \"{s}\"{s}\n", .{ @tagName(t), if (option_index < option_count) "," else "" });
        }
        if (co.module) |m| {
            option_index += 1;
            printStdout("    \"module\": \"{s}\"{s}\n", .{ @tagName(m), if (option_index < option_count) "," else "" });
        }
        if (co.out_dir) |d| {
            option_index += 1;
            printStdout("    \"outDir\": \"{s}\"{s}\n", .{ d, if (option_index < option_count) "," else "" });
        }
        if (co.strict) |s| {
            option_index += 1;
            printStdout("    \"strict\": {s}{s}\n", .{ if (s) "true" else "false", if (option_index < option_count) "," else "" });
        }
        if (co.declaration) |d| {
            option_index += 1;
            printStdout("    \"declaration\": {s}{s}\n", .{ if (d) "true" else "false", if (option_index < option_count) "," else "" });
        }
    }
    printStdout("  }},\n", .{});
    printStdout("  \"files\": [\n", .{});
    for (input_files, 0..) |path, i| {
        printStdout("    \"{s}\"{s}\n", .{ path, if (i + 1 < input_files.len) "," else "" });
    }
    printStdout("  ]\n", .{});
    printStdout("}}\n", .{});
}

fn reportErrorSummary(
    pretty: bool,
    error_count: usize,
    files_with_errors: usize,
    first_error_file: []const u8,
    first_error_line: usize,
    error_file_counts: []const ErrorFileCount,
) void {
    if (!pretty or error_count == 0) return;
    if (error_count == 1) {
        if (files_with_errors == 1 and first_error_file.len != 0) {
            buildStatusMessage(6259, "Found 1 error in {s}\n", .{first_error_file});
        } else {
            buildStatusMessage(6216, "Found 1 error.\n", .{});
        }
    } else if (files_with_errors > 1) {
        buildStatusMessage(6261, "Found {d} errors in {d} files.\n", .{ error_count, files_with_errors });
        printErrorFileSummaryTable(error_file_counts);
    } else if (files_with_errors == 1 and first_error_file.len != 0) {
        buildStatusMessage(6260, "Found {d} errors in the same file, starting at: {s}:{d}\n", .{ error_count, first_error_file, first_error_line });
    } else {
        buildStatusMessage(6217, "Found {d} errors.\n", .{error_count});
    }
}

/// Emit a tsc status message. tsc prints these
/// CategoryMessage diagnostics as plain text (no `TSxxxx:` prefix); the
/// `code` is carried so the diagnostic-coverage ledger credits it.
fn buildStatusMessage(comptime code: u32, comptime fmt: []const u8, args: anytype) void {
    comptime std.debug.assert(code >= 6000);
    printStdout(fmt, args);
}

fn reportWatchErrorStatus(error_count: usize) void {
    if (error_count == 1) {
        buildStatusMessage(6193, "Found 1 error. Watching for file changes.\n", .{});
    } else {
        buildStatusMessage(6194, "Found {d} errors. Watching for file changes.\n", .{error_count});
    }
}

fn printTraceEntries(sink: *const ts_resolver.TraceSink, printed_count: *usize) void {
    while (printed_count.* < sink.entries.items.len) : (printed_count.* += 1) {
        printStdout("{s}\n", .{sink.entries.items[printed_count.*].text});
    }
}

/// A project is up to date when every expected output (`.js`, and `.d.ts`
/// when declarations are emitted) exists and is at least as new as every
/// input file. Mirrors the timestamp half of tsc's getUpToDateStatus.
fn projectIsUpToDate(
    gpa: std.mem.Allocator,
    inputs: []const []const u8,
    out_dir: ?[]const u8,
    declaration_dir: ?[]const u8,
    emit_dts: bool,
    project: []const u8,
    verbose: bool,
) bool {
    var newest_input: i128 = std.math.minInt(i128);
    var newest_input_path: []const u8 = "";
    var oldest_output: i128 = std.math.maxInt(i128);
    var oldest_output_path: []u8 = "";
    defer if (oldest_output_path.len != 0) gpa.free(oldest_output_path);
    for (inputs) |in| {
        const m = fileMtimeNanos(in) orelse return false; // can't stat → rebuild
        if (m > newest_input) {
            newest_input = m;
            newest_input_path = in;
        }
    }
    for (inputs) |in| {
        const js = computeOutPath(gpa, in, out_dir, ".js") catch return false;
        defer gpa.free(js);
        const jm = fileMtimeNanos(js) orelse {
            // TS6352 — output file does not exist → out of date.
            if (verbose) buildStatusMessage(6352, "Project '{s}' is out of date because output file '{s}' does not exist\n", .{ project, js });
            return false;
        };
        if (jm < newest_input) {
            // TS6350 — output older than input → out of date.
            if (verbose) buildStatusMessage(6350, "Project '{s}' is out of date because output '{s}' is older than input '{s}'\n", .{ project, js, newest_input_path });
            return false;
        }
        if (verbose and jm < oldest_output) {
            if (oldest_output_path.len != 0) gpa.free(oldest_output_path);
            oldest_output_path = gpa.dupe(u8, js) catch "";
            oldest_output = jm;
        }
        if (emit_dts) {
            const dts = computeOutPath(gpa, in, declaration_dir, ".d.ts") catch return false;
            defer gpa.free(dts);
            const dm = fileMtimeNanos(dts) orelse {
                if (verbose) buildStatusMessage(6352, "Project '{s}' is out of date because output file '{s}' does not exist\n", .{ project, dts });
                return false;
            };
            if (dm < newest_input) {
                if (verbose) buildStatusMessage(6350, "Project '{s}' is out of date because output '{s}' is older than input '{s}'\n", .{ project, dts, newest_input_path });
                return false;
            }
            if (verbose and dm < oldest_output) {
                if (oldest_output_path.len != 0) gpa.free(oldest_output_path);
                oldest_output_path = gpa.dupe(u8, dts) catch "";
                oldest_output = dm;
            }
        }
    }
    // TS6351 — verbose build reason for a timestamp-clean project.
    if (verbose and oldest_output_path.len != 0) {
        buildStatusMessage(6351, "Project '{s}' is up to date because newest input '{s}' is older than output '{s}'\n", .{ project, newest_input_path, oldest_output_path });
    }
    return true;
}

const BuildOneProjectResult = enum {
    up_to_date,
    built_dts_unchanged,
    built_dts_changed,
    errors_outputs_skipped,
    errors_outputs_generated,
};

fn shouldReportUpToDateWithDtsFilesFromDependencies(upstream_dependency_built_with_unchanged_dts: bool) bool {
    return upstream_dependency_built_with_unchanged_dts;
}

/// Build a single project (used by `tsc --build` for each project in
/// dependency order): load its tsconfig, gather inputs, compile, and emit
/// `.js` (+ `.d.ts` when declaration/composite is set). Paths are resolved
/// against the project's own directory. Reuses the same program/driver/emit
/// APIs as the normal single-project flow.
fn buildOneProject(
    gpa: std.mem.Allocator,
    arena: std.mem.Allocator,
    config_path: []const u8,
    verbose: bool,
    force: bool,
    upstream_dependency_built_with_unchanged_dts: bool,
    default_pretty: bool,
) BuildOneProjectResult {
    const cfg_src = RealFs.read(arena, config_path) catch {
        printStdout("error reading {s}\n", .{config_path});
        return .errors_outputs_skipped;
    };
    var cfg = tsconfig_mod.parseString(gpa, arena, cfg_src) catch {
        printStdout("error parsing {s}\n", .{config_path});
        return .errors_outputs_skipped;
    };
    cfg.file_path = config_path;
    const config_validation_diags = cfg.validate(gpa) catch return .errors_outputs_skipped;
    defer tsconfig_mod.freeValidationDiagnostics(gpa, config_validation_diags);
    const project_pretty = cfg.compiler_options.pretty orelse default_pretty;
    printConfigValidationDiagnostics(
        gpa,
        cfg,
        cfg_src,
        config_validation_diags,
        project_pretty,
        project_pretty,
    ) catch return .errors_outputs_skipped;
    const config_summary = config_diagnostics.summarize(cfg, config_validation_diags);
    const config_errors = config_summary.hasErrors();
    const project_dir = std.fs.path.dirname(config_path) orelse ".";

    var input_files: std.ArrayListUnmanaged([]const u8) = .empty;
    defer input_files.deinit(gpa);
    var owned: std.ArrayListUnmanaged([]u8) = .empty;
    defer {
        for (owned.items) |p| gpa.free(p);
        owned.deinit(gpa);
    }
    if (cfg.files) |fs_list| {
        ts_cli.appendProjectFilePaths(gpa, project_dir, fs_list, &input_files, &owned) catch return .errors_outputs_skipped;
    } else {
        var exclude_storage: [2][]const u8 = undefined;
        expandProjectGlobs(
            gpa,
            project_dir,
            effectiveIncludePatterns(cfg),
            cfg.effectiveExcludePatterns(&exclude_storage),
            tsconfig_mod.effectiveAllowJs(cfg.compiler_options),
            &input_files,
            &owned,
        ) catch return .errors_outputs_skipped;
    }
    if (input_files.items.len == 0) {
        if (verbose) printStdout("  (no input files)\n", .{});
        return .up_to_date;
    }

    // Output directories are resolved against the project's own dir.
    const out_dir: ?[]const u8 = if (cfg.compiler_options.out_dir) |d|
        (std.fs.path.join(arena, &.{ project_dir, d }) catch return .errors_outputs_skipped)
    else
        null;
    const emit_dts = (cfg.compiler_options.declaration orelse false) or (cfg.compiler_options.composite orelse false);
    const declaration_dir: ?[]const u8 = if (cfg.compiler_options.declaration_dir) |d|
        (std.fs.path.join(arena, &.{ project_dir, d }) catch return .errors_outputs_skipped)
    else
        out_dir;

    // Incremental up-to-date check (tsc's getUpToDateStatus, simplified to
    // input/output mtime comparison). Skipped under `--force`.
    if (!force and !config_errors) {
        if (projectBuildInfoVersionMismatch(gpa, arena, config_path, cfg)) |stored_version| {
            if (verbose) {
                const default_options = ts_emit.tsbuildinfo.Options{};
                buildStatusMessage(6381, "Project '{s}' is out of date because output for it was generated with version '{s}' that differs with current version '{s}'\n", .{ config_path, stored_version, default_options.compiler_version });
            }
        } else if (projectBuildInfoHasPendingEmit(gpa, arena, config_path, cfg)) |buildinfo_path| {
            if (verbose) {
                buildStatusMessage(6399, "Project '{s}' is out of date because buildinfo file '{s}' indicates that some of the changes were not emitted\n", .{ config_path, buildinfo_path });
            }
        } else if (projectBuildInfoHasErrors(gpa, arena, config_path, cfg)) |buildinfo_path| {
            if (verbose) {
                buildStatusMessage(6419, "Project '{s}' is out of date because buildinfo file '{s}' indicates that program needs to report errors.\n", .{ config_path, buildinfo_path });
            }
        } else if (projectBuildInfoOptionsMismatch(gpa, arena, config_path, cfg)) |buildinfo_path| {
            if (verbose) {
                buildStatusMessage(6406, "Project '{s}' is out of date because buildinfo file '{s}' indicates there is change in compilerOptions\n", .{ config_path, buildinfo_path });
            }
        } else if (projectBuildInfoRootMismatch(gpa, arena, config_path, cfg, input_files.items)) |mismatch| {
            if (verbose) {
                buildStatusMessage(6412, "Project '{s}' is out of date because buildinfo file '{s}' indicates that file '{s}' was root file of compilation but not any more.\n", .{ config_path, mismatch.buildinfo_path, mismatch.root_path });
            }
        } else if (projectNeedsTimestampUpdate(gpa, arena, config_path, cfg, input_files.items, out_dir, declaration_dir, emit_dts)) {
            if (verbose) {
                buildStatusMessage(6400, "Project '{s}' is up to date but needs to update timestamps of output files that are older than input files\n", .{config_path});
                buildStatusMessage(6359, "Updating output timestamps of project '{s}'...\n", .{config_path});
            }
            touchProjectOutputs(gpa, input_files.items, out_dir, declaration_dir, emit_dts);
            return .up_to_date;
        } else if (projectIsUpToDate(gpa, input_files.items, out_dir, declaration_dir, emit_dts, config_path, verbose and !shouldReportUpToDateWithDtsFilesFromDependencies(upstream_dependency_built_with_unchanged_dts))) {
            if (verbose and shouldReportUpToDateWithDtsFilesFromDependencies(upstream_dependency_built_with_unchanged_dts)) {
                buildStatusMessage(6354, "Project '{s}' is up to date with .d.ts files from its dependencies\n", .{config_path});
            }
            return .up_to_date;
        }
    }
    // TS6388 — under `--force`, tsc rebuilds regardless of up-to-dateness.
    if (force and verbose) buildStatusMessage(6388, "Project '{s}' is being forcibly rebuilt\n", .{config_path});
    // TS6358 — `Building project '{0}'...`
    if (verbose) buildStatusMessage(6358, "Building project '{s}'...\n", .{config_path});

    const resolver_config = resolverConfigFromConfig(arena, cfg, null);

    var resolver_fs = ResolverRealFs.init(gpa);
    defer resolver_fs.deinit();
    var resolver = ts_resolver.Resolver.init(gpa, resolver_fs.fs(), resolver_config);
    defer resolver.deinit();
    var program = ts_program.Program.init(gpa, &resolver);
    defer program.deinit();
    for (input_files.items) |path| {
        const src = RealFs.read(gpa, path) catch {
            printStdout("error reading {s}\n", .{path});
            return .errors_outputs_skipped;
        };
        defer gpa.free(src);
        _ = program.add(path, src) catch return .errors_outputs_skipped;
    }

    var compile_opts = ts_driver.optionsFromConfig(&cfg);
    var resolver_adapter = CheckerResolverAdapter.init(gpa, &resolver);
    defer resolver_adapter.deinit();
    resolver_adapter.setProgramSources(&program, compile_opts);
    compile_opts.external_resolver = .{ .ptr = &resolver_adapter, .vtable = &CheckerResolverAdapter.vtable };
    _ = program.loadImportClosureParallel(compile_opts, null) catch {};

    var had_errors = config_errors;
    var stream_ctx: StreamCtx = .{
        .gpa = gpa,
        .program = &program,
        .use_pretty = project_pretty,
        .use_color = project_pretty,
        .filter = if (config_errors) .syntax_only else .all,
        .any_errors = &had_errors,
    };
    program.compileAllStreaming(compile_opts, &stream_ctx, streamDiagsCallback) catch return .errors_outputs_skipped;
    if (!config_errors and (cfg.compiler_options.composite orelse false)) {
        const composite_summary = printCompositeProjectFileListDiagnostics(
            gpa,
            &program,
            input_files.items,
            config_path,
            true,
            false,
        );
        if (composite_summary.error_count > 0) had_errors = true;
    }
    if (compile_opts.no_emit) return if (had_errors) .errors_outputs_skipped else .built_dts_unchanged;

    var reported_unchanged_timestamps = false;
    var changed_dts = false;
    for (program.files.items) |f| {
        const c = f.compilation orelse continue;
        const out_path = computeOutPath(gpa, f.path, out_dir, ".js") catch continue;
        defer gpa.free(out_path);
        _ = writeProjectOutput(gpa, out_path, c.js, config_path, verbose, &reported_unchanged_timestamps);
        if (emit_dts) {
            const dts_path = computeOutPath(gpa, f.path, declaration_dir, ".d.ts") catch continue;
            defer gpa.free(dts_path);
            // Prefer zig-dtsx (source-driven, infers exported types); fall
            // back to the symbol-driven emitter if it can't process the file.
            if (ts_emit.d_ts_fast.emit(gpa, f.source)) |dts| {
                defer gpa.free(dts);
                if (writeProjectOutput(gpa, dts_path, dts, config_path, verbose, &reported_unchanged_timestamps)) changed_dts = true;
            } else |_| {
                var emitter = ts_emit.DtsEmitter.initWithTypes(gpa, &c.hir, &c.interner, &c.type_interner, .{});
                defer emitter.deinit();
                emitter.emitSourceFile(c.root) catch continue;
                const dts_bytes = emitter.toOwnedSlice() catch continue;
                defer gpa.free(dts_bytes);
                if (writeProjectOutput(gpa, dts_path, dts_bytes, config_path, verbose, &reported_unchanged_timestamps)) changed_dts = true;
            }
        }
    }
    if (had_errors) return .errors_outputs_generated;
    return if (changed_dts) .built_dts_changed else .built_dts_unchanged;
}

const ProjectDryStatus = enum { build, up_to_date, update_timestamps };

fn projectDryStatus(gpa: std.mem.Allocator, arena: std.mem.Allocator, config_path: []const u8) ProjectDryStatus {
    const cfg_src = RealFs.read(arena, config_path) catch return .build;
    var cfg = tsconfig_mod.parseString(gpa, arena, cfg_src) catch return .build;
    cfg.file_path = config_path;
    const project_dir = std.fs.path.dirname(config_path) orelse ".";

    var input_files: std.ArrayListUnmanaged([]const u8) = .empty;
    defer input_files.deinit(gpa);
    var owned: std.ArrayListUnmanaged([]u8) = .empty;
    defer {
        for (owned.items) |p| gpa.free(p);
        owned.deinit(gpa);
    }
    if (cfg.files) |fs_list| {
        ts_cli.appendProjectFilePaths(gpa, project_dir, fs_list, &input_files, &owned) catch return .build;
    } else {
        var exclude_storage: [2][]const u8 = undefined;
        expandProjectGlobs(
            gpa,
            project_dir,
            effectiveIncludePatterns(cfg),
            cfg.effectiveExcludePatterns(&exclude_storage),
            tsconfig_mod.effectiveAllowJs(cfg.compiler_options),
            &input_files,
            &owned,
        ) catch return .build;
    }
    if (input_files.items.len == 0) return .up_to_date;

    const out_dir: ?[]const u8 = if (cfg.compiler_options.out_dir) |d|
        (std.fs.path.join(arena, &.{ project_dir, d }) catch return .build)
    else
        null;
    const emit_dts = (cfg.compiler_options.declaration orelse false) or (cfg.compiler_options.composite orelse false);
    const declaration_dir: ?[]const u8 = if (cfg.compiler_options.declaration_dir) |d|
        (std.fs.path.join(arena, &.{ project_dir, d }) catch return .build)
    else
        out_dir;

    if (projectNeedsTimestampUpdate(gpa, arena, config_path, cfg, input_files.items, out_dir, declaration_dir, emit_dts)) {
        return .update_timestamps;
    }
    return if (projectIsUpToDate(gpa, input_files.items, out_dir, declaration_dir, emit_dts, config_path, false))
        .up_to_date
    else
        .build;
}

fn buildInfoVersionForPath(info: ts_emit.tsbuildinfo.BuildInfo, path: []const u8) ?[]const u8 {
    for (info.file_names, 0..) |name, i| {
        if (std.mem.eql(u8, name, path)) return info.file_infos[i].version;
    }
    return null;
}

fn projectBuildInfoVersionMismatch(
    gpa: std.mem.Allocator,
    arena: std.mem.Allocator,
    config_path: []const u8,
    cfg: tsconfig_mod.TsConfig,
) ?[]const u8 {
    const buildinfo_path = (projectBuildInfoFilePath(arena, config_path, cfg) catch null) orelse return null;
    const buildinfo_src = RealFs.read(gpa, buildinfo_path) catch return null;
    defer gpa.free(buildinfo_src);
    var info = ts_emit.tsbuildinfo.read(gpa, buildinfo_src) catch return null;
    defer info.deinit(gpa);
    const default_options = ts_emit.tsbuildinfo.Options{};
    const current_version = default_options.compiler_version;
    if (std.mem.eql(u8, info.version, current_version)) return null;
    return arena.dupe(u8, info.version) catch null;
}

fn projectBuildInfoOptionsMismatch(
    gpa: std.mem.Allocator,
    arena: std.mem.Allocator,
    config_path: []const u8,
    cfg: tsconfig_mod.TsConfig,
) ?[]const u8 {
    const buildinfo_path = (projectBuildInfoFilePath(arena, config_path, cfg) catch null) orelse return null;
    const buildinfo_src = RealFs.read(gpa, buildinfo_path) catch return null;
    defer gpa.free(buildinfo_src);
    var info = ts_emit.tsbuildinfo.read(gpa, buildinfo_src) catch return null;
    defer info.deinit(gpa);
    const current_options = buildInfoOptionsJson(gpa, cfg) catch return null;
    defer gpa.free(current_options);
    if (std.mem.eql(u8, info.options_json, current_options)) return null;
    return buildinfo_path;
}

fn projectBuildInfoHasPendingEmit(
    gpa: std.mem.Allocator,
    arena: std.mem.Allocator,
    config_path: []const u8,
    cfg: tsconfig_mod.TsConfig,
) ?[]const u8 {
    const buildinfo_path = (projectBuildInfoFilePath(arena, config_path, cfg) catch null) orelse return null;
    const buildinfo_src = RealFs.read(gpa, buildinfo_path) catch return null;
    defer gpa.free(buildinfo_src);
    var info = ts_emit.tsbuildinfo.read(gpa, buildinfo_src) catch return null;
    defer info.deinit(gpa);
    if (!info.has_pending_emit) return null;
    return buildinfo_path;
}

fn projectBuildInfoHasErrors(
    gpa: std.mem.Allocator,
    arena: std.mem.Allocator,
    config_path: []const u8,
    cfg: tsconfig_mod.TsConfig,
) ?[]const u8 {
    const buildinfo_path = (projectBuildInfoFilePath(arena, config_path, cfg) catch null) orelse return null;
    const buildinfo_src = RealFs.read(gpa, buildinfo_path) catch return null;
    defer gpa.free(buildinfo_src);
    var info = ts_emit.tsbuildinfo.read(gpa, buildinfo_src) catch return null;
    defer info.deinit(gpa);
    if (!info.has_errors) return null;
    return buildinfo_path;
}

const BuildInfoRootMismatch = struct {
    buildinfo_path: []const u8,
    root_path: []const u8,
};

fn projectBuildInfoRootMismatch(
    gpa: std.mem.Allocator,
    arena: std.mem.Allocator,
    config_path: []const u8,
    cfg: tsconfig_mod.TsConfig,
    inputs: []const []const u8,
) ?BuildInfoRootMismatch {
    const buildinfo_path = (projectBuildInfoFilePath(arena, config_path, cfg) catch null) orelse return null;
    const buildinfo_src = RealFs.read(gpa, buildinfo_path) catch return null;
    defer gpa.free(buildinfo_src);
    var info = ts_emit.tsbuildinfo.read(gpa, buildinfo_src) catch return null;
    defer info.deinit(gpa);
    for (info.file_names) |name| {
        if (!isTsLikeExtension(name)) continue;
        if (pathInList(inputs, name)) continue;
        return .{
            .buildinfo_path = buildinfo_path,
            .root_path = arena.dupe(u8, name) catch return null,
        };
    }
    return null;
}

fn buildInfoOptionsJson(gpa: std.mem.Allocator, cfg: tsconfig_mod.TsConfig) ![]u8 {
    var buf: std.ArrayListUnmanaged(u8) = .empty;
    errdefer buf.deinit(gpa);
    try buf.append(gpa, '{');
    var first = true;
    const co = cfg.compiler_options;

    const BoolEntry = struct { name: []const u8, field: []const u8 };
    const bool_fields = comptime [_]BoolEntry{
        .{ .name = "strict", .field = "strict" },
        .{ .name = "noImplicitAny", .field = "no_implicit_any" },
        .{ .name = "strictNullChecks", .field = "strict_null_checks" },
        .{ .name = "strictFunctionTypes", .field = "strict_function_types" },
        .{ .name = "strictBindCallApply", .field = "strict_bind_call_apply" },
        .{ .name = "strictPropertyInitialization", .field = "strict_property_initialization" },
        .{ .name = "noImplicitThis", .field = "no_implicit_this" },
        .{ .name = "useUnknownInCatchVariables", .field = "use_unknown_in_catch_variables" },
        .{ .name = "alwaysStrict", .field = "always_strict" },
        .{ .name = "noUnusedLocals", .field = "no_unused_locals" },
        .{ .name = "noUnusedParameters", .field = "no_unused_parameters" },
        .{ .name = "exactOptionalPropertyTypes", .field = "exact_optional_property_types" },
        .{ .name = "noImplicitReturns", .field = "no_implicit_returns" },
        .{ .name = "noFallthroughCasesInSwitch", .field = "no_fallthrough_cases_in_switch" },
        .{ .name = "noUncheckedIndexedAccess", .field = "no_unchecked_indexed_access" },
        .{ .name = "noImplicitOverride", .field = "no_implicit_override" },
        .{ .name = "noPropertyAccessFromIndexSignature", .field = "no_property_access_from_index_signature" },
        .{ .name = "erasableSyntaxOnly", .field = "erasable_syntax_only" },
        .{ .name = "skipLibCheck", .field = "skip_lib_check" },
        .{ .name = "skipDefaultLibCheck", .field = "skip_default_lib_check" },
        .{ .name = "forceConsistentCasingInFileNames", .field = "force_consistent_casing_in_file_names" },
        .{ .name = "traceResolution", .field = "trace_resolution" },
        .{ .name = "keyofStringsOnly", .field = "keyof_strings_only" },
        .{ .name = "suppressExcessPropertyErrors", .field = "suppress_excess_property_errors" },
        .{ .name = "suppressImplicitAnyIndexErrors", .field = "suppress_implicit_any_index_errors" },
        .{ .name = "resolveJsonModule", .field = "resolve_json_module" },
        .{ .name = "resolvePackageJsonExports", .field = "resolve_package_json_exports" },
        .{ .name = "resolvePackageJsonImports", .field = "resolve_package_json_imports" },
        .{ .name = "allowImportingTsExtensions", .field = "allow_importing_ts_extensions" },
        .{ .name = "rewriteRelativeImportExtensions", .field = "rewrite_relative_import_extensions" },
        .{ .name = "esModuleInterop", .field = "es_module_interop" },
        .{ .name = "isolatedModules", .field = "isolated_modules" },
        .{ .name = "isolatedDeclarations", .field = "isolated_declarations" },
        .{ .name = "verbatimModuleSyntax", .field = "verbatim_module_syntax" },
        .{ .name = "allowSyntheticDefaultImports", .field = "allow_synthetic_default_imports" },
        .{ .name = "noLib", .field = "no_lib" },
        .{ .name = "declaration", .field = "declaration" },
        .{ .name = "declarationMap", .field = "declaration_map" },
        .{ .name = "emitDeclarationOnly", .field = "emit_declaration_only" },
        .{ .name = "composite", .field = "composite" },
        .{ .name = "incremental", .field = "incremental" },
        .{ .name = "assumeChangesOnlyAffectDirectDependencies", .field = "assume_changes_only_affect_direct_dependencies" },
        .{ .name = "disableSizeLimit", .field = "disable_size_limit" },
        .{ .name = "removeComments", .field = "remove_comments" },
        .{ .name = "noEmit", .field = "no_emit" },
        .{ .name = "importHelpers", .field = "import_helpers" },
        .{ .name = "noEmitHelpers", .field = "no_emit_helpers" },
        .{ .name = "downlevelIteration", .field = "down_level_iteration" },
        .{ .name = "preserveConstEnums", .field = "preserve_const_enums" },
        .{ .name = "experimentalDecorators", .field = "experimental_decorators" },
        .{ .name = "emitDecoratorMetadata", .field = "emit_decorator_metadata" },
        .{ .name = "sourceMap", .field = "source_map" },
        .{ .name = "inlineSourceMap", .field = "inline_source_map" },
        .{ .name = "inlineSources", .field = "inline_sources" },
        .{ .name = "allowJs", .field = "allow_js" },
        .{ .name = "checkJs", .field = "check_js" },
        .{ .name = "useDefineForClassFields", .field = "use_define_for_class_fields" },
    };
    inline for (bool_fields) |entry| {
        try appendBuildInfoBoolOption(gpa, &buf, &first, entry.name, @field(co, entry.field));
    }

    try appendBuildInfoStringOption(gpa, &buf, &first, "baseUrl", co.base_url);
    try appendBuildInfoStringOption(gpa, &buf, &first, "moduleDetection", co.module_detection);
    try appendBuildInfoStringOption(gpa, &buf, &first, "ignoreDeprecations", co.ignore_deprecations);
    try appendBuildInfoStringOption(gpa, &buf, &first, "jsxFactory", co.jsx_factory);
    try appendBuildInfoStringOption(gpa, &buf, &first, "jsxFragmentFactory", co.jsx_fragment_factory);
    try appendBuildInfoStringOption(gpa, &buf, &first, "jsxImportSource", co.jsx_import_source);
    try appendBuildInfoStringOption(gpa, &buf, &first, "reactNamespace", co.react_namespace);
    try appendBuildInfoStringOption(gpa, &buf, &first, "outDir", co.out_dir);
    try appendBuildInfoStringOption(gpa, &buf, &first, "rootDir", co.root_dir);
    try appendBuildInfoStringOption(gpa, &buf, &first, "declarationDir", co.declaration_dir);
    try appendBuildInfoStringOption(gpa, &buf, &first, "mapRoot", co.map_root);
    try appendBuildInfoStringOption(gpa, &buf, &first, "sourceRoot", co.source_root);
    try appendBuildInfoStringOption(gpa, &buf, &first, "tsBuildInfoFile", co.ts_buildinfo_file);
    try appendBuildInfoNumberOption(gpa, &buf, &first, "maxNodeModuleJsDepth", co.max_node_module_js_depth);

    if (co.module) |value| try appendBuildInfoStringOption(gpa, &buf, &first, "module", moduleOptionName(value));
    if (co.module_resolution) |value| try appendBuildInfoStringOption(gpa, &buf, &first, "moduleResolution", moduleResolutionOptionName(value));
    if (co.target) |value| try appendBuildInfoStringOption(gpa, &buf, &first, "target", targetOptionName(value));
    if (co.jsx) |value| try appendBuildInfoStringOption(gpa, &buf, &first, "jsx", jsxOptionName(value));

    try appendBuildInfoStringArrayOption(gpa, &buf, &first, "rootDirs", co.root_dirs);
    try appendBuildInfoStringArrayOption(gpa, &buf, &first, "typeRoots", co.type_roots);
    try appendBuildInfoStringArrayOption(gpa, &buf, &first, "types", co.types);
    try appendBuildInfoStringArrayOption(gpa, &buf, &first, "customConditions", co.custom_conditions);
    try appendBuildInfoStringArrayOption(gpa, &buf, &first, "lib", co.lib);
    if (co.paths) |paths| try appendBuildInfoPathsOption(gpa, &buf, &first, paths);

    try buf.append(gpa, '}');
    return buf.toOwnedSlice(gpa);
}

fn appendBuildInfoOptionKey(
    gpa: std.mem.Allocator,
    buf: *std.ArrayListUnmanaged(u8),
    first: *bool,
    name: []const u8,
) !void {
    if (!first.*) try buf.append(gpa, ',');
    first.* = false;
    try buf.append(gpa, '"');
    try appendJsonStringBody(gpa, buf, name);
    try buf.appendSlice(gpa, "\":");
}

fn appendBuildInfoBoolOption(
    gpa: std.mem.Allocator,
    buf: *std.ArrayListUnmanaged(u8),
    first: *bool,
    name: []const u8,
    value: ?bool,
) !void {
    const actual = value orelse return;
    try appendBuildInfoOptionKey(gpa, buf, first, name);
    try buf.appendSlice(gpa, if (actual) "true" else "false");
}

fn appendBuildInfoNumberOption(
    gpa: std.mem.Allocator,
    buf: *std.ArrayListUnmanaged(u8),
    first: *bool,
    name: []const u8,
    value: ?f64,
) !void {
    const actual = value orelse return;
    try appendBuildInfoOptionKey(gpa, buf, first, name);
    const rendered = try std.fmt.allocPrint(gpa, "{d}", .{actual});
    defer gpa.free(rendered);
    try buf.appendSlice(gpa, rendered);
}

fn appendBuildInfoStringOption(
    gpa: std.mem.Allocator,
    buf: *std.ArrayListUnmanaged(u8),
    first: *bool,
    name: []const u8,
    value: ?[]const u8,
) !void {
    const actual = value orelse return;
    try appendBuildInfoOptionKey(gpa, buf, first, name);
    try buf.append(gpa, '"');
    try appendJsonStringBody(gpa, buf, actual);
    try buf.append(gpa, '"');
}

fn appendBuildInfoStringArrayOption(
    gpa: std.mem.Allocator,
    buf: *std.ArrayListUnmanaged(u8),
    first: *bool,
    name: []const u8,
    value: ?[][]const u8,
) !void {
    const actual = value orelse return;
    try appendBuildInfoOptionKey(gpa, buf, first, name);
    try appendBuildInfoJsonStringArray(gpa, buf, actual);
}

fn appendBuildInfoPathsOption(
    gpa: std.mem.Allocator,
    buf: *std.ArrayListUnmanaged(u8),
    first: *bool,
    paths: tsconfig_mod.Paths,
) !void {
    try appendBuildInfoOptionKey(gpa, buf, first, "paths");
    try buf.append(gpa, '{');
    for (paths.patterns, 0..) |pattern, i| {
        if (i > 0) try buf.append(gpa, ',');
        try buf.append(gpa, '"');
        try appendJsonStringBody(gpa, buf, pattern);
        try buf.appendSlice(gpa, "\":");
        try appendBuildInfoJsonStringArray(gpa, buf, paths.substitutions[i]);
    }
    try buf.append(gpa, '}');
}

fn appendBuildInfoJsonStringArray(
    gpa: std.mem.Allocator,
    buf: *std.ArrayListUnmanaged(u8),
    values: []const []const u8,
) !void {
    try buf.append(gpa, '[');
    for (values, 0..) |value, i| {
        if (i > 0) try buf.append(gpa, ',');
        try buf.append(gpa, '"');
        try appendJsonStringBody(gpa, buf, value);
        try buf.append(gpa, '"');
    }
    try buf.append(gpa, ']');
}

fn appendJsonStringBody(gpa: std.mem.Allocator, buf: *std.ArrayListUnmanaged(u8), value: []const u8) !void {
    for (value) |c| switch (c) {
        '"' => try buf.appendSlice(gpa, "\\\""),
        '\\' => try buf.appendSlice(gpa, "\\\\"),
        '\n' => try buf.appendSlice(gpa, "\\n"),
        '\r' => try buf.appendSlice(gpa, "\\r"),
        '\t' => try buf.appendSlice(gpa, "\\t"),
        else => try buf.append(gpa, c),
    };
}

fn moduleOptionName(value: tsconfig_mod.Module) []const u8 {
    return @tagName(value);
}

fn moduleResolutionOptionName(value: tsconfig_mod.ModuleResolution) []const u8 {
    return @tagName(value);
}

fn resolverConfigFromConfig(
    arena: std.mem.Allocator,
    cfg: tsconfig_mod.TsConfig,
    cli_out_dir: ?[]const u8,
) ts_resolver.Config {
    const co = cfg.compiler_options;
    var resolver_config: ts_resolver.Config = .{};
    if (co.module_resolution) |mr| {
        resolver_config.strategy = switch (mr) {
            .classic => .classic,
            .node10 => .node10,
            .node16 => .node16,
            .nodenext => .nodenext,
            .bundler => .bundler,
        };
        resolver_config.explicit_strategy = true;
    }
    if (co.base_url) |base_url| resolver_config.base_url = base_url;
    if (co.paths) |paths| {
        resolver_config.paths = ts_resolver.Config.pathEntriesFromParallel(
            arena,
            paths.patterns,
            paths.substitutions,
        ) catch &.{};
    }
    const effective_out_dir = cli_out_dir orelse co.out_dir;
    if (effective_out_dir) |out_dir_value| resolver_config.out_dir = out_dir_value;
    if (co.declaration_dir) |declaration_dir_value| {
        resolver_config.declaration_dir = declaration_dir_value;
    } else if (effective_out_dir) |out_dir_value| {
        resolver_config.declaration_dir = out_dir_value;
    }
    if (co.root_dir) |root_dir| resolver_config.root_dir = root_dir;
    if (co.root_dirs) |root_dirs| resolver_config.root_dirs = root_dirs;
    if (co.type_roots) |type_roots| resolver_config.type_roots = type_roots;
    resolver_config.config_file_path = cfg.file_path;
    resolver_config.project_reference_output_diagnostics = cfg.references.len > 0;
    return resolver_config;
}

fn targetOptionName(value: tsconfig_mod.Target) []const u8 {
    return @tagName(value);
}

fn jsxOptionName(value: tsconfig_mod.Jsx) []const u8 {
    return switch (value) {
        .preserve => "preserve",
        .react => "react",
        .react_jsx => "react-jsx",
        .react_jsxdev => "react-jsxdev",
        .react_native => "react-native",
    };
}

fn sourceSha1Hex(gpa: std.mem.Allocator, source: []const u8) ![]u8 {
    var hasher = std.crypto.hash.Sha1.init(.{});
    hasher.update(source);
    var digest: [20]u8 = undefined;
    hasher.final(&digest);
    const hex = try gpa.alloc(u8, digest.len * 2);
    const hex_chars = "0123456789abcdef";
    for (digest, 0..) |b, i| {
        hex[i * 2] = hex_chars[b >> 4];
        hex[i * 2 + 1] = hex_chars[b & 0x0F];
    }
    return hex;
}

fn projectNeedsTimestampUpdate(
    gpa: std.mem.Allocator,
    arena: std.mem.Allocator,
    config_path: []const u8,
    cfg: tsconfig_mod.TsConfig,
    inputs: []const []const u8,
    out_dir: ?[]const u8,
    declaration_dir: ?[]const u8,
    emit_dts: bool,
) bool {
    const buildinfo_path = (projectBuildInfoFilePath(arena, config_path, cfg) catch null) orelse return false;
    const buildinfo_src = RealFs.read(gpa, buildinfo_path) catch return false;
    defer gpa.free(buildinfo_src);
    var info = ts_emit.tsbuildinfo.read(gpa, buildinfo_src) catch return false;
    defer info.deinit(gpa);

    var newest_input: i128 = std.math.minInt(i128);
    for (inputs) |path| {
        const input_mtime = fileMtimeNanos(path) orelse return false;
        if (input_mtime > newest_input) newest_input = input_mtime;
        const source = RealFs.read(gpa, path) catch return false;
        defer gpa.free(source);
        const current_hash = sourceSha1Hex(gpa, source) catch return false;
        defer gpa.free(current_hash);
        const stored_hash = buildInfoVersionForPath(info, path) orelse return false;
        if (!std.mem.eql(u8, current_hash, stored_hash)) return false;
    }

    var found_older_output = false;
    for (inputs) |path| {
        const js = computeOutPath(gpa, path, out_dir, ".js") catch return false;
        defer gpa.free(js);
        const js_mtime = fileMtimeNanos(js) orelse return false;
        if (js_mtime < newest_input) found_older_output = true;
        if (emit_dts) {
            const dts = computeOutPath(gpa, path, declaration_dir, ".d.ts") catch return false;
            defer gpa.free(dts);
            const dts_mtime = fileMtimeNanos(dts) orelse return false;
            if (dts_mtime < newest_input) found_older_output = true;
        }
    }
    return found_older_output;
}

fn touchFileNow(path: []const u8) void {
    var threaded = std.Io.Threaded.init(std.heap.page_allocator, .{});
    defer threaded.deinit();
    const io = threaded.io();
    const cwd = std.Io.Dir.cwd();
    var file = cwd.openFile(io, path, .{}) catch return;
    defer file.close(io);
    file.setTimestampsNow(io) catch {};
}

fn touchProjectOutputs(
    gpa: std.mem.Allocator,
    inputs: []const []const u8,
    out_dir: ?[]const u8,
    declaration_dir: ?[]const u8,
    emit_dts: bool,
) void {
    for (inputs) |path| {
        const js = computeOutPath(gpa, path, out_dir, ".js") catch continue;
        defer gpa.free(js);
        touchFileNow(js);
        if (emit_dts) {
            const dts = computeOutPath(gpa, path, declaration_dir, ".d.ts") catch continue;
            defer gpa.free(dts);
            touchFileNow(dts);
        }
    }
}

fn writeProjectOutput(
    gpa: std.mem.Allocator,
    path: []const u8,
    bytes: []const u8,
    project: []const u8,
    verbose: bool,
    reported_unchanged_timestamps: *bool,
) bool {
    if (RealFs.read(gpa, path)) |existing| {
        defer gpa.free(existing);
        if (std.mem.eql(u8, existing, bytes)) {
            if (verbose and !reported_unchanged_timestamps.*) {
                buildStatusMessage(6371, "Updating unchanged output timestamps of project '{s}'...\n", .{project});
                reported_unchanged_timestamps.* = true;
            }
            touchFileNow(path);
            return false;
        }
    } else |_| {}
    writeOrDie(gpa, path, bytes);
    return true;
}

fn appendCleanOutputIfPresent(
    gpa: std.mem.Allocator,
    inputs: []const []const u8,
    outputs: *std.ArrayListUnmanaged([]u8),
    output_path: []const u8,
) !void {
    if (pathInList(inputs, output_path)) return;
    if (fileMtimeNanos(output_path) == null) return;
    try outputs.append(gpa, try gpa.dupe(u8, output_path));
}

fn appendProjectCleanOutputs(
    gpa: std.mem.Allocator,
    arena: std.mem.Allocator,
    config_path: []const u8,
    outputs: *std.ArrayListUnmanaged([]u8),
) !void {
    const cfg_src = RealFs.read(arena, config_path) catch return;
    var cfg = tsconfig_mod.parseString(gpa, arena, cfg_src) catch return;
    cfg.file_path = config_path;
    const project_dir = std.fs.path.dirname(config_path) orelse ".";

    var input_files: std.ArrayListUnmanaged([]const u8) = .empty;
    defer input_files.deinit(gpa);
    var owned: std.ArrayListUnmanaged([]u8) = .empty;
    defer {
        for (owned.items) |p| gpa.free(p);
        owned.deinit(gpa);
    }
    if (cfg.files) |fs_list| {
        try ts_cli.appendProjectFilePaths(gpa, project_dir, fs_list, &input_files, &owned);
    } else {
        var exclude_storage: [2][]const u8 = undefined;
        try expandProjectGlobs(
            gpa,
            project_dir,
            effectiveIncludePatterns(cfg),
            cfg.effectiveExcludePatterns(&exclude_storage),
            tsconfig_mod.effectiveAllowJs(cfg.compiler_options),
            &input_files,
            &owned,
        );
    }

    const out_dir: ?[]const u8 = if (cfg.compiler_options.out_dir) |d|
        try std.fs.path.join(arena, &.{ project_dir, d })
    else
        null;
    const emit_dts = (cfg.compiler_options.declaration orelse false) or (cfg.compiler_options.composite orelse false);
    const declaration_dir: ?[]const u8 = if (cfg.compiler_options.declaration_dir) |d|
        try std.fs.path.join(arena, &.{ project_dir, d })
    else
        out_dir;

    for (input_files.items) |path| {
        const js = try computeOutPath(gpa, path, out_dir, ".js");
        defer gpa.free(js);
        try appendCleanOutputIfPresent(gpa, input_files.items, outputs, js);
        if (emit_dts) {
            const dts = try computeOutPath(gpa, path, declaration_dir, ".d.ts");
            defer gpa.free(dts);
            try appendCleanOutputIfPresent(gpa, input_files.items, outputs, dts);
        }
    }
}

fn printDryCleanOutputs(outputs: []const []u8) void {
    // TS6356 — dry clean status with one bullet per would-delete output.
    buildStatusMessage(6356, "A non-dry build would delete the following files:\n", .{});
    for (outputs) |path| {
        printStdout(" * {s}\n", .{path});
    }
}

fn alreadyIncludedFileNameDiffersOnlyInCasingMessage(
    gpa: std.mem.Allocator,
    file_name: []const u8,
    existing_file_name: []const u8,
) ![]u8 {
    return std.fmt.allocPrint(
        gpa,
        "Already included file name '{s}' differs from file name '{s}' only in casing.",
        .{ file_name, existing_file_name },
    );
}

const CaseOnlyInputFileMismatch = struct {
    file_name: []const u8,
    existing_file_name: []const u8,
    file_index: usize,
    existing_file_index: usize,
};

fn findCaseOnlyInputFileMismatch(input_files: []const []const u8) ?CaseOnlyInputFileMismatch {
    for (input_files, 0..) |path, i| {
        var j: usize = 0;
        while (j < i) : (j += 1) {
            const previous = input_files[j];
            if (std.mem.eql(u8, previous, path)) break;
            if (!std.ascii.eqlIgnoreCase(previous, path)) continue;
            return .{
                .file_name = path,
                .existing_file_name = previous,
                .file_index = i,
                .existing_file_index = j,
            };
        }
    }
    return null;
}

const CaseOnlyInputRootContext = struct {
    kind: enum { none, files, include } = .none,
    config_path: []const u8 = "",
    config_source: []const u8 = "",
    specs: []const []const u8 = &.{},
};

fn findTsConfigSpecLineCol(config_source: []const u8, property: []const u8, spec: []const u8) struct { line: u32, col: u32 } {
    if (config_source.len == 0) return .{ .line = 1, .col = 1 };
    var start: usize = 0;
    var property_buf: [64]u8 = undefined;
    const property_needle = std.fmt.bufPrint(&property_buf, "\"{s}\"", .{property}) catch "";
    if (property_needle.len > 0) {
        if (std.mem.indexOf(u8, config_source, property_needle)) |pos| start = pos + property_needle.len;
    }
    var spec_buf: [512]u8 = undefined;
    const spec_needle = std.fmt.bufPrint(&spec_buf, "\"{s}\"", .{spec}) catch "";
    const pos = if (spec_needle.len > 0)
        std.mem.indexOf(u8, config_source[start..], spec_needle)
    else
        null;
    const absolute_pos = if (pos) |p| start + p else start;
    const line_col = ts_diagnostics.positionToLineCol(config_source, @intCast(@min(absolute_pos, std.math.maxInt(u32))));
    return .{ .line = line_col.line, .col = line_col.col };
}

fn caseOnlyInputRelatedInfo(
    ctx: CaseOnlyInputRootContext,
    mismatch: CaseOnlyInputFileMismatch,
    out: *[2]ts_diagnostics.Related,
) []const ts_diagnostics.Related {
    const code_include_pattern_specified_here: u32 = 1408;
    const code_files_list_specified_here: u32 = 1410;
    const code = switch (ctx.kind) {
        .files => code_files_list_specified_here,
        .include => code_include_pattern_specified_here,
        .none => return &.{},
    };
    const message = (ts_diagnostics.codes.lookup(code) orelse unreachable).message;
    const property = switch (ctx.kind) {
        .files => "files",
        .include => "include",
        .none => unreachable,
    };

    var len: usize = 0;
    const indices = [_]usize{ mismatch.existing_file_index, mismatch.file_index };
    for (indices) |index| {
        const spec = if (index < ctx.specs.len) ctx.specs[index] else if (ctx.specs.len > 0) ctx.specs[0] else "";
        const lc = findTsConfigSpecLineCol(ctx.config_source, property, spec);
        out[len] = .{
            .file = ctx.config_path,
            .line = lc.line,
            .col = lc.col,
            .code = code,
            .code_prefix = .TS,
            .message = message,
        };
        len += 1;
    }
    return out[0..len];
}

fn caseOnlyInputReasonChain(
    gpa: std.mem.Allocator,
    ctx: CaseOnlyInputRootContext,
    top: *[1]ts_diagnostics.ChainEntry,
    children: *[1]ts_diagnostics.ChainEntry,
    owned_child_message: *?[]u8,
) ![]const ts_diagnostics.ChainEntry {
    const code_file_in_program_because: u32 = 1430;
    const code_include_pattern: u32 = 1407;
    const code_files_list: u32 = 1409;
    const child_message: []const u8 = switch (ctx.kind) {
        .files => (ts_diagnostics.codes.lookup(code_files_list) orelse unreachable).message,
        .include => blk: {
            const pattern = if (ctx.specs.len > 0) ctx.specs[0] else "**/*";
            const config_name = if (ctx.config_path.len > 0) ctx.config_path else "tsconfig.json";
            owned_child_message.* = try std.fmt.allocPrint(
                gpa,
                "Matched by include pattern '{s}' in '{s}'",
                .{ pattern, config_name },
            );
            _ = code_include_pattern;
            break :blk owned_child_message.*.?;
        },
        .none => return &.{},
    };

    children[0] = .{ .message = child_message };
    top[0] = .{
        .message = (ts_diagnostics.codes.lookup(code_file_in_program_because) orelse unreachable).message,
        .children = children[0..1],
    };
    return top[0..1];
}

fn alreadyIncludedFileNameDiffersOnlyInCasingDiagnostic(
    gpa: std.mem.Allocator,
    mismatch: CaseOnlyInputFileMismatch,
    chain: []const ts_diagnostics.ChainEntry,
    related: []const ts_diagnostics.Related,
) ![]u8 {
    const message = try alreadyIncludedFileNameDiffersOnlyInCasingMessage(gpa, mismatch.file_name, mismatch.existing_file_name);
    defer gpa.free(message);
    const diag: ts_diagnostics.Diagnostic = .{
        .file = "",
        .line = 0,
        .col = 0,
        .code = 1261,
        .code_prefix = .TS,
        .severity = .err,
        .message = message,
        .span_len = 0,
        .chain = chain,
        .related = related,
    };
    return ts_diagnostics.formatDefault(gpa, diag);
}

fn reportCaseOnlyInputFileDiagnostics(gpa: std.mem.Allocator, input_files: []const []const u8, root_context: CaseOnlyInputRootContext) bool {
    const mismatch = findCaseOnlyInputFileMismatch(input_files) orelse return false;
    var chain_top_buf: [1]ts_diagnostics.ChainEntry = undefined;
    var chain_child_buf: [1]ts_diagnostics.ChainEntry = undefined;
    var owned_chain_child_message: ?[]u8 = null;
    defer if (owned_chain_child_message) |msg| gpa.free(msg);
    const chain = caseOnlyInputReasonChain(gpa, root_context, &chain_top_buf, &chain_child_buf, &owned_chain_child_message) catch &.{};
    var related_buf: [2]ts_diagnostics.Related = undefined;
    const related = caseOnlyInputRelatedInfo(root_context, mismatch, &related_buf);
    const msg = alreadyIncludedFileNameDiffersOnlyInCasingDiagnostic(gpa, mismatch, chain, related) catch return true;
    defer gpa.free(msg);
    printStdout("{s}\n", .{msg});
    return true;
}

/// How a root (input) file was specified, for `--explainFiles`.
const RootInclusion = struct {
    /// TS1427 / TS1409 / TS1457 / TS1407 — chosen by provenance.
    code: u32,
    /// For TS1407, the include patterns in source order. The first pattern
    /// that actually matches each root supplies that root's `{0}`.
    specs: []const []const u8 = &.{},
    /// Directory against which include patterns are interpreted.
    project_dir: []const u8 = "",
    /// Config file path, for TS1407's `{1}`.
    config_path: []const u8 = "",
};

const ExplainNodeFormatReason = struct {
    code: u32,
    message: []const u8,
};

fn sourceLooksExternalOrCommonJSModule(source: []const u8) bool {
    return std.mem.indexOf(u8, source, "import ") != null or
        std.mem.indexOf(u8, source, "export ") != null or
        std.mem.indexOf(u8, source, "require(") != null or
        std.mem.indexOf(u8, source, "module.exports") != null or
        std.mem.indexOf(u8, source, "exports.") != null;
}

fn nodeExplainModuleKind(module: ?tsconfig_mod.Module) ?tsconfig_mod.Module {
    return switch (module orelse return null) {
        .node16, .node18, .node20, .nodenext => |m| m,
        else => null,
    };
}

fn packageTypeCanAffectPath(file_path: []const u8) bool {
    return !(std.mem.endsWith(u8, file_path, ".mts") or
        std.mem.endsWith(u8, file_path, ".cts") or
        std.mem.endsWith(u8, file_path, ".mjs") or
        std.mem.endsWith(u8, file_path, ".cjs"));
}

fn nearestPackageJson(gpa: std.mem.Allocator, fs: ts_resolver.FileSystem, file_path: []const u8) !?[]u8 {
    var dir = std.fs.path.dirname(file_path) orelse return null;
    while (true) {
        const candidate = try std.fs.path.join(gpa, &.{ dir, "package.json" });
        if (fs.fileExists(candidate)) return candidate;
        gpa.free(candidate);
        const parent = std.fs.path.dirname(dir) orelse return null;
        if (std.mem.eql(u8, parent, dir)) return null;
        dir = parent;
    }
}

fn packageJsonTypeKind(gpa: std.mem.Allocator, fs: ts_resolver.FileSystem, package_json_path: []const u8) enum { missing, module, other } {
    const bytes = fs.readFile(gpa, package_json_path) catch return .missing;
    defer gpa.free(bytes);
    const parsed = std.json.parseFromSlice(std.json.Value, gpa, bytes, .{}) catch return .missing;
    defer parsed.deinit();
    const object = switch (parsed.value) {
        .object => |object| object,
        else => return .missing,
    };
    const type_value = object.get("type") orelse return .missing;
    return switch (type_value) {
        .string => |s| if (std.mem.eql(u8, s, "module")) .module else .other,
        else => .missing,
    };
}

fn explainNodeFormatReason(
    gpa: std.mem.Allocator,
    fs: ts_resolver.FileSystem,
    file_path: []const u8,
    source: []const u8,
    module: ?tsconfig_mod.Module,
) !?ExplainNodeFormatReason {
    _ = nodeExplainModuleKind(module) orelse return null;
    if (!packageTypeCanAffectPath(file_path)) return null;
    if (!sourceLooksExternalOrCommonJSModule(source)) return null;

    const package_json_path = try nearestPackageJson(gpa, fs, file_path) orelse {
        return .{
            .code = 1461,
            .message = try gpa.dupe(u8, "File is CommonJS module because 'package.json' was not found"),
        };
    };
    defer gpa.free(package_json_path);

    return switch (packageJsonTypeKind(gpa, fs, package_json_path)) {
        .module => .{
            .code = 1458,
            .message = try std.fmt.allocPrint(
                gpa,
                "File is ECMAScript module because '{s}' has field \"type\" with value \"module\"",
                .{package_json_path},
            ),
        },
        .other => .{
            .code = 1459,
            .message = try std.fmt.allocPrint(
                gpa,
                "File is CommonJS module because '{s}' has field \"type\" whose value is not \"module\"",
                .{package_json_path},
            ),
        },
        .missing => .{
            .code = 1460,
            .message = try std.fmt.allocPrint(
                gpa,
                "File is CommonJS module because '{s}' does not have field \"type\"",
                .{package_json_path},
            ),
        },
    };
}

fn printNodeFormatExplain(
    gpa: std.mem.Allocator,
    fs: ts_resolver.FileSystem,
    f: *const ts_program.File,
    module: ?tsconfig_mod.Module,
) void {
    if (f.redirect_target != null) return;
    const reason = explainNodeFormatReason(gpa, fs, f.path, f.source, module) catch return;
    if (reason) |r| {
        defer gpa.free(r.message);
        printStdout("  {s}\n", .{r.message});
    }
}

fn rootIncludeRelativePath(root: RootInclusion, file_path: []const u8) []const u8 {
    const project_dir = std.mem.trimEnd(u8, root.project_dir, "/\\");
    if (project_dir.len == 0 and root.project_dir.len > 0 and
        (root.project_dir[0] == '/' or root.project_dir[0] == '\\'))
    {
        return std.mem.trimStart(u8, file_path, "/\\");
    }
    if (project_dir.len == 0 or std.mem.eql(u8, project_dir, ".")) {
        return if (std.mem.startsWith(u8, file_path, "./")) file_path[2..] else file_path;
    }
    if (!std.mem.startsWith(u8, file_path, project_dir)) return file_path;
    if (file_path.len == project_dir.len) return "";
    if (file_path[project_dir.len] != '/' and file_path[project_dir.len] != '\\') return file_path;
    return file_path[project_dir.len + 1 ..];
}

fn matchingRootIncludeSpec(root: RootInclusion, file_path: []const u8) []const u8 {
    const relative_path = rootIncludeRelativePath(root, file_path);
    for (root.specs) |spec| {
        if (tsconfig_mod.matchFileIncludeGlob(spec, relative_path)) return spec;
    }
    return if (root.specs.len > 0) root.specs[0] else "**/*";
}

fn printImportIncludeReasonLine(
    gpa: std.mem.Allocator,
    program: *const ts_program.Program,
    reason: ts_program.IncludeReason,
) void {
    const importer_path = program.files.items[reason.importer].path;
    const message = if (reason.package_id.len != 0)
        std.fmt.allocPrint(
            gpa,
            "  Imported via {s} from file '{s}' with packageId '{s}'",
            .{ reason.specifier_text, importer_path, reason.package_id },
        ) catch return
    else
        std.fmt.allocPrint(
            gpa,
            "  Imported via {s} from file '{s}'",
            .{ reason.specifier_text, importer_path },
        ) catch return;
    defer gpa.free(message);
    printStdout("{s}\n", .{message});
}

/// `--explainFiles`: print each program file with the reason it is part of
/// the compilation, mirroring tsc's `ExplainFiles`. Root (input) files use
/// the provenance-derived reason; transitively-added files use their recorded
/// import/reference reason.
fn printExplainFiles(
    gpa: std.mem.Allocator,
    fs: ts_resolver.FileSystem,
    program: *const ts_program.Program,
    roots: []const []const u8,
    root: RootInclusion,
    module: ?tsconfig_mod.Module,
) void {
    // The file-inclusion reason codes this renders (referenced here so the
    // status scanner credits them as emitted).
    const code_root_specified: u32 = 1427;
    const code_files_list: u32 = 1409;
    const code_default_include: u32 = 1457;
    const code_include_pattern: u32 = 1407;
    // TS1393/TS1394 `Imported via {0} from file '{1}'` — the reason a
    // transitively-included (non-root) file is in the program. Mirrors
    // tsgo's `fileIncludeKindImport` branch of `computeReferenceFileDiagnostic`.
    const code_imported_via: u32 = 1393;
    const code_imported_via_package: u32 = 1394;
    _ = code_imported_via;
    _ = code_imported_via_package;
    // TS1395/TS1396 — compiler-injected `tslib` import for importHelpers.
    const code_imported_helper_via: u32 = 1395;
    const code_imported_helper_via_package: u32 = 1396;
    _ = code_imported_helper_via;
    _ = code_imported_helper_via_package;
    // TS1397/TS1398 — automatic JSX runtime imports.
    const code_imported_jsx_runtime_via: u32 = 1397;
    const code_imported_jsx_runtime_via_package: u32 = 1398;
    _ = code_imported_jsx_runtime_via;
    _ = code_imported_jsx_runtime_via_package;
    // TS1400 `Referenced via '{0}' from file '{1}'` — a file pulled in by
    // a `/// <reference path="…" />` directive.
    const code_referenced_via: u32 = 1400;
    _ = code_referenced_via;
    // TS1402/TS1403 — type library pulled in by `/// <reference types>`.
    const code_type_library_referenced_via: u32 = 1402;
    const code_type_library_referenced_via_package: u32 = 1403;
    _ = code_type_library_referenced_via;
    _ = code_type_library_referenced_via_package;
    // TS1404 — related-info anchor for the `types` directive.
    const code_file_included_via_type_library_reference_here: u32 = 1404;
    _ = code_file_included_via_type_library_reference_here;
    // TS1405 — library pulled in by `/// <reference lib>`.
    const code_library_referenced_via: u32 = 1405;
    _ = code_library_referenced_via;
    // TS1406 — related-info anchor for the `lib` directive.
    const code_file_included_via_library_reference_here: u32 = 1406;
    _ = code_file_included_via_library_reference_here;
    // TS1417/TS1418/TS1419 — explicit compilerOptions.types entries.
    const code_entry_point_type_library: u32 = 1417;
    const code_entry_point_type_library_package: u32 = 1418;
    const code_file_is_entry_point_type_library_here: u32 = 1419;
    _ = code_entry_point_type_library;
    _ = code_entry_point_type_library_package;
    _ = code_file_is_entry_point_type_library_here;
    // TS1420/TS1421 — automatic visible `@types` inclusions.
    const code_entry_point_implicit_type_library: u32 = 1420;
    const code_entry_point_implicit_type_library_package: u32 = 1421;
    _ = code_entry_point_implicit_type_library;
    _ = code_entry_point_implicit_type_library_package;
    // TS1422/TS1423 — explicit compilerOptions.lib entries.
    const code_library_in_compiler_options: u32 = 1422;
    const code_file_is_library_specified_here: u32 = 1423;
    _ = code_library_in_compiler_options;
    _ = code_file_is_library_specified_here;
    // TS1424/TS1425/TS1426 — implicit default library inclusion.
    const code_default_library: u32 = 1424;
    const code_default_library_for_target: u32 = 1425;
    const code_file_is_default_library_for_target_here: u32 = 1426;
    _ = code_default_library;
    _ = code_default_library_for_target;
    _ = code_file_is_default_library_for_target_here;
    // TS1428 — output declaration file redirected to a project-reference source.
    const code_file_is_output_of_project_reference_source: u32 = 1428;
    _ = code_file_is_output_of_project_reference_source;
    // TS1429 — package-ID deduplication redirect to a canonical source file.
    const code_file_redirects_to_file: u32 = 1429;
    _ = code_file_redirects_to_file;
    // TS1458–TS1461 explain how Node16/NodeNext implied module format was
    // derived from the nearest package.json, mirroring tsgo's
    // explainRedirectAndImpliedFormat helper.
    const code_esm_package_type_module: u32 = 1458;
    const code_cjs_package_type_not_module: u32 = 1459;
    const code_cjs_package_no_type: u32 = 1460;
    const code_cjs_package_not_found: u32 = 1461;
    _ = code_esm_package_type_module;
    _ = code_cjs_package_type_not_module;
    _ = code_cjs_package_no_type;
    _ = code_cjs_package_not_found;
    for (program.files.items) |f| {
        printStdout("{s}\n", .{explainFileDisplayPath(f)});
        const is_root = pathInList(roots, f.path);
        if (is_root) {
            // A file can independently be an include root and the target of
            // an import. TypeScript reports both reasons (for example an
            // explicitly included package entry imported by `root.ts`).
            if (f.include_reason) |reason| {
                if (reason.kind == .import) printImportIncludeReasonLine(gpa, program, reason);
            }
        } else {
            // A non-root file is here because something pulled it in —
            // an import (TS1393) or a `/// <reference path>` directive
            // (TS1400). tsgo prints one line per include reason; Home
            // records the first puller.
            if (f.include_reason) |ir| {
                switch (ir.kind) {
                    .import => {
                        printImportIncludeReasonLine(gpa, program, ir);
                        printProjectReferenceOutputExplain(f);
                        printRedirectExplain(program, f);
                        printNodeFormatExplain(gpa, fs, f, module);
                        continue;
                    },
                    .imported_helper => {
                        const importer_path = program.files.items[ir.importer].path;
                        const msg = if (ir.package_id.len != 0)
                            std.fmt.allocPrint(
                                gpa,
                                "  Imported via {s} from file '{s}' with packageId '{s}' to import 'importHelpers' as specified in compilerOptions",
                                .{ ir.specifier_text, importer_path, ir.package_id },
                            ) catch return
                        else
                            std.fmt.allocPrint(
                                gpa,
                                "  Imported via {s} from file '{s}' to import 'importHelpers' as specified in compilerOptions",
                                .{ ir.specifier_text, importer_path },
                            ) catch return;
                        defer gpa.free(msg);
                        printStdout("{s}\n", .{msg});
                        printProjectReferenceOutputExplain(f);
                        printRedirectExplain(program, f);
                        printNodeFormatExplain(gpa, fs, f, module);
                        continue;
                    },
                    .jsx_runtime_import => {
                        const importer_path = program.files.items[ir.importer].path;
                        const msg = if (ir.package_id.len != 0)
                            std.fmt.allocPrint(
                                gpa,
                                "  Imported via {s} from file '{s}' with packageId '{s}' to import 'jsx' and 'jsxs' factory functions",
                                .{ ir.specifier_text, importer_path, ir.package_id },
                            ) catch return
                        else
                            std.fmt.allocPrint(
                                gpa,
                                "  Imported via {s} from file '{s}' to import 'jsx' and 'jsxs' factory functions",
                                .{ ir.specifier_text, importer_path },
                            ) catch return;
                        defer gpa.free(msg);
                        printStdout("{s}\n", .{msg});
                        printProjectReferenceOutputExplain(f);
                        printRedirectExplain(program, f);
                        printNodeFormatExplain(gpa, fs, f, module);
                        continue;
                    },
                    .reference_file => {
                        const referencing_path = program.files.items[ir.importer].path;
                        const msg = std.fmt.allocPrint(
                            gpa,
                            "  Referenced via '{s}' from file '{s}'",
                            .{ ir.specifier_text, referencing_path },
                        ) catch return;
                        defer gpa.free(msg);
                        printStdout("{s}\n", .{msg});
                        printProjectReferenceOutputExplain(f);
                        printRedirectExplain(program, f);
                        printNodeFormatExplain(gpa, fs, f, module);
                        continue;
                    },
                    .type_reference => {
                        const referencing_path = program.files.items[ir.importer].path;
                        const msg = if (ir.package_id.len != 0)
                            std.fmt.allocPrint(
                                gpa,
                                "  Type library referenced via '{s}' from file '{s}' with packageId '{s}'",
                                .{ ir.specifier_text, referencing_path, ir.package_id },
                            ) catch return
                        else
                            std.fmt.allocPrint(
                                gpa,
                                "  Type library referenced via '{s}' from file '{s}'",
                                .{ ir.specifier_text, referencing_path },
                            ) catch return;
                        defer gpa.free(msg);
                        printStdout("{s}\n", .{msg});
                        printProjectReferenceOutputExplain(f);
                        printRedirectExplain(program, f);
                        printNodeFormatExplain(gpa, fs, f, module);
                        continue;
                    },
                    .lib_reference => {
                        const referencing_path = program.files.items[ir.importer].path;
                        const msg = std.fmt.allocPrint(
                            gpa,
                            "  Library referenced via '{s}' from file '{s}'",
                            .{ ir.specifier_text, referencing_path },
                        ) catch return;
                        defer gpa.free(msg);
                        printStdout("{s}\n", .{msg});
                        printProjectReferenceOutputExplain(f);
                        printRedirectExplain(program, f);
                        printNodeFormatExplain(gpa, fs, f, module);
                        continue;
                    },
                    .compiler_type_reference => {
                        const msg = if (ir.package_id.len != 0)
                            std.fmt.allocPrint(
                                gpa,
                                "  Entry point of type library '{s}' specified in compilerOptions with packageId '{s}'",
                                .{ ir.specifier_text, ir.package_id },
                            ) catch return
                        else
                            std.fmt.allocPrint(
                                gpa,
                                "  Entry point of type library '{s}' specified in compilerOptions",
                                .{ir.specifier_text},
                            ) catch return;
                        defer gpa.free(msg);
                        printStdout("{s}\n", .{msg});
                        printProjectReferenceOutputExplain(f);
                        printRedirectExplain(program, f);
                        printNodeFormatExplain(gpa, fs, f, module);
                        continue;
                    },
                    .implicit_type_reference => {
                        const msg = if (ir.package_id.len != 0)
                            std.fmt.allocPrint(
                                gpa,
                                "  Entry point for implicit type library '{s}' with packageId '{s}'",
                                .{ ir.specifier_text, ir.package_id },
                            ) catch return
                        else
                            std.fmt.allocPrint(
                                gpa,
                                "  Entry point for implicit type library '{s}'",
                                .{ir.specifier_text},
                            ) catch return;
                        defer gpa.free(msg);
                        printStdout("{s}\n", .{msg});
                        printProjectReferenceOutputExplain(f);
                        printRedirectExplain(program, f);
                        printNodeFormatExplain(gpa, fs, f, module);
                        continue;
                    },
                    .compiler_lib_reference => {
                        const msg = std.fmt.allocPrint(
                            gpa,
                            "  Library '{s}' specified in compilerOptions",
                            .{ir.specifier_text},
                        ) catch return;
                        defer gpa.free(msg);
                        printStdout("{s}\n", .{msg});
                        printProjectReferenceOutputExplain(f);
                        printRedirectExplain(program, f);
                        printNodeFormatExplain(gpa, fs, f, module);
                        continue;
                    },
                    .default_lib_reference => {
                        const msg = if (ir.specifier_text.len != 0)
                            std.fmt.allocPrint(
                                gpa,
                                "  Default library for target '{s}'",
                                .{ir.specifier_text},
                            ) catch return
                        else
                            std.fmt.allocPrint(
                                gpa,
                                "  Default library",
                                .{},
                            ) catch return;
                        defer gpa.free(msg);
                        printStdout("{s}\n", .{msg});
                        printProjectReferenceOutputExplain(f);
                        printRedirectExplain(program, f);
                        printNodeFormatExplain(gpa, fs, f, module);
                        continue;
                    },
                    .root => {},
                }
            }
            // No recorded edge (partial program / resolution gap): fall
            // back to the generic root-specified reason rather than
            // fabricating a puller.
            printStdout("  {s}\n", .{(ts_diagnostics.codes.lookup(code_root_specified) orelse unreachable).message});
            printProjectReferenceOutputExplain(f);
            printRedirectExplain(program, f);
            printNodeFormatExplain(gpa, fs, f, module);
            continue;
        }
        if (root.code == code_include_pattern) {
            // "Matched by include pattern '{0}' in '{1}'."
            const cfg_base = std.fs.path.basename(root.config_path);
            const spec = matchingRootIncludeSpec(root, f.path);
            const msg = std.fmt.allocPrint(gpa, "  Matched by include pattern '{s}' in '{s}'", .{ spec, cfg_base }) catch return;
            defer gpa.free(msg);
            printStdout("{s}\n", .{msg});
        } else {
            const code = switch (root.code) {
                code_files_list => code_files_list,
                code_default_include => code_default_include,
                else => code_root_specified,
            };
            printStdout("  {s}\n", .{(ts_diagnostics.codes.lookup(code) orelse unreachable).message});
        }
        printNodeFormatExplain(gpa, fs, f, module);
    }
}

/// True when `needle` string-equals any entry in `haystack`.
fn pathInList(haystack: []const []const u8, needle: []const u8) bool {
    for (haystack) |p| {
        if (std.mem.eql(u8, p, needle)) return true;
    }
    return false;
}

fn explainFileDisplayPath(file: *const ts_program.File) []const u8 {
    if (file.include_reason) |ir| {
        if (ir.project_reference_output.len != 0) return ir.project_reference_output;
    }
    return file.path;
}

fn printProjectReferenceOutputExplain(file: *const ts_program.File) void {
    const ir = file.include_reason orelse return;
    if (ir.project_reference_output.len == 0) return;
    printStdout("  File is output of project reference source '{s}'\n", .{file.path});
}

fn printRedirectExplain(program: *const ts_program.Program, file: *const ts_program.File) void {
    const target_id = file.redirect_target orelse return;
    const target = program.fileById(target_id);
    printStdout("  File redirects to file '{s}'\n", .{target.path});
}

const CompositeProjectFileListSummary = struct {
    error_count: usize = 0,
    files_with_errors: usize = 0,
    first_error_file: []const u8 = "",
    first_error_line: usize = 0,
    first_error_col: usize = 0,
};

fn sourceFileMayBeEmittedByProject(f: *const ts_program.File) bool {
    return !f.is_declaration;
}

fn compositeProjectFileListMessage(
    gpa: std.mem.Allocator,
    file_path: []const u8,
    config_path: []const u8,
) ![]u8 {
    return std.fmt.allocPrint(
        gpa,
        "File '{s}' is not listed within the file list of project '{s}'. Projects must list all files or use an 'include' pattern.",
        .{ file_path, config_path },
    );
}

fn compositeDiagnosticAnchor(
    program: *const ts_program.Program,
    f: *const ts_program.File,
) struct { file: *const ts_program.File, pos: u32, span_len: u32 } {
    if (f.include_reason) |reason| {
        if (reason.importer < program.files.items.len) {
            const importer = program.fileById(reason.importer);
            return .{ .file = importer, .pos = reason.specifier_pos, .span_len = reason.specifierSpanLen() };
        }
    }
    return .{ .file = f, .pos = 0, .span_len = 0 };
}

fn compositeDiagnosticRelated(
    program: *const ts_program.Program,
    f: *const ts_program.File,
    out: *[1]ts_diagnostics.Related,
) []const ts_diagnostics.Related {
    const reason = f.include_reason orelse return &.{};
    if (reason.importer >= program.files.items.len) return &.{};
    const code = reason.relatedDiagnosticCode() orelse return &.{};
    const message = reason.relatedDiagnosticMessage() orelse return &.{};
    const importer = program.fileById(reason.importer);
    const lc = ts_diagnostics.positionToLineCol(importer.source, reason.specifier_pos);
    out[0] = .{
        .file = importer.path,
        .line = lc.line,
        .col = lc.col,
        .code = code,
        .code_prefix = .TS,
        .message = message,
    };
    return out[0..1];
}

fn printCompositeProjectFileListDiagnostics(
    gpa: std.mem.Allocator,
    program: *const ts_program.Program,
    roots: []const []const u8,
    config_path: []const u8,
    use_pretty: bool,
    use_color: bool,
) CompositeProjectFileListSummary {
    var summary: CompositeProjectFileListSummary = .{};
    var seen_files: std.StringHashMapUnmanaged(void) = .empty;
    defer seen_files.deinit(gpa);
    for (program.files.items) |f| {
        if (!sourceFileMayBeEmittedByProject(f)) continue;
        if (pathInList(roots, f.path)) continue;
        const anchor = compositeDiagnosticAnchor(program, f);
        const lc = ts_diagnostics.positionToLineCol(anchor.file.source, anchor.pos);
        const message = compositeProjectFileListMessage(gpa, f.path, config_path) catch continue;
        defer gpa.free(message);
        var related_buf: [1]ts_diagnostics.Related = undefined;
        const related = compositeDiagnosticRelated(program, f, &related_buf);
        const diag: ts_diagnostics.Diagnostic = .{
            .file = anchor.file.path,
            .line = lc.line,
            .col = lc.col,
            .code = 6307,
            .code_prefix = .TS,
            .severity = .err,
            .message = message,
            .span_len = anchor.span_len,
            .related = related,
        };
        const formatted = if (use_pretty)
            ts_diagnostics.formatPretty(gpa, diag, anchor.file.source, use_color) catch continue
        else
            ts_diagnostics.formatDefault(gpa, diag) catch continue;
        defer gpa.free(formatted);
        printStdout("{s}\n", .{formatted});

        summary.error_count += 1;
        if (!seen_files.contains(anchor.file.path)) {
            seen_files.put(gpa, anchor.file.path, {}) catch {};
            summary.files_with_errors += 1;
        }
        if (summary.first_error_file.len == 0) {
            summary.first_error_file = anchor.file.path;
            summary.first_error_line = lc.line;
            summary.first_error_col = lc.col;
        }
    }
    return summary;
}

/// Modification time of `path` in nanoseconds, or null if it can't be
/// stat'd (missing/unreadable). Used by `tsc --build`'s up-to-date check.
fn fileMtimeNanos(path: []const u8) ?i128 {
    var threaded = std.Io.Threaded.init(std.heap.page_allocator, .{});
    defer threaded.deinit();
    const io = threaded.io();
    const cwd = std.Io.Dir.cwd();
    var file = cwd.openFile(io, path, .{}) catch return null;
    defer file.close(io);
    const st = file.stat(io) catch return null;
    return @as(i128, st.mtime.nanoseconds);
}

/// Write `bytes` to `path`, or emit TS5033 and exit on failure. Mirrors
/// tsc's emitter, which reports `Could_not_write_file` for any output
/// write error.
fn writeOrDie(gpa: std.mem.Allocator, path: []const u8, bytes: []const u8) void {
    RealFs.write(gpa, path, bytes) catch |err| {
        const msg = ts_cli.couldNotWriteFileDiagnostic(gpa, path, @errorName(err)) catch std.process.exit(1);
        defer gpa.free(msg);
        printStdout("{s}\n", .{msg});
        std.process.exit(1);
    };
}

/// A TypeScript project served by `home lsp`, set up the way `home tsc`
/// compiles: the real filesystem, a `tsconfig.json` (compiler and resolver
/// options), and the cross-file resolver adapter,
/// so editor diagnostics match the command line. The editor's open
/// documents join the program as they are opened, along with their
/// imports. Heap-allocated because the program, service and compile
/// options hold pointers into it.
pub const LspProject = struct {
    gpa: std.mem.Allocator,
    config_arena: std.heap.ArenaAllocator,
    /// Backs `config`'s strings, which alias it.
    config_source: []const u8,
    config_source_owned: bool,
    config: ?tsconfig_mod.TsConfig,
    fs: ResolverRealFs,
    resolver: ts_resolver.Resolver,
    program: ts_program.Program,
    adapter: CheckerResolverAdapter,
    service: ts_lsp.Service,

    /// `config_path` is the tsconfig to load (`home lsp` passes the working
    /// directory's `tsconfig.json`); null or a missing file means defaults.
    pub fn create(gpa: std.mem.Allocator, config_path: ?[]const u8) !*LspProject {
        const self = try gpa.create(LspProject);
        errdefer gpa.destroy(self);
        self.gpa = gpa;
        self.config_arena = std.heap.ArenaAllocator.init(gpa);
        self.config_source = &.{};
        self.config_source_owned = false;
        self.config = null;
        if (config_path) |path| {
            if (RealFs.read(gpa, path)) |source| {
                self.config_source = source;
                self.config_source_owned = true;
                self.config = tsconfig_mod.parseString(gpa, self.config_arena.allocator(), self.config_source) catch null;
                if (self.config) |*c| c.file_path = path;
            } else |_| {}
        }
        self.fs = ResolverRealFs.init(gpa);
        const resolver_config: ts_resolver.Config = if (self.config) |c|
            resolverConfigFromConfig(self.config_arena.allocator(), c, null)
        else
            .{};
        self.resolver = ts_resolver.Resolver.init(gpa, self.fs.fs(), resolver_config);
        self.program = ts_program.Program.init(gpa, &self.resolver);
        self.adapter = CheckerResolverAdapter.init(gpa, &self.resolver);
        self.service = ts_lsp.Service.init(gpa, &self.program);
        var compile_options: ts_driver.CompileOptions = if (self.config) |*c| ts_driver.optionsFromConfig(c) else .{};
        self.adapter.setProgramSources(&self.program, compile_options);
        compile_options.external_resolver = .{ .ptr = &self.adapter, .vtable = &CheckerResolverAdapter.vtable };
        self.service.compile_options = compile_options;
        return self;
    }

    pub fn destroy(self: *LspProject) void {
        const gpa = self.gpa;
        self.service.deinit();
        self.adapter.deinit();
        self.program.deinit();
        self.resolver.deinit();
        self.fs.deinit();
        if (self.config_source_owned) gpa.free(self.config_source);
        self.config_arena.deinit();
        gpa.destroy(self);
    }

    /// Handle one JSON-RPC message and return the response or notification
    /// body to send back (empty when there is none). Caller owns it.
    pub fn handle(self: *LspProject, message: []const u8) ![]u8 {
        if (editsDocuments(message)) {
            // The adapter caches imported modules as read from disk; start
            // fresh on each edit so saved changes to dependencies show up.
            self.adapter.deinit();
            self.adapter = CheckerResolverAdapter.init(self.gpa, &self.resolver);
            self.adapter.setProgramSources(&self.program, self.service.compile_options);
        }
        return ts_lsp_server.dispatchRequest(&self.service, self.gpa, message);
    }

    fn editsDocuments(message: []const u8) bool {
        const methods = [_][]const u8{
            "\"textDocument/didOpen\"",
            "\"textDocument/didChange\"",
            "\"textDocument/didSave\"",
        };
        for (methods) |method| {
            if (std.mem.indexOf(u8, message, method) != null) return true;
        }
        return false;
    }
};

const ResolverRealFs = struct {
    threaded: std.Io.Threaded,

    fn init(gpa: std.mem.Allocator) ResolverRealFs {
        return .{ .threaded = std.Io.Threaded.init(gpa, .{}) };
    }

    fn deinit(self: *ResolverRealFs) void {
        self.threaded.deinit();
    }

    pub fn fs(self: *ResolverRealFs) ts_resolver.FileSystem {
        return .{ .ptr = self, .vtable = &vt };
    }

    const vt: ts_resolver.FileSystem.VTable = .{
        .fileExists = fileExists,
        .directoryExists = directoryExists,
        .readFile = readFile,
        .readDir = readDir,
        .realpath = realpath,
    };

    fn fileExists(ptr: *anyopaque, path: []const u8) bool {
        const self: *ResolverRealFs = @ptrCast(@alignCast(ptr));
        const io = self.threaded.io();
        const cwd = std.Io.Dir.cwd();
        var file = cwd.openFile(io, path, .{}) catch return false;
        defer file.close(io);
        return true;
    }

    fn directoryExists(ptr: *anyopaque, path: []const u8) bool {
        const self: *ResolverRealFs = @ptrCast(@alignCast(ptr));
        const io = self.threaded.io();
        const cwd = std.Io.Dir.cwd();
        var dir = cwd.openDir(io, path, .{}) catch return false;
        defer dir.close(io);
        return true;
    }

    fn readFile(ptr: *anyopaque, gpa: std.mem.Allocator, path: []const u8) anyerror![]u8 {
        const self: *ResolverRealFs = @ptrCast(@alignCast(ptr));
        const bytes = try RealFs.readWithIo(gpa, self.threaded.io(), path);
        return @constCast(bytes);
    }

    fn readDir(ptr: *anyopaque, gpa: std.mem.Allocator, path: []const u8) anyerror![]ts_resolver.FileSystem.DirEntry {
        const self: *ResolverRealFs = @ptrCast(@alignCast(ptr));
        const io = self.threaded.io();
        const cwd = std.Io.Dir.cwd();
        var dir = try cwd.openDir(io, path, .{ .iterate = true });
        defer dir.close(io);

        var out: std.ArrayListUnmanaged(ts_resolver.FileSystem.DirEntry) = .empty;
        errdefer {
            for (out.items) |entry| gpa.free(entry.name);
            out.deinit(gpa);
        }
        var iter = dir.iterate();
        while (try iter.next(io)) |entry| {
            const name = try gpa.dupe(u8, entry.name);
            out.append(gpa, .{ .name = name, .is_dir = entry.kind == .directory }) catch |err| {
                gpa.free(name);
                return err;
            };
        }
        return out.toOwnedSlice(gpa);
    }

    fn realpath(ptr: *anyopaque, gpa: std.mem.Allocator, path: []const u8) anyerror![]u8 {
        const self: *ResolverRealFs = @ptrCast(@alignCast(ptr));
        const io = self.threaded.io();
        const cwd = std.Io.Dir.cwd();
        return cwd.realPathFileAlloc(io, path, gpa);
    }
};

/// True if `path` names an existing regular file. Used by the explicit
/// `--project` existence checks (TS5058 / TS5081).
fn fileExistsOnDisk(gpa: std.mem.Allocator, path: []const u8) bool {
    var threaded = std.Io.Threaded.init(gpa, .{});
    defer threaded.deinit();
    const io = threaded.io();
    const cwd = std.Io.Dir.cwd();
    var file = cwd.openFile(io, path, .{}) catch return false;
    file.close(io);
    return true;
}

/// True if `path` names an existing directory.
fn directoryExistsOnDisk(gpa: std.mem.Allocator, path: []const u8) bool {
    var threaded = std.Io.Threaded.init(gpa, .{});
    defer threaded.deinit();
    const io = threaded.io();
    const cwd = std.Io.Dir.cwd();
    var dir = cwd.openDir(io, path, .{}) catch return false;
    dir.close(io);
    return true;
}

const ResolverMutex = struct {
    state: std.atomic.Value(u32) = .init(0),

    fn lock(self: *ResolverMutex) void {
        while (true) {
            if (self.state.cmpxchgWeak(0, 1, .acquire, .monotonic) == null) return;
            while (self.state.load(.monotonic) != 0) std.atomic.spinLoopHint();
        }
    }

    fn unlock(self: *ResolverMutex) void {
        self.state.store(0, .release);
    }
};

const ModuleExportCacheKey = struct {
    path: []const u8,
    name: []const u8,
    mode: enum(u8) { normal, import, require },
};

const ModuleExportCacheContext = struct {
    pub fn hash(_: ModuleExportCacheContext, key: ModuleExportCacheKey) u64 {
        var hasher = std.hash.Wyhash.init(0);
        hasher.update(&.{@backingInt(key.mode)});
        hasher.update(key.path);
        hasher.update(&.{0});
        hasher.update(key.name);
        return hasher.final();
    }

    pub fn eql(_: ModuleExportCacheContext, a: ModuleExportCacheKey, b: ModuleExportCacheKey) bool {
        return a.mode == b.mode and
            std.mem.eql(u8, a.path, b.path) and
            std.mem.eql(u8, a.name, b.name);
    }
};

const ModuleExportCache = std.HashMapUnmanaged(
    ModuleExportCacheKey,
    ts_driver.ExternalResolver.ModuleExport,
    ModuleExportCacheContext,
    80,
);

const CheckerResolverAdapter = struct {
    resolver: *ts_resolver.Resolver,
    /// Borrow the actual source-admission inventory, which is immutable
    /// while the Program's parallel checker workers are running.
    admitted_program: ?*const ts_program.Program = null,
    js_sources_enabled: bool = false,
    resolver_mutex: ResolverMutex = .{},
    cache_mutex: ResolverMutex = .{},
    cache_arena: std.heap.ArenaAllocator,
    module_export_cache: ModuleExportCache = .empty,
    module_compilation_cache: std.StringHashMapUnmanaged(*ts_driver.Compilation) = .empty,
    module_export_names_cache: std.StringHashMapUnmanaged([]const []const u8) = .empty,
    // Immutable source views for declaration-origin queries. Guarded by
    // resolver_mutex; shared across names so wide barrels are parsed once.
    export_origin_query: ts_program.export_origins.Query,

    fn init(gpa: std.mem.Allocator, resolver: *ts_resolver.Resolver) CheckerResolverAdapter {
        return .{
            .resolver = resolver,
            .cache_arena = std.heap.ArenaAllocator.init(gpa),
            .export_origin_query = ts_program.export_origins.Query.init(gpa, resolver),
        };
    }

    fn setProgramSources(self: *CheckerResolverAdapter, program: *const ts_program.Program, options: ts_driver.CompileOptions) void {
        self.admitted_program = program;
        self.js_sources_enabled = options.allow_js or options.check_js;
    }

    fn admittedJavaScript(self: *CheckerResolverAdapter, path: []const u8) bool {
        if (!self.js_sources_enabled) return false;
        if (!(std.mem.endsWith(u8, path, ".js") or std.mem.endsWith(u8, path, ".jsx") or
            std.mem.endsWith(u8, path, ".mjs") or std.mem.endsWith(u8, path, ".cjs"))) return false;
        const program = self.admitted_program orelse return false;
        return program.lookupPath(path) != null;
    }

    fn deinit(self: *CheckerResolverAdapter) void {
        self.export_origin_query.deinit();
        var compilations = self.module_compilation_cache.valueIterator();
        while (compilations.next()) |compilation| {
            const source = compilation.*.source;
            compilation.*.deinit();
            self.resolver.gpa.destroy(compilation.*);
            self.resolver.gpa.free(source);
        }
        self.module_compilation_cache.deinit(self.resolver.gpa);
        var export_names = self.module_export_names_cache.valueIterator();
        while (export_names.next()) |names| {
            for (names.*) |name| self.resolver.gpa.free(name);
            self.resolver.gpa.free(names.*);
        }
        self.module_export_names_cache.deinit(self.resolver.gpa);
        self.module_export_cache.deinit(self.resolver.gpa);
        self.cache_arena.deinit();
    }

    fn moduleCompilation(
        self: *CheckerResolverAdapter,
        path: []const u8,
    ) ?*ts_driver.Compilation {
        if (self.admitted_program) |program| {
            if (program.lookupPath(path)) |id| {
                if (program.fileById(id).compilation) |compilation| return compilation;
            }
        }
        self.cache_mutex.lock();
        if (self.module_compilation_cache.get(path)) |cached| {
            self.cache_mutex.unlock();
            return cached;
        }
        self.cache_mutex.unlock();

        const source = self.resolver.fs.readFile(self.resolver.gpa, path) catch return null;
        const compilation = ts_program.compileModuleForExportFacts(self.resolver.gpa, path, source) catch {
            self.resolver.gpa.free(source);
            return null;
        };

        self.cache_mutex.lock();
        defer self.cache_mutex.unlock();
        if (self.module_compilation_cache.get(path)) |cached| {
            compilation.deinit();
            self.resolver.gpa.destroy(compilation);
            self.resolver.gpa.free(source);
            return cached;
        }
        const stored_path = self.cache_arena.allocator().dupe(u8, path) catch {
            compilation.deinit();
            self.resolver.gpa.destroy(compilation);
            self.resolver.gpa.free(source);
            return null;
        };
        self.module_compilation_cache.put(self.resolver.gpa, stored_path, compilation) catch {
            compilation.deinit();
            self.resolver.gpa.destroy(compilation);
            self.resolver.gpa.free(source);
            return null;
        };
        return compilation;
    }

    fn cachedModuleExport(
        self: *CheckerResolverAdapter,
        key: ModuleExportCacheKey,
    ) ?ts_driver.ExternalResolver.ModuleExport {
        self.cache_mutex.lock();
        defer self.cache_mutex.unlock();
        return self.module_export_cache.get(key);
    }

    fn cacheModuleExport(
        self: *CheckerResolverAdapter,
        key: ModuleExportCacheKey,
        result: ts_driver.ExternalResolver.ModuleExport,
    ) void {
        self.cache_mutex.lock();
        defer self.cache_mutex.unlock();
        if (self.module_export_cache.contains(key)) return;
        const arena = self.cache_arena.allocator();
        const stored_path = arena.dupe(u8, key.path) catch return;
        const stored_name = arena.dupe(u8, key.name) catch return;
        self.module_export_cache.put(self.resolver.gpa, .{
            .path = stored_path,
            .name = stored_name,
            .mode = key.mode,
        }, result) catch {};
    }

    fn resolveModule(
        self: *CheckerResolverAdapter,
        specifier: []const u8,
        containing_file: []const u8,
    ) ?ts_resolver.Resolution {
        self.resolver_mutex.lock();
        defer self.resolver_mutex.unlock();
        return self.resolver.resolve(specifier, containing_file) catch null;
    }

    fn resolveTypeReference(
        self: *CheckerResolverAdapter,
        specifier: []const u8,
        containing_file: []const u8,
        mode: ts_resolver.TypeReferenceResolutionMode,
    ) ?ts_resolver.Resolution {
        self.resolver_mutex.lock();
        defer self.resolver_mutex.unlock();
        return self.resolver.resolveTypeReferenceDirectiveWithMode(specifier, containing_file, mode) catch null;
    }

    pub const vtable = ts_driver.ExternalResolver.VTable{
        .resolve = resolveImpl,
        .moduleExport = moduleExportImpl,
        .moduleExportWithMode = moduleExportWithModeImpl,
        .moduleExportNames = moduleExportNamesImpl,
        .sameModuleExport = sameModuleExportImpl,
        .commonJsExportPrivateName = commonJsExportPrivateNameImpl,
        .ambiguousProjectRoot = ambiguousProjectRootImpl,
    };

    fn sameModuleExportImpl(
        self_ptr: *anyopaque,
        left_specifier: []const u8,
        right_specifier: []const u8,
        containing_file: []const u8,
        name: []const u8,
    ) ?bool {
        const self: *CheckerResolverAdapter = @ptrCast(@alignCast(self_ptr));
        const left = self.resolveModule(left_specifier, containing_file) orelse return null;
        const right = self.resolveModule(right_specifier, containing_file) orelse return null;
        const left_compilation = self.moduleCompilation(left.path) orelse return null;
        const right_compilation = self.moduleCompilation(right.path) orelse return null;
        self.resolver_mutex.lock();
        defer self.resolver_mutex.unlock();
        const query = &self.export_origin_query;
        if (!query.files.contains(left.path)) query.borrow(left.path, left_compilation) catch return null;
        if (!query.files.contains(right.path)) query.borrow(right.path, right_compilation) catch return null;
        const a = query.resolve(left.path, name) catch return null;
        const b = query.resolve(right.path, name) catch return null;
        return a.sameDeclaration(b);
    }

    fn moduleExportNamesImpl(
        self_ptr: *anyopaque,
        specifier: []const u8,
        containing_file: []const u8,
    ) ?[]const []const u8 {
        const self: *CheckerResolverAdapter = @ptrCast(@alignCast(self_ptr));
        const resolved = self.resolveModule(specifier, containing_file) orelse return null;

        self.cache_mutex.lock();
        if (self.module_export_names_cache.get(resolved.path)) |cached| {
            self.cache_mutex.unlock();
            return cached;
        }
        self.cache_mutex.unlock();

        const names = blk: {
            self.resolver_mutex.lock();
            defer self.resolver_mutex.unlock();
            break :blk ts_program.moduleExportNamesFromQuery(
                self.resolver.gpa,
                self.resolver,
                &self.export_origin_query,
                resolved.path,
            ) catch return null;
        };

        self.cache_mutex.lock();
        defer self.cache_mutex.unlock();
        if (self.module_export_names_cache.get(resolved.path)) |cached| {
            for (names) |name| self.resolver.gpa.free(name);
            self.resolver.gpa.free(names);
            return cached;
        }
        const stored_path = self.cache_arena.allocator().dupe(u8, resolved.path) catch {
            for (names) |name| self.resolver.gpa.free(name);
            self.resolver.gpa.free(names);
            return null;
        };
        self.module_export_names_cache.put(self.resolver.gpa, stored_path, names) catch {
            for (names) |name| self.resolver.gpa.free(name);
            self.resolver.gpa.free(names);
            return null;
        };
        return names;
    }

    /// TS2209/TS2210 — read the project-root-ambiguous record the resolver
    /// stashed during the most recent (failed) resolve, so the production
    /// CLI reports it too (not just the conformance harness).
    fn ambiguousProjectRootImpl(self_ptr: *anyopaque) ?ts_driver.ExternalResolver.AmbiguousProjectRoot {
        const self: *CheckerResolverAdapter = @ptrCast(@alignCast(self_ptr));
        self.resolver_mutex.lock();
        defer self.resolver_mutex.unlock();
        const amb = self.resolver.ambiguous_root orelse return null;
        return .{ .entry = amb.entry, .file = amb.file, .is_imports = amb.is_imports };
    }

    fn resolveImpl(
        self_ptr: *anyopaque,
        specifier: []const u8,
        containing_file: []const u8,
    ) ?ts_driver.ExternalResolver.Resolution {
        const self: *CheckerResolverAdapter = @ptrCast(@alignCast(self_ptr));
        const r = self.resolveModule(specifier, containing_file) orelse return null;
        return .{
            .path = r.path,
            // The checker API's bit means typed resolution, including
            // admitted JS source inference, not only declaration files.
            .is_declaration = r.is_declaration or self.admittedJavaScript(r.path),
            .alternate_result = r.alternate_result,
            .project_reference_output = r.project_reference_output,
        };
    }

    /// Cross-module export query, backing the checker's
    /// `crossModulePrivateNameInfo` (TS4023/TS4024/TS4026/TS4030/TS4034
    /// "… from external/private module …" privacy diagnostics). Without
    /// this the production CLI left those codes silent on real `home-tsc`
    /// invocations even though the checker emission sites exist — only
    /// the conformance harness wired it. Resolve the specifier, read +
    /// bind the resolved module, and report whether `name` is a top-level
    /// type-space export (`exported_type`) or reachable only as a nested
    /// member of an exported namespace (`cannot_be_named`). Mirrors the
    /// conformance harness's `CheckerResolverAdapter.moduleExportImpl`.
    fn moduleExportImpl(
        self_ptr: *anyopaque,
        specifier: []const u8,
        containing_file: []const u8,
        name: []const u8,
    ) ?ts_driver.ExternalResolver.ModuleExport {
        const self: *CheckerResolverAdapter = @ptrCast(@alignCast(self_ptr));
        const r = self.resolveModule(specifier, containing_file) orelse return null;
        const cache_key: ModuleExportCacheKey = .{ .path = r.path, .name = name, .mode = .normal };
        if (self.cachedModuleExport(cache_key)) |cached| return cached;
        const compilation = self.moduleCompilation(r.path) orelse return null;
        const export_assignment_class_name = if (name.len == 0)
            ts_program.moduleCommonJsExportAssignmentClassNameFromCompilation(compilation)
        else
            null;
        const facts = blk: {
            self.resolver_mutex.lock();
            defer self.resolver_mutex.unlock();
            break :blk ts_program.moduleExportFactsFromCompilationWithQuery(
                self.resolver.gpa,
                self.resolver,
                r.path,
                compilation,
                name,
                &self.export_origin_query,
            );
        };
        const local_facts = ts_program.moduleLocalImportFactsFromCompilation(compilation, name);
        const exported = facts.exported_type;
        const cannot_be_named = facts.cannot_be_named;
        const type_only_pos = facts.type_only_pos;
        const result: ts_driver.ExternalResolver.ModuleExport = blk: {
            self.resolver_mutex.lock();
            defer self.resolver_mutex.unlock();
            // The resolver's arena outlives every checker call.
            const arena = self.resolver.arena.allocator();
            const module_name = ts_program.renderModuleDisplayName(arena, r.path) catch return null;
            const export_path = if (type_only_pos != null) (arena.dupe(u8, if (facts.type_only_path.len != 0) facts.type_only_path else r.path) catch return null) else "";
            const origins = self.boundExportOrigins(r.path, compilation, name);
            break :blk .{
                .module_name = module_name,
                .exported_type = exported,
                .exported_value = facts.exported_value,
                .namespace_meaning = facts.namespace_meaning,
                .declares_local = local_facts.declares_local,
                .local_exported_as = if (local_facts.exported_as.len != 0)
                    arena.dupe(u8, local_facts.exported_as) catch return null
                else
                    "",
                .namespace_module_path = namespaceExportOwner(origins) orelse "",
                .runtime_value = runtimeValueFromExportFacts(origins, facts.exported_value),
                .exported_value_readonly = facts.exported_value_readonly,
                .ambient_const_enum = facts.ambient_const_enum,
                .cannot_be_named = cannot_be_named,
                .type_only_export = type_only_pos != null,
                .type_only_import = facts.type_only_import,
                .export_path = export_path,
                .export_pos = type_only_pos orelse 0,
                .export_assignment_type_only = facts.export_assignment_type_only,
                .export_assignment_class_name = if (export_assignment_class_name) |class_name|
                    arena.dupe(u8, class_name) catch return null
                else
                    "",
                .default_export_member_readonly = facts.default_export_member_readonly,
                .generic_function = facts.generic_function,
                .call_only_function = facts.call_only_function,
                .module_is_external = facts.module_is_external,
                .default_import_info = facts.default_import_info,
            };
        };
        self.cacheModuleExport(cache_key, result);
        return result;
    }

    fn moduleExportWithModeImpl(
        self_ptr: *anyopaque,
        specifier: []const u8,
        containing_file: []const u8,
        name: []const u8,
        resolution_mode: []const u8,
    ) ?ts_driver.ExternalResolver.ModuleExport {
        const self: *CheckerResolverAdapter = @ptrCast(@alignCast(self_ptr));
        const mode: ts_resolver.TypeReferenceResolutionMode = if (std.mem.eql(u8, resolution_mode, "require"))
            .require
        else
            .import;
        const resolved = self.resolveTypeReference(specifier, containing_file, mode) orelse return null;
        const cache_key: ModuleExportCacheKey = .{
            .path = resolved.path,
            .name = name,
            .mode = if (mode == .require) .require else .import,
        };
        if (self.cachedModuleExport(cache_key)) |cached| return cached;
        const compilation = self.moduleCompilation(resolved.path) orelse return null;
        const facts = blk: {
            self.resolver_mutex.lock();
            defer self.resolver_mutex.unlock();
            break :blk ts_program.moduleExportFactsFromCompilationWithQuery(
                self.resolver.gpa,
                self.resolver,
                resolved.path,
                compilation,
                name,
                &self.export_origin_query,
            );
        };
        const local_facts = ts_program.moduleLocalImportFactsFromCompilation(compilation, name);
        const type_only_pos = facts.type_only_pos;
        const result: ts_driver.ExternalResolver.ModuleExport = blk: {
            self.resolver_mutex.lock();
            defer self.resolver_mutex.unlock();
            const arena = self.resolver.arena.allocator();
            const origins = self.boundExportOrigins(resolved.path, compilation, name);
            break :blk .{
                .module_name = ts_program.renderModuleDisplayName(arena, resolved.path) catch return null,
                .exported_type = facts.exported_type,
                .exported_value = facts.exported_value,
                .namespace_meaning = facts.namespace_meaning,
                .declares_local = local_facts.declares_local,
                .local_exported_as = if (local_facts.exported_as.len != 0)
                    arena.dupe(u8, local_facts.exported_as) catch return null
                else
                    "",
                .namespace_module_path = namespaceExportOwner(origins) orelse "",
                .runtime_value = runtimeValueFromExportFacts(origins, facts.exported_value),
                .ambient_const_enum = facts.ambient_const_enum,
                .type_only_export = type_only_pos != null,
                .type_only_import = facts.type_only_import,
                .export_path = if (type_only_pos != null) (arena.dupe(u8, if (facts.type_only_path.len != 0) facts.type_only_path else resolved.path) catch return null) else "",
                .export_pos = type_only_pos orelse 0,
                .generic_function = facts.generic_function,
                .call_only_function = facts.call_only_function,
                .module_is_external = facts.module_is_external,
                .default_import_info = facts.default_import_info,
            };
        };
        self.cacheModuleExport(cache_key, result);
        return result;
    }

    /// Called while holding resolver_mutex. Origins distinguish a module
    /// namespace alias from an ordinary same-named namespace declaration.
    fn boundExportOrigins(self: *CheckerResolverAdapter, path: []const u8, compilation: *ts_driver.Compilation, name: []const u8) ?ts_program.export_origins.Origins {
        // The bound ESM query does not model CommonJS assignment exports.
        // Leave those shapes unknown rather than claiming an empty module.
        if (std.mem.endsWith(u8, path, ".js") or std.mem.endsWith(u8, path, ".jsx") or
            std.mem.endsWith(u8, path, ".cjs") or std.mem.endsWith(u8, path, ".mjs")) return null;
        const query = &self.export_origin_query;
        if (!query.files.contains(path)) query.borrow(path, compilation) catch return null;
        const origins = query.resolve(path, name) catch return null;
        if (!origins.complete or origins.ambiguous) return null;
        return origins;
    }

    fn namespaceExportOwner(origins: ?ts_program.export_origins.Origins) ?[]const u8 {
        const origin = (origins orelse return null).value orelse return null;
        return if (origin.kind == .namespace) origin.path else null;
    }

    fn runtimeValueFromExportFacts(origins: ?ts_program.export_origins.Origins, exported_value: bool) ?bool {
        if (origins) |known| return known.value != null;
        return if (exported_value) true else null;
    }

    fn commonJsExportPrivateNameImpl(
        self_ptr: *anyopaque,
        specifier: []const u8,
        containing_file: []const u8,
    ) ?ts_driver.ExternalResolver.CommonJsExportPrivateName {
        const self: *CheckerResolverAdapter = @ptrCast(@alignCast(self_ptr));
        self.resolver_mutex.lock();
        defer self.resolver_mutex.unlock();
        const resolved = self.resolver.resolve(specifier, containing_file) catch return null;
        const source = self.resolver.fs.readFile(self.resolver.gpa, resolved.path) catch return null;
        defer self.resolver.gpa.free(source);
        const is_tsx = std.mem.endsWith(u8, resolved.path, ".tsx") or std.mem.endsWith(u8, resolved.path, ".jsx");
        const private_name = ts_program.moduleExportAssignmentPrivateTypeName(self.resolver.gpa, source, is_tsx) orelse return null;
        defer self.resolver.gpa.free(private_name);
        const arena = self.resolver.arena.allocator();
        return .{
            .symbol_name = arena.dupe(u8, private_name) catch return null,
            .module_name = ts_program.renderExternalModulePathDisplayName(arena, resolved.path) catch return null,
        };
    }
};

/// Standalone entry, kept for the `zig build home-tsc` benchmark target.
/// Users reach the same code through `home tsc`.
pub fn main(init: std.process.Init) !void {
    var args_arena = std.heap.ArenaAllocator.init(std.heap.page_allocator);
    defer args_arena.deinit();
    const all_args = try init.minimal.args.toSlice(args_arena.allocator());
    return run(init.environ_map, if (all_args.len > 1) all_args[1..] else &.{});
}

/// Run the compiler with `tsc`-style `args`, excluding the program name.
/// Shared by the standalone binary and the `home tsc` subcommand.
pub fn run(environ: *const std.process.Environ.Map, args: []const [:0]const u8) !void {
    var gpa_state: std.heap.DebugAllocator(.{}) = .init;
    defer {
        if (builtin.mode == .debug) _ = gpa_state.deinit();
    }
    const gpa = if (builtin.mode == .debug) gpa_state.allocator() else std.heap.smp_allocator;

    var args_arena = std.heap.ArenaAllocator.init(std.heap.page_allocator);
    defer args_arena.deinit();

    const default_pretty = defaultIsPretty(environ, stdoutIsTty());

    var argv: std.ArrayListUnmanaged([]const u8) = .empty;
    defer argv.deinit(gpa);
    if (args.len > 0) {
        // Expand `@response-file` args (TS5083 / TS6045 on failure) before
        // option parsing, the way tsc does.
        expandResponseFiles(gpa, args_arena.allocator(), args, &argv, 0);
    }

    // `tsc -b` / `tsc --build` (build mode) must be the FIRST argument.
    const is_build_mode = argv.items.len > 0 and
        (std.mem.eql(u8, argv.items[0], "-b") or std.mem.eql(u8, argv.items[0], "--build"));

    var opts: ts_cli.Options = undefined;
    var opts_files_owned = false;
    if (is_build_mode) {
        // Parse the build flags (TS5072/5073/5077/5094/6369/6370). Phase A:
        // on clean parse, build each project via the normal per-project
        // compile flow (full topological/incremental orchestration is a
        // follow-up). Non-dry `--clean` is not yet implemented.
        var bp = ts_cli.parseBuildArgs(gpa, argv.items[1..]) catch
            std.process.exit(@backingInt(ts_cli.ExitCode.internal_error));
        defer bp.deinit(gpa);
        var had_build_err = false;
        for (bp.diagnostics) |d| {
            printStdout("{s}\n", .{d});
            had_build_err = true;
        }
        if (had_build_err) std.process.exit(@backingInt(ts_cli.ExitCode.config_error));
        if (bp.options.clean and !bp.options.dry) {
            printStdout("home tsc --build: '--clean' is not yet implemented.\n", .{});
            return;
        }
        // Resolve the project reference graph, check for cycles (TS6202),
        // then build every project in dependency order. "." / a directory
        // resolves to its tsconfig.json.
        const root_ref = if (bp.projects.len > 0) bp.projects[0] else ".";
        const root_cfg = resolveConfigPath(args_arena.allocator(), ".", root_ref) catch root_ref;
        const graph = loadBuildGraph(gpa, args_arena.allocator(), root_cfg) catch {
            printStdout("error: cannot load project '{s}'\n", .{root_cfg});
            std.process.exit(@backingInt(ts_cli.ExitCode.config_error));
        };
        if (graph.diagnostics.len > 0) {
            for (graph.diagnostics) |d| printStdout("{s}\n", .{d});
            std.process.exit(@backingInt(ts_cli.ExitCode.config_error));
        }
        var ord = ts_cli.topoSortProjects(gpa, graph.nodes) catch
            ts_cli.BuildOrder{ .order = &.{}, .cycle = null };
        defer ord.deinit(gpa);
        if (ord.cycle) |cyc| {
            const msg = ts_cli.projectReferenceCycleDiagnostic(gpa, cyc) catch
                std.process.exit(@backingInt(ts_cli.ExitCode.internal_error));
            defer gpa.free(msg);
            printStdout("{s}\n", .{msg});
            std.process.exit(@backingInt(ts_cli.ExitCode.config_error));
        }
        if (bp.options.verbose and graph.paths.len > 1) {
            // TS6355 — `Projects in this build: {0}` (the project list).
            buildStatusMessage(6355, "Projects in this build:\n", .{});
            for (graph.paths) |p| printStdout("    * {s}\n", .{p});
        }
        if (bp.options.clean and bp.options.dry) {
            var clean_outputs: std.ArrayListUnmanaged([]u8) = .empty;
            defer {
                for (clean_outputs.items) |p| gpa.free(p);
                clean_outputs.deinit(gpa);
            }
            for (ord.order) |pi| {
                try appendProjectCleanOutputs(gpa, args_arena.allocator(), graph.paths[pi], &clean_outputs);
            }
            printDryCleanOutputs(clean_outputs.items);
            return;
        }
        if (bp.options.dry) {
            for (ord.order) |pi| {
                const project_path = graph.paths[pi];
                switch (projectDryStatus(gpa, args_arena.allocator(), project_path)) {
                    .build => {
                        // TS6357 — dry build status for a project that would build.
                        buildStatusMessage(6357, "A non-dry build would build project '{s}'\n", .{project_path});
                    },
                    .update_timestamps => {
                        // TS6374 — dry build status for a timestamp-only pseudo build.
                        buildStatusMessage(6374, "A non-dry build would update timestamps for output of project '{s}'\n", .{project_path});
                    },
                    .up_to_date => {
                        // TS6361 — dry build status for a project that is already current.
                        buildStatusMessage(6361, "Project '{s}' is up to date\n", .{project_path});
                    },
                }
            }
            return;
        }
        // Build each project (dependencies first). The per-project builder
        // handles up-to-date checks unless `--force` is set.
        const BuildProjectStatus = enum { up_to_date, built_dts_unchanged, built_dts_changed, errors, skipped };
        const project_status = try gpa.alloc(BuildProjectStatus, graph.paths.len);
        defer gpa.free(project_status);
        @memset(project_status, .up_to_date);
        var build_had_errors = false;
        var build_outputs_generated = false;
        for (ord.order) |pi| {
            var blocked_dep: ?usize = null;
            var blocked_dep_status: BuildProjectStatus = .up_to_date;
            var upstream_dependency_built_with_unchanged_dts = false;
            for (graph.nodes[pi].deps) |dep| {
                switch (project_status[dep]) {
                    .built_dts_unchanged => upstream_dependency_built_with_unchanged_dts = true,
                    .up_to_date, .built_dts_changed => {},
                    .errors, .skipped => {
                        blocked_dep = dep;
                        blocked_dep_status = project_status[dep];
                        break;
                    },
                }
            }
            if (blocked_dep) |dep| {
                if (bp.options.verbose) {
                    if (blocked_dep_status == .skipped) {
                        // TS6383 / TS6382 — transitive dependency was not built.
                        buildStatusMessage(6383, "Project '{s}' can't be built because its dependency '{s}' was not built\n", .{ graph.paths[pi], graph.paths[dep] });
                        buildStatusMessage(6382, "Skipping build of project '{s}' because its dependency '{s}' was not built\n", .{ graph.paths[pi], graph.paths[dep] });
                    } else {
                        // TS6363 / TS6362 — direct dependency has errors.
                        buildStatusMessage(6363, "Project '{s}' can't be built because its dependency '{s}' has errors\n", .{ graph.paths[pi], graph.paths[dep] });
                        buildStatusMessage(6362, "Skipping build of project '{s}' because its dependency '{s}' has errors\n", .{ graph.paths[pi], graph.paths[dep] });
                    }
                }
                project_status[pi] = .skipped;
                build_had_errors = true;
                continue;
            }
            switch (buildOneProject(gpa, args_arena.allocator(), graph.paths[pi], bp.options.verbose, bp.options.force, upstream_dependency_built_with_unchanged_dts, default_pretty)) {
                .up_to_date => project_status[pi] = .up_to_date,
                .built_dts_unchanged => {
                    project_status[pi] = .built_dts_unchanged;
                    build_outputs_generated = true;
                },
                .built_dts_changed => {
                    project_status[pi] = .built_dts_changed;
                    build_outputs_generated = true;
                },
                .errors_outputs_skipped => {
                    project_status[pi] = .errors;
                    build_had_errors = true;
                },
                .errors_outputs_generated => {
                    project_status[pi] = .errors;
                    build_had_errors = true;
                    build_outputs_generated = true;
                },
            }
        }
        if (build_had_errors) {
            std.process.exit(@backingInt(ts_cli.diagnosticsExitCode(build_outputs_generated)));
        }
        return;
    } else {
        var parse_ctx: ts_cli.ParseContext = .{};
        opts = ts_cli.parseArgsCtx(gpa, argv.items, &parse_ctx) catch |err| {
            switch (err) {
                // TS6044: a non-boolean flag (e.g. `--outDir`) was the last
                // argument with no value following it.
                error.MissingValue => {
                    if (parse_ctx.missing_value_option.len > 0) {
                        const msg = ts_cli.compilerOptionExpectsArgumentDiagnostic(gpa, parse_ctx.missing_value_option) catch {
                            std.process.exit(@backingInt(ts_cli.ExitCode.config_error));
                        };
                        defer gpa.free(msg);
                        printStdout("{s}\n", .{msg});
                    } else {
                        std.debug.print("error parsing args: {s}\n", .{@errorName(err)});
                    }
                },
                error.ConfigOnlyOption => {
                    if (parse_ctx.config_only_option.len > 0) {
                        const msg = ts_cli.optionCanOnlyBeSpecifiedInTsconfigOrNullDiagnostic(gpa, parse_ctx.config_only_option) catch {
                            std.process.exit(@backingInt(ts_cli.ExitCode.config_error));
                        };
                        defer gpa.free(msg);
                        printStdout("{s}\n", .{msg});
                    } else {
                        std.debug.print("error parsing args: {s}\n", .{@errorName(err)});
                    }
                },
                error.ConfigOnlyBooleanOption => {
                    if (parse_ctx.config_only_option.len > 0) {
                        const msg = ts_cli.optionCanOnlyBeSpecifiedInTsconfigOrFalseOrNullDiagnostic(gpa, parse_ctx.config_only_option) catch {
                            std.process.exit(@backingInt(ts_cli.ExitCode.config_error));
                        };
                        defer gpa.free(msg);
                        printStdout("{s}\n", .{msg});
                    } else {
                        std.debug.print("error parsing args: {s}\n", .{@errorName(err)});
                    }
                },
                error.InvalidEnumOption => {
                    if (parse_ctx.enum_option.len > 0 and parse_ctx.enum_allowed_values.len > 0) {
                        const msg = ts_cli.argumentForOptionMustBeDiagnostic(gpa, parse_ctx.enum_option, parse_ctx.enum_allowed_values) catch {
                            std.process.exit(@backingInt(ts_cli.ExitCode.config_error));
                        };
                        defer gpa.free(msg);
                        printStdout("{s}\n", .{msg});
                    } else {
                        std.debug.print("error parsing args: {s}\n", .{@errorName(err)});
                    }
                },
                error.WatchOptionTypeMismatch => {
                    if (parse_ctx.watch_option.len > 0 and parse_ctx.watch_option_type.len > 0) {
                        const msg = ts_cli.watchOptionRequiresValueDiagnostic(gpa, parse_ctx.watch_option, parse_ctx.watch_option_type) catch {
                            std.process.exit(@backingInt(ts_cli.ExitCode.config_error));
                        };
                        defer gpa.free(msg);
                        printStdout("{s}\n", .{msg});
                    } else {
                        std.debug.print("error parsing args: {s}\n", .{@errorName(err)});
                    }
                },
                else => std.debug.print("error parsing args: {s}\n", .{@errorName(err)}),
            }
            std.process.exit(@backingInt(ts_cli.ExitCode.config_error));
        };
        opts_files_owned = true;

        // TS5093 / TS6369: a build-only option (or a non-first `--build`)
        // used in plain `tsc` mode.
        for (argv.items) |a| {
            if (ts_cli.buildOnlyOptionInNormalMode(a)) |bn| {
                const code: u32 = 5093;
                const msg = std.fmt.allocPrint(gpa, "error TS{d}: Compiler option '--{s}' may only be used with '--build'.", .{ code, bn }) catch
                    std.process.exit(@backingInt(ts_cli.ExitCode.config_error));
                defer gpa.free(msg);
                printStdout("{s}\n", .{msg});
                std.process.exit(@backingInt(ts_cli.ExitCode.config_error));
            }
            if (std.mem.eql(u8, a, "--build") or std.mem.eql(u8, a, "-b")) {
                const code: u32 = 6369;
                printStdout("error TS{d}: Option '--build' must be the first command line argument.\n", .{code});
                std.process.exit(@backingInt(ts_cli.ExitCode.config_error));
            }
        }
    }
    defer if (opts_files_owned) gpa.free(opts.files);

    // TS5042: `--project` (or `-p`) cannot be combined with positional
    // source files. Mirrors upstream `internal/execute/tsc.go`.
    if (opts.project != null and opts.files.len > 0) {
        const msg = projectMixedWithSourceFilesDiagnostic(gpa) catch {
            std.process.exit(@backingInt(ts_cli.ExitCode.config_error));
        };
        defer gpa.free(msg);
        printStdout("{s}\n", .{msg});
        std.process.exit(@backingInt(ts_cli.ExitCode.config_error));
    }

    // Resolve tsconfig BEFORE dispatch so a discovered tsconfig
    // counts as input for the "no files" check inside dispatch.
    // Explicit `--project <path>` wins; otherwise we walk upward
    // from cwd looking for the nearest `tsconfig.json`.
    var cfg_arena = std.heap.ArenaAllocator.init(gpa);
    defer cfg_arena.deinit();
    var cfg_path_buf: ?[]u8 = null;
    defer if (cfg_path_buf) |b| gpa.free(b);
    var loaded_cfg: ?tsconfig_mod.TsConfig = null;
    const explicit_project = opts.project;
    const should_load_config = shouldLoadConfig(opts);
    const should_check_positional_config = shouldCheckPositionalConfig(opts);

    // For an explicit `--project`, validate existence the way upstream
    // does before resolving the config path: a path that names an
    // existing directory must contain a `tsconfig.json` (else TS5081);
    // a non-directory path is treated as a file and must exist (else
    // TS5058).
    if (explicit_project) |proj| {
        if (directoryExistsOnDisk(gpa, proj)) {
            const candidate = try std.fmt.allocPrint(gpa, "{s}/tsconfig.json", .{proj});
            defer gpa.free(candidate);
            if (!fileExistsOnDisk(gpa, candidate)) {
                const msg = try cannotFindTsConfigAtCurrentDirectoryDiagnostic(gpa, candidate);
                defer gpa.free(msg);
                printStdout("{s}\n", .{msg});
                std.process.exit(@backingInt(ts_cli.ExitCode.config_error));
            }
        } else if (!fileExistsOnDisk(gpa, proj)) {
            const msg = try specifiedPathDoesNotExistDiagnostic(gpa, proj);
            defer gpa.free(msg);
            printStdout("{s}\n", .{msg});
            std.process.exit(@backingInt(ts_cli.ExitCode.config_error));
        }
    }

    // TypeScript still discovers the nearest config beside positional files,
    // but only to reject the ambiguous invocation with TS5112. Do not publish
    // that path as `opts.project`: the config must never be loaded in this
    // branch. Help, version, and --init retain their upstream precedence below.
    if (should_check_positional_config) {
        if (resolveTsConfigPath(gpa, null) catch null) |path| {
            cfg_path_buf = path;
        }
    } else if (should_load_config) {
        if (resolveTsConfigPath(gpa, opts.project) catch null) |path| {
            opts.project = path;
            cfg_path_buf = path;
        }
    }

    // Help is rendered from the compiler-options table (table-driven, so
    // the `--help` text stays in lockstep with the diagnostic catalogue).
    if (opts.show_help or opts.show_all_help) {
        const help = ts_cli.renderHelp(gpa, opts.show_all_help) catch {
            printStdout("{s}\n", .{ts_cli.helpText});
            return;
        };
        defer gpa.free(help);
        printStdout("{s}\n", .{help});
        return;
    }

    // `--init`: write a default tsconfig.json, or TS5054 if one exists.
    if (opts.init_config) {
        if (fileExistsOnDisk(gpa, "tsconfig.json")) {
            const msg = ts_cli.tsconfigAlreadyDefinedDiagnostic(gpa, "tsconfig.json") catch std.process.exit(1);
            defer gpa.free(msg);
            printStdout("{s}\n", .{msg});
            std.process.exit(1);
        }
        const tsconfig_text = ts_cli.defaultTsconfigContentsWithDiagnostics(gpa) catch std.process.exit(1);
        defer gpa.free(tsconfig_text);
        RealFs.write(gpa, "tsconfig.json", tsconfig_text) catch |err| {
            std.debug.print("error writing tsconfig.json: {s}\n", .{@errorName(err)});
            std.process.exit(1);
        };
        // TS6071 — tsc's `--init` success message (CategoryMessage).
        buildStatusMessage(6071, "Successfully created a tsconfig.json file.\n", .{});
        return;
    }

    const dec = ts_cli.dispatch(opts);
    if (dec.stdout_text.len > 0) {
        printStdout("{s}\n", .{dec.stdout_text});
    }
    if (dec.stderr_text.len > 0) {
        std.debug.print("{s}\n", .{dec.stderr_text});
    }
    if (dec.code != .success) std.process.exit(@backingInt(dec.code));

    if (opts.show_version or opts.show_help) return;

    if (should_check_positional_config and cfg_path_buf != null) {
        const msg = positionalFilesBesideConfigDiagnostic(gpa) catch {
            std.process.exit(@backingInt(ts_cli.ExitCode.type_errors));
        };
        defer gpa.free(msg);
        printStdout("{s}\n", .{msg});
        std.process.exit(@backingInt(ts_cli.ExitCode.type_errors));
    }

    // Load the discovered tsconfig. The JSONC parser aliases
    // strings into the source buffer, so cfg_src must outlive
    // `loaded_cfg`'s borrowed slices — keep it for the rest of
    // main rather than freeing inside this block.
    var cfg_src: []const u8 = &.{};
    var cfg_src_owned = false;
    defer if (cfg_src_owned) gpa.free(cfg_src);
    if (cfg_path_buf) |path| {
        const read_source: ?[]const u8 = RealFs.read(gpa, path) catch |err| blk: {
            std.debug.print("error reading {s}: {s}\n", .{ path, @errorName(err) });
            break :blk null;
        };
        if (read_source) |source| {
            cfg_src = source;
            cfg_src_owned = true;
            loaded_cfg = tsconfig_mod.parseString(gpa, cfg_arena.allocator(), cfg_src) catch |err| blk: {
                std.debug.print("error parsing tsconfig {s}: {s}\n", .{ path, @errorName(err) });
                break :blk null;
            };
            if (loaded_cfg) |*c| {
                c.file_path = path;
                ts_cli.applyConfigOverrides(c, opts);
            }
        }
    }

    const config_pretty: ?bool = if (loaded_cfg) |c| c.compiler_options.pretty else null;
    const pretty = opts.pretty orelse config_pretty orelse default_pretty;
    const diagnostic_color = pretty;

    // Determine the file list. Precedence:
    //   1. positional args (CLI wins)
    //   2. tsconfig `files`: literal list, used as-is
    //   3. tsconfig `include` / `exclude`: glob-expanded against the
    //      tsconfig's directory; default ext filter is `.ts` / `.tsx`
    //      / `.d.ts` / `.mts` / `.cts` plus Home's `.hm` / `.home`.
    var input_files: std.ArrayListUnmanaged([]const u8) = .empty;
    var owned_paths: std.ArrayListUnmanaged([]u8) = .empty;
    defer {
        input_files.deinit(gpa);
        for (owned_paths.items) |p| gpa.free(p);
        owned_paths.deinit(gpa);
    }
    for (opts.files) |f| try input_files.append(gpa, f);
    if (input_files.items.len == 0) {
        if (loaded_cfg) |c| {
            if (c.files) |fs_list| {
                const project_dir = std.fs.path.dirname(c.file_path) orelse ".";
                try ts_cli.appendProjectFilePaths(gpa, project_dir, fs_list, &input_files, &owned_paths);
            }
        }
    }
    if (input_files.items.len == 0) {
        if (loaded_cfg) |c| {
            const project_dir = std.fs.path.dirname(c.file_path) orelse ".";
            const include_patterns = effectiveIncludePatterns(c);
            var exclude_storage: [2][]const u8 = undefined;
            const exclude_patterns = c.effectiveExcludePatterns(&exclude_storage);
            try expandProjectGlobs(
                gpa,
                project_dir,
                include_patterns,
                exclude_patterns,
                tsconfig_mod.effectiveAllowJs(c.compiler_options),
                &input_files,
                &owned_paths,
            );
        }
    }

    var config_validation_diags: ?[]tsconfig_mod.ValidationDiagnostic = null;
    defer if (config_validation_diags) |diagnostics| {
        tsconfig_mod.freeValidationDiagnostics(gpa, diagnostics);
    };
    if (!opts.show_config) {
        if (loaded_cfg) |c| {
            config_validation_diags = try c.validate(gpa);
        }
    }
    const pending_config_summary = if (loaded_cfg) |c|
        config_diagnostics.summarize(c, config_validation_diags orelse &.{})
    else
        config_diagnostics.Summary{};

    if (input_files.items.len == 0) {
        if (loaded_cfg) |c| {
            if (opts.files.len == 0) {
                if (c.files == null) {
                    const project_dir = std.fs.path.dirname(c.file_path) orelse ".";
                    var exclude_display_list: std.ArrayListUnmanaged([]const u8) = .empty;
                    defer exclude_display_list.deinit(gpa);
                    var owned_default_excludes: [2]?[]u8 = .{ null, null };
                    defer for (owned_default_excludes) |owned| if (owned) |path| gpa.free(path);
                    const exclude_display_patterns = try effectiveExcludeDiagnosticPatterns(
                        gpa,
                        project_dir,
                        c,
                        &exclude_display_list,
                        &owned_default_excludes,
                    );
                    const msg = try noInputsFoundInConfigDiagnostic(
                        gpa,
                        c.file_path,
                        effectiveIncludePatterns(c),
                        exclude_display_patterns,
                    );
                    defer gpa.free(msg);
                    printStdout("{s}\n", .{msg});
                    std.process.exit(2);
                }
                if (c.files) |files| {
                    if (files.len == 0 and c.references.len == 0 and !c.has_extends) {
                        printStdout("error TS{d}: The 'files' list in config file '{s}' is empty.\n", .{ ts_empty_files_list_in_config, c.file_path });
                        std.process.exit(2);
                    }
                }
            }
        }
        std.debug.print("error: no input files; pass paths or --project=<path>\n", .{});
        std.process.exit(2);
    }

    // `--showConfig` converts the parsed command line before a Program is
    // created. Program option diagnostics such as TS5108 therefore do not
    // participate, even though file discovery does.
    if (opts.show_config) {
        printResolvedConfig(loaded_cfg, input_files.items);
        return;
    }

    // §4.A.12 — read-side of `.tsbuildinfo` round-trip. When
    // `compilerOptions.incremental` is on and a prior buildinfo
    // exists, parse it and surface a one-liner so callers can see
    // the round-trip is wired. Actually skipping unchanged files
    // is a follow-up — for now we just demonstrate the read path
    // can be invoked without breaking the pipeline.
    if (loaded_cfg) |cfg_ptr| {
        const want_buildinfo = cfg_ptr.compiler_options.incremental orelse false;
        if (want_buildinfo) {
            const out_dir_for_read: ?[]const u8 = opts.out_dir orelse blk: {
                if (cfg_ptr.compiler_options.out_dir) |d| break :blk d;
                break :blk null;
            };
            const bi_path: ?[]u8 = blk: {
                if (cfg_ptr.compiler_options.ts_buildinfo_file) |p| break :blk gpa.dupe(u8, p) catch null;
                break :blk if (out_dir_for_read) |od|
                    std.fs.path.join(gpa, &.{ od, "tsconfig.tsbuildinfo" }) catch null
                else
                    gpa.dupe(u8, "tsconfig.tsbuildinfo") catch null;
            };
            if (bi_path) |p| {
                defer gpa.free(p);
                if (RealFs.read(gpa, p)) |bi_src| {
                    defer gpa.free(bi_src);
                    if (ts_emit.tsbuildinfo.read(gpa, bi_src)) |info_const| {
                        var info = info_const;
                        defer info.deinit(gpa);
                        std.debug.print("home tsc: loaded incremental info ({d} previously-compiled files)\n", .{info.file_names.len});
                    } else |_| {}
                } else |_| {}
            }
        }
    }

    var resolver_fs = ResolverRealFs.init(gpa);
    defer resolver_fs.deinit();
    const resolver_config: ts_resolver.Config = if (loaded_cfg) |c|
        resolverConfigFromConfig(cfg_arena.allocator(), c, opts.out_dir)
    else
        .{};
    var resolver = ts_resolver.Resolver.init(gpa, resolver_fs.fs(), resolver_config);
    defer resolver.deinit();
    const trace_resolution = opts.trace_resolution or blk: {
        if (loaded_cfg) |c| break :blk (c.compiler_options.trace_resolution orelse false);
        break :blk false;
    };
    var trace_sink: ?ts_resolver.TraceSink = null;
    defer if (trace_sink) |*sink| sink.deinit();
    if (trace_resolution) {
        trace_sink = ts_resolver.TraceSink.init(gpa);
        resolver.trace = &trace_sink.?;
    }
    var printed_trace_entries: usize = 0;

    var program = ts_program.Program.init(gpa, &resolver);
    defer program.deinit();

    // §file-add — extension gate. tsc rejects an input file whose
    // extension it cannot process before it ever reads the file:
    // a JavaScript file without `allowJs` is TS6504; any other
    // unsupported extension is TS6054. (`allowNonTsExtensions` — the
    // upstream escape hatch — has no CLI surface in Home yet, so the
    // check always runs.)
    const force_consistent_casing: bool = blk: {
        if (loaded_cfg) |c| break :blk (c.compiler_options.force_consistent_casing_in_file_names orelse true);
        break :blk true;
    };
    const case_only_root_context: CaseOnlyInputRootContext = blk: {
        if (opts.files.len == 0) {
            if (loaded_cfg) |c| {
                if (c.files) |files| {
                    break :blk .{
                        .kind = .files,
                        .config_path = c.file_path,
                        .config_source = cfg_src,
                        .specs = files,
                    };
                }
                if (c.include) |include| {
                    break :blk .{
                        .kind = .include,
                        .config_path = c.file_path,
                        .config_source = cfg_src,
                        .specs = include,
                    };
                }
            }
        }
        break :blk .{};
    };
    if (force_consistent_casing and reportCaseOnlyInputFileDiagnostics(gpa, input_files.items, case_only_root_context)) std.process.exit(1);

    const allow_js: bool = blk: {
        if (loaded_cfg) |c| break :blk tsconfig_mod.effectiveAllowJs(c.compiler_options);
        break :blk false;
    };
    var extension_errors: bool = false;
    for (input_files.items) |path| {
        switch (classifyExtension(path)) {
            .supported => {},
            .javascript => {
                if (!allow_js) {
                    const msg = try javaScriptFileNeedsAllowJsDiagnostic(gpa, path);
                    defer gpa.free(msg);
                    printStdout("{s}\n", .{msg});
                    extension_errors = true;
                }
            },
            .unsupported => {
                const msg = try unsupportedExtensionDiagnostic(gpa, path);
                defer gpa.free(msg);
                printStdout("{s}\n", .{msg});
                extension_errors = true;
            },
        }
    }
    if (extension_errors) std.process.exit(1);

    var source_io_threaded = std.Io.Threaded.init(gpa, .{});
    defer source_io_threaded.deinit();
    const source_io = source_io_threaded.io();
    for (input_files.items) |path| {
        const src = RealFs.readWithIo(gpa, source_io, path) catch |err| {
            std.debug.print("error reading {s}: {s}\n", .{ path, @errorName(err) });
            std.process.exit(1);
        };
        defer gpa.free(src);
        _ = program.add(path, src) catch |err| {
            std.debug.print("error adding file: {s}\n", .{@errorName(err)});
            std.process.exit(1);
        };
    }

    var compile_opts: ts_driver.CompileOptions = if (loaded_cfg) |*c|
        ts_driver.optionsFromConfig(c)
    else
        .{};
    ts_cli.applyCompileOptions(&compile_opts, opts);
    var resolver_adapter = CheckerResolverAdapter.init(gpa, &resolver);
    defer resolver_adapter.deinit();
    resolver_adapter.setProgramSources(&program, compile_opts);
    compile_opts.external_resolver = .{
        .ptr = &resolver_adapter,
        .vtable = &CheckerResolverAdapter.vtable,
    };

    // Build the transitive import closure (like tsc's file loader) so
    // every reachable file participates in the program. This is what
    // lets `--explainFiles` report imported files with their TS1393
    // "Imported via … from file …" reason. Best-effort: resolution gaps
    // simply leave the program partial, as they did before.
    _ = program.loadImportClosureParallel(compile_opts, null) catch {};
    if (trace_sink) |*sink| printTraceEntries(sink, &printed_trace_entries);

    // Stream diagnostics as each file finishes compiling. Brings
    // time-to-first-diagnostic down from whole-program time to
    // per-file check time — Phase 5 §5.8 / §5.A.10.
    var any_errors_streaming = false;
    var stream_error_count: usize = 0;
    var stream_files_with_errors: usize = 0;
    var stream_first_error_file: []const u8 = "";
    var stream_first_error_line: usize = 0;
    var stream_first_error_col: usize = 0;
    var stream_error_file_counts: std.ArrayListUnmanaged(ErrorFileCount) = .empty;
    defer stream_error_file_counts.deinit(gpa);
    var stream_ctx: StreamCtx = .{
        .gpa = gpa,
        .program = &program,
        .use_pretty = pretty,
        .use_color = diagnostic_color,
        .any_errors = &any_errors_streaming,
        .error_count = &stream_error_count,
        .files_with_errors = &stream_files_with_errors,
        .first_error_file = &stream_first_error_file,
        .first_error_line = &stream_first_error_line,
        .first_error_col = &stream_first_error_col,
        .error_file_counts = &stream_error_file_counts,
    };
    if (opts.watch) {
        buildStatusMessage(6031, "Starting compilation in watch mode...\n", .{});
    }

    // Upstream first gathers syntax diagnostics. Only when syntax is clean
    // does it add option diagnostics, and option errors suppress global and
    // semantic diagnostics. `--listFilesOnly` follows the same syntax/options
    // path but never asks for semantic diagnostics. Preserve streaming for
    // ordinary clean configs; defer only for these exceptional paths.
    const defer_program_diagnostics = pending_config_summary.hasErrors() or opts.list_files_only;
    if (defer_program_diagnostics) {
        var syntax_probe: SyntaxDiagnosticProbe = .{};
        program.compileAllStreaming(compile_opts, &syntax_probe, SyntaxDiagnosticProbe.receive) catch |err| {
            std.debug.print("compile error: {s}\n", .{@errorName(err)});
            std.process.exit(1);
        };
        if (syntax_probe.has_errors) {
            stream_ctx.filter = .syntax_only;
            for (program.files.items) |file| {
                const compilation = file.compilation orelse continue;
                streamDiagsCallback(&stream_ctx, file.path, compilation.diagnostics.items);
            }
        } else if (pending_config_summary.hasErrors()) {
            try printConfigValidationDiagnostics(
                gpa,
                loaded_cfg.?,
                cfg_src,
                config_validation_diags.?,
                pretty,
                diagnostic_color,
            );
            any_errors_streaming = true;
            stream_error_count = pending_config_summary.count;
            stream_files_with_errors = if (pending_config_summary.file_error_count > 0) 1 else 0;
            stream_first_error_file = pending_config_summary.first_error_file;
            stream_first_error_line = pending_config_summary.first_error_line;
            stream_first_error_col = pending_config_summary.first_error_col;
            if (pending_config_summary.file_error_count > 0) {
                try stream_error_file_counts.append(gpa, .{
                    .path = pending_config_summary.first_error_file,
                    .count = pending_config_summary.file_error_count,
                });
            }
        }
    } else {
        program.compileAllStreaming(compile_opts, &stream_ctx, streamDiagsCallback) catch |err| {
            std.debug.print("compile error: {s}\n", .{@errorName(err)});
            std.process.exit(1);
        };
    }
    if (trace_sink) |*sink| printTraceEntries(sink, &printed_trace_entries);
    if (!defer_program_diagnostics) {
        if (loaded_cfg) |c| {
            if (c.compiler_options.composite orelse false) {
                const composite_summary = printCompositeProjectFileListDiagnostics(
                    gpa,
                    &program,
                    input_files.items,
                    c.file_path,
                    pretty,
                    diagnostic_color,
                );
                if (composite_summary.error_count > 0) {
                    any_errors_streaming = true;
                    stream_error_count += composite_summary.error_count;
                    stream_files_with_errors += composite_summary.files_with_errors;
                    if (stream_first_error_file.len == 0) {
                        stream_first_error_file = composite_summary.first_error_file;
                        stream_first_error_line = composite_summary.first_error_line;
                        stream_first_error_col = composite_summary.first_error_col;
                    }
                }
            }
        }
    }

    // Output-path diagnostics are program diagnostics, not an emit side
    // effect. TypeScript computes them before `--listFilesOnly` prints the
    // admitted program and returns, even though that mode never writes a
    // file. Resolve the paths here so both list-only and ordinary compiles
    // share one verification pass.
    const out_dir: ?[]const u8 = opts.out_dir orelse blk: {
        if (loaded_cfg) |c| if (c.compiler_options.out_dir) |d| break :blk d;
        break :blk null;
    };
    const emit_dts: bool = blk: {
        if (opts.declaration) |d| break :blk d;
        if (loaded_cfg) |c| if (c.compiler_options.declaration) |d| break :blk d;
        break :blk false;
    };
    const declaration_dir: ?[]const u8 = blk: {
        if (loaded_cfg) |c| if (c.compiler_options.declaration_dir) |d| break :blk d;
        break :blk out_dir;
    };
    var blocked_outputs: std.ArrayListUnmanaged([]const u8) = .empty;
    defer {
        for (blocked_outputs.items) |path| gpa.free(path);
        blocked_outputs.deinit(gpa);
    }
    const output_collision_count = try reportOutputCollisions(
        gpa,
        &program,
        out_dir,
        declaration_dir,
        emit_dts,
        compile_opts.no_emit,
        loaded_cfg != null,
        &blocked_outputs,
    );
    if (output_collision_count > 0) {
        any_errors_streaming = true;
        stream_error_count += output_collision_count;
    }

    // tsc lists files after reporting diagnostics and after deciding whether
    // emit is skipped. `--listFilesOnly` never reaches the emit loop.
    if (opts.list_files or opts.list_files_only) {
        for (program.files.items) |file| {
            printStdout("{s}\n", .{file.path});
        }
        if (opts.list_files_only) {
            reportErrorSummary(
                pretty,
                stream_error_count,
                stream_files_with_errors,
                stream_first_error_file,
                stream_first_error_line,
                stream_error_file_counts.items,
            );
            if (any_errors_streaming) {
                std.process.exit(@backingInt(ts_cli.diagnosticsExitCode(false)));
            }
            return;
        }
    }
    // tsc's post-compilation summary (CategoryMessage). Non-watch
    // compiles stay silent when clean; watch compiles always report
    // the TS6193/TS6194 "Watching for file changes" status. For
    // non-watch errors, tsc picks the message by error-and-file count:
    // 1 error → TS6259 in one file else TS6216; many errors across >1
    // files → TS6261; otherwise TS6217. Like typescript-go's
    // `CreateReportErrorSummary`, the non-watch summary is pretty-only.
    if (opts.watch) {
        reportWatchErrorStatus(stream_error_count);
    } else {
        reportErrorSummary(
            pretty,
            stream_error_count,
            stream_files_with_errors,
            stream_first_error_file,
            stream_first_error_line,
            stream_error_file_counts.items,
        );
    }

    // `--explainFiles`: list every file with its inclusion reason. Input
    // files in a run come from one source (CLI args XOR tsconfig `files`
    // XOR include globs), so the root reason is uniform.
    if (opts.explain_files) {
        var root_incl: RootInclusion = .{ .code = 1427 };
        if (opts.files.len == 0) {
            if (loaded_cfg) |c| {
                if (c.files != null) {
                    root_incl.code = 1409; // Part of 'files' list
                } else if (c.include == null) {
                    root_incl.code = 1457; // Matched by default **/* pattern
                } else {
                    root_incl.code = 1407; // Matched by include pattern
                    root_incl.specs = c.include.?;
                    root_incl.project_dir = std.fs.path.dirname(c.file_path) orelse ".";
                    root_incl.config_path = c.file_path;
                }
            }
        }
        const explain_module = if (loaded_cfg) |c| c.compiler_options.module else null;
        printExplainFiles(gpa, resolver_fs.fs(), &program, input_files.items, root_incl, explain_module);
    }

    // Resolve `sourceMap` from CLI or tsconfig. CLI wins.
    const emit_source_map: bool = blk: {
        if (opts.source_map) |s| break :blk s;
        if (loaded_cfg) |c| if (c.compiler_options.source_map) |s| break :blk s;
        break :blk false;
    };

    // Resolve `declarationMap` from CLI or tsconfig. CLI wins. Has no
    // effect unless `declaration` emission is also on (matches tsc).
    const emit_decl_map: bool = blk: {
        if (opts.declaration_map) |d| break :blk d;
        if (loaded_cfg) |c| if (c.compiler_options.declaration_map) |d| break :blk d;
        break :blk false;
    };

    // Diagnostics already printed above by the streaming callback;
    // this loop only handles JS / .d.ts emission. The streaming
    // any-errors flag flows into the final exit-code decision.
    const any_errors = any_errors_streaming;
    var outputs_generated = false;

    for (program.files.items) |f| {
        const c = f.compilation orelse continue;
        if (compile_opts.no_emit) continue;
        const out_path = try computeOutPath(gpa, f.path, out_dir, ".js");
        defer gpa.free(out_path);
        // Skip files whose output was blocked by the TS5055/5056 check.
        if (pathInList(blocked_outputs.items, out_path)) continue;

        // §4.A.13 — when sourceMap is enabled, re-emit through a
        // Printer hooked up to a SourceMap so the printer records
        // mappings as it streams. The compileSource path produced
        // `c.js` without mappings, so we discard it here in favor
        // of the freshly-emitted bytes that include the trailing
        // `//# sourceMappingURL=…` comment.
        var sm_owned_js: ?[]u8 = null;
        defer if (sm_owned_js) |b| gpa.free(b);
        var sm_owned_map: ?[]u8 = null;
        defer if (sm_owned_map) |b| gpa.free(b);
        var sm_map_path_owned: ?[]u8 = null;
        defer if (sm_map_path_owned) |b| gpa.free(b);

        if (emit_source_map) {
            const map_path = std.fmt.allocPrint(gpa, "{s}.map", .{out_path}) catch unreachable;
            sm_map_path_owned = map_path;
            const map_basename = std.fs.path.basename(map_path);
            const out_basename = std.fs.path.basename(out_path);
            var sm = ts_emit.SourceMap.init(gpa, out_basename);
            defer sm.deinit();
            const src_idx = sm.addSource(f.path, f.source) catch 0;

            var emit_options = compile_opts.emit;
            emit_options.source_map = &sm;
            emit_options.source_map_src_idx = src_idx;
            emit_options.source_map_url = map_basename;

            var printer = ts_emit.Printer.init(gpa, &c.hir, &c.interner, emit_options);
            defer printer.deinit();
            printer.setSource(f.source);
            printer.printSourceFile(c.root) catch |err| {
                std.debug.print("warning: source-map emit failed for {s}: {s}\n", .{ f.path, @errorName(err) });
            };
            sm_owned_js = printer.toOwnedSlice() catch null;
            sm_owned_map = sm.toJson() catch null;
        }

        const js_bytes: []const u8 = sm_owned_js orelse c.js;
        writeOrDie(gpa, out_path, js_bytes);
        outputs_generated = true;
        if (emit_source_map) {
            const map_bytes: []const u8 = sm_owned_map orelse "{}";
            const map_path = sm_map_path_owned.?;
            writeOrDie(gpa, map_path, map_bytes);
        }

        if (emit_dts) {
            var emitter = ts_emit.DtsEmitter.initWithTypes(gpa, &c.hir, &c.interner, &c.type_interner, .{});
            defer emitter.deinit();
            emitter.emitSourceFile(c.root) catch |err| {
                std.debug.print("error emitting d.ts for {s}: {s}\n", .{ f.path, @errorName(err) });
                continue;
            };
            const dts_bytes = emitter.toOwnedSlice() catch continue;
            defer gpa.free(dts_bytes);
            const dts_path = try computeOutPath(gpa, f.path, declaration_dir, ".d.ts");
            defer gpa.free(dts_path);
            writeOrDie(gpa, dts_path, dts_bytes);

            // §4.A.x — when `declarationMap` is on, write a parallel
            // `.d.ts.map` next to the `.d.ts`. v0 emits Source Map V3
            // framing only (empty `mappings`); the symbol-driven
            // re-printer fills in real positions later. Reuses
            // `d_hm.renderDeclarationMap` since the format is shared
            // between `.d.hm.map` and `.d.ts.map`.
            if (emit_decl_map) {
                const dts_basename = std.fs.path.basename(dts_path);
                const map_bytes = d_hm.renderDeclarationMap(
                    gpa,
                    f.path,
                    .{ .file = dts_basename },
                ) catch |err| blk: {
                    std.debug.print("warning: declaration-map render failed for {s}: {s}\n", .{ f.path, @errorName(err) });
                    break :blk null;
                };
                if (map_bytes) |mb| {
                    defer gpa.free(mb);
                    const map_path = try std.fmt.allocPrint(gpa, "{s}.map", .{dts_path});
                    defer gpa.free(map_path);
                    writeOrDie(gpa, map_path, mb);
                }
            }
        }
    }

    // §4.A.12 — write `.tsbuildinfo` when `compilerOptions.incremental: true`.
    if (loaded_cfg) |cfg_ptr| {
        const want_buildinfo = cfg_ptr.compiler_options.incremental orelse false;
        if (want_buildinfo) {
            // File names + per-file content-version (sha-1 over source).
            var file_names: std.ArrayListUnmanaged([]const u8) = .empty;
            defer file_names.deinit(gpa);
            var file_infos: std.ArrayListUnmanaged(ts_emit.tsbuildinfo.FileInfo) = .empty;
            defer {
                for (file_infos.items) |fi| gpa.free(fi.version);
                file_infos.deinit(gpa);
            }
            for (program.files.items) |f| {
                try file_names.append(gpa, f.path);
                var hasher = std.crypto.hash.Sha1.init(.{});
                hasher.update(f.source);
                var digest: [20]u8 = undefined;
                hasher.final(&digest);
                const hex = try gpa.alloc(u8, digest.len * 2);
                const hex_chars = "0123456789abcdef";
                for (digest, 0..) |b, i| {
                    hex[i * 2] = hex_chars[b >> 4];
                    hex[i * 2 + 1] = hex_chars[b & 0x0F];
                }
                try file_infos.append(gpa, .{ .version = hex });
            }
            const options_json = buildInfoOptionsJson(gpa, cfg_ptr) catch null;
            defer if (options_json) |json| gpa.free(json);
            const buildinfo = ts_emit.tsbuildinfo.emit(
                gpa,
                file_names.items,
                file_infos.items,
                options_json orelse "{}",
                .{},
            ) catch null;
            if (buildinfo) |bi| {
                defer gpa.free(bi);
                const bi_path: []const u8 = blk: {
                    if (cfg_ptr.compiler_options.ts_buildinfo_file) |p| break :blk p;
                    break :blk if (out_dir) |od|
                        try std.fs.path.join(gpa, &.{ od, "tsconfig.tsbuildinfo" })
                    else
                        try gpa.dupe(u8, "tsconfig.tsbuildinfo");
                };
                defer if (cfg_ptr.compiler_options.ts_buildinfo_file == null) gpa.free(bi_path);
                RealFs.write(gpa, bi_path, bi) catch |err| {
                    std.debug.print("warning: could not write {s}: {s}\n", .{ bi_path, @errorName(err) });
                };
                outputs_generated = true;
            }
        }
    }

    if (opts.watch) {
        // §5.A.5 — polling watch loop driven by `ts_watch.Watcher`
        // over `RealStatFs`. Each tick compares mtime+size for every
        // tracked path and reports a `ChangeSet`; we re-read, update
        // the program, recompile changed files, and re-emit JS.
        // Native FS-event backends (FSEvents/inotify/ReadDirChangesW)
        // are tracked separately.
        var watch_threaded = std.Io.Threaded.init(gpa, .{});
        defer watch_threaded.deinit();
        const watch_io = watch_threaded.io();
        var rfs = ts_watch.RealStatFs.init(gpa);
        defer rfs.deinit();
        var watcher = ts_watch.Watcher.init(gpa, rfs.fs());
        defer watcher.deinit();
        // Pre-populate the tracked set so the first tick records a
        // real baseline rather than reporting every input as added.
        for (input_files.items) |path| {
            try watcher.track(path);
        }
        while (true) {
            // Inter-poll pause: 100ms via `std.Io.Clock.Duration.sleep`.
            // A platform-native FS-event backend (FSEvents/inotify/
            // ReadDirChangesW) is the right long-term replacement and
            // is tracked as Phase 5 §5.A.5.
            std.Io.Clock.Duration.sleep(.{
                .clock = .boot,
                .raw = .fromNanoseconds(100 * std.time.ns_per_ms),
            }, watch_io) catch {};
            var change_set = watcher.tick() catch |err| {
                std.debug.print("watch error: {s}\n", .{@errorName(err)});
                continue;
            };
            defer change_set.deinit(gpa);
            if (change_set.isEmpty()) continue;

            var changed: std.ArrayListUnmanaged([]const u8) = .empty;
            defer changed.deinit(gpa);
            for (change_set.changes.items) |ch| {
                if (ch.kind == .removed) continue;
                const src = RealFs.read(gpa, ch.path) catch |err| {
                    std.debug.print("error reading {s}: {s}\n", .{ ch.path, @errorName(err) });
                    continue;
                };
                defer gpa.free(src);
                // `updateSource` dupes the buffer internally.
                _ = program.updateSource(ch.path, src) catch |err| {
                    std.debug.print("error updating source {s}: {s}\n", .{ ch.path, @errorName(err) });
                    continue;
                };
                // The watcher's tracked-set keys are owned strings
                // independent of `input_files`, so it's safe to
                // borrow the input_files slice here for re-emit.
                const path_borrow = blk: {
                    for (input_files.items) |p| {
                        if (std.mem.eql(u8, p, ch.path)) break :blk p;
                    }
                    break :blk ch.path;
                };
                try changed.append(gpa, path_borrow);
            }
            if (changed.items.len == 0) continue;
            buildStatusMessage(6032, "File change detected. Starting incremental compilation...\n", .{});
            // Export/default facts cached by the resolver adapter describe a
            // particular source revision. Recreate the caches before checking
            // the revised reverse dependency closure. The external-resolver
            // pointer remains valid because `resolver_adapter` keeps its
            // address.
            resolver_adapter.deinit();
            resolver_adapter = CheckerResolverAdapter.init(gpa, &resolver);
            resolver_adapter.setProgramSources(&program, compile_opts);
            _ = program.recompileChanged(changed.items, compile_opts) catch |err| {
                std.debug.print("recompile error: {s}\n", .{@errorName(err)});
                continue;
            };
            var watch_any_errors = false;
            var watch_error_count: usize = 0;
            var watch_stream_ctx: StreamCtx = .{
                .gpa = gpa,
                .program = &program,
                .use_pretty = pretty,
                .use_color = diagnostic_color,
                .any_errors = &watch_any_errors,
                .error_count = &watch_error_count,
            };
            // A dependency revision can add or remove diagnostics in any
            // transitive importer. Publish the complete current project set,
            // as tsc watch does, instead of only the physically changed path.
            for (program.files.items) |f| {
                if (f.redirect_target != null) continue;
                const c = f.compilation orelse continue;
                streamDiagsCallback(&watch_stream_ctx, f.path, c.diagnostics.items);
            }
            reportWatchErrorStatus(watch_error_count);
            // Re-emit each changed file's JS to disk.
            for (changed.items) |path| {
                const file_id = program.lookupPath(path) orelse continue;
                const f = program.fileById(file_id);
                const c = f.compilation orelse continue;
                if (compile_opts.no_emit) continue;
                const out_path = computeOutPath(gpa, path, out_dir, ".js") catch continue;
                defer gpa.free(out_path);
                writeOrDie(gpa, out_path, c.js);
            }
        }
    }

    if (any_errors) {
        std.process.exit(@backingInt(ts_cli.diagnosticsExitCode(outputs_generated)));
    }
}

fn mapPhaseToCode(phase: ts_driver.Diagnostic.Phase) u32 {
    return switch (phase) {
        .lex, .parse => 1109,
        .bind => 2304,
        .emit => 5024,
    };
}

const DiagnosticFilter = enum { all, syntax_only };

const SyntaxDiagnosticProbe = struct {
    has_errors: bool = false,

    fn receive(self: *SyntaxDiagnosticProbe, _: []const u8, diagnostics: []const ts_driver.Diagnostic) void {
        for (diagnostics) |diagnostic| {
            if (diagnostic.category == .error_ and
                (diagnostic.phase == .lex or diagnostic.phase == .parse))
            {
                self.has_errors = true;
                return;
            }
        }
    }
};

/// Context carried through `Program.compileAllStreaming`'s
/// per-file callback. `program` lets the callback resolve
/// the file's source bytes for line/col rendering; `any_errors`
/// is OR'd from each file's non-emit-phase diagnostics so the
/// final exit code reflects what's been streamed.
const StreamCtx = struct {
    gpa: std.mem.Allocator,
    program: *const ts_program.Program,
    use_pretty: bool,
    use_color: bool,
    filter: DiagnosticFilter = .all,
    any_errors: *bool,
    /// Running count of non-emit diagnostics, for the TS6216/TS6217
    /// "Found N errors" summary. Optional so the build-mode caller can
    /// skip it.
    error_count: ?*usize = null,
    /// Count of distinct files that had at least one error, and the
    /// path of the first such file — for the per-file summary variants
    /// TS6259 ("Found 1 error in {0}") / TS6261 ("Found {0} errors in
    /// {1} files.").
    files_with_errors: ?*usize = null,
    first_error_file: ?*[]const u8 = null,
    /// Line/col of the first error, for TS6260's "starting at:" anchor.
    first_error_line: ?*usize = null,
    first_error_col: ?*usize = null,
    /// Per-file diagnostic counts used for tsc's TS6041 "Errors  Files"
    /// table after a multi-file summary.
    error_file_counts: ?*std.ArrayListUnmanaged(ErrorFileCount) = null,
};

const ErrorFileCount = struct {
    path: []const u8,
    count: usize,
};

/// Invoked once per compiled file, in compilation order. Renders
/// every diagnostic via the same formatter the post-compile loop
/// used to use, but earlier — diagnostics for file 0 surface before
/// file N has even been parsed.
fn streamDiagsCallback(ctx: *StreamCtx, file_path: []const u8, diags: []const ts_driver.Diagnostic) void {
    const fid = ctx.program.lookupPath(file_path) orelse return;
    const f = ctx.program.fileById(fid);
    var file_had_error = false;
    var file_error_count: usize = 0;
    for (diags) |d| {
        if (ctx.filter == .syntax_only and d.phase != .lex and d.phase != .parse) continue;
        const pos = ts_diagnostics.positionToLineCol(f.source, d.pos);
        const code = if (d.code != 0) d.code else mapPhaseToCode(d.phase);
        const prefix: ts_diagnostics.Diagnostic.CodePrefix = switch (d.code_prefix) {
            .TS => .TS,
            .HM => .HM,
        };
        // Map the driver's nested elaboration chain (tsc `messageChain`)
        // into the renderer's chain so it surfaces as indented
        // continuation lines under the header. Allocated in an arena tied
        // to this diagnostic's render; freed right after.
        var chain_arena = std.heap.ArenaAllocator.init(ctx.gpa);
        defer chain_arena.deinit();
        const rendered_chain = mapDriverChain(chain_arena.allocator(), d.chain) catch &.{};
        const rendered_related = mapDriverRelated(chain_arena.allocator(), ctx.program, f, d.related) catch &.{};
        const fdiag: ts_diagnostics.Diagnostic = .{
            .file = f.path,
            .line = pos.line,
            .col = pos.col,
            .code = code,
            .code_prefix = prefix,
            .severity = switch (d.category) {
                .error_ => .err,
                .warning => .warning,
                .suggestion => .suggestion,
            },
            .message = d.message,
            .span_len = 0,
            .chain = rendered_chain,
            .related = rendered_related,
        };
        const formatted = if (ctx.use_pretty)
            ts_diagnostics.formatPretty(ctx.gpa, fdiag, f.source, ctx.use_color) catch continue
        else
            ts_diagnostics.formatDefault(ctx.gpa, fdiag) catch continue;
        defer ctx.gpa.free(formatted);
        printStdout("{s}\n", .{formatted});
        if (d.phase != .emit and d.category == .error_) {
            ctx.any_errors.* = true;
            if (ctx.error_count) |ec| ec.* += 1;
            file_error_count += 1;
            if (!file_had_error) {
                file_had_error = true;
                if (ctx.files_with_errors) |fc| fc.* += 1;
                if (ctx.first_error_file) |fe| {
                    if (fe.*.len == 0) {
                        fe.* = f.path;
                        if (ctx.first_error_line) |fl| fl.* = pos.line;
                        if (ctx.first_error_col) |fcol| fcol.* = pos.col;
                    }
                }
            }
        }
    }
    if (file_error_count > 0) {
        if (ctx.error_file_counts) |counts| {
            for (counts.items) |*entry| {
                if (std.mem.eql(u8, entry.path, f.path)) {
                    entry.count += file_error_count;
                    return;
                }
            }
            counts.append(ctx.gpa, .{ .path = f.path, .count = file_error_count }) catch {};
        }
    }
}

fn decimalDigits(value: usize) usize {
    var n = value;
    var digits: usize = 1;
    while (n >= 10) : (digits += 1) n /= 10;
    return digits;
}

fn printErrorFileSummaryTable(counts: []const ErrorFileCount) void {
    if (counts.len == 0) return;
    var max_errors: usize = 0;
    for (counts) |entry| {
        if (entry.count > max_errors) max_errors = entry.count;
    }
    const left_heading_len = "Errors".len;
    const count_width = decimalDigits(max_errors);
    const left_padding_goal = @max(left_heading_len, count_width);
    const header_padding = if (count_width > left_heading_len) count_width - left_heading_len else 0;
    var i: usize = 0;
    while (i < header_padding) : (i += 1) printStdout(" ", .{});
    buildStatusMessage(6041, "Errors  Files\n", .{});
    for (counts) |entry| {
        const digits = decimalDigits(entry.count);
        var pad: usize = digits;
        while (pad < left_padding_goal) : (pad += 1) printStdout(" ", .{});
        printStdout("{d}  {s}\n", .{ entry.count, entry.path });
    }
}

/// Recursively map a driver elaboration chain into the renderer's
/// `ChainEntry` shape (message + children only; the renderer flattens
/// tsc-style without re-printing the per-entry code). Allocated in the
/// caller's arena.
fn mapDriverChain(
    arena: std.mem.Allocator,
    chain: []const ts_driver.DiagnosticChainEntry,
) error{OutOfMemory}![]const ts_diagnostics.ChainEntry {
    if (chain.len == 0) return &.{};
    const out = try arena.alloc(ts_diagnostics.ChainEntry, chain.len);
    for (chain, 0..) |entry, i| {
        out[i] = .{
            .message = entry.message,
            .children = try mapDriverChain(arena, entry.children),
        };
    }
    return out;
}

/// Map a driver diagnostic's related-info anchors into the renderer's
/// shape, resolving each anchor's byte `pos` to line:col against the
/// right file source. A null `file` anchors in the diagnostic's own file
/// (`primary`); a non-null `file` is a cross-file anchor (e.g. TS1377)
/// looked up in the program. If the cross-file source isn't available,
/// the anchor still renders its message (location omitted). Allocated in
/// the caller's arena.
fn mapDriverRelated(
    arena: std.mem.Allocator,
    program: *const ts_program.Program,
    primary: *const ts_program.File,
    related: []const ts_driver.RelatedInfo,
) error{OutOfMemory}![]const ts_diagnostics.Related {
    if (related.len == 0) return &.{};
    const out = try arena.alloc(ts_diagnostics.Related, related.len);
    for (related, 0..) |r, i| {
        const prefix: ts_diagnostics.Diagnostic.CodePrefix = switch (r.code_prefix) {
            .TS => .TS,
            .HM => .HM,
        };
        // Resolve the anchor's file + source.
        var anchor_file: []const u8 = primary.path;
        var anchor_source: ?[]const u8 = primary.source;
        if (r.file) |rf| {
            anchor_file = rf;
            if (program.lookupPath(rf)) |afid| {
                anchor_source = program.fileById(afid).source;
            } else {
                anchor_source = null; // source unavailable — omit location
            }
        }
        if (anchor_source) |src| {
            const lc = ts_diagnostics.positionToLineCol(src, r.pos);
            out[i] = .{ .file = anchor_file, .line = lc.line, .col = lc.col, .code = r.code, .code_prefix = prefix, .message = r.message };
        } else {
            out[i] = .{ .file = "", .code = r.code, .code_prefix = prefix, .message = r.message };
        }
    }
    return out;
}

/// Walk `project_dir` recursively, collect every TypeScript-shaped
/// file whose path (relative to the project) matches at least one
/// `include` glob and no `exclude` glob. Owned paths are stored in
/// `owned` so the caller can free them after compilation; borrowed
/// `[]const u8` slices into those owned bytes are appended to
/// `out`. Mirrors the file shapes tsc accepts by default;
/// JavaScript-family inputs participate only when `allowJs` is enabled.
fn expandProjectGlobs(
    gpa: std.mem.Allocator,
    project_dir: []const u8,
    include: []const []const u8,
    exclude: []const []const u8,
    allow_js: bool,
    out: *std.ArrayListUnmanaged([]const u8),
    owned: *std.ArrayListUnmanaged([]u8),
) !void {
    const exclude_base = try std.fs.path.resolve(gpa, &.{project_dir});
    defer gpa.free(exclude_base);

    // TypeScript retains wildcard matches in an extension-priority map rather
    // than appending every supported file. Keep this list separate from
    // `owned`: rejected and displaced allocations still remain owned by the
    // caller, while only the selected paths are appended to `out` below.
    var wildcard_files: std.ArrayListUnmanaged([]const u8) = .empty;
    defer wildcard_files.deinit(gpa);
    const case_sensitive_file_names = switch (builtin.os.tag) {
        .windows, .macos => false,
        else => true,
    };

    var threaded = std.Io.Threaded.init(gpa, .{});
    defer threaded.deinit();
    const io = threaded.io();
    const cwd = std.Io.Dir.cwd();
    var dir = cwd.openDir(io, project_dir, .{ .iterate = true }) catch return;
    defer dir.close(io);

    var stack: std.ArrayListUnmanaged([]u8) = .empty;
    defer {
        for (stack.items) |s| gpa.free(s);
        stack.deinit(gpa);
    }
    try stack.append(gpa, try gpa.dupe(u8, ""));

    while (stack.items.len > 0) {
        const rel = stack.pop().?;
        defer gpa.free(rel);

        const subdir_path = if (rel.len == 0)
            try gpa.dupe(u8, project_dir)
        else
            try std.fmt.allocPrint(gpa, "{s}/{s}", .{ project_dir, rel });
        defer gpa.free(subdir_path);

        var sub = cwd.openDir(io, subdir_path, .{ .iterate = true }) catch continue;
        defer sub.close(io);
        var iter = sub.iterate();
        while (iter.next(io) catch null) |entry| {
            const child_rel = if (rel.len == 0)
                try gpa.dupe(u8, entry.name)
            else
                try std.fmt.allocPrint(gpa, "{s}/{s}", .{ rel, entry.name });

            switch (entry.kind) {
                .directory => {
                    // TypeScript's wildcard matcher implicitly excludes dot
                    // directories and package folders, but a literal include
                    // component may opt back into them. Ask the include
                    // matcher whether any descendant can qualify instead of
                    // unconditionally dropping `node_modules`.
                    if (!anyFileIncludeMayMatchDirectory(include, child_rel)) {
                        gpa.free(child_rel);
                        continue;
                    }
                    if (anyMatches(exclude_base, exclude, child_rel)) {
                        gpa.free(child_rel);
                        continue;
                    }
                    try stack.append(gpa, child_rel);
                },
                .file => {
                    defer gpa.free(child_rel);
                    if (!isProjectInputExtension(child_rel, allow_js)) continue;
                    if (anyMatches(exclude_base, exclude, child_rel)) continue;
                    if (!anyFileIncludeMatches(include, child_rel)) continue;
                    const full = try std.fmt.allocPrint(gpa, "{s}/{s}", .{ project_dir, child_rel });
                    try owned.append(gpa, full);
                    var keep_candidate = true;
                    var selected_index: usize = 0;
                    while (selected_index < wildcard_files.items.len) {
                        switch (tsconfig_mod.projectInputPriorityRelation(
                            wildcard_files.items[selected_index],
                            full,
                            allow_js,
                            case_sensitive_file_names,
                        )) {
                            .same_path, .existing_preferred => {
                                keep_candidate = false;
                                break;
                            },
                            .candidate_preferred => {
                                _ = wildcard_files.orderedRemove(selected_index);
                            },
                            .unrelated, .coexist => selected_index += 1,
                        }
                    }
                    if (keep_candidate) try wildcard_files.append(gpa, full);
                },
                else => gpa.free(child_rel),
            }
        }
    }
    try out.appendSlice(gpa, wildcard_files.items);
}

fn anyMatches(project_dir: []const u8, patterns: []const []const u8, path: []const u8) bool {
    for (patterns) |raw_pattern| {
        var pattern = raw_pattern;
        while (std.mem.startsWith(u8, pattern, "./")) pattern = pattern[2..];
        while (pattern.len > 1 and (pattern[pattern.len - 1] == '/' or pattern[pattern.len - 1] == '\\')) {
            pattern = pattern[0 .. pattern.len - 1];
        }
        if (std.fs.path.isAbsolute(pattern)) {
            var base = project_dir;
            while (base.len > 1 and (base[base.len - 1] == '/' or base[base.len - 1] == '\\')) {
                base = base[0 .. base.len - 1];
            }
            if (std.mem.eql(u8, pattern, base)) return true;
            if (pattern.len <= base.len or
                !std.mem.eql(u8, pattern[0..base.len], base) or
                (pattern[base.len] != '/' and pattern[base.len] != '\\')) continue;
            pattern = pattern[base.len + 1 ..];
        }
        if (tsconfig_mod.matchGlob(pattern, path)) return true;
    }
    return false;
}

fn anyFileIncludeMatches(patterns: []const []const u8, path: []const u8) bool {
    for (patterns) |pattern| {
        if (tsconfig_mod.matchFileIncludeGlob(pattern, path)) return true;
    }
    return false;
}

fn anyFileIncludeMayMatchDirectory(patterns: []const []const u8, path: []const u8) bool {
    for (patterns) |pattern| {
        if (tsconfig_mod.fileIncludeGlobMayMatchDirectory(pattern, path)) return true;
    }
    return false;
}

fn isTsLikeExtension(path: []const u8) bool {
    if (std.mem.endsWith(u8, path, ".d.ts")) return true;
    if (std.mem.endsWith(u8, path, ".d.hm")) return true;
    if (std.mem.endsWith(u8, path, ".d.home")) return true;
    if (std.mem.endsWith(u8, path, ".ts")) return true;
    if (std.mem.endsWith(u8, path, ".tsx")) return true;
    if (std.mem.endsWith(u8, path, ".mts")) return true;
    if (std.mem.endsWith(u8, path, ".cts")) return true;
    if (std.mem.endsWith(u8, path, ".hm")) return true;
    if (std.mem.endsWith(u8, path, ".home")) return true;
    return false;
}

fn isProjectInputExtension(path: []const u8, allow_js: bool) bool {
    if (isTsLikeExtension(path)) return true;
    if (!allow_js) return false;
    return std.mem.endsWith(u8, path, ".js") or
        std.mem.endsWith(u8, path, ".jsx") or
        std.mem.endsWith(u8, path, ".mjs") or
        std.mem.endsWith(u8, path, ".cjs");
}

fn effectiveIncludePatterns(cfg: tsconfig_mod.TsConfig) []const []const u8 {
    return cfg.include orelse &[_][]const u8{"**/*"};
}

fn effectiveExcludeDiagnosticPatterns(
    gpa: std.mem.Allocator,
    project_dir: []const u8,
    cfg: tsconfig_mod.TsConfig,
    out: *std.ArrayListUnmanaged([]const u8),
    owned_defaults: *[2]?[]u8,
) ![]const []const u8 {
    if (cfg.exclude) |exclude| return exclude;
    var default_storage: [2][]const u8 = undefined;
    for (cfg.effectiveExcludePatterns(&default_storage), 0..) |pattern, index| {
        const display = if (std.fs.path.isAbsolute(pattern))
            pattern
        else blk: {
            const joined = try std.fs.path.join(gpa, &.{ project_dir, pattern });
            owned_defaults[index] = joined;
            break :blk joined;
        };
        try out.append(gpa, display);
    }
    return out.items;
}

/// TS5042: `--project` cannot be combined with positional source files.
/// Faithful port of the check in upstream `internal/execute/tsc.go`.
fn projectMixedWithSourceFilesDiagnostic(gpa: std.mem.Allocator) ![]u8 {
    const code: u32 = 5042;
    return try std.fmt.allocPrint(
        gpa,
        "error TS{d}: Option 'project' cannot be mixed with source files on a command line.",
        .{code},
    );
}

/// TS5112: a discovered tsconfig would be ignored because positional source
/// files were supplied without the explicit `--ignoreConfig` escape hatch.
fn positionalFilesBesideConfigDiagnostic(gpa: std.mem.Allocator) ![]u8 {
    const code: u32 = 5112;
    return try std.fmt.allocPrint(
        gpa,
        "error TS{d}: tsconfig.json is present but will not be loaded if files are specified on commandline. Use '--ignoreConfig' to skip this error.",
        .{code},
    );
}

/// TS5058: an explicit `--project` path (treated as a file because it
/// isn't an existing directory) does not exist on disk.
fn specifiedPathDoesNotExistDiagnostic(gpa: std.mem.Allocator, file_or_directory: []const u8) ![]u8 {
    const code: u32 = 5058;
    return try std.fmt.allocPrint(
        gpa,
        "error TS{d}: The specified path does not exist: '{s}'.",
        .{ code, file_or_directory },
    );
}

/// TS5081: `--project` named an existing directory but it has no
/// `tsconfig.json`. (Upstream uses the "current directory" message here
/// with the resolved `tsconfig.json` path as the argument.)
fn cannotFindTsConfigAtCurrentDirectoryDiagnostic(gpa: std.mem.Allocator, config_file_name: []const u8) ![]u8 {
    const code: u32 = 5081;
    return try std.fmt.allocPrint(
        gpa,
        "error TS{d}: Cannot find a tsconfig.json file at the current directory: {s}.",
        .{ code, config_file_name },
    );
}

fn noInputsFoundInConfigDiagnostic(
    gpa: std.mem.Allocator,
    config_path: []const u8,
    include_patterns: []const []const u8,
    exclude_patterns: []const []const u8,
) ![]u8 {
    const code: u32 = 18003;
    var include_json: std.ArrayListUnmanaged(u8) = .empty;
    defer include_json.deinit(gpa);
    var exclude_json: std.ArrayListUnmanaged(u8) = .empty;
    defer exclude_json.deinit(gpa);
    try appendJsonStringArray(&include_json, gpa, include_patterns);
    try appendJsonStringArray(&exclude_json, gpa, exclude_patterns);
    return try std.fmt.allocPrint(
        gpa,
        "error TS{d}: No inputs were found in config file '{s}'. Specified 'include' paths were '{s}' and 'exclude' paths were '{s}'.",
        .{ code, config_path, include_json.items, exclude_json.items },
    );
}

/// The TypeScript-supported source extensions, rendered in the exact
/// order and quoting tsc uses for the TS6054 message (`SupportedTSExt-
/// ensionsFlat`). Home additionally accepts its native `.hm`/`.home`
/// shapes, but those are deliberately omitted from the *diagnostic*
/// string so the message stays byte-identical to tsc.
const ts_supported_extensions_display = "'.ts', '.tsx', '.d.ts', '.cts', '.d.cts', '.mts', '.d.mts'";

/// Classification of an input file's extension for the file-add
/// extension checks (TS6504 / TS6054).
const ExtensionClass = enum {
    /// A TS/Home source extension the compiler accepts — no diagnostic.
    supported,
    /// A JavaScript-family extension (`.js`/`.jsx`/`.mjs`/`.cjs`).
    /// Reported as TS6504 when `allowJs` is off.
    javascript,
    /// Any other recognized-but-unsupported extension. Reported as
    /// TS6054. Extension-less paths are treated as supported (tsc only
    /// runs the check when the path `HasExtension`).
    unsupported,
};

fn classifyExtension(path: []const u8) ExtensionClass {
    // Home + TS source shapes the compiler can actually process.
    if (isTsLikeExtension(path)) return .supported;
    if (std.mem.endsWith(u8, path, ".js") or
        std.mem.endsWith(u8, path, ".jsx") or
        std.mem.endsWith(u8, path, ".mjs") or
        std.mem.endsWith(u8, path, ".cjs"))
    {
        return .javascript;
    }
    // Mirror tsc: only files that actually carry an extension are
    // candidates for the unsupported-extension diagnostic. A path with
    // no `.` in its basename is left alone.
    const base = std.fs.path.basename(path);
    if (std.mem.indexOfScalar(u8, base, '.') == null) return .supported;
    return .unsupported;
}

/// TS6504: an input file is a JavaScript file but `allowJs` is not set.
/// `{0}` is the file path. Caller frees.
fn javaScriptFileNeedsAllowJsDiagnostic(gpa: std.mem.Allocator, path: []const u8) ![]u8 {
    const code: u32 = 6504;
    return try std.fmt.allocPrint(
        gpa,
        "error TS{d}: File '{s}' is a JavaScript file. Did you mean to enable the 'allowJs' option?",
        .{ code, path },
    );
}

/// TS6054: an input file has an extension the compiler does not support.
/// `{0}` is the file path, `{1}` the supported-extension list. Caller
/// frees.
fn unsupportedExtensionDiagnostic(gpa: std.mem.Allocator, path: []const u8) ![]u8 {
    const code: u32 = 6054;
    return try std.fmt.allocPrint(
        gpa,
        "error TS{d}: File '{s}' has an unsupported extension. The only supported extensions are {s}.",
        .{ code, path, ts_supported_extensions_display },
    );
}

fn appendJsonStringArray(
    out: *std.ArrayListUnmanaged(u8),
    gpa: std.mem.Allocator,
    values: []const []const u8,
) !void {
    try out.append(gpa, '[');
    for (values, 0..) |value, i| {
        if (i > 0) try out.append(gpa, ',');
        try out.append(gpa, '"');
        for (value) |ch| {
            switch (ch) {
                '"' => try out.appendSlice(gpa, "\\\""),
                '\\' => try out.appendSlice(gpa, "\\\\"),
                '\n' => try out.appendSlice(gpa, "\\n"),
                '\r' => try out.appendSlice(gpa, "\\r"),
                '\t' => try out.appendSlice(gpa, "\\t"),
                else => {
                    if (ch < 0x20) {
                        const hex = "0123456789abcdef";
                        try out.appendSlice(gpa, "\\u00");
                        try out.append(gpa, hex[ch >> 4]);
                        try out.append(gpa, hex[ch & 0x0f]);
                    } else {
                        try out.append(gpa, ch);
                    }
                },
            }
        }
        try out.append(gpa, '"');
    }
    try out.append(gpa, ']');
}

/// Verify every prospective JavaScript/declaration output before list-only
/// reporting or emit. The returned count contributes to the global error
/// summary; `blocked_outputs` owns copies used to suppress only the colliding
/// writes when ordinary emit continues.
fn reportOutputCollisions(
    gpa: std.mem.Allocator,
    program: *const ts_program.Program,
    out_dir: ?[]const u8,
    declaration_dir: ?[]const u8,
    emit_dts: bool,
    no_emit: bool,
    has_config: bool,
    blocked_outputs: *std.ArrayListUnmanaged([]const u8),
) !usize {
    if (no_emit) return 0;

    var inputs: std.ArrayListUnmanaged([]const u8) = .empty;
    defer inputs.deinit(gpa);
    var outputs: std.ArrayListUnmanaged([]const u8) = .empty;
    defer {
        for (outputs.items) |path| gpa.free(path);
        outputs.deinit(gpa);
    }
    for (program.files.items) |file| {
        try inputs.append(gpa, file.path);
        if (file.compilation == null) continue;
        try outputs.append(gpa, try computeOutPath(gpa, file.path, out_dir, ".js"));
        if (emit_dts) try outputs.append(gpa, try computeOutPath(gpa, file.path, declaration_dir, ".d.ts"));
    }

    const collisions = try ts_cli.detectOutputCollisions(gpa, inputs.items, outputs.items, has_config);
    defer gpa.free(collisions);
    for (collisions) |collision| {
        const message = try ts_cli.formatOutputCollision(gpa, collision);
        defer gpa.free(message);
        printStdout("{s}\n", .{message});
        try blocked_outputs.append(gpa, try gpa.dupe(u8, collision.output_path));
    }
    return collisions.len;
}

/// Compute the output path for a source file with the given extension
/// (e.g. `.js`, `.d.ts`). With no out_dir, emit alongside the source
/// (`a.ts` → `a.js`). With an out_dir, mirror just the basename
/// (full path-mirroring vs. rootDir is a Phase 5 follow-up).
fn computeOutPath(gpa: std.mem.Allocator, src_path: []const u8, out_dir: ?[]const u8, ext: []const u8) ![]u8 {
    const ext_dot = std.mem.lastIndexOfScalar(u8, src_path, '.') orelse src_path.len;
    const stem = src_path[0..ext_dot];
    if (out_dir) |dir| {
        const base = std.fs.path.basename(stem);
        return try std.fmt.allocPrint(gpa, "{s}/{s}{s}", .{ dir, base, ext });
    }
    return try std.fmt.allocPrint(gpa, "{s}{s}", .{ stem, ext });
}

fn shouldLoadConfig(opts: ts_cli.Options) bool {
    return opts.project != null or opts.files.len == 0 or (opts.show_config and !opts.ignore_config);
}

fn shouldCheckPositionalConfig(opts: ts_cli.Options) bool {
    return opts.project == null and opts.files.len > 0 and !opts.ignore_config;
}

/// Resolve the path to a tsconfig.json. With an explicit `--project`
/// (file or directory), use it directly. Otherwise walk upward from
/// cwd looking for the nearest `tsconfig.json`. Returns a freshly
/// allocated path that the caller frees, or null when nothing is
/// found.
fn resolveTsConfigPath(gpa: std.mem.Allocator, project: ?[]const u8) !?[]u8 {
    var threaded = std.Io.Threaded.init(gpa, .{});
    defer threaded.deinit();
    const io = threaded.io();
    const cwd = std.Io.Dir.cwd();

    if (project) |p| {
        // If the path ends with .json, treat as the file directly;
        // otherwise treat as a directory and append `tsconfig.json`.
        if (std.mem.endsWith(u8, p, ".json")) {
            return try gpa.dupe(u8, p);
        }
        const joined = try std.fmt.allocPrint(gpa, "{s}/tsconfig.json", .{p});
        return joined;
    }

    // Upward walk. Use the absolute path of cwd so we know when we
    // hit the root.
    var dir_buf: [std.fs.max_path_bytes]u8 = undefined;
    const n = try std.process.currentPath(io, &dir_buf);
    var cur = try gpa.dupe(u8, dir_buf[0..n]);
    defer gpa.free(cur);
    while (cur.len > 0) {
        const candidate = try std.fmt.allocPrint(gpa, "{s}/tsconfig.json", .{cur});
        // Try to stat — if it exists, return.
        const exists = blk: {
            var f = cwd.openFile(io, candidate, .{}) catch break :blk false;
            f.close(io);
            break :blk true;
        };
        if (exists) return candidate;
        gpa.free(candidate);
        const parent = std.fs.path.dirname(cur) orelse break;
        if (std.mem.eql(u8, parent, cur)) break;
        const new_cur = try gpa.dupe(u8, parent);
        gpa.free(cur);
        cur = new_cur;
    }
    return null;
}

test "tsc_main: TS5042 project mixed with source files diagnostic" {
    const msg = try projectMixedWithSourceFilesDiagnostic(std.testing.allocator);
    defer std.testing.allocator.free(msg);
    try std.testing.expectEqualStrings(
        "error TS5042: Option 'project' cannot be mixed with source files on a command line.",
        msg,
    );
}

test "tsc_main: TS5112 positional files beside discovered config diagnostic" {
    const msg = try positionalFilesBesideConfigDiagnostic(std.testing.allocator);
    defer std.testing.allocator.free(msg);
    try std.testing.expectEqualStrings(
        "error TS5112: tsconfig.json is present but will not be loaded if files are specified on commandline. Use '--ignoreConfig' to skip this error.",
        msg,
    );
}

test "tsc_main: TypeScript 7 removed option diagnostic retains config value location" {
    var arena = std.heap.ArenaAllocator.init(std.testing.allocator);
    defer arena.deinit();
    const source =
        \\{
        \\  "compilerOptions": {
        \\    "ignoreDeprecations": "6.0",
        \\    "moduleResolution": "node10"
        \\  }
        \\}
    ;
    var cfg = try tsconfig_mod.parseString(std.testing.allocator, arena.allocator(), source);
    cfg.file_path = "/repo/tsconfig.json";
    const diagnostics = try cfg.validate(std.testing.allocator);
    defer tsconfig_mod.freeValidationDiagnostics(std.testing.allocator, diagnostics);
    var removed: ?tsconfig_mod.ValidationDiagnostic = null;
    for (diagnostics) |diagnostic| {
        if (diagnostic.code == 5108) removed = diagnostic;
    }
    const formatted = try config_diagnostics.format(std.testing.allocator, cfg, source, removed.?, false, false);
    defer std.testing.allocator.free(formatted);
    try std.testing.expectEqualStrings(
        "/repo/tsconfig.json(4,25): error TS5108: Option 'moduleResolution=node10' has been removed. Please remove it from your configuration.",
        formatted,
    );
}

test "tsc_main: option-diagnostic precedence probes syntax errors only" {
    var probe: SyntaxDiagnosticProbe = .{};
    const semantic = [_]ts_driver.Diagnostic{.{
        .phase = .bind,
        .pos = 0,
        .line = 1,
        .code = 2322,
        .message = "Type mismatch.",
    }};
    probe.receive("/repo/a.ts", &semantic);
    try std.testing.expect(!probe.has_errors);

    const syntax = [_]ts_driver.Diagnostic{.{
        .phase = .parse,
        .pos = 0,
        .line = 1,
        .code = 1109,
        .message = "Expression expected.",
    }};
    probe.receive("/repo/a.ts", &syntax);
    try std.testing.expect(probe.has_errors);
}

test "tsc_main: ignoreConfig only suppresses config discovery beside positional files" {
    const files = [_][]const u8{"entry.ts"};
    try std.testing.expect(!shouldLoadConfig(.{ .files = &files }));
    try std.testing.expect(shouldCheckPositionalConfig(.{ .files = &files }));
    try std.testing.expect(shouldLoadConfig(.{ .files = &files, .show_config = true }));
    try std.testing.expect(shouldCheckPositionalConfig(.{ .files = &files, .show_config = true }));
    try std.testing.expect(!shouldLoadConfig(.{ .files = &files, .show_config = true, .ignore_config = true }));
    try std.testing.expect(!shouldCheckPositionalConfig(.{ .files = &files, .show_config = true, .ignore_config = true }));
    try std.testing.expect(shouldLoadConfig(.{ .ignore_config = true }));
    try std.testing.expect(!shouldCheckPositionalConfig(.{ .ignore_config = true }));
    try std.testing.expect(shouldLoadConfig(.{ .files = &files, .project = "tsconfig.json", .ignore_config = true }));
    try std.testing.expect(!shouldCheckPositionalConfig(.{ .files = &files, .project = "tsconfig.json", .ignore_config = true }));
}

test "tsc_main: command-line skipLibCheck overrides config in both directions" {
    var compile_opts: ts_driver.CompileOptions = .{ .skip_lib_check = false };
    ts_cli.applyCompileOptions(&compile_opts, .{ .skip_lib_check = true });
    try std.testing.expect(compile_opts.skip_lib_check);

    compile_opts.skip_lib_check = true;
    ts_cli.applyCompileOptions(&compile_opts, .{ .skip_lib_check = false });
    try std.testing.expect(!compile_opts.skip_lib_check);

    compile_opts.skip_lib_check = true;
    ts_cli.applyCompileOptions(&compile_opts, .{});
    try std.testing.expect(compile_opts.skip_lib_check);
}

test "tsc_main: build info retains maxNodeModuleJsDepth" {
    var arena = std.heap.ArenaAllocator.init(std.testing.allocator);
    defer arena.deinit();
    const cfg = try tsconfig_mod.parseString(std.testing.allocator, arena.allocator(),
        \\{ "compilerOptions": { "maxNodeModuleJsDepth": 2 } }
    );
    const options_json = try buildInfoOptionsJson(std.testing.allocator, cfg);
    defer std.testing.allocator.free(options_json);
    try std.testing.expect(std.mem.indexOf(u8, options_json, "\"maxNodeModuleJsDepth\":2") != null);
}

test "tsc_main: TS5058 specified path does not exist diagnostic" {
    const msg = try specifiedPathDoesNotExistDiagnostic(std.testing.allocator, "./missing.json");
    defer std.testing.allocator.free(msg);
    try std.testing.expectEqualStrings(
        "error TS5058: The specified path does not exist: './missing.json'.",
        msg,
    );
}

test "tsc_main: TS5081 cannot find tsconfig at current directory diagnostic" {
    const msg = try cannotFindTsConfigAtCurrentDirectoryDiagnostic(std.testing.allocator, "/repo/sub/tsconfig.json");
    defer std.testing.allocator.free(msg);
    try std.testing.expectEqualStrings(
        "error TS5081: Cannot find a tsconfig.json file at the current directory: /repo/sub/tsconfig.json.",
        msg,
    );
}

test "tsc_main: TS6306 referenced project must be composite diagnostic" {
    const msg = try referencedProjectMustBeCompositeDiagnostic(std.testing.allocator, "../lib");
    defer std.testing.allocator.free(msg);
    try std.testing.expectEqualStrings(
        "error TS6306: Referenced project '../lib' must have setting \"composite\": true.",
        msg,
    );
}

test "tsc_main: TS6310 referenced project may not disable emit diagnostic" {
    const msg = try referencedProjectMayNotDisableEmitDiagnostic(std.testing.allocator, "../lib");
    defer std.testing.allocator.free(msg);
    try std.testing.expectEqualStrings(
        "error TS6310: Referenced project '../lib' may not disable emit.",
        msg,
    );
}

test "tsc_main: project build info path resolves explicit relative path" {
    var arena_state = std.heap.ArenaAllocator.init(std.testing.allocator);
    defer arena_state.deinit();
    const arena = arena_state.allocator();
    const cfg = try tsconfig_mod.parseString(std.testing.allocator, arena,
        \\{ "compilerOptions": { "composite": true, "tsBuildInfoFile": "../shared.tsbuildinfo" } }
    );
    const path = (try projectBuildInfoFilePath(arena, "/repo/app/tsconfig.json", cfg)).?;
    try std.testing.expectEqualStrings("/repo/shared.tsbuildinfo", path);
}

test "tsc_main: project build info path follows Home default convention" {
    var arena_state = std.heap.ArenaAllocator.init(std.testing.allocator);
    defer arena_state.deinit();
    const arena = arena_state.allocator();
    const cfg = try tsconfig_mod.parseString(std.testing.allocator, arena,
        \\{ "compilerOptions": { "incremental": true, "outDir": "dist" } }
    );
    const path = (try projectBuildInfoFilePath(arena, "/repo/app/tsconfig.json", cfg)).?;
    try std.testing.expectEqualStrings("/repo/app/dist/tsconfig.tsbuildinfo", path);
}

test "tsc_main: TS6377 referenced project build info overwrite diagnostic" {
    const msg = try referencedProjectBuildInfoOverwriteDiagnostic(std.testing.allocator, "/repo/shared.tsbuildinfo", "../lib");
    defer std.testing.allocator.free(msg);
    try std.testing.expectEqualStrings(
        "error TS6377: Cannot write file '/repo/shared.tsbuildinfo' because it will overwrite '.tsbuildinfo' file generated by referenced project '../lib'.",
        msg,
    );
}

test "tsc_main: TS6354 status is selected after an upstream dependency build with unchanged dts" {
    try std.testing.expect(shouldReportUpToDateWithDtsFilesFromDependencies(true));
    try std.testing.expect(!shouldReportUpToDateWithDtsFilesFromDependencies(false));
}

test "tsc_main: TS18003 no-input config diagnostic uses include and exclude specs" {
    const include = [_][]const u8{ "src/**/*.ts", "tests/**/*.ts" };
    const exclude = [_][]const u8{"dist"};
    const msg = try noInputsFoundInConfigDiagnostic(std.testing.allocator, "/repo/tsconfig.json", &include, &exclude);
    defer std.testing.allocator.free(msg);
    try std.testing.expectEqualStrings(
        "error TS18003: No inputs were found in config file '/repo/tsconfig.json'. Specified 'include' paths were '[\"src/**/*.ts\",\"tests/**/*.ts\"]' and 'exclude' paths were '[\"dist\"]'.",
        msg,
    );
}

test "tsc_main: TS18003 no-input config diagnostic preserves empty include list" {
    const include = [_][]const u8{};
    const exclude = [_][]const u8{};
    const msg = try noInputsFoundInConfigDiagnostic(std.testing.allocator, "tsconfig.json", &include, &exclude);
    defer std.testing.allocator.free(msg);
    try std.testing.expectEqualStrings(
        "error TS18003: No inputs were found in config file 'tsconfig.json'. Specified 'include' paths were '[]' and 'exclude' paths were '[]'.",
        msg,
    );
}

test "tsc_main: project excludes normalize config-relative directory syntax" {
    const relative = [_][]const u8{"./OutDir"};
    try std.testing.expect(anyMatches("/repo", &relative, "OutDir"));

    const repeated = [_][]const u8{"././generated/"};
    try std.testing.expect(anyMatches("/repo", &repeated, "generated"));
    try std.testing.expect(!anyMatches("/repo", &repeated, "src/generated"));

    const absolute = [_][]const u8{"/repo/OutDir"};
    try std.testing.expect(anyMatches("/repo", &absolute, "OutDir"));
    try std.testing.expect(!anyMatches("/other", &absolute, "OutDir"));
}

test "tsc_main: TS18003 diagnostic uses implicit output directory exclude display" {
    var arena = std.heap.ArenaAllocator.init(std.testing.allocator);
    defer arena.deinit();
    const cfg = try tsconfig_mod.parseString(std.testing.allocator, arena.allocator(),
        \\{ "compilerOptions": { "outDir": "dist", "declarationDir": "types" } }
    );
    var out: std.ArrayListUnmanaged([]const u8) = .empty;
    defer out.deinit(std.testing.allocator);
    var owned: [2]?[]u8 = .{ null, null };
    defer for (owned) |path| if (path) |p| std.testing.allocator.free(p);

    const patterns = try effectiveExcludeDiagnosticPatterns(std.testing.allocator, "/repo", cfg, &out, &owned);
    try std.testing.expectEqual(@as(usize, 2), patterns.len);
    try std.testing.expectEqualStrings("/repo/dist", patterns[0]);
    try std.testing.expectEqualStrings("/repo/types", patterns[1]);
}

test "tsc_main: TS6504 JavaScript-file diagnostic text" {
    const msg = try javaScriptFileNeedsAllowJsDiagnostic(std.testing.allocator, "src/app.js");
    defer std.testing.allocator.free(msg);
    try std.testing.expectEqualStrings(
        "error TS6504: File 'src/app.js' is a JavaScript file. Did you mean to enable the 'allowJs' option?",
        msg,
    );
}

test "tsc_main: TS6054 unsupported-extension diagnostic text" {
    const msg = try unsupportedExtensionDiagnostic(std.testing.allocator, "data/notes.txt");
    defer std.testing.allocator.free(msg);
    try std.testing.expectEqualStrings(
        "error TS6054: File 'data/notes.txt' has an unsupported extension. The only supported extensions are '.ts', '.tsx', '.d.ts', '.cts', '.d.cts', '.mts', '.d.mts'.",
        msg,
    );
}

test "tsc_main: direct exported values remain runtime values when aggregate origins are incomplete" {
    const origin: ts_program.export_origins.Origin = .{ .path = "/owner.ts", .position = 1, .kind = .declaration };
    try std.testing.expectEqual(@as(?bool, true), CheckerResolverAdapter.runtimeValueFromExportFacts(null, true));
    try std.testing.expectEqual(@as(?bool, null), CheckerResolverAdapter.runtimeValueFromExportFacts(null, false));
    try std.testing.expectEqual(@as(?bool, true), CheckerResolverAdapter.runtimeValueFromExportFacts(.{ .value = origin }, false));
    try std.testing.expectEqual(@as(?bool, false), CheckerResolverAdapter.runtimeValueFromExportFacts(.{}, true));
}

test "tsc_main: resolver adapter preserves generic functions through js export stars" {
    var vfs = ts_resolver.VirtualFs.init(std.testing.allocator);
    defer vfs.deinit();
    try vfs.addFile(
        "/owner.ts",
        "export function $constructor<T>(value: T): T { return value; }",
    );
    try vfs.addFile("/barrel.ts", "export * from \"./owner.js\";");
    var resolver = ts_resolver.Resolver.init(std.testing.allocator, vfs.fs(), .{});
    defer resolver.deinit();
    var adapter = CheckerResolverAdapter.init(std.testing.allocator, &resolver);
    defer adapter.deinit();

    const info = CheckerResolverAdapter.moduleExportImpl(
        &adapter,
        "./barrel.js",
        "/consumer.ts",
        "$constructor",
    ) orelse return error.TestUnexpectedResult;
    try std.testing.expect(info.exported_value);
    try std.testing.expect(info.generic_function);
    try std.testing.expect(info.call_only_function);
}

test "tsc_main: resolver admission distinguishes typed JS from untyped implementations" {
    var vfs = ts_resolver.VirtualFs.init(std.testing.allocator);
    defer vfs.deinit();
    try vfs.addFile("/project.js", "exports.named = 1;");
    try vfs.addFile("/unadmitted.js", "exports.named = 1;");
    try vfs.addFile("/node_modules/explicit/index.js", "exports.named = 1;");
    var resolver = ts_resolver.Resolver.init(std.testing.allocator, vfs.fs(), .{});
    defer resolver.deinit();
    var program = ts_program.Program.init(std.testing.allocator, &resolver);
    defer program.deinit();
    _ = try program.add("/project.js", "exports.named = 1;");
    _ = try program.add("/node_modules/explicit/index.js", "exports.named = 1;");
    var adapter = CheckerResolverAdapter.init(std.testing.allocator, &resolver);
    defer adapter.deinit();
    for ([_]ts_driver.CompileOptions{ .{}, .{ .allow_js = true }, .{ .check_js = true } }) |options| {
        adapter.setProgramSources(&program, options);
        const project = CheckerResolverAdapter.resolveImpl(&adapter, "./project.js", "/main.ts").?;
        const explicit = CheckerResolverAdapter.resolveImpl(&adapter, "./node_modules/explicit/index.js", "/main.ts").?;
        const unadmitted = CheckerResolverAdapter.resolveImpl(&adapter, "./unadmitted.js", "/main.ts").?;
        try std.testing.expectEqual(options.allow_js or options.check_js, project.is_declaration);
        try std.testing.expectEqual(options.allow_js or options.check_js, explicit.is_declaration);
        try std.testing.expect(!unadmitted.is_declaration);
    }
}

test "tsc_main: explicit package include selects the actual root pattern" {
    const root: RootInclusion = .{
        .code = 1407,
        .specs = &.{ "**/*", "node_modules/**/*" },
        .project_dir = "/repo",
        .config_path = "/repo/tsconfig.json",
    };
    try std.testing.expectEqualStrings(
        "**/*",
        matchingRootIncludeSpec(root, "/repo/root.ts"),
    );
    try std.testing.expectEqualStrings(
        "node_modules/**/*",
        matchingRootIncludeSpec(root, "/repo/node_modules/pkg/index.js"),
    );
    var root_directory = root;
    root_directory.project_dir = "/";
    try std.testing.expectEqualStrings(
        "node_modules/**/*",
        matchingRootIncludeSpec(root_directory, "/node_modules/pkg/index.js"),
    );
    try std.testing.expect(anyFileIncludeMayMatchDirectory(root.specs, "node_modules"));
    try std.testing.expect(anyFileIncludeMatches(root.specs, "node_modules/pkg/index.js"));
}

test "tsc_main: resolver admission follows maxNodeModuleJsDepth" {
    const main_source =
        \\import { value } from 'pkg';
        \\const bad: string = value;
    ;
    var vfs = ts_resolver.VirtualFs.init(std.testing.allocator);
    defer vfs.deinit();
    try vfs.addFile("/proj/main.ts", main_source);
    try vfs.addFile("/proj/node_modules/pkg/package.json", "{\"main\":\"index.js\"}");
    try vfs.addFile("/proj/node_modules/pkg/index.js", "exports.value = 1;\n");
    var resolver = ts_resolver.Resolver.init(std.testing.allocator, vfs.fs(), .{
        .strategy = .nodenext,
        .module_kind = "nodenext",
    });
    defer resolver.deinit();
    var adapter = CheckerResolverAdapter.init(std.testing.allocator, &resolver);
    defer adapter.deinit();

    var default_program = ts_program.Program.init(std.testing.allocator, &resolver);
    defer default_program.deinit();
    _ = try default_program.add("/proj/main.ts", main_source);
    var default_options: ts_driver.CompileOptions = .{ .allow_js = true, .check_js = true, .no_emit = true };
    adapter.setProgramSources(&default_program, default_options);
    default_options.external_resolver = .{ .ptr = &adapter, .vtable = &CheckerResolverAdapter.vtable };
    try std.testing.expectEqual(@as(usize, 0), try default_program.loadImportClosure(default_options));
    try std.testing.expect(!CheckerResolverAdapter.resolveImpl(&adapter, "pkg", "/proj/main.ts").?.is_declaration);

    var depth_one_program = ts_program.Program.init(std.testing.allocator, &resolver);
    defer depth_one_program.deinit();
    _ = try depth_one_program.add("/proj/main.ts", main_source);
    var depth_one_options: ts_driver.CompileOptions = .{
        .allow_js = true,
        .check_js = true,
        .no_emit = true,
        .max_node_module_js_depth = 1,
    };
    adapter.setProgramSources(&depth_one_program, depth_one_options);
    depth_one_options.external_resolver = .{ .ptr = &adapter, .vtable = &CheckerResolverAdapter.vtable };
    try std.testing.expectEqual(@as(usize, 1), try depth_one_program.loadImportClosure(depth_one_options));
    try std.testing.expect(CheckerResolverAdapter.resolveImpl(&adapter, "pkg", "/proj/main.ts").?.is_declaration);
    const main_id = depth_one_program.lookupPath("/proj/main.ts") orelse return error.TestUnexpectedResult;
    var saw_imported_type_error = false;
    for (depth_one_program.fileById(main_id).compilation.?.diagnostics.items) |diagnostic| {
        if (diagnostic.code == 2322) saw_imported_type_error = true;
    }
    try std.testing.expect(saw_imported_type_error);
}

test "tsc_main: resolver adapter prefers sibling declarations over admitted package JavaScript" {
    const main_source =
        \\import * as m4 from 'm4';
        \\const value: number = m4.foo;
    ;
    var vfs = ts_resolver.VirtualFs.init(std.testing.allocator);
    defer vfs.deinit();
    try vfs.addFile("/proj/main.ts", main_source);
    try vfs.addFile("/proj/node_modules/m4/package.json", "{\"name\":\"m4\",\"version\":\"1.0.0\",\"main\":\"entry.js\"}");
    try vfs.addFile("/proj/node_modules/m4/entry.js", "exports.test = 'implementation';\n");
    try vfs.addFile("/proj/node_modules/@types/m4/package.json", "{\"name\":\"m4\",\"version\":\"1.0.0\",\"types\":\"entry.d.ts\"}");
    try vfs.addFile("/proj/node_modules/@types/m4/entry.d.ts", "export declare const foo: number;\n");

    var resolver = ts_resolver.Resolver.init(std.testing.allocator, vfs.fs(), .{});
    defer resolver.deinit();
    var program = ts_program.Program.init(std.testing.allocator, &resolver);
    defer program.deinit();
    _ = try program.add("/proj/main.ts", main_source);
    const options: ts_driver.CompileOptions = .{
        .allow_js = true,
        .check_js = true,
        .max_node_module_js_depth = 3,
        .no_emit = true,
    };
    try std.testing.expectEqual(@as(usize, 1), try program.loadImportClosure(options));
    try std.testing.expect(program.lookupPath("/proj/node_modules/m4/entry.js") == null);

    var adapter = CheckerResolverAdapter.init(std.testing.allocator, &resolver);
    defer adapter.deinit();
    adapter.setProgramSources(&program, options);
    const resolved = CheckerResolverAdapter.resolveImpl(&adapter, "m4", "/proj/main.ts") orelse return error.TestUnexpectedResult;
    try std.testing.expectEqualStrings("/proj/node_modules/@types/m4/entry.d.ts", resolved.path);
    try std.testing.expect(resolved.is_declaration);
    const foo = CheckerResolverAdapter.moduleExportImpl(&adapter, "m4", "/proj/main.ts", "foo") orelse return error.TestUnexpectedResult;
    try std.testing.expect(foo.exported_value);
    const implementation_only = CheckerResolverAdapter.moduleExportImpl(&adapter, "m4", "/proj/main.ts", "test") orelse return error.TestUnexpectedResult;
    try std.testing.expect(!implementation_only.exported_value);
}

test "tsc_main: resolver adapter uses admitted in-memory JavaScript revision" {
    var vfs = ts_resolver.VirtualFs.init(std.testing.allocator);
    defer vfs.deinit();
    try vfs.addFile("/owner.js", "exports.oldValue = 1;");
    var resolver = ts_resolver.Resolver.init(std.testing.allocator, vfs.fs(), .{});
    defer resolver.deinit();
    var program = ts_program.Program.init(std.testing.allocator, &resolver);
    defer program.deinit();
    _ = try program.add("/owner.js", "exports.currentValue = 1;");
    const options: ts_driver.CompileOptions = .{ .allow_js = true, .check_js = true, .no_emit = true };
    try program.compileAll(options);

    var adapter = CheckerResolverAdapter.init(std.testing.allocator, &resolver);
    defer adapter.deinit();
    adapter.setProgramSources(&program, options);
    const current = CheckerResolverAdapter.moduleExportImpl(
        &adapter,
        "./owner.js",
        "/consumer.ts",
        "currentValue",
    ) orelse return error.TestUnexpectedResult;
    const old = CheckerResolverAdapter.moduleExportImpl(
        &adapter,
        "./owner.js",
        "/consumer.ts",
        "oldValue",
    ) orelse return error.TestUnexpectedResult;
    try std.testing.expect(current.exported_value);
    try std.testing.expect(!old.exported_value);
}

test "tsc_main: resolver adapter carries prepared local import facts" {
    var vfs = ts_resolver.VirtualFs.init(std.testing.allocator);
    defer vfs.deinit();
    try vfs.addFile("/owner.ts", "const hidden = 1; export { hidden as public };");
    var resolver = ts_resolver.Resolver.init(std.testing.allocator, vfs.fs(), .{});
    defer resolver.deinit();
    var adapter = CheckerResolverAdapter.init(std.testing.allocator, &resolver);
    defer adapter.deinit();

    const hidden = CheckerResolverAdapter.moduleExportImpl(
        &adapter,
        "./owner",
        "/consumer.ts",
        "hidden",
    ) orelse return error.TestUnexpectedResult;
    try std.testing.expect(!hidden.exported_value);
    try std.testing.expect(hidden.declares_local);
    try std.testing.expectEqualStrings("public", hidden.local_exported_as);

    const public = CheckerResolverAdapter.moduleExportImpl(
        &adapter,
        "./owner",
        "/consumer.ts",
        "public",
    ) orelse return error.TestUnexpectedResult;
    try std.testing.expect(public.exported_value);
}

test "tsc_main: classifyExtension recognizes TS, Home, JS and unsupported shapes" {
    try std.testing.expectEqual(ExtensionClass.supported, classifyExtension("a.ts"));
    try std.testing.expectEqual(ExtensionClass.supported, classifyExtension("a.tsx"));
    try std.testing.expectEqual(ExtensionClass.supported, classifyExtension("a.d.ts"));
    try std.testing.expectEqual(ExtensionClass.supported, classifyExtension("a.mts"));
    try std.testing.expectEqual(ExtensionClass.supported, classifyExtension("a.cts"));
    try std.testing.expectEqual(ExtensionClass.supported, classifyExtension("a.hm"));
    try std.testing.expectEqual(ExtensionClass.supported, classifyExtension("a.home"));
    // JS family -> TS6504 candidate.
    try std.testing.expectEqual(ExtensionClass.javascript, classifyExtension("a.js"));
    try std.testing.expectEqual(ExtensionClass.javascript, classifyExtension("a.jsx"));
    try std.testing.expectEqual(ExtensionClass.javascript, classifyExtension("a.mjs"));
    try std.testing.expectEqual(ExtensionClass.javascript, classifyExtension("a.cjs"));
    // Anything else with an extension -> TS6054 candidate.
    try std.testing.expectEqual(ExtensionClass.unsupported, classifyExtension("a.txt"));
    try std.testing.expectEqual(ExtensionClass.unsupported, classifyExtension("a.json"));
    // No extension -> left alone (matches tsc's HasExtension gate).
    try std.testing.expectEqual(ExtensionClass.supported, classifyExtension("Makefile"));
    try std.testing.expectEqual(ExtensionClass.supported, classifyExtension("src/noext"));
}

test "tsc_main: project discovery uses effective allowJs" {
    try std.testing.expect(isProjectInputExtension("src/app.ts", false));
    try std.testing.expect(!isProjectInputExtension("src/app.js", false));
    try std.testing.expect(!isProjectInputExtension("src/app.jsx", false));
    try std.testing.expect(!isProjectInputExtension("src/app.mjs", false));
    try std.testing.expect(!isProjectInputExtension("src/app.cjs", false));

    try std.testing.expect(isProjectInputExtension("src/app.js", true));
    try std.testing.expect(isProjectInputExtension("src/app.jsx", true));
    try std.testing.expect(isProjectInputExtension("src/app.mjs", true));
    try std.testing.expect(isProjectInputExtension("src/app.cjs", true));
    try std.testing.expect(!isProjectInputExtension("src/app.json", true));

    const implicit: tsconfig_mod.CompilerOptions = .{ .check_js = true };
    try std.testing.expect(isProjectInputExtension("src/app.js", tsconfig_mod.effectiveAllowJs(implicit)));
    const disabled: tsconfig_mod.CompilerOptions = .{ .allow_js = false, .check_js = true };
    try std.testing.expect(!isProjectInputExtension("src/app.js", tsconfig_mod.effectiveAllowJs(disabled)));
}

test "tsc_main: wildcard discovery honors TypeScript extension priority" {
    var tmp = std.testing.tmpDir(.{});
    defer tmp.cleanup();

    const io = std.testing.io;
    for ([_][]const u8{
        "a.d.ts", "a.js",  "a.ts",
        "b.d.ts", "b.js",  "c.d.mts",
        "c.mjs",  "c.mts",
    }) |name| {
        var file = try tmp.dir.createFile(io, name, .{ .truncate = true });
        file.close(io);
    }
    const root = try tmp.dir.realPathFileAlloc(io, ".", std.testing.allocator);
    defer std.testing.allocator.free(root);

    var selected: std.ArrayListUnmanaged([]const u8) = .empty;
    defer selected.deinit(std.testing.allocator);
    var owned: std.ArrayListUnmanaged([]u8) = .empty;
    defer {
        for (owned.items) |path| std.testing.allocator.free(path);
        owned.deinit(std.testing.allocator);
    }
    try expandProjectGlobs(
        std.testing.allocator,
        root,
        &[_][]const u8{"**/*"},
        &.{},
        true,
        &selected,
        &owned,
    );

    try std.testing.expectEqual(@as(usize, 4), selected.items.len);
    for ([_][]const u8{ "a.ts", "b.d.ts", "b.js", "c.mts" }) |name| {
        const path = try std.fs.path.join(std.testing.allocator, &.{ root, name });
        defer std.testing.allocator.free(path);
        try std.testing.expect(pathInList(selected.items, path));
    }
    for ([_][]const u8{ "a.d.ts", "a.js", "c.d.mts", "c.mjs" }) |name| {
        const path = try std.fs.path.join(std.testing.allocator, &.{ root, name });
        defer std.testing.allocator.free(path);
        try std.testing.expect(!pathInList(selected.items, path));
    }
}

test "tsc_main: TS18003 diagnostic JSON-escapes control characters" {
    const include = [_][]const u8{"src/\x01*.ts"};
    const exclude = [_][]const u8{};
    const msg = try noInputsFoundInConfigDiagnostic(std.testing.allocator, "tsconfig.json", &include, &exclude);
    defer std.testing.allocator.free(msg);

    try std.testing.expect(std.mem.indexOf(u8, msg, "src/\\u0001*.ts") != null);
}

test "tsc_main: TS1261 reports input files that differ only by casing" {
    const exact = [_][]const u8{ "/repo/src/foo.ts", "/repo/src/foo.ts" };
    try std.testing.expect(findCaseOnlyInputFileMismatch(&exact) == null);

    const mismatch = [_][]const u8{ "/repo/src/foo.ts", "/repo/src/Foo.ts" };
    const found = findCaseOnlyInputFileMismatch(&mismatch) orelse return error.TestExpectedSome;
    try std.testing.expectEqualStrings("/repo/src/Foo.ts", found.file_name);
    try std.testing.expectEqualStrings("/repo/src/foo.ts", found.existing_file_name);
    try std.testing.expectEqual(@as(usize, 1), found.file_index);
    try std.testing.expectEqual(@as(usize, 0), found.existing_file_index);

    const msg = try alreadyIncludedFileNameDiffersOnlyInCasingDiagnostic(std.testing.allocator, found, &.{}, &.{});
    defer std.testing.allocator.free(msg);
    try std.testing.expectEqualStrings(
        "error TS1261: Already included file name '/repo/src/Foo.ts' differs from file name '/repo/src/foo.ts' only in casing.",
        msg,
    );
}

test "tsc_main: TS1261 carries config-root related information for files and include" {
    const mismatch = CaseOnlyInputFileMismatch{
        .file_name = "src/Foo.ts",
        .existing_file_name = "src/foo.ts",
        .file_index = 1,
        .existing_file_index = 0,
    };

    const config_source =
        \\{
        \\  "files": ["src/foo.ts", "src/Foo.ts"],
        \\  "include": ["src/**/*"]
        \\}
    ;

    const files = [_][]const u8{ "src/foo.ts", "src/Foo.ts" };
    var files_related_buf: [2]ts_diagnostics.Related = undefined;
    const files_related = caseOnlyInputRelatedInfo(.{
        .kind = .files,
        .config_path = "/repo/tsconfig.json",
        .config_source = config_source,
        .specs = &files,
    }, mismatch, &files_related_buf);
    try std.testing.expectEqual(@as(usize, 2), files_related.len);
    try std.testing.expectEqual(@as(u32, 1410), files_related[0].code);
    try std.testing.expectEqualStrings("File is matched by 'files' list specified here.", files_related[0].message);

    var chain_top_buf: [1]ts_diagnostics.ChainEntry = undefined;
    var chain_child_buf: [1]ts_diagnostics.ChainEntry = undefined;
    var owned_chain_child_message: ?[]u8 = null;
    defer if (owned_chain_child_message) |msg| std.testing.allocator.free(msg);
    const files_chain = try caseOnlyInputReasonChain(std.testing.allocator, .{
        .kind = .files,
        .config_path = "/repo/tsconfig.json",
        .config_source = config_source,
        .specs = &files,
    }, &chain_top_buf, &chain_child_buf, &owned_chain_child_message);
    const files_msg = try alreadyIncludedFileNameDiffersOnlyInCasingDiagnostic(std.testing.allocator, mismatch, files_chain, files_related);
    defer std.testing.allocator.free(files_msg);
    try std.testing.expect(std.mem.indexOf(u8, files_msg, "\n  The file is in the program because:\n    Part of 'files' list in tsconfig.json") != null);
    try std.testing.expect(std.mem.indexOf(u8, files_msg, "/repo/tsconfig.json(2,13): File is matched by 'files' list specified here.") != null);
    try std.testing.expect(std.mem.indexOf(u8, files_msg, "/repo/tsconfig.json(2,27): File is matched by 'files' list specified here.") != null);

    const include = [_][]const u8{"src/**/*"};
    var include_related_buf: [2]ts_diagnostics.Related = undefined;
    const include_related = caseOnlyInputRelatedInfo(.{
        .kind = .include,
        .config_path = "/repo/tsconfig.json",
        .config_source = config_source,
        .specs = &include,
    }, mismatch, &include_related_buf);
    try std.testing.expectEqual(@as(usize, 2), include_related.len);
    try std.testing.expectEqual(@as(u32, 1408), include_related[0].code);
    try std.testing.expectEqualStrings("File is matched by include pattern specified here.", include_related[0].message);

    var include_chain_top_buf: [1]ts_diagnostics.ChainEntry = undefined;
    var include_chain_child_buf: [1]ts_diagnostics.ChainEntry = undefined;
    var include_owned_chain_child_message: ?[]u8 = null;
    defer if (include_owned_chain_child_message) |msg| std.testing.allocator.free(msg);
    const include_chain = try caseOnlyInputReasonChain(std.testing.allocator, .{
        .kind = .include,
        .config_path = "/repo/tsconfig.json",
        .config_source = config_source,
        .specs = &include,
    }, &include_chain_top_buf, &include_chain_child_buf, &include_owned_chain_child_message);
    try std.testing.expectEqual(@as(usize, 1), include_chain.len);
    try std.testing.expectEqualStrings("The file is in the program because:", include_chain[0].message);
    try std.testing.expectEqualStrings("Matched by include pattern 'src/**/*' in '/repo/tsconfig.json'", include_chain[0].children[0].message);
}

test "tsc_main: explainFiles reports Node package type module format reasons" {
    var vfs = ts_resolver.VirtualFs.init(std.testing.allocator);
    defer vfs.deinit();
    try vfs.addFile("/repo/package.json", "{\"type\":\"module\"}");

    const reason = (try explainNodeFormatReason(
        std.testing.allocator,
        vfs.fs(),
        "/repo/src/app.ts",
        "import './dep';",
        .node16,
    )).?;
    defer std.testing.allocator.free(reason.message);

    try std.testing.expectEqual(@as(u32, 1458), reason.code);
    try std.testing.expectEqualStrings(
        "File is ECMAScript module because '/repo/package.json' has field \"type\" with value \"module\"",
        reason.message,
    );
}

test "tsc_main: explainFiles reports Node package type non-module format reasons" {
    var vfs = ts_resolver.VirtualFs.init(std.testing.allocator);
    defer vfs.deinit();
    try vfs.addFile("/repo/package.json", "{\"type\":\"commonjs\"}");

    const reason = (try explainNodeFormatReason(
        std.testing.allocator,
        vfs.fs(),
        "/repo/src/app.ts",
        "export const x = 1;",
        .nodenext,
    )).?;
    defer std.testing.allocator.free(reason.message);

    try std.testing.expectEqual(@as(u32, 1459), reason.code);
    try std.testing.expectEqualStrings(
        "File is CommonJS module because '/repo/package.json' has field \"type\" whose value is not \"module\"",
        reason.message,
    );
}

test "tsc_main: explainFiles reports Node package without type format reasons" {
    var vfs = ts_resolver.VirtualFs.init(std.testing.allocator);
    defer vfs.deinit();
    try vfs.addFile("/repo/package.json", "{\"name\":\"pkg\"}");

    const reason = (try explainNodeFormatReason(
        std.testing.allocator,
        vfs.fs(),
        "/repo/src/app.ts",
        "const x = require('dep');",
        .node18,
    )).?;
    defer std.testing.allocator.free(reason.message);

    try std.testing.expectEqual(@as(u32, 1460), reason.code);
    try std.testing.expectEqualStrings(
        "File is CommonJS module because '/repo/package.json' does not have field \"type\"",
        reason.message,
    );

    try vfs.addFile("/other/package.json", "{\"type\":true}");
    const non_string = (try explainNodeFormatReason(
        std.testing.allocator,
        vfs.fs(),
        "/other/src/app.ts",
        "export const x = 1;",
        .node16,
    )).?;
    defer std.testing.allocator.free(non_string.message);
    try std.testing.expectEqual(@as(u32, 1460), non_string.code);
}

test "tsc_main: explainFiles reports missing package.json format reasons" {
    var vfs = ts_resolver.VirtualFs.init(std.testing.allocator);
    defer vfs.deinit();

    const reason = (try explainNodeFormatReason(
        std.testing.allocator,
        vfs.fs(),
        "/repo/src/app.ts",
        "module.exports = {};",
        .node20,
    )).?;
    defer std.testing.allocator.free(reason.message);

    try std.testing.expectEqual(@as(u32, 1461), reason.code);
    try std.testing.expectEqualStrings(
        "File is CommonJS module because 'package.json' was not found",
        reason.message,
    );
}

test "tsc_main: explainFiles skips non-node module format and scripts" {
    var vfs = ts_resolver.VirtualFs.init(std.testing.allocator);
    defer vfs.deinit();
    try vfs.addFile("/repo/package.json", "{\"type\":\"module\"}");

    try std.testing.expect((try explainNodeFormatReason(
        std.testing.allocator,
        vfs.fs(),
        "/repo/src/app.ts",
        "import './dep';",
        .esnext,
    )) == null);
    try std.testing.expect((try explainNodeFormatReason(
        std.testing.allocator,
        vfs.fs(),
        "/repo/src/script.ts",
        "const x = 1;",
        .node16,
    )) == null);
    try std.testing.expect((try explainNodeFormatReason(
        std.testing.allocator,
        vfs.fs(),
        "/repo/src/app.mts",
        "import './dep';",
        .node16,
    )) == null);
}

test "tsc_main: TS6307 diagnostic message and anchor match composite file list validation" {
    const msg = try compositeProjectFileListMessage(
        std.testing.allocator,
        "/repo/src/dep.ts",
        "/repo/tsconfig.json",
    );
    defer std.testing.allocator.free(msg);
    try std.testing.expectEqualStrings(
        "File '/repo/src/dep.ts' is not listed within the file list of project '/repo/tsconfig.json'. Projects must list all files or use an 'include' pattern.",
        msg,
    );

    var vfs = ts_resolver.VirtualFs.init(std.testing.allocator);
    defer vfs.deinit();
    try vfs.addFile("/repo/src/main.ts", "import { dep } from './dep';\n");
    try vfs.addFile("/repo/src/dep.ts", "export const dep = 1;\n");
    var resolver = ts_resolver.Resolver.init(std.testing.allocator, vfs.fs(), .{});
    defer resolver.deinit();
    var program = ts_program.Program.init(std.testing.allocator, &resolver);
    defer program.deinit();
    _ = try program.add("/repo/src/main.ts", "import { dep } from './dep';\n");
    const dep_id = try program.add("/repo/src/dep.ts", "export const dep = 1;\n");
    try program.compileAll(.{});

    const dep = program.fileById(dep_id);
    const anchor = compositeDiagnosticAnchor(&program, dep);
    const lc = ts_diagnostics.positionToLineCol(anchor.file.source, anchor.pos);
    try std.testing.expectEqualStrings("/repo/src/main.ts", anchor.file.path);
    try std.testing.expectEqual(@as(u32, 1), lc.line);
    try std.testing.expectEqual(@as(u32, 21), lc.col);
    try std.testing.expectEqual(@as(u32, 7), anchor.span_len);

    var related_buf: [1]ts_diagnostics.Related = undefined;
    const related = compositeDiagnosticRelated(&program, dep, &related_buf);
    try std.testing.expectEqual(@as(usize, 1), related.len);
    try std.testing.expectEqual(@as(u32, 1399), related[0].code);
    try std.testing.expectEqualStrings("File is included via import here.", related[0].message);
    try std.testing.expectEqualStrings("/repo/src/main.ts", related[0].file);
}

test "LspProject: publishes diagnostics on open and change, answers hover, frees everything" {
    // No tsconfig: the repository's own would make results depend on
    // whether its type packages are installed.
    const project = try LspProject.create(std.testing.allocator, null);
    defer project.destroy();

    const opened = try project.handle(
        \\{"jsonrpc":"2.0","method":"textDocument/didOpen","params":{"textDocument":{"uri":"file:///home-lsp-test/main.ts","languageId":"typescript","version":1,"text":"const total: number = \"x\";\nexport {};\n"}}}
    );
    defer std.testing.allocator.free(opened);
    try std.testing.expect(std.mem.indexOf(u8, opened, "\"method\":\"textDocument/publishDiagnostics\"") != null);
    try std.testing.expect(std.mem.indexOf(u8, opened, "2322") != null);

    const hover = try project.handle(
        \\{"jsonrpc":"2.0","id":2,"method":"textDocument/hover","params":{"textDocument":{"uri":"file:///home-lsp-test/main.ts"},"position":{"line":0,"character":8}}}
    );
    defer std.testing.allocator.free(hover);
    try std.testing.expect(std.mem.indexOf(u8, hover, "const total: number") != null);

    const changed = try project.handle(
        \\{"jsonrpc":"2.0","method":"textDocument/didChange","params":{"textDocument":{"uri":"file:///home-lsp-test/main.ts","version":2},"contentChanges":[{"text":"const total: number = 1;\nexport {};\n"}]}}
    );
    defer std.testing.allocator.free(changed);
    try std.testing.expect(std.mem.indexOf(u8, changed, "\"diagnostics\":[]") != null);
}

test "LspProject: loads an empty tsconfig as the default config" {
    var tmp = std.testing.tmpDir(.{});
    defer tmp.cleanup();

    const io = std.testing.io;
    {
        var config_file = try tmp.dir.createFile(io, "tsconfig.json", .{ .truncate = true });
        config_file.close(io);
    }
    const config_path = try tmp.dir.realPathFileAlloc(io, "tsconfig.json", std.testing.allocator);
    defer std.testing.allocator.free(config_path);

    const project = try LspProject.create(std.testing.allocator, config_path);
    defer project.destroy();
    try std.testing.expect(project.config_source_owned);
    try std.testing.expectEqual(@as(usize, 0), project.config_source.len);
    try std.testing.expect(project.config != null);
    try std.testing.expectEqualStrings(config_path, project.config.?.file_path);
}

test "LspProject: publishes Home diagnostics with HM wire codes" {
    var tmp = std.testing.tmpDir(.{});
    defer tmp.cleanup();

    const io = std.testing.io;
    {
        var config_file = try tmp.dir.createFile(io, "tsconfig.json", .{ .truncate = true });
        defer config_file.close(io);
        try config_file.writeStreamingAll(io, "{ \"home\": { \"sound\": true } }");
    }
    const config_path = try tmp.dir.realPathFileAlloc(io, "tsconfig.json", std.testing.allocator);
    defer std.testing.allocator.free(config_path);

    const project = try LspProject.create(std.testing.allocator, config_path);
    defer project.destroy();

    const opened = try project.handle(
        \\{"jsonrpc":"2.0","method":"textDocument/didOpen","params":{"textDocument":{"uri":"file:///home-lsp-test/sound.ts","languageId":"typescript","version":1,"text":"const value: any = 1;\n"}}}
    );
    defer std.testing.allocator.free(opened);
    try std.testing.expect(std.mem.indexOf(u8, opened, "\"method\":\"textDocument/publishDiagnostics\"") != null);
    try std.testing.expect(std.mem.indexOf(u8, opened, "\"code\":\"HM9001\"") != null);
    try std.testing.expect(std.mem.indexOf(u8, opened, "\"source\":\"home\"") != null);
}

pub fn auditProjectNoEmit(gpa: std.mem.Allocator, config_path: []const u8) !bool {
    var arena_state = std.heap.ArenaAllocator.init(gpa);
    defer arena_state.deinit();
    const arena = arena_state.allocator();
    const cfg_src = try RealFs.read(arena, config_path);
    var cfg = try tsconfig_mod.parseString(gpa, arena, cfg_src);
    cfg.file_path = config_path;
    const validation = try cfg.validate(gpa);
    defer tsconfig_mod.freeValidationDiagnostics(gpa, validation);
    try printConfigValidationDiagnostics(gpa, cfg, cfg_src, validation, false, false);
    if (config_diagnostics.summarize(cfg, validation).hasErrors()) return error.InvalidAuditConfiguration;
    const project_dir = std.fs.path.dirname(config_path) orelse ".";
    var inputs: std.ArrayListUnmanaged([]const u8) = .empty;
    defer inputs.deinit(gpa);
    var owned: std.ArrayListUnmanaged([]u8) = .empty;
    defer {
        for (owned.items) |path| gpa.free(path);
        owned.deinit(gpa);
    }
    if (cfg.files) |files| {
        try ts_cli.appendProjectFilePaths(gpa, project_dir, files, &inputs, &owned);
    } else {
        var exclude_storage: [2][]const u8 = undefined;
        try expandProjectGlobs(gpa, project_dir, effectiveIncludePatterns(cfg),
            cfg.effectiveExcludePatterns(&exclude_storage),
            tsconfig_mod.effectiveAllowJs(cfg.compiler_options), &inputs, &owned);
    }
    var resolver_fs = ResolverRealFs.init(gpa);
    defer resolver_fs.deinit();
    var resolver = ts_resolver.Resolver.init(gpa, resolver_fs.fs(), resolverConfigFromConfig(arena, cfg, null));
    defer resolver.deinit();
    var program = ts_program.Program.init(gpa, &resolver);
    defer program.deinit();
    for (inputs.items) |path| {
        const source = try RealFs.read(gpa, path);
        defer gpa.free(source);
        _ = try program.add(path, source);
    }
    var options = ts_driver.optionsFromConfig(&cfg);
    ts_cli.applyCompileOptions(&options, .{ .no_emit = true, .home_options = .{ .list_unmodeled_any = true } });
    var adapter = CheckerResolverAdapter.init(gpa, &resolver);
    defer adapter.deinit();
    adapter.setProgramSources(&program, options);
    options.external_resolver = .{ .ptr = &adapter, .vtable = &CheckerResolverAdapter.vtable };
    _ = program.loadImportClosureParallel(options, null) catch {};
    var had_errors = false;
    var stream: StreamCtx = .{ .gpa = gpa, .program = &program,
        .use_pretty = false, .use_color = false, .any_errors = &had_errors };
    try program.compileAllStreaming(options, &stream, streamDiagsCallback);
    std.debug.print("audit-project roots={d} admitted-files={d}\n", .{ inputs.items.len, program.files.items.len });
    return had_errors;
}
