import hashlib
import json
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
integration = Path('/Users/chris/.cache/home-ts-main-flow-proof-integration.dYlSre')
original = Path('/Users/chris/.cache/home-ts-callable-intersection-facts.34PC25')
runner = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
sys.path.insert(0, str(runner / 'bench/vs_tsgo'))
import run
import competitors

def save(path, content):
    assert not path.exists(), path
    path.parent.mkdir(parents=True, exist_ok=True)
    patch = '*** Begin Patch\n*** Add File: ' + str(path) + '\n'
    patch += ''.join('+' + line + '\n' for line in content.splitlines()) + '*** End Patch\n'
    subprocess.run(['apply_patch'], input=patch, text=True, check=True, capture_output=True)

assert not (root / 'results.json').exists()
candidate = integration / 'candidate-home-tsc'
parent = integration / 'baseline-home-tsc'
assert hashlib.sha256(candidate.read_bytes()).hexdigest() == '754926fd350062fac7094768b6adb2f1a5e808b21c37a59ec151b31ac46d59af'
trace = []
before = {}
for variant in ['base-value', 'model-value', 'self-named-factory', 'base-and-factory']:
    for negative in [False, True]:
        name = variant + ('-negative' if negative else '-positive')
        project = root / name
        prior = original / ('collection-factory-negative' if negative else 'collection-factory-positive')
        for relative in ['tsconfig.json', 'src/util.d.ts', 'src/factory.ts', 'src/lib.d.ts']:
            save(project / relative, (prior / relative).read_text())
        source = (prior / 'src/main.ts').read_text()
        if variant in ['base-value', 'base-and-factory']:
            source = source.replace('type Part=', 'declare const Base:factory.Creator<Base>;\ntype Part=')
            source = source.replace(' for(const part', ' Base.init(instance,def);\n for(const part')
        if variant == 'model-value':
            source = source.replace('const result:', 'declare const Model:factory.Creator<Model>;\nconst result:')
        if variant in ['self-named-factory', 'base-and-factory']:
            source = source.replace('const result:', 'const Model:').replace('void result;', 'void Model;')
        save(project / 'src/main.ts', source)
        before[name] = competitors.inventory_hash(competitors.payload_inventory(project))
        commands = run.compiler_commands()
        commands['home'] = [str(candidate)]
        commands['parent'] = [str(parent)]
        for compiler, command in commands.items():
            result, passed = run.admission_process(compiler, command + ['--noEmit', '-p', str(project / 'tsconfig.json')],
                name, expected_codes=['2322', '2339'] if negative else None, trace=trace)
            print(name, compiler, result.returncode, passed, trace[-1]['codes'], flush=True)
after = {name: competitors.inventory_hash(competitors.payload_inventory(root / name)) for name in before}
assert before == after
save(root / 'results.json', json.dumps({'records': trace, 'before': before, 'after': after,
    'reference_controls_valid': all(row['passed'] for row in trace if row['compiler'] in ['tsc', 'tsgo']),
    'timings_taken': False, 'source_adopted': False}, indent=2) + '\n')
