export interface Entity209<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity209<U>;
}

export type Result209<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap209<T> = T extends Result209<infer U, unknown> ? U : never;

export function transform209<T, U>(
  input: Entity209<T>,
  fn: (value: T) => U,
): Result209<Entity209<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker209: Result209<number> = { ok: true, value: 209 };
