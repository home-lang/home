export interface Entity210<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity210<U>;
}

export type Result210<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap210<T> = T extends Result210<infer U, unknown> ? U : never;

export function transform210<T, U>(
  input: Entity210<T>,
  fn: (value: T) => U,
): Result210<Entity210<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker210: Result210<number> = { ok: true, value: 210 };
