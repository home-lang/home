# Restored Zod source audit for #751

The exact #688 parent and #751 fix were rebuilt with the same Zig toolchain,
ReleaseSafe optimization, stripped symbols, and fixed 3,840 MB footprint cap.
The compiler sources and all 106 production Zod files were unmodified.
Core and locales are separate root selections; normal import closure discovery
is enabled for both. TypeScript 6.0.3 and native TypeScript 7.0.2 receive the
same configurations and accept both projects without diagnostics.

The complete Home diagnostic identity multisets match between revisions on
both projects. An identity is the tuple of corpus-relative path, line, column,
and TS code. The identity hash is SHA-256 of sorted unique identities, joined
with colons and a newline after every row. Duplicate identities are retained
in the multiset comparison and total count.

Logs retain all diagnostic messages and source excerpts. Only private path
prefixes are replaced with $CORPUS, $EVIDENCE, $REPO, $OTHER_CHECKOUT,
$TOOLCHAIN, and $REFERENCE_TOOLS. Original logs remain in the local evidence directory. Compiler
and configuration hashes, exits, counts, and peak footprints are in metadata.
The unstripped parent build exceeded the cap and was stopped; neither its
partial output nor the initial reference-command usage error is admitted.

This is an untimed historical correctness gate. The remaining Home diagnostics
keep this production project outside the cross-compiler timing table.
