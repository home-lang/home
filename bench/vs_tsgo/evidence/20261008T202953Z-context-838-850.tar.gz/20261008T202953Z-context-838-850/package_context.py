import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
subprocess.run(['python3', str(root / 'verify.py')], check=True)
subprocess.run(['python3', str(root / 'verify_docs.py')], check=True)
command = ['env', 'HOME_RUN_MAX_MB=3840', 'HOME_RUN_LABEL=ts838-matrix-context-tests',
           'perl', 'scripts/run-bounded.pl', '600', 'python3', '-m', 'unittest', 'discover',
           '-s', 'bench/vs_tsgo', '-p', 'test_*.py']
tests = subprocess.run(command, cwd=repo, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
(root / 'harness.log').write_text(tests.stdout)
assert tests.returncode == 0 and 'Ran 128 tests' in tests.stdout
proof = json.loads((root / 'verified.json').read_text())
assert subprocess.run(['git', 'diff', '--quiet', proof['compiler_source'], proof['source'],
                       '--', 'packages', 'build.zig', 'build.zig.zon'], cwd=repo).returncode == 0
context = {'source': proof['source'], 'compiler_source': proof['compiler_source'],
    'compiler_tree_equal': True, 'matrix_archive_sha256': proof['archive_sha256'],
    'guard_mb': 3840, 'peak_tree_mb': 391, 'host_low_water_percent': 40,
    'harness_tests': 128, 'harness_command': command,
    'home_leads': proof['home_leads'], 'home_beats_go': proof['home_beats_go'],
    'patch_ab_claim': False, 'other_platforms_verified': False,
    'cpp_timing_admitted': False, 'goal_complete': False}
(root / 'context.json').write_text(json.dumps(context, indent=2) + '\n')
name = '20261008T202953Z-context-838-850'
entries = {filename: (root / filename).read_bytes() for filename in
           ('matrix.py', 'verify.py', 'verify_docs.py', 'package_context.py', 'command.json',
            'verified.json', 'context.json', 'matrix.log', 'harness.log')}
for filename in ('integration-summary.json', 'integrated-build-command.json', 'integrated-build-logged.log'):
    entries['compiler/' + filename] = (Path('/Users/chris/.cache/home-ts-global-refs.p6XJ88') / filename).read_bytes()
checksums = ''.join(hashlib.sha256(data).hexdigest() + '  ' + path + '\n' for path, data in sorted(entries.items()))
count = len(entries)
entries['SHA256SUMS'] = checksums.encode()
archive = repo / 'bench/vs_tsgo/evidence' / (name + '.tar.gz')
assert not archive.exists()
with archive.open('wb') as output:
    with gzip.GzipFile(filename='', mode='wb', fileobj=output, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as tar:
            for path, data in sorted(entries.items()):
                info = tarfile.TarInfo(name + '/' + path)
                info.size, info.mode, info.mtime = len(data), 0o644, 0
                tar.addfile(info, io.BytesIO(data))
with tarfile.open(archive) as tar:
    for line in checksums.splitlines():
        digest, path = line.split('  ', 1)
        assert hashlib.sha256(tar.extractfile(name + '/' + path).read()).hexdigest() == digest
print(json.dumps({'archive': str(archive), 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
                  'verified_payload_checksums': count}), flush=True)
