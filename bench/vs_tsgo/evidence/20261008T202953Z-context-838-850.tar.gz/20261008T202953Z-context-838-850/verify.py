import hashlib
import json
from pathlib import Path
import statistics
import sys
import tarfile

repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
root = Path(__file__).resolve().parent
sys.path.insert(0, str(repo / 'bench/vs_tsgo'))
import compare

result = repo / 'bench/vs_tsgo/results/20261008T202953Z'
metadata = json.loads((result / 'metadata.json').read_text())
compare.validate_interleaved_rounds(result, metadata)
assert metadata['provenance']['status'] == 'verified'
assert metadata['provenance']['before'] == metadata['provenance']['after']
admission = json.loads((result / 'admission.jsonl').read_text())
assert len(admission['records']) == 140 and all(row['passed'] for row in admission['records'])
rows = {}
for workload in metadata['workloads']:
    samples = {name: [] for name in metadata['compilers']}
    for index in range(30):
        data = json.loads((result / f'{workload}-round-{index:03d}.json').read_text())
        for record in data['results']:
            name = record['command'].split(' ', 1)[0]
            samples[name].extend(record['times'])
    assert all(len(values) == 30 for values in samples.values())
    rows[workload] = {name: statistics.median(values) for name, values in samples.items()}
archive = repo / 'bench/vs_tsgo/evidence/20261008T202953Z.tar.gz'
with tarfile.open(archive) as tar:
    sums = [name for name in tar.getnames() if name.endswith('/SHA256SUMS')]
    assert len(sums) == 1
    prefix = sums[0].rsplit('/', 1)[0] + '/'
    checksums = tar.extractfile(sums[0]).read().decode().splitlines()
    for line in checksums:
        digest, relative = line.split(None, 1)
        assert hashlib.sha256(tar.extractfile(prefix + relative.removeprefix('./')).read()).hexdigest() == digest
    for path in result.glob('*-round-*.json'):
        assert tar.extractfile(prefix + path.name).read() == path.read_bytes()
home_leads = [name for name, values in rows.items() if values['home'] == min(values.values())]
home_beats_go = [name for name, values in rows.items() if values['home'] < values['tsgo']]
leaders = {name: min(values, key=values.get) for name, values in rows.items()}
summary = {'result': result.name, 'source': '211d28ce32d96c8b88656966ce40ce0730034b9d',
    'compiler_source': '00a9dcf8fd4cf6ce4505803f6a699e1dec6c2650',
    'rounds': 600, 'samples': 3000, 'admissions': 140, 'verified_payload_checksums': len(checksums),
    'archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
    'home_leads': home_leads, 'home_beats_go': home_beats_go, 'leaders': leaders, 'rows': rows}
(root / 'verified.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({key: value for key, value in summary.items() if key != 'rows'}), flush=True)
