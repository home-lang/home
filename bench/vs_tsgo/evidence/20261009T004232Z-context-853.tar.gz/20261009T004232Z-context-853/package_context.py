import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
verified = json.loads((root / 'verified.json').read_text())
assert verified['rounds'] == 600 and verified['samples'] == 3000 and verified['admissions'] == 145
assert verified['native_sha256'] == 'fb77a18ed4b9b14a7c0ef29366963166754de8904602c2516ea2d223389cbb82'
entries = {}
for name in ('matrix.py', 'verify.py', 'verify_docs.py', 'report_tables.py', 'package_context.py', 'command.json', 'matrix.log', 'verified.json', 'docs-table.md', 'readme-table.md', 'verification-initial-failure.json'):
    entries[name] = (root / name).read_bytes()
for name in ('run.py', 'compare.py', 'competitors.py', 'corpus.toml', 'test_run.py', 'test_compare.py'):
    entries['harness/' + name] = (repo / 'bench/vs_tsgo' / name).read_bytes()
entries['harness/darwin-arm64.json'] = (repo / 'bench/vs_tsgo/profiles/darwin-arm64.json').read_bytes()
name = verified['result'] + '-context-853'
checksums = ''.join(hashlib.sha256(data).hexdigest() + '  ' + path + '\n' for path, data in sorted(entries.items()))
count = len(entries)
entries['SHA256SUMS'] = checksums.encode()
archive = repo / 'bench/vs_tsgo/evidence' / (name + '.tar.gz')
assert not archive.exists()
with archive.open('wb') as output:
    with gzip.GzipFile(filename='', mode='wb', fileobj=output, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as tar:
            for path, data in sorted(entries.items()):
                info = tarfile.TarInfo(name + '/' + path)
                info.size, info.mode, info.mtime = len(data), 0o644, 0
                tar.addfile(info, io.BytesIO(data))
with tarfile.open(archive) as tar:
    for line in checksums.splitlines():
        digest, path = line.split('  ', 1)
        assert hashlib.sha256(tar.extractfile(name + '/' + path).read()).hexdigest() == digest
report = {'archive': str(archive), 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'payload_checksums': count}
(root / 'context.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report))
