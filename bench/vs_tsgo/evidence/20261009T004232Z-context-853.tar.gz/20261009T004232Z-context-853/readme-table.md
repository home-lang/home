| Workload | tsc 6.0.3 median | native TS 7.0.2 median | Home median | Rust tsc-rs 0.1.0 median | Bun canary median | Home vs fastest competitor |
|---|---:|---:|---:|---:|---:|---:|
| Startup (one small file) | 69.7 ms | 8.2 ms | 3.3 ms | 6.5 ms | 6.9 ms | **2.00× faster** |
| 256 independent files | 210.0 ms | 23.3 ms | 22.1 ms | 16.7 ms | 13.6 ms | 1.63× slower |
| 128-module import chain | 146.1 ms | 16.4 ms | 22.4 ms | 12.5 ms | 16.3 ms | 1.79× slower |
| 64 modules through 8 barrel re-exports | 104.2 ms | 11.1 ms | 13.2 ms | 9.3 ms | 8.8 ms | 1.50× slower |
| Deep conditional / mapped / template types | 141.1 ms | 22.4 ms | 22.1 ms | 15.1 ms | 14.1 ms | 1.57× slower |
| Recursive generics | 159.7 ms | 41.1 ms | 15.0 ms | 33.3 ms | 9.7 ms | 1.56× slower |
| Checked JavaScript with JSDoc | 201.6 ms | 23.0 ms | 28.0 ms | 22.8 ms | 13.3 ms | 2.10× slower |
| Control-flow narrowing (256 unions) | 206.2 ms | 28.7 ms | 27.2 ms | 25.8 ms | 16.9 ms | 1.61× slower |
| 256 type-predicate families | 257.1 ms | 43.0 ms | 35.4 ms | 37.3 ms | 25.5 ms | 1.39× slower |
| 2,048 type-predicate families | 1,120.3 ms | 340.8 ms | 269.5 ms | 296.1 ms | 174.4 ms | 1.55× slower |
