| Workload | tsc 6.0.3 median | native TS 7.0.2 median | Home median | Rust tsc-rs 0.1.0 median | Bun canary median | Home vs fastest competitor |
|---|---:|---:|---:|---:|---:|---:|
| `checkjs_jsdoc` | 201.6 ms | 23.0 ms | 28.0 ms | 22.8 ms | 13.3 ms | 2.10× slower |
| `class_hierarchy` | 217.2 ms | 23.1 ms | 26.1 ms | 20.0 ms | 15.0 ms | 1.74× slower |
| `commonjs_graph` | 153.4 ms | 18.1 ms | 24.7 ms | 14.8 ms | 12.2 ms | 2.02× slower |
| `control_flow` | 206.2 ms | 28.7 ms | 27.2 ms | 25.8 ms | 16.9 ms | 1.61× slower |
| `deep_types` | 141.1 ms | 22.4 ms | 22.1 ms | 15.1 ms | 14.1 ms | 1.57× slower |
| `destructuring` | 154.9 ms | 18.1 ms | 16.3 ms | 15.7 ms | 11.8 ms | 1.38× slower |
| `generic_calls` | 200.1 ms | 24.6 ms | 24.9 ms | 21.2 ms | 15.3 ms | 1.63× slower |
| `import_graph` | 146.1 ms | 16.4 ms | 22.4 ms | 12.5 ms | 16.3 ms | 1.79× slower |
| `interface_composition` | 220.7 ms | 33.8 ms | 37.2 ms | 25.9 ms | 18.4 ms | 2.02× slower |
| `many_files` | 210.0 ms | 23.3 ms | 22.1 ms | 16.7 ms | 13.6 ms | 1.63× slower |
| `null_safe_access` | 203.5 ms | 27.7 ms | 33.7 ms | 24.3 ms | 17.1 ms | 1.97× slower |
| `overload_resolution` | 205.8 ms | 33.5 ms | 24.0 ms | 27.0 ms | 20.3 ms | 1.18× slower |
| `recursive_generics` | 159.7 ms | 41.1 ms | 15.0 ms | 33.3 ms | 9.7 ms | 1.56× slower |
| `reexport_graph` | 104.2 ms | 11.1 ms | 13.2 ms | 9.3 ms | 8.8 ms | 1.50× slower |
| `startup` | 69.7 ms | 8.2 ms | 3.3 ms | 6.5 ms | 6.9 ms | **2.00× faster** |
| `structural_objects` | 200.6 ms | 28.6 ms | 24.3 ms | 23.8 ms | 18.0 ms | 1.35× slower |
| `tsx_components` | 173.0 ms | 16.8 ms | 20.8 ms | 14.8 ms | 10.5 ms | 1.98× slower |
| `type_predicates` | 257.1 ms | 43.0 ms | 35.4 ms | 37.3 ms | 25.5 ms | 1.39× slower |
| `type_predicates_large` | 1,120.3 ms | 340.8 ms | 269.5 ms | 296.1 ms | 174.4 ms | 1.55× slower |
| `variadic_tuples` | 283.3 ms | 49.2 ms | 35.3 ms | 37.1 ms | 21.3 ms | 1.66× slower |
