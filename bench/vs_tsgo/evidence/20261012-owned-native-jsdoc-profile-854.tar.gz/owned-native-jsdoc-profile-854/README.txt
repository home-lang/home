Diagnostic profile of the exact measured bb4c00dd native image; zero benchmark timing samples.
One native process and two fixed windows. All six scale admissions and30 full native controls passed.
All original profile/context bytes, retained link/object/native images and generated controls are preserved.
Map verification compares bytes outside whole relocation words; no opcode equivalence is claimed inside masks.
Only explicit displayed PCs are mapped. Ellipses and inclusive/collapsed counts are not assigned CPU shares.
Metadata paths remain verbatim; no credential environment is captured.
The compiler is unchanged. Root require-binding scanning remains a lead, not a measured optimization gain.
