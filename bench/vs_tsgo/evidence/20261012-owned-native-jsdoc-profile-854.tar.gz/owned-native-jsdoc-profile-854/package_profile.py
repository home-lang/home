import hashlib
import json
from pathlib import Path
import sys
import tarfile

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts863-qualification-docs/lang')
sys.path.insert(0, str(repo / 'bench/vs_tsgo'))
import run

assert json.loads((root / 'verified-map.json').read_bytes())['passed']
assert json.loads((root / 'verified-profile.json').read_bytes())['passed']
outcome = json.loads((root / 'profile-outcome.json').read_bytes())
assert outcome['artifacts_unchanged'] and all(row['exit'] == 0 for row in outcome['records'])
prefix = 'owned-native-jsdoc-profile-854'
members = {}
for path in sorted(root.rglob('*')):
    if path.is_symlink():
        raise ValueError('No symlinks in raw profile evidence')
    if path.is_file() and '__pycache__' not in path.parts:
        members[f'{prefix}/{path.relative_to(root).as_posix()}'] = path.read_bytes()
members[f'{prefix}/README.txt'] = (
    'Diagnostic profile of the exact measured bb4c00dd native image; zero benchmark timing samples.\n'
    'One native process and two fixed windows. All six scale admissions and30 full native controls passed.\n'
    'All original profile/context bytes, retained link/object/native images and generated controls are preserved.\n'
    'Map verification compares bytes outside whole relocation words; no opcode equivalence is claimed inside masks.\n'
    'Only explicit displayed PCs are mapped. Ellipses and inclusive/collapsed counts are not assigned CPU shares.\n'
    'Metadata paths remain verbatim; no credential environment is captured.\n'
    'The compiler is unchanged. Root require-binding scanning remains a lead, not a measured optimization gain.\n'
).encode()
members[f'{prefix}/SHA256SUMS'] = ''.join(
    f'{hashlib.sha256(raw).hexdigest()}  {name.removeprefix(prefix + "/")}\n'
    for name, raw in sorted(members.items())).encode()
output = repo / 'bench/vs_tsgo/evidence/20261012-owned-native-jsdoc-profile-854.tar.gz'
assert not output.exists(), 'Do not overwrite raw evidence'
run.write_evidence_archive(output, members)
with tarfile.open(output) as archive:
    for name, raw in members.items():
        assert archive.extractfile(name).read() == raw, name
print(json.dumps({'archive': str(output), 'sha256': hashlib.sha256(output.read_bytes()).hexdigest(),
                  'verified_payloads': len(members) - 1, 'bytes': output.stat().st_size,
                  'all_original_bytes_verified': True}))
