"""Reuse published verifier algorithms with explicit new image/context identities."""
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts863-qualification-docs/lang')
measured = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
archive = repo / 'bench/vs_tsgo/evidence/20261010-exact-native-jsdoc-profile-854.tar.gz'
old_hash = 'ff78eeff3f36f622db610d23881be7165dce31b424481318e82360f1da5935f8'
native_hash = 'bb4c00dd2fdfba719098150082b696b4f9ba8ab65a7a47640b197540420cf771'
names = ['build_native_map.py', 'verify_map.py', 'prepare_scale.py', 'admit_scale.py',
         'profile_native.py', 'resolve_samples.py', 'verify_profile.py', 'extract_observed_code.py']
records = []
with tarfile.open(archive) as source:
    for name in names:
        original = source.extractfile('profile/' + name).read().decode()
        content = original.replace(str(measured), str(repo)).replace(old_hash, native_hash)
        content = content.replace('0b8d1f049e4db8660c9bbc77eb498bb49d7d62eb', '4b4060e053874895573a8413b83099b0d14b4032')
        content = content.replace("sys.path.insert(0, str(repo / 'bench/vs_tsgo'))", "sys.path.insert(0, '" + str(measured / 'bench/vs_tsgo') + "')")
        if name == 'prepare_scale.py':
            content = content.replace("(repo / 'bench/vs_tsgo/run.py').read_bytes()", "Path(run.__file__).read_bytes()")
        if name == 'admit_scale.py':
            content = content.replace('commands = run.compiler_commands()',
                "matrix = json.loads(Path('" + str(repo / 'bench/vs_tsgo/results/20261011T232901Z-resumed/metadata.json') + "').read_text())\n"
                "commands = {name: matrix['provenance']['before']['compilers'][name]['command'] for name in ['tsc', 'tsgo', 'home']}")
        if name == 'build_native_map.py':
            content = content.replace("original = matches[0].parent / 'home-tsc_zcu.o'",
                "cached_object = matches[0].parent / 'home-tsc_zcu.o'\n"
                "original = root / 'retained-native-object.o'\n"
                "assert digest(original) == digest(cached_object)\n"
                "retained_link = root / 'retained-native-link'\n"
                "assert not retained_link.exists()\n"
                "shutil.copy2(matches[0], retained_link)\n"
                "assert digest(retained_link) == expected")
            content = content.replace("'exact_cached_link_image': str(matches[0])", "'exact_cached_link_image': str(retained_link), 'reconstructed_cached_origin': str(matches[0])")
            content = content.replace('Exact original cached link/object layout.', 'Reconstructed cached link matches the measured native image byte-for-byte; paired object retained.')
        if name == 'extract_observed_code.py':
            content = content.replace('    assert len(entries) == 1',
                "    if not entries:\n"
                "        records.append({'name': name, 'explicitly_observed': False, 'reason': 'Not displayed in either fixed window; no repeat or CPU inference'})\n"
                "        continue\n"
                "    assert len(entries) == 1")
        target = root / name
        assert not target.exists()
        patch = '*** Begin Patch\n*** Add File: ' + str(target) + '\n' + ''.join('+' + line + '\n' for line in content.splitlines()) + '*** End Patch\n'
        subprocess.run(['apply_patch'], input=patch, text=True, check=True, capture_output=True)
        records.append({'name': name, 'published_source_sha256': hashlib.sha256(original.encode()).hexdigest(),
                        'current_sha256': hashlib.sha256(target.read_bytes()).hexdigest()})
record = {'reference_archive': str(archive), 'reference_archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
          'native_sha256': native_hash, 'compiler_source': '4b4060e053874895573a8413b83099b0d14b4032',
          'source_context': str(repo), 'harness_context': str(measured), 'scripts': records,
          'mapping_and_verification_algorithms_unchanged': True,
          'missing_old_target_observation_retained_not_repeated': True,
          'fixed_windows': [{'offset_seconds': 0.1, 'duration_seconds': 1}, {'offset_seconds': 3.0, 'duration_seconds': 1}],
          'diagnostic_only': True, 'benchmark_timing_samples': 0}
with (root / 'profile-protocol.json').open('x') as stream:
    json.dump(record, stream, indent=2)
print(json.dumps({'prepared_scripts': len(records), 'fixed_windows': record['fixed_windows'], 'compiler_semantics_modified': False}))
