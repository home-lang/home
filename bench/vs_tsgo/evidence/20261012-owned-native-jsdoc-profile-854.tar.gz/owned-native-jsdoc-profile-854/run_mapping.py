import json
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
assert json.loads((root / 'rebuild-outcome.json').read_text())['identical_to_measured_image']
records = []
for name in ['build_native_map.py', 'verify_map.py', 'prepare_scale.py']:
    print('Starting ' + name, flush=True)
    with (root / (name + '.log')).open('x') as stream:
        result = subprocess.run([sys.executable, str(root / name)], stdout=stream, stderr=subprocess.STDOUT)
    records.append({'script': name, 'exit': result.returncode})
    print(json.dumps(records[-1]), flush=True)
    if result.returncode != 0:
        print((root / (name + '.log')).read_text()[-2500:], flush=True)
        break
with (root / 'mapping-outcome.json').open('x') as stream:
    json.dump({'records': records, 'sampling_started': False}, stream, indent=2)
raise SystemExit(records[-1]['exit'])
