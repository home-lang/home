"""Reconstruct a matching object without overwriting or sampling retained images."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts863-qualification-docs/lang')
expected = 'bb4c00dd2fdfba719098150082b696b4f9ba8ab65a7a47640b197540420cf771'
retained = Path('/Users/chris/.cache/home-ts-owned-alias-inflight-interfaces.jHEAoG/candidate-home-tsc')
installed = repo / 'zig-out/bin/home-tsc'
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def git(*args):
    return subprocess.check_output(['git', *args], cwd=repo)
assert digest(retained) == digest(installed) == expected
assert not git('status', '--porcelain')
source = git('rev-parse', 'HEAD').decode().strip()
modules = ['hir', 'string_interner', 'binder', 'ts_cli', 'ts_program', 'ts_resolver', 'ts_driver',
           'ts_diagnostics', 'ts_emit', 'tsconfig', 'ts_watch', 'd_hm', 'ts_lsp', 'ts_lsp_server',
           'ts_cache', 'ts_lexer', 'ts_parser', 'ts_checker']
compiler_diff = git('diff', '4b4060e053874895573a8413b83099b0d14b4032', 'HEAD', '--',
                    'build.zig', 'build.zig.zon', *['packages/' + name for name in modules])
assert not compiler_diff, 'Compiler/build source changed since qualified image'
prefix = root / 'reconstructed'
assert not prefix.exists()
command = ['/Users/chris/Code/Home/lang-bun-port/zig-out/toolchains/zig-aarch64-macos-0.17.0-dev.2163+89ff10d56/zig',
           'build', 'home-tsc', '-Doptimize=ReleaseFast', '-Dhome-tsc-strip=true', '-Denable_jsc=false',
           '-j1', '--summary', 'all', '--prefix', str(prefix)]
with (root / 'rebuild.log').open('x') as stream:
    result = subprocess.run(command, cwd=repo, stdout=stream, stderr=subprocess.STDOUT)
record = {'command': command, 'exit': result.returncode, 'source': source,
          'qualified_compiler_source': '4b4060e053874895573a8413b83099b0d14b4032',
          'compiler_build_diff_empty': True, 'retained_native_sha256': expected,
          'retained_installed_images_unchanged': digest(retained) == digest(installed) == expected,
          'sampling_started': False, 'timing_samples': 0}
if result.returncode == 0:
    native = prefix / 'bin/home-tsc'
    record['reconstructed_native_sha256'] = digest(native)
    record['identical_to_measured_image'] = digest(native) == expected
    if record['identical_to_measured_image']:
        matches = [path for path in (repo / '.zig-cache/o').glob('*/home-tsc')
                   if path.is_file() and path.stat().st_size == native.stat().st_size
                   and digest(path) == expected and (path.parent / 'home-tsc_zcu.o').is_file()]
        assert matches, 'Exact matching cached object unavailable; do not sample'
        original = matches[0].parent / 'home-tsc_zcu.o'
        frozen_object = root / 'retained-native-object.o'
        shutil.copy2(original, frozen_object)
        record.update(cached_link=str(matches[0]), cached_object=str(original),
                      retained_object=str(frozen_object), object_sha256=digest(frozen_object))
        assert digest(original) == record['object_sha256']
assert git('rev-parse', 'HEAD').decode().strip() == source
assert record['retained_installed_images_unchanged']
with (root / 'rebuild-outcome.json').open('x') as stream:
    json.dump(record, stream, indent=2)
print(json.dumps(record), flush=True)
if result.returncode != 0:
    raise SystemExit(result.returncode)
assert record.get('identical_to_measured_image'), 'Fresh image differs; stop before mapping or sampling'
