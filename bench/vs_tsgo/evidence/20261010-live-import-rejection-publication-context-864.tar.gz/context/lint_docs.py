import json
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
records = []
for scope, command in [('repository', ['bunx', '--bun', 'pickier', '.']),
                       ('changed_documents', ['bunx', '--bun', 'pickier', 'README.md', 'docs/docs/TS_PERFORMANCE.md'])]:
    with (root / ('pickier-' + scope + '.log')).open('w') as output:
        result = subprocess.run(command, stdout=output, stderr=subprocess.STDOUT)
    records.append({'scope': scope, 'command': command, 'exit': result.returncode})
    print(scope, 'exit', result.returncode, flush=True)
    print((root / ('pickier-' + scope + '.log')).read_text()[-500:], flush=True)
(root / 'pickier-results.json').write_text(json.dumps(records, indent=2) + '\n')
assert records[-1]['exit'] == 0
