import json
from pathlib import Path

root = Path(__file__).resolve().parent
header = '| Phase and workload | Parent median | Candidate median | Paired mean-saving 95% interval |'
separator = '|---|---:|---:|---:|'

def row(label, value):
    interval = value['paired_mean_saving_95_interval']
    return f"| {label} | {value['parent_median'] * 1000:.3f} ms | {value['candidate_median'] * 1000:.3f} ms | {interval[0] * 1000:+.3f} to {interval[1] * 1000:+.3f} ms |"

screen = json.loads((root / 'screen-statistics.json').read_text())
target = json.loads((root / 'target-statistics.json').read_text())
full = [header, separator]
for name, value in screen['rows'].items():
    full.append(row('Screen ' + name + ' (10 pairs)', value))
full.append(row('Independent null-safe target (30 pairs)', target['rows']['null_safe_access']))
for path in sorted(root.glob('risk-*-statistics.json')):
    data = json.loads(path.read_text())
    for name, value in data['rows'].items():
        full.append(row('Independent ' + name + ' (30 pairs)', value))
(root / 'all-results-table.md').write_text('\n'.join(full) + '\n')
readme = [header, separator, row('Null-safe screen, 10 pairs', screen['rows']['null_safe_access']),
    row('Null-safe independent, 30 pairs', target['rows']['null_safe_access']),
    row('Re-export screen, 10 pairs', screen['rows']['reexport_graph'])]
for name in ['reexport_graph', 'destructuring', 'interface_composition']:
    value = json.loads((root / ('risk-' + name + '-statistics.json')).read_text())['rows'][name]
    readme.append(row(name.replace('_', ' ') + ' independent, 30 pairs', value))
(root / 'readme-results-table.md').write_text('\n'.join(readme) + '\n')
print('\n'.join(readme), flush=True)
