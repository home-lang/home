| Phase and workload | Parent median | Candidate median | Paired mean-saving 95% interval |
|---|---:|---:|---:|
| Null-safe screen, 10 pairs | 32.464 ms | 32.544 ms | -0.062 to +0.399 ms |
| Null-safe independent, 30 pairs | 34.038 ms | 33.841 ms | -0.106 to +2.981 ms |
| Re-export screen, 10 pairs | 11.612 ms | 12.304 ms | -0.973 to -0.058 ms |
| reexport graph independent, 30 pairs | 12.191 ms | 12.248 ms | -0.296 to +0.595 ms |
| destructuring independent, 30 pairs | 15.484 ms | 15.683 ms | -0.255 to +0.048 ms |
| interface composition independent, 30 pairs | 35.836 ms | 35.382 ms | +0.087 to +0.959 ms |
