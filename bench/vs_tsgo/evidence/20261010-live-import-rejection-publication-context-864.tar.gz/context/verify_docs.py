import hashlib
import json
from pathlib import Path
import tarfile

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
package = json.loads((root / 'package-rejection.json').read_text())
verified = json.loads((root / 'verified-completed.json').read_text())
assert verified['passed'] and verified['decision'] == 'reject'
archive = repo / package['archive']
assert hashlib.sha256(archive.read_bytes()).hexdigest() == package['sha256']
with tarfile.open(archive, 'r:gz') as tar:
    lines = tar.extractfile('SHA256SUMS').read().decode().splitlines()
    assert len(lines) == package['payload_checksums'] == 1269
    for line in lines:
        digest, name = line.split('  ', 1)
        assert hashlib.sha256(tar.extractfile(name).read()).hexdigest() == digest
    publication = json.loads(tar.extractfile('publication.json').read())
    assert publication['decision'] == 'reject' and publication['pairs'] == 530
    assert publication['per_phase_admissions'] == 100 and publication['initial_admissions'] == 180
    assert publication['candidate_pushed'] is False and publication['source_candidate_removed']
readme = (repo / 'README.md').read_text()
document = (repo / 'docs/docs/TS_PERFORMANCE.md').read_text()
heading = '## Live HIR import absence rejected 2026 10 10 UTC'
assert document.count(heading) == 1
section = document.split(heading, 1)[1].split('\n## ', 1)[0]
for row in (root / 'all-results-table.md').read_text().splitlines()[2:]:
    assert row in section, row
for row in (root / 'readme-results-table.md').read_text().splitlines()[2:]:
    assert row in readme, row
for token in ['530 original pairs', '180 initial image admissions', '100 per-phase admissions',
              '60.264167 ms', '-0.106 to +2.981 ms', '1,269 payload checksums']:
    assert token in section, token
assert package['sha256'] in section and publication['native_restored_sha256'] in section
assert 'rejected and was never pushed' in section
assert 'same verifier was rerun' in section and 'never any measurement' in section
assert '530 pairs / 280 admissions' in readme
assert '#live-hir-import-absence-rejected-2026-10-10-utc' in readme
assert hashlib.sha256((repo / 'zig-out/bin/home-tsc').read_bytes()).hexdigest() == publication['native_restored_sha256']
result = {'passed': True, 'pairs': 530, 'admissions': 280, 'decision': 'reject',
          'raw_archive_sha256': package['sha256'], 'payload_checksums': 1269,
          'readme_sha256': hashlib.sha256(readme.encode()).hexdigest(),
          'document_sha256': hashlib.sha256(document.encode()).hexdigest(),
          'source_restored': True, 'native_restored': True, 'measurement_reruns': 0}
(root / 'verified-docs.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result), flush=True)
