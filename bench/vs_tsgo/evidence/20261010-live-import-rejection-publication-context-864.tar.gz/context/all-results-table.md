| Phase and workload | Parent median | Candidate median | Paired mean-saving 95% interval |
|---|---:|---:|---:|
| Screen startup (10 pairs) | 2.860 ms | 2.883 ms | -0.142 to +0.053 ms |
| Screen many_files (10 pairs) | 21.026 ms | 20.700 ms | -0.289 to +0.477 ms |
| Screen deep_types (10 pairs) | 21.335 ms | 21.561 ms | -0.436 to +0.553 ms |
| Screen import_graph (10 pairs) | 16.524 ms | 16.419 ms | -0.195 to +0.604 ms |
| Screen reexport_graph (10 pairs) | 11.612 ms | 12.304 ms | -0.973 to -0.058 ms |
| Screen tsx_components (10 pairs) | 18.897 ms | 19.185 ms | -0.461 to +0.062 ms |
| Screen generic_calls (10 pairs) | 22.380 ms | 22.382 ms | -0.296 to +0.361 ms |
| Screen control_flow (10 pairs) | 25.316 ms | 25.009 ms | -0.050 to +0.366 ms |
| Screen type_predicates (10 pairs) | 32.236 ms | 32.073 ms | -0.100 to +0.618 ms |
| Screen type_predicates_large (10 pairs) | 248.142 ms | 243.827 ms | -2.875 to +4.681 ms |
| Screen null_safe_access (10 pairs) | 32.464 ms | 32.544 ms | -0.062 to +0.399 ms |
| Screen destructuring (10 pairs) | 14.644 ms | 14.671 ms | -0.119 to +0.177 ms |
| Screen overload_resolution (10 pairs) | 24.649 ms | 24.087 ms | -0.158 to +0.632 ms |
| Screen class_hierarchy (10 pairs) | 23.127 ms | 22.975 ms | -0.150 to +0.304 ms |
| Screen structural_objects (10 pairs) | 22.430 ms | 22.199 ms | -0.123 to +0.262 ms |
| Screen interface_composition (10 pairs) | 33.643 ms | 33.597 ms | -0.139 to +0.577 ms |
| Screen variadic_tuples (10 pairs) | 30.978 ms | 30.702 ms | +0.025 to +0.551 ms |
| Screen checkjs_jsdoc (10 pairs) | 27.092 ms | 27.067 ms | -0.530 to +0.843 ms |
| Screen commonjs_graph (10 pairs) | 17.557 ms | 17.407 ms | -0.323 to +0.336 ms |
| Screen recursive_generics (10 pairs) | 14.430 ms | 14.192 ms | -0.061 to +0.412 ms |
| Independent null-safe target (30 pairs) | 34.038 ms | 33.841 ms | -0.106 to +2.981 ms |
| Independent checkjs_jsdoc (30 pairs) | 28.408 ms | 28.265 ms | -0.100 to +0.548 ms |
| Independent class_hierarchy (30 pairs) | 24.009 ms | 23.962 ms | -0.138 to +0.365 ms |
| Independent commonjs_graph (30 pairs) | 18.512 ms | 18.708 ms | -0.510 to +0.272 ms |
| Independent destructuring (30 pairs) | 15.484 ms | 15.683 ms | -0.255 to +0.048 ms |
| Independent import_graph (30 pairs) | 18.331 ms | 18.531 ms | -0.964 to +0.173 ms |
| Independent interface_composition (30 pairs) | 35.836 ms | 35.382 ms | +0.087 to +0.959 ms |
| Independent recursive_generics (30 pairs) | 15.197 ms | 15.225 ms | -0.322 to +0.047 ms |
| Independent reexport_graph (30 pairs) | 12.191 ms | 12.248 ms | -0.296 to +0.595 ms |
| Independent type_predicates_large (30 pairs) | 250.842 ms | 251.674 ms | -3.342 to +2.047 ms |
| Independent variadic_tuples (30 pairs) | 33.225 ms | 33.319 ms | -0.291 to +0.563 ms |
