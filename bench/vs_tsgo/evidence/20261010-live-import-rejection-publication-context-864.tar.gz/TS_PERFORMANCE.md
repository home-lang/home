# TypeScript frontend performance

Home maintains a reproducible frontend benchmark for `home-tsc`, TypeScript's
JavaScript implementation (`tsc` 6.x), and stable native TypeScript 7
(`tsgo` in the tables below).
The benchmark measures parse, bind, and type-check work only; all compilers
receive the same valid projects and run with emission disabled.
Ongoing coverage and optimization work is tracked in
[GitHub issue #416](https://github.com/home-lang/home/issues/416).

## Current snapshot

The latest complete timing matrix is `20261010T051920Z`, measuring the landed
[Record and indexed-interface fixes](#imported-record-and-indexed-interface-admission-2026-10-10-utc)
independently of their diagnostic-only admission checks. Home leads **1/20**
workloads and beats native TS 7 on **12/20**; the broader goal remains incomplete.

The later ordered namespace-import candidate is **rejected**, fully restored
and never pushed: independent destructuring confirmation regresses despite
target-scale gains. Its [complete report](#ordered-namespace-import-candidates-2026-10-09-utc)
retains all 592 rounds / 660 admissions and every warning. The matrix below
still measures the accepted compiler without that rejected candidate.

The later JSDoc ancestor-prefix index is **accepted** with a 9.1%-lower
8,192-family exact-parent Home median and all 30 large pairs faster across
five batches. Official/512-family and independent declaration checks remain
inconclusive; recursive generics retains an adverse warning. The
[complete A/B report](#jsdoc-ancestor-prefix-facts-2026-10-09-utc) preserves all
532 rounds / 660 admissions. The five-compiler matrix below now measures the
landed source independently; its ranking is not inferred from the Home-only A/B.

Both later require-presence candidates were **rejected**: the presence-only
design for interface-composition regression and the earlier broad shared-cache
design for class-hierarchy regression. Complete evidence is
[documented below](#presence-specific-require-facts-rejected-2026-10-09-utc).
The current matrix includes the accepted ancestor-prefix index and subsequent
[#846](https://github.com/home-lang/home/issues/846) correctness work, with
neither rejected candidate present. The restored-source snapshot remains
below as a separately versioned historical comparison.
It is a full competitor comparison, not an exact-parent patch A/B.

The virtual-section source index's exact-parent Home-only A/B is separate
from the fresh competitor matrix below. Its scaling gains and unresolved
adverse recursive-generics warning are [documented below](#virtual-section-prefix-facts-2026-10-09-utc).

### Landed Record and indexed interface matrix 2026 10 10 UTC

Result `20261010T051920Z` measures clean source
[`b4985e4bd304ddf1fc9b6e14c375fc1de3878f2e`](https://github.com/home-lang/home/commit/b4985e4bd304ddf1fc9b6e14c375fc1de3878f2e),
with compiler implementation
[`a6570c80599122f4c263527bc35a1c27d65987c3`](https://github.com/home-lang/home/commit/a6570c80599122f4c263527bc35a1c27d65987c3).
A fresh clean standalone build matches qualified native SHA-256
`d58ddc54a147b3ad8b177a98a6b5cda04fd4df77595c5ccf44da690de5d57b32`.
This is a full competitor comparison, not an exact-parent patch A/B or proof
of a causal performance change from the correctness fixes.

All five unchanged byte-pinned compilers pass **145/145 protocol-4 admissions**
on the same 20 positive workloads and nine negative-control projects, including
the complete checked-JS error multiset. Every compiler receives the identical
strict no-emit project, minimal ambient shim, `noLib` and `skipLibCheck` settings.
Bun's existing exact checked-files success policy is preserved; no diagnostics
are filtered. This synthetic frontend suite is not production-library admission.

Three warmups precede 30 fresh processes per compiler/workload in equally
rotating order: **600 original rounds / 3,000 retained samples**. Executable,
payload, input, harness and project-context fingerprints match before and
after measurement. Independent verification checks every order, nonzero
negative exit, complete diagnostic multiset, sample array and archive payload.
No compiler, row, sample or adverse observation is removed or repeated.

Host: Apple M3 Pro / Mac15,6, 11 logical cores, Darwin 27 arm64. Pins are TS6.0.3,
direct native TS7.0.2, Home0.1.0, Rust tsc-rs0.1.0/TS7.1.0-dev and
Bun1.4.3-canary.1+bd599f5af. Home uses pinned Zig2163, stripped ReleaseFast and
`-Denable_jsc=false`. The shared 600-second/3,840-MB guard, machine lock and
disk floors are unchanged. Matrix peak tree footprint is 391 MB, host low-water
45%, and the command exits 0. Evidence export waited for an unrelated live
build's lock; the completed measurement was not restarted.

| Workload | tsc 6.0.3 median | native TS 7.0.2 median | Home median | Rust tsc-rs 0.1.0 median | Bun canary median | Home vs fastest competitor |
|---|---:|---:|---:|---:|---:|---:|
| `checkjs_jsdoc` | 202.5 ms | 23.3 ms | 27.0 ms | 22.6 ms | 13.5 ms | 2.00× slower |
| `class_hierarchy` | 186.6 ms | 21.4 ms | 23.5 ms | 18.0 ms | 13.6 ms | 1.72× slower |
| `commonjs_graph` | 152.0 ms | 17.9 ms | 18.0 ms | 14.7 ms | 11.9 ms | 1.52× slower |
| `control_flow` | 192.4 ms | 27.9 ms | 26.3 ms | 25.0 ms | 16.7 ms | 1.57× slower |
| `deep_types` | 149.9 ms | 22.8 ms | 22.3 ms | 15.4 ms | 14.3 ms | 1.56× slower |
| `destructuring` | 141.6 ms | 17.3 ms | 15.6 ms | 15.1 ms | 11.1 ms | 1.40× slower |
| `generic_calls` | 185.0 ms | 23.8 ms | 23.2 ms | 19.9 ms | 15.0 ms | 1.55× slower |
| `import_graph` | 138.3 ms | 15.7 ms | 18.1 ms | 12.0 ms | 16.4 ms | 1.51× slower |
| `interface_composition` | 208.6 ms | 32.3 ms | 35.4 ms | 24.5 ms | 17.9 ms | 1.98× slower |
| `many_files` | 220.7 ms | 23.8 ms | 23.2 ms | 17.2 ms | 14.2 ms | 1.63× slower |
| `null_safe_access` | 199.0 ms | 27.4 ms | 34.1 ms | 23.6 ms | 16.9 ms | 2.02× slower |
| `overload_resolution` | 204.8 ms | 34.0 ms | 24.5 ms | 27.4 ms | 20.6 ms | 1.19× slower |
| `recursive_generics` | 157.3 ms | 41.6 ms | 14.9 ms | 33.2 ms | 9.5 ms | 1.57× slower |
| `reexport_graph` | 102.0 ms | 11.1 ms | 12.4 ms | 9.3 ms | 9.2 ms | 1.35× slower |
| `startup` | 69.5 ms | 8.0 ms | 3.2 ms | 6.3 ms | 6.6 ms | **2.00× faster** |
| `structural_objects` | 184.5 ms | 26.7 ms | 23.0 ms | 22.6 ms | 16.5 ms | 1.40× slower |
| `tsx_components` | 175.4 ms | 17.0 ms | 19.8 ms | 15.3 ms | 11.1 ms | 1.78× slower |
| `type_predicates` | 237.9 ms | 40.1 ms | 32.6 ms | 34.0 ms | 23.4 ms | 1.39× slower |
| `type_predicates_large` | 1,032.4 ms | 322.1 ms | 251.9 ms | 274.3 ms | 164.4 ms | 1.53× slower |
| `variadic_tuples` | 254.8 ms | 45.2 ms | 32.4 ms | 34.3 ms | 19.7 ms | 1.64× slower |

Home leads **1/20** (startup), beats native TS7 on **12/20**, and loses the
other 19 fastest-competitor comparisons. Bun leads 18 rows; Rust leads imports.
Counts use unrounded medians. These are descriptive observations, not
statistical-significance, equivalence or causal patch claims. Generic calls
is now faster than TS7 and CommonJS slightly slower, without a causal inference
from the earlier matrix's opposite ordering.

The largest current gaps are null-safe access **2.02×**, checked JS **2.00×**,
interfaces **1.98×**, TSX **1.78×** and class hierarchy **1.72×** slower than
the fastest measured competitor. [#864](https://github.com/home-lang/home/issues/864)
tracks current-native null-safe profiling and stronger inferred-local/optional-call
negative controls before new timing. Zod still reports 241 TS diagnostics and
two HM9002 warnings and is unadmitted. Finite/symbolic Record domains, canonical
C++ and Linux/Windows coverage remain incomplete; no unsupported result is
called a win.

The [matrix archive](../../bench/vs_tsgo/evidence/20261010T051920Z.tar.gz)
retains all original arrays and admissions. All **603 payload checksums** verify.
Archive SHA-256:
`0f71bbe9dcc5a51089d993253c956e80ceb24e520c4de13d3eb9f4e02005255b`.
The older matrix below remains a separately versioned historical comparison.

### Landed JSDoc ancestor-prefix matrix (2026-10-09 UTC)

Result `20261009T205353Z` measures clean source
[`0d2b0097abf6dbb37630505b69e8a261c7d53c9a`](https://github.com/home-lang/home/commit/0d2b0097abf6dbb37630505b69e8a261c7d53c9a),
compiler inputs equal
[`11055ba4746b224735c8ec2cba2f5e449bfff980`](https://github.com/home-lang/home/commit/11055ba4746b224735c8ec2cba2f5e449bfff980).
A clean matching standalone build reproduces native SHA-256
`68c6ed517f9125ae1b570ff2e585c5b368745389af828258f6621fe5e6e0311c`.
The accepted ancestor-prefix index is present; both rejected require-presence
variants are absent. This full competitor comparison is not an exact-parent
patch A/B; changes versus earlier matrix runs do not establish causal gains.

All five unchanged byte-pinned compilers pass **145/145 admissions** on the
same 20 positive/nine negative projects, validation protocol **4**, including
TS2322×9, TS2339×3 and TS2345×3 checked-JS negatives. The original strict,
no-emit configuration, minimal ambient fixture library, `noLib` and
`skipLibCheck` settings are identical for every compiler; this is a synthetic
frontend suite, not a production-library admission claim. Canonical Bun
success reports checked-source-file counts rather than silence; its exact
one-line policy is preserved, not diagnostic filtering. Complete negative
code multisets and nonzero exits are independently rechecked for every compiler.

Three warmups precede 30 fresh native processes per compiler/workload in
equally rotating order: **600 original rounds / 3,000 retained samples**.
Before/after executable, payload, input, harness and project-context
fingerprints match. No compiler, workload, diagnostic, round or observation
is removed. No diagnostic image is timed.

Host/tools remain Apple M3 Pro / Mac15,6, 11 logical cores, Darwin27 arm64,
Node26.10.0, Hyperfine1.20.0 and Python3.9.6. Pins remain TS6.0.3, direct
native TS7.0.2, Home0.1.0, Rust tsc-rs0.1.0/TS7.1.0-dev and
Bun1.4.3-canary.1+bd599f5af; all original payload inventories remain unchanged.
Home is pinned Zig2163, stripped ReleaseFast with `-Denable_jsc=false`.
Shared **600**-second/3,840 MB guard, shared lock and disk floors are unchanged;
matrix peak 391 MB, host low-water 40%. The measurement command exits 0.

| Workload | tsc 6.0.3 median | native TS 7.0.2 median | Home median | Rust tsc-rs 0.1.0 median | Bun canary median | Home vs fastest competitor |
|---|---:|---:|---:|---:|---:|---:|
| `checkjs_jsdoc` | 203.3 ms | 23.2 ms | 27.2 ms | 22.4 ms | 13.4 ms | 2.03× slower |
| `class_hierarchy` | 191.6 ms | 21.8 ms | 23.8 ms | 18.4 ms | 14.0 ms | 1.70× slower |
| `commonjs_graph` | 151.0 ms | 18.1 ms | 17.9 ms | 14.8 ms | 12.0 ms | 1.49× slower |
| `control_flow` | 193.8 ms | 27.8 ms | 25.9 ms | 24.8 ms | 16.6 ms | 1.56× slower |
| `deep_types` | 130.1 ms | 21.4 ms | 21.1 ms | 14.1 ms | 13.3 ms | 1.59× slower |
| `destructuring` | 147.4 ms | 17.2 ms | 15.5 ms | 15.8 ms | 11.6 ms | 1.34× slower |
| `generic_calls` | 189.0 ms | 23.5 ms | 23.7 ms | 19.5 ms | 15.1 ms | 1.56× slower |
| `import_graph` | 128.9 ms | 14.7 ms | 17.1 ms | 11.3 ms | 15.1 ms | 1.51× slower |
| `interface_composition` | 199.0 ms | 31.6 ms | 34.0 ms | 23.6 ms | 17.5 ms | 1.95× slower |
| `many_files` | 198.1 ms | 22.5 ms | 21.7 ms | 16.0 ms | 13.2 ms | 1.65× slower |
| `null_safe_access` | 189.6 ms | 26.4 ms | 32.4 ms | 22.6 ms | 16.5 ms | 1.97× slower |
| `overload_resolution` | 211.8 ms | 34.6 ms | 24.7 ms | 27.6 ms | 21.2 ms | 1.16× slower |
| `recursive_generics` | 152.8 ms | 40.0 ms | 14.5 ms | 32.5 ms | 9.4 ms | 1.54× slower |
| `reexport_graph` | 96.7 ms | 10.5 ms | 12.5 ms | 8.9 ms | 8.6 ms | 1.46× slower |
| `startup` | 63.9 ms | 7.5 ms | 2.9 ms | 5.9 ms | 6.3 ms | **2.04× faster** |
| `structural_objects` | 192.1 ms | 27.0 ms | 23.2 ms | 22.7 ms | 16.7 ms | 1.39× slower |
| `tsx_components` | 166.9 ms | 16.2 ms | 19.0 ms | 14.4 ms | 10.5 ms | 1.80× slower |
| `type_predicates` | 235.1 ms | 40.5 ms | 32.7 ms | 34.1 ms | 23.4 ms | 1.40× slower |
| `type_predicates_large` | 1,010.1 ms | 309.8 ms | 244.3 ms | 268.9 ms | 158.5 ms | 1.54× slower |
| `variadic_tuples` | 247.5 ms | 45.8 ms | 31.8 ms | 34.0 ms | 19.2 ms | 1.66× slower |

Home leads **1/20** (`startup`) and beats native TS7 on **12/20**, using
unrounded medians. Bun leads18 and Rust leads imports. These are descriptive
medians, not statistical-significance, equivalence or causal patch claims.
Generic calls is slightly slower than TS7 in this snapshot; no causal
regression is inferred from the earlier13/20 tally. Current gaps include
checked JS **2.03×**, null-safe access **1.97×**, interfaces **1.95×**,
TSX **1.80×** and class hierarchy **1.70×** slower than the fastest measured
competitor. CommonJS is **1.49×** slower. The unchanged Zod198-diagnostic
baseline is not production admission; canonical C++ and Linux/Windows coverage
remain unresolved. Repository Actions was disabled at the recorded earlier
dispatch; no unsupported platform result or new policy change is inferred.

The first supplemental verifier incorrectly required silence for Bun's
canonical positive status. Its correction uses the unchanged registry output
policy; it does not weaken admission. A second attempt reached archive
verification before the separate canonical `run.py evidence` step had been
run. The original completed result was then packaged and fully verified.
Both failure records remain; the original failing script was not captured,
so no reconstruction is mislabeled as an original. **No measurement rerun,
compiler patch, corpus change, pin change or discarded sample** occurred.

The [matrix archive](../../bench/vs_tsgo/evidence/20261009T205353Z.tar.gz)
has **603** verified payload checksums, including all original arrays and
admissions. SHA-256:
`3d65ea6df449742f89053f94b2ae444fb5815ecdfc658b495f4a184fccc98915`.
The [context archive](../../bench/vs_tsgo/evidence/20261009T205353Z-context-854.tar.gz)
retains clean-build/source provenance, full matrix command/log, report tools,
strict verifiers, unchanged harness/profile, both verification-attempt records
and evidence export. It has **28** verified payload checksums, SHA-256:
`2ffe1ac71fa8281953be14098fb0a22ed3f95a5a23fff11d35c6fca965e89eb7`.
The broader #416/#838 goal remains incomplete. Subsequent work must profile
the actual landed source and preserve all existing adverse-risk controls.

### Restored current-main matrix (2026-10-09 UTC)

Result `20261009T194221Z` measures source
[`624916ec4210bb13ebbc8e9368f9f28d9152cb89`](https://github.com/home-lang/home/commit/624916ec4210bb13ebbc8e9368f9f28d9152cb89),
compiler inputs equal
[`37b5225c2`](https://github.com/home-lang/home/commit/37b5225c2cf795e16bf3d20a436a606c0ae594e9).
Native SHA-256:
`34118002e25d69a8351a60ee493c504ca734b477ed31efc79fb03ee63a9ad331`.
Both rejected require-presence variants are absent. This fresh whole-matrix
comparison includes current #846 correctness work, but is not an A/B
attributing cross-run changes to it or any one optimization.

All five unchanged byte-pinned compilers pass **145/145 admissions** on the
same 20 positive/nine negative projects, validation protocol **4**, including
TS2322×9, TS2339×3 and TS2345×3 checked-JS errors. Three warmups precede
30 fresh processes per compiler/workload with equally rotating order:
**600 original rounds / 3,000 retained samples**. Before/after executable,
payload, input, harness and project-context fingerprints match. No compiler,
workload, diagnostic or observation is removed; diagnostic images are not timed.

Host/tools remain Apple M3 Pro / Mac15,6, 11 logical cores, Darwin27 arm64,
Node 26.10.0, Hyperfine 1.20.0 and Python 3.9.6. Compilers remain TS 6.0.3,
direct native TS 7.0.2, Home 0.1.0, Rust tsc-rs 0.1.0/TS 7.1.0-dev and
Bun 1.4.3-canary.1+bd599f5af, with original payload inventories unchanged.
Home is pinned Zig 2163, stripped ReleaseFast with `-Denable_jsc=false`.
Shared 600-second/3,840 MB guard and disk floors are unchanged; peak 394 MB,
host low-water 32%. All jobs are terminal with recorded results.

| Workload | tsc 6.0.3 median | native TS 7.0.2 median | Home median | Rust tsc-rs 0.1.0 median | Bun canary median | Home vs fastest competitor |
|---|---:|---:|---:|---:|---:|---:|
| `checkjs_jsdoc` | 214.7 ms | 24.3 ms | 28.1 ms | 23.7 ms | 14.0 ms | 2.00× slower |
| `class_hierarchy` | 188.4 ms | 21.4 ms | 23.3 ms | 17.8 ms | 13.7 ms | 1.71× slower |
| `commonjs_graph` | 158.5 ms | 18.6 ms | 18.2 ms | 15.2 ms | 12.3 ms | 1.48× slower |
| `control_flow` | 209.4 ms | 28.8 ms | 27.0 ms | 25.7 ms | 17.1 ms | 1.58× slower |
| `deep_types` | 132.9 ms | 21.7 ms | 21.2 ms | 14.2 ms | 13.5 ms | 1.57× slower |
| `destructuring` | 134.7 ms | 16.4 ms | 14.7 ms | 14.0 ms | 10.5 ms | 1.40× slower |
| `generic_calls` | 197.3 ms | 24.8 ms | 24.6 ms | 21.0 ms | 15.7 ms | 1.57× slower |
| `import_graph` | 152.3 ms | 16.0 ms | 18.6 ms | 12.8 ms | 17.6 ms | 1.45× slower |
| `interface_composition` | 220.7 ms | 34.0 ms | 35.7 ms | 25.3 ms | 18.6 ms | 1.92× slower |
| `many_files` | 197.9 ms | 22.2 ms | 21.0 ms | 15.5 ms | 12.6 ms | 1.67× slower |
| `null_safe_access` | 188.0 ms | 26.4 ms | 31.9 ms | 22.1 ms | 15.9 ms | 2.01× slower |
| `overload_resolution` | 197.8 ms | 32.6 ms | 23.6 ms | 26.2 ms | 19.8 ms | 1.19× slower |
| `recursive_generics` | 157.2 ms | 40.2 ms | 14.6 ms | 33.0 ms | 9.4 ms | 1.55× slower |
| `reexport_graph` | 99.3 ms | 10.6 ms | 12.1 ms | 9.0 ms | 8.9 ms | 1.37× slower |
| `startup` | 64.1 ms | 7.4 ms | 2.9 ms | 5.9 ms | 6.3 ms | **2.03× faster** |
| `structural_objects` | 192.3 ms | 27.8 ms | 23.4 ms | 23.3 ms | 17.3 ms | 1.36× slower |
| `tsx_components` | 177.9 ms | 17.1 ms | 20.2 ms | 15.3 ms | 10.9 ms | 1.85× slower |
| `type_predicates` | 241.2 ms | 40.7 ms | 33.3 ms | 34.7 ms | 23.2 ms | 1.43× slower |
| `type_predicates_large` | 1,003.6 ms | 306.5 ms | 243.5 ms | 268.4 ms | 162.9 ms | 1.49× slower |
| `variadic_tuples` | 270.6 ms | 47.8 ms | 33.0 ms | 35.6 ms | 20.2 ms | 1.63× slower |

Home leads **1/20** (`startup`) and beats native TS 7 on **13/20**, using
unrounded medians. Bun leads 18 and Rust leads imports. These descriptive
medians are not statistical-significance, equivalence or causal patch claims.
The new rows cannot establish a causal gain over older runs. Current gaps
include null-safe access **2.01×**, checked JS **2.00×**, interfaces **1.92×**,
TSX **1.85×** and class hierarchy **1.71×** slower than the fastest measured
competitor. CommonJS is **1.48×** slower. Universal leadership, Zod
production admission, canonical C++ admission and other-platform coverage
remain incomplete (#416/#838/#548). Repository Actions was disabled at the
recorded Linux dispatch attempt; no unsupported platform result is inferred.

The [matrix archive](https://github.com/home-lang/home/raw/main/bench/vs_tsgo/evidence/20261009T194221Z.tar.gz)
has **603** verified payload checksums with all original arrays/admissions.
SHA-256:
`16b959d655b2eaf2d16767951f24bb9d48d284a9604fa713d75d5b6dac89b80c`.
The [run-context archive](https://github.com/home-lang/home/raw/main/bench/vs_tsgo/evidence/20261009T194221Z-context-854.tar.gz)
retains runner/log/command, recomputed statistics, table/verifier scripts and
frozen harness/registry with **17** verified checksums. SHA-256:
`0955caf39fda85a25b485c32daa6ae4a5115b686d684ab2c8cb9295a6dcd78e0`.

Repository-wide `bunx --bun pickier .` reports 11,461 existing errors and
10,613 warnings in unchanged code/fixtures; no auto-fixes were applied.
Detailed/README row verifiers, profile count/hash/symbol checks and
`git diff --check` pass. The separate
[publication context](../../bench/vs_tsgo/evidence/20261009-restored-matrix-profile-publication-context-854.tar.gz)
retains the full lint command/log, both report verifiers and terminal job
records, with seven verified payload checksums, SHA-256
`ae40e02b29276068406738962634471c9fc22effaa64f4cf592e9e5495b88200`.

### Previous landed virtual-section matrix (2026-10-09 UTC)

Result `20261009T045701Z` measures source
[`71fa7dbe7`](https://github.com/home-lang/home/commit/71fa7dbe7ca391d2255ab72211c5bbc16df3e1e1),
compiler inputs equal
[`30330c169`](https://github.com/home-lang/home/commit/30330c16947900dd0d9ce441071649c7f822c2fc).
Native SHA-256:
`7ab04d806bc0557ff385a91cc993b95c3a727b7e82353ff3ea3e1b59301f822a`.
This fresh whole-matrix comparison includes virtual-section prefix facts;
cross-run differences are not an A/B proving this patch caused a regression
or improvement in any other compiler/family.

All five unchanged byte-pinned compilers pass the same 20 positive/nine
negative projects: **145/145 admissions**, validation protocol **4**, including
all 15 checked-JS errors (TS2322×9, TS2339×3, TS2345×3). Three warmups precede
30 fresh processes per compiler/workload with equally rotating order:
**600 original rounds / 3,000 retained samples**. Executable/payload/input/
harness/project-context fingerprints match before admission and after timing.
No compiler, family or observation is removed.

Host/tools remain M3 Pro / Mac15,6, 11 logical cores, Darwin 27 arm64,
Node 26.10.0, Hyperfine 1.20.0 and Python 3.9.6. Compilers remain TS 6.0.3,
direct native TS 7.0.2, Home 0.1.0, Rust tsc-rs 0.1.0/TS 7.1.0-dev and
Bun 1.4.3-canary.1+bd599f5af; original extra payload inventories are unchanged.
Home uses pinned Zig 2163, stripped ReleaseFast, `-Denable_jsc=false`.
The shared 600-second/3,840 MB guard and disk floors are unchanged;
peak 381 MB, host low-water 24%. No diagnostic image supplies timings.

| Workload | tsc 6.0.3 median | native TS 7.0.2 median | Home median | Rust tsc-rs 0.1.0 median | Bun canary median | Home vs fastest competitor |
|---|---:|---:|---:|---:|---:|---:|
| `checkjs_jsdoc` | 218.4 ms | 24.8 ms | 29.0 ms | 24.3 ms | 14.2 ms | 2.04× slower |
| `class_hierarchy` | 241.6 ms | 26.4 ms | 27.8 ms | 22.3 ms | 16.9 ms | 1.65× slower |
| `commonjs_graph` | 178.8 ms | 20.9 ms | 28.7 ms | 17.1 ms | 14.1 ms | 2.03× slower |
| `control_flow` | 225.2 ms | 31.1 ms | 28.8 ms | 27.7 ms | 18.0 ms | 1.60× slower |
| `deep_types` | 149.9 ms | 23.3 ms | 22.8 ms | 15.7 ms | 14.7 ms | 1.55× slower |
| `destructuring` | 218.9 ms | 25.0 ms | 21.6 ms | 21.7 ms | 15.9 ms | 1.36× slower |
| `generic_calls` | 233.1 ms | 27.3 ms | 27.3 ms | 23.8 ms | 17.7 ms | 1.54× slower |
| `import_graph` | 148.4 ms | 16.2 ms | 23.2 ms | 12.7 ms | 16.9 ms | 1.82× slower |
| `interface_composition` | 241.1 ms | 36.2 ms | 38.1 ms | 27.2 ms | 20.4 ms | 1.87× slower |
| `many_files` | 212.4 ms | 23.0 ms | 22.5 ms | 17.2 ms | 13.7 ms | 1.64× slower |
| `null_safe_access` | 215.8 ms | 29.5 ms | 35.8 ms | 25.3 ms | 18.2 ms | 1.97× slower |
| `overload_resolution` | 249.2 ms | 38.4 ms | 28.5 ms | 30.9 ms | 23.9 ms | 1.19× slower |
| `recursive_generics` | 162.0 ms | 42.1 ms | 15.7 ms | 34.3 ms | 9.9 ms | 1.58× slower |
| `reexport_graph` | 117.5 ms | 12.3 ms | 14.5 ms | 10.7 ms | 9.8 ms | 1.48× slower |
| `startup` | 68.1 ms | 7.8 ms | 3.2 ms | 6.3 ms | 6.7 ms | **2.00× faster** |
| `structural_objects` | 230.9 ms | 32.0 ms | 26.9 ms | 26.6 ms | 19.5 ms | 1.38× slower |
| `tsx_components` | 193.9 ms | 18.0 ms | 21.1 ms | 16.1 ms | 12.1 ms | 1.75× slower |
| `type_predicates` | 275.5 ms | 46.2 ms | 37.1 ms | 38.6 ms | 26.5 ms | 1.40× slower |
| `type_predicates_large` | 1,099.7 ms | 349.6 ms | 268.7 ms | 287.5 ms | 174.3 ms | 1.54× slower |
| `variadic_tuples` | 266.1 ms | 47.6 ms | 33.8 ms | 35.8 ms | 19.9 ms | 1.70× slower |

Using unrounded medians, Home leads **1/20** (`startup`) and beats native TS 7
on **11/20**. Bun leads 18, Rust leads imports. These are descriptive
medians, not statistical significance, equivalence or causal cross-run claims.
`generic_calls` displays TS 7/Home both 27.3 ms; Home's unrounded median is
higher, so it is not counted as beating TS 7. Current gaps are checked JS
**2.04×**, CommonJS **2.03×**, null-safe **1.97×**, interfaces **1.87×** and
TSX **1.75×** slower than the fastest measured competitor. Exact-parent #854
evidence separately supports checked-JS scale gains and retains the adverse
recursive-generics warning. All-benchmark leadership, canonical admitted C++,
other platforms and Zod production admission remain incomplete (#416/#838/#548).

The [matrix archive](https://github.com/home-lang/home/raw/main/bench/vs_tsgo/evidence/20261009T045701Z.tar.gz)
has **603** verified payload checksums including all original round arrays
and complete admissions. SHA-256:
`900c9ab76a4649f562d0dc1747b97d6e578c2f0bd15f8125f18aa15d8056029e`.
The [run-context archive](https://github.com/home-lang/home/raw/main/bench/vs_tsgo/evidence/20261009T045701Z-context-854.tar.gz)
retains runner/log/command, recomputed statistics, table/verifier scripts
and frozen harness/registry, with **17** verified checksums. SHA-256:
`512ce4c6f1b3aef5f3e045984603aa914cb6eced575e0b6282752c2c7cea4303`.
Matrix and current-source profile job handles are terminal.

### Previous landed nearest-prior matrix (2026-10-09 UTC)

Result `20261009T033439Z` measures source
[`b9e6d2591`](https://github.com/home-lang/home/commit/b9e6d25916804d238c17dc9caee4e1d05fdd3032),
compiler inputs equal
[`af5fb320a`](https://github.com/home-lang/home/commit/af5fb320a7bfb17f0654ff25cd8dec1211f3b4c9).
Native SHA-256:
`69836df6bd81695ed3f78c2b147a7ec8ac908e5e406da5523b9da7ed3c4a895a`.
This fresh whole-matrix comparison includes the nearest-prior declaration
index; it is not an A/B attributing all cross-run changes to that source patch.

All five unchanged byte-pinned compilers pass the same 20 positive/nine
negative projects: **145/145 admissions**, validation protocol **4**, including
all 15 checked-JS rejection errors (TS2322×9, TS2339×3, TS2345×3). Three warmups
precede 30 fresh processes per compiler/workload with equally rotating order:
**600 original rounds / 3,000 retained samples**. Executable/payload/input/
harness/project-context fingerprints match before admission and after timing.
No compiler, family or observation is removed.

Host/tools remain M3 Pro / Mac15,6, 11 logical cores, Darwin 27 arm64,
Node 26.10.0, Hyperfine 1.20.0 and Python 3.9.6. Compilers remain TS6.0.3,
direct native TS7.0.2, Home0.1.0, Rust tsc-rs0.1.0/TS7.1.0-dev and
Bun1.4.3-canary.1+bd599f5af, with original extra payload inventories unchanged.
Home is pinned Zig2163, stripped ReleaseFast, `-Denable_jsc=false`.
The shared 600-second/3,840 MB guard and disk floors are unchanged; peak 395 MB,
host low-water 43%. No diagnostic image supplies matrix timings.

| Workload | tsc 6.0.3 median | native TS 7.0.2 median | Home median | Rust tsc-rs 0.1.0 median | Bun canary median | Home vs fastest competitor |
|---|---:|---:|---:|---:|---:|---:|
| `checkjs_jsdoc` | 198.5 ms | 22.9 ms | 26.8 ms | 22.3 ms | 13.8 ms | 1.95× slower |
| `class_hierarchy` | 181.3 ms | 21.0 ms | 22.8 ms | 17.5 ms | 13.8 ms | 1.66× slower |
| `commonjs_graph` | 147.6 ms | 17.4 ms | 24.1 ms | 14.5 ms | 12.2 ms | 1.98× slower |
| `control_flow` | 188.5 ms | 27.2 ms | 25.6 ms | 24.0 ms | 16.3 ms | 1.57× slower |
| `deep_types` | 130.9 ms | 21.4 ms | 21.3 ms | 14.1 ms | 13.4 ms | 1.58× slower |
| `destructuring` | 133.7 ms | 16.4 ms | 14.6 ms | 14.3 ms | 10.9 ms | 1.33× slower |
| `generic_calls` | 177.5 ms | 22.7 ms | 23.0 ms | 19.0 ms | 14.6 ms | 1.58× slower |
| `import_graph` | 129.1 ms | 14.7 ms | 20.4 ms | 10.9 ms | 14.6 ms | 1.87× slower |
| `interface_composition` | 197.5 ms | 30.9 ms | 33.3 ms | 23.3 ms | 17.7 ms | 1.88× slower |
| `many_files` | 194.5 ms | 21.5 ms | 21.4 ms | 15.5 ms | 12.6 ms | 1.70× slower |
| `null_safe_access` | 187.1 ms | 26.0 ms | 32.0 ms | 22.3 ms | 16.3 ms | 1.96× slower |
| `overload_resolution` | 196.5 ms | 31.9 ms | 23.4 ms | 25.9 ms | 20.0 ms | 1.17× slower |
| `recursive_generics` | 150.7 ms | 39.1 ms | 14.2 ms | 31.9 ms | 9.7 ms | 1.47× slower |
| `reexport_graph` | 95.7 ms | 10.3 ms | 12.1 ms | 8.7 ms | 8.7 ms | 1.40× slower |
| `startup` | 62.7 ms | 7.2 ms | 2.8 ms | 5.6 ms | 6.1 ms | **2.02× faster** |
| `structural_objects` | 183.5 ms | 26.5 ms | 22.4 ms | 22.2 ms | 16.8 ms | 1.33× slower |
| `tsx_components` | 160.4 ms | 15.9 ms | 20.0 ms | 14.1 ms | 10.5 ms | 1.90× slower |
| `type_predicates` | 233.4 ms | 40.1 ms | 32.8 ms | 34.0 ms | 23.4 ms | 1.40× slower |
| `type_predicates_large` | 981.7 ms | 299.3 ms | 238.4 ms | 263.4 ms | 156.7 ms | 1.52× slower |
| `variadic_tuples` | 243.1 ms | 43.6 ms | 30.6 ms | 32.9 ms | 19.1 ms | 1.60× slower |

Home still leads **1/20** (`startup`) and beats native TS7 on **11/20**, using
unrounded medians. Bun leads 18, Rust leads imports. Counts/near ties are
descriptive, not significance/equivalence claims or causal regression verdicts.
`reexport_graph` displays Rust/Bun both 8.7 ms; its winner uses unrounded values.
Current gaps are CommonJS **1.98×**, null-safe **1.96×**, checked JS **1.95×**,
TSX **1.90×**, interfaces **1.88×** slower than the fastest measured competitor.
The exact-parent #854 experiments separately establish scoped gains.
All-benchmark leadership, canonical admitted C++, other platforms and Zod
production admission remain incomplete (#416/#838/#548).

The [matrix archive](https://github.com/home-lang/home/raw/main/bench/vs_tsgo/evidence/20261009T033439Z.tar.gz)
contains all original rounds/admissions and **603** verified payload checksums.
SHA-256:
`eccb0c89d461f28fa2b4ba17f25597e352f81dcf6f932463fc61f330026ff1ea`.
The [run-context archive](https://github.com/home-lang/home/raw/main/bench/vs_tsgo/evidence/20261009T033439Z-context-854.tar.gz)
retains runner/log/command, statistics, table/verification scripts and frozen
harness/registry with **17** checksums. SHA-256:
`0d44e483418bf3a019857dc2cb440fd5e5466faff7c1e42ffe056606ae88cbee`.
Full checker 4,542 and harness 136 remain green; every earlier dated matrix
and all accepted/rejected A/B evidence stay unchanged below.

### Previous landed class-owner matrix (2026-10-09 UTC)

Result `20261009T004232Z` measures source
[`962957813`](https://github.com/home-lang/home/commit/96295781351d015b7ebaafbd368e66f6b21a9c33),
whose compiler inputs equal
[`ac3488350`](https://github.com/home-lang/home/commit/ac348835050d26963166dc276b8774d6d9a8a383),
including both landed #853 indexes. Native SHA-256 is
`fb77a18ed4b9b14a7c0ef29366963166754de8904602c2516ea2d223389cbb82`.
This is a fresh whole-matrix comparison, not a patch A/B attributing every
cross-run change to #853. The exact-parent confirmations remain separate below.

All five unchanged byte-pinned compilers pass the same 20 positive/nine
negative projects: **145/145 admissions**, validation protocol **4**. Checked-JS
rejection requires all 15 errors (TS2322×9, TS2339×3, TS2345×3), not partial
diagnostics or erased types. After three warmups, 30 fresh processes per
compiler/workload rotate command order equally: **600 original rounds /
3,000 retained samples**. Executable/payload/input/harness/project-context
fingerprints match before admission and after timing. No compiler, workload
or observation is omitted.

Host: Apple M3 Pro / Mac15,6, 11 logical cores, Darwin 27.0.0 arm64. Tools:
Node 26.10.0, Hyperfine 1.20.0, Python 3.9.6. Versions remain TS6.0.3,
direct native TS7.0.2, Home0.1.0, Rust tsc-rs0.1.0/TS7.1.0-dev and
Bun1.4.3-canary.1+bd599f5af; both additional payload inventories match their
original registry pins. Standalone Home uses pinned Zig2163, stripped
ReleaseFast with `-Denable_jsc=false`. Guard peak is 389 MB, host low-water 28%;
the shared 600-second/3,840 MB limit and disk floors are unchanged.

| Workload | tsc 6.0.3 median | native TS 7.0.2 median | Home median | Rust tsc-rs 0.1.0 median | Bun canary median | Home vs fastest competitor |
|---|---:|---:|---:|---:|---:|---:|
| `checkjs_jsdoc` | 201.6 ms | 23.0 ms | 28.0 ms | 22.8 ms | 13.3 ms | 2.10× slower |
| `class_hierarchy` | 217.2 ms | 23.1 ms | 26.1 ms | 20.0 ms | 15.0 ms | 1.74× slower |
| `commonjs_graph` | 153.4 ms | 18.1 ms | 24.7 ms | 14.8 ms | 12.2 ms | 2.02× slower |
| `control_flow` | 206.2 ms | 28.7 ms | 27.2 ms | 25.8 ms | 16.9 ms | 1.61× slower |
| `deep_types` | 141.1 ms | 22.4 ms | 22.1 ms | 15.1 ms | 14.1 ms | 1.57× slower |
| `destructuring` | 154.9 ms | 18.1 ms | 16.3 ms | 15.7 ms | 11.8 ms | 1.38× slower |
| `generic_calls` | 200.1 ms | 24.6 ms | 24.9 ms | 21.2 ms | 15.3 ms | 1.63× slower |
| `import_graph` | 146.1 ms | 16.4 ms | 22.4 ms | 12.5 ms | 16.3 ms | 1.79× slower |
| `interface_composition` | 220.7 ms | 33.8 ms | 37.2 ms | 25.9 ms | 18.4 ms | 2.02× slower |
| `many_files` | 210.0 ms | 23.3 ms | 22.1 ms | 16.7 ms | 13.6 ms | 1.63× slower |
| `null_safe_access` | 203.5 ms | 27.7 ms | 33.7 ms | 24.3 ms | 17.1 ms | 1.97× slower |
| `overload_resolution` | 205.8 ms | 33.5 ms | 24.0 ms | 27.0 ms | 20.3 ms | 1.18× slower |
| `recursive_generics` | 159.7 ms | 41.1 ms | 15.0 ms | 33.3 ms | 9.7 ms | 1.56× slower |
| `reexport_graph` | 104.2 ms | 11.1 ms | 13.2 ms | 9.3 ms | 8.8 ms | 1.50× slower |
| `startup` | 69.7 ms | 8.2 ms | 3.3 ms | 6.5 ms | 6.9 ms | **2.00× faster** |
| `structural_objects` | 200.6 ms | 28.6 ms | 24.3 ms | 23.8 ms | 18.0 ms | 1.35× slower |
| `tsx_components` | 173.0 ms | 16.8 ms | 20.8 ms | 14.8 ms | 10.5 ms | 1.98× slower |
| `type_predicates` | 257.1 ms | 43.0 ms | 35.4 ms | 37.3 ms | 25.5 ms | 1.39× slower |
| `type_predicates_large` | 1,120.3 ms | 340.8 ms | 269.5 ms | 296.1 ms | 174.4 ms | 1.55× slower |
| `variadic_tuples` | 283.3 ms | 49.2 ms | 35.3 ms | 37.1 ms | 21.3 ms | 1.66× slower |

Home leads **1/20** (`startup`) and beats native TS7 on **11/20**, using all
unrounded medians. Bun leads 18, Rust leads imports. Small differences/counts
are descriptive, not significance or equivalence claims. The prior native-Go
count was 12/20; `generic_calls` now falls on the other side of the median
comparison. This cross-run count is not a causal regression verdict.
Measured gaps include JSDoc **2.10×**, interface composition/CommonJS
**2.02×**, TSX **1.98×**, and null-safe access **1.97×** slower than the fastest
competitor. All-benchmark leadership, canonical C++ admission, other platforms
and production Zod compatibility remain incomplete (#416/#838/#548).

The [matrix archive](https://github.com/home-lang/home/raw/main/bench/vs_tsgo/evidence/20261009T004232Z.tar.gz)
retains all original rounds, 145 admissions and **603** verified payload
checksums. SHA-256:
`6e7fe267dd31d9ae2e25ac77bd67684f3f90258bb445d4aced1d501686bb034a`.
The [run-context archive](https://github.com/home-lang/home/raw/main/bench/vs_tsgo/evidence/20261009T004232Z-context-853.tar.gz)
retains exact runner/log/command, verification/table scripts, statistics and
harness/registry snapshot with **18** checksums. SHA-256:
`19b062ebcb19a66b39ec55e143c98f8a0fd317b9e480ebb60a166dbfe8c6019b`.
An initial post-run verifier invocation preceded the explicit archive packaging
step and reported its missing archive; the sequencing record is retained.
Packaging then verification succeeded on the same raw data, with no timing
rerun, sample removal or weakened admission. Full harness 136/136 and the
landed source's complete 4,536 checker tests remain green.

### Previous JSDoc-rejection-gated matrix (2026-10-08 UTC)

Result `20261008T213919Z` uses source/harness
[`3491cdb45`](https://github.com/home-lang/home/commit/3491cdb45a78a9b21db5602e5726957b06e7260c)
and validation protocol **4** under
[#852](https://github.com/home-lang/home/issues/852). Compiler inputs equal
`db28b2e10`; the frozen standalone native binary remains SHA-256
`c16c8caaf52d35180a7fcd53b87cac0dd71ff7b86526ef285e09bb4e088335f4`.
This strengthens admission, not compiler speed, and does not attribute
cross-run timing changes to a source patch.
This full matrix predates the later [#853 index](#classinterface-modifier-merge-index-2026-10-08-utc);
its exact-parent A/B is not a fresh five-compiler ranking.

All five byte-pinned compilers pass the same 20 positive and nine negative
projects: **145/145 admissions**. The new checked-JS control plants 15 errors
in separate, untimed copies, covering model assignments/missing members,
callback returns, instance arguments and nested generic values at first,
middle and last families. Expected codes are TS2322×9, TS2339×3, TS2345×3;
partial diagnostics, erased `any`, silent success and abnormal exits fail.
Base three-compiler runs now retain admission evidence too, and reporting
rejects skipped/weakened JSDoc gates or a legacy schedule claiming protocol 4.
The earlier positive-only JSDoc rows stay provisional; they are not
retroactively relabeled as having run these controls.

Host: Apple M3 Pro / Mac15,6, 11 logical cores, Darwin 27.0.0 arm64. Tools:
Node 26.10.0, Hyperfine 1.20.0, Python 3.9.6. Versions remain TS6.0.3,
direct native TS7.0.2, Home0.1.0, Rust tsc-rs0.1.0/TS7.1.0-dev and
Bun1.4.3-canary.1+bd599f5af. Both additional payload inventories match their
unchanged pins. After three warmups, 30 fresh processes per compiler/workload
rotate command order equally: **600 original rounds / 3,000 retained samples**.
Executable, payload, input, harness and project-context fingerprints match
before admission and after timing. No observation or compiler was removed.

| Workload | tsc 6.0.3 median | native TS 7.0.2 median | Home median | Rust tsc-rs 0.1.0 median | Bun canary median | Home vs fastest competitor |
|---|---:|---:|---:|---:|---:|---:|
| `checkjs_jsdoc` | 216.1 ms | 24.4 ms | 30.7 ms | 23.8 ms | 14.3 ms | 2.14× slower |
| `class_hierarchy` | 209.9 ms | 22.4 ms | 25.0 ms | 19.4 ms | 14.6 ms | 1.71× slower |
| `commonjs_graph` | 175.3 ms | 20.1 ms | 28.0 ms | 16.8 ms | 13.2 ms | 2.12× slower |
| `control_flow` | 220.8 ms | 29.9 ms | 27.7 ms | 26.6 ms | 17.9 ms | 1.55× slower |
| `deep_types` | 146.0 ms | 22.9 ms | 22.3 ms | 15.5 ms | 14.7 ms | 1.52× slower |
| `destructuring` | 144.0 ms | 17.3 ms | 15.6 ms | 15.0 ms | 11.0 ms | 1.41× slower |
| `generic_calls` | 207.1 ms | 25.4 ms | 25.2 ms | 21.4 ms | 16.3 ms | 1.54× slower |
| `import_graph` | 140.8 ms | 16.5 ms | 22.0 ms | 12.2 ms | 16.6 ms | 1.80× slower |
| `interface_composition` | 240.4 ms | 34.5 ms | 37.2 ms | 25.8 ms | 19.3 ms | 1.93× slower |
| `many_files` | 233.0 ms | 25.8 ms | 24.0 ms | 18.3 ms | 15.3 ms | 1.56× slower |
| `null_safe_access` | 213.6 ms | 29.4 ms | 35.3 ms | 24.9 ms | 17.5 ms | 2.01× slower |
| `overload_resolution` | 214.8 ms | 34.8 ms | 25.1 ms | 27.9 ms | 21.0 ms | 1.20× slower |
| `recursive_generics` | 163.8 ms | 41.0 ms | 15.2 ms | 33.1 ms | 9.9 ms | 1.54× slower |
| `reexport_graph` | 110.6 ms | 12.1 ms | 14.2 ms | 10.0 ms | 9.9 ms | 1.43× slower |
| `startup` | 78.6 ms | 9.0 ms | **3.6 ms** | 7.5 ms | 7.9 ms | **2.08× faster** |
| `structural_objects` | 201.7 ms | 28.9 ms | 23.8 ms | 24.0 ms | 18.3 ms | 1.31× slower |
| `tsx_components` | 188.3 ms | 18.1 ms | 21.9 ms | 16.5 ms | 11.9 ms | 1.84× slower |
| `type_predicates` | 347.5 ms | 54.4 ms | 40.5 ms | 44.7 ms | 30.8 ms | 1.31× slower |
| `type_predicates_large` | 1,136.6 ms | 347.1 ms | 270.2 ms | 289.7 ms | 172.0 ms | 1.57× slower |
| `variadic_tuples` | 269.5 ms | 46.9 ms | 32.1 ms | 34.9 ms | 19.9 ms | 1.61× slower |

Home leads **1/20** (`startup`) and beats direct native TS7 on **12/20**,
using unrounded medians. Bun leads 18 and Rust leads imports. Counts and small
margins are descriptive, not significance or equivalence claims. The main
measured gaps remain checked JS/JSDoc **2.14×**, CommonJS **2.12×**, null-safe
access **2.01×**, interface composition **1.93×**, and TSX **1.84×** slower.
No universal leadership, other-platform result, canonical C++ selection or
production Zod admission is established. #416/#838/#548 remain open; the
unmodified C++ candidate still fails negative admission and has no timing row.

The [matrix archive](https://github.com/home-lang/home/raw/main/bench/vs_tsgo/evidence/20261008T213919Z.tar.gz)
retains all rounds byte-for-byte, all 145 admissions and **603 verified payload
checksums**. SHA-256:
`d1f7b629929bdc7214bbdaeee3fcc5c79571f21d4808a38a6f3377160e6c2ca0`.
The shared-lock run peaked at 380 MB, with a 30% host low-water mark; the
3,840 MB guard and disk floors are unchanged. Full harness **136/136** passes.

#### Untimed admission and diagnostic profile

All five compilers also pass five isolated feature controls plus their
combined gate: **35** retained process records with exact fixture bytes and
unchanged provenance. This establishes the new gate before the matrix rather
than weakening it around a failure. The diagnostic image passed all **58**
official image admissions and has identical original/renamed **object** instruction bytes,
SHA-256 `1c9d4cd471ae2c71e2e73dff7a4deb0205bb81ef02f4d921fb48976a8da505bb`.
It is never used for timing. An unchanged 8,192-family checked-JS generator
exits zero silently, with stable source/input/binary fingerprints.

Its one-second sample records 428 leaf observations in `checkSourceFile`,
348 in `checkDeclarationSpaceDiagnosticsImpl`, 18 in `jsdoc.parse`, and five
in string interning. These are exploratory leaf counts, not whole-run CPU
percentages or causal proof. The next investigation is
[#853](https://github.com/home-lang/home/issues/853): map the actual sampled
loops and replace repeated metadata scans with complete owned/pass-local facts,
preserving diagnostic ordering, duplicates/merges, virtual sections and OOM
behavior. No guessed source-level optimization is claimed by this sample.

The [admission/profile context archive](https://github.com/home-lang/home/raw/main/bench/vs_tsgo/evidence/20261008-jsdoc-admission-profile-852-853.tar.gz)
retains every isolated/combined process record and exact project, the full
scale source, raw sample, both instruction sections, exact matrix/profile
runners/logs, row statistics, provenance and full harness log. Its **50**
payload checksums verify. SHA-256:
`db598c898ebbd9ef69ad3b3e5a043049780086ac51e237c150cb9c812aa9d5c0`.
Admission probes peak at 95/74 MB and profiling at 308 MB, under the same guard.

## Live HIR import absence rejected 2026 10 10 UTC

The stateless live-HIR absence guard under [#864](https://github.com/home-lang/home/issues/864)
is **rejected and was never pushed**. The independent null-safe target's
paired saving interval spans zero, failing the frozen positive-target
acceptance rule. All **530 original pairs**, **180 initial image admissions**
and **100 per-phase admissions** are retained. No independent risk interval
is wholly negative, but that does not establish equivalence or a target gain.
The candidate and its four tests are removed; source is clean and a fresh
parent build restores the native byte-for-byte.

### Exact implementation and qualification

Parent source is `cb6b427f30b7e346961b8758edfd3b6708087360`; parent/restored native:
`d58ddc54a147b3ad8b177a98a6b5cda04fd4df77595c5ccf44da690de5d57b32`.
Candidate native:
`e3e0be622f647eed2453500eb6d9216516021f796966a6f9ece5d93af8508040`.
Exact source/test patch SHA-256:
`a5ce10d174e5e08bc259c2be027502d2c01b0d422eee5162727f5df248d20b1e`.

The wrapper returned null only when the current HIR import-payload pool was
empty. Every valid import node owns such a payload; later imports invalidate
that absence proof naturally. Every nonempty pool delegated to the original
resolver body, independently verified byte-identical. No source-word,
filename/library predicate, cache, name index, stored resolved type, allocation,
changed search order, body skip, diagnostic suppression or work cap was added.
This was not the rejected ordered namespace-index design under #857.

Before timing, checker **4,557**, Program **255**, driver **200**, CLI **76**,
entrypoint **38** and harness **147** tests pass. Four new tests cover empty,
comment/string, sourceless, virtual namespace/import-equals, unrelated-root
and later-HIR cases. The first checker run passed 4,555 and failed two new
raw-TypeId-equality expectations after dynamic namespace lowering. The retained
correction compares complete structural identity and concrete exported member
types instead of requiring a resolved-TypeId cache; the production resolver
body did not change. All **180 protocol-5 checks** for the five pinned compilers
including the candidate plus the retained Home parent pass. Both Home images
retain the same **241 TS errors / two HM9002 warnings** on the unchanged pinned
Zod graph, which remains unadmitted and untimed.

### Frozen paired protocol and complete results

The protocol was fixed before candidate timing: three warmups, 10 alternating
pairs on all 20 official workloads, a separate 30-pair null-safe target, and
30 independent pairs on ten fixed regression workloads. Any other wholly
negative screen interval would trigger exactly one independent 30-pair
confirmation; none required an additional phase. The re-export screen warning
was already covered by the fixed risk list. All **12 phases** complete with
unchanged before/after executable, payload, corpus, harness and source provenance.

Intervals are paired parent-minus-candidate **mean-saving** 95% percentile
bootstrap intervals, fixed seed **864** and **20,000 resamples**. Medians are
descriptive. The frozen rule requires a positive independent target interval
and rejects any wholly negative independent risk interval. No row, sample or
adverse value is filtered; no phase is repeated, realigned or tuned to pass.

| Phase and workload | Parent median | Candidate median | Paired mean-saving 95% interval |
|---|---:|---:|---:|
| Screen startup (10 pairs) | 2.860 ms | 2.883 ms | -0.142 to +0.053 ms |
| Screen many_files (10 pairs) | 21.026 ms | 20.700 ms | -0.289 to +0.477 ms |
| Screen deep_types (10 pairs) | 21.335 ms | 21.561 ms | -0.436 to +0.553 ms |
| Screen import_graph (10 pairs) | 16.524 ms | 16.419 ms | -0.195 to +0.604 ms |
| Screen reexport_graph (10 pairs) | 11.612 ms | 12.304 ms | -0.973 to -0.058 ms |
| Screen tsx_components (10 pairs) | 18.897 ms | 19.185 ms | -0.461 to +0.062 ms |
| Screen generic_calls (10 pairs) | 22.380 ms | 22.382 ms | -0.296 to +0.361 ms |
| Screen control_flow (10 pairs) | 25.316 ms | 25.009 ms | -0.050 to +0.366 ms |
| Screen type_predicates (10 pairs) | 32.236 ms | 32.073 ms | -0.100 to +0.618 ms |
| Screen type_predicates_large (10 pairs) | 248.142 ms | 243.827 ms | -2.875 to +4.681 ms |
| Screen null_safe_access (10 pairs) | 32.464 ms | 32.544 ms | -0.062 to +0.399 ms |
| Screen destructuring (10 pairs) | 14.644 ms | 14.671 ms | -0.119 to +0.177 ms |
| Screen overload_resolution (10 pairs) | 24.649 ms | 24.087 ms | -0.158 to +0.632 ms |
| Screen class_hierarchy (10 pairs) | 23.127 ms | 22.975 ms | -0.150 to +0.304 ms |
| Screen structural_objects (10 pairs) | 22.430 ms | 22.199 ms | -0.123 to +0.262 ms |
| Screen interface_composition (10 pairs) | 33.643 ms | 33.597 ms | -0.139 to +0.577 ms |
| Screen variadic_tuples (10 pairs) | 30.978 ms | 30.702 ms | +0.025 to +0.551 ms |
| Screen checkjs_jsdoc (10 pairs) | 27.092 ms | 27.067 ms | -0.530 to +0.843 ms |
| Screen commonjs_graph (10 pairs) | 17.557 ms | 17.407 ms | -0.323 to +0.336 ms |
| Screen recursive_generics (10 pairs) | 14.430 ms | 14.192 ms | -0.061 to +0.412 ms |
| Independent null-safe target (30 pairs) | 34.038 ms | 33.841 ms | -0.106 to +2.981 ms |
| Independent checkjs_jsdoc (30 pairs) | 28.408 ms | 28.265 ms | -0.100 to +0.548 ms |
| Independent class_hierarchy (30 pairs) | 24.009 ms | 23.962 ms | -0.138 to +0.365 ms |
| Independent commonjs_graph (30 pairs) | 18.512 ms | 18.708 ms | -0.510 to +0.272 ms |
| Independent destructuring (30 pairs) | 15.484 ms | 15.683 ms | -0.255 to +0.048 ms |
| Independent import_graph (30 pairs) | 18.331 ms | 18.531 ms | -0.964 to +0.173 ms |
| Independent interface_composition (30 pairs) | 35.836 ms | 35.382 ms | +0.087 to +0.959 ms |
| Independent recursive_generics (30 pairs) | 15.197 ms | 15.225 ms | -0.322 to +0.047 ms |
| Independent reexport_graph (30 pairs) | 12.191 ms | 12.248 ms | -0.296 to +0.595 ms |
| Independent type_predicates_large (30 pairs) | 250.842 ms | 251.674 ms | -3.342 to +2.047 ms |
| Independent variadic_tuples (30 pairs) | 33.225 ms | 33.319 ms | -0.291 to +0.563 ms |

The target has 17/30 faster candidate pairs but a saving interval of
**-0.106 to +2.981 ms**. Its parent maximum **60.264167 ms** remains in the data,
not used as a reason to discard or rerun. The re-export screen has a negative
interval; its independent confirmation spans zero. Interface composition's
positive independent interval does not replace the failed primary acceptance.
All other independent risk intervals span zero, which is not equivalence.
The separate five-compiler matrix still leads 1/20 rows and beats native TS7
on 12/20; these Home-only observations do not refresh that ranking.

### Restoration and retained evidence

The guard and four controls were removed through a scoped recoverable patch
reversal, preserving the exact patch in evidence. Fresh clean-parent
ReleaseFast compilation exits 0 and matches the parent hash. Shared
600-second/3,840-MB limits, lock and disk floors are unchanged. A supplemental
completed-data verifier first reached restoration before the confirmed-live
build had produced its metadata; that orchestration failure is retained.
Only the same verifier was rerun after completion, never any measurement.

The [raw rejection archive](../../bench/vs_tsgo/evidence/20261010-live-hir-import-absence-rejected-864.tar.gz)
retains every original pair and admission, full gate logs, source patches,
first test failure, fixed protocol, independent raw/statistical/decision
verifiers and restoration proof. All **1,269 payload checksums** verify.
Archive SHA-256:
`66e1e2d44ee47056cdee463d6b5eb900dadbf10aa1dfa4464c7d081a1b27bda9`.
This exact candidate is not adopted or tuned after rejection. The broader
goal remains incomplete, including Zod, finite/symbolic Record domains,
canonical C++ and other-platform coverage.

## Exact native null safe profile 2026 10 10 UTC

The current-native profile under [#864](https://github.com/home-lang/home/issues/864)
shows displayed PCs in the namespace-import helper's root-statement scan while
checking local signatures on an import-free null-safe workload. This is a
general resolution path to investigate, **not a measured optimization gain**.
The earlier rejected ordered namespace-index design under #857 is not revived
or tuned on the strength of this observation.

### Actual image and input admission

Source is `666a8ada5217013e8337c322c1f2f3e38f2284d4`, compiler implementation
`a6570c80599122f4c263527bc35a1c27d65987c3`. Only the unmodified standalone native
`d58ddc54a147b3ad8b177a98a6b5cda04fd4df77595c5ccf44da690de5d57b32`
is sampled. No diagnostic executable is built, relinked, sampled or timed.
Original object SHA-256:
`266add3b449c17bb470dc801a52ed15d50f5df2671e37085e6a052ab2c08b0b0`.

The existing generator creates 32,768 families, 128 times the benchmark's
256-family structure, without changing types, bodies, strict settings or
compiler mode. Fixed inferred-local negatives at 0/16,384/32,767 require the
same 27 errors. TS6.0.3, native TS7.0.2 and Home pass all **six complete scale
admissions**; all **30 protocol-5 native preflight checks** also pass. Source,
image and positive/negative input inventories remain unchanged. This is an
untimed diagnostic scale, not a new ranked benchmark row.

### Fixed windows and displayed addresses

One native process finishes silently with exit 0. Two one-second exploratory
windows run at fixed offsets 0.1 and 60 seconds, actually starting at 0.105
and 60.004 seconds. The original two-second middle-window estimate was revised
**before any sampling** after observing the positive admission still live at
119 seconds; the old plan and rationale are retained. No window or process is
repeated to obtain a desired result. There are zero benchmark timing samples.

The early/middle samples contain **817/830 main-thread observations** and
explicit displayed PCs resolve to **181 symbols**. The stripped call graph
collapses under `main`; inclusive group counts and ellipses remain unassigned.
Neither those counts nor the displayed offset sets establish per-function
CPU percentages, whole-run CPU shares or causal performance gains.

| Current native symbol | Preferred address | Early displayed offsets | Middle displayed offsets |
|---|---|---|---|
| `moduleNamespaceTypeForLocalImport` | `0x1002eda08` | 188 | 188, 200 |
| `checkFnSignatureOnly` | `0x10051ab44` | 19,852, 22,872 | 19,852, 20,788, 32,528 |
| `aliasedGuardReferencesAreStable` | `0x1003320c0` | 152, 180, 456, 488 | 152, 180, 456, 488 |

The actual native disassembly places namespace offsets 188/200 in the loop
that decrements the remaining root-statement count and reads statement kinds.
The scaled project has no import declarations. A future absence/binding proof
must preserve resolution order, dynamic lowering, malformed/recovery sources,
source ownership, virtual sections and later HIR changes; a source-word guess
or previously rejected cache is not sufficient qualification.

### Address proof and retained evidence

The original cached link image matches the sampled image byte-for-byte.
Object text **9,675,952 bytes** maps into native text **9,677,200 bytes** with
zero differences outside **159,379 declared relocations**, covering **633,792
whole relocation-sized bytes**. These masks do **not** prove opcode or bit
equivalence inside relocated words. All **5,890 original symbol ranges** are
verified; the extra **1,248 native-tail bytes** remain unmapped. ASLR resolution
uses the actual sample load address, not old-image addresses. Independent
verification retains every raw line, displayed PC, ellipsis and collapsed count.

The unchanged 600-second/3,840-MB guard and shared lock remain. Scale admission
peaks at 2,377 MB and the single native profile at 687 MB; both exit 0. Earlier
queue waits leave unrelated builds intact. No guard is raised or diagnostic
check skipped. The [raw profile archive](../../bench/vs_tsgo/evidence/20261010-exact-native-nullsafe-profile-864.tar.gz)
retains exact text sections, relocation/symbol tables, input projects, every
admission, raw samples, procedure revision, original source/disassembly and
independent verifiers. All **46 payload checksums** verify. Archive SHA-256:
`9dcf699825b34f6f7b5a69d0d20030326566ced5e017f2b3cdf133f0afee7bdb`.
The separate competitor matrix remains 1/20 leads and 12/20 versus native TS7.
Zod, finite/symbolic Record domains, canonical C++ and other-platform coverage
remain incomplete; this profile does not establish universal leadership.

## Null safe inferred result admission 2026 10 10 UTC

The stronger null-safe contract under [#864](https://github.com/home-lang/home/issues/864)
is [landed](https://github.com/home-lang/home/commit/5a5db509af878cc8163fe680640e8b7d9e9ab1d6).
All **150 protocol-5 admissions** pass across the five unchanged pinned
compilers and all 20 existing workloads. The compiler and timed corpus are
unchanged; these are **untimed diagnostic checks**, not a speedup.

The controls run inside `readNullable` at the first, middle and last families
(0/128/255), checking actual inferred locals rather than only the explicit
exported tuple annotations. The original project is copied for each negative
audit; no timed source is edited or replaced.

| Control per family | Required diagnostic | Features checked |
|---|---|---|
| Wrong label, score, formatted value and non-null fallback types | Four TS2322 | Inferred optional access, nullish fallback and optional call results |
| Optional label and call assigned to non-optional string | Two TS2322 | Preserved undefined in optional results |
| Optional formatter called with a number | One TS2345 | Argument checking through optional calls |
| Optional tuple access at index 2 | One TS2493 | Exact readonly tuple bounds |
| Missing profile member | One TS2339 | Member checking through optional access |

Each compiler rejects the negative project with exactly **27 errors**:
18 TS2322 and three each TS2339/TS2345/TS2493. All five positive projects also
pass the unchanged success policy. Version, executable, payload and original
input fingerprints match; no source body, compiler diagnostic or output rule
is skipped. The complete suite now has ten negative-control projects, and
the reporter requires all their records plus the full null-safe multiset.

All **147 harness tests** pass. Regressions reject silent successes, incomplete
diagnostics, abnormal exits, weakened contracts, missing source anchors,
missing admission records and legacy measurement schedules. Protocol 5 keeps
the complete JSDoc gate; protocol-4 results remain readable and retain their
original identity. Updated reporters mark null-safe ratios without protocol-5
inferred-local controls provisional. The matrix `20261010T051920Z` remains
protocol 4; successful later controls are not retroactively called pre-timing
admission. All original samples remain unchanged.

Qualification ran on `1c0f38f07ec37c445b46bb894ae5f844f448ed30` plus patch
SHA-256 `7a53f73ac4dfbdd1b9fb8b0298c4cc5e6434e32b49d6d2ec3914505ad8f0a28e`.
The compiler is still native
`d58ddc54a147b3ad8b177a98a6b5cda04fd4df77595c5ccf44da690de5d57b32`.
The full untimed admission command exits 0 under the unchanged shared
600-second/3,840-MB guard, peak tree footprint 264 MB. No measurement is rerun.
One initial unit expectation treated schema 5 as unsupported for JSDoc;
the retained correction explicitly verifies both schemas 4 and 5 and rejects
unknown schema 6, without weakening either contract.

The [raw admission archive](../../bench/vs_tsgo/evidence/20261010-nullsafe-inferred-admission-864.tar.gz)
retains complete process records, original and mutated projects, source patch,
qualified harness, full test log, first unit-expectation failure and independent
admission verification. All **24 payload checksums** verify. Archive SHA-256:
`6084fa605da7cdc3b7dd8858934b635ff57d799e65329281d82f3b0b02958ca2`.
General current-native profiling and performance optimization remain open.
Zod, finite/symbolic Record domains, canonical C++ and other-platform coverage
remain incomplete; universal leadership is not established by these controls.

## Imported Record and indexed interface admission 2026 10 10 UTC

The general fixes under [#863](https://github.com/home-lang/home/issues/863)
are [landed](https://github.com/home-lang/home/commit/a6570c80599122f4c263527bc35a1c27d65987c3).
Closed Record index domains, imported literal aliases and indexed-interface
returns retain their checked types. The existing five-compiler benchmark
protocol passes all **145 admission checks**, but these are **untimed results,
not a speedup or refreshed ranking**. Complete Zod admission, finite/symbolic
Record domains, canonical C++ admission and other-platform coverage remain
incomplete; universal benchmark leadership is not established.

### Exact semantics and diagnostic controls

`Record<string, V>`, `Record<number, V>`, `Record<symbol, V>` and their key-domain
unions use the existing exact Program index representation. Their complete
value graphs, generic interface members and readonly flags are preserved.
Qualified imports no longer reduce these supported graphs to partial
projections. Finite or symbolic keys are not widened into string indices;
their unfinished representation remains visible.

Two general defects were exposed by the wider graph: literal checking did
not resolve imported alias instances, and a return-shape predicate treated
object intersections as non-objects. Literal checking now resolves the alias;
return checking uses the structural intersection relation. Recursive traversal
reacquires immutable union/intersection members by index so interning cannot
invalidate borrowed pool slices. No library/filename special case, `any`
fallback, skipped diagnostic, semantic cap or benchmark shortcut was added.

Home, pinned TS 6.0.3 and native TS 7.0.2 receive identical strict diagnostic
projects. General probes use the benchmark's shared `noLib` ambient shim;
full Zod uses its normal target libraries. Negative controls are untimed copies,
never replacement timed sources.

| Diagnostic case | Parent or retained pre-fix Home | Final Home | TS 6 and native TS 7 |
|---|---|---|---|
| Four closed Record-domain positives | TS2304 and TS2339 | Silent success | Silent success |
| Each closed Record-domain negative | Wrong error set from missing inherited types | Two TS2322 and one TS2339 | Same exact errors |
| Full inherited/qualified Record fixture | Not separately compared | Silent positive; six TS2322, one TS2339 and one TS2542 negative | Same exact result |
| General indexed-interface fixture | Four false-positive TS2322 | Silent positive; three TS2322 negative | Same exact result |
| Isolated original upstream JSON-schema declarations | Positive silent, both negative controls missed | Silent positive; two TS2322 negative | Same exact result |
| Finite Record-key fixture | Fails admission | Still fails admission | Silent positive; exact negative errors |

All **48 final Home processes** are retained: **46 supported checks pass**
and **two finite-key checks fail**. The earlier 24 positive import checks,
48 recursive-constructor checks and 24 cyclic-import checks did not reproduce
the defect and are retained. The first property-removal reduction introduced
reference-compiler excess-property errors and is rejected as a reproducer.
Later reductions require silent reference admission and separate the return
and literal failures; neither requires recursion. Failed or inapplicable
probes are not discarded.

### Complete Zod remains unadmitted

All three compilers receive the identical strict NodeNext, ES2022, no-emit
configuration and **106 unmodified production files** from the pinned Zod
4.5.2 npm archive. Its SHA-512 and every production-file SHA-256 verify.
Configuration SHA-256:
`80c3c21c184d02b7ee451da35640c461cad77061b7a72f5058541cb3c8916d05`.
Upstream tests are excluded as the same project boundary for every compiler,
not as a compiler-specific exception.

| Complete graph revision | Home TS errors | Home HM9002 warnings | TS 6 and native TS 7 |
|---|---:|---:|---|
| Clean parent | 195 | 3 | Silent success |
| Initial Record transfer candidate | 244 | 2 | Same unchanged graph; silent success |
| Landed literal, return and pool-safety fixes | 241 | 2 | Same unchanged graph; silent success |

The erroneous missing `$ZodError` heritage is resolved and the isolated
JSON-schema controls pass, but many other errors become visible under the
wider exact graph. More diagnostics are not a quality or performance gain.
Final counts include 186 TS2345, 20 TS2339, 11 TS7006, 10 TS2322, five TS2774,
two each TS2304/TS2344/TS2698/TS4110, and one TS18048. Zod remains **unadmitted
and untimed** under [#548](https://github.com/home-lang/home/issues/548).
No sources, configuration, libraries or error checks were relaxed.

### Qualification and retained evidence

Final source gates ran on parent
`ec18f7fb3bed4a614f02d0c1eb91da099f9a3491` plus exact patch SHA-256
`70a8d18950fd305be59e4a91124cb34abcefa19ce1bf74a98de2d93618970495`:
Program **255**, checker **4,553**, driver **200**, CLI **76**, entrypoint
**38**, and benchmark harness **136** tests pass. Formatting and diff checks
pass. The unchanged protocol-4 admission passes all **145 processes** across
five pinned compilers, 20 positive workloads and nine negative-control projects,
with identical before/after artifact provenance. Bun retains the existing
checked-files success policy; no output rule changed.

Both newer runtime commits through
`c1e00c785b2d62a57286d237a0a3ea5399dd3db3` are preserved. Compiler/build/benchmark
paths and the patch match; a fresh post-sync build matches the qualified native
byte-for-byte:
`d58ddc54a147b3ad8b177a98a6b5cda04fd4df77595c5ccf44da690de5d57b32`.
Earlier results retain their own image identities, not relabeled final-image
tests. Heavy compiler jobs use the unchanged 600-second, 3,840-MB guard and
shared machine lock.

The [raw evidence archive](https://github.com/home-lang/home/raw/main/bench/vs_tsgo/evidence/20261010-record-indexed-admission-863.tar.gz)
retains the pinned archive, exact production and diagnostic projects, all
process outputs, earlier failures, rejected reductions, patches, qualified
source, canonical inputs, full test logs, independent verifiers and main-sync
proof. All **2,022 payload checksums** verify. Archive SHA-256:
`7d8b465183c7071fba65fc16e381694135175e1733ab617a828238fa42749586`.
Native binaries are identified by hash, not republished. The first packaging
attempt requested nonexistent `build.zig.zon` and failed before archive creation;
that failure and correction are retained, with no compiler or timing rerun.

## Simple value name guard 2026 10 10 UTC

The stateless guard under [#861](https://github.com/home-lang/home/issues/861)
is **not admitted and was never pushed**. The experiment retains **706 of
712 planned timing pairs** and **all 660 admissions**, but it does not
complete the frozen five-batch protocol. One batch lost its execution/guard
record after interruption; the fifth was stopped at the disk floor and
contains no completed timing pairs. All six candidate controls and the guard
are removed, newer upstream work preserved, source clean and native restored
byte-for-byte. No completed timings were repeated to obtain a pass.

The official and 512-family independent confirmations have slower candidate
medians and zero-spanning saving intervals. Interface composition has a
wholly negative family-screen interval, but neither its independent recheck
nor the separate declaration check confirms that loss. No retained independent
risk/declaration interval is wholly negative. This is **not equivalence or
acceptance**: the required large target and execution evidence remain incomplete.
The completed fourth large batch's positive interval does not replace the
missing fifth batch or qualify the interrupted third batch.

### Source identity and implementation

Full semantic gates ran on
[`e7206761f810020aae39fc81d88e363becab0d46`](https://github.com/home-lang/home/commit/e7206761f810020aae39fc81d88e363becab0d46).
The measured parent was
[`6863bd9c3ffd4426681d338504c2411f3b8dee5c`](https://github.com/home-lang/home/commit/6863bd9c3ffd4426681d338504c2411f3b8dee5c).
The tracked compiler/build/configuration/benchmark definitions matched between
these commits, tree-record SHA-256
`7d1b0cc9217a73fa0c22496a81f0ee5e6558657222a01dceead2133c5424ef6c`.
Fresh clean-parent and reapplied-candidate builds matched both originally
qualified images byte-for-byte. Original gates retain their actual source;
they are not relabeled as executions on another commit.

- Parent/restored native: `68c6ed517f9125ae1b570ff2e585c5b368745389af828258f6621fe5e6e0311c`.
- Candidate native: `0acd7ea8defe80b902f5a04b05cb3db5ac634046d0544bdc1852d0f4454d2657`.
- Exact source/test patch: `21306acd6474df14190bb9dd92eb1b43f599f1d4c856def9d08e069b440784e5`.
- Original protocol: `3269be55e82316b9f574b233f6a414790dc1c22404bb41d014f85c34de0d4a77`.
- Measured-parent protocol: `c3198f2015d8daad36938d228853a5b3e4ddc6d80db840385ffbc1c56b032317`.

An assertion proves only the parent-source provenance changed during
reconciliation; all timing, admissions, retention and acceptance rules stayed
identical. Restoration source is
[`59e66f30863c005a5719eb33a86ddd57701d9ae7`](https://github.com/home-lang/home/commit/59e66f30863c005a5719eb33a86ddd57701d9ae7).
Its newer runtime/build changes are preserved; its fresh standalone compiler
still matches the measured parent bytes.

The archived runtime change adds 21 lines around the unchanged complete value
resolver. Only a provably different simple identifier name in a variable,
function or class declaration/expression may return null before entering
visibility and the full resolver. Matching names, patterns, imports, loops,
absent/malformed names and all other kinds use the original resolver.
One export layer, original statement order, visibility, live TypeIds, lowering,
shadowing, deprecation and error behavior remain. There is no cache, root-only
restriction, library/filename/benchmark rule, body omission or semantic cap.
An automated comparison proves the entire shared original resolver body is
byte-identical. These properties describe the archived unadmitted design,
not current production code.

The actual-native profile displayed resolver offsets 24/120/168/636 early and
24/212 middle; its disassembly contains a 320-byte frame and visibility before
simple-name matching. These observations identify work, not CPU shares or a
causal speed estimate. A separate one-second sample of the Zig compiler during
long test compilation shows LLVM code generation/register allocation, not
Home runtime performance.

### Correctness and resource controls

Six controls cover fast/scalar types and complete diagnostics for every HIR
node/identifier in representative projects; unrelated-name zero-allocation
versus matching visibility OOM fallback and live types; all seven simple
declaration kinds plus direct/nested/empty exports and malformed names;
live name changes with unchanged node count and actual higher NodeIds inserted
first; every forced-growth visibility-metadata allocation failure with cleanup;
and complete variable/function/class deprecation suggestions and related
declaration information.

Full **checker 4,559 / binder 21 / Program 251 / driver 200 / CLI 76 /
entrypoint 38** suites passed without named filters, plus the native build
and **136** harness tests. Six untimed full-native controls compare complete
stdout/stderr/exit status across visibility, patterns/loops, overloads, scopes,
exports and checked JavaScript. Pinned Zod 4.5.2 retains **195 TS + 3 HM9002**
primary diagnostics with unchanged positions, messages and multiplicity:
`6bf2feb527d91c651631642e523da6d28cd2b0c7ae4898cac0888aa7b420874f`.
Zod remains **unadmitted**, not compatible merely because failures match.

The 600-second / 3,840-MB tree-footprint guard, shared lock and
1,024/512-MB disk admission/continuation floors are unchanged. All waits,
resource failures and host variation remain in the evidence. Before current
control builds, 80 old closed owned Zig test-cache files totaling
1,001,948,584 bytes were recovered into a locally retained archive, every
payload/hash/path/mtime/open-file check verified, then only those exact files
unlinked. Recovery archive SHA-256:
`71fd819f0e5aa0f15bfdd2b8baeba8a481d62c4b0004b7a0b7ec32896cb87221`.
Source, native images, raw benchmark data, recent outputs and unrelated work
were not removed. The manifest and cleanup record are in the raw archive.

### Interruption and incomplete execution

The original orchestration/guard/logging processes disappeared after the
conversation was deliberately interrupted. The third-batch orphan was
observed finishing its final pair, then ended; all six original raw pairs and
66 admissions survived, but canonical summary, wrapper exit and guard
completion did not. A separate data-only recovery rechecks every pair's
exit code, order, count and unchanged fingerprints and applies the same frozen
saving calculation. It runs no compiler/timer and does **not** infer a zero
wrapper exit or fully guarded execution.

The initial recovery helper rejected its fingerprint assertion because its
extracted fingerprint function evaluated the helper's `__file__`, rather than
the frozen runner's path. The dependent continuation stopped before executing
any phase. Correcting that context retained exact fingerprint equality;
the failed attempt remains. Only never-started phases were dispatched.

The fifth batch passed all 66 original admissions, then the guard stopped it
at **485 MB free**, below the unchanged 512-MB critical floor, with **exit 123**.
It has **zero completed timing pairs**. Warmup or unexported timer progress is
unconfirmed, and the phase was not retimed. After disk space recovered without
another deletion or floor change, only the never-started 11 risk rechecks and
class/interface checks ran.

The original frozen verifier remains unchanged and exits one for missing
canonical third/fifth-batch results. The supplemental data audit verifies
706 retained pairs, 594 admissions attached to timed-data phases and the failed
fifth batch's 66 admissions, totaling 660. It explicitly reports
`execution_qualified: false`, `candidate_eligible_for_production: false`
and an incomplete five-batch protocol. It is **not** a substitute execution
pass. The planned 712 pairs/30 large pairs are not relabeled as 706/24.

### All retained measurements

Pairs use fresh native processes in alternating order; each started phase
requires the original complete positive/negative controls, including all 15
checked-JS errors at first/middle/last. Positive mean-saving intervals favor
the candidate. Third-batch values below are recovered data only; batch five
has no timing result. No pooled four-batch interval is substituted for the
predeclared five-batch target.

| Retained measurement | Parent median | Candidate median | Candidate faster | Paired mean saving 95% interval |
|---|---:|---:|---:|---:|
| Official checked JS screen | 36.077 ms | 37.863 ms | 8/20 | -5.261 to +0.723 ms |
| 512 family screen | 154.728 ms | 158.185 ms | 2/6 | -15.598 to +10.656 ms |
| 8192 family screen | 11,151.313 ms | 10,735.609 ms | 4/6 | -723.334 to +1,851.352 ms |
| Official checked JS independent confirmation | 36.102 ms | 37.224 ms | 12/30 | -4.705 to +1.400 ms |
| 512 family independent confirmation | 147.629 ms | 149.565 ms | 10/30 | -3.734 to +2.916 ms |
| 8192 family batch 1 | 13,205.332 ms | 10,679.446 ms | 4/6 | -2,848.505 to +9,345.077 ms |
| 8192 family batch 2 | 10,721.569 ms | 9,743.467 ms | 4/6 | -1,174.681 to +2,832.900 ms |
| 8192 family batch 3 data recovered execution unconfirmed | 14,264.008 ms | 15,088.627 ms | 3/6 | -15,472.494 to +8,329.141 ms |
| 8192 family batch 4 | 11,085.269 ms | 9,518.928 ms | 6/6 | +253.933 to +4,314.435 ms |
| 8192 family batch 5 disk stopped | No completed pairs | No completed pairs | 0/6 planned | Not available |

| All family screens ten pairs each | Parent median | Candidate median | Candidate faster | Paired mean saving 95% interval |
|---|---:|---:|---:|---:|
| `checkjs_jsdoc` | 36.714 ms | 36.599 ms | 5/10 | -2.340 to +5.213 ms |
| `class_hierarchy` | 34.655 ms | 33.485 ms | 7/10 | -9.890 to +11.369 ms |
| `commonjs_graph` | 30.239 ms | 28.085 ms | 5/10 | -11.694 to +6.285 ms |
| `control_flow` | 37.888 ms | 43.454 ms | 2/10 | -18.363 to +1.386 ms |
| `deep_types` | 31.766 ms | 31.556 ms | 3/10 | -17.911 to +7.405 ms |
| `destructuring` | 20.248 ms | 19.747 ms | 6/10 | -2.125 to +8.853 ms |
| `generic_calls` | 43.953 ms | 46.195 ms | 3/10 | -7.080 to +3.232 ms |
| `import_graph` | 29.103 ms | 27.347 ms | 5/10 | -3.943 to +6.277 ms |
| `interface_composition` | 47.791 ms | 60.971 ms | 1/10 | -17.033 to -4.314 ms |
| `many_files` | 31.675 ms | 30.160 ms | 6/10 | -3.991 to +9.842 ms |
| `null_safe_access` | 55.926 ms | 53.872 ms | 6/10 | -8.191 to +9.169 ms |
| `overload_resolution` | 35.088 ms | 35.268 ms | 5/10 | -10.153 to +1.867 ms |
| `recursive_generics` | 21.829 ms | 21.562 ms | 6/10 | -3.288 to +4.780 ms |
| `reexport_graph` | 16.295 ms | 17.249 ms | 4/10 | -4.339 to +1.999 ms |
| `startup` | 3.919 ms | 3.923 ms | 2/10 | -0.437 to +0.120 ms |
| `structural_objects` | 33.735 ms | 33.024 ms | 4/10 | -4.218 to +4.359 ms |
| `tsx_components` | 27.006 ms | 26.138 ms | 5/10 | -2.199 to +6.269 ms |
| `type_predicates` | 49.344 ms | 49.236 ms | 5/10 | -16.832 to +13.905 ms |
| `type_predicates_large` | 363.625 ms | 361.548 ms | 4/10 | -42.973 to +53.632 ms |
| `variadic_tuples` | 46.162 ms | 48.706 ms | 6/10 | -3.597 to +3.486 ms |

| Independent risk checks thirty pairs each | Parent median | Candidate median | Candidate faster | Paired mean saving 95% interval |
|---|---:|---:|---:|---:|
| `checkjs_jsdoc` | 43.210 ms | 42.132 ms | 16/30 | -3.246 to +1.862 ms |
| `commonjs_graph` | 30.045 ms | 29.216 ms | 12/30 | -2.117 to +2.567 ms |
| `control_flow` | 43.360 ms | 46.292 ms | 14/30 | -7.450 to +18.563 ms |
| `deep_types` | 52.372 ms | 54.734 ms | 12/30 | -5.566 to +20.171 ms |
| `destructuring` | 25.443 ms | 24.698 ms | 16/30 | -3.190 to +3.141 ms |
| `generic_calls` | 44.622 ms | 42.863 ms | 17/30 | -4.775 to +6.454 ms |
| `interface_composition` | 52.294 ms | 50.145 ms | 13/30 | -13.029 to +7.541 ms |
| `recursive_generics` | 29.591 ms | 32.065 ms | 12/30 | -23.980 to +3.673 ms |
| `reexport_graph` | 21.523 ms | 19.147 ms | 15/30 | -3.632 to +4.041 ms |
| `type_predicates_large` | 565.326 ms | 624.102 ms | 13/30 | -242.097 to +295.340 ms |
| `variadic_tuples` | 107.637 ms | 98.618 ms | 19/30 | -21.083 to +44.561 ms |

| Independent declaration checks thirty pairs each | Parent median | Candidate median | Candidate faster | Paired mean saving 95% interval |
|---|---:|---:|---:|---:|
| `class_hierarchy` | 41.582 ms | 46.604 ms | 9/30 | -7.434 to +0.985 ms |
| `interface_composition` | 55.683 ms | 62.015 ms | 11/30 | -15.476 to +23.459 ms |

Variation remains visible: the first batch includes a 23.417-second parent,
the recovered third batch a 38.239-second candidate, and the separate interface
check retains parent 348.693-ms and candidate 253.093-ms observations.
The interface screen's negative interval and all slower or inconclusive points
remain; later zero-spanning intervals do not erase the screen. No sample
filter, alignment tuning, changed warmups, skipped checking or repeat-to-pass
is used.

### Evidence and scope

The [complete retained raw archive](https://github.com/home-lang/home/raw/main/bench/vs_tsgo/evidence/20261010-simple-value-name-guard-incomplete-861.tar.gz)
contains **2,001** verified payload checksums. SHA-256:
`eed995b6427dfa34c77f25f66d0b0641d75a925332ddd1629504b6008471845b`.
It retains every original pair/admission, interrupted and disk-stop records,
strict-verifier failure, separate recovery/data audit, original experiment,
source/input/native proofs, all correctness gates and complete diagnostic
fixtures, cleanup manifest, failed helper attempt, exact generated inputs and
nine explicitly labeled untimed negative-project generator replays.
Replays execute no compiler and are not original admissions/timings.
The large cache-recovery capsule stays local; its verified manifest and hash
are retained, not mistaken for benchmark data.

This is unadmitted Home-only data, not an update of the separate five-compiler
ranking: **Home 1/20 leads and 12/20 versus native TS7** remains the last
published matrix. Linux workflow listings and permissions report active/enabled,
but actual dispatch still returns HTTP 422 and no run exists; no settings were
changed. Canonical C++, Linux/Windows coverage and Zod admission remain unresolved.
The full [#416](https://github.com/home-lang/home/issues/416) goal is incomplete.
Further work under [#861](https://github.com/home-lang/home/issues/861) must not
revive this run, retime failures to obtain a pass or treat absent confirmed
regressions as equivalence.

The [publication context archive](https://github.com/home-lang/home/raw/main/bench/vs_tsgo/evidence/20261010-simple-value-name-incomplete-publication-context-861.tar.gz)
retains lint commands/logs, complete claim verifier, restoration, known
terminal/failed/unknown job outcomes, the strict verifier failure and separate
data audit, with **16** verified payload checksums. SHA-256:
`236748dc5fd5413e69b0d045c10b059499580ef540ea9ee27e7e6ea00ab9e864`.
Repository-wide `bunx --bun pickier .` exits one with **11,460 errors and
10,614 warnings** outside the changed Markdown; no broad auto-fix is applied.
Focused Pickier on both changed files exits zero. Full tables, selected README
rows/links, all 2,001 raw checksums, incomplete scope and restored native verify.

## Shared function statement groups 2026 10 10 UTC

The candidate under [#859](https://github.com/home-lang/home/issues/859) is
**rejected and never pushed**. Independent large-predicate checking rises from
242.178 to 243.708 ms, with only 12/30 pairs faster and a paired mean-saving
95% interval of **[-7.550, -0.122] ms**. That confirmed regression overrides
the supported checked-JS scaling gain. The candidate and all nine candidate
controls are removed; source is clean and native restored byte-for-byte.
All **622 pairs / 660 admissions** remain in the result, without retiming,
sample exclusions, layout/alignment tuning or skipped checking.

The five 8,192-family batches have pooled medians of 7,295.837 versus
6,566.492 ms, 10.0% lower candidate elapsed time and 30/30 faster pairs.
The pooled saving interval is [+616.393, +1,052.243] ms; the supplemental
five-batch interval (df=4) is [+530.419, +1,138.216] ms. Both support this
scoped target gain, not acceptance or universal leadership. Every batch is
included, with three fresh warmups per binary per batch. Parent observations
of 9.878 and 9.138 seconds and a candidate observation of 8.445 seconds
remain; variation is not filtered away.

### Source and native identity

Full semantic gates ran on
[`aea27323599a13051ce1bfb8a98a19f4de457d1d`](https://github.com/home-lang/home/commit/aea27323599a13051ce1bfb8a98a19f4de457d1d).
Before timing, the source was clean-fast-forwarded to the measured and
restored parent
[`dad1ea95f27a724574772bb2882a34576d7282bb`](https://github.com/home-lang/home/commit/dad1ea95f27a724574772bb2882a34576d7282bb),
preserving all newer runtime work. Tracked compiler modules, build files,
package configuration and tracked benchmark definitions were identical between these
commits: tree-record SHA-256
`81474f5289781cec4d2514e3070d8816040d591d37d7359ad92ef2aeb31c9813`.
Fresh clean-parent and reapplied-candidate builds then matched the originally
qualified native images **byte-for-byte**. The original gates are attributed
to their actual source, not relabeled as runs on another commit.

- Parent/restored native SHA-256: `68c6ed517f9125ae1b570ff2e585c5b368745389af828258f6621fe5e6e0311c`.
- Rejected candidate native: `cf83d04c72ebed61e39be784bfb431e5012c0d691027509bb996a6d643e768dd`.
- Exact source/test patch: `25a2a5a7c760bff71ffd3d5d48acaef5572cff7d663c92bce326bf96bc9efd7c`.
- Original protocol: `f1479a40089e390d41a7a9fbf204ea4eb482e648282cc2ea43e574bf424c7ff2`.
- Current-parent protocol: `58c6eeb955f7af2110f9fd143048aabb3429401d09eb74fb6216517721c0be3b`.

An assertion verifies that only the protocol's parent source changed during
reconciliation; every timing, admission, retention and acceptance rule stayed
identical before any measurement. The
[exact-native profile](#exact-native-profile-and-byte-scope-audit-2026-10-09-utc)
maps explicitly displayed collection offsets 36/56 early and 36/96 middle to
the original scan. These offsets identify work, not per-function CPU shares
or a speed estimate.

### Archived implementation and correctness controls

The rejected design completed the existing forward-overload table into
immutable function-statement groups by physical container and interned name.
It retained every eligible declaration in original order, including ordinary
functions, and shared reference-counted snapshots between forward checking
and signature collection. Consumers read current TypeIds and signature flags;
the table stored no mutable types. Both consumers unwrap exactly **one**
export layer. Namespace collection still stops immediately; a block walk
stops only when output is nonempty. Forward checking remains lazy and requires
at least two declarations and a bodyless declaration.

Source reset releases table ownership. HIR growth replaces stale snapshots
without freeing active borrowers. Partial construction frees its own
allocations without publishing an incomplete table or removing the old one.
Collection uses the complete original scalar path on metadata allocation
failure; append failures remain errors. There are no new section, visibility,
prior-position, library, filename or benchmark filters, semantic caps, body
omissions, separate general-value indexes or cached signatures.

Binder declaration lists were not reused: four characterization controls
demonstrate stale HIR growth, foreign equal NodeIds and shared augmentation
mutation even with the original HIR unchanged. First-declaration indexes also
cannot represent complete ordered overload groups. These findings motivated
the shared owned-syntax design; they do not prove the performance cause of
its later predicate regression.

Nine candidate controls cover complete signatures in all physical containers;
live TypeId changes; actual HIR growth and retained snapshots across reset;
original lazy overload qualification; every forced-growth construction
allocation failure, cleanup and retry; full scalar metadata-OOM fallback and
append errors; direct/nested/empty exports, malformed names, duplicates and
unsorted recovery spans; namespace stopping and empty-block ascent; and failed
stale replacement with old ownership retained across multiple roots.
Full suites passed: **checker 4,562 / binder 21 / Program 251 / driver 200 /
CLI 76 / entrypoint 38**, plus the native build and **136** harness tests.
Four untimed full-process overload/scope/export/checked-JS controls match
complete stdout, stderr and exit status, not just error counts.

Pinned Zod 4.5.2 retains all **195 TS + 3 HM9002** primary diagnostics, including
positions, messages and multiplicity, with no additions or removals.
Normalized diagnostic SHA-256:
`6bf2feb527d91c651631642e523da6d28cd2b0c7ae4898cac0888aa7b420874f`.
Zod remains **unadmitted**; unchanged failures are not compatibility success.
The initial test-only nonexistent `Primitive.number` compilation error,
its corrected `number_t` draft, all four/six/nine-control drafts and complete
logs remain. A mechanical reverse-patch conversion first failed atomically on
repeated function headers; the unchanged patch hash was reverified before
ordinary context hunks applied successfully. No compiler or timing result was
taken from that failed conversion.

### Complete benchmark results

Each of ten phases passed all **66** original positive/negative admissions
on both native images, including every checked-JS first/middle/last error.
The protocol retains the 32-pair scale screen, 60-pair official/512 confirmation,
all 20 families at ten pairs each, five six-pair large batches, eight independent
30-pair risk rechecks and separate 30-pair class/interface checks. CommonJS
joined the carried risks under the predeclared >3% adverse-median rule;
destructuring was already carried regardless of screen results.
Pairs use fresh native processes in alternating order, with three warmups per
binary per phase. Positive mean-saving intervals favor the candidate.

| Measurement | Parent median | Candidate median | Candidate faster | Paired mean-saving 95% interval |
|---|---:|---:|---:|---:|
| Official checked JS, 20-pair screen | 26.470 ms | 26.382 ms | 14/20 | +0.015 to +0.449 ms |
| 512 families, six-pair screen | 111.885 ms | 108.934 ms | 5/6 | +0.179 to +5.654 ms |
| 8,192 families, six-pair screen | 7,021.969 ms | 6,396.838 ms | 6/6 | +334.680 to +1,034.497 ms |
| Official checked JS, 30-pair confirmation | 26.544 ms | 26.679 ms | 13/30 | -0.255 to +0.156 ms |
| 512 families, 30-pair confirmation | 112.479 ms | 110.040 ms | 27/30 | +0.364 to +3.614 ms |
| 8,192 families, confirmation batch 1 (six pairs) | 7,115.587 ms | 6,492.837 ms | 6/6 | +263.794 to +1,344.126 ms |
| 8,192 families, confirmation batch 2 (six pairs) | 8,048.152 ms | 7,260.371 ms | 6/6 | +58.477 to +1,579.863 ms |
| 8,192 families, confirmation batch 3 (six pairs) | 7,874.791 ms | 6,610.658 ms | 6/6 | +286.623 to +2,093.830 ms |
| 8,192 families, confirmation batch 4 (six pairs) | 7,421.304 ms | 6,618.029 ms | 6/6 | +459.597 to +1,255.543 ms |
| 8,192 families, confirmation batch 5 (six pairs) | 6,962.085 ms | 6,494.331 ms | 6/6 | +379.542 to +621.780 ms |
| 8,192 families, all five batches (30 pairs total) | 7,295.837 ms | 6,566.492 ms | 30/30 | +616.393 to +1,052.243 ms |

| Family screen (10 pairs each) | Parent median | Candidate median | Candidate faster | Paired mean-saving 95% interval |
|---|---:|---:|---:|---:|
| `checkjs_jsdoc` | 26.375 ms | 26.232 ms | 6/10 | -0.145 to +0.301 ms |
| `class_hierarchy` | 22.691 ms | 22.620 ms | 5/10 | -0.482 to +0.414 ms |
| `commonjs_graph` | 17.645 ms | 18.246 ms | 4/10 | -0.648 to +0.295 ms |
| `control_flow` | 25.641 ms | 25.430 ms | 6/10 | -0.349 to +0.383 ms |
| `deep_types` | 20.675 ms | 20.738 ms | 2/10 | -0.686 to +0.105 ms |
| `destructuring` | 14.291 ms | 14.752 ms | 3/10 | -0.332 to +0.049 ms |
| `generic_calls` | 22.330 ms | 22.011 ms | 9/10 | +0.109 to +1.055 ms |
| `import_graph` | 16.349 ms | 16.442 ms | 5/10 | -0.439 to +0.199 ms |
| `interface_composition` | 33.765 ms | 33.642 ms | 7/10 | -0.135 to +0.343 ms |
| `many_files` | 20.849 ms | 21.347 ms | 4/10 | -1.080 to +0.386 ms |
| `null_safe_access` | 32.184 ms | 32.271 ms | 5/10 | -0.480 to +0.262 ms |
| `overload_resolution` | 23.357 ms | 23.323 ms | 6/10 | -0.172 to +0.881 ms |
| `recursive_generics` | 14.114 ms | 14.206 ms | 3/10 | -0.392 to +0.048 ms |
| `reexport_graph` | 11.151 ms | 10.999 ms | 5/10 | -1.321 to +0.434 ms |
| `startup` | 2.673 ms | 2.654 ms | 5/10 | -0.206 to +0.180 ms |
| `structural_objects` | 22.241 ms | 21.930 ms | 9/10 | +0.187 to +0.712 ms |
| `tsx_components` | 18.516 ms | 18.470 ms | 5/10 | -0.265 to +0.339 ms |
| `type_predicates` | 32.407 ms | 32.455 ms | 5/10 | -0.406 to +0.435 ms |
| `type_predicates_large` | 242.022 ms | 245.449 ms | 4/10 | -8.303 to +0.986 ms |
| `variadic_tuples` | 30.852 ms | 31.105 ms | 3/10 | -0.884 to +0.132 ms |

| Independent carried-risk recheck (30 pairs each) | Parent median | Candidate median | Candidate faster | Paired mean-saving 95% interval |
|---|---:|---:|---:|---:|
| `checkjs_jsdoc` | 25.785 ms | 25.596 ms | 19/30 | +0.050 to +0.271 ms |
| `commonjs_graph` | 17.377 ms | 17.318 ms | 14/30 | -0.524 to +0.166 ms |
| `control_flow` | 24.637 ms | 24.659 ms | 15/30 | -0.391 to +0.154 ms |
| `deep_types` | 20.646 ms | 20.609 ms | 15/30 | -0.153 to +0.121 ms |
| `destructuring` | 14.842 ms | 14.839 ms | 14/30 | -0.261 to +0.214 ms |
| `recursive_generics` | 14.081 ms | 14.105 ms | 17/30 | -0.055 to +0.130 ms |
| `reexport_graph` | 11.515 ms | 11.513 ms | 15/30 | -1.271 to +1.575 ms |
| `type_predicates_large` | 242.178 ms | 243.708 ms | 12/30 | -7.550 to -0.122 ms |

| Independent declaration-risk check (30 pairs each) | Parent median | Candidate median | Candidate faster | Paired mean-saving 95% interval |
|---|---:|---:|---:|---:|
| `class_hierarchy` | 23.109 ms | 22.770 ms | 18/30 | -0.029 to +0.331 ms |
| `interface_composition` | 33.648 ms | 33.655 ms | 17/30 | -0.131 to +0.317 ms |

The original official confirmation is slower at its median and inconclusive;
the later predeclared carried check does not erase that observation. CommonJS,
destructuring, control flow, deep types, recursive generics, reexports and both
declaration checks retain their zero-spanning intervals and adverse points
where present. Inconclusive is not equivalence. Only the independent large
predicate interval is wholly negative, and it is sufficient to reject.
The separate five-compiler ranking remains **Home 1/20 leads and 12/20 versus
native TS7**; these Home-only results do not update competitor or platform
rankings. Canonical C++ coverage and Linux/Windows runs remain unresolved.

### Evidence and restoration

The [complete raw archive](https://github.com/home-lang/home/raw/main/bench/vs_tsgo/evidence/20261010-shared-function-statement-groups-rejected-859.tar.gz)
has **1,892** verified payload checksums. SHA-256:
`a464393450de380317dc7f424ee3855311c73b8f731f9492b805945db28e7b1f`.
It includes every raw pair and admission, exact positive/scaled-negative inputs,
nine explicitly labeled untimed generator replays of deleted temporary
negative projects, diagnostic fixtures, development failures, original
experiment and native/input reconciliation, protocol/runners, complete gates
and final terminal-job lifecycle. Generator replays execute no compiler and
are not original admission or timing observations.

All heavy jobs use the unchanged 600-second / 3,840-MB tree-footprint guard,
shared machine lock and 1,024/512-MB disk admission/continuation floors.
Original/current candidate builds peak at 3,066/3,132 MB, the final checker at
3,454 MB, clean-current-parent at 2,977 MB and restoration at 2,958 MB.
Shared-lock waits and host low-water observations remain in the logs.
Clean source and restored native match the measured parent; no rejected code
is in production. Future work under [#859](https://github.com/home-lang/home/issues/859)
requires a materially different design, not revival of this binary or
repeat-to-pass. The broader [#416](https://github.com/home-lang/home/issues/416)
performance and complete-feature goal remains incomplete.

The [publication context archive](https://github.com/home-lang/home/raw/main/bench/vs_tsgo/evidence/20261010-function-group-rejection-publication-context-859.tar.gz)
retains the lint commands/logs, documentation verifier, restoration and final
job lifecycle, with **11** verified payload checksums. SHA-256:
`c66d7ee7f289f1185378c99963b5f172a73617d6883d62dc03e9e0be0a5dd23b`.
Repository-wide `bunx --bun pickier .` exits one with **11,460 errors and
10,613 warnings** outside the changed Markdown files; no broad auto-fix is
applied. Focused Pickier on both changed files exits zero. All tables and
selected README rows, links, native identity and raw checksums verify.

## Ordered namespace-import candidates (2026-10-09 UTC)

The candidate under [#857](https://github.com/home-lang/home/issues/857) is
**rejected and never pushed**. Independent destructuring confirmation rises
from 13.908 to 14.030 ms, only 9/30 pairs faster, with paired mean-saving
95% interval **[-0.237, -0.029] ms**. Positive checked-JS scaling results do
not override a confirmed independent regression. The candidate and all eight
index-specific controls are removed, native restored byte-for-byte, and newer
runtime work preserved. No retest-to-pass, layout/alignment tuning, semantic
cap, source-name shortcut, omitted checking or sample exclusion is used.

Exact tested parent:
[`88a8c2d39c5608be367e75f8379d572b4f571c29`](https://github.com/home-lang/home/commit/88a8c2d39c5608be367e75f8379d572b4f571c29).
Parent/restored native SHA-256:
`68c6ed517f9125ae1b570ff2e585c5b368745389af828258f6621fe5e6e0311c`.
Rejected candidate native:
`1b3330a32a5ebcec0cc7783a2d086531a28e5675ff2298b0e95cc636527cd612`.
Final source/test patch:
`e3234d7b55a978c565876fd382220f26850e4b6688dfff553281637d9e122fc6`.
Frozen protocol:
`a64c278e7e156d223bd628c1cb2bef3c50fcba9d5d0926abdddd5ba8e0567809`.
The [exact-native profile](#exact-native-profile-and-byte-scope-audit-2026-10-09-utc)
maps displayed offsets 188/200 to this helper's root-statement scan; no
invented per-function CPU counts are used to choose it.

This separate design grouped complete direct-import syntax candidates by
physical HIR root and interned local name, preserving original statement
order and namespace-binding precedence. Default-binding require eligibility
remained live against current source, as did every original CommonJS,
interoperability, Program and namespace-type lowering branch. It cached no
mutable type or require predicate, added no section/visibility/prior-position
filter, and did not couple general local-declaration indexes. Source replacement
released facts; actual HIR growth invalidated them. Every construction failure
freed partial ownership and used the complete scalar statements; already
complete roots remained usable while failed uncached roots did not rebuild.
These facts describe the archived rejected implementation, not current runtime.

Eight controls cover full root/name scalar selection parity and natural
absence; live source require eligibility/reset; namespace precedence and real
HIR growth; every forced-growth allocation failure/cleanup; completed-root
retention and growth retry after failure; first missing-module null rather
than later-import substitution and recovery/use-before-import positions;
malformed non-identifier namespace precedence, missing source and invalid
spans; and complete typed/checked-JS diagnostic parity against scalar fallback.
Initial five-control **4,558** and seven-control **4,560** full checker passes
remain. Final eight-control checker passes **4,561** tests, with cached
confirmation; Program **251**, driver **200**, CLI **76**, entrypoint **38**,
native build and **136** harness tests pass unfiltered before timing.

Unmodified pinned Zod 4.5.2 (106 production files) retains identical complete
**198** primary-message/position/code diagnostics: 195 TS plus 3 HM9002,
normalized SHA-256
`6bf2feb527d91c651631642e523da6d28cd2b0c7ae4898cac0888aa7b420874f`.
This is **not production admission**. The entry point requires complete
module/build/Zod/harness gates before creating any timing sample.

All **592** original fresh-process alternating-pair rounds and **660**
admissions verify, with stable native/input/harness/runner fingerprints.
Three warmups per binary precede every phase/batch. All complete positive and
negative controls repeat before each phase; official/512/8192 checked-JS
negatives require all TS2322×9, TS2339×3 and TS2345×3 errors at first/middle/last
families. The full 20-family screen, all five six-pair large batches, seven
independent 30-pair carried/adverse rechecks and independent 30-pair class/interface
checks remain. Recheck selection is the frozen >3%-slower median or wholly
negative screen interval plus checkjs/deep/recursive/predicate/reexport carries.

| Measurement | Parent median | Candidate median | Candidate faster | Paired mean-saving 95% interval |
|---|---:|---:|---:|---:|
| Official checked JS, 20-pair screen | 25.660 ms | 25.650 ms | 9/20 | -0.201 to +0.229 ms |
| 512 families, six-pair screen | 110.263 ms | 111.034 ms | 4/6 | -2.168 to +2.326 ms |
| 8,192 families, six-pair screen | 6,894.239 ms | 6,401.857 ms | 6/6 | +439.000 to +637.418 ms |
| Official checked JS, 30-pair confirmation | 26.820 ms | 26.733 ms | 18/30 | -0.117 to +0.761 ms |
| 512 families, 30-pair confirmation | 113.317 ms | 110.763 ms | 28/30 | +1.166 to +3.012 ms |
| 8,192 families, confirmation batch 1 (six pairs) | 6,830.906 ms | 6,238.544 ms | 6/6 | +506.875 to +663.471 ms |
| 8,192 families, confirmation batch 2 (six pairs) | 6,801.149 ms | 6,262.904 ms | 6/6 | +474.145 to +656.200 ms |
| 8,192 families, confirmation batch 3 (six pairs) | 6,980.379 ms | 6,357.736 ms | 6/6 | +418.310 to +939.443 ms |
| 8,192 families, confirmation batch 4 (six pairs) | 6,841.696 ms | 6,270.456 ms | 6/6 | +472.241 to +675.177 ms |
| 8,192 families, confirmation batch 5 (six pairs) | 6,820.405 ms | 6,306.709 ms | 6/6 | +224.310 to +652.261 ms |
| 8,192 families, all five batches (30 pairs total) | 6,823.087 ms | 6,281.212 ms | 30/30 | +506.044 to +630.443 ms |

| Family screen (10 pairs each) | Parent median | Candidate median | Candidate faster | Paired mean-saving 95% interval |
|---|---:|---:|---:|---:|
| `checkjs_jsdoc` | 27.194 ms | 27.227 ms | 6/10 | -0.646 to +0.602 ms |
| `class_hierarchy` | 23.697 ms | 23.323 ms | 7/10 | -3.590 to +11.315 ms |
| `commonjs_graph` | 18.482 ms | 18.610 ms | 4/10 | -0.332 to +0.257 ms |
| `control_flow` | 25.672 ms | 26.019 ms | 4/10 | -0.893 to -0.038 ms |
| `deep_types` | 21.531 ms | 21.190 ms | 5/10 | -0.327 to +0.433 ms |
| `destructuring` | 14.651 ms | 15.151 ms | 2/10 | -0.593 to -0.068 ms |
| `generic_calls` | 22.953 ms | 22.597 ms | 6/10 | -0.098 to +0.795 ms |
| `import_graph` | 17.125 ms | 17.314 ms | 4/10 | -0.333 to +0.093 ms |
| `interface_composition` | 35.292 ms | 34.478 ms | 9/10 | +0.071 to +1.583 ms |
| `many_files` | 21.768 ms | 21.745 ms | 6/10 | -0.341 to +0.599 ms |
| `null_safe_access` | 32.221 ms | 32.311 ms | 5/10 | -0.407 to +0.200 ms |
| `overload_resolution` | 24.726 ms | 24.339 ms | 5/10 | -0.990 to +1.237 ms |
| `recursive_generics` | 15.078 ms | 15.032 ms | 5/10 | -1.053 to +0.450 ms |
| `reexport_graph` | 11.863 ms | 11.743 ms | 6/10 | -0.270 to +0.322 ms |
| `startup` | 2.846 ms | 2.853 ms | 4/10 | -0.052 to +0.052 ms |
| `structural_objects` | 23.140 ms | 23.076 ms | 6/10 | -0.513 to +1.130 ms |
| `tsx_components` | 19.098 ms | 18.926 ms | 6/10 | -0.133 to +0.388 ms |
| `type_predicates` | 32.556 ms | 32.685 ms | 5/10 | -0.653 to +0.405 ms |
| `type_predicates_large` | 251.777 ms | 253.140 ms | 4/10 | -106.523 to +231.885 ms |
| `variadic_tuples` | 31.956 ms | 31.576 ms | 4/10 | -0.776 to +0.955 ms |

| Independent carried-risk recheck (30 pairs each) | Parent median | Candidate median | Candidate faster | Paired mean-saving 95% interval |
|---|---:|---:|---:|---:|
| `checkjs_jsdoc` | 25.701 ms | 25.714 ms | 16/30 | -0.159 to +0.157 ms |
| `control_flow` | 24.738 ms | 24.857 ms | 13/30 | -0.242 to +0.066 ms |
| `deep_types` | 20.209 ms | 20.248 ms | 11/30 | -0.199 to +0.083 ms |
| `destructuring` | 13.908 ms | 14.030 ms | 9/30 | -0.237 to -0.029 ms |
| `recursive_generics` | 13.853 ms | 13.952 ms | 16/30 | -0.130 to +0.173 ms |
| `reexport_graph` | 10.833 ms | 10.790 ms | 18/30 | -0.057 to +0.201 ms |
| `type_predicates_large` | 235.674 ms | 237.005 ms | 11/30 | -3.191 to +0.182 ms |

| Independent declaration-risk check (30 pairs each) | Parent median | Candidate median | Candidate faster | Paired mean-saving 95% interval |
|---|---:|---:|---:|---:|
| `class_hierarchy` | 21.975 ms | 22.001 ms | 16/30 | -0.140 to +0.214 ms |
| `interface_composition` | 32.604 ms | 32.529 ms | 16/30 | +0.002 to +0.373 ms |

Independent 512-family median is 2.3% lower; pooled 8,192-family median is
7.9% lower with 30/30 pairs faster. Large paired mean saving is 0.568243 seconds,
interval [0.506044, 0.630443] seconds; supplemental five-batch t interval
(df 4) is [0.461711, 0.674775] seconds. All batch intervals are positive, but
the variable fifth batch retains its 6.857-second candidate observation.
The initial 512-family screen is slower and inconclusive, not replaced by
confirmation. Official confirmation and its carried recheck remain inconclusive.

Both control-flow and destructuring screen intervals are negative and both
receive independent confirmation. Control flow retains a slower independent
median with interval spanning zero. Destructuring's independent interval is
wholly negative and determines rejection. Deep types, recursive generics and
large predicates retain slower independent medians with zero-spanning intervals;
the predicate interval is nearly negative. None is equivalence or proof of
no regression. Class confirmation is inconclusive; interface confirmation is
positive but does not erase the destructuring loss. Variable class/predicate
screen observations remain without outlier removal.

The exact owned patch was reversed with `apply_patch`, restoring source to
the tested parent and removing all eight index-specific controls. Original
native was restored before clean fast-forward to
[`1d50e79971dfd0beb244502505f3497f20b08b07`](https://github.com/home-lang/home/commit/1d50e79971dfd0beb244502505f3497f20b08b07),
preserving newer Worker/WebSocket/runtime work. A clean matching standalone
build passes with the same `68c6ed51` native SHA-256. Subsequent core-stream
runtime commits were also preserved by fast-forward to `f1e2d94c9`; its clean
matching standalone build reproduces the same native (cached 55 ms).
This is restoration/provenance evidence, not a new A/B or competitor ranking.

All jobs are terminal with recorded exits. Guards remain **600** seconds /
3,840 MB, shared machine lock and 1,024/512 MB disk floors. Final checker peak
3,448 MB (earlier 3,405/3,407), Program 3,242, driver 2,911, CLI 2,678,
entrypoint 3,134, candidate build 3,080, restoration 3,101 and timing 282 MB.
Shared-lock waits behind unrelated runtime tasks are preserved; no unrelated
process was stopped, guard raised or completed measurement restarted.

The [complete rejection archive](../../bench/vs_tsgo/evidence/20261009-namespace-import-candidates-rejected-857.tar.gz)
has **1,725** verified payload checksums, including all raw arrays/admissions,
initial/final source/test patches, full test/build/Zod/guard evidence,
decision/lifecycle/restoration, exact scale inputs, harness and strict verifiers.
SHA-256:
`76786c37f15e3f68a9f950a8e2853a1d78004a1739ccf724005425d7494ed3ae`.
Original negative temporary directories were deleted by the original harness;
actual process records remain. Nine labeled untimed generator replays preserve
fixtures, not original directories or additional admissions/timings.
No universal performance, current-source ranking, Zod, canonical C++ or
other-platform completion is inferred. The broader #416 goal remains open.

## Exact-native profile and byte-scope audit (2026-10-09 UTC)

Direct sampling of the **unchanged native executable** at source
[`b6608b14c631db91be6099e78c957ab67a3b5266`](https://github.com/home-lang/home/commit/b6608b14c631db91be6099e78c957ab67a3b5266)
replaces reliance on relinked diagnostic images for choosing the next scan.
Native SHA-256:
`68c6ed517f9125ae1b570ff2e585c5b368745389af828258f6621fe5e6e0311c`.
All **31** complete native admissions pass: all 20 official positives/nine
negatives plus the 8,192-family positive and full 15-error negative. The
sampled process exits zero silently. Binary/source/input fingerprints remain
unchanged, with positive inventory
`bfb2fb1bef4dcb4ad7df9bffa647b5d44bd35c6895b32772fb4044ce0ced829e`
and negative inventory
`439cf46bb43c4386f85b07af49583ff7ae3ad1ba6b7e73989fa776dce372b467`.
There are **zero diagnostic images sampled or timed** in this new method.

The stronger audit first found that renaming local symbols preserves object
instruction bytes, but relinking through clang does **not** preserve final
native executable text. Native text has 9,675,688 bytes, SHA-256
`77288d82ae38d7d741276d9f2734dce2f2d6916af69a11d4c14ed953e0f25e5c`;
the rejected relinked image has 9,674,440 bytes, SHA-256
`732298add1119f7332c21be55ad844656cdef69524cba540045f743b9063473c`.
That attempt stopped before admission or sampling. The canonical unstripped
ReleaseFast build then reached 3,885 MB and was stopped by the unchanged
3,840 MB guard, exit **125**. The native binary was restored byte-for-byte.
An LLVM metadata-only symbol-addition capability probe also returned unsupported
for Mach-O; no generated probe image was admitted, sampled or timed.
All attempts remain; no guard increase, source/optimizer/alignment adjustment,
repeat-to-pass or weakened byte-equality assertion was used.

The successful method uses the retained exact cached native link image and
object `.zig-cache/o/11a829d35bce9e9be525665ca4e81af0/home-tsc_zcu.o`,
object SHA-256
`36aba5ab5e5bf1c982bac3265552fa50c992938ec7cf67bf6b2e46f685a00f92`.
Its complete 9,674,440-byte text layout matches the native prefix outside
**159,369 explicitly declared linker relocations** covering 633,752 bytes at
relocation sites: **zero undeclared changed bytes**. The comparison excludes
whole relocation-sized words, not only immediate operand bits; it does not
prove opcode identity at those sites. The native has an additional
1,248-byte thunk tail, outside this object's mapping. This is a precise
link-layout/address proof, **not** a claim of native/diagnostic byte equality.
The retained `_main` anchor and native section layout give link delta
`0x100001768` and **5,889** text-symbol ranges. Symbol aliases and locations
outside the mapped object are retained without invented names. No executable
is rebuilt, relinked or modified for the successful sampling step.

Two one-second windows start at 0.1 and 3.0 seconds, with **826 / 823** main
thread observations. The raw stripped-native report collapses local symbols
under global `main`; therefore its group counts cannot establish per-function
leaf counts. The offline resolver adjusts explicit PCs for the actual ASLR
load address and maps them to verified source/object ranges. **Ellipses,
unmapped PCs, aliases and collapsed group counts remain undistributed**.
Displayed frame locations can include callers, not just active leaves.
Neither these locations nor the group counts are whole-run CPU percentages,
causal speed evidence or a new benchmark ranking.

| Native function | Preferred start | Early explicitly displayed offsets | Middle explicitly displayed offsets |
|---|---|---|---|
| `memberAccessReceiverIsRequireAssignmentBinding` | `0x100688e68` | 244, 476 | 416, 476 |
| `moduleNamespaceTypeForLocalImport` | `0x1002ed7bc` | 188, 200 | 188, 200 |
| `collectFunctionSignaturesFromStatements` | `0x1003ae10c` | 36, 56 | 36, 96 |
| `resolveValueDeclInStmt` | `0x10061f5e4` | 24, 120, 168, 636 | 24, 212 |
| `jsDocTypeForPreviousIdentifierDecl` | `0x10030e3fc` | 640, 712, 1588, 4996, 5480 | none explicitly displayed |
| `virtualSectionStartForNode` | `0x1000f2cc0` | 0 | 0, 188 |

Native disassembly maps namespace-import offsets 188/200 to root-statement
loop decrement/import-kind testing; signature offsets 36/56/96 are also scan
instructions. The next candidate is
[#857](https://github.com/home-lang/home/issues/857): complete ordered syntax
candidates by physical root/local name, live require eligibility and type
lowering, source/HIR invalidation and complete scalar OOM fallback. No new
section/visibility/prior-position filter, mutable type cache, general local-index
coupling or source-name shortcut is permitted. Full semantic gates and frozen
exact-parent/full-family/independent adverse-risk A/B are required before a
candidate source push. This profile does not claim an optimization gain.

The [complete profile/audit archive](../../bench/vs_tsgo/evidence/20261009-exact-native-prefix-profile-854.tar.gz)
contains **73** verified payload checksums: raw native samples and resolved
call graphs, byte/relocation/layout/symbol evidence, exact source/native
disassembly, all admission records and scale inputs, runners/verifiers, both
failed approaches and unsupported capability probe. SHA-256:
`0f0fb7ebcbf75e736903fd8cc8952cae9414af218289fea157f4523cdd051d60`.
Native profiling peak is 299 MB; read-only map verification 143 MB and archive
133 MB. Guards remain 600 seconds / 3,840 MB with shared lock/disk floors.
The archive waited for an unrelated runtime build and completed after it ended;
no unrelated process was stopped. Subsequent runtime commits were preserved
by clean fast-forward to `a96bb9a40`, and the matching standalone rebuild
reproduced the same native SHA-256. The recorded sampled source remains `b6608b14c`.

Earlier diagnostic archives are preserved as separately versioned exploratory
samples of their relinked images. Their original/renamed **pre-link object**
checks do not prove final native executable instruction equality. Their leaf
counts must not be relabeled exact native counts. All accepted/rejected A/B
timings used native binaries, so this scope correction does not change those
raw measurements or establish a different ranking. The latest five-compiler
matrix still has Home **1/20** leads and **12/20** versus native TS7; Zod,
canonical C++ and other-platform admission remain incomplete.

## Restored current-main profile (2026-10-09 UTC)

Diagnostic-only sampling of source `624916ec4` / compiler inputs `37b5225c2`
passes all **62 admissions** on the native/diagnostic images, including full
8,192-family positive and TS2322×9/TS2339×3/TS2345×3 rejection controls.
Native SHA-256 is `34118002e25d69a8351a60ee493c504ca734b477ed31efc79fb03ee63a9ad331`.
The exact cached link object is
`.zig-cache/o/62b7b0fc002c63dfcd24caf77e590450/home-tsc_zcu.o`, SHA-256
`aa12e18240cc11c4e6188d65593754d2517087ec7e0f12929c78a6ff2d35e708`.
Renaming 20,341 local symbols and relinking for readable stacks preserves the
original/renamed object instruction sections byte-for-byte, SHA-256
`dbb0d14c4cf5512bca7641a2ee20b0decb8760405355d6f9c081392d07dfe2f2`.
Diagnostic image SHA-256 is
`c3cb630ce987507c73073183cb107086194a0e10df09b17e5b3f769df559e6cf`.
It supplies **zero timing samples**.

Two separate one-second exploratory samples start at 0.1 and 3.0 seconds.
These are not whole-run CPU percentages, causal speed proof or a new A/B.
The complete 8,192-family input inventory remains
`bfb2fb1bef4dcb4ad7df9bffa647b5d44bd35c6895b32772fb4044ce0ced829e`.
Compiler exit is 0 with empty output, both samples succeed, and source/native/
input provenance is unchanged. The same shared lock/time/memory/disk guard
applies; peak 250 MB, host low-water 40%. Matrix/profile handles are terminal.

| Exploratory leaf observations | Early | Later |
|---|---:|---:|
| Main-thread observations | 822 | 814 |
| `memberAccessReceiverIsRequireAssignmentBinding` | 148 | 120 |
| `resolveValueDeclInStmt` | 14 | 106 |
| `jsDocTypeForPreviousIdentifierDecl` | 11 | 66 |
| `moduleNamespaceTypeForLocalImport` | 53 | 65 |
| `collectFunctionSignaturesFromStatements` | 57 | 56 |
| `virtualSectionStartForNode` | 46 | 43 |
| `requireImportAssignmentMemberType` | 43 | 32 |

All other frames and counts remain in the raw samples. Bounds and displayed
offsets come from this image's own symbols and samples, not previous addresses:

| Source method | Unslid symbol start | Explicitly displayed offsets |
|---|---|---|
| `virtualSectionStartForNode` | `0x1000effac` | 0, 200 |
| `memberAccessReceiverIsRequireAssignmentBinding` | `0x10067aff8` | 244, 416, 476 |
| `jsDocTypeForPreviousIdentifierDecl` | `0x100304cf0` | 2156, 4344, 4356, 4432 |
| `resolveValueDeclInStmt` | `0x100611e38` | 0, 24, 28, 52, 120, 212, 2408, 2416 |

The previous-JSDoc source first queries the already indexed nearest-prior
declaration; if it has no leading JSDoc result, its ancestor fallback scans
container statements in original order, breaking at the first statement whose
start is not before the use, and returns the first matching simple var/let/const
declaration's live JSDoc lowering result. Assembly offsets 4344/4356/4432 map
to that prefix loop's span/kind/name loads; 2156 is in the indexed portion.
This fallback is distinct from the rejected require-presence work and is a
concrete next target for exact source-order candidate facts, not type-result
caching or a guessed filename/semantic cap. Current source has no fallback
virtual-section filter to invent. Any replacement must preserve all these rules,
including null results and recovery positions, with full scalar/OOM controls.

Value-declaration resolution has repeated calls plus visibility, mutable HIR
type reads/lowering and deprecation behavior. Displayed offsets include
prologue/epilogue loads, so they are not proof that a particular internal scan
consumes the whole leaf count. Full source/assembly is retained for further
mapping. No third require-cache retest or alignment workaround is introduced.
Collapsed samples can contain ellipses; displayed offsets are not an invented
complete execution set.

The [profile archive](../../bench/vs_tsgo/evidence/20261009-restored-current-jsdoc-profile-854.tar.gz)
retains all admissions, input/source/assembly mapping, two raw samples, both
instruction sections, symbols, runners/logs and verifiers with **33** verified
payload checksums. SHA-256:
`4e917dfa81fb99a50b33f2aabc1f570466fb3fb5f41fb968f17944ef850ec90a`.
The unchanged scale-negative fixture is retained in the immutable prior
presence-specific archive below. No diagnostic-image timing, new compatibility
claim or universal performance result is inferred from sampling.

## JSDoc ancestor-prefix facts (2026-10-09 UTC)

The distinct candidate under [#854](https://github.com/home-lang/home/issues/854)
is **accepted** in
[`11055ba4746b224735c8ec2cba2f5e449bfff980`](https://github.com/home-lang/home/commit/11055ba4746b224735c8ec2cba2f5e449bfff980).
The complete frozen protocol supports a 9.1%-lower 8,192-family median,
7.712274 → 7.007293 seconds, with all 30 pairs faster across all five
predeclared batches. No independent interval is wholly negative, but
inconclusive and adverse estimates remain unresolved, not equivalence.
This scoped Home-only A/B does not refresh the five-compiler matrix or prove
universal leadership. The rejected require-presence implementations remain absent.

Exact parent:
[`abe538a8638ed4542abfa7b256f3a2711a1f59c6`](https://github.com/home-lang/home/commit/abe538a8638ed4542abfa7b256f3a2711a1f59c6).
Clean parent native SHA-256:
`34118002e25d69a8351a60ee493c504ca734b477ed31efc79fb03ee63a9ad331`.
Candidate/landed native:
`68c6ed517f9125ae1b570ff2e585c5b368745389af828258f6621fe5e6e0311c`.
Frozen source/test patch:
`0719bd67d2b1310753cc8097b099ccef43b18bd326e07ebbff5122443c7cf951`.
Frozen protocol:
`d0cc1b2f8998136289cde70a86f979a37dfabe706ccb67eece5b4bc873bc6664`.
The committed patch matches the tested patch byte-for-byte; no layout tweak,
sample exclusion, repeat-until-pass, semantic cap or source-name shortcut is used.

The mapped previous-JSDoc ancestor fallback repeatedly walks block/namespace
statements. Its new immutable facts retain the first simple value binding by
name in original container order. Each candidate stores the maximum start
position through **every** preceding statement, including unrelated/recovery
nodes. Strictly exceeding that maximum preserves the original stop-at-first-span
rule even for out-of-order or equal positions; sorting declarations alone
would not. Direct export unwrapping and first-binding/null behavior are unchanged.
The nearest-prior lookup and live JSDoc lowering remain unchanged; there is
no mutable type cache, new virtual-section filter or general local-index coupling.
Source replacement releases ownership, HIR growth invalidates facts, and every
construction allocation failure frees partials and preserves full scalar lookup.

Six controls cover complete node/name scalar parity through nested scopes,
exports/patterns/sections; all 3,087 small position combinations and a maximum-u32
unrelated barrier; first binding/null/section/source replacement; actual HIR
root-order growth; every forced-growth allocation failure/cleanup; and full JS
diagnostic equality plus failure retry on revision change.
Both unfiltered checker runs pass **4,553** tests; Program **251**, driver
**200**, CLI **76**, entrypoint **38**, native build and **136** harness tests
pass. Timing requires all module/build/Zod/harness gates before its first sample.

Unmodified Zod 4.5.2 (106 production files) retains the identical complete
**198** primary-message/position/code multiset: 195 TS errors and 3 HM9002.
Normalized SHA-256:
`6bf2feb527d91c651631642e523da6d28cd2b0c7ae4898cac0888aa7b420874f`.
This is **not production admission**; package bytes and diagnostics are unchanged.

All **532** original alternating fresh-process rounds and **660** admissions
are verified with stable native/input/harness/runner fingerprints. Three
warmups per binary precede each phase/batch. Every phase repeats all complete
positive/negative admissions; official/512/8192 checked-JS negatives require
TS2322×9, TS2339×3 and TS2345×3 at first/middle/last families.
Official/scale screens, independent official/512 confirmations, all 20 family
screens, five six-pair large batches, five carried-risk rechecks and independent
30-pair class/interface controls are retained. Recheck selection is the frozen
>3%-slower median or wholly negative screen interval, plus all five carried
risks regardless of the new screen. No observations are removed.

| Measurement | Parent median | Candidate median | Candidate faster | Paired mean-saving 95% interval |
|---|---:|---:|---:|---:|
| Official checked JS, 20-pair screen | 25.946 ms | 25.880 ms | 14/20 | -0.042 to +0.257 ms |
| 512 families, six-pair screen | 113.007 ms | 112.363 ms | 5/6 | -0.055 to +2.795 ms |
| 8,192 families, six-pair screen | 7,758.223 ms | 7,024.731 ms | 6/6 | +598.092 to +750.393 ms |
| Official checked JS, 30-pair confirmation | 28.625 ms | 28.648 ms | 20/30 | -0.054 to +0.351 ms |
| 512 families, 30-pair confirmation | 114.294 ms | 111.934 ms | 23/30 | -1.461 to +2.965 ms |
| 8,192 families, confirmation batch 1 (six pairs) | 7,582.381 ms | 6,914.782 ms | 6/6 | +413.052 to +818.854 ms |
| 8,192 families, confirmation batch 2 (six pairs) | 7,909.772 ms | 7,303.897 ms | 6/6 | +417.626 to +826.192 ms |
| 8,192 families, confirmation batch 3 (six pairs) | 7,674.694 ms | 6,890.669 ms | 6/6 | +580.864 to +888.743 ms |
| 8,192 families, confirmation batch 4 (six pairs) | 7,788.488 ms | 7,041.545 ms | 6/6 | +647.991 to +808.036 ms |
| 8,192 families, confirmation batch 5 (six pairs) | 7,689.371 ms | 6,999.119 ms | 6/6 | +606.784 to +756.409 ms |
| 8,192 families, all five batches (30 pairs total) | 7,712.274 ms | 7,007.293 ms | 30/30 | +622.101 to +730.809 ms |

| Family screen (10 pairs each) | Parent median | Candidate median | Candidate faster | Paired mean-saving 95% interval |
|---|---:|---:|---:|---:|
| `checkjs_jsdoc` | 26.164 ms | 26.297 ms | 6/10 | -0.153 to +0.215 ms |
| `class_hierarchy` | 23.050 ms | 22.523 ms | 8/10 | -0.267 to +0.918 ms |
| `commonjs_graph` | 18.025 ms | 17.203 ms | 7/10 | -0.019 to +0.830 ms |
| `control_flow` | 26.090 ms | 25.708 ms | 8/10 | -0.403 to +1.786 ms |
| `deep_types` | 22.016 ms | 22.177 ms | 3/10 | -3.060 to +0.931 ms |
| `destructuring` | 14.338 ms | 14.281 ms | 8/10 | -0.023 to +0.145 ms |
| `generic_calls` | 23.519 ms | 23.231 ms | 7/10 | -0.046 to +1.075 ms |
| `import_graph` | 16.978 ms | 16.848 ms | 5/10 | -1.328 to +2.492 ms |
| `interface_composition` | 33.734 ms | 33.824 ms | 6/10 | -0.604 to +0.489 ms |
| `many_files` | 21.460 ms | 21.149 ms | 6/10 | -0.715 to +0.935 ms |
| `null_safe_access` | 33.786 ms | 33.905 ms | 5/10 | -0.232 to +0.699 ms |
| `overload_resolution` | 23.404 ms | 23.381 ms | 4/10 | -0.455 to +0.354 ms |
| `recursive_generics` | 14.127 ms | 14.050 ms | 5/10 | -0.132 to +0.173 ms |
| `reexport_graph` | 13.528 ms | 14.112 ms | 5/10 | -3.280 to +5.445 ms |
| `startup` | 2.782 ms | 2.759 ms | 5/10 | -0.044 to +0.074 ms |
| `structural_objects` | 22.514 ms | 22.386 ms | 5/10 | -1.115 to +0.441 ms |
| `tsx_components` | 19.112 ms | 19.370 ms | 3/10 | -0.268 to +0.059 ms |
| `type_predicates` | 32.873 ms | 32.679 ms | 8/10 | -0.365 to +0.804 ms |
| `type_predicates_large` | 285.977 ms | 283.387 ms | 5/10 | -45.459 to +19.010 ms |
| `variadic_tuples` | 30.492 ms | 30.522 ms | 5/10 | -0.300 to +0.485 ms |

| Independent carried-risk recheck (30 pairs each) | Parent median | Candidate median | Candidate faster | Paired mean-saving 95% interval |
|---|---:|---:|---:|---:|
| `checkjs_jsdoc` | 25.935 ms | 25.901 ms | 13/30 | -0.166 to +0.132 ms |
| `deep_types` | 20.232 ms | 20.173 ms | 15/30 | -0.425 to +1.059 ms |
| `recursive_generics` | 13.996 ms | 14.132 ms | 11/30 | -0.670 to +0.041 ms |
| `reexport_graph` | 10.794 ms | 10.738 ms | 18/30 | -0.805 to +0.520 ms |
| `type_predicates_large` | 238.079 ms | 237.896 ms | 14/30 | -3.285 to +1.067 ms |

| Independent declaration-risk check (30 pairs each) | Parent median | Candidate median | Candidate faster | Paired mean-saving 95% interval |
|---|---:|---:|---:|---:|
| `class_hierarchy` | 22.629 ms | 22.543 ms | 17/30 | -0.062 to +0.428 ms |
| `interface_composition` | 33.850 ms | 33.772 ms | 13/30 | -0.373 to +0.200 ms |

Pooled large paired mean saving is 0.676455 seconds, interval
[0.622101, 0.730809] seconds. The supplemental five-batch t interval (df 4)
is [0.606433, 0.746477] seconds, preserving batch variation, not treating
30 pairs as one warmup set. All five batch intervals are positive.
Official and 512-family confirmations span zero, despite a 2.1%-lower
512-family median. Re-export screening retains its 4.3%-slower median;
the independent recheck spans zero. Recursive generics retains a 1.0%-slower
independent median, only 11/30 pairs faster and nearly negative interval
[-0.670, +0.041] ms. These are unresolved warnings, not evidence of equivalence
or a regression-free result. Class/interface confirmations are inconclusive;
no prior require-cache regression is relabeled fixed by these different runs.

Host is Apple M3 Pro / Mac15,6, 11 logical cores, Darwin27 arm64,
Hyperfine 1.20.0 and Python 3.9.6. Both native binaries use pinned Zig2163,
stripped ReleaseFast, `-Denable_jsc=false`, emission disabled. Diagnostic
images are never timed. All jobs are terminal; guards remain **600** seconds /
3,840 MB with the shared machine lock and 1,024/512 MB disk floors.
Checker peak 3,282 MB (cached confirmation 21), Program 3,121, driver 2,781,
CLI 2,669, entrypoint 3,028, build 2,923 and timing peak 276 MB. Original
logs and variability remain; no guard refusal or failed timing attempt occurred.

The [complete accepted archive](../../bench/vs_tsgo/evidence/20261009-jsdoc-ancestor-prefix-accepted-854.tar.gz)
has **1,659** verified payload checksums, including every array/admission,
all patches, complete test/build/Zod/guard/lifecycle evidence, source/input
provenance, harness and independent verifiers. SHA-256:
`336e6b45731608f04309aa999b5ead588c847968709d7b7f81347bf7adca8ff4`.
Original negative temporary directories were removed by the original harness;
actual process records remain. Nine separately labeled untimed generator
replays preserve fixtures, not original directories or extra admissions.
Repository-wide read-only `bunx --bun pickier .` retains the existing
11,461 errors and 10,613 warnings; no auto-fix or fabricated lint pass.
The five-compiler ranking, C++/other-platform coverage, Zod admission and the
broader #416 goal remain incomplete; no new ranking is inferred from this A/B.

## Presence-specific require facts (rejected, 2026-10-09 UTC)

The independent presence-only candidate under [#854](https://github.com/home-lang/home/issues/854)
is **rejected and never pushed** to production. Its interface-composition
confirmation regresses: 44.753 → 45.817 ms, only 10/30 pairs faster, paired
mean-saving interval **[−6.423, −1.076] ms**. Positive target-scale gains do
not override a confirmed independent regression. All results below remain;
no retry-until-pass, alignment tweak, omitted work, semantic cap, source-name
shortcut, or sample exclusion is introduced.

Exact tested parent is
[`68ea38d7a4654b45e91e5386f3d9ca8e8562e5f8`](https://github.com/home-lang/home/commit/68ea38d7a4654b45e91e5386f3d9ca8e8562e5f8).
Clean parent native SHA-256:
`34118002e25d69a8351a60ee493c504ca734b477ed31efc79fb03ee63a9ad331`.
Candidate native:
`de7d12e8370340759031a22b35a68b4f294fe2dc308c2842dbc4a5dc2873219b`;
frozen production/test patch:
`23c7c20dd5f2b3a871240b32fb8018fed736150a45eac10516e41a1896aeacbd`.
This is a distinct design, not a retest of the rejected shared-cache binary.

The prior design altered general local declaration/ordinal index construction.
This candidate instead stores complete immutable membership by physical HIR
root, binding name and virtual-section start, using the original require
predicate. It owns no specifier strings or mutable types. Root syntax is
scanned completely on demand, including natural absence; there is no raw
source prefilter. Source replacement releases facts, HIR growth invalidates
them, and construction failures release partial ownership and keep complete
scalar queries. General local-value, specifier and ordinal indexes are unchanged.
Presence still includes later same-section bindings, with no earlier-position
or cross-section fallback rule. The archived source is not current runtime.

Both full checker runs pass **4,554** tests; Program **251**, driver **200**,
CLI **76**, entrypoint **38**, standalone native build and **136** harness
tests pass without filtering. Seven controls cover complete scalar/node
parity; root/section/ordering; absence/source replacement/null/detached nodes;
multiple HIR roots; actual root growth; every forced-growth construction
allocation failure/cleanup/retry; and full JS/typed diagnostic equality.
This semantic success is necessary but does not erase adverse performance.

Unmodified Zod 4.5.2 (106 production files, unchanged package SHA-512) retains
the identical complete **198** primary-message/position/code diagnostic
multiset: 195 TS errors plus 3 HM9002, normalized SHA-256
`6bf2feb527d91c651631642e523da6d28cd2b0c7ae4898cac0888aa7b420874f`.
This is **not production admission**. The measurement entry point explicitly
requires all module/build/Zod/harness gates before timing.

The complete predeclared protocol includes official/512/8192 screens,
independent official/512 confirmations, all 20 family screens, all five
six-pair large batches, independent warning selection (>3%-slower median or
negative interval), four carried adverse risks regardless of screen, and
class/interface confirmation. The family screen selected an additional
checked-JS recheck. Each phase passes all 66 positive/negative admissions
on both frozen native binaries. Checked-JS first/middle/last controls require
TS2322×9, TS2339×3 and TS2345×3, not erased or partial checking.
Three warmups precede alternating fresh processes. Before/after executable,
source-patch, input, harness and tool fingerprints match. All **532** paired
rounds (**1,064** raw times) and **660** successful complete admission records
verify; no observation is omitted and no diagnostic image supplies timing.

| Measurement | Parent median | Candidate median | Candidate faster | Paired mean-saving 95% interval |
|---|---:|---:|---:|---:|
| Official checked JS, 20-pair screen | 29.572 ms | 29.105 ms | 13/20 | -0.056 to +0.883 ms |
| 512 families, six-pair screen | 209.849 ms | 134.515 ms | 3/6 | -56.971 to +111.904 ms |
| 8,192 families, six-pair screen | 16,777.862 ms | 9,850.214 ms | 5/6 | -1,027.474 to +15,554.682 ms |
| Official checked JS, 30-pair confirmation | 29.938 ms | 29.991 ms | 18/30 | -4.646 to +2.181 ms |
| 512 families, 30-pair confirmation | 121.349 ms | 115.059 ms | 26/30 | +4.278 to +9.173 ms |
| 8,192 families, confirmation batch 1 (six pairs) | 8,342.326 ms | 6,978.889 ms | 6/6 | +313.382 to +3,425.266 ms |
| 8,192 families, confirmation batch 2 (six pairs) | 7,908.671 ms | 6,557.446 ms | 5/6 | -1,315.897 to +2,483.741 ms |
| 8,192 families, confirmation batch 3 (six pairs) | 8,125.610 ms | 6,760.708 ms | 5/6 | +304.048 to +1,953.589 ms |
| 8,192 families, confirmation batch 4 (six pairs) | 7,721.234 ms | 6,503.883 ms | 6/6 | +936.371 to +1,481.801 ms |
| 8,192 families, confirmation batch 5 (six pairs) | 8,606.116 ms | 6,543.746 ms | 6/6 | +1,234.003 to +2,889.555 ms |
| 8,192 families, all five batches (30 pairs total) | 8,050.697 ms | 6,637.805 ms | 28/30 | +918.689 to +1,822.483 ms |

| Family screen (10 pairs each) | Parent median | Candidate median | Candidate faster | Paired mean-saving 95% interval |
|---|---:|---:|---:|---:|
| `checkjs_jsdoc` | 42.722 ms | 54.406 ms | 3/10 | -44.012 to +7.983 ms |
| `class_hierarchy` | 25.017 ms | 25.637 ms | 5/10 | -1.266 to +1.106 ms |
| `commonjs_graph` | 40.951 ms | 38.095 ms | 5/10 | -9.475 to +6.547 ms |
| `control_flow` | 26.029 ms | 26.254 ms | 6/10 | -0.370 to +0.455 ms |
| `deep_types` | 20.792 ms | 20.859 ms | 3/10 | -0.231 to +0.131 ms |
| `destructuring` | 14.698 ms | 14.919 ms | 2/10 | -0.404 to +0.052 ms |
| `generic_calls` | 23.137 ms | 23.216 ms | 5/10 | -0.567 to +0.488 ms |
| `import_graph` | 17.030 ms | 17.196 ms | 4/10 | -0.577 to +0.363 ms |
| `interface_composition` | 48.592 ms | 47.519 ms | 6/10 | -15.917 to +9.039 ms |
| `many_files` | 21.560 ms | 21.811 ms | 2/10 | -3.133 to +0.634 ms |
| `null_safe_access` | 32.286 ms | 32.006 ms | 6/10 | -0.112 to +0.800 ms |
| `overload_resolution` | 26.453 ms | 26.085 ms | 4/10 | -1.415 to +0.924 ms |
| `recursive_generics` | 20.595 ms | 22.578 ms | 2/10 | -4.301 to +1.444 ms |
| `reexport_graph` | 11.787 ms | 11.368 ms | 7/10 | -0.733 to +2.319 ms |
| `startup` | 2.692 ms | 2.661 ms | 7/10 | -0.006 to +0.110 ms |
| `structural_objects` | 24.793 ms | 25.266 ms | 4/10 | -0.853 to +0.051 ms |
| `tsx_components` | 18.639 ms | 18.672 ms | 5/10 | -0.240 to +0.147 ms |
| `type_predicates` | 32.522 ms | 32.432 ms | 3/10 | -0.301 to +0.261 ms |
| `type_predicates_large` | 250.320 ms | 249.204 ms | 6/10 | -13.491 to +7.829 ms |
| `variadic_tuples` | 51.406 ms | 46.106 ms | 6/10 | -11.672 to +19.772 ms |

| Independent carried-risk recheck (30 pairs each) | Parent median | Candidate median | Candidate faster | Paired mean-saving 95% interval |
|---|---:|---:|---:|---:|
| `checkjs_jsdoc` | 30.085 ms | 29.936 ms | 21/30 | -1.884 to +6.590 ms |
| `deep_types` | 32.345 ms | 29.983 ms | 15/30 | -3.989 to +21.779 ms |
| `recursive_generics` | 16.601 ms | 16.633 ms | 15/30 | -0.580 to +0.763 ms |
| `reexport_graph` | 19.999 ms | 26.242 ms | 11/30 | -18.704 to +0.769 ms |
| `type_predicates_large` | 308.094 ms | 292.604 ms | 17/30 | -21.880 to +41.461 ms |

| Independent declaration-risk check (30 pairs each) | Parent median | Candidate median | Candidate faster | Paired mean-saving 95% interval |
|---|---:|---:|---:|---:|
| `class_hierarchy` | 28.873 ms | 27.661 ms | 19/30 | -1.194 to +1.734 ms |
| `interface_composition` | 44.753 ms | 45.817 ms | 10/30 | -6.423 to -1.076 ms |

Independent 512-family median is 5.2% lower and pooled 8,192-family median is
17.5% lower. The large candidate is faster on 28/30 pairs; both adverse pairs
remain. Pooled mean saving is 1.370586 seconds, interval [0.918689, 1.822483]
seconds. The supplemental five-batch t interval (df 4) is [0.628334, 2.112838]
seconds, retaining batch variation, not 30 pairs after one warmup set.
Batch two's interval spans zero and its **12.371**-second candidate time
remains. The highly variable initial screen also remains, including parent
large times up to 27.301 seconds. No outlier filtering or selective batching.

The family checked-JS screen has a 27.3%-slower candidate median and recursive
generics 9.6% slower; both warnings are retained. Official confirmation and
all five selected rechecks span zero. Re-exports retains a 31.2%-slower
independent median and nearly negative interval; this is an unresolved warning,
not equivalence or proof of no regression. Class confirmation is inconclusive,
not a claim that the previous design's class regression is fixed. The negative
independent interface interval determines rejection.

The candidate and all new controls were removed with an exact source restore
to the tested parent, and installed native restored byte-for-byte. The clean
worktree then advanced to
[`37b5225c2cf795e16bf3d20a436a606c0ae594e9`](https://github.com/home-lang/home/commit/37b5225c2cf795e16bf3d20a436a606c0ae594e9),
preserving newer runtime work. A clean matching standalone build passes,
with the same native `34118002` SHA-256 above. This restoration is not a
new A/B or competitor rank. All jobs are terminal with exit records.
The unchanged guard is **600** seconds / 3,840 MB with the shared machine
lock and disk floors intact. First checker peak 3,408 MB (cached rerun 21 MB),
Program 3,122 MB, driver 2,848 MB, CLI 2,821 MB, entrypoint 3,159 MB,
candidate build 3,089 MB, restoration 3,001 MB and timing peak 283 MB.
Shared-lock waits, variability and original logs remain.

GitHub's initial issue helper returned HTTP 401. Plugin-management inspection
found the existing authenticated account and standard REST issue access
working; normal REST updates succeeded as `chrisbbreuer`. No credential,
permission or plugin connection was changed, and no failure is relabeled
success. This access check is not a benchmark-policy workaround.

The [complete rejection archive](../../bench/vs_tsgo/evidence/20261009-presence-specific-facts-rejected-854.tar.gz)
has **1,656** verified payload checksums, including all arrays/admissions,
source/test patches, test/build/Zod evidence, command/guard logs, restoration,
decision/lifecycle/access records, inputs, harness and independent verifiers.
Archive SHA-256:
`5dc948934a065562ddcf9c8528f418657e4f6f946e4127fee0ed63faf5b5da01`.
Original negative temporary directories were deleted by the original harness;
actual process records remain. Nine separately labeled generator replays
preserve fixtures, not original directories, additional admissions or timings.
No five-compiler ranking, C++ admission, other-platform result, Zod admission
or universal leadership is inferred. The broader goal remains open.

Repository-wide `bunx --bun pickier .` at restoration source `37b5225c2`
exits 1 with **11,461 existing errors and 10,613 warnings** in unchanged
code/fixtures. No auto-fixes were applied; new Markdown values/links and
`git diff --check` verify. The separate
[lint context](../../bench/vs_tsgo/evidence/20261009-presence-specific-facts-lint-context-854.tar.gz)
retains full command/log and terminal-state records with five verified payload
checksums, SHA-256
`db18b488a6e2f1111c9b50ba74c9fdcf6e17d4fdf31f6c25f39acf5a7d4b8627`.

## Shared require-binding presence (rejected, 2026-10-09 UTC)

The complete candidate under [#854](https://github.com/home-lang/home/issues/854)
is **rejected and never pushed** to production. Despite checked-JS scaling
gains, the independent class-hierarchy check confirms a slowdown: 22.280 →
22.405 ms, only 9/30 pairs faster, paired mean-saving interval
**[−0.429, −0.041] ms**. No repeat-until-pass, code-alignment tweak, source-name
shortcut, semantic cap, diagnostic omission or sample exclusion is used.
The positive class screen is retained too; it does not override independent
adverse confirmation. This experiment does not establish a universal gain.

Exact tested parent is
[`f60a1fa637778db68b6f452d417314dddfe8e150`](https://github.com/home-lang/home/commit/f60a1fa637778db68b6f452d417314dddfe8e150),
including the first three #846 correctness commits. It was built cleanly,
native SHA-256
`0963397d935ae4ae70f9262c2e59c671a3e812c6374e25816a12846a753f997d`.
Candidate native:
`258e2d79a04ed0779be91552ddb7b7745cc6e73d3237f13a3e9a4e0ec770061f`;
frozen production/test patch:
`f30ea0345f78ee928018543e3ee73fd7435473c0cdaabd7e010b65e208b03c39`.
These exact artifacts, not the older blocked-parent build, supply the A/B.

The target is the repeated root-statement loop in
`memberAccessReceiverIsRequireAssignmentBinding`. Its source method is
byte-identical between the preceding mapped profile and refreshed parent,
SHA-256 `3c47f5a8b136f854448dc367766fe2b250e23f5142b6771c9b6c250bc55eb919`.
This proves source-level continuity, not machine-address/CPU-percentage
equivalence with the old image. The candidate reuses existing local-value
root groups, makes their require syntax complete without a raw-source
prefilter, tracks HIR growth, and caches construction failure for a revision
with full scalar fallback. Presence keeps same-section eligibility but no
earlier-position or cross-section fallback filter; separate specifier/local
value queries keep their original gates/order. All partial allocations are
released, source replacement resets ownership, and no mutable types are cached.
The entire candidate, including its controls, is retained in evidence only.

The original candidate was preserved when disk admission refused execution
at 702 MB versus the unchanged 1,024 MB floor. A malformed initial field
placement was corrected before tests; both drafts and the formatter outcome
remain. Explicit inventory/hash/open-file checks permitted removal of 58
closed, rebuildable task-owned unit-cache files (763,584,512 bytes); source,
native/profile objects and evidence were preserved. That cleanup did not
relax a guard, and the later restored headroom allowed resumption.
The candidate was reconciled with the refreshed exact parent before testing.

Complete checker **4,553** (both first/cached runs), Program **250**, driver
**200**, CLI **74**, entrypoint **36**, standalone native build and **136**
harness tests pass. Six controls cover complete node/scalar parity, root/
section/ordering distinctions, source replacement/null, actual HIR-root growth,
every forced-growth allocation failure/cleanup/retry, and full JS/typed
diagnostic equality against scalar queries. Counts include upstream test
replacements/renames; none are filtered or disabled. The first Program run
timed out at the unchanged **600** seconds before results; the exact full
retry passed. Full timeout commands/logs and all shared-lock waits remain.

Unmodified pinned Zod 4.5.2 (106 production files, unchanged package SHA-512)
retains the identical complete 198 primary-message/position/code diagnostics:
195 TS errors plus 3 HM9002, normalized SHA-256
`6bf2feb527d91c651631642e523da6d28cd2b0c7ae4898cac0888aa7b420874f`.
This is **not production admission**, and no Zod runtime is timed.

The protocol was declared before timing: official/512/8192 screens,
independent official/512 confirmation, all 20 family screens, all five
six-pair large batches, independent carried deep-types/recursive-generics/
predicates/re-exports risks regardless of current screen, additional >3%-slower
or negative-interval warnings, and class/interface risk checks.
Each phase passes all 66 positive/negative admissions on both frozen natives.
Checked-JS first/middle/last errors require TS2322×9, TS2339×3 and TS2345×3.
Three warmups precede alternating fresh processes. Before/after source,
native, patch, input, harness and tool fingerprints match; diagnostic images
are never timed. All **502** paired rounds (**1,004** raw times) and **660**
successful complete admission records verify, with no observations dropped.

The original measurement process/tool handle disappeared after the second
large batch. Its next directory was empty, with no persisted admission,
timing or exit record: cause and exit are **unknown**, not reconstructed.
The empty attempt remains recoverable in cache and its audit is archived;
zero persisted records is not a claim that no compiler ever executed.
After authoritative process/handle checks and frozen-artifact revalidation,
only missing declared phases resumed. Completed data was never rerun/replaced.

| Measurement | Parent median | Candidate median | Candidate faster | Paired mean-saving 95% interval |
|---|---:|---:|---:|---:|
| Official checked JS, 20-pair screen | 28.215 ms | 27.629 ms | 15/20 | +0.061 to +0.675 ms |
| 512 families, six-pair screen | 119.435 ms | 117.445 ms | 4/6 | -6.397 to +16.055 ms |
| 8,192 families, six-pair screen | 8,934.588 ms | 7,775.258 ms | 5/6 | -146.254 to +2,224.429 ms |
| Official checked JS, 30-pair confirmation | 26.802 ms | 26.968 ms | 18/30 | -0.094 to +0.498 ms |
| 512 families, 30-pair confirmation | 115.434 ms | 110.414 ms | 25/30 | +0.588 to +5.410 ms |
| 8,192 families, confirmation batch 1 (six pairs) | 8,944.691 ms | 7,190.235 ms | 6/6 | -27.579 to +4,807.307 ms |
| 8,192 families, confirmation batch 2 (six pairs) | 7,849.280 ms | 6,573.949 ms | 6/6 | +907.036 to +1,579.383 ms |
| 8,192 families, confirmation batch 3 (six pairs) | 7,557.926 ms | 6,424.563 ms | 6/6 | +891.280 to +1,327.551 ms |
| 8,192 families, confirmation batch 4 (six pairs) | 7,621.128 ms | 6,440.683 ms | 6/6 | +1,053.424 to +1,347.999 ms |
| 8,192 families, confirmation batch 5 (six pairs) | 7,435.060 ms | 6,407.767 ms | 6/6 | +609.047 to +1,244.007 ms |
| 8,192 families, all five batches (30 pairs total) | 7,577.868 ms | 6,487.183 ms | 30/30 | +958.507 to +1,789.384 ms |

Independent scale medians are 4.3%/14.4% lower. All 30 large pairs favor the
candidate, with pooled mean saving 1.373945 seconds, interval
[0.958507, 1.789384] seconds. The supplemental five-batch t interval (df 4)
is [0.652893, 2.094998] seconds, retaining each batch's variability. This is
not 30 pairs after one warmup set. The first large batch's interval spans zero;
its variable observations remain. Official checking is inconclusive. These
gains do not justify shipping the independent class-hierarchy regression.

| Family screen (10 pairs each) | Parent median | Candidate median | Candidate faster | Paired mean-saving 95% interval |
|---|---:|---:|---:|---:|
| `checkjs_jsdoc` | 28.948 ms | 28.941 ms | 5/10 | -0.921 to +1.194 ms |
| `class_hierarchy` | 23.726 ms | 23.176 ms | 10/10 | +0.197 to +0.610 ms |
| `commonjs_graph` | 19.572 ms | 19.274 ms | 6/10 | -0.211 to +0.568 ms |
| `control_flow` | 32.799 ms | 32.376 ms | 8/10 | -0.396 to +2.136 ms |
| `deep_types` | 21.083 ms | 21.272 ms | 3/10 | -0.638 to +0.351 ms |
| `destructuring` | 14.907 ms | 14.867 ms | 5/10 | -0.488 to +0.334 ms |
| `generic_calls` | 31.936 ms | 27.477 ms | 8/10 | -16.531 to +50.667 ms |
| `import_graph` | 17.093 ms | 17.451 ms | 5/10 | -0.836 to +0.334 ms |
| `interface_composition` | 37.063 ms | 36.462 ms | 6/10 | -0.170 to +1.155 ms |
| `many_files` | 22.056 ms | 20.940 ms | 8/10 | -0.029 to +1.215 ms |
| `null_safe_access` | 33.022 ms | 33.238 ms | 4/10 | -0.879 to +1.052 ms |
| `overload_resolution` | 23.997 ms | 23.934 ms | 3/10 | -0.407 to +0.247 ms |
| `recursive_generics` | 15.255 ms | 15.756 ms | 2/10 | -0.780 to +0.088 ms |
| `reexport_graph` | 11.483 ms | 11.945 ms | 3/10 | -1.430 to +0.393 ms |
| `startup` | 2.691 ms | 2.682 ms | 7/10 | -0.105 to +0.146 ms |
| `structural_objects` | 23.157 ms | 22.620 ms | 6/10 | -0.636 to +2.089 ms |
| `tsx_components` | 19.592 ms | 19.730 ms | 4/10 | -8.063 to +5.566 ms |
| `type_predicates` | 34.982 ms | 34.958 ms | 5/10 | -1.676 to +0.613 ms |
| `type_predicates_large` | 256.865 ms | 252.439 ms | 6/10 | -4.882 to +9.394 ms |
| `variadic_tuples` | 32.341 ms | 32.959 ms | 3/10 | -2.062 to +0.357 ms |

| Independent carried-risk recheck (30 pairs each) | Parent median | Candidate median | Candidate faster | Paired mean-saving 95% interval |
|---|---:|---:|---:|---:|
| `deep_types` | 20.974 ms | 20.787 ms | 16/30 | -5.457 to +5.047 ms |
| `recursive_generics` | 14.474 ms | 14.499 ms | 14/30 | -0.142 to +0.128 ms |
| `reexport_graph` | 13.275 ms | 12.342 ms | 16/30 | -1.587 to +1.756 ms |
| `type_predicates_large` | 238.896 ms | 240.545 ms | 17/30 | -8.124 to +2.905 ms |

| Independent declaration-risk check (30 pairs each) | Parent median | Candidate median | Candidate faster | Paired mean-saving 95% interval |
|---|---:|---:|---:|---:|
| `class_hierarchy` | 22.280 ms | 22.405 ms | 9/30 | -0.429 to -0.041 ms |
| `interface_composition` | 33.020 ms | 33.167 ms | 12/30 | -0.289 to +0.124 ms |

The re-export and recursive-generics screen warnings are retained (4.0% and
3.3% slower medians). Independent carried-risk intervals span zero; recursive
generics/predicates retain adverse medians, not equivalence or proof of no
regression. Interfaces are also inconclusive. The confirmed class interval
determines rejection even though its earlier screen favored the candidate.

Experiment changes were restored exactly to the tested parent, and native
bytes restored to `0963397d`. The clean worktree then advanced to
[`3f967d367bf8175d2dbb70fd32cbe165819f5509`](https://github.com/home-lang/home/commit/3f967d367bf8175d2dbb70fd32cbe165819f5509),
preserving later #846 work. A clean matching native rebuild passes, SHA-256
`34118002e25d69a8351a60ee493c504ca734b477ed31efc79fb03ee63a9ad331`.
That restoration build is not the A/B parent/candidate or a new ranking.
All job handles are terminal/missing with recorded scope; an unknown exit is
not relabeled success. The 600-second/3,840 MB guard, disk floors and shared
lock remain unchanged. Test/build peaks are 3,259/3,073/2,798/2,797/2,987 MB
for checker/Program/driver/CLI/entrypoint; candidate build 2,929 MB, restored
current-main build 3,000 MB, timing peak 279 MB. No diagnostic image is timed.

Broader platform discovery is evidence only. The two previously audited
C++ heads remain unchanged. A separately maintained
[C++/LLVM compiler](https://github.com/ASDAlexander77/TypeScriptCompiler)
at `95bfa6990b6ba8300cb58b78a0670b3ba7f78049` is recorded with release
`v0.0-pre-alpha92` asset digests (release source `b617c712a`). Its Linux/Windows
x64 assets are not local Darwin-arm64 payloads. The scoped
[primary CLI audit](https://github.com/ASDAlexander77/TypeScriptCompiler/blob/95bfa6990b6ba8300cb58b78a0670b3ba7f78049/tslang/tslang/tslang.cpp)
finds default JIT execution, emission actions, no check-only/noEmit option in
that file, and AST-dump return before later setup. It is not installed,
executed, registered, admitted or timed; other entry points remain unproven.
The existing Linux workflow dispatch was refused with **HTTP 422** because
repository Actions are disabled: no job created, settings changed or Linux
result claimed. Runner/Actions access was requested while local work continued.

The [complete rejection archive](../../bench/vs_tsgo/evidence/20261009-shared-require-presence-rejected-854.tar.gz)
contains **1,665** verified payload checksums, including all round arrays,
admissions, fixtures, source/test patches, full logs/commands, refusal/timeout/
interruption/recovery records, restoration, platform discovery, harness and
independent verifiers. Archive SHA-256:
`dbae49f0a1008d64625ada5a2846211e53d13d63f7521a066d15d25b69cf7149`.
Original negative temporary directories were deleted by the original harness;
actual process records remain. Nine separately labeled generator replays
preserve fixtures, not original directories, new admissions or timing samples.
No five-compiler ranking, C++ admission, Linux/Windows result or universal
leadership is inferred. Those requirements remain open under #416/#838/#548.

Repository-wide `bunx --bun pickier .` on restoration source `3f967d367`
exits 1 with **11,461 existing errors and 10,613 warnings** in unchanged
code/fixtures. No auto-fixes were applied; the new Markdown tables/links and
`git diff --check` verify. The separate
[lint context](../../bench/vs_tsgo/evidence/20261009-shared-require-presence-lint-context-854.tar.gz)
retains the full command/log and terminal records with five verified payload
checksums, SHA-256
`2e134db2cc2c385533caaae0dce4daa718a319bb5eda316c4670b14905c46509`.

## Landed virtual-section profile (2026-10-09 UTC)

Diagnostic-only sampling of source `71fa7dbe7` / compiler `30330c169`,
native SHA-256
`7ab04d806bc0557ff385a91cc993b95c3a727b7e82353ff3ea3e1b59301f822a`,
passes all **62 admissions** on native/diagnostic images, including complete
8,192-family positive and TS2322×9/TS2339×3/TS2345×3 rejection controls.
The exact cached link object is
`.zig-cache/o/f8dba37497bb3b7d9b38666de3232423/home-tsc_zcu.o`, SHA-256
`d08dc0b23e922fdf5bd5f0a07898c20920591f10715a596dfd54abafbbda6483`.
Renaming 20,337 local symbols and relinking for readable stacks preserves
original/renamed object instruction sections byte-for-byte, SHA-256
`d85187627a244581eb27def017220627fe430a8f2637f0d0258d1c0feff91b9c`.
Diagnostic image SHA-256 is
`3ab6f8184056722c10b4d1c65366de98661f30e8e931f21b7dbb0acc45464e5e`.
It supplies **zero timing samples**. Native build flags/tool pins are unchanged.

Two separate one-second exploratory samples start at 0.1 and 3.0 seconds.
The later offset is declared before sampling, reflecting the shorter native
large run; the previous profile used 5.0 seconds. These are not whole-run CPU
percentages, causal speed evidence or directly comparable time windows.
The complete input inventory hash remains
`bfb2fb1bef4dcb4ad7df9bffa647b5d44bd35c6895b32772fb4044ce0ced829e`.
The compiler finishes silently with exit 0, every sample succeeds, and source/
native/input provenance is unchanged. Peak tree 315 MB, host low-water 41%,
under the same machine-lock/time/memory/disk guard; job handles are terminal.

| Exploratory leaf observations | Early | Later |
|---|---:|---:|
| Main-thread observations | 810 | 811 |
| `memberAccessReceiverIsRequireAssignmentBinding` | 130 | 108 |
| `resolveValueDeclInStmt` | 23 | 96 |
| `jsDocTypeForPreviousIdentifierDecl` | 8 | 77 |
| `collectFunctionSignaturesFromStatements` | 52 | 70 |
| `moduleNamespaceTypeForLocalImport` | 56 | 69 |
| `virtualSectionStartForNode` | 46 | 48 |
| `requireImportAssignmentMemberType` | 52 | 41 |

Raw samples retain all other frames/counts. Current `virtualSectionStartForNode`
is mapped at unslid `0x10019a2c8`; explicitly displayed offsets 0/200 match
the source/marker-presence guard and return path, and full assembly retains
the node cache plus call to `VirtualSectionIndex.start`. The root-statement
require-binding query maps at `0x100720020`, displayed offsets 244/416/476:
loop decrement and declaration-kind/name loads in the complete per-query
root loop. Source verifies identifier/root/virtual-section checks,
require-import default bindings, export unwrapping and var/let/const
`require(...)` candidates. These repeated syntax queries, and the remaining
previous-JSDoc fallback, are concrete #854 follow-up candidates; no new
runtime optimization or performance claim is made here.

Symbol bounds are derived from this diagnostic image's own `nm` output,
not copied from the previous profile. Collapsed raw samples can contain
ellipses: only explicitly displayed offsets are listed, not an invented
complete set. The first verifier missed the image-name text preceding those
offsets; its draft archive/version remains recoverable in the task cache,
and the published archive retains that verifier and first archive metadata.
Corrected parsing and instruction bounds verify without resampling or
altering any observation.

The [profile archive](../../bench/vs_tsgo/evidence/20261009-landed-virtual-section-jsdoc-profile-854.tar.gz)
has **29** verified payload checksums, including full admission process records,
exact inputs, both raw samples, instruction sections, symbols, source/assembly
mapping, runners/logs and verifier versions. SHA-256:
`e22df848c73e855a6ad5a77d23a8af0c244df3b14f2fab268dc30b33daf837ca`.
Scale-negative fixture bytes remain in the immutable virtual-section A/B
archive below and are used unchanged, not silently regenerated.

## Virtual-section prefix facts (2026-10-09 UTC)

Source [`30330c16947900dd0d9ce441071649c7f822c2fc`](https://github.com/home-lang/home/commit/30330c16947900dd0d9ce441071649c7f822c2fc)
lands a scoped source-index improvement under
[#854](https://github.com/home-lang/home/issues/854). Exact parent source is
`5ea87f0f81ce20d18782abcad2d0412797b9d3a0`, native SHA-256
`69836df6bd81695ed3f78c2b147a7ec8ac908e5e406da5523b9da7ed3c4a895a`.
Candidate native SHA-256 is
`7ab04d806bc0557ff385a91cc993b95c3a727b7e82353ff3ea3e1b59301f822a`;
frozen production/test diff SHA-256 is
`ca4aed72f39a53c74aa538652b917cac602cbe31a6033d101f9854dea0f8001a`.
The committed diff equals the frozen patch and the installed native equals
the timed candidate. No diagnostic image is timed.

The preceding landed-source profile maps repeated source-prefix scans in
`virtualSectionStartForNode` (172/169 early/middle leaf observations, not
whole-run CPU percentages). A complete lazy source-owned list now records
raw marker-line starts in one physical-source pass. Binary search returns
the last start at or before the clamped position. This deliberately is not
a directive parser: `@filename:` and `@Filename:` anywhere on a line count,
including comments/strings and a marker after the queried byte. A line is
recorded once even with both spellings. Exact newline queries still belong
to the preceding line; empty sources, trailing empty lines, EOF/wide positions
and default start zero preserve the original scalar scan.

Node and raw-position queries share these immutable position facts. Existing
node caching, filename interpretation and section-end scanning are unchanged;
no types or mutable HIR values are cached. Source replacement releases and
resets the index. Every allocation failure releases all partial facts and
uses the complete original scalar scanner for that source revision. There
are no source/library/benchmark-name exceptions, semantic numeric caps,
omitted bodies, diagnostic filtering or alignment workarounds.

Host/toolchain remain Apple M3 Pro / Mac15,6, 11 logical cores, Darwin 27 arm64,
Hyperfine 1.20.0, Python 3.9.6 and pinned Zig 2163; standalone stripped
ReleaseFast uses `-Denable_jsc=false`. Three warmups per native binary precede
alternating fresh-process pairs. The complete protocol was declared before
timing: official/512/8192 screens, independent official/512 confirmation,
all 20 family screens, independent 30-pair rechecks for every >3%-slower median
or negative screen interval plus carried predicate/re-export risks,
class/interface risk checks, and all five six-pair large batches.
Every phase passes 66 admissions: both natives on 20 positive/nine negative
official projects plus unchanged positive/negative scale projects.
Checked-JS negative controls require TS2322×9, TS2339×3 and TS2345×3 at
first/middle/last families, not erased or partial checking. Source, binary,
patch, harness, input and tool fingerprints match before/after every phase.

All **502** paired rounds (**1,004** raw times) and **660** admission checks
verify. Every large batch and slow observation is retained, including higher
variation in batches four/five. The unchanged 600-second/3840-MB machine-lock
guard kept disk admission 1024 MB/continuation 512 MB; no guard was relaxed.
First checker peak 3290 MB, corrected checker 3167 MB, Program 3044 MB,
driver 2776 MB, CLI 2566 MB, entrypoint 2992 MB, native build 2885 MB;
timing phases peak 251 MB, host low-water 28%. All job handles are terminal.

| Measurement | Parent median | Candidate median | Candidate faster | Paired mean-saving 95% interval |
|---|---:|---:|---:|---:|
| Official checked JS, 20-pair screen | 26.936 ms | 26.470 ms | 14/20 | -1.447 to +0.609 ms |
| 512 families, six-pair screen | 118.741 ms | 112.437 ms | 6/6 | +3.258 to +9.855 ms |
| 8,192 families, six-pair screen | 8,528.752 ms | 7,253.681 ms | 6/6 | +1,199.774 to +1,320.240 ms |
| Official checked JS, 30-pair confirmation | 27.475 ms | 27.284 ms | 23/30 | -0.791 to +0.576 ms |
| 512 families, 30-pair confirmation | 119.253 ms | 114.483 ms | 25/30 | +2.752 to +5.372 ms |
| 8,192 families, confirmation batch 1 (six pairs) | 8,525.480 ms | 7,185.194 ms | 6/6 | +1,282.705 to +1,398.093 ms |
| 8,192 families, confirmation batch 2 (six pairs) | 8,531.539 ms | 7,218.829 ms | 6/6 | +1,264.306 to +1,367.185 ms |
| 8,192 families, confirmation batch 3 (six pairs) | 8,575.845 ms | 7,232.368 ms | 6/6 | +1,215.612 to +1,616.995 ms |
| 8,192 families, confirmation batch 4 (six pairs) | 9,049.089 ms | 7,549.525 ms | 6/6 | +727.883 to +2,869.344 ms |
| 8,192 families, confirmation batch 5 (six pairs) | 8,980.750 ms | 7,694.942 ms | 6/6 | +936.006 to +1,990.802 ms |
| 8,192 families, all five batches (30 pairs total) | 8,571.067 ms | 7,274.721 ms | 30/30 | +1,275.955 to +1,657.831 ms |

Independent 512-family median is **4.0% lower**; the large median is **15.1%
lower**, with all 30 pairs faster. The pooled large paired mean saving is
1.466893 s, interval [1.275955, 1.657831] s. The supplemental five-batch t
interval (df 4) is also positive: **[1.225320, 1.708466] s**, keeping each
predeclared batch's mean and its variation. It is not 30 pairs after one
warmup set. Official checking is **inconclusive**, not a confirmed gain.

| Family screen (10 pairs each) | Parent median | Candidate median | Candidate faster | Paired mean-saving 95% interval |
|---|---:|---:|---:|---:|
| `checkjs_jsdoc` | 27.735 ms | 27.401 ms | 9/10 | -0.466 to +1.406 ms |
| `class_hierarchy` | 23.300 ms | 22.975 ms | 8/10 | +0.012 to +0.592 ms |
| `commonjs_graph` | 25.196 ms | 25.553 ms | 6/10 | -0.969 to +3.306 ms |
| `control_flow` | 25.645 ms | 25.665 ms | 5/10 | -0.146 to +0.484 ms |
| `deep_types` | 21.044 ms | 21.235 ms | 1/10 | -0.317 to -0.051 ms |
| `destructuring` | 14.829 ms | 14.758 ms | 6/10 | -0.107 to +0.329 ms |
| `generic_calls` | 23.074 ms | 22.659 ms | 5/10 | -0.272 to +0.833 ms |
| `import_graph` | 20.001 ms | 19.864 ms | 6/10 | -0.183 to +0.473 ms |
| `interface_composition` | 34.954 ms | 34.887 ms | 6/10 | -4.242 to +1.906 ms |
| `many_files` | 21.021 ms | 20.786 ms | 6/10 | -0.210 to +0.353 ms |
| `null_safe_access` | 32.542 ms | 32.546 ms | 4/10 | -0.318 to +0.742 ms |
| `overload_resolution` | 24.124 ms | 24.172 ms | 5/10 | -0.366 to +0.274 ms |
| `recursive_generics` | 14.622 ms | 14.926 ms | 0/10 | -0.628 to -0.124 ms |
| `reexport_graph` | 12.096 ms | 12.222 ms | 4/10 | -0.675 to +0.744 ms |
| `startup` | 2.669 ms | 2.682 ms | 6/10 | -0.095 to +0.073 ms |
| `structural_objects` | 22.705 ms | 22.622 ms | 8/10 | -0.133 to +0.334 ms |
| `tsx_components` | 20.028 ms | 18.862 ms | 10/10 | +0.945 to +1.375 ms |
| `type_predicates` | 32.837 ms | 32.803 ms | 4/10 | -0.453 to +0.233 ms |
| `type_predicates_large` | 244.542 ms | 243.704 ms | 5/10 | -1.905 to +2.913 ms |
| `variadic_tuples` | 32.085 ms | 32.006 ms | 5/10 | -0.479 to +0.563 ms |

| Independent carried-risk recheck (30 pairs each) | Parent median | Candidate median | Candidate faster | Paired mean-saving 95% interval |
|---|---:|---:|---:|---:|
| `deep_types` | 21.705 ms | 21.846 ms | 15/30 | -0.210 to +0.126 ms |
| `recursive_generics` | 15.650 ms | 15.877 ms | 9/30 | -0.447 to +0.007 ms |
| `reexport_graph` | 12.408 ms | 12.381 ms | 16/30 | -0.153 to +0.305 ms |
| `type_predicates_large` | 253.623 ms | 253.723 ms | 13/30 | -2.133 to +1.808 ms |

| Independent declaration-risk check (30 pairs each) | Parent median | Candidate median | Candidate faster | Paired mean-saving 95% interval |
|---|---:|---:|---:|---:|
| `class_hierarchy` | 24.099 ms | 23.780 ms | 20/30 | +0.038 to +0.412 ms |
| `interface_composition` | 35.223 ms | 35.327 ms | 13/30 | -0.433 to +0.090 ms |

**Adverse warnings remain unresolved.** The deep-types and recursive-generics
screens have negative saving intervals (1/10 and 0/10 wins). Independent
rechecks span zero, but recursive generics still has a **1.5%-slower median**,
only 9/30 wins, and a nearly entirely negative interval. This does not prove
equivalence or absence of regression. Deep types also retains a 0.7%-slower
independent median; predicate, re-export and interface results are inconclusive.
The class risk interval is positive. Acceptance is scoped to the supported
checked-JS scaling improvement, not a universal speedup or regression-free
claim; the warnings stay in #854's follow-up. Exploratory TSX screen improvement
is not promoted to a confirmed feature gain.

Complete checker **4,546**, Program 247, driver 200, CLI 74, entrypoint 35 and
all 136 harness tests pass. Four new controls cover every byte through/beyond
EOF, raw markers/case/duplicates, LF/CRLF, newline ownership, clamped HIR starts,
source replacement/absence/null, every forced-growth construction allocation
failure with balanced ownership/no repeated build, and complete mixed virtual
JS/TS diagnostic parity. First full run was **4,545 pass/one failure**: a
test incorrectly counted the failed allocation as a successful one. Only
that assertion was corrected; the initial draft and complete failure log remain.

Unmodified pinned Zod 4.5.2 (106 production files, package SHA-512 unchanged)
retains the identical complete 198 primary-message/position/code diagnostic
multiset: **195 TS errors plus 3 HM9002**, normalized SHA-256
`6bf2feb527d91c651631642e523da6d28cd2b0c7ae4898cac0888aa7b420874f`.
This is **not production admission**. Compatibility, admitted C++, and
Linux/Windows coverage remain unresolved. This Home-only A/B leaves the
published five-compiler ranking at **1/20** Home leads and **11/20** ahead of
native TypeScript 7; it cannot establish a new rank or causal cross-run change.

The [raw evidence](../../bench/vs_tsgo/evidence/20261009-virtual-section-facts-accepted-854.tar.gz)
archive has **1,617** payload checksums, all extracted bytes verified;
archive SHA-256:
`f3e2fa7d0920a883fc3e7bb3a15d63bdb146584f4102264fb570d1abf3b971e0`.
It includes all round arrays/admissions, both drafts, logs/commands, complete
test/diagnostic evidence, protocol/decision/lifecycle records, inputs,
harness and independent verifiers. Official negative temporary directories
were deleted by the original harness; actual process records remain, while
nine separately labeled generator replays preserve the negative fixtures.
Those replays are not the original directories, new admissions or timings.

Repository-wide `bunx --bun pickier .` exits 1 on **11,461 errors and 10,613
warnings** in unchanged files, including vendored fixtures; no auto-fixes were
applied. The changed Zig file passes pinned `zig fmt --check`, the complete
table/README verifier passes, and `git diff --check` passes. The separate
[lint context](../../bench/vs_tsgo/evidence/20261009-virtual-section-lint-context-854.tar.gz)
preserves the full read-only lint log, command and terminal-state record with
five verified payload checksums, SHA-256
`663498c41b11d231ac9fb85ddcbdd065decde0334636dbb51ad83d5b3fc045f9`.

## Landed nearest-prior profile (2026-10-09 UTC)

The separate diagnostic-only profile of source `b9e6d2591` / compiler
`af5fb320a`, native `69836df6`, passes all **62 admissions** on native/diagnostic
images, including complete 8,192-family positive/rejection controls. Original/
renamed object instruction sections are byte-identical, SHA-256
`1b07da70be706bdf2368c9b4486b0d5081503c0315d9ab842d4a375f5e6a96a5`.
Diagnostic image SHA-256:
`7a620df53e7819628825b386074cff44de808a3e3a5e58f952bcee93950adee0`,
20,336 symbols renamed for observability. It is never used for timing.

Unchanged generated input exits zero silently and matches before/after,
SHA-256 `bfb2fb1bef4dcb4ad7df9bffa647b5d44bd35c6895b32772fb4044ce0ced829e`.
Two separate one-second samples at early 0.1s/middle 5s record 824/817 main-thread
observations. These are exploratory leaf counts, not whole-run CPU percentages,
complete performance coverage or proof of a next speedup.

| Observed leaf function | Early | Middle |
|---|---:|---:|
| `virtualSectionStartForNode` | 172 | 169 |
| `memberAccessReceiverIsRequireAssignmentBinding` | 100 | 80 |
| `jsDocTypeForPreviousIdentifierDecl` | 15 | 79 |
| `collectFunctionSignaturesFromStatements` | 44 | 37 |

Source and disassembly expose remaining virtual-section prefix scans and full
root-statement require-binding lookups. Virtual-section symbol `0x100199aec`
is sampled at offsets 40/52/1424/1432; source/section presence and per-node
facts are checked, otherwise lines up to the clamped node start are searched
for both exact marker spellings. Binding symbol `0x10071f5e4` is sampled at
offsets 288/376, with root-statement/section and import/require eligibility in
the retained source/assembly. Detailed mapping and exact scalar/indexed
controls must precede any new optimization; source/library names, semantic
caps or omitted diagnostics are not substitutes.

The [new profile archive](https://github.com/home-lang/home/raw/main/bench/vs_tsgo/evidence/20261009-landed-nearest-jsdoc-profile-854.tar.gz)
retains both raw samples, both instruction sections, exact generated input,
62 process outcomes, source/assembly and verification runners, with **27**
checksums. SHA-256:
`41707450fdd406855a76ac5bf92213b9070b3d3102c746609e207a19c2bd3799`.
Scale-negative input bytes remain in the separate immutable nearest-prior
evidence archive and were used unchanged here. Guard peak 322 MB, host
low-water 44%, under the same bounds. No new optimization/timing result is
claimed by this profile.

## Nearest-prior value declaration index (2026-10-09 UTC)

Source [`af5fb320a7bfb17f0654ff25cd8dec1211f3b4c9`](https://github.com/home-lang/home/commit/af5fb320a7bfb17f0654ff25cd8dec1211f3b4c9)
lands the measured declaration-query improvement under
[#854](https://github.com/home-lang/home/issues/854). Exact parent source is
`4bbbd191d83df1e8c6f44c8b0bd96a9490f57e0c`, compiler inputs equal the
preceding class-owner source. Its complete previous-JSDoc/nearest-prior
functions match the instruction-mapped profile below byte-for-byte. The
sampled full-HIR var/let/const search is the actual target, not a guessed
source/library/benchmark exception.

The existing local-value index is not interchangeable: it selects first
bindings per container (including functions/classes), with statement ordinal
boundaries. This query needs nearest earlier simple-identifier var/let/const,
lowest NodeId ties and exact function/virtual-section eligibility. The new
complete syntax index groups declaration NodeIds by name and source start;
strict binary search/reverse eligibility preserves those rules, including
null-function recovery declarations whose positions lie inside the use
function. The original outer-container JSDoc fallback and type lowering are
unchanged; mutable TypeIds are never cached.

All construction failures release partial groups and retain the complete
original scalar scan. Source replacement releases/reset facts; HIR growth
rebuilds complete candidates. Empty name buckets are derived from complete
syntax, not numeric caps or filename shortcuts. No type approximation,
diagnostic filtering or omitted body is introduced.

Native parent SHA-256:
`fb77a18ed4b9b14a7c0ef29366963166754de8904602c2516ea2d223389cbb82`;
candidate:
`69836df6bd81695ed3f78c2b147a7ec8ac908e5e406da5523b9da7ed3c4a895a`.
Frozen production/test diff SHA-256:
`4c50fe344ba488a79cdb63d904fbc0c7017219df9e9ce5bd3d784f652b872bd0`.
Live bytes matched before commit. Host/toolchain remain M3 Pro / Mac15,6,
Darwin27 arm64, Hyperfine1.20.0, Python3.9.6, pinned Zig2163, standalone
stripped ReleaseFast with `-Denable_jsc=false`. No diagnostic image is timed.

Before timing we declared official/512/8192 screens, independent official/512
30-pair confirmation, all 20 family screens, independent checks of every
>3%-slower or wholly negative warning plus carried predicates/reexports,
separate class/interface risk checks, and all five six-pair large batches.
Each phase passes all 66 admissions: both binaries on the 20 positive/nine
negative official projects plus positive/negative unchanged scale projects.
Checked-JS controls require TS2322×9, TS2339×3, TS2345×3, not partial/erased
diagnostics. Three warmups per binary precede equally alternating fresh
processes; source/input/binary/harness/patch fingerprints remain unchanged.
All observations and each batch's admissions/warmups remain, under the same
600-second execution/3,840 MB guard, 900-second lock wait and disk floors.

Intervals below are paired parent-minus-candidate **mean** savings, not median
differences. No original or subsequent phase is excluded.

| Measurement | Parent median | Candidate median | Candidate faster | Paired mean-saving 95% interval |
|---|---:|---:|---:|---:|
| Official checked JS, 20-pair screen | 28.397 ms | 27.641 ms | 16/20 | +0.069 to +1.279 ms |
| 512 families, six-pair screen | 128.661 ms | 118.902 ms | 5/6 | +0.100 to +17.005 ms |
| 8,192 families, six-pair screen | 13,894.930 ms | 9,467.790 ms | 6/6 | +3,016.525 to +7,355.445 ms |
| Official checked JS, 30-pair confirmation | 29.169 ms | 28.265 ms | 26/30 | +0.568 to +1.000 ms |
| 512 families, 30-pair confirmation | 147.003 ms | 132.509 ms | 27/30 | +6.169 to +19.478 ms |
| 8,192 families, confirmation batch 1 (six pairs) | 13,424.807 ms | 9,610.209 ms | 6/6 | +3,237.912 to +4,355.824 ms |
| 8,192 families, confirmation batch 2 (six pairs) | 12,967.795 ms | 9,439.359 ms | 6/6 | +2,538.474 to +4,582.129 ms |
| 8,192 families, confirmation batch 3 (six pairs) | 16,973.782 ms | 12,130.317 ms | 6/6 | +1,852.235 to +11,925.098 ms |
| 8,192 families, confirmation batch 4 (six pairs) | 17,137.272 ms | 11,198.688 ms | 6/6 | +3,789.131 to +7,860.338 ms |
| 8,192 families, confirmation batch 5 (six pairs) | 14,687.403 ms | 10,035.663 ms | 6/6 | +2,650.329 to +6,150.067 ms |
| 8,192 families, all five batches (30 pairs total) | 14,287.718 ms | 10,035.663 ms | 30/30 | +3,907.759 to +5,880.549 ms |

Independent official/512/8192 confirmation supports **3.1%, 9.9% and 29.8%
lower medians**, respectively. All 30 large pairs favor the candidate; the
supplemental **five-batch** t interval (df=4) is also positive,
**+3,130.656 to +6,657.651 ms**. Batch mean savings are +3,796.868, +3,560.302,
+6,888.666, +5,824.734 and +4,400.198 ms. Variable absolute times, slower
smaller-input pairs and the adverse initial 512-family pair remain, not a
best-of selection. These are scoped results, not universal speedups.

| Family screen (10 pairs each) | Parent median | Candidate median | Candidate faster | Paired mean-saving 95% interval |
|---|---:|---:|---:|---:|
| `checkjs_jsdoc` | 28.827 ms | 28.078 ms | 9/10 | +0.204 to +0.959 ms |
| `class_hierarchy` | 24.314 ms | 23.911 ms | 9/10 | +0.251 to +1.009 ms |
| `commonjs_graph` | 25.723 ms | 25.555 ms | 7/10 | -0.242 to +0.482 ms |
| `control_flow` | 25.893 ms | 26.064 ms | 2/10 | -0.656 to +0.059 ms |
| `deep_types` | 25.375 ms | 27.308 ms | 4/10 | -5.151 to +2.325 ms |
| `destructuring` | 15.849 ms | 16.266 ms | 3/10 | -0.637 to +0.564 ms |
| `generic_calls` | 23.340 ms | 23.228 ms | 6/10 | -0.476 to +0.543 ms |
| `import_graph` | 21.041 ms | 21.526 ms | 5/10 | -0.611 to +0.893 ms |
| `interface_composition` | 36.255 ms | 36.643 ms | 5/10 | -1.802 to +2.897 ms |
| `many_files` | 21.726 ms | 22.143 ms | 3/10 | -1.497 to +0.087 ms |
| `null_safe_access` | 33.852 ms | 34.109 ms | 3/10 | -5.062 to +2.952 ms |
| `overload_resolution` | 26.285 ms | 26.819 ms | 4/10 | -1.009 to +1.133 ms |
| `recursive_generics` | 14.880 ms | 15.181 ms | 4/10 | -0.582 to +0.794 ms |
| `reexport_graph` | 12.388 ms | 12.593 ms | 5/10 | -0.632 to +0.807 ms |
| `startup` | 3.290 ms | 3.050 ms | 10/10 | +0.117 to +0.304 ms |
| `structural_objects` | 23.217 ms | 23.400 ms | 5/10 | -0.542 to +0.385 ms |
| `tsx_components` | 20.419 ms | 20.348 ms | 6/10 | -0.221 to +0.195 ms |
| `type_predicates` | 33.459 ms | 33.345 ms | 5/10 | -0.336 to +0.345 ms |
| `type_predicates_large` | 277.387 ms | 276.345 ms | 8/10 | -10.604 to +13.215 ms |
| `variadic_tuples` | 31.622 ms | 32.089 ms | 6/10 | -0.677 to +0.272 ms |

`deep_types` triggers the predeclared >3%-slower warning (~7.6% slower median),
despite its interval spanning zero. It receives an extra independent 30-pair
recheck alongside the carried predicates/reexports. Positive class/startup
screens are retained but not promoted to confirmed gains of this JSDoc change.

| Independent carried-risk recheck (30 pairs each) | Parent median | Candidate median | Candidate faster | Paired mean-saving 95% interval |
|---|---:|---:|---:|---:|
| `deep_types` | 24.603 ms | 24.799 ms | 15/30 | -3.308 to +1.512 ms |
| `reexport_graph` | 17.467 ms | 16.048 ms | 22/30 | -2.992 to +3.013 ms |
| `type_predicates_large` | 350.175 ms | 372.888 ms | 12/30 | -117.987 to +159.554 ms |

| Independent declaration-risk check (30 pairs each) | Parent median | Candidate median | Candidate faster | Paired mean-saving 95% interval |
|---|---:|---:|---:|---:|
| `class_hierarchy` | 26.269 ms | 26.034 ms | 18/30 | -1.213 to +1.277 ms |
| `interface_composition` | 38.369 ms | 37.938 ms | 13/30 | -0.533 to +3.086 ms |

The `deep_types` (~0.8% slower) and predicate (~6.5% slower) independent
medians remain adverse, with inconclusive intervals; reexport/class/interface
intervals also span zero. No equivalence or universal regression-free claim is
made. All **472** original paired rounds (944 timing samples) and **660**
admissions are independently recomputed, including the extra warning recheck.

Full checker/Program/driver/CLI/entrypoint pass **4,542 / 247 / 200 / 74 / 35**,
harness **136/136**, on the first draft with no failed/filtered/skipped test.
Six controls compare every identifier across scopes/sections/exports/ignored
patterns; **3,087** synthetic ordering/position cases and lowest NodeId ties;
strict prior boundaries; null-function recovery; source reset; actual HIR
growth; every deterministic construction allocation failure with full scalar
fallback, partial-group cleanup and balanced bytes; and complete indexed/
forced-scalar checked-JS diagnostics. Checker peak is 3,307 MB, build 3,011 MB;
measurement peaks are retained in each run log under the unchanged guard.

Pinned, unmodified Zod retains the complete primary message/position/code
multiset: **195 TS + 3 HM9002**, zero added/removed, normalized SHA-256
`6bf2feb527d91c651631642e523da6d28cd2b0c7ae4898cac0888aa7b420874f`.
This is not production admission. The later `20261009T033439Z` matrix above
measures this landed source separately and remains **1/20 / 11/20**; no
ranking is inferred from these A/Bs.
C++ admission, other platforms and the all-benchmark leadership goal remain
incomplete.

The [evidence archive](https://github.com/home-lang/home/raw/main/bench/vs_tsgo/evidence/20261009-nearest-prior-value-index-accepted-854.tar.gz)
retains **1,585** verified payload checksums. SHA-256:
`ff5837c1dd9008148a9a164552f0816c12100a3122fdaf26a7a9c10cc21bc3ad`.
Every phase/round/admission, source diff, original scalar/source mapping,
full test/build/Zod log, provenance and recalculation script remains. Exact
positive/scale-negative bytes are archived; official negative temporary
copies were deleted by the unchanged harness after their actual process
records were captured. Labeled generator replays reconstruct them without
running a compiler and are not claimed as original directories/new admissions.

## Landed-source JSDoc profile (2026-10-09 UTC)

Follow-up [#854](https://github.com/home-lang/home/issues/854) profiles the
actual landed source `962957813` / compiler `ac3488350`, native
`fb77a18ed4b9b14a7c0ef29366963166754de8904602c2516ea2d223389cbb82`.
The diagnostic-only image passes **62 admissions**: both native/diagnostic
images on the 58 official positive/negative processes plus 8,192-family
positive/rejection controls on both. Its original/renamed object instruction
sections are byte-identical, SHA-256
`a03c8bf884cbd5ea7210c72a5dd95524a862c3a9fab581228005a8aa581468d2`.
Diagnostic image SHA-256:
`8c2ae47e4fbff9a0cfdd6bede833a8706dd2f491cc41a61ae92b2259396e10e2`;
20,332 local symbols are renamed for observability. It is never timed.

The unchanged 8,192-family project exits zero silently with the same input
inventory before/after, SHA-256
`bfb2fb1bef4dcb4ad7df9bffa647b5d44bd35c6895b32772fb4044ce0ced829e`.
Separate one-second samples start at early (0.1-second) and middle
(5-second) offsets, yielding 805/822 main-thread observations. These are
exploratory leaf counts, **not whole-run CPU percentages**, complete profiles
or causal proof of the next optimization. The native binary remains unchanged.

| Observed leaf function | Early sample | Middle sample |
|---|---:|---:|
| `jsDocTypeForPreviousIdentifierDecl` | 172 | 261 |
| `virtualSectionStartForNode` | 119 | 131 |
| `memberAccessReceiverIsRequireAssignmentBinding` | 57 | 75 |
| `collectFunctionSignaturesFromStatements` | 38 | 27 |

The dominant named leaf in both samples maps precisely to the inlined
`nearestPriorValueDeclInSameFunction` scan. Symbol start `0x1003a8278` plus
sampled offsets 400/416/432 gives `0x1003a8408`, `0x1003a8418` and `0x1003a8428`.
Captured instructions advance a full-HIR ordinal, filter kinds 3/4/5 (var/let/const), compare
earlier/nearest spans and identifier names, then enforce enclosing-function
and virtual-section eligibility. The original source and assembly are retained.
This repeated syntax/declaration query is the next candidate for complete
owned facts; no new optimization, filename shortcut or performance claim has
yet been made under #854. Secondary require-binding/section observations are
also retained rather than declared resolved from a one-second snapshot.

The [profile archive](https://github.com/home-lang/home/raw/main/bench/vs_tsgo/evidence/20261009-landed-owner-jsdoc-profile-854.tar.gz)
retains both raw samples, both instruction sections, exact generated input,
all 62 process records, source/assembly mapping, provenance and verification
runners, with **24** payload checksums. SHA-256:
`0fd6303df6aae1681b110bf4cebbb7265df78d9e943f417a9a502de6c826c600`.
Scale-negative fixture bytes remain in the separate immutable class-owner
evidence archive; this profile uses those exact rejection inputs. Guard peak
is 262 MB, host low-water 34%; no execution/memory/disk bound is relaxed.

## Class-local typedef owner index (2026-10-09 UTC)

Source [`ac348835050d26963166dc276b8774d6d9a8a383`](https://github.com/home-lang/home/commit/ac348835050d26963166dc276b8774d6d9a8a383)
lands the separate class-local JSDoc typedef ownership improvement in
[#853](https://github.com/home-lang/home/issues/853). Parent source is
`b513c85d39a00b9f0d7266ae8b46bc7de3cbc0cb`, already including the earlier
modifier-merge index. Samples from those experiments are not merged.
The current parent's entire typedef pass and class-search function match the
previously instruction-mapped source byte-for-byte: per typed typedef tag,
`reportClassLocalTypedefTemplateReferences` searches every HIR node for the
smallest class strictly containing its comment. The older sample addresses
are not mislabeled as a new profile of the later parent binary.

The new complete class-span index is built lazily and owned by one typedef
pass. Sorted nested/disjoint ranges support binary-search ownership, with
strict start/end boundaries and lowest NodeId ties preserved. Empty/reversed
ranges cannot contain a comment. Crossing ranges or allocation failure free
partial data and use the complete scalar search for all remaining queries.
JSDoc parsing, template/type checking and diagnostic emission remain unchanged.
No persistent checker fields, foreign TypeIds, source-name shortcuts, numeric
semantic caps, approximate types or body omission are added.

The scalar search now tests actual owner absence instead of using the widest
u32 width as an unset sentinel. A synthetic widest-range control verifies
that logical boundary correction on both paths; this is not a claim of
successful compilation of a 4 GB file.

Native parent SHA-256 is
`9e9cc2a1d108640694c066b7afb36e2b286a73a03d92271d30b3fa657c54f8ea`;
candidate is
`fb77a18ed4b9b14a7c0ef29366963166754de8904602c2516ea2d223389cbb82`.
Frozen production/test diff SHA-256:
`b90fd86e1421a2b0cc6d6cd8a2d64d5eed556b1498288957582ca0b096c74a83`.
Its live working-tree bytes matched before commit. The standalone native
build uses pinned Zig `0.17.0-dev.2163+89ff10d56`, stripped ReleaseFast,
`-Denable_jsc=false`, on M3 Pro / Mac15,6, Darwin 27 arm64, Hyperfine 1.20.0
and Python 3.9.6. Diagnostic images never supply these timing samples.

All phases were declared before timing and require 66 successful admissions:
both binaries on 20 official positive/nine negative projects, plus unchanged
512/8,192-family positive/negative generators. Every checked-JS control
requires TS2322×9, TS2339×3 and TS2345×3, not partial/erased diagnostics.
After three warmups per binary, fresh processes alternate pair order equally.
Binary/input/harness/patch fingerprints match before/after every phase.
All five separate six-pair large batches retain their own admissions, warmups
and fingerprints under the unchanged 600-second execution bound and 3,840 MB
tree guard. They are not represented as one continuous 30-pair run.

Intervals below describe paired parent-minus-candidate **mean** savings,
not differences between the displayed medians. No observation is filtered.

| Measurement | Parent median | Candidate median | Candidate faster | Paired mean-saving 95% interval |
|---|---:|---:|---:|---:|
| Official checked JS, 20-pair screen | 29.612 ms | 28.146 ms | 20/20 | +1.326 to +1.722 ms |
| 512 families, six-pair screen | 157.622 ms | 130.732 ms | 6/6 | +23.734 to +30.319 ms |
| 8,192 families, six-pair screen | 18,588.827 ms | 12,295.112 ms | 6/6 | +6,251.493 to +6,312.807 ms |
| Official checked JS, 30-pair confirmation | 29.662 ms | 28.097 ms | 30/30 | +1.339 to +1.753 ms |
| 512 families, 30-pair confirmation | 157.129 ms | 131.756 ms | 30/30 | +23.146 to +33.404 ms |
| 8,192 families, confirmation batch 1 (six pairs) | 21,232.136 ms | 15,186.577 ms | 6/6 | +3,440.071 to +7,025.335 ms |
| 8,192 families, confirmation batch 2 (six pairs) | 18,255.094 ms | 11,941.947 ms | 6/6 | +6,147.551 to +6,444.165 ms |
| 8,192 families, confirmation batch 3 (six pairs) | 17,907.636 ms | 11,408.930 ms | 6/6 | +6,307.982 to +6,701.440 ms |
| 8,192 families, confirmation batch 4 (six pairs) | 18,872.256 ms | 12,670.743 ms | 6/6 | +5,767.170 to +7,126.680 ms |
| 8,192 families, confirmation batch 5 (six pairs) | 20,875.306 ms | 13,336.153 ms | 6/6 | +3,853.595 to +8,818.746 ms |
| 8,192 families, all five batches (30 pairs total) | 18,790.065 ms | 12,398.067 ms | 30/30 | +5,665.278 to +6,661.269 ms |

Independent confirmation supports **5.3%, 16.1% and 34.0% lower medians** at
official/512/8,192-family sizes, respectively. Every one of the 30 paired
observations per confirmation favors the candidate. The supplemental
**five-batch** t interval (df=4) is also positive: **+5,509.152 to +6,817.395 ms**.
Batch mean savings are +5,232.703, +6,295.858, +6,504.711, +6,446.925 and
+6,336.170 ms. Variable first/last batches and large individual observations,
including the final 22.731-second candidate run, remain. These are scoped
results, not universal leadership or performance-equivalence proof.

| Family screen (10 pairs each) | Parent median | Candidate median | Candidate faster | Paired mean-saving 95% interval |
|---|---:|---:|---:|---:|
| `checkjs_jsdoc` | 31.922 ms | 29.148 ms | 10/10 | +0.766 to +2.577 ms |
| `class_hierarchy` | 23.898 ms | 23.336 ms | 9/10 | -15.997 to +44.182 ms |
| `commonjs_graph` | 24.016 ms | 23.954 ms | 7/10 | -0.439 to +0.771 ms |
| `control_flow` | 26.028 ms | 26.077 ms | 3/10 | -0.429 to +0.482 ms |
| `deep_types` | 20.621 ms | 21.179 ms | 5/10 | -2.783 to +5.961 ms |
| `destructuring` | 14.124 ms | 14.082 ms | 5/10 | -0.149 to +0.191 ms |
| `generic_calls` | 22.223 ms | 22.335 ms | 5/10 | -0.601 to +0.231 ms |
| `import_graph` | 19.724 ms | 19.759 ms | 4/10 | -1.171 to +0.235 ms |
| `interface_composition` | 35.450 ms | 34.681 ms | 7/10 | -2.545 to +12.932 ms |
| `many_files` | 22.339 ms | 21.539 ms | 8/10 | -0.025 to +2.014 ms |
| `null_safe_access` | 31.327 ms | 31.530 ms | 5/10 | -0.470 to +0.195 ms |
| `overload_resolution` | 22.946 ms | 22.926 ms | 6/10 | -0.218 to +0.325 ms |
| `recursive_generics` | 13.905 ms | 13.835 ms | 8/10 | -0.199 to +0.416 ms |
| `reexport_graph` | 12.565 ms | 11.265 ms | 7/10 | -0.595 to +2.943 ms |
| `startup` | 2.622 ms | 2.588 ms | 5/10 | -0.054 to +0.086 ms |
| `structural_objects` | 23.923 ms | 23.952 ms | 4/10 | -0.786 to +1.510 ms |
| `tsx_components` | 19.489 ms | 19.455 ms | 8/10 | +0.020 to +0.366 ms |
| `type_predicates` | 32.728 ms | 32.830 ms | 7/10 | -0.228 to +0.728 ms |
| `type_predicates_large` | 246.493 ms | 249.880 ms | 9/10 | -1.751 to +8.075 ms |
| `variadic_tuples` | 38.851 ms | 39.103 ms | 5/10 | -6.043 to +3.545 ms |

No screen median exceeds the 3%-slower threshold and no screen interval is
wholly negative. The full family screen is retained, including wide intervals.
The predeclared carried-predicate/re-export checks still run, as do separate
class/interface checks; a positive small TSX screen is not promoted into an
independent-confirmation claim for this JSDoc change.

| Independent carried-risk recheck (30 pairs each) | Parent median | Candidate median | Candidate faster | Paired mean-saving 95% interval |
|---|---:|---:|---:|---:|
| `reexport_graph` | 11.459 ms | 11.479 ms | 13/30 | -0.806 to +0.301 ms |
| `type_predicates_large` | 242.898 ms | 245.442 ms | 11/30 | -7.941 to +7.407 ms |

| Independent declaration-risk check (30 pairs each) | Parent median | Candidate median | Candidate faster | Paired mean-saving 95% interval |
|---|---:|---:|---:|---:|
| `class_hierarchy` | 22.427 ms | 22.432 ms | 14/30 | -0.144 to +0.181 ms |
| `interface_composition` | 33.055 ms | 33.042 ms | 18/30 | -0.081 to +0.340 ms |

Predicates/re-exports have adverse recheck medians (~1.0%/~0.2% slower) with
inconclusive intervals. Class/interface intervals also span zero. None is
called equivalent or universally regression-free. All **442** paired rounds
(884 timing samples) and **660** admissions remain, independently recalculated
from raw order/exits/arrays, negative codes and before/after fingerprints.

Full checker/Program/driver/CLI/entrypoint gates pass **4,536 / 247 / 200 / 74 / 35**;
harness passes **136/136**. Five controls compare all source-byte positions,
**93,750** ordered synthetic three-range queries, widest spans, strict bounds,
ties and crossing fallback; fail every forced reallocating growth allocation;
check partial cleanup/balanced bytes; compare complete indexed/forced-scalar/
failed-index typedef diagnostics across nested/exported classes, expressions
and virtual sections; and verify lazy/empty ownership needs no allocation.

The first full checker passed **4,535 / one failed** in the new OOM control:
in-place remaps made its allocation-growth assumption nondeterministic. The
corrected TEST allocator refuses remaps, retains the multiple-growth assertion
and tests every actual growth allocation, including OOM after partial ownership.
Production code was unchanged by this correction. The original full failed
log/diff remains; no named filter or skip was introduced.

Native build passed, but disk admission subsequently refused corrected
checker/driver/entrypoint/harness before execution at 565–566 MB free. All exit
123 logs/commands remain. With no open handles, only 100 inventoried old
compiler/test cache output files in 50 task-worktree directories were removed
(1,297,717,280 rebuildable bytes). Source, evidence, benchmark binaries and
diagnostic profile objects stayed intact; the manifest records every target.
The refused gates were rerun successfully with the same 1,024/512 MB disk
floors, 600-second execution bound, 900-second lock wait and 3,840 MB limit.
Checker peak was 3,373 MB, build 2,919 MB; measurements peak at 235–275 MB.

Pinned, unmodified Zod's 106 production files retain the complete primary
message/position/code multiset: **195 TS + 3 HM9002**, zero added/removed;
normalized SHA-256
`6bf2feb527d91c651631642e523da6d28cd2b0c7ae4898cac0888aa7b420874f`.
This is **not production admission**. No C++ admission, other-platform result
or all-benchmark leadership is established. The latest full matrix above
at this A/B's publication led **1/20** and beat native TS7 **12/20**. The
separate fresh `20261009T004232Z` matrix above now reports **1/20 / 11/20**;
it is not inferred from these A/B samples.

The [complete evidence archive](https://github.com/home-lang/home/raw/main/bench/vs_tsgo/evidence/20261009-class-typedef-owner-index-accepted-853.tar.gz)
contains **1,570** verified payload checksums; SHA-256:
`2b1a5411fea8319951b831cd0497988daef540f93024a773e03cce15426b6ca5`.
Every phase/round/admission, source/test diff, mapping proof, full gate/build/
Zod log, original failure, guard refusal, cache-removal manifest and
recalculation script is retained. Positive and scale-negative project bytes
are archived. Official negative temporary copies were deleted by the unchanged
harness after their actual process records were captured; separately labeled
generator replays reconstruct those inputs without executing a compiler and
are not mislabeled as original directories or new admissions.

## Class/interface modifier-merge index (2026-10-08 UTC)

Source [`bbabc2f4dd2417b4a71460b722b0a07930136c88`](https://github.com/home-lang/home/commit/bbabc2f4dd2417b4a71460b722b0a07930136c88)
lands the first measured optimization in
[#853](https://github.com/home-lang/home/issues/853). The declaration-space
sample offset 12,656 maps to `checkClassInterfaceMemberModifierMerges`'s
inner whole-statement scan: export unwrapping, interface kind, virtual section
and declaration-name comparisons. This mapping uses the actual sampled
instructions and original source, not a guessed library/benchmark shortcut.

The implementation builds a complete, pass-local ordered index of interfaces
by the exact existing `(name, virtual_section_start)` key. Classes and each
same-key interface list retain statement order; the existing member-level
diagnostic checker is unchanged. A complete absence of eligible interfaces
ends this one merge check naturally. Partial construction frees every group
and falls back to the complete original scan on OOM. No persistent checker
fields, foreign TypeIds, semantic limits or diagnostic suppression are added.

Parent source is `6004a2634c71da0fdf13571ca94e117f8b23504a`, reusing the
accepted native parent SHA-256
`c16c8caaf52d35180a7fcd53b87cac0dd71ff7b86526ef285e09bb4e088335f4`.
Candidate SHA-256 is
`9e9cc2a1d108640694c066b7afb36e2b286a73a03d92271d30b3fa657c54f8ea`,
built with pinned Zig `0.17.0-dev.2163+89ff10d56`, stripped ReleaseFast,
`-Denable_jsc=false`. The frozen source/test diff SHA-256 is
`c83cf3f0e2fa3fcf80c9be499e43f94c6786e0bb9077b98c1ad1a9e82ab51422`;
the live working-tree diff matched it before commit. Host/tools are the same
M3 Pro / Mac15,6, Darwin 27 arm64, Hyperfine 1.20.0 and Python 3.9.6.

Every phase passes **66 admissions** before timing: both binaries on the
20 official positive/nine negative projects, plus positive/negative projects
at 512 and 8,192 unchanged-generator JSDoc families. Each checked-JS negative
control requires all 15 expected errors (TS2322×9, TS2339×3, TS2345×3), not
silent acceptance or erased types. Binary/input/harness/patch fingerprints
match before and after every phase. Each round retains one fresh process per
binary, with equally alternating command order and three warmups per binary.

Because 8,192-family processes take about 18–21 seconds, before confirmation
we declared **five separate six-pair batches**, each with its own admissions,
warmups and fingerprints. All 30 pairs remain; this is not represented as
one continuous 30-pair run or a best-of selection. The 600-second execution
bound, 3,840 MB tree guard, 900-second lock wait and disk floors are unchanged.
The original screen runner and subsequent batching revision are both retained.

Intervals below describe paired **parent-minus-candidate mean** savings,
not differences between the displayed medians. No observation is filtered.

| Measurement | Parent median | Candidate median | Candidate faster | Paired mean-saving 95% interval |
|---|---:|---:|---:|---:|
| Official checked JS, 20-pair screen | 31.074 ms | 31.055 ms | 7/20 | -0.414 to +0.342 ms |
| 512 families, six-pair screen | 161.638 ms | 159.119 ms | 5/6 | -0.195 to +7.932 ms |
| 8,192 families, six-pair screen | 20,893.870 ms | 20,300.335 ms | 4/6 | -2,184.677 to +1,717.159 ms |
| Official checked JS, 30-pair confirmation | 29.197 ms | 29.176 ms | 16/30 | -0.086 to +0.566 ms |
| 512 families, 30-pair confirmation | 156.808 ms | 155.196 ms | 22/30 | +0.268 to +2.385 ms |
| 8,192 families, confirmation batch 1 (six pairs) | 18,267.311 ms | 18,952.048 ms | 1/6 | -1,060.826 to +250.589 ms |
| 8,192 families, confirmation batch 2 (six pairs) | 18,528.940 ms | 18,090.819 ms | 6/6 | +277.837 to +574.783 ms |
| 8,192 families, confirmation batch 3 (six pairs) | 18,389.790 ms | 18,035.703 ms | 6/6 | +258.045 to +451.751 ms |
| 8,192 families, confirmation batch 4 (six pairs) | 18,382.151 ms | 18,062.660 ms | 6/6 | +204.821 to +522.891 ms |
| 8,192 families, confirmation batch 5 (six pairs) | 18,524.941 ms | 17,902.198 ms | 6/6 | +232.601 to +834.960 ms |
| 8,192 families, all five batches (30 pairs total) | 18,406.634 ms | 18,069.441 ms | 25/30 | +84.799 to +424.692 ms |

Independent confirmation supports small gains at **512 families (~1.0%)**
and **class hierarchy (~1.0%)**. Official checked JS remains inconclusive.
The pooled large-input interval is positive, but the supplemental **five-batch**
t interval (df=4) is **−211.693 to +721.184 ms**, spanning zero. Its batch
mean savings are −405.119, +426.310, +354.898, +363.856 and +533.780 ms.
The adverse first batch is not discarded; cross-batch uncertainty remains,
so the pooled interval is not claimed as universal/scaling proof.

| Family screen (10 pairs each) | Parent median | Candidate median | Candidate faster | Paired mean-saving 95% interval |
|---|---:|---:|---:|---:|
| `checkjs_jsdoc` | 29.290 ms | 29.230 ms | 6/10 | -0.179 to +0.250 ms |
| `class_hierarchy` | 23.214 ms | 23.071 ms | 7/10 | -0.009 to +0.344 ms |
| `commonjs_graph` | 24.156 ms | 24.169 ms | 4/10 | -0.387 to +0.827 ms |
| `control_flow` | 25.641 ms | 25.548 ms | 6/10 | -0.710 to +0.493 ms |
| `deep_types` | 20.943 ms | 20.947 ms | 5/10 | -0.194 to +0.253 ms |
| `destructuring` | 14.605 ms | 14.695 ms | 6/10 | -0.223 to +0.286 ms |
| `generic_calls` | 22.469 ms | 22.516 ms | 7/10 | -0.072 to +0.610 ms |
| `import_graph` | 20.757 ms | 20.525 ms | 6/10 | -0.596 to +0.609 ms |
| `interface_composition` | 33.553 ms | 33.746 ms | 4/10 | -0.392 to +0.009 ms |
| `many_files` | 21.359 ms | 21.261 ms | 5/10 | -0.546 to +0.438 ms |
| `null_safe_access` | 31.870 ms | 32.273 ms | 2/10 | -0.567 to +0.036 ms |
| `overload_resolution` | 23.418 ms | 23.394 ms | 5/10 | -0.302 to +0.447 ms |
| `recursive_generics` | 14.415 ms | 14.472 ms | 5/10 | -0.257 to +0.230 ms |
| `reexport_graph` | 11.811 ms | 11.728 ms | 7/10 | -0.363 to +1.866 ms |
| `startup` | 2.593 ms | 2.622 ms | 5/10 | -0.068 to +0.064 ms |
| `structural_objects` | 22.406 ms | 22.506 ms | 5/10 | -0.348 to +0.256 ms |
| `tsx_components` | 19.959 ms | 20.330 ms | 2/10 | -0.416 to +0.413 ms |
| `type_predicates` | 32.623 ms | 32.934 ms | 4/10 | -0.669 to +0.353 ms |
| `type_predicates_large` | 248.194 ms | 245.774 ms | 7/10 | -10.769 to +5.873 ms |
| `variadic_tuples` | 31.357 ms | 31.417 ms | 5/10 | -0.381 to +0.315 ms |

No screen median is more than 3% slower and no screen interval is wholly
negative. The carried #848/#851 risks still receive independent 30-pair
rechecks. Source review additionally motivated class/interface-family checks:
the eager index can allocate even when no class can merge, and the interface
screen's small adverse observation needed confirmation rather than omission.

| Independent carried-risk recheck (30 pairs each) | Parent median | Candidate median | Candidate faster | Paired mean-saving 95% interval |
|---|---:|---:|---:|---:|
| `reexport_graph` | 11.802 ms | 11.680 ms | 16/30 | -0.539 to +0.966 ms |
| `type_predicates_large` | 244.421 ms | 243.934 ms | 15/30 | -2.647 to +0.748 ms |

| Independent declaration-risk check (30 pairs each) | Parent median | Candidate median | Candidate faster | Paired mean-saving 95% interval |
|---|---:|---:|---:|---:|
| `class_hierarchy` | 23.198 ms | 22.970 ms | 22/30 | +0.074 to +0.447 ms |
| `interface_composition` | 33.957 ms | 33.823 ms | 20/30 | -0.087 to +0.522 ms |

The interface/carried-risk intervals span zero, not proof of equivalence or
regression freedom. All **442** original paired rounds (**884** timing samples)
and **660** admissions remain. The verifier recomputes raw sample order,
arrays, medians, intervals, fingerprints and complete negative code counts.

Full checker/Program/driver/CLI/entrypoint pass **4,531 / 247 / 200 / 74 / 35**;
the benchmark harness passes **136/136**. New controls compare complete
diagnostic slices with the original scanner across exports, duplicates,
namespace containers and virtual sections; fail every construction allocation,
verify partial-group cleanup/full fallback, and test allocation-free absence
of interfaces. The first OOM-control test used a hardcoded failure range that
also hit diagnostic allocation: its original draft and full logged failing
repeat (**4,530 passed / one failed**) remain. The corrected test measures
the construction allocation count; no test is filtered or skipped.

Pinned, unmodified Zod's 106 production files retain the same complete primary
message/position/code multiset: **195 TS + 3 HM9002**, zero added/removed.
Normalized SHA-256 is
`6bf2feb527d91c651631642e523da6d28cd2b0c7ae4898cac0888aa7b420874f`.
This is not Zod production admission. Checker peak is 3,113 MB, build 2,951 MB;
measurement phases peak at 232–276 MB under the unchanged guard.

The [evidence archive](https://github.com/home-lang/home/raw/main/bench/vs_tsgo/evidence/20261008-class-interface-index-accepted-853.tar.gz)
has **1,563** verified payload checksums; SHA-256:
`68abb2117c469dcbf4a6d66f48a530fa767f72ed3a5eeb476f7edaf7f9607613`.
It includes every phase/round/admission, both runner revisions and the
independent risk runner, exact positive/scale-negative projects, source diffs,
assembly mappings, full test/build/Zod logs and the recalculation scripts.
Official negative temporary copies were deleted by the unchanged harness;
their complete actual process records remain. Separately labeled archived
generator replays reconstruct those inputs without invoking a compiler and
are not mislabeled as the original directories or new admissions.

The separate late `checkSourceFile` sample is now mapped to
`reportClassLocalTypedefTemplateReferences`, called per typed typedef by
`checkJSDocTypedefTypeTags`: instruction kinds 8/52 are class declarations/
expressions, and the loop selects the shortest class strictly containing the
comment before reading its leading JSDoc. This whole-HIR scan per typedef is
**not optimized by this commit**. An archived exhaustive interval design model
is exploratory, not a compiler correctness/performance result. #853 stays
open for this next source-derived change; #416/#838/#548 stay open. The latest
full matrix remains Home first **1/20**, faster than native TS7 **12/20**;
no fresh ranking, universal leadership, C++ admission or other-platform result
is established by this A/B.

## Historical compiler matrices

### Landed global-reference matrix (2026-10-08 UTC)

Result `20261008T202953Z` measures source
[`211d28ce3`](https://github.com/home-lang/home/commit/211d28ce32d96c8b88656966ce40ce0730034b9d),
whose compiler tree equals
[`00a9dcf8f`](https://github.com/home-lang/home/commit/00a9dcf8fd4cf6ce4505803f6a699e1dec6c2650)
([#850](https://github.com/home-lang/home/issues/850)), including main's separate
owned-transfer change in #842. This is a fresh same-host compiler matrix, not
an exact-parent experiment attributing every difference to those changes.

This run predates [#852](https://github.com/home-lang/home/issues/852)'s direct
JSDoc negative controls. Its checked-JS row is therefore a provisional timing,
not a fair speed claim under validation protocol 4. All five pinned compilers
pass the subsequent untimed isolated and combined controls, but those checks
are not retroactively relabeled as admission performed before this measurement.
A fresh complete protocol-4 run is required to replace this checkpoint.

All five compilers pass the identical 20 positive projects and eight
negative-control projects: **140/140 admissions**. Thirty fresh processes per
compiler/workload follow three warmups, with rotating order balanced across
all five commands: **600 raw rounds / 3,000 retained samples**. Executables,
complete Rust/Bun payloads, generated projects, harness and project context
match before admission and after measurement. No outlier or compiler is
removed to improve the ranking.

Host: Apple M3 Pro / Mac15,6, 11 logical cores, Darwin 27.0.0 arm64. Tools:
Node 26.10.0, Hyperfine 1.20.0, Python 3.9.6. Home uses pinned Zig
`0.17.0-dev.2163+89ff10d56`, stripped ReleaseFast, `-Denable_jsc=false`.
The standalone native executable is byte-pinned at SHA-256
`c16c8caaf52d35180a7fcd53b87cac0dd71ff7b86526ef285e09bb4e088335f4`.
Native TypeScript 7 runs directly; Rust and Bun use the unchanged
[Darwin ARM64 registry](https://github.com/home-lang/home/blob/main/bench/vs_tsgo/profiles/darwin-arm64.json).
The surviving cached Bun payload matches the original executable and full
inventory pins; no moving-canary substitution was made.

| Workload | tsc 6.0.3 median | native TS 7.0.2 median | Home median | Rust tsc-rs 0.1.0 median | Bun canary median | Home vs fastest competitor |
|---|---:|---:|---:|---:|---:|---:|
| `checkjs_jsdoc` | 205.2 ms | 23.4 ms | 29.7 ms | 22.6 ms | 13.5 ms | Provisional (JSDoc gate absent) |
| `class_hierarchy` | 187.6 ms | 21.4 ms | 23.6 ms | 18.0 ms | 14.1 ms | 1.68× slower |
| `commonjs_graph` | 149.2 ms | 18.2 ms | 24.1 ms | 14.6 ms | 11.8 ms | 2.04× slower |
| `control_flow` | 185.3 ms | 26.5 ms | 25.0 ms | 23.5 ms | 15.9 ms | 1.58× slower |
| `deep_types` | 127.9 ms | 20.4 ms | 20.4 ms | 13.5 ms | 12.7 ms | 1.61× slower |
| `destructuring` | 132.2 ms | 16.2 ms | 14.4 ms | 14.0 ms | 10.8 ms | 1.34× slower |
| `generic_calls` | 176.3 ms | 22.2 ms | 22.4 ms | 18.4 ms | 14.1 ms | 1.59× slower |
| `import_graph` | 125.9 ms | 14.1 ms | 19.4 ms | 10.5 ms | 13.9 ms | 1.84× slower |
| `interface_composition` | 202.4 ms | 32.3 ms | 34.1 ms | 23.7 ms | 17.5 ms | 1.95× slower |
| `many_files` | 191.5 ms | 21.1 ms | 20.3 ms | 15.0 ms | 12.3 ms | 1.65× slower |
| `null_safe_access` | 185.3 ms | 26.0 ms | 31.9 ms | 22.0 ms | 16.2 ms | 1.97× slower |
| `overload_resolution` | 195.6 ms | 32.3 ms | 23.5 ms | 26.0 ms | 20.1 ms | 1.17× slower |
| `recursive_generics` | 152.4 ms | 40.0 ms | 14.5 ms | 32.4 ms | 9.4 ms | 1.54× slower |
| `reexport_graph` | 93.7 ms | 10.0 ms | 11.2 ms | 8.3 ms | 8.2 ms | 1.36× slower |
| `startup` | 63.2 ms | 7.2 ms | **2.8 ms** | 5.7 ms | 6.2 ms | **2.02× faster** |
| `structural_objects` | 189.6 ms | 27.3 ms | 23.0 ms | 22.8 ms | 17.0 ms | 1.35× slower |
| `tsx_components` | 160.3 ms | 15.5 ms | 19.4 ms | 13.7 ms | 10.1 ms | 1.93× slower |
| `type_predicates` | 228.5 ms | 38.7 ms | 32.0 ms | 32.9 ms | 22.7 ms | 1.41× slower |
| `type_predicates_large` | 979.7 ms | 295.4 ms | 240.0 ms | 262.3 ms | 156.6 ms | 1.53× slower |
| `variadic_tuples` | 246.4 ms | 45.9 ms | 31.7 ms | 34.1 ms | 19.3 ms | 1.64× slower |

Home has the lowest unrounded median on **1/20** workloads (`startup`) and
beats native TypeScript 7 on **11/20**. Bun leads 18 and Rust leads imports.
`deep_types` rounds both Home and native TS 7 to 20.4 ms; the count uses the
actual unrounded medians. These are descriptive comparisons, not significance
tests, equivalence claims, or a causal regression from the earlier 2/20
snapshot. All compilers' absolute times changed across those runs; earlier
numbers are retained below as dated history and are never mixed into this table.

The provisional checked-JS timing ratio is **2.19×**, pending the new gate.
Validated relative gaps include CommonJS
(**2.04×**), null-safe access (**1.97×**), interface composition (**1.95×**),
and TSX (**1.93×**). The separate #850 exact-parent measurements remain the
evidence for that patch's gains, including its inconclusive 1,024-family
confirmation and adverse observations. This matrix identifies remaining
work; it does not demonstrate the #416 all-benchmark leadership goal.

The C++ OnlySpecs candidate stays excluded: its unmodified pinned CLI exits
zero silently on all eight negative-control projects. Canonical active C++
selection and other platforms remain open under #838; no excluded compiler
gets a timing row. Full pinned Zod still emits **195 TS + 3 HM9002** (#548),
so this synthetic admission is not real-project production admission.

The [matrix archive](https://github.com/home-lang/home/raw/main/bench/vs_tsgo/evidence/20261008T202953Z.tar.gz)
retains all 600 round files byte-for-byte, all admissions, and **603 verified
payload checksums**. Archive SHA-256:
`516ab0004c30e366d76395a4ac7d522f597a6c87ffc88089dc1a5103d790cb75`.
The shared-lock run stayed below the unchanged 3,840 MB guard, with a 391 MB
peak tree footprint and 40% host low-water mark. No resource limit or disk
floor was relaxed.

The [run-context archive](https://github.com/home-lang/home/raw/main/bench/vs_tsgo/evidence/20261008T202953Z-context-838-850.tar.gz)
retains the exact guarded runner/log, source-tree equivalence proof, all
recomputed medians/leader counts, row verifier and passing **128/128** harness
log, plus the linked integrated compiler build record. Its **12** payload
checksums verify. SHA-256:
`3e0e7637a5bff6562f25bf706ddfa2fcea8d4a52ca6d920e8ded4af9fa8f14ba`.

## Historical correctness and performance checkpoints

### Default module-owner correctness and cost checkpoint (2026-10-08 UTC)

Source [`206cdf1aa`](https://github.com/home-lang/home/commit/206cdf1aae079699d1e7dceab3aa2897bf30b3e4)
([#845](https://github.com/home-lang/home/issues/845),
[#846](https://github.com/home-lang/home/issues/846)) is measured against
exact parent `b6e34fc68`, with
retained declaration/source facts rather than a filename-only default-import
check. This is **not a new five-compiler matrix or a demonstrated speedup**.
At that checkpoint, the expanded matrix below recorded Home leading only 2/20
workloads. It is historical; the current matrix is above. The #416 leadership
goal remains incomplete.

Default eligibility now separates actual value/type defaults from synthetic
defaults, using declaration/JS source kind, ESM syntax, export assignment,
`__esModule`, and package-implied module format. Declaration owners retain
their actual `.d.ts`/`.d.mts`/`.d.cts` parse context. Package format provenance
follows TypeScript's file/strategy/package rules; it is not used to admit JS.
JS is a typed inference source only when JS sources are enabled **and that
path is actually in the Program inventory**. An explicit admitted
`node_modules` JS root and an unadmitted sibling are both unit controls, so
the admission decision is not a folder-name heuristic. Build, normal CLI and
LSP/edit paths share this borrowed inventory.

Real default checks cover relative and package imports, including type-only
bindings and type-space defaults. Untyped JS retains genuine TS7016 rather
than receiving an extra missing-default error; its primary report now anchors
to the module literal. Named-import suggestions remain distinct from TS1192.

| Same-input correctness gate | Candidate outcome |
|---|---|
| 95 source/option cases versus native TS 7.0.2 | All 95 match primary code/count/position/message and success/error exit classes |
| The 76 configurations shared with TS 6.0.3 | All 76 match exactly; includes the previously failed star-barrel default import |
| 19 CommonJS/node10 configurations | TS 6 accepts the deprecated option with `ignoreDeprecations: "6.0"`; native TS 7 and Home reject with located TS5108, not semantic passes |
| 10 additional package/default/untyped-JS controls | All 10 match TS 6 and native TS 7 exactly |
| Initial declaration-owner and package gates | Failures retained, not relabeled successful |

The 95-case matrix covers ESNext, CommonJS, Preserve and NodeNext ESM/CJS
package scopes, TS/MTS/CTS/declaration/JS sources, direct/named/namespace/type
defaults, star barrels, value/type imports and interop markers. The separate
package matrix preserves unadmitted-JS negatives. Config locations are from
upstream [#847](https://github.com/home-lang/home/issues/847), not an option
suppression in this patch. Oracle normalization only canonicalizes known
fixture path prefixes, including config paths; it preserves every code,
count, source coordinate, message and original raw output. Primary diagnostic
parity is not a claim that every related-info/hint format or all TS projects
are correct. Broader #843/#844/#845/#846 acceptance remains open.

#### Exact-parent costs and adverse observations

Parent and candidate use Zig `0.17.0-dev.2163+89ff10d56`, stripped ReleaseFast,
`-Denable_jsc=false` for the independent standalone target. The host is Apple
M3 Pro / Mac15,6, 11 logical cores, Darwin 27.0.0 arm64. Each phase admits both
compilers on the 20 unchanged official workloads and their existing negatives
(56 admissions), requires the unchanged 4,096-module scale project to exit
zero without output, and retains all fresh-process samples after three
warmups. Pair order alternates and reverses; binary/input/harness/tool/runner
hashes are unchanged before and after. No compiler failing admission is timed.

| Exact-parent confirmation | Parent median | Candidate median | Faster pairs | Paired mean saving 95% t interval |
|---|---:|---:|---:|---:|
| Official re-export graph | 13.293 ms | 13.399 ms | 12/30 | −0.724 to +0.250 ms |
| 4,096-module scale | 1,310.054 ms | 1,299.988 ms | 5/10 | −42.673 to +72.428 ms |
| Large-predicate family screen | 266.172 ms | 275.544 ms | 1/10 | **−14.135 to −1.550 ms** |
| Independent large-predicate recheck | 267.171 ms | 269.456 ms | 11/30 | −3.735 to +4.465 ms |

Graph and scale confirmation medians are respectively **0.8% slower / 0.8%
faster**, with intervals spanning zero: inconclusive, not equivalence or a
speedup. The large-predicate screen is **3.5% slower**, with an entirely
negative saving interval. The predeclared >3%-slower median rule requires an
independent 30-pair recheck. That recheck is **0.9% slower**, with an interval
spanning zero. Both observations are retained, without substituting a
favorable rerun for the adverse screen; neither establishes universal
regression freedom or a permanent slowdown.

All 20 ten-pair family screens remain visible:

| Workload | Parent median (ms) | Candidate median (ms) | Faster pairs |
|---|---:|---:|---:|
| Startup | 3.298 | 3.059 | 9/10 |
| Many files | 23.334 | 23.233 | 6/10 |
| Deep types | 23.597 | 23.446 | 7/10 |
| Import graph | 22.269 | 22.305 | 5/10 |
| Re-export graph | 15.529 | 14.665 | 7/10 |
| TSX components | 22.009 | 21.801 | 8/10 |
| Generic calls | 25.509 | 25.654 | 2/10 |
| Control flow | 28.182 | 28.157 | 4/10 |
| Type predicates | 35.523 | 35.401 | 7/10 |
| Large type predicates | 266.172 | 275.544 | 1/10 |
| Null-safe access | 35.288 | 35.091 | 5/10 |
| Destructuring | 16.113 | 16.095 | 6/10 |
| Overloads | 25.951 | 26.161 | 3/10 |
| Class hierarchy | 25.705 | 25.609 | 7/10 |
| Structural objects | 24.490 | 24.745 | 3/10 |
| Interface composition | 37.519 | 37.375 | 6/10 |
| Variadic tuples | 36.378 | 34.992 | 8/10 |
| Checked JS / JSDoc | 32.058 | 32.252 | 3/10 |
| CommonJS graph | 27.813 | 28.309 | 3/10 |
| Recursive generics | 15.928 | 15.932 | 3/10 |

An earlier 26-round screen used source parent `aed1dad3b` / compiler
`929d46a67` and the pre-integration prototype, not these current binaries.
Its graph medians were 13.440 → 13.329 ms (13/20 faster pairs; saving interval
−0.585 to +0.487 ms), scale 1,292.996 → 1,293.756 ms (2/6; −27.656 to
+23.536 ms): also inconclusive. It stays separately labeled history, not a
patch comparison with the subsequent inheritance/config integration.

#### Verification and evidence

Final full standalone checker **4,501**, Program **238**, CLI **74**,
entrypoint **35** and driver **199** tests passed; harness **128/128**.
No named filters exclude tests. Zig formatting and diff checks pass.
Pinned unmodified Zod 4.5.2, all 106 production files, retains the exact
**195 TS errors + 3 HM9002** multiset against this parent: zero additions or
removals. Guarded observed footprints are 520 MiB parent / 501 MiB candidate,
not a universal memory claim or production admission. The older 196-error
snapshot is not the exact parent after unrelated inheritance integration.

The full pickier run exits 1 with **22,075 problems (11,462 errors / 10,613
warnings)**. One was a prose line beginning with a bare issue number in the
earlier report; that Markdown error is corrected. This is not a lint pass,
and unrelated files/generated controls are not auto-fixed. Three machine-lock
admission timeouts (exit 121, before command execution) remain alongside their
actual retries, not counted as passes. Native builds/tests/timings retain the
3,840 MiB tree ceiling, 600-second execution limit and 1,024/512 MiB disk floors.
The corrected README/performance-doc scope passes a targeted pickier check;
the full repository run remains failed as stated above.

The [raw evidence archive](https://github.com/home-lang/home/raw/main/bench/vs_tsgo/evidence/20261008-default-module-owners-845.tar.gz)
retains **296 pair rounds**, **224 passing admissions** across the earlier
screen and three current-parent phases, all initial/red/final oracle records
and fixture bytes, source patches, scripts, official/scale inputs, semantic
logs and complete Zod diagnostics. All **6,271 checksums** are verified; its
verifier recomputes every median, saving interval and win count, checks the
exact primary diagnostic identities and retains the explicit TS 6/7 dialect
differences. Archive SHA-256:
`4a77c9f4a49cd86c0e4e4097189041f6a8622073423f7479467e6ad0babccee0`.
Parent/candidate binary SHA-256:
`cd120ba9a36bf8d7326f26a4b231211a47250151f7ec819549f50031304f6df9` /
`7346fd7bbc264c20a9b32a0da08e8579e615e68795c961f4f91911e6b276063a`.

### Complete export-fact traversal and option diagnostics (2026-10-08 UTC)

Source [`929d46a67`](https://github.com/home-lang/home/commit/929d46a678c30e30970c80ba039ae1875b53d392)
contains the cycle-safe export-fact worklist in
[#843](https://github.com/home-lang/home/issues/843), plus the ambient enum
diagnostic/config fix in
[`4e8ee8637`](https://github.com/home-lang/home/commit/4e8ee86370e76899acf5218269b45685a9dc07a1)
([#844](https://github.com/home-lang/home/issues/844)). Its exact integrated
parent is `53167b7e5`. This is a correctness checkpoint and same-parent cost
experiment, **not a new five-compiler matrix or a demonstrated speedup**.
At that checkpoint the expanded matrix was `20261008T042639Z` below, with Home
leading 2/20 workloads. That matrix is now historical. The goal in #416 remains
incomplete.

The previous recursive fact evaluator stopped after eight layers. The new
request-local dependency worklist keys states by module path and export name,
retains immutable bound owners in the origin query, and wakes parents when
child facts change. It has no numeric depth cutoff or recursive native-stack
walk. Type-only restriction provenance comes from complete origin resolution,
not the order provisional dependency facts arrive. Star edges exclude the
language's default export; explicit named defaults are not excluded. This
does not remove every unrelated virtual-checker resolver limitation or change
the existing directory/index star-resolution policy.

The checker now distinguishes `verbatimModuleSyntax` errors at ambient const
enum value imports/re-exports from `isolatedModules` errors at actual value
accesses. Unused bindings are legal in isolated-only mode. The config driver
also forwards `verbatimModuleSyntax`, which it previously parsed but dropped.
No diagnostics were normalized away or suppressed to admit timings.

| Correctness control | Exact parent | Published candidate / TS oracle |
|---|---|---|
| Valid 8- and 32-layer named/star graphs; 32 includes a cycle | Incorrect TS2305 | Both accept, matching TS 6.0.3 |
| Isolated ambient enum through 1, 8 and 32 layers | Wrong bindings/re-exports; deeper graph also TS2305 | One TS2748 at actual `index.ts(2,31)`, exact message match |
| 24 cases: no flags / isolated / verbatim / both × unused, member, alias, element, namespace, type | Flag/location mismatches retained | All 24 match codes, counts, positions, messages and success/error exit classes |
| Repeated cyclic type restrictions and shared/conflicting diamond origins | New controls | Program checks stable provenance, shared declaration identity and ambiguity |
| Direct `export *` default fact | Failed new Program assertion | Correctly excluded; 237/237 Program tests pass |
| Real `.ts` default import from a star barrel | Silently accepted | **Still silently accepted**, unlike TS1192; failed CLI gate retained in [#845](https://github.com/home-lang/home/issues/845) |

The last row is a separate real-project checker coverage gap: its default
import check only queries `.mts`/`.mjs` targets. Correct Program facts alone
do not make that CLI path diagnose ordinary `.ts` imports. The failed final
oracle is **not counted among the 30 passing cases**, and neither #843 nor
[#844](https://github.com/home-lang/home/issues/844) is claimed to satisfy its entire broader acceptance scope. Those issues
and #845 remain open. The parent fails the new deep valid projects, so these
projects are not used for an A/B speed claim.

#### Exact integrated-parent cost measurements

Both frozen binaries use Zig `0.17.0-dev.2163+89ff10d56`, stripped ReleaseFast,
with `-Denable_jsc=false` for the independent standalone compiler target.
Host: Apple M3 Pro / Mac15,6, 11 logical cores, Darwin 27.0.0 arm64.
Each phase independently admits both compilers on all 20 unchanged official
workloads and their existing negative controls (**56 admissions per phase**).
The unchanged 4,096-module scale project must also exit zero without output.
Timings use three warmups, fresh processes, alternating reversed pair order,
and retain every raw sample. Binary/input/harness/tool/runner hashes match
before and after each phase. No deep failing-parent timing or cross-run
matrix difference is treated as a patch comparison.

Positive paired saving means the candidate is faster. The t intervals below
describe these paired observations; they do not establish equivalence or
universal performance. The >3%-slower family-median rule selects independent
30-pair rechecks; it is not a reason to discard the adverse screen.

| Phase / unchanged workload | Parent median | Candidate median | Faster pairs | Paired mean saving 95% t interval |
|---|---:|---:|---:|---:|
| Screen: official re-export graph | 14.354 ms | 14.125 ms | 10/20 | −2.664 to +1.720 ms |
| Independent confirmation: official graph | 13.802 ms | 14.197 ms | 11/30 | −1.061 to +0.137 ms |
| Screen: 4,096-module scale | 1,382.127 ms | 1,417.007 ms | 2/6 | −51.344 to +48.923 ms |
| Independent confirmation: scale | 1,384.203 ms | 1,405.088 ms | 5/10 | −122.538 to +21.693 ms |
| Large-predicate family warning | 267.503 ms | 275.705 ms | 2/10 | **−14.142 to −0.964 ms** |
| Independent large-predicate recheck | 280.212 ms | 281.744 ms | 12/30 | −5.666 to +1.767 ms |

Confirmation graph/scale medians are respectively **2.9% / 1.5% slower**;
their intervals include zero. The large-predicate screen is 3.1% slower with
an entirely negative saving interval; its recheck is 0.5% slower with an
interval spanning zero. Retain both: the warning is not proof of a permanent
regression, and the recheck is not proof of no regression. This correctness
change has **no demonstrated graph speedup** and is not a benchmark win.

All 20 family screens (10 pairs each) remain visible:

| Workload | Parent median (ms) | Candidate median (ms) | Faster pairs |
|---|---:|---:|---:|
| Startup | 3.296 | 3.114 | 10/10 |
| Many files | 23.526 | 23.258 | 7/10 |
| Deep types | 23.037 | 23.310 | 6/10 |
| Import graph | 22.723 | 23.284 | 3/10 |
| Re-export graph | 13.415 | 13.689 | 3/10 |
| TSX components | 21.840 | 21.599 | 8/10 |
| Generic calls | 24.753 | 24.663 | 6/10 |
| Control flow | 28.289 | 28.092 | 7/10 |
| Type predicates | 35.985 | 35.586 | 6/10 |
| Large type predicates | 267.503 | 275.705 | 2/10 |
| Null-safe access | 35.631 | 35.237 | 5/10 |
| Destructuring | 16.129 | 16.296 | 2/10 |
| Overloads | 26.381 | 26.346 | 6/10 |
| Class hierarchy | 25.782 | 25.671 | 7/10 |
| Structural objects | 25.248 | 24.875 | 6/10 |
| Interface composition | 37.537 | 37.783 | 4/10 |
| Variadic tuples | 34.410 | 34.828 | 3/10 |
| Checked JS / JSDoc | 32.471 | 32.923 | 3/10 |
| CommonJS graph | 28.697 | 28.734 | 6/10 |
| Recursive generics | 15.878 | 15.844 | 5/10 |

An earlier prototype against source parent `a444cf021` / compiler `30d3824da`
is also retained, not mixed into these integrated-source results. Its graph
confirmation was 13.531 → 13.629 ms (15/30 faster pairs; saving interval
−0.974 to +1.279 ms), and scale 1,330.791 → 1,329.527 ms (6/10; −43.390 to
+33.970 ms): inconclusive. Its startup warning was 3.269 → 3.662 ms (2/10;
−0.574 to +0.048 ms), followed by a selected independent recheck of
3.308 → 3.054 ms (30/30; +0.205 to +0.295 ms). Both earlier observations,
all 20 earlier family screens and their source/patch/binary identities remain
in the archive, without substituting a favorable result for another run.

#### Semantic, production and reproducibility evidence

Full integrated standalone suites passed: checker **4,493**, driver **199**,
Program **237**, CLI **74**, entrypoint **33**; no named test filters.
Program was rerun after the final default-star edge change. The final CLI
and entrypoint suites are rerun on the published source as well. Harness
tests: **128/128**. Zig formatting and `git diff --check` passed.
`bunx --bun pickier .` exits 1 with the unchanged repository-wide
**22,074 problems (11,461 errors / 10,613 warnings)**; this is not a lint pass
and unrelated/generated controls are not auto-fixed.

Pinned unmodified Zod 4.5.2, all 106 production files, retains the exact
**196 TS errors + 3 HM9002** multiset, zero additions/removals. The final
candidate's guarded observed footprint is 570 MiB; the parent 571 MiB.
Neither this ratchet nor identical diagnostics admit Zod for a speed claim.
Native builds/tests/timings kept the 3,840 MiB tree ceiling, 600-second execution
limit and 1,024/512 MiB disk floors. Disk-floor refusals, an early compilation
error, the red default-star test, a cancelled wrong build target, the missing
runtime dependency configure failure and the failed CLI oracle are retained
and are not counted as passing verification. The corrected standalone build
uses the same non-JSC option as its parent, not a semantic compiler shortcut.

The [raw evidence archive](https://github.com/home-lang/home/raw/main/bench/vs_tsgo/evidence/20261008-export-fact-worklist-843.tar.gz)
contains all earlier and final pair phases, admissions, fixture bytes and
hashes, official and scale inputs, source patch, commands/scripts, semantic
logs and complete Zod diagnostics: **592 pair-round files**, **448 passing
admissions** across eight independent old/final phases, and **6,206 verified
checksums**. Its verifier recomputes medians, intervals, win counts,
exact-message oracle matches and the explicitly failing default oracle.
Archive SHA-256:
`705bcf5818d80aaf4138ee9afc0efbe894af8049233dc2056a5f830ebf0e09cf`.

### Nested export-owner checkpoint (2026-10-08 UTC)

Result `20261008T042639Z` measures source
[`30d3824da`](https://github.com/home-lang/home/commit/30d3824da0cb58c943377418f8a6454f2ca2122e),
exact parent `eaaddf213` plus the retained nested-owner reuse patch. The parent
compiler inputs are byte-identical to `69c3d28ee`: only docs/evidence differ.
No upstream source landed during rebase. Build: Zig
`0.17.0-dev.2163+89ff10d56`, stripped ReleaseFast; harness `76d1016f4`.
Host: Apple M3 Pro / Mac15,6, 11 logical cores, Darwin 27.0.0 arm64. Tools:
Node 26.10.0, Hyperfine 1.20.0, Python 3.9.6. Compiler/payload pins remain in
the [Darwin ARM64 registry](https://github.com/home-lang/home/blob/main/bench/vs_tsgo/profiles/darwin-arm64.json).

All five compilers pass the same 20 positive and 8 negative-control projects:
**140/140 admissions**. Thirty fresh processes per compiler/workload after
three warmups, with rotating command order, retain **600 raw rounds / 3,000
samples**. Every observation is retained; executables, payloads, projects,
harness, and project context match before/after. Native TS 7 runs directly;
Bun uses its validated canonical check-only mode.

| Workload | tsc 6.0.3 median | native TS 7.0.2 median | Home median | Rust tsc-rs 0.1.0 median | Bun canary median | Home vs fastest competitor |
|---|---:|---:|---:|---:|---:|---:|
| `checkjs_jsdoc` | 451.1 ms | 55.2 ms | 47.3 ms | 44.7 ms | 29.8 ms | 1.59× slower |
| `class_hierarchy` | 416.6 ms | 47.3 ms | 45.2 ms | 36.8 ms | 31.5 ms | 1.44× slower |
| `commonjs_graph` | 292.1 ms | 36.7 ms | 46.8 ms | 31.2 ms | 24.7 ms | 1.89× slower |
| `control_flow` | 702.2 ms | 55.6 ms | 51.3 ms | 55.2 ms | 32.4 ms | 1.58× slower |
| `deep_types` | 237.1 ms | 43.7 ms | 30.3 ms | 28.3 ms | 26.7 ms | 1.14× slower |
| `destructuring` | 282.0 ms | 35.6 ms | 24.0 ms | 30.6 ms | 22.8 ms | 1.05× slower |
| `generic_calls` | 576.6 ms | 52.3 ms | 44.9 ms | 43.4 ms | 30.0 ms | 1.50× slower |
| `import_graph` | 240.7 ms | 27.6 ms | 36.4 ms | 21.0 ms | 37.7 ms | 1.73× slower |
| `interface_composition` | 457.8 ms | 70.9 ms | 59.5 ms | 48.5 ms | 36.8 ms | 1.62× slower |
| `many_files` | 392.4 ms | 40.3 ms | 34.7 ms | 28.9 ms | 22.3 ms | 1.56× slower |
| `null_safe_access` | 522.0 ms | 54.1 ms | 56.7 ms | 52.6 ms | 36.5 ms | 1.56× slower |
| `overload_resolution` | 465.9 ms | 69.2 ms | 41.4 ms | 48.2 ms | 43.4 ms | **1.05× faster** |
| `recursive_generics` | 299.8 ms | 66.6 ms | 23.5 ms | 51.8 ms | 20.7 ms | 1.13× slower |
| `reexport_graph` | 169.3 ms | 19.7 ms | 20.7 ms | 17.0 ms | 16.2 ms | 1.27× slower |
| `startup` | 94.5 ms | 14.8 ms | 6.4 ms | 12.6 ms | 12.5 ms | **1.97× faster** |
| `structural_objects` | 464.3 ms | 61.0 ms | 44.6 ms | 51.2 ms | 41.4 ms | 1.08× slower |
| `tsx_components` | 430.9 ms | 28.3 ms | 35.5 ms | 30.7 ms | 22.0 ms | 1.61× slower |
| `type_predicates` | 601.6 ms | 95.8 ms | 58.8 ms | 77.0 ms | 52.6 ms | 1.12× slower |
| `type_predicates_large` | 2826.6 ms | 647.0 ms | 529.1 ms | 639.2 ms | 359.4 ms | 1.47× slower |
| `variadic_tuples` | 555.3 ms | 88.9 ms | 54.1 ms | 63.2 ms | 40.5 ms | 1.34× slower |

Home has the lowest unrounded median on **2/20** workloads (`startup` and
`overload_resolution`) and beats direct native TS 7 on **15/20**. Bun leads
17; Rust leads imports. These counts and small margins are descriptive, not
statistical-significance claims or proof that this patch caused every change
from earlier runs. Host conditions and timing vary across runs; no earlier
number is merged here. Only the same-parent paired experiment below isolates
the source change. The guard's full-run host low-water mark is 26%.

The [matrix archive](https://github.com/home-lang/home/raw/main/bench/vs_tsgo/evidence/20261008T042639Z.tar.gz)
contains all 600 byte-identical rounds, 140 admissions, and **603 verified
payload checksums**. Only known private metadata/admission paths are
normalized. Archive SHA-256:
`ed253feb8650bcb68995ba7c21ad83c07c2ed6652fc4747a879c00f35c60c8fd`.
Home executable SHA-256:
`92338a9715ef01c3bf7e7238f980e9df72e856340f6684daabf98924ceea4960`.
Candidate build peak: 3,043 MiB; complete matrix: 409 MiB. Re-exports still
trail Bun by **1.27×**; #839 stays open. Other platforms, full production
admission and canonical C++ selection remain outstanding under
[#416](https://github.com/home-lang/home/issues/416),
[#548](https://github.com/home-lang/home/issues/548), and
[#838](https://github.com/home-lang/home/issues/838).

#### Nested-owner reuse acceptance and adverse observations (#839)

Named/star recursive fact requests now obtain immutable bound owners from the
existing origin query instead of reopening and binding each nested target.
CLI-shared and standalone request-local lifetimes retain their ownership
rules. Field propagation, target resolution, and traversal order are
unchanged. No library/compiler/benchmark-name handling, diagnostic
suppression, approximate types, or new cutoff is introduced. The inherited
eight-level fact cutoff is **not fixed or certified** by this optimization:
[#843](https://github.com/home-lang/home/issues/843) tracks complete cycle-safe
traversal without an arbitrary depth bound as outstanding correctness work.

Parent executable SHA-256:
`4b4af24fdb57dcfdba69de49a460014a1800cacdda7164a4fc8614e727e9ec2d`.
Both binaries share the same Zig/build flags. Each stage retains all **56
admissions**, runner/binary/input/harness/Hyperfine fingerprints, all samples,
three warmups and reversed pair order.

| Workload / stage | Pairs | Parent median | Candidate median | Candidate wins | Median improvement |
|---|---:|---:|---:|---:|---:|
| Official unchanged 64-leaf graph, initial screen | 20 | 25.467 ms | 20.504 ms | 20/20 | 1.242× |
| Official graph, independent confirmation | 30 | 25.546 ms | 20.730 ms | 25/30 | 1.232× |
| Same generator at 4,096 leaves, initial screen | 6 | 2.506 s | 2.000 s | 6/6 | 1.253× |
| Same generator at 4,096 leaves, independent confirmation | 10 | 2.888 s | 2.351 s | 10/10 | 1.228× |

Independent paired mean saving 95% t intervals: **+2.446 to +9.779 ms**
(official, 29 degrees of freedom), **+375.313 to +791.154 ms** (scale, 9
degrees of freedom). The secondary scale uses the same generator/eight leaves
per barrel; the official project is unchanged and not enlarged for a win.

The all-20-family 10-pair screen records an adverse overload result:
**34.391 → 42.957 ms**, 2/10 paired wins, saving interval **−9.375 to −0.516
ms**. Acceptance was held. Every family with a >3% slower screen median was
selected by the predefined rule for independent 30-pair confirmation:

| Workload | Parent median | Candidate median | Candidate wins | Paired mean saving 95% t interval |
|---|---:|---:|---:|---:|
| `deep_types` | 22.010 ms | 22.023 ms | 17/30 | −0.142 to +0.135 ms |
| `control_flow` | 26.806 ms | 26.813 ms | 16/30 | −0.078 to +0.233 ms |
| `overload_resolution` | 25.054 ms | 25.050 ms | 15/30 | −0.319 to +0.096 ms |
| `class_hierarchy` | 24.445 ms | 24.358 ms | 20/30 | −0.039 to +0.300 ms |
| `structural_objects` | 23.583 ms | 23.679 ms | 14/30 | −2.719 to +1.082 ms |
| `interface_composition` | 35.413 ms | 35.275 ms | 20/30 | −0.074 to +0.331 ms |
| `variadic_tuples` | 32.395 ms | 32.460 ms | 14/30 | −0.198 to +0.152 ms |
| `checkjs_jsdoc` | 30.673 ms | 30.649 ms | 16/30 | −0.220 to +0.185 ms |
| `commonjs_graph` | 26.798 ms | 26.983 ms | 11/30 | −0.819 to +0.026 ms |
| `recursive_generics` | 15.288 ms | 15.106 ms | 19/30 | −0.008 to +0.447 ms |

The overload warning and >3% median slowdowns do not reproduce in these
independent rechecks. CommonJS still has a **0.7% slower observed median**.
Overlapping intervals are not equivalence or proof of no regression; all
initial adverse samples and rechecks are retained, not selected away.

Full Program **231/231**, checker **4,483/4,483**, core CLI **74/74**,
entrypoint **33/33**, and harness **128/128** pass. The new full-record control
covers nested named/star edges, generic callable aliases, type-only
interfaces, ambient const enums, ordinary values and missing names after
source reads are denied. Program/core CLI/entrypoint peaks: 3,185 / 2,617 /
2,855 MiB. The exact unchanged checker test artifact executes from cache
(21 MiB); this is not a new checker compilation peak. Complete explicit
module/import graphs have native symbols stripped, without named filters or
source exclusions. Formatting, AST checks, and diff checks pass. Pickier
exits 1 with 22,082 findings (11,469 errors / 10,613 warnings), not a clean
lint pass; generated controls are not auto-fixed.

The pinned, unmodified 106-file Zod graph retains identical complete
**196 TS + 3 HM9002** diagnostic multisets, zero additions/removals. Guarded footprint
observations are **1,087 MiB parent / 936 MiB candidate**, not a universal
memory improvement or production admission claim. Guard ceilings/floors are
unchanged. Source/binary/runner/input/harness/tool hashes are verified stable.

The [paired archive](https://github.com/home-lang/home/raw/main/bench/vs_tsgo/evidence/20261008-nested-export-owners-839.tar.gz)
retains **566 byte-identical pair rounds**, every stage's admissions and
observations, complete scale inputs, exact source patch/scripts, semantic
logs, and normalized Zod identities, with **5,209 verified checksums**.
Its verifier recomputes every median, saving interval and win count. SHA-256:
`37199143215b6a03705bf3cba9975de232c43c8f4e0e9693ea0b8699a80e53bb`.

### Shared export-fact origins checkpoint (2026-10-08 UTC)

Result `20261008T031844Z` measures source
[`69c3d28ee`](https://github.com/home-lang/home/commit/69c3d28ee6469bf89816a45bba9290d919805085),
the exact frozen `3318885fb` parent plus the retained export-fact reuse patch.
No intervening upstream source landed during rebase. Home uses Zig
`0.17.0-dev.2163+89ff10d56`, stripped ReleaseFast; the benchmark harness is
`76d1016f4`. Host: Apple M3 Pro / Mac15,6, 11 logical cores, Darwin 27.0.0
arm64. Tools: Node 26.10.0, Hyperfine 1.20.0, Python 3.9.6. Compiler/payload
pins remain in the
[Darwin ARM64 registry](https://github.com/home-lang/home/blob/main/bench/vs_tsgo/profiles/darwin-arm64.json).

All five compilers pass the same 20 positive and 8 negative-control projects:
**140/140 admissions**. Thirty fresh processes per compiler/workload after
three warmups, with rotating command order, retain **600 raw rounds / 3,000
samples**. No failed or slow sample is removed. Executables, payloads,
projects, harness, and project context are unchanged before/after. Native TS
7 runs directly; Bun uses its validated canonical check-only command.

| Workload | tsc 6.0.3 median | native TS 7.0.2 median | Home median | Rust tsc-rs 0.1.0 median | Bun canary median | Home vs fastest competitor |
|---|---:|---:|---:|---:|---:|---:|
| `checkjs_jsdoc` | 475.2 ms | 39.4 ms | 47.4 ms | 35.7 ms | 21.6 ms | 2.20× slower |
| `class_hierarchy` | 205.2 ms | 23.5 ms | 25.6 ms | 20.2 ms | 15.0 ms | 1.71× slower |
| `commonjs_graph` | 320.2 ms | 31.4 ms | 53.4 ms | 29.3 ms | 22.7 ms | 2.35× slower |
| `control_flow` | 230.6 ms | 31.6 ms | 29.4 ms | 28.4 ms | 18.7 ms | 1.57× slower |
| `deep_types` | 154.2 ms | 24.1 ms | 23.6 ms | 16.7 ms | 15.3 ms | 1.54× slower |
| `destructuring` | 149.0 ms | 18.1 ms | 16.2 ms | 16.2 ms | 11.8 ms | 1.37× slower |
| `generic_calls` | 280.0 ms | 32.5 ms | 31.5 ms | 26.8 ms | 20.1 ms | 1.57× slower |
| `import_graph` | 141.6 ms | 16.9 ms | 22.5 ms | 12.7 ms | 16.9 ms | 1.77× slower |
| `interface_composition` | 248.8 ms | 37.6 ms | 39.5 ms | 28.8 ms | 21.4 ms | 1.85× slower |
| `many_files` | 226.4 ms | 24.9 ms | 24.2 ms | 18.4 ms | 15.0 ms | 1.61× slower |
| `null_safe_access` | 218.8 ms | 29.9 ms | 35.6 ms | 25.8 ms | 17.7 ms | 2.02× slower |
| `overload_resolution` | 233.3 ms | 37.9 ms | 27.2 ms | 30.7 ms | 22.9 ms | 1.19× slower |
| `recursive_generics` | 312.4 ms | 65.6 ms | 23.2 ms | 54.1 ms | 16.0 ms | 1.45× slower |
| `reexport_graph` | 107.1 ms | 12.2 ms | 19.4 ms | 10.2 ms | 9.8 ms | 1.99× slower |
| `startup` | 81.7 ms | 9.4 ms | 3.8 ms | 8.0 ms | 8.1 ms | **2.11× faster** |
| `structural_objects` | 275.8 ms | 35.1 ms | 29.4 ms | 29.6 ms | 21.0 ms | 1.40× slower |
| `tsx_components` | 202.7 ms | 18.8 ms | 23.3 ms | 17.2 ms | 12.5 ms | 1.86× slower |
| `type_predicates` | 273.1 ms | 46.4 ms | 36.1 ms | 38.1 ms | 25.7 ms | 1.41× slower |
| `type_predicates_large` | 1164.5 ms | 356.3 ms | 263.6 ms | 295.4 ms | 176.8 ms | 1.49× slower |
| `variadic_tuples` | 818.4 ms | 101.1 ms | 80.7 ms | 84.9 ms | 44.9 ms | 1.80× slower |

Home has the lowest unrounded median on **1/20** workloads and beats direct
native TS 7 on **12/20**. Bun leads 18; Rust leads `import_graph`; Home leads
`startup`. These are descriptive medians, not significance or universal-lead
claims. Numbers differ across earlier runs for multiple compilers; cross-run
changes are **not** attributed to this patch. Only same-parent paired results
below isolate its effect. Execution headroom fluctuated; the guard recorded a
25% host low-water mark, without relaxing resource/disk floors.

The [matrix archive](https://github.com/home-lang/home/raw/main/bench/vs_tsgo/evidence/20261008T031844Z.tar.gz)
has all 600 byte-identical rounds, 140 admissions, and **603 verified payload
checksums**. Known private paths are normalized only in metadata/admission.
Archive SHA-256:
`50ea6212fdf1de7b6884a83d298c3a654a023ad1712e877a53163e70107f90ce`.
Home executable SHA-256:
`4b4af24fdb57dcfdba69de49a460014a1800cacdda7164a4fc8614e727e9ec2d`.
Candidate build peak: 2,966 MiB; matching parent build: 2,918 MiB; complete
matrix: 401 MiB. Full Zod admission, other platforms, and canonical C++
selection remain outstanding under
[#548](https://github.com/home-lang/home/issues/548),
[#416](https://github.com/home-lang/home/issues/416), and
[#838](https://github.com/home-lang/home/issues/838).

#### Export-fact reuse acceptance and tradeoffs (#839)

Export-facts callbacks now use the existing mutex-guarded origin query and its
immutable bound owner/index data. A local export of an imported binding also
consumes the already completed same-name origin result, instead of repeating
that resolution. Fact traversal and recursive-target handling are unchanged;
there are no library, compiler, or benchmark-name checks, approximate types,
or diagnostic suppression. The new no-reread control compares every fact
field for generic callable aliases, import-type restrictions, type-only
namespace aliases, and missing names.

Exact parent: `3318885fb6a286e145c9d5d77a4373981e343dd3`; executable SHA-256:
`fae92032c458c63252118fc04455cfa3d1a32713b627f793253cd06e0fb11608`.
Both binaries use the same Zig/build flags. Every pair reverses command order;
all observations are retained after three warmups. Each stage retains all
**56 admissions** and unchanged binary/input/harness/Hyperfine fingerprints.

| Workload / stage | Pairs | Parent median | Candidate median | Candidate wins | Median improvement |
|---|---:|---:|---:|---:|---:|
| Official unchanged 64-leaf graph, initial screen | 20 | 25.451 ms | 19.136 ms | 20/20 | 1.330× |
| Official graph, independent confirmation | 30 | 32.665 ms | 24.885 ms | 25/30 | 1.313× |
| Same generator at 4,096 leaves, initial screen | 6 | 2.338 s | 1.606 s | 6/6 | 1.456× |
| Same generator at 4,096 leaves, independent confirmation | 10 | 2.503 s | 1.950 s | 9/10 | 1.283× |

Independent paired mean saving 95% t intervals: **+2.516 to +13.013 ms**
(official, 29 degrees of freedom) and **+255.781 to +710.265 ms** (scale,
9 degrees of freedom). The scale project uses the same eight leaves per
barrel and unchanged generator; it is diagnostic, not an enlarged official
row or a competitor-lead claim.

The all-20-family 10-pair screen has no saving interval wholly below zero,
but startup, many-files, and imports have medians over 3% slower. The explicit
screen rule therefore selects those three for independent 30-pair rechecks:

| Workload | Parent median | Candidate median | Candidate wins | Paired mean saving 95% t interval |
|---|---:|---:|---:|---:|
| `startup` | 3.221 ms | 3.243 ms | 9/30 | −0.323 to +0.007 ms |
| `many_files` | 24.954 ms | 24.846 ms | 15/30 | −3.674 to +0.716 ms |
| `import_graph` | 23.110 ms | 23.010 ms | 15/30 | −0.165 to +0.576 ms |

The >3% median slowdowns do not reproduce; startup still has a **0.7% slower
observed median**. Overlapping intervals are not equivalence or proof of no
regression. Both the unfavorable initial samples and rechecks are published.

Full Program **230/230**, checker **4,483/4,483**, CLI core **74/74**, CLI
entrypoint **33/33**, and harness **128/128** pass. Native test symbols are
stripped, with complete module/import graphs and no named-test filters or
source exclusions. Program/checker/core CLI/entrypoint peaks: 3,088 / 3,230 /
2,639 / 2,909 MiB. Formatting, AST checks, and `git diff --check` pass.
Pickier exits 1 with existing 22,074 findings (11,461 errors / 10,613 warnings),
not a clean lint pass; no generated control is auto-fixed.

Both pinned, unmodified 106-file Zod 4.5.2 checks retain identical complete
**196 TS + 3 HM9002** diagnostic identity multisets, zero additions/removals.
This is regression stability, not production admission. Observed guarded
footprint is **887 MiB parent / 991 MiB candidate**: retained metadata has an
explicit memory tradeoff, not an across-the-board resource improvement. The
guard conservatively over-counts shared pages. Resource ceilings/floors were
not raised or relaxed. Earlier disk refusals happened before compiler/test
execution and are not counted as passes.

The [paired archive](https://github.com/home-lang/home/raw/main/bench/vs_tsgo/evidence/20261008-export-fact-origins-839.tar.gz)
has **356 byte-identical raw pair rounds**, all admissions and observations,
full scale inputs, exact patch/scripts, semantic logs, normalized Zod identity
multisets, and **5,002 verified checksums**. Its summary recomputes every
median, paired saving interval, and win count. Archive SHA-256:
`6f7abd669e0c0ad3692e7f96117bf78c18f0883c05586bd4d2cf8f861d1ade3e`.
[#839](https://github.com/home-lang/home/issues/839) stays open: Home is still
**1.99× slower than Bun** on re-exports in the fresh matrix.

### Export-owner reuse checkpoint (2026-10-08 UTC)

Result `20261008T000856Z` measures the frozen export-owner reuse candidate:
parent `ef0174c05b9ca978ec5f5887c86bd4e8def670cd` plus the exact
`candidate-initial.patch` in the paired evidence below. The source change was
subsequently rebased and pushed as
[`b18f19203`](https://github.com/home-lang/home/commit/b18f192035260d2a9e6bd0324c32e952a0679a62).
Intervening compiler changes are **not** measured by this frozen result.
The harness is `76d1016f4`; Home is stripped ReleaseFast, built with Zig
`0.17.0-dev.2163+89ff10d56`. Host: Apple M3 Pro / Mac15,6, 11 logical cores,
Darwin 27.0.0 arm64. Tools: Node 26.10.0, Hyperfine 1.20.0, Python 3.9.6.
Compiler commands and complete payload pins are in the
[Darwin ARM64 registry](https://github.com/home-lang/home/blob/main/bench/vs_tsgo/profiles/darwin-arm64.json).

All five compilers pass the same 20 positive and 8 negative-control projects:
**140/140** admissions. Thirty fresh processes per compiler and workload,
after three warmups with rotating command order, retain **600 raw rounds /
3,000 samples**. Every sample is kept, including outliers. Executables,
payloads, projects, harness, and project context match before and after.
Native TS 7 is invoked directly; Bun's canonical check is check-only, with
its complete zero-error status line validated rather than discarded.

| Workload | tsc 6.0.3 median | native TS 7.0.2 median | Home median | Rust tsc-rs 0.1.0 median | Bun canary median | Home vs fastest competitor |
|---|---:|---:|---:|---:|---:|---:|
| `checkjs_jsdoc` | 194.1 ms | 22.6 ms | 28.9 ms | 21.6 ms | 13.4 ms | 2.16× slower |
| `class_hierarchy` | 178.0 ms | 20.4 ms | 22.6 ms | 16.9 ms | 13.2 ms | 1.71× slower |
| `commonjs_graph` | 146.4 ms | 17.7 ms | 24.5 ms | 14.2 ms | 11.8 ms | 2.08× slower |
| `control_flow` | 188.9 ms | 27.4 ms | 25.4 ms | 23.7 ms | 16.0 ms | 1.59× slower |
| `deep_types` | 130.8 ms | 21.6 ms | 21.1 ms | 14.2 ms | 13.3 ms | 1.59× slower |
| `destructuring` | 135.8 ms | 16.4 ms | 15.1 ms | 14.5 ms | 10.9 ms | 1.39× slower |
| `generic_calls` | 179.4 ms | 22.9 ms | 22.8 ms | 19.0 ms | 14.4 ms | 1.58× slower |
| `import_graph` | 129.5 ms | 15.2 ms | 20.4 ms | 11.2 ms | 14.9 ms | 1.82× slower |
| `interface_composition` | 196.7 ms | 30.5 ms | 33.5 ms | 23.1 ms | 17.4 ms | 1.93× slower |
| `many_files` | 200.2 ms | 24.1 ms | 22.0 ms | 17.6 ms | 13.5 ms | 1.62× slower |
| `null_safe_access` | 184.4 ms | 26.0 ms | 31.4 ms | 21.7 ms | 16.0 ms | 1.97× slower |
| `overload_resolution` | 193.9 ms | 32.0 ms | 23.1 ms | 25.7 ms | 19.9 ms | 1.16× slower |
| `recursive_generics` | 149.9 ms | 38.9 ms | 14.1 ms | 31.7 ms | 9.5 ms | 1.48× slower |
| `reexport_graph` | 96.6 ms | 10.6 ms | 16.5 ms | 9.0 ms | 8.5 ms | 1.94× slower |
| `startup` | 64.7 ms | 7.4 ms | 2.9 ms | 5.8 ms | 6.2 ms | **2.00× faster** |
| `structural_objects` | 178.8 ms | 25.8 ms | 22.0 ms | 21.4 ms | 16.3 ms | 1.35× slower |
| `tsx_components` | 164.0 ms | 16.3 ms | 20.2 ms | 14.3 ms | 10.4 ms | 1.94× slower |
| `type_predicates` | 228.3 ms | 39.4 ms | 32.0 ms | 32.9 ms | 22.8 ms | 1.40× slower |
| `type_predicates_large` | 968.6 ms | 294.2 ms | 234.6 ms | 259.3 ms | 155.1 ms | 1.51× slower |
| `variadic_tuples` | 238.2 ms | 43.5 ms | 30.3 ms | 32.3 ms | 18.9 ms | 1.61× slower |

Home has the lowest unrounded median on **1/20** workloads and beats direct
native TS 7 on **12/20**. Bun leads 18; Rust leads `import_graph`; Home leads
`startup`. These are descriptive medians, not significance claims or a
universal lead. Full Zod production admission, additional platforms, and C++
repository selection remain outstanding under
[#548](https://github.com/home-lang/home/issues/548),
[#416](https://github.com/home-lang/home/issues/416), and
[#838](https://github.com/home-lang/home/issues/838).

The [matrix evidence archive](https://github.com/home-lang/home/raw/main/bench/vs_tsgo/evidence/20261008T000856Z.tar.gz)
has 600 byte-identical raw rounds, 140 admissions, and **603 verified payload
checksums**. Only known private path prefixes in metadata/admission are
normalized. Archive SHA-256:
`20d645283831bd360212267cbc27be7c54590c83fda2e9a02b6af6316d1e6672`.
Home executable SHA-256:
`2972a61a93d99b04844db10e4c018caddf581cf0fc9f928251e129ffd950e6e1`.
Candidate build peak: 2,984 MB; complete matrix peak: 390 MB.

#### Same-parent optimization acceptance (#839)

The CLI's export-name callback previously reread and rebound each module in
every traversal while holding the shared resolver mutex. It now obtains
immutable bound owners from its existing `export_origins.Query`. Full
per-enumeration traversal, cycle handling, owned results, default exclusion,
quoted aliases, namespace aliases, and type-only exports are unchanged.
There are no compiler/library/benchmark-name checks or approximate types.

Both frozen binaries use the same Zig, ReleaseFast, strip flags, and parent.
Parent executable SHA-256:
`c510235a37f9012bb7ebb62728e873bc22d927d04c4e81c8d81fcae3400eac9c`.
Every pair reverses order relative to the previous pair; three warmups and all
samples are retained. Independent confirmation fingerprints every input file
and both executables before and after; all fingerprints match.

| Workload / stage | Pairs | Parent median | Candidate median | Candidate wins | Median improvement |
|---|---:|---:|---:|---:|---:|
| Official 64 leaves / 8 per barrel, initial screen | 20 | 21.566 ms | 17.993 ms | 19/20 | 1.199× |
| Official unchanged graph, independent confirmation | 30 | 20.178 ms | 17.430 ms | 27/30 | 1.158× |
| Same generator at 4,096 leaves, initial screen | 6 | 1.715 s | 1.534 s | 6/6 | 1.118× |
| Same generator at 4,096 leaves, independent confirmation | 10 | 1.701 s | 1.538 s | 10/10 | 1.106× |

Confirmation paired mean savings have two-sided 95% t intervals of
**1.565–3.403 ms** (official, 29 degrees of freedom) and
**131.280–226.124 ms** (scale, 9 degrees of freedom). The secondary scale
project is diagnostic, not an enlarged official row or competitor lead claim.
The 10-pair screen across all 20 families detects no regression whose paired
mean saving interval is wholly below zero; this is **not** statistical
equivalence. Cross-run matrix changes are not attributed to this patch.

Full Program **228/228**, checker **4,473/4,473**, CLI **74/74**, and harness
**128/128** pass. The new no-reread test preserves the complete cyclic,
quoted-name, namespace, type-only, and default-filtered surface after source
reads are denied. Both binaries pass all 20 positive and 8 negative controls.
On the byte-pinned, unmodified 106-file Zod 4.5.2 graph, both retain exactly
**196 TS diagnostics + 3 HM9002**, with identical complete diagnostic identity
multisets: zero additions/removals. This is regression evidence, not Zod
admission. Parent/candidate Zod peaks: 943/936 MB.

Unstripped test builds exceeded the unchanged 3,840 MB footprint cap before
execution. Complete ReleaseFast module suites were retried with native symbol
emission stripped, without test-name filters or source exclusions. Program,
checker, and CLI peaks: 3,159 / 3,263 / 2,735 MB. Resource and disk floors
were not raised or relaxed. Zig formatting and `git diff --check` pass;
Pickier reports existing repository debt: 22,074 findings (11,461 errors,
10,613 warnings), not a clean lint pass.

The [paired evidence archive](https://github.com/home-lang/home/raw/main/bench/vs_tsgo/evidence/20261008-export-owner-reuse-839.tar.gz)
retains all 266 raw pair rounds, exact patch, scripts, source/semantic logs,
Zod diagnostics, and complete scale inputs, with **4,902 verified checksums**.
Its recomputed summary includes every pair and normalized diagnostic identity.
Archive SHA-256:
`2c59c9f4781daae166031d43af2ece2d17e9180083e4b6a15eace89b9d37bd9a`.
[#839](https://github.com/home-lang/home/issues/839) remains open: export-owner
reuse improves Home, but does not close the measured competitor gap.

### Earlier expanded native-compiler measurement (2026-10-07)

Result `20261007T214816Z` uses harness commit `76d1016f4` and a stripped
ReleaseFast Home build from `9d27218fc`. It measures five compilers on one
Apple M3 Pro / Mac15,6 with 11 logical cores, Darwin 27.0.0 arm64. Node is
26.10.0, Hyperfine 1.20.0, and Python 3.9.6. TypeScript 7 runs as its native
payload directly; Rust and Bun use the exact source, executable, and complete
payload pins in the [Darwin ARM64 registry](https://github.com/home-lang/home/blob/main/bench/vs_tsgo/profiles/darwin-arm64.json).

All five compilers pass the same 20 positive projects and 8 existing negative
control projects each: **140/140** process admissions. The retained records
include every command, exit, stdout, stderr, actual code, and expected code.
Bun's single zero-error status line is parsed explicitly; diagnostics and
unknown output are never discarded. A valid top-level throw separately
confirmed that its canonical project check does not execute source.

The complete run retains 30 fresh processes per compiler and workload after
three warmups, with command order rotating each round: **600 raw round files
and 3,000 successful samples**. Executables, payload inventories, generated
projects, harness code, and project context are unchanged before admission
and after measurement. No failed or slow sample was removed or rerun.

| Workload | tsc 6.0.3 median | native TS 7.0.2 median | Home median | Rust tsc-rs 0.1.0 median | Bun canary median | Home vs fastest competitor |
|---|---:|---:|---:|---:|---:|---:|
| `checkjs_jsdoc` | 195.9 ms | 22.4 ms | 29.4 ms | 21.9 ms | 13.5 ms | 2.17× slower |
| `class_hierarchy` | 178.8 ms | 20.5 ms | 22.8 ms | 17.1 ms | 13.3 ms | 1.71× slower |
| `commonjs_graph` | 146.0 ms | 17.5 ms | 24.2 ms | 14.0 ms | 11.8 ms | 2.05× slower |
| `control_flow` | 186.8 ms | 26.9 ms | 25.6 ms | 23.8 ms | 16.3 ms | 1.57× slower |
| `deep_types` | 132.7 ms | 21.7 ms | 21.6 ms | 14.2 ms | 13.5 ms | 1.61× slower |
| `destructuring` | 134.0 ms | 16.2 ms | 14.7 ms | 14.2 ms | 10.7 ms | 1.38× slower |
| `generic_calls` | 178.5 ms | 23.0 ms | 23.2 ms | 19.2 ms | 14.6 ms | 1.58× slower |
| `import_graph` | 129.9 ms | 15.0 ms | 20.3 ms | 11.2 ms | 14.8 ms | 1.82× slower |
| `interface_composition` | 198.0 ms | 31.0 ms | 33.9 ms | 23.2 ms | 17.5 ms | 1.94× slower |
| `many_files` | 198.2 ms | 22.7 ms | 21.8 ms | 16.0 ms | 13.2 ms | 1.66× slower |
| `null_safe_access` | 189.0 ms | 26.2 ms | 32.3 ms | 22.5 ms | 16.3 ms | 1.98× slower |
| `overload_resolution` | 199.1 ms | 32.6 ms | 23.7 ms | 26.5 ms | 20.2 ms | 1.17× slower |
| `recursive_generics` | 150.2 ms | 39.4 ms | 14.3 ms | 32.3 ms | 9.7 ms | 1.48× slower |
| `reexport_graph` | 97.7 ms | 10.5 ms | 19.3 ms | 8.9 ms | 8.6 ms | 2.24× slower |
| `startup` | 64.9 ms | 7.5 ms | **2.9 ms** | 5.8 ms | 6.3 ms | **1.96× faster** |
| `structural_objects` | 178.7 ms | 25.9 ms | 22.0 ms | 21.6 ms | 16.4 ms | 1.34× slower |
| `tsx_components` | 164.9 ms | 16.2 ms | 20.5 ms | 14.4 ms | 10.6 ms | 1.93× slower |
| `type_predicates` | 227.0 ms | 38.9 ms | 31.9 ms | 32.9 ms | 22.9 ms | 1.39× slower |
| `type_predicates_large` | 1006.0 ms | 305.0 ms | 240.1 ms | 267.6 ms | 159.8 ms | 1.50× slower |
| `variadic_tuples` | 244.7 ms | 44.8 ms | 31.0 ms | 33.2 ms | 19.1 ms | 1.62× slower |

Home has the lowest median on **1/20** workloads and is faster than the direct
native TypeScript 7 command on **11/20**. Bun is fastest on 18 workloads and
Rust on `import_graph`; Home leads `startup`. These counts use unrounded
medians from every retained sample. Ratios rounded to 1.00× are near ties,
not directional or statistical-significance claims.

The [evidence archive](https://github.com/home-lang/home/raw/main/bench/vs_tsgo/evidence/20261007T214816Z.tar.gz)
contains all 600 byte-identical Hyperfine round files, 140 retained admission
records, metadata, and 603 verified payload checksums. Published metadata and
admission normalize only known private path prefixes. Archive SHA-256:
`90d1b8094cc95fe8ab98195f96a8e6d93fe4777003146f28c8124cc49aa4aefc`.
Home executable SHA-256:
`e3dc03289ef1e34b2273b9b26951f43bad8940614d032f3e40aceaf461600ab3`.
The guarded build peaked at 3,027 MB; the full measurement run at 385 MB.

This is the earlier expanded baseline under
[#838](https://github.com/home-lang/home/issues/838), not a universal lead.
The C++ repository selection remains outstanding. Older measurements used
different hosts, competitor sets, and TypeScript 7 launchers; their numerical
differences are not regression evidence. The largest measured relative gap
is the unchanged re-export graph, tracked for profiling and improvement in
[#839](https://github.com/home-lang/home/issues/839).

### Earlier three-compiler measurement (2026-10-07)

Result `20261007T183321Z` measures source commit `5f90572c7` with the stripped
ReleaseFast build. The host was an Apple M2 Pro / Mac14,9 with 10 logical
cores, running macOS 26.3.1 (Darwin 25.3.0) arm64. The harness admitted all 20
unchanged generated projects before timing, ran 30 fresh processes per
compiler after three warmups in rotating order, retained all 600 round files /
1,800 successful samples, and verified every compiler and measurement-tool
hash before admission and after measurement.

| Workload | tsc 6.0.3 median | native TS 7.0.2 median | Home 0.1.0 median | Home vs fastest competitor |
|---|---:|---:|---:|---:|
| `checkjs_jsdoc` | 261.3 ms | 68.5 ms | **37.8 ms** | **1.81× faster** |
| `class_hierarchy` | 235.7 ms | 64.5 ms | **29.4 ms** | **2.20× faster** |
| `commonjs_graph` | 207.9 ms | 63.1 ms | **37.7 ms** | **1.67× faster** |
| `control_flow` | 235.9 ms | 73.2 ms | **31.9 ms** | **2.30× faster** |
| `deep_types` | 157.1 ms | 64.6 ms | **25.7 ms** | **2.52× faster** |
| `destructuring` | 169.4 ms | 58.2 ms | **18.6 ms** | **3.13× faster** |
| `generic_calls` | 213.9 ms | 67.1 ms | **28.3 ms** | **2.37× faster** |
| `import_graph` | 156.9 ms | 57.1 ms | **30.9 ms** | **1.85× faster** |
| `interface_composition` | 246.3 ms | 78.5 ms | **42.6 ms** | **1.84× faster** |
| `many_files` | 253.8 ms | 66.7 ms | **33.0 ms** | **2.02× faster** |
| `null_safe_access` | 233.3 ms | 70.1 ms | **38.0 ms** | **1.84× faster** |
| `overload_resolution` | 253.2 ms | 79.5 ms | **30.3 ms** | **2.62× faster** |
| `recursive_generics` | 358.1 ms | 114.1 ms | **33.7 ms** | **3.39× faster** |
| `reexport_graph` | 118.1 ms | 52.0 ms | **24.5 ms** | **2.13× faster** |
| `startup` | 78.0 ms | 47.4 ms | **3.8 ms** | **12.62× faster** |
| `structural_objects` | 232.1 ms | 71.5 ms | **28.4 ms** | **2.52× faster** |
| `tsx_components` | 197.1 ms | 58.6 ms | **24.3 ms** | **2.41× faster** |
| `type_predicates` | 293.9 ms | 88.1 ms | **40.6 ms** | **2.17× faster** |
| `type_predicates_large` | 1,229.8 ms | 419.7 ms | **308.3 ms** | **1.36× faster** |
| `variadic_tuples` | 360.1 ms | 95.1 ms | **40.8 ms** | **2.33× faster** |

Home had the lowest median on **20/20** admitted workloads in this earlier
three-compiler run, which used the TypeScript 7 npm launcher. It is retained
as historical measurement, not a universal performance claim. The large-predicate scaling
regression tracked in [#837](https://github.com/home-lang/home/issues/837) was
fixed by the lazy forward-overload root index. Older snapshots were measured
from older compiler sources and are not used as current claims.

The [evidence archive](https://github.com/home-lang/home/raw/main/bench/vs_tsgo/evidence/20261007T183321Z.tar.gz)
contains all 600 byte-for-byte Hyperfine round files, metadata with repository
paths normalized to `$REPO`, and SHA-256 checksums. Archive SHA-256:
`de0068831ee0d037b9c103232d7b3eeb51e140c984f8d6be54b866dd355e1cfe`.
The measured `home-tsc` executable SHA-256 is
`2423c443af320c1334a0ad19264ef7d6a9ad7d0a323846baedaf3bb6dc4ae77c`.
Node was 24.4.1, Hyperfine 1.20.0, and Python 3.12.4. The guarded build peaked
at 2,902 MB tree footprint; benchmark execution peaked at 460 MB.

All values above are medians of every retained sample. Ratios use unrounded
medians and the faster of `tsc` and native TS 7. Schema-3 admission still
requires normal diagnostic exits and exact negative-control code multisets;
a crash after printing diagnostics does not qualify. No failed or slow sample
was removed or rerun.

### Historical optimization journal

The sections below retain dated A/B investigations, including rejected ideas.
They describe the source revisions named in each section and must not be read
as the current full-suite result above.

### Whole CommonJS path indexes (rejected, 2026-10-08 UTC)

Issue [#848](https://github.com/home-lang/home/issues/848) investigated a
general repeated cost in `programCommonJsModuleHasWholeExport`: each query
scanned all whole-export records and repeatedly compared extensionless
module paths. Current stack samples on same-generator CommonJS 1,024-family
and re-export 4,096-leaf projects are retained. A diagnostic-only image was
relinked from the exact cached ReleaseFast object with temporary local symbols
renamed; the machine-code section is byte-identical. It passed all 56
frozen/diagnostic admission records and was never used for accepted timings.

Two candidates indexed canonical whole-export paths, preserving external OR
fallback resolution, duplicates, misses, metadata replacement, and
importer/resolver invalidation. The first stored an inline hash table/built
flag; the second allocated a lazy index behind a nullable pointer. Neither
stored foreign TypeIds, changed diagnostics, imposed a limit, or recognized
benchmark/declaration names. **Both were rejected**: positive CommonJS
confirmation coexisted with independently adverse large-predicate results.
The cause of the unrelated-family cost is unproven; pointer storage did not
clear it, and it is not dismissed as noise or declared harmless.

Every A/B below uses source parent `3698c7a06` / byte-identical compiler
`206cdf1aa`, pinned Zig `0.17.0-dev.2163+89ff10d56`, stripped ReleaseFast and
the same guard limits. Host: Apple M3 Pro / Mac15,6, 11 logical cores,
Darwin 27.0.0 arm64. Each phase independently passed 56 admissions on the
20 unchanged official workloads and existing negatives. The scale used the
unchanged CommonJS generator, 1,024 families, on both sides. Three warmups,
fresh processes, reversed alternating pair order, all samples and stable
before/after binary/input/harness/tool/runner hashes are retained.

Positive paired saving means faster candidate; the intervals are
exploratory observations, not universal significance/equivalence claims.

| Variant / independent gate | Parent median | Candidate median | Faster pairs | Paired mean saving 95% t interval |
|---|---:|---:|---:|---:|
| Inline: official CommonJS confirmation | 29.823 ms | 28.327 ms | 26/30 | +0.218 to +1.856 ms |
| Inline: CommonJS scale confirmation | 449.598 ms | 373.946 ms | 10/10 | +65.470 to +86.664 ms |
| Inline: large-predicate screen | 273.002 ms | 281.876 ms | 2/10 | −22.018 to −3.402 ms |
| Inline: independent large-predicate recheck | 266.922 ms | 270.431 ms | 8/30 | **−6.510 to −0.496 ms** |
| Lazy pointer: official CommonJS confirmation | 30.088 ms | 28.531 ms | 29/30 | +0.699 to +2.262 ms |
| Lazy pointer: scale confirmation | 453.839 ms | 379.511 ms | 10/10 | +59.207 to +81.697 ms |
| Lazy pointer: large-predicate screen | 282.829 ms | 282.717 ms | 4/10 | −6.272 to +6.557 ms |
| Lazy pointer: carried-forward independent predicate recheck | 279.147 ms | 283.733 ms | 9/30 | **−6.528 to −1.070 ms** |

CommonJS confirmation medians improve about **5.3% / 5.2%**; large-predicate
recheck medians worsen **1.3% / 1.6%**, with entirely negative saving
intervals. The inline official screen had an interval crossing zero, despite
a 3.7% lower median; it remains in the archive. The predeclared >3%-slower
family-median rule selected startup/predicates for inline, and
startup/re-exports/generic calls for lazy storage. The prior independently
adverse predicate family was additionally carried forward before the lazy
recheck: absence from its screen threshold did not establish clearance.

| Other independent recheck | Parent median | Candidate median | Faster pairs | Saving interval |
|---|---:|---:|---:|---:|
| Inline startup | 3.168 ms | 3.169 ms | 17/30 | −0.201 to +0.137 ms |
| Lazy startup | 3.500 ms | 3.244 ms | 20/30 | −0.077 to +0.330 ms |
| Lazy re-exports | 13.867 ms | 13.985 ms | 17/30 | −0.874 to +0.581 ms |
| Lazy generic calls | 26.447 ms | 26.400 ms | 15/30 | −1.095 to +0.839 ms |

These zero-spanning intervals do not prove equivalence. All 20 family screens
for each candidate remain in raw evidence; no favorable phase substitutes
for another variant/run. Candidate full checker 4,503, Program 238 and
entrypoint 35 tests passed as applicable; each candidate retained the complete
pinned 195 TS + 3 HM9002 Zod multiset, zero changes, not production admission.
The compiler implementation was restored. The restored native image is
byte-identical to the frozen parent (`7346fd7b…`); only the two general
path-matching/reset tests were kept in
[`773ca888f`](https://github.com/home-lang/home/commit/773ca888fe4940965c0556cc4ac6bdc9fe6bc69f),
after unrelated upstream integration. These equivalence/measurements refer
to the original experiment source, not that later runtime tree.

The complete inline-prototype five-compiler run `20261008T140417Z` is retained
as **unaccepted evidence**, not the current snapshot or a successful compiler
change. It passes 140 admissions and preserves 600 rounds / 3,000 samples,
all five pinned versions and unchanged provenance. Home leads only **1/20**
(startup); CommonJS is 28.2 ms versus Bun's 13.4 ms, **2.10× slower**. The
current accepted snapshot above is not replaced with this rejected variant.
Its [matrix archive](https://github.com/home-lang/home/raw/main/bench/vs_tsgo/evidence/20261008T140417Z-rejected-848.tar.gz)
has 603 verified payload checksums; SHA-256:
`6052b7d07edbdfbe7e2356a74b4803486e0aaa55a5d02890d0360f3030feea74`.

The [paired/profile archive](https://github.com/home-lang/home/raw/main/bench/vs_tsgo/evidence/20261008-whole-commonjs-paths-rejected-848.tar.gz)
records all 686 pair rounds, seven independent
phases (392 admissions), the separate 56 profile admissions, both rejected
patches and frozen binary hashes, retained/restored test logs, full Zod output,
all official/scale inputs, scripts and raw samples. Archive provenance is
covered by **7,031 verified checksums**. SHA-256:
`a54ace54f9e3a5f991cc04149e082cd4e4e8948c72e76589002aac0740b96e73`.
Its verifier recomputes medians, intervals and win counts and verifies the
separate matrix, both negative predicate intervals, and diagnostic-image
code/admission equivalence. Parent, inline and lazy binary SHA-256:
`7346fd7bbc264c20a9b32a0da08e8579e615e68795c961f4f91911e6b276063a`,
`cb451c6a896264aaabc10d601bf69fd31940b339bd468b4e65c9f038d6db22cc`,
`0ffab1f3a47c2c09a1f6d0abce75304895131bb47aa55e3d4f34a1cc3de3b6d6`.
At that checkpoint, issue [#848](https://github.com/home-lang/home/issues/848)
remained open for a design that could recover the general CommonJS gain without
the observed tradeoff; the full benchmark-leadership goal was not achieved.

### Program-owned canonical CommonJS export table (accepted, 2026-10-08 UTC)

Commit
[`3c397539e`](https://github.com/home-lang/home/commit/3c397539e0ae54fd5c018b553a7cc7162ab0b74a)
resolves the repeated whole-export scan without either rejected candidate's
per-checker state. `Program` stamps each collected record with its original
position, stably sorts the owned table once by extension-normalized module
path, and lends that slice to every checker. Named-export, whole-export,
whole-export-type, and private-name queries binary-search the matching range.
The original position remains the metadata tiebreaker when external and
relative-fallback resolutions name different recorded modules, so the index
does not change first-match behavior. There is no new limit, benchmark-name
recognition, foreign `TypeId`, or per-source checker allocation.

The exact compiler-tree parent was `774f72f160b9`; the later final commit parent
`6f753d20f` added only #842 documentation/evidence and had a byte-identical
compiler, harness, and corpus tree. Parent and candidate were built in the
same checkout with pinned Zig, stripped ReleaseFast, identical caches and
flags. Their SHA-256 values are respectively
`849072fb4e7b03ed1e95d1d018f2932afde06ddefe3dbbdf1b6096694fb733cc`
and
`c7990a621cf0695478059068c8e2dcc5754d7338086abf4b6d6a3e24f88fa477`.
Every phase used three warmups, fresh processes, alternating pair order, and
all observations without filtering.

Before timing, both binaries passed the unchanged 56 official admissions plus
four 1,024-family positive/negative admissions. The scale negatives produced
exactly three TS2322 and three TS2339 diagnostics on each binary. The complete
20-family screen used ten pairs per workload. It selected `deep_types` under
the predeclared candidate-median-greater-than-103%-of-parent rule; the prior
rejected designs' `type_predicates_large` risk was carried forward whether or
not the screen selected it. Both then received independent 30-pair rechecks.

| Exact-parent phase | Parent median | Candidate median | Faster pairs | Paired mean saving 95% t interval |
|---|---:|---:|---:|---:|
| Official `commonjs_graph` confirmation | 34.325 ms | **33.478 ms** | 25/30 | **+0.429 to +1.255 ms** |
| Scale 1,024, first retained phase | 573.819 ms | 486.144 ms | 7/10 | −173.289 to +125.179 ms |
| Scale 1,024, independent follow-up | 563.116 ms | **473.763 ms** | 30/30 | **+79.260 to +93.304 ms** |
| `deep_types` independent recheck | 25.462 ms | 25.678 ms | 14/30 | −0.390 to +0.227 ms |
| `type_predicates_large` independent recheck | 306.698 ms | 310.473 ms | 12/30 | −12.206 to +3.980 ms |

The first scale phase is not discarded: two candidate observations above
950 ms make its paired mean and interval inconclusive despite the lower
median. That outcome triggered an explicitly labeled independent 30-pair
follow-up, which is retained alongside it and won all 30 pairs. The official
graph confirmation and scale follow-up have wholly positive saving intervals;
both independent regression rechecks span zero. Every other screen family
also has a zero-spanning interval. These are observed exact-parent results,
not universal equivalence or benchmark-leadership claims.

Correctness on the final source passed checker **4,509/4,509**, Program
**242/242**, driver **200/200**, CLI **74/74**, and `tsc_main` **35/35**. The
byte-pinned Zod 4.5.2 gate covered 106 production files: parent and candidate
both emitted the identical normalized **195 TS + 3 HM9002** multiset and the
same normalized SHA-256
`b605370cd3f75e876e7cf9710c6105296e4993e3a0de75a32d43ef7da56e4e5c`.
The largest guarded tree footprint was 3,097 MB under the 3,840 MB ceiling.

The expanded compiler matrix was attempted but not admitted. The exact
tsc-rs 0.1.0 archive matched its checked-in SHA-256; the moving Bun canary
download no longer matched the required `bd599f5af` archive pin, so no
substitute binary and no matrix samples were accepted. At that checkpoint the
previous accepted five-compiler snapshot therefore remained current. Bun check, tsc-rs, native
TS 7/tsgo, TypeScript 6, and the active C++ TypeScript port remain required
for the next fully pinned matrix under
[#838](https://github.com/home-lang/home/issues/838).

The [raw evidence archive](https://github.com/home-lang/home/raw/main/bench/vs_tsgo/evidence/20261008T165919Z-commonjs-sorted-table-848.tar.gz)
contains 330 original paired rounds plus the 30-pair scale follow-up, all 64
admission records, exact runners and fingerprints, full test/build/Zod logs,
the source patch, and 385 payload checksums. Archive SHA-256:
`ee3d55e06172a84f34f7a5264ccd3ba0d6a6a509b3d04f15bf13f121b2a5f68f`.

### Grouped require-binding candidates (accepted, 2026-10-08 UTC)

Issue [#849](https://github.com/home-lang/home/issues/849), under the broader
checker-performance tracker
[#416](https://github.com/home-lang/home/issues/416), addressed another
repeated source-root scan. `requireSpecifierForLocal` previously walked every
top-level statement each time it resolved a local CommonJS binding. The
accepted implementation extends the existing declaration index with a flat
arena of statically classifiable `require` and import-equals candidates plus a
per-local-name linked bucket. A query now visits only candidates for the
requested name.

The exact statement classifier is shared by the indexed and retained scanner
paths. Candidate order, anchor position, same-virtual-section precedence,
cross-section agreement and conflict behavior, exported declarations, and
import-equals bindings remain unchanged. Dynamic `require` arguments,
member-call lookalikes, and nested-root declarations are excluded exactly as
before. Index construction is lazy, source replacement releases the added
state through the existing owner, and every allocation failure abandons the
partial index and executes the complete scanner instead of returning a partial
answer.

The exact source parent was
`5976d10d3697fb95eff4b633b8f047a4182d351e`. Parent and candidate used pinned
Zig `0.17.0-dev.2163+89ff10d56`, identical stripped ReleaseFast flags and the
same command/module graph. Their SHA-256 values are respectively
`7dee4d66ec679603abe30bc6e324f4545f9f6401b0c4d908272d8e1d95e54e96`
and
`1e512778b479e7c30c92ffb0d81d501457c2bffa9e952914dcc7e7528be76a5c`;
both are 11,070,072 bytes. The supported repository build command was
`zig build home-tsc -Doptimize=ReleaseFast -Dhome-tsc-strip=true -j1`. Its
whole-file hash differs because of Mach-O metadata, while every file-backed
Mach-O section, including `__TEXT,__text`, matches the direct candidate.

Before timing, the runner admitted all 60 official and 1,024-family records.
The independent 1,024- and 4,096-family phases each passed four more positive
and negative admissions. Every phase used three warmups, fresh processes,
alternating pair order, and all observations without filtering. The scale
projects were generated by the repository's existing deterministic CommonJS
generator; the 4,096-family inventory contains 4,098 files and 20,480 index
lines.

| Exact-parent phase | Parent median | Candidate median | Faster pairs | Paired mean saving 95% t interval |
|---|---:|---:|---:|---:|
| Official `commonjs_graph` confirmation | 40.968 ms | 40.719 ms | 15/30 | −1.995 to +1.931 ms |
| Scale 1,024, first retained phase | 571.899 ms | 483.082 ms | 8/10 | −15.347 to +121.432 ms |
| Scale 1,024, independent follow-up | 529.868 ms | 519.387 ms | 19/30 | −16.975 to +30.202 ms |
| Scale 4,096, independent confirmation | 6,103.936 ms | **5,980.145 ms** | 22/30 | **+23.185 to +209.313 ms** |

The official and both 1,024-family intervals span zero and are therefore
retained as inconclusive, not promoted as wins. The independent 4,096-family
confirmation has a wholly positive interval: its paired mean saving is
**116.249 ms**, with 22 of 30 lower candidate observations. This is a measured
large-project result, not a universal performance or benchmark-leadership
claim.

The 20-family screen triggered or carried forward independent 30-pair rechecks
for `control_flow`, `type_predicates_large`, `destructuring`,
`overload_resolution`, `class_hierarchy`, `variadic_tuples`, and
`checkjs_jsdoc`. Every recheck interval spans zero; none establishes a
regression or equivalence. Correctness on the exact benchmark candidate passed
checker **4,511/4,511**, Program **242/242**, driver **200/200**, CLI
**74/74**, and `tsc_main` **35/35**. After a clean rebase onto the concurrent
relation work in [#842](https://github.com/home-lang/home/issues/842), the
integrated checker passed **4,521/4,521**. A
byte-pinned Zod 4.5.2 gate covered 106 production
files: parent and candidate both emitted the same normalized **195 TS + 3
HM9002** diagnostics, with normalized SHA-256
`e2085bca2f31e7abd290405136f1083a0e872e1adbf626cd9cea3297c981d756`.

All work stayed under the 3,840 MB guard. Unstripped ReleaseFast attempts were
stopped at the ceiling rather than granted more memory; the supported stripped
build peaked at 3,044 MB, the exact parent/candidate builds at no more than
3,116 MB, tests at no more than 2,320 MB, paired execution at 268 MB, and the
4,096-family confirmation at 989 MB.

This exact-parent A/B does not replace the expanded competitor matrix. A new
fair matrix still requires TypeScript 6, native TypeScript 7/tsgo, Bun check,
tsc-rs/ts-rust, and the active C++ TypeScript port under the shared
corpus/options/diagnostic protocol tracked by
[#838](https://github.com/home-lang/home/issues/838). No unpinned substitute
or new cross-compiler ranking is claimed here.

The [raw evidence archive](https://github.com/home-lang/home/raw/main/bench/vs_tsgo/evidence/20261008T181346Z-require-binding-index-849.tar.gz)
contains all unfiltered rounds, **68** semantic admission records, both full
scale corpora, exact runner revisions and fingerprints, fresh-cache test and
build logs, binary and Mach-O section hashes, the source patch, and
byte-identical normalized Zod output. Its **5,701** payload checksums verify;
archive SHA-256:
`3ef88a53c0e54347e486e4d87f865dd6cccba20f688b0856e6f925c51434e9bb`.

### C++ admission and current-source profile (2026-10-08 UTC)

The next investigation under [#838](https://github.com/home-lang/home/issues/838)
audited the OnlySpecs C++ candidate at exact source
[`8fd72a2a34f615d71e12f450d3e571683e16404b`](https://github.com/lidangzzz/TypeScript-C-Implementation-by-OnlySpecs/tree/8fd72a2a34f615d71e12f450d3e571683e16404b).
This is a candidate probe, not confirmation that it is the intended canonical
active port. Its README and source headers declare Apache-2.0; the GitHub
repository metadata reports no detected license file. TypeRunner at
[`21f9ce87a`](https://github.com/marcj/TypeRunner/tree/21f9ce87a72fbfe011be9bfcf404f6e76bd74fe6)
instead documents a narrower proof-of-concept subset and stalled development.
Neither project's third-party performance numbers enter Home's table.

OnlySpecs configured and built unmodified with AppleClang
`21.0.0.21000325`, CMake Release, C++20, `BUILD_TESTS=OFF`, target `tsc`, and
one build worker. Disabling its separate test executables does not alter the
compiler or Home's admission controls. The executable SHA-256 is
`c2934fc0381d317f8d2861f8533a15ecfefbf43538808e2341280166e1d9631b`.
The native CLI reports TypeScript Compiler v6.0.0 (C++ Implementation).

| Untimed admission | Outcome | Interpretation |
|---|---:|---|
| Unchanged positive projects | 20/20 exit 0 silently | Insufficient evidence of equivalent checking |
| Unchanged negative-control projects | **0/8 pass** | All eight exit 0 silently, with none of the required diagnostics |
| Accepted timing samples | **0** | Excluded from the matrix |

The failures cover imports, re-exports, both predicate scales, destructuring,
variadic tuples, CommonJS, and recursive generics. They retain their existing
expected TS2322/TS2339/TS2493/TS2540 multisets. The first audit runner stopped
on the first negative-control `SystemExit`; a corrected exception handler
then retained the complete 28-process probe. An independent input-retention
probe reproduced all 28 semantic outcomes and saved every byte of every
positive and negative project. No failure, compiler diagnostic, or control was
discarded; neither probe collected timing samples.

The source explains why silent positive acceptance is misleading: the
[CLI diagnostic path](https://github.com/lidangzzz/TypeScript-C-Implementation-by-OnlySpecs/blob/8fd72a2a34f615d71e12f450d3e571683e16404b/src/cli/tsc_main.cpp#L75)
reads diagnostics without calling `Program::compile()` or `Program::check()`.
[Project creation](https://github.com/lidangzzz/TypeScript-C-Implementation-by-OnlySpecs/blob/8fd72a2a34f615d71e12f450d3e571683e16404b/src/compiler/program.cpp#L669)
only adds parsed files, and `getSemanticDiagnostics` reads the existing
diagnostic vector. We do not patch the competitor to activate a different
workflow or treat this missing work as a performance win. Source status stayed
clean before and after admission.

The exact Bun `bd599f5af` and Rust `72b339e4` payloads remain available in this
task's local cache. Their native executable hashes and complete payload
inventory hashes match the checked-in Darwin ARM64 profile. This resolves the
local payload availability concern from the earlier moving-canary download
failure; it does not make the moving URL immutable, certify another machine's
payloads, or replace the last admitted five-compiler matrix.

Separately, clean Home source `30ab18c8cb6a1495f11780bf8065d4ad64dc1e76`
was built with pinned Zig `0.17.0-dev.2163+89ff10d56`, stripped ReleaseFast,
`-Denable_jsc=false`, and one worker. Frozen executable SHA-256:
`9b5b834b77aa4ba400e79c7acd773732e44133be4414b7a85c0e4e79327a920f`.
For diagnostic sampling only, local Mach-O symbol names were made visible and
the object relinked. Original and renamed `__TEXT,__text` bytes are identical,
SHA-256 `46f65426e7529763f8f22e4cd9869b7f190dc9d98866a76428beb010f897557f`.
Both executables passed all **56** official semantic admissions. The diagnostic
image is never used for timing, and all source, binary, and sampled input
fingerprints stayed unchanged.

One-second native samples of the unchanged 4,096-family generators show
repeated `Program.fileReferencesGlobalName` scans and `importProgramGlobals`
work on CommonJS; re-exports instead emphasize resolver and export-name
queries. These are exploratory samples across worker threads, not latency
measurements, percentages of whole-run CPU, causal speedup evidence, or proof
that other work is absent. The next scoped optimization is
[#850](https://github.com/home-lang/home/issues/850): complete per-pass global
reference facts with exact scanner parity, semantic-environment preservation,
source-update and allocation-failure controls.

All work used the shared machine lock and unchanged **3,840 MB** guard. The
Home build peaked at 2,986 MB, diagnostic profiling at 843 MB, and the initial
C++ build at 172 MB; these tree footprints over-count shared pages. All **128**
benchmark-harness tests pass. This checkpoint changes no compiler source and
claims no new benchmark lead or production-project admission.

The [raw evidence archive](https://github.com/home-lang/home/raw/main/bench/vs_tsgo/evidence/20261008-current-profile-cpp-admission-838-850.tar.gz)
retains complete C++ configure/build output, both full admission probes, all
28 exact projects, pinned source snapshots/inventory, profile instructions and
raw samples, both scale corpora, identical instruction sections, and Bun/Rust
payload inventories. All **9,794** payload checksums verify. Archive SHA-256:
`7f538b457302bd0bc307065ca0b1d7895a05e3d16a1382100bae1d5a16b2bbb6`.

### Per-pass global-reference candidate (2026-10-08 UTC)

Issue [#850](https://github.com/home-lang/home/issues/850) follows the current
source profile above. The implementation is now landed in
[`00a9dcf8f`](https://github.com/home-lang/home/commit/00a9dcf8fd4cf6ce4505803f6a699e1dec6c2650)
after correctness verification with main's independent type-transfer change
[`bdb366c03`](https://github.com/home-lang/home/commit/bdb366c03ae740267f0be5315a26dc5a651caf3a).
The experiment below is not relabeled as a measurement of the combined changes
and does not replace the current five-compiler ranking.

The candidate collects complete reference-presence facts from a file's
retained HIR into a pass-local name-to-symbol-space mask. Global-owner queries
reuse those facts instead of repeatedly traversing HIR. Construction occurs
only on the first actual reference query: local-only globals and the existing
implicit declaration-owner environment do not pay for an unused index. There
is no persistent `File` or checker state, foreign `TypeId`, omitted owner,
depth cutoff, benchmark-name branch, or altered diagnostic rule. Allocation
failure destroys partial state and keeps the original complete scanner for
every remaining query in that pass.

The exact parent is `7b9e6f2ab29e85acc58c811740cfe37a2876394e`, whose compiler
tree equals the profiled `30ab18c8c` (intervening changes are documentation and
evidence only). Frozen parent/candidate executable SHA-256 values:
`9b5b834b77aa4ba400e79c7acd773732e44133be4414b7a85c0e4e79327a920f`
and `74b7c607ea47308e26e7d057b7decb258b9d52ffe6ea1730916c311f29e4296c`.
The source patch SHA-256 is
`1c4464495ab652ca24d4c07f5ce8feea50dec5a337fac5826d4fab557418fbcf`.
Both use pinned Zig `0.17.0-dev.2163+89ff10d56`, stripped ReleaseFast,
`-Denable_jsc=false`, and one build worker. The byte-pinned parent is reused
from the verified native profile build, not mislabeled as a fresh compilation.

Every phase passed **64** admissions before timing: 56 unchanged official
records plus eight positive/negative scale records. The existing deterministic
CommonJS generator supplies both scales; controls mutate first, middle and
last families in separate retained projects and require exactly TS2322×3 and
TS2339×3 on each binary. Three warmups precede fresh-process measurements,
pair order alternates, and every observation is retained. Binary, input,
runner, harness and tool fingerprints are identical before and after.

| Exact-parent phase | Parent median | Candidate median | Lower candidate pairs | Paired mean-saving 95% t interval |
|---|---:|---:|---:|---:|
| Official CommonJS initial screen | 24.663 ms | 24.185 ms | 12/20 | −0.357 to +0.996 ms |
| Scale 1,024 initial screen | 321.150 ms | 290.896 ms | 6/6 | +23.965 to +36.308 ms |
| Scale 4,096 initial screen | 3,610.959 ms | 2,775.052 ms | 6/6 | +244.235 to +1,191.925 ms |
| Official CommonJS independent confirmation | 26.271 ms | **25.519 ms** | 22/30 | **+0.084 to +0.898 ms** |
| Scale 1,024 independent confirmation | 375.040 ms | 324.106 ms | 9/10 | −10.883 to +86.004 ms |
| Scale 4,096 independent confirmation | 3,505.488 ms | **3,064.615 ms** | 29/30 | **+377.701 to +575.922 ms** |
| Large predicates independent risk recheck | 259.743 ms | 259.157 ms | 17/30 | −1.115 to +2.698 ms |

Official CommonJS confirmation has a wholly positive saving interval; its
paired mean saving is 0.491 ms. Scale 4,096 has a 476.812 ms paired mean saving
and a 12.6% lower candidate median. Scale 1,024 confirmation remains
**inconclusive**, despite nine lower candidate pairs and the positive initial
screen. Its noisy observations are not removed or replaced by a favorable run.
These are version-scoped same-parent results, not universal wins.

The complete **20-family**, ten-pair screen selected no family under the
predeclared candidate-median-greater-than-103%-of-parent rule; no family had a
wholly negative saving interval. Large predicates still received an independent
30-pair recheck because both rejected #848 designs had adverse evidence in
that family. Its screen retains candidate observations of **809.312** and
**572.024 ms**, with an interval of −208.651 to +35.513 ms. The independent
recheck interval spans zero. Neither the absence of a threshold warning nor
that recheck establishes equivalence or universal regression freedom. The
re-export screen's positive interval is exploratory, not a confirmed target gain.

Frozen-source correctness passed Program **247/247**, checker **4,526/4,526**,
driver **200/200**, CLI **74/74**, entrypoint **35/35**, and harness
**128/128**. Controls compare every interned name in all three symbol spaces,
including declaration/property/label exclusions, nested references, shorthand,
destructuring, `globalThis` and mixed type/value names. Every construction
allocation is failed in turn until a successful build, with complete scanner
parity, partial-state cleanup and retry checks. Source replacement rebuilds
facts. A separate allocator control proves local-only queries construct no
reference table. The initial eager correctness-only draft passed 246 Program
tests and built, but collected **zero** timing samples; its source and logs
are retained separately.

The unchanged global and bound-global audits pass **116/116** cases on each
of TypeScript 6.0.3, direct native TypeScript 7.0.2, parent Home and candidate
Home: **464** retained process records with all exact project bytes and stable
executable/payload/harness fingerprints. Pinned unmodified Zod 4.5.2 retains
the identical complete primary diagnostic multiset, including positions and
messages: **195 TS + 3 HM9002**, normalized SHA-256
`6bf2feb527d91c651631642e523da6d28cd2b0c7ae4898cac0888aa7b420874f`.
This is not production admission; #548 remains open.

All work used the shared machine lock and unchanged **3,840 MB** guard. The
frozen experiment's largest recorded footprint is 3,239 MB (checker); the final candidate build
peaked at 2,895 MB, Program at 3,094 MB, and paired phases at no more than
983 MB. Footprints over-count shared pages. Queued work waited for confirmed
live jobs rather than competing with them or raising guard limits.

The [frozen candidate evidence archive](https://github.com/home-lang/home/raw/main/bench/vs_tsgo/evidence/20261008-per-pass-global-reference-candidate-850.tar.gz)
contains all **332** original pair rounds, **256** passing admission records,
the four full scale/control corpora, official inputs, 116 exact semantic-audit
projects, complete test/build/Zod logs, source snapshots/patches, and statistics
verifiers. All **11,754** payload checksums verify. Archive SHA-256:
`ddbc0e6cc1346872078a1202290a236bc52fa0f7a0fcaefac18814231ac211ed`.
The frozen archive records integration as pending **at its initial publication**
in `28b7134d3`; it is preserved unchanged, not reused as proof that the combined
source passed or has these timings.

#### Integrated-source verification

Source `00a9dcf8f` passed the complete checker **4,527/4,527**, Program
**247/247**, and the supported stripped ReleaseFast native build after
integration with `bdb366c03`. The concurrent `aef8f1dd0` rebase added only
evidence and did not change compiler inputs. Frozen-source driver/CLI/entrypoint
results above retain their actual source scope; they are not relabeled as new
integrated test runs.

The integrated native executable SHA-256 is
`c16c8caaf52d35180a7fcd53b87cac0dd71ff7b86526ef285e09bb4e088335f4`.
All **32** integrated official/scale admissions pass with unchanged fingerprints.
All **116** semantic global cases pass on each of TypeScript 6.0.3, direct
native TypeScript 7.0.2, the earlier profile baseline, and the integrated
binary: another **464** retained process records. These are untimed semantic
controls, not a new exact-parent performance comparison. Integrated Zod retains
the identical **195 TS + 3 HM9002** full primary diagnostic multiset and
normalized SHA-256 `6bf2feb527d91c651631642e523da6d28cd2b0c7ae4898cac0888aa7b420874f`.

Integrated checker/Program/build footprints peak at **3,080/3,210/3,023 MB**,
under the unchanged 3,840 MB guard. The largest admission footprint is 976 MB;
semantic auditing and Zod peak at 58/532 MB. No integrated timing samples or
new competitor ranking are claimed. The next full pinned matrix remains
under #838; the overall #416 and real-project #548 goals remain open.

The [separate integration archive](https://github.com/home-lang/home/raw/main/bench/vs_tsgo/evidence/20261008-per-pass-global-reference-integration-850.tar.gz)
retains full new test/build/Zod logs, 32 admissions, 464 audit process records,
all 116 exact audit projects, source snapshots, runners and fingerprints.
All **492** payload checksums verify. Archive SHA-256:
`acd2390d230a7c2bd29f65a0e9c7e804069dc97bcacdb05336128c647e9d553a`.

### Borrowed resolver-key lookup (rejected, 2026-10-08 UTC)

Issue [#851](https://github.com/home-lang/home/issues/851) investigated
`Resolver.resolve` allocating the complete containing-file + NUL + specifier
key before every cache lookup, including hits. The draft used a borrowed
adapted lookup with streaming Wyhash and segmented equality, preserving the
existing `StringHashMap` representation and owned stored keys. Misses still
ran complete resolution; only cacheable results allocated key storage.
Trace banners, ambiguity reset/non-caching, importer-specific bundler
conditions, negative hits and allocation-failure behavior were retained.

All **124** resolver tests passed, including **16,900** binary/empty/length
key cases, exact concatenated hash/equality parity, owned caller bytes,
every insertion-allocation failure until success/retry, repeated ambiguity,
and MTS/CTS importer conditions. **8,192** repeated positive/negative hits
performed no allocator calls, consumed no arena bytes and added no traces.
That allocation result did **not** translate into acceptable latency.

The exact parent is `ac8af9ce7602116ae4fabaea1d8a3818fc8f120b` (compiler
inputs equal to `00a9dcf8f`). Parent/candidate native SHA-256 values are
`c16c8caaf52d35180a7fcd53b87cac0dd71ff7b86526ef285e09bb4e088335f4`
and `cab3dc5a3c355208bd213f810b38423c990719fa826a77bfad2679cb6548cae1`.
Patch SHA-256:
`7890fb1ccba6e2cc52677cec6e71be21134dba480269619f48c407d14e3a479c`.
Both binaries use pinned Zig2163, stripped ReleaseFast, no JSC, and one build
worker. Every phase requires **64** unchanged official/scale positive/negative
admissions before timing. Scale controls mutate first/middle/last families
in separate retained inputs and require TS2322×3 + TS2339×3 on both binaries.
Three warmups precede fresh processes; pair order alternates and every sample
remains present. Before/after binary/input/harness/tool fingerprints match.

| Target | Initial screen: parent → candidate | Initial mean-saving 95% interval | Independent 30-pair confirmation | Confirmation saving interval | Lower candidate pairs |
|---|---:|---:|---:|---:|---:|
| Official imports | 19.902 → 20.451 ms | −0.948 to +0.066 ms | 20.513 → 20.713 ms | −0.700 to +0.067 ms | 11/30 |
| Official re-exports | 12.000 → 12.725 ms | **−2.392 to −0.176 ms** | 12.569 → 12.783 ms | **−1.300 to −0.046 ms** | 13/30 |
| Official CommonJS | 24.045 → 24.374 ms | −0.578 to +0.284 ms | 25.177 → 25.226 ms | −0.371 to +0.232 ms | 11/30 |
| CommonJS 1,024 families | 281.128 → 285.276 ms | −6.841 to +2.839 ms | 291.316 → 293.459 ms | **−12.614 to −0.817 ms** | 13/30 |
| Re-exports 4,096 leaves | 1,323.521 → 1,282.795 ms | −49.041 to +111.533 ms | 1,261.839 → 1,298.532 ms | **−73.518 to −20.605 ms** | 4/30 |

The independent re-export medians are **1.7% slower** officially and **2.9%
slower** at scale; CommonJS scale is **0.7% slower**. Their wholly negative
saving intervals reject this draft. Import and official CommonJS intervals
cross zero: inconclusive, not equivalence. The initial lower scale re-export
median is retained rather than promoted over the adverse independent result.
Streaming-hash overhead is a hypothesis, not a proven cause; no alignment
tweak, filtered sample, benchmark shortcut or favorable replacement run was used.

All **20** ten-pair family screens remain visible in the archive; none selected
an extra family under the predeclared >3%-slower-median/negative-interval rule.
The carried-forward large-predicate risk still received 30 independent pairs:
272.843 → 272.316 ms, 12/30 lower candidate observations, interval **−13.532
to +16.112 ms**. It remains inconclusive and does not cancel the target regressions.

Candidate correctness passed Program **247**, checker **4,527**, driver **200**,
CLI **74**, entrypoint **35**, resolver **124**, and harness **128** tests.
All **105** primary diagnostic source/option/package cases match parent and
native TS7, with **86** shared-config TS6 matches and **19** documented option
dialect differences retained separately. Pinned unmodified Zod's complete
primary message/position multiset remains identical at **195 TS + 3 HM9002**,
normalized SHA-256 `6bf2feb527d91c651631642e523da6d28cd2b0c7ae4898cac0888aa7b420874f`.
This is not production admission or a new competitor ranking.

The production optimization and optimization-only tests are removed. Only
general caller-key ownership and importer-condition/repeated-ambiguity controls
remain, along with corrected cache-key documentation. Restored resolver
**122/122** tests pass, and the supported rebuilt native binary is
**byte-identical to the accepted parent**, SHA-256 `c16c8caa…`. The initial
context-initializer syntax failure is retained as a pre-execution failure,
not a semantic test failure or an excluded test. No rejected compiler code
was pushed; #851 remains open for a different measured design.

The shared lock, **3,840 MB** guard and disk floors are unchanged. Candidate
build/Program/entrypoint peaks are 2,906/3,074/2,978 MB; paired phases remain
at or below 874 MB. Restored build peaks at 2,926 MB. These tree footprints
over-count shared pages, not universal resource bounds.

The [rejection evidence archive](https://github.com/home-lang/home/raw/main/bench/vs_tsgo/evidence/20261008-resolver-borrowed-keys-rejected-851.tar.gz)
retains all **452** paired rounds and **256** admissions, complete family
screens/recheck, exact positive/negative scale and oracle inputs, full
test/build/Zod logs, rejected and retained patches plus source snapshots,
binary fingerprints and statistical/oracle verifiers. All **13,078** payload
checksums verify. Archive SHA-256:
`306b81723e6c9b342e86a04b90634f5caf7981aeedad0fffd0d78651b14dd10b`.

### Lazy forward-overload root index

Issue [#837](https://github.com/home-lang/home/issues/837) traced the remaining
`type_predicates_large` loss to `ensureForwardOverloadSet`. A call through an
ordinary identifier scanned every statement in the source root to prove that
the name was not an overload. The 2,048-family workload contains 8,192 uniquely
named functions and 8,192 corresponding calls, so the negative lookup became
quadratic even though no overload group existed.

A source-history bisection separated this from the Zig 1441-to-2163 migration:
adjacent builds around the toolchain port measured 283.7 and 276.6 ms, while
the first checker revision containing the repeated scan measured 730.5 ms
against its 304.9 ms parent in the same screen. All compared binaries exited
successfully with identical empty output. The first proposed fix eagerly
prechecked every function signature; it was rejected because it slowed the
official workload to 922.8 ms and failed two contextual-overload tests.

The accepted implementation builds an immutable source-root index once, keeps
only genuine duplicate groups with at least one bodyless overload signature,
and still checks the requested group lazily at the original call site. This
preserves contextual-typing and diagnostic order while replacing repeated
root scans with linear indexing. The complete checker suite passes 4,472/4,472,
and the benchmark harness passes 104/104 tests.

The admitted focused run `20261007T183136Z` retained 30 interleaved rounds and
measured Home at 305.6 ms, native TS 7.0.2 at 420.3 ms, and tsc 6.0.3 at
1,192.4 ms: Home is 1.38× faster than the fastest competitor. The independent
20-workload run `20261007T183321Z` retained all 1,800 samples and confirmed
308.3 ms versus 419.7 ms on the repaired row, with Home lowest on 20/20
workloads. The measured stripped binary SHA-256 is
`2423c443af320c1334a0ad19264ef7d6a9ad7d0a323846baedaf3bb6dc4ae77c`.

### Contextual cache descendant index

Commit `21e6155d4`, tracked in
[#416](https://github.com/home-lang/home/issues/416), replaces repeated
whole-HIR scans during contextual function rechecking with a lazily built,
exact parent-to-children index. The original path visited every HIR node and
walked parent chains to find the descendants whose cached types must be
cleared. The index is built only when a contextual second pass occurs, then a
reused stack visits exactly that function subtree. If building or extending
either scratch structure fails, the checker executes the unchanged whole-HIR
scan, so cache invalidation is never weakened.

The direction came from an independently generated 4,096-family copy of the
existing interface-composition workload. TS 6.0.3, native TS 7.0.2, and Home
all accepted that scaled project silently. A ten-second sample of the accepted
Home binary recorded 1,018 exclusive samples in `clearCachedTypesWithin`, the
largest leaf in the trace. The profile corpus, exact outputs, and sample are
retained under
`bench/vs_tsgo/results/interface-composition-profile.20260901T111819Z/`.
This scaled copy selected the implementation target; it did not replace the
unchanged admitted workload used by the primary A/B.

The fixed accepted baseline binary is SHA-256
`cf7fab7977de31aaaf298cf54a316082ab3e0dd6523f1b37ec53b99e2f0dfc71`;
the candidate is
`927659113386a43edda5fc884cf8b1eabab5ee6eec11e454c52752b84b0f869d`.
Both exit zero with byte-identical empty stdout and stderr on the official
128-family project and the independent 4,096-family profile project. A focused
regression verifies exact descendant invalidation, sibling preservation, and
index reuse. The complete ReleaseFast checker, driver, and CLI suites pass.
All 20 benchmark workloads also pass version-pinned admission, including every
existing negative control, against TS 6.0.3 and the single native TS 7.0.2
competitor.

The official screen retained all ten reversed-order pairs after three
alternating warmup pairs:

| Official 128-family A/B, 10 pairs | Baseline | Descendant index | Result | Paired 95% CI |
|---|---:|---:|---:|---:|
| Wall | 40.302 ± 1.071 ms | **37.924 ± 0.994 ms** | **1.0627×; 10/10 candidate wins** | **+1.791 to +3.003 ms** |
| CPU | 39.390 ± 0.990 ms | **37.069 ± 0.978 ms** | **1.0626×; 10/10 candidate wins** | **+1.773 to +2.873 ms** |
| Peak RSS | 16.416 ± 0.008 MiB | **16.381 ± 0.037 MiB** | 1.0021×; 5/10 candidate wins | **+0.013 to +0.056 MiB** |

The independent 30-pair confirmation retained every round:

| Official 128-family A/B, 30 pairs | Baseline | Descendant index | Result | Paired 95% CI |
|---|---:|---:|---:|---:|
| Wall | 39.353 ± 0.657 ms | **37.441 ± 0.684 ms** | **1.0511×; 29/30 candidate wins** | **+1.547 to +2.268 ms** |
| CPU | 38.498 ± 0.590 ms | **36.582 ± 0.584 ms** | **1.0524×; 30/30 candidate wins** | **+1.618 to +2.203 ms** |
| Peak RSS | 16.422 ± 0.008 MiB | **16.387 ± 0.036 MiB** | 1.0021×; 15/30 candidate wins | **+0.022 to +0.047 MiB** |

The required 16× scale used the identical generator at 2,048 families. All
three pinned compilers and both Home binaries accepted it silently, and the
Home outputs remained byte-identical:

| Scaled 2,048-family A/B, 10 pairs | Baseline | Descendant index | Result | Paired 95% CI |
|---|---:|---:|---:|---:|
| Wall | 3913.685 ± 89.745 ms | **3397.317 ± 35.948 ms** | **1.1520×; 10/10 candidate wins** | **+459.034 to +564.619 ms** |
| CPU | 3903.645 ± 85.059 ms | **3389.624 ± 35.453 ms** | **1.1516×; 10/10 candidate wins** | **+459.204 to +559.232 ms** |
| Peak RSS | **112.316 ± 1.584 MiB** | 113.823 ± 0.011 MiB | 0.9868×; 0/10 candidate wins | **-2.414 to -0.603 MiB** |

The exact index costs two `u32` entries per HIR node, producing the disclosed
1.5 MiB peak-RSS increase on this 92,160-line scale while saving about 516 ms
of wall time. The official workload has slightly lower measured RSS. An
unrelated Zig test occupied one core throughout the official screen and
appeared in both confirmation snapshots; the scale snapshots changed from an
unrelated Zig test to an unrelated Zig build. Reversed process order, retained
samples, and strongly positive timing intervals make those loads explicit
without selecting rounds.

A separate provenance-verified, round-robin checkpoint compares the accepted
candidate directly with the pinned compilers for 30 fresh processes after
three warmups:

| Targeted interface-composition checkpoint | Mean ± sample SD | Paired detail |
|---|---:|---:|
| TS 6.0.3 | 202.1 ± 6.3 ms | — |
| Native TS 7.0.2 | 66.1 ± 9.9 ms | Fastest competitor |
| Home at `21e6155d4` | **40.8 ± 18.7 ms** | **1.62× faster; 29/30 wins; TS7-minus-Home CI +21.383 to +27.862 ms** |

The first Home round was a 139.8 ms outlier and remains included. All **30
round files / 90 successful finite samples** and unchanged before/after binary
provenance are retained under `bench/vs_tsgo/results/20260901T113706Z/`.
Frozen A/B binaries, the 2,048-family corpus, exact outputs, load snapshots,
and every screen, confirmation, and scale round are retained under
`bench/vs_tsgo/results/contextual-type-child-index.20260901T112050Z/`.

### Complementary value-declaration indexes

Commit [`8d1d198b2`](https://github.com/home-lang/home/commit/8d1d198b2),
tracked in [#416](https://github.com/home-lang/home/issues/416), removes the
next profile-backed statement-list scan from ordinary identifier resolution.
After the contextual-cache change above, the retained 4,096-family profile
showed `resolveValueDeclInStmt` as the largest exclusive leaf. A namespace
value reference could miss the existing simple variable/function index, scan
every statement in the root, and only then continue to the dedicated namespace
resolver.

The checker now pairs the existing simple-value index with a supplemental exact
index for only the declaration forms it omitted: binding patterns, classes,
imports, and loop bindings. A linear scan is skipped only when both indexes
completed successfully and both miss. Allocation failure leaves an index
incomplete and therefore executes the unchanged scan. Virtual multi-file
sections also retain the scan because ambient script declarations can cross
section keys, as do recovery HIR bindings that cannot be enumerated exactly.
The supplemental index is built only for blocks with at least 16 statements;
smaller blocks keep the cheaper linear walk.

The fixed baseline is the accepted contextual-cache binary, SHA-256
`927659113386a43edda5fc884cf8b1eabab5ee6eec11e454c52752b84b0f869d`.
The final candidate is
`e51d04c1c63f463d2512b92e0dcf34002344800896d9fdc208ba6846fe9f76a5`.
Both exit zero with byte-identical empty output on the unchanged official
128-family project and the independently generated 2,048-family, 92,160-line
scale. The scale is accepted silently by TS 6.0.3, native TS 7.0.2, and both
Home binaries.

The official screen retained all ten reversed-order pairs after three
alternating warmup pairs:

| Official 128-family A/B, 10 pairs | Baseline | Complementary indexes | Result | Paired 95% CI |
|---|---:|---:|---:|---:|
| Wall | 38.167 ± 0.793 ms | **36.102 ± 0.973 ms** | **1.0572×; 10/10 candidate wins** | **+1.397 to +2.782 ms** |
| CPU | 37.371 ± 0.752 ms | **35.203 ± 0.831 ms** | **1.0616×; 10/10 candidate wins** | **+1.636 to +2.763 ms** |
| Peak RSS | **16.391 ± 0.035 MiB** | 16.419 ± 0.012 MiB | 0.9983×; 0/10 candidate wins | **-0.047 to -0.009 MiB** |

The independent 30-pair confirmation retained every round:

| Official 128-family A/B, 30 pairs | Baseline | Complementary indexes | Result | Paired 95% CI |
|---|---:|---:|---:|---:|
| Wall | 36.772 ± 0.886 ms | **34.771 ± 0.914 ms** | **1.0575×; 30/30 candidate wins** | **+1.644 to +2.348 ms** |
| CPU | 35.991 ± 0.790 ms | **33.947 ± 0.834 ms** | **1.0602×; 30/30 candidate wins** | **+1.738 to +2.343 ms** |
| Peak RSS | **16.393 ± 0.035 MiB** | 16.423 ± 0.010 MiB | 0.9982×; 0/30 candidate wins | **-0.041 to -0.019 MiB** |

At 16× scale, the same final binaries retained all ten pairs:

| Scaled 2,048-family A/B, 10 pairs | Baseline | Complementary indexes | Result | Paired 95% CI |
|---|---:|---:|---:|---:|
| Wall | 3285.301 ± 99.137 ms | **2621.967 ± 52.107 ms** | **1.2530×; 10/10 candidate wins** | **+624.290 to +703.416 ms** |
| CPU | 3279.234 ± 93.889 ms | **2618.173 ± 50.545 ms** | **1.2525×; 10/10 candidate wins** | **+624.247 to +698.274 ms** |
| Peak RSS | **113.856 ± 0.035 MiB** | 113.892 ± 0.012 MiB | 0.9997×; 0/10 candidate wins | **-0.059 to -0.013 MiB** |

The final form therefore trades a measured fixed RSS delta of roughly 0.03 MiB
for about 2.0 ms on the official project and 663 ms at scale. Two earlier forms
were rejected despite timing wins: a duplicated complete name map reached a
0.56 MiB scale delta, and an unbounded supplemental completion set reached a
1.10 MiB scale delta. Their samples remain under
`resolvable-value-negative-index.20260901T115523Z/` and
`complementary-value-index.20260901T120833Z/`; they are not mixed with the final
tables. Final evidence is under
`bounded-complementary-value-index.20260901T121547Z/`.

All 20 version-pinned workload admissions and their negative controls pass.
The complete ReleaseFast checker passes 4,325/4,325 tests, driver 188/188, CLI
69/69, and the benchmark harness 95/95. The admission-only three-compiler gate
is `20260901T122448Z`; its single timing sample is not used as a performance
claim.

A separate final 30-round checkpoint uses three warmups, round-robin order,
and verified unchanged provenance. It retains two early Home outliers at 239.3
and 111.3 ms and every other sample:

| Final interface-composition checkpoint | Mean ± sample SD | Paired detail |
|---|---:|---:|
| TS 6.0.3 | 219.7 ± 13.9 ms | — |
| Native TS 7.0.2 | 76.0 ± 28.0 ms | Fastest competitor |
| Home at `8d1d198b2` | **47.1 ± 38.7 ms** | **1.61× faster; 29/30 wins; TS7-minus-Home CI +16.520 to +38.149 ms** |

All 30 round files / 90 finite successful samples are retained under
`bench/vs_tsgo/results/20260901T122547Z/`. TS 7 and `tsgo` are one native
competitor throughout; no superseded development build is counted.

### Import-free export-assignment gate

Commit [`b3dcb63c5`](https://github.com/home-lang/home/commit/b3dcb63c5),
tracked in [#416](https://github.com/home-lang/home/issues/416), applies the
next fresh-profile result after the complementary value indexes. A ten-second
sample of the accepted 4,096-family binary recorded 1,015 exclusive samples in
`virtualExportAssignmentTargetDeclForLocal`, the second-largest leaf. That
helper walked the complete source root looking for a require-style import even
when the checker had already established that the attached source could not
contain any import declaration.

The helper now returns immediately from that exact negative source fact.
Sources that can contain `import` keep the unchanged HIR walk, and source-less
HIR callers also retain it. The source fact is conservative: a real import
declaration necessarily contains the `import` token. This does not infer an
export-assignment target, change module resolution, or specialize behavior for
the benchmark corpus.

The fixed baseline is the accepted complementary-index binary, SHA-256
`e51d04c1c63f463d2512b92e0dcf34002344800896d9fdc208ba6846fe9f76a5`;
the candidate is
`f451419a6bbd8e897e9f0b048f992a8034866d95d458591c916f090be0a95e23`.
Both exit zero with byte-identical empty output on the unchanged official
128-family project and the independently generated 2,048-family, 92,160-line
scale.

The official screen retained every reversed-order pair after three alternating
warmup pairs:

| Official 128-family A/B, 10 pairs | Baseline | Import-free gate | Result | Paired 95% CI |
|---|---:|---:|---:|---:|
| Wall | 37.867 ± 0.858 ms | **36.265 ± 1.077 ms** | **1.0442×; 9/10 candidate wins** | **+1.003 to +2.205 ms** |
| CPU | 36.798 ± 0.706 ms | **35.134 ± 0.941 ms** | **1.0474×; 10/10 candidate wins** | **+1.248 to +2.060 ms** |
| Peak RSS | 16.416 ± 0.011 MiB | 16.419 ± 0.012 MiB | 0.9998×; 1/10 candidate wins | -0.013 to +0.006 MiB |

The independent 30-pair confirmation also retained every round:

| Official 128-family A/B, 30 pairs | Baseline | Import-free gate | Result | Paired 95% CI |
|---|---:|---:|---:|---:|
| Wall | 36.161 ± 0.860 ms | **34.845 ± 0.911 ms** | **1.0378×; 23/30 candidate wins** | **+0.833 to +1.802 ms** |
| CPU | 35.162 ± 0.729 ms | **33.885 ± 0.762 ms** | **1.0377×; 26/30 candidate wins** | **+0.898 to +1.663 ms** |
| Peak RSS | 16.424 ± 0.008 MiB | 16.423 ± 0.010 MiB | 1.0001×; 7/30 candidate wins | -0.003 to +0.005 MiB |

At 16× scale, the same binaries retained all ten pairs:

| Scaled 2,048-family A/B, 10 pairs | Baseline | Import-free gate | Result | Paired 95% CI |
|---|---:|---:|---:|---:|
| Wall | 2728.437 ± 47.535 ms | **2351.781 ± 48.171 ms** | **1.1602×; 10/10 candidate wins** | **+349.128 to +404.735 ms** |
| CPU | 2709.193 ± 45.382 ms | **2336.193 ± 47.550 ms** | **1.1597×; 10/10 candidate wins** | **+343.958 to +402.185 ms** |
| Peak RSS | 113.895 ± 0.011 MiB | 113.891 ± 0.013 MiB | 1.0000×; 2/10 candidate wins | -0.003 to +0.014 MiB |

The complete ReleaseFast checker passes 4,325/4,325 tests, driver 188/188,
CLI 69/69, and the benchmark harness 95/95. All 20 positive and negative
workload admissions pass against TS 6.0.3, native TS 7.0.2, and the frozen
candidate; the admission-only artifact is `20260901T123630Z`.

A separate final checkpoint uses the same verified compiler pins, three
warmups, 30 round-robin rounds, and retains every sample:

| Final interface-composition checkpoint | Mean ± sample SD | Paired detail |
|---|---:|---:|
| TS 6.0.3 | 210.3 ± 8.6 ms | — |
| Native TS 7.0.2 | 67.5 ± 11.8 ms | Fastest competitor |
| Home at `b3dcb63c5` | **35.7 ± 2.0 ms** | **1.89× faster; 30/30 wins; TS7-minus-Home CI +29.141 to +36.480 ms** |

The fresh profile is retained under
`interface-composition-profile-final.20260901T122859Z/`; frozen binaries,
exact outputs, load snapshots, and A/B samples are under
`import-free-export-assignment-gate.20260901T123335Z/`; the final 30-round
checkpoint is `20260901T124307Z/`. TS 7 and `tsgo` remain one native
competitor throughout.

### Global-namespace negative index (rejected)

The next profile leaf, `globalAugmentedValueType`, repeatedly scanned the root
for a namespace whose decoded identifier was exactly `global`. The rejected
candidate reused the existing exact namespace index for a negative proof in
ordinary single-source files. It did not use a text marker, so escaped
identifiers remained correct; virtual sections, multiple matches, and an
incomplete index retained the original scan.

The fixed accepted baseline is SHA-256
`f451419a6bbd8e897e9f0b048f992a8034866d95d458591c916f090be0a95e23`;
the candidate was
`8c75bc1b256d16ae2fb4eb6bfd6ad1a00837ca327adf2469f090c5bcb8bd7791`.
Both exited zero with byte-identical empty output on the official and 16×
projects. The official screen retained all ten reversed-order pairs after
three alternating warmup pairs:

| Official 128-family A/B, 10 pairs | Baseline | Candidate | Result | Paired 95% CI |
|---|---:|---:|---:|---:|
| Wall | **35.809 ± 1.140 ms** | 35.962 ± 1.904 ms | 0.9957×; 4/10 candidate wins | -1.491 to +1.072 ms |
| CPU | 34.662 ± 0.932 ms | **34.560 ± 1.616 ms** | 1.0030×; 6/10 candidate wins | -1.017 to +1.036 ms |
| Peak RSS | 16.420 ± 0.012 MiB | **16.405 ± 0.020 MiB** | 1.0010×; 5/10 candidate wins | **+0.006 to +0.027 MiB** |

The wall mean regressed and both timing intervals crossed zero. The source was
fully reverted; no confirmation, scale timing, source commit, or competitor
checkpoint was admitted. Frozen binaries, exact outputs, load snapshots, and
every screen sample remain under
`global-namespace-negative-index.20260901T124843Z/`.

### Qualified-annotation root namespace index (rejected)

The next accepted-binary profile attributed repeated root scans to
`typeAnnotationRootIsUnresolved`. Qualified annotations such as
`Composite42.Snapshot` searched every root statement for a one-segment
namespace even though the checker already maintains an exact namespace index.
The rejected candidate reused that index only for ordinary sources without
virtual filename sections. An incomplete index fell back to the original scan,
virtual sections retained the original scan, and source-less HIR retained the
import walk. Attached sources whose conservative marker proved they contained
no `import` token skipped the otherwise impossible root import loop.

The fixed accepted baseline is SHA-256
`f451419a6bbd8e897e9f0b048f992a8034866d95d458591c916f090be0a95e23`;
the candidate was
`6b3e6d85483a1124ebdc6a2b4547c8d68752c40ef3e7241e6dcbafda628b2548`.
Both exited zero with byte-identical empty stdout and stderr on the unchanged
official 128-family project and the existing 2,048-family, 92,160-line scale.
The official screen retained all ten reversed-order pairs after three
alternating warmup pairs:

| Official 128-family A/B, 10 pairs | Baseline | Candidate | Result | Paired 95% CI |
|---|---:|---:|---:|---:|
| Wall | 52.427 ± 7.230 ms | **48.469 ± 5.878 ms** | 1.0817×; 6/10 candidate wins | -0.642 to +9.406 ms |
| CPU | 50.360 ± 3.470 ms | **48.613 ± 2.195 ms** | 1.0359×; 7/10 candidate wins | -0.635 to +4.213 ms |
| Peak RSS | 16.423 ± 0.009 MiB | **16.422 ± 0.010 MiB** | 1.0001×; 2/10 candidate wins | -0.003 to +0.006 MiB |

Ten unrelated sharded Zig test processes occupied most of the workstation in
both load snapshots; load average rose from 26.33 to 29.23 during the set.
Every sample remains retained and process order was balanced. The lower means
therefore do not override the precommitted paired-interval rule: both timing
intervals cross zero. The source was fully reverted, and no confirmation,
scale timing, correctness suite, source commit, or TypeScript 6.0.3 versus
native TypeScript 7.0.2 competitor checkpoint was admitted. Frozen binaries,
exact outputs, load snapshots, and every screen sample remain under
`qualified-type-root-namespace-index.20260901T125755Z/`.

### Namespace-value miss index

Commit [`4ba46f4d6`](https://github.com/home-lang/home/commit/4ba46f4d6),
tracked in [#416](https://github.com/home-lang/home/issues/416), removes the
next independently profiled root scan. Ordinary property accesses call
`mergedNamespaceValueMemberType` because the same source can contain real
namespace values. The helper first performs an indexed visible-namespace
lookup, but a miss then repeated a linear scan of every root statement. On the
4,096-family profile corpus, this redundant fallback was the largest exclusive
leaf with 1,322 samples.

The accepted path returns the exact negative result only after the visible
namespace lookup has completed the root index and found no namespace. Virtual
filename sections retain the old scan, because declarations can cross section
keys. Roots containing dotted namespace declarations also retain it, because
`namespace A.B {}` creates the runtime root `A` without an exact `A` index
entry. A failed dotted-marker allocation now leaves the index incomplete, so
allocation failure also retains the old scan. Visible and reopened namespaces
continue through the unchanged member and merge logic. No property name,
namespace name, diagnostic, or benchmark-specific pattern is cached.

The fixed accepted baseline is SHA-256
`f451419a6bbd8e897e9f0b048f992a8034866d95d458591c916f090be0a95e23`;
the candidate is
`4c0f758c9c8a8bf313ced6fd4d8b872e6f6b96166503b7c4035e8141a2fea7a9`.
Both exit zero with byte-identical empty stdout and stderr on the unchanged
official 128-family project and the existing 2,048-family, 92,160-line scale.

The official screen retained all ten reversed-order pairs after three
alternating warmup pairs:

| Official 128-family A/B, 10 pairs | Baseline | Namespace miss index | Result | Paired 95% CI |
|---|---:|---:|---:|---:|
| Wall | 34.655 ± 1.014 ms | **33.321 ± 1.000 ms** | **1.0400×; 8/10 candidate wins** | **+0.486 to +2.185 ms** |
| CPU | 33.709 ± 0.923 ms | **32.306 ± 0.842 ms** | **1.0434×; 8/10 candidate wins** | **+0.720 to +2.092 ms** |
| Peak RSS | 16.423 ± 0.012 MiB | **16.422 ± 0.010 MiB** | 1.0001×; 2/10 candidate wins | -0.003 to +0.006 MiB |

The independent 30-pair confirmation retained every round:

| Official 128-family A/B, 30 pairs | Baseline | Namespace miss index | Result | Paired 95% CI |
|---|---:|---:|---:|---:|
| Wall | 36.506 ± 1.128 ms | **35.183 ± 1.350 ms** | **1.0376×; 20/30 candidate wins** | **+0.700 to +1.937 ms** |
| CPU | 35.480 ± 0.970 ms | **34.027 ± 1.080 ms** | **1.0427×; 26/30 candidate wins** | **+0.977 to +1.930 ms** |
| Peak RSS | 16.426 ± 0.009 MiB | **16.424 ± 0.011 MiB** | 1.0001×; 7/30 candidate wins | -0.003 to +0.006 MiB |

At 16× scale, the same frozen binaries retained all ten pairs:

| Scaled 2,048-family A/B, 10 pairs | Baseline | Namespace miss index | Result | Paired 95% CI |
|---|---:|---:|---:|---:|
| Wall | 2506.140 ± 57.410 ms | **2077.577 ± 56.174 ms** | **1.2063×; 10/10 candidate wins** | **+387.978 to +479.160 ms** |
| CPU | 2486.218 ± 54.444 ms | **2057.291 ± 55.361 ms** | **1.2085×; 10/10 candidate wins** | **+389.549 to +479.714 ms** |
| Peak RSS | 113.894 ± 0.012 MiB | 113.894 ± 0.012 MiB | 1.0000×; 2/10 candidate wins | -0.006 to +0.006 MiB |

Focused dotted- and merged-namespace tests pass, as do the complete ReleaseFast
checker 4,325/4,325, driver 188/188, and CLI 69/69 suites. The benchmark
harness passes 95/95 tests. All 20 version-pinned workload admissions and
their rejection controls pass against TS 6.0.3, the single native TS 7.0.2
(`tsgo`) competitor, and the frozen candidate; the admission-only artifact is
`20260901T132853Z`.

A separate final checkpoint uses verified unchanged compiler provenance,
three warmups, 30 rotating-order rounds, and retains every sample:

| Final interface-composition checkpoint | Mean ± sample SD | Paired detail |
|---|---:|---:|
| TS 6.0.3 | 210.2 ± 5.2 ms | — |
| Native TS 7.0.2 | 70.8 ± 19.9 ms | Fastest competitor |
| Home at `4ba46f4d6` | **34.7 ± 5.1 ms** | **2.04× faster; 30/30 wins; TS7-minus-Home CI +30.368 to +44.490 ms** |

The first Home round was a 61.2 ms outlier and remains included. Frozen
binaries, exact outputs, load snapshots, and every A/B round are retained
under `namespace-value-miss-index.20260901T130826Z/`; all 30 competitor rounds
and verified provenance are under `20260901T132947Z/`. TS 7 and `tsgo` remain
one native competitor throughout.

### Enum-free visible-namespace index

Commit [`65a6037e6`](https://github.com/home-lang/home/commit/65a6037e6),
tracked in [#416](https://github.com/home-lang/home/issues/416), removes the
next independently profiled statement-list scan. A fresh ten-second sample of
the accepted 4,096-family binary recorded 776 exclusive samples in
`visibleTypeDeclarationExistsAt`. That helper walked every statement in each
enclosing block and namespace while resolving whether a declaration name was
already visible.

The checker now reuses its exact per-container namespace-declaration index for
those lookups when an attached source is known to contain no enum declaration
and no virtual filename sections. A matching indexed namespace returns the
same positive answer; a completed indexed miss advances to the next enclosing
container without rescanning its statements. An incomplete index, any enum-
bearing source, virtual sections, and source-less HIR all retain the unchanged
linear loop. The enum gate matters because enum declarations can participate
in the same type-visible result without being namespace-index entries.
Allocation failure leaves the relevant index incomplete and therefore also
falls back to the original scan. No declaration name or workload-specific
shape is cached.

The fixed accepted baseline binary is SHA-256
`4c0f758c9c8a8bf313ced6fd4d8b872e6f6b96166503b7c4035e8141a2fea7a9`;
the candidate is
`cf92eaf386deb3e3d075af85f689072c2a196d6fe16d460603c0710a597dd4ee`.
Both exit zero with byte-identical empty stdout and stderr on the unchanged
official 128-family project and the existing 2,048-family, 92,160-line scale.

The official screen retained all ten reversed-order pairs after three
alternating warmup pairs:

| Official 128-family A/B, 10 pairs | Baseline | Visible-namespace index | Result | Paired 95% CI |
|---|---:|---:|---:|---:|
| Wall | 33.786 ± 1.088 ms | **32.914 ± 1.027 ms** | **1.0265×; 8/10 candidate wins** | **+0.312 to +1.423 ms** |
| CPU | 32.851 ± 0.881 ms | **31.906 ± 0.821 ms** | **1.0296×; 9/10 candidate wins** | **+0.520 to +1.352 ms** |
| Peak RSS | 16.423 ± 0.009 MiB | **16.398 ± 0.024 MiB** | 1.0015×; 5/10 candidate wins | **+0.009 to +0.044 MiB** |

The independent 30-pair confirmation retained every round:

| Official 128-family A/B, 30 pairs | Baseline | Visible-namespace index | Result | Paired 95% CI |
|---|---:|---:|---:|---:|
| Wall | 35.036 ± 1.115 ms | **33.956 ± 1.127 ms** | **1.0318×; 25/30 candidate wins** | **+0.505 to +1.627 ms** |
| CPU | 33.946 ± 0.958 ms | **32.884 ± 0.968 ms** | **1.0323×; 25/30 candidate wins** | **+0.596 to +1.491 ms** |
| Peak RSS | 16.421 ± 0.011 MiB | **16.399 ± 0.029 MiB** | 1.0014×; 15/30 candidate wins | **+0.014 to +0.032 MiB** |

At 16× scale, the same frozen binaries retained all ten pairs:

| Scaled 2,048-family A/B, 10 pairs | Baseline | Visible-namespace index | Result | Paired 95% CI |
|---|---:|---:|---:|---:|
| Wall | 2102.508 ± 35.611 ms | **1859.311 ± 31.373 ms** | **1.1308×; 10/10 candidate wins** | **+215.583 to +271.102 ms** |
| CPU | 2083.572 ± 32.784 ms | **1841.363 ± 27.314 ms** | **1.1315×; 10/10 candidate wins** | **+218.572 to +266.353 ms** |
| Peak RSS | **114.320 ± 0.453 MiB** | 114.755 ± 0.011 MiB | 0.9962×; 0/10 candidate wins | **-0.697 to -0.173 MiB** |

The scale result therefore discloses a 0.435 MiB higher candidate mean while
saving about 243 ms of wall time. The official project instead measured a
small RSS reduction. A refinement that built the index only for containers
with at least 16 statements reduced official RSS too, but failed the timing
admission rule: its ten-pair wall result was 35.454 ± 1.540 ms versus 34.929 ±
3.052 ms with a -1.862 to +2.470 ms paired interval, and CPU was 34.347 ±
1.315 ms versus 33.690 ± 2.728 ms with a -1.427 to +2.300 ms interval. Both
timing intervals crossed zero, so that bounded form was rejected without a
confirmation or scale run. Its frozen binary and every sample remain under
`bounded-enum-free-visible-namespace-index.20260901T134342Z/` and are not
mixed into the accepted tables.

The complete ReleaseFast checker passes 4,325/4,325 tests, driver 188/188,
CLI 69/69, and the benchmark harness 95/95. All 20 positive and negative
workload admissions pass against TS 6.0.3, the single native TS 7.0.2 (`tsgo`)
competitor, and the frozen candidate; the admission-only artifact is
`20260901T135121Z`.

A separate final checkpoint uses verified unchanged compiler provenance,
three warmups, 30 rotating-order rounds, and retains every sample:

| Final interface-composition checkpoint | Mean ± sample SD | Paired detail |
|---|---:|---:|
| TS 6.0.3 | 220.1 ± 46.4 ms | — |
| Native TS 7.0.2 | 69.9 ± 21.6 ms | Fastest competitor |
| Home at `65a6037e6` | **35.5 ± 9.2 ms** | **1.97× faster; 29/30 wins; TS7-minus-Home CI +29.691 to +40.983 ms** |

Home's only loss was the first measured round by 1.10 ms. The next round had
large values for all three compilers—459.8 ms for TS 6, 183.9 ms for native TS
7, and 71.1 ms for Home—and remains included. The target-selection profile is
retained under
`interface-composition-profile-namespace-miss.20260901T133105Z/`; frozen
binaries, exact outputs, load snapshots, and every accepted A/B round are
under `enum-free-visible-namespace-index.20260901T133659Z/`; all 30 competitor
rounds and verified provenance are under `20260901T135136Z/`. TS 7 and `tsgo`
remain one native competitor throughout.

### Unique interface-heritage index (rejected)

The next fresh profile used an independently generated 8,192-family version
of the same interface-composition workload. It confirmed that the accepted
visible-namespace path above had fallen to one residual sample. The largest
untested checker leaf was then `interfaceHeritageReachesName` with 1,029
exclusive samples; the larger `globalAugmentedValueType` leaf was skipped
because its exact negative-index form had already failed admission.

The rejected candidate built one local map for declaration-space diagnostics
on statement lists with at least 16 entries. Each unique interface name mapped
to its declaration, avoiding repeated statement scans while following
heritage chains. Duplicate interface names retained the original scan so every
merged declaration remained visible; smaller lists and an incomplete index
also retained it. The map was scoped to one diagnostic pass and released at
its end.

The fixed accepted baseline binary is SHA-256
`cf92eaf386deb3e3d075af85f689072c2a196d6fe16d460603c0710a597dd4ee`;
the rejected candidate was
`e981cbba2782982d653190d392fff68f9739c635740a6f3e7e6108e28e779626`.
Both exited zero with byte-identical empty output on the unchanged official
128-family project and the existing 2,048-family, 92,160-line scale. The full
ReleaseFast checker suite also passed before timing.

The official screen retained every reversed-order pair after three alternating
warmup pairs:

| Official 128-family A/B, 10 pairs | Baseline | Heritage index | Result | Paired 95% CI |
|---|---:|---:|---:|---:|
| Wall | **35.993 ± 1.751 ms** | 36.162 ± 1.586 ms | 0.9953×; 4/10 candidate wins | -1.142 to +0.824 ms |
| CPU | **34.711 ± 1.509 ms** | 34.792 ± 1.436 ms | 0.9977×; 4/10 candidate wins | -0.933 to +0.859 ms |
| Peak RSS | 16.608 ± 0.009 MiB | **16.591 ± 0.019 MiB** | 1.0010×; 5/10 candidate wins | **+0.005 to +0.031 MiB** |

The timing means regressed slightly and both timing intervals crossed zero.
The RSS reduction does not override the timing admission rule. The candidate
was fully reverted; no confirmation, scale timing, source commit, or compiler
checkpoint was admitted. The 8,192-family corpus and current-code profile are
retained under
`interface-composition-profile-visible-namespace.20260901T135700Z/`; frozen
binaries and every screen round remain under
`interface-heritage-index.20260901T140413Z/`.

### Merged-interface scan indexes (rejected)

The same independent 8,192-family profile identified the next two untreated
checker leaves: `checkUncheckedMergedInterfacesInStmts` with 685 exclusive
samples and `collectPriorMergedInterfaceExtends` with 658. Two exact designs
tested whether one source-ordered declaration index could replace their
repeated statement scans without changing merge semantics.

The broad design built a standalone index for root and namespace interface and
class declarations. It preserved source order, qualified names, class and
interface interactions, virtual-file fallback, and the original scan whenever
the index was incomplete. The full ReleaseFast checker suite passed, and the
baseline and candidate both exited zero with byte-identical empty output on
the unchanged official 128-family project and existing 2,048-family scale.
The fixed baseline binary was SHA-256
`cf92eaf386deb3e3d075af85f689072c2a196d6fe16d460603c0710a597dd4ee`;
the broad candidate was
`b0cdd5514609bd31c1dad743e12ce1de827b016f59eae2623bdd1cb0c15f0f20`.

An initial ten-pair set was retained but excluded from admission because ten
unrelated Zig test shards were running concurrently: its wall means were
46.404 ± 20.165 ms for baseline and 79.648 ± 36.129 ms for candidate. After
those processes exited, a fresh clean screen retained every reversed-order
pair after three alternating warmup pairs:

| Official 128-family broad-index A/B, 10 pairs | Baseline | Broad index | Result | Paired 95% CI |
|---|---:|---:|---:|---:|
| Wall | 34.339 ± 1.536 ms | **33.846 ± 1.265 ms** | 1.0146×; 6/10 candidate wins | -0.770 to +1.695 ms |
| CPU | 33.281 ± 1.486 ms | **32.773 ± 1.233 ms** | 1.0155×; 6/10 candidate wins | -0.640 to +1.612 ms |
| Peak RSS | **16.617 ± 0.013 MiB** | 16.622 ± 0.012 MiB | 0.9997×; 1/10 candidate wins | -0.014 to +0.003 MiB |

The refinement avoided the standalone prepass. It extended the already
accepted visible named-type index only when a duplicate interface was found,
recording source-ordered successor links while leaving unique declarations
without extra chain entries. Both merge consumers used those links only for
exact root-statement cases and retained the original scan for virtual files,
classes, incomplete indexes, or any chain that did not reach the current
declaration. The full ReleaseFast checker suite again passed, and both binaries
again produced byte-identical empty output on the official and scaled projects.
The refined candidate was SHA-256
`6b664bad7337687da1d19155b6b2832d48a3b8879d574c033401ba1e6d0d9393`.

Its independent screen also retained every reversed-order pair after three
alternating warmup pairs:

| Official 128-family duplicate-chain A/B, 10 pairs | Baseline | Refined chain | Result | Paired 95% CI |
|---|---:|---:|---:|---:|
| Wall | **34.103 ± 1.087 ms** | 34.138 ± 1.122 ms | 0.9990×; 4/10 candidate wins | -0.901 to +0.871 ms |
| CPU | 32.988 ± 0.885 ms | **32.909 ± 0.976 ms** | 1.0024×; 5/10 candidate wins | -0.518 to +0.754 ms |
| Peak RSS | 16.608 ± 0.009 MiB | **16.595 ± 0.012 MiB** | 1.0008×; 5/10 candidate wins | **+0.003 to +0.022 MiB** |

Neither exact design established positive wall and CPU intervals. The refined
form's 0.0125 MiB mean RSS reduction does not override that timing rule. Both
candidates were fully reverted; no confirmation, scale timing, source commit,
or compiler checkpoint was admitted. Frozen binaries, exact-output checks, the
excluded loaded set, and every clean broad round remain under
`merged-type-declaration-index.20260901T141838Z/`; the refined artifacts and
every round remain under `duplicate-interface-chain.20260901T144314Z/`.

### Namespace merge-order indexes (rejected)

The same 8,192-family profile next showed 569 exclusive samples in
`checkNamespaceFunctionMergeOrder`. The workload has many independent
namespace declarations whose names do not match later top-level functions, so
the original diagnostic pass repeatedly scans the remaining statement suffix
to establish each negative result.

The first exact design indexed the last direct class or function statement by
declaration name and virtual-file section for lists with at least 16 entries.
Statement ordinals, rather than source offsets, preserved parser-recovery
ordering; diagnostics still ran in their original forward order. Smaller
lists and allocation failure retained the original suffix scan. The full
ReleaseFast checker suite passed, and the fixed accepted baseline and candidate
both exited zero with byte-identical empty output on the unchanged official
128-family project and existing 2,048-family scale. The baseline binary was
SHA-256
`cf92eaf386deb3e3d075af85f689072c2a196d6fe16d460603c0710a597dd4ee`;
the ordinal-index candidate was
`bdf32ce6c3e3a8cf597c0bcd142d2746ec5403b5eb0297d6bccf16d33d0ab506`.

Its screen retained every reversed-order pair after three alternating warmup
pairs:

| Official 128-family ordinal-index A/B, 10 pairs | Baseline | Ordinal index | Result | Paired 95% CI |
|---|---:|---:|---:|---:|
| Wall | 33.121 ± 1.345 ms | **32.684 ± 1.029 ms** | 1.0134×; 5/10 candidate wins | -0.319 to +1.288 ms |
| CPU | 32.122 ± 1.180 ms | **31.772 ± 0.957 ms** | 1.0110×; 6/10 candidate wins | -0.261 to +1.041 ms |
| Peak RSS | 16.609 ± 0.015 MiB | **16.581 ± 0.023 MiB** | 1.0017×; 5/10 candidate wins | **+0.009 to +0.047 MiB** |

A simpler refinement then removed the new map entirely. For an attached source
with no class or enum syntax, it reused the existing per-container function
index: an exact miss proved that no same-name class or function could occur
later, while any hit, virtual-file ambiguity, small list, or HIR-only setup
retained the original order- and section-sensitive suffix scan. The full
ReleaseFast checker suite and both exact-output checks passed again. The
refined candidate was SHA-256
`332075196c3527a3c7b13d8db4a940a5c166a7d806e77c1d454a262314c5adba`.

Its independent screen used the same protocol and retained every pair:

| Official 128-family existing-index A/B, 10 pairs | Baseline | Existing-index reuse | Result | Paired 95% CI |
|---|---:|---:|---:|---:|
| Wall | **34.091 ± 1.709 ms** | 34.474 ± 2.232 ms | 0.9889×; 5/10 candidate wins | -1.386 to +0.482 ms |
| CPU | **33.113 ± 1.514 ms** | 33.265 ± 1.660 ms | 0.9954×; 6/10 candidate wins | -0.805 to +0.439 ms |
| Peak RSS | 16.608 ± 0.009 MiB | **16.603 ± 0.013 MiB** | 1.0003×; 2/10 candidate wins | 0.000 to +0.011 MiB |

The ordinal form's positive means did not establish positive timing intervals,
and the simpler reuse regressed both timing means. The small RSS changes do not
override the timing rule. Both candidates were fully reverted; no confirmation,
scale timing, source commit, or compiler checkpoint was admitted. Frozen
binaries, exact-output checks, and every round remain under
`namespace-merge-order-index.20260901T150258Z/` and
`namespace-merge-function-index.20260901T153151Z/`.

### `declarationName` forced inline (rejected)

The next largest untreated leaf in the same accepted-code profile was the
small, pure HIR accessor `declarationName` with 854 exclusive samples. The
candidate changed only its Zig declaration from `fn` to `inline fn`, allowing
known declaration kinds to fold at its many checker call sites without adding
a cache or changing lookup semantics.

The full ReleaseFast checker suite passed. The fixed accepted baseline and
candidate both exited zero with byte-identical empty output on the unchanged
official 128-family project and existing 2,048-family scale. The baseline
binary was SHA-256
`cf92eaf386deb3e3d075af85f689072c2a196d6fe16d460603c0710a597dd4ee`;
the inline candidate was
`45d120d2ea5883a6fc79f2229b3b2fb91ab19edef022246a8bf48b0d7d36f865`.
Its file size increased from 12,288,760 to 12,305,304 bytes, a 16,544-byte or
0.135% expansion.

An initial ten-pair set was retained but excluded from admission. A macOS
maintenance service that had appeared stable remained active and the measured
wall means rose to 54.407 ± 12.023 ms for baseline and 49.121 ± 10.374 ms for
candidate; the wall paired interval spanned -4.165 to +14.734 ms. After that
exact process exited, a 30-second settling interval and one short follow-on
test process completed before a fresh clean screen began. The clean screen
retained every reversed-order pair after three alternating warmup pairs:

| Official 128-family clean A/B, 10 pairs | Baseline | Forced inline | Result | Paired 95% CI |
|---|---:|---:|---:|---:|
| Wall | 33.385 ± 0.732 ms | **33.041 ± 0.505 ms** | 1.0104×; 6/10 candidate wins | -0.138 to +0.931 ms |
| CPU | 32.419 ± 0.434 ms | **32.226 ± 0.423 ms** | 1.0060×; 4/10 candidate wins | -0.128 to +0.574 ms |
| Peak RSS | **16.655 ± 0.052 MiB** | 16.703 ± 0.007 MiB | 0.9971×; 0/10 candidate wins | **-0.080 to -0.019 MiB** |

Neither timing interval established an improvement, while measured RSS and
binary size increased. The inline hint was fully reverted; no confirmation,
scale timing, source commit, or compiler checkpoint was admitted. Both the
excluded loaded set and every clean round remain under
`declaration-name-inline.20260901T154420Z/`.

### Import-free virtual-import gate

Commit [`83c44368c`](https://github.com/home-lang/home/commit/83c44368c),
tracked in [#416](https://github.com/home-lang/home/issues/416), removes the
next independently profiled root scan. The accepted-code 8,192-family profile
recorded 293 exclusive samples in `virtualImportTypeForLocal`. Identifier
resolution called that helper repeatedly, and it walked every root statement
even when the attached source's exact marker index had already proved that no
`import` token existed.

The helper now returns the exact negative result from the same conservative
`source_may_have_import_declaration` fact already used by sibling import
lookups. Import-bearing sources and source-less HIR retain the unchanged root,
virtual-section, program-export, external-resolver, and relative-module logic.
No identifier, module specifier, diagnostic, or benchmark-specific shape is
cached.

The fixed accepted baseline binary is SHA-256
`cf92eaf386deb3e3d075af85f689072c2a196d6fe16d460603c0710a597dd4ee`;
the candidate is
`1cb63e69d37841d207964c95c95f11fb7f42e0969c5403838f51e938efbc9b7b`.
Both binaries are 12,288,760 bytes and exit zero with byte-identical empty
stdout and stderr on the unchanged official 128-family project and existing
2,048-family scale.

An initial ten-pair set was retained but excluded because a follow-on thread
fuzzer remained active and the baseline mean stayed well above its established
range: wall was 41.558 ± 5.593 ms versus 40.492 ± 4.744 ms, with a -1.777 to
+4.023 ms paired interval. After that exact process and a transient database
startup exited, a replacement screen retained every reversed-order pair after
three alternating warmup pairs. One 45.662 ms baseline-minus-candidate outlier
remains included:

| Official 128-family replacement A/B, 10 pairs | Baseline | Import-free gate | Result | Paired 95% CI |
|---|---:|---:|---:|---:|
| Wall | 37.499 ± 14.478 ms | **32.501 ± 0.598 ms** | **1.1538×; 8/10 candidate wins** | **+0.277 to +14.128 ms** |
| CPU | 35.222 ± 10.178 ms | **31.628 ± 0.565 ms** | **1.1136×; 9/10 candidate wins** | **+0.237 to +10.004 ms** |
| Peak RSS | **16.606 ± 0.012 MiB** | 16.609 ± 0.010 MiB | 0.9998×; 1/10 candidate wins | -0.009 to +0.003 MiB |

The required independent 30-pair confirmation retained every sample. It also
includes a 21.437 ms baseline-minus-candidate wall outlier rather than
filtering it:

| Official 128-family confirmation A/B, 30 pairs | Baseline | Import-free gate | Result | Paired 95% CI |
|---|---:|---:|---:|---:|
| Wall | 33.946 ± 4.246 ms | **32.870 ± 0.812 ms** | **1.0327×; 18/30 candidate wins** | **+0.138 to +2.649 ms** |
| CPU | 32.755 ± 2.772 ms | **31.948 ± 0.724 ms** | **1.0253×; 20/30 candidate wins** | **+0.178 to +1.813 ms** |
| Peak RSS | 16.610 ± 0.010 MiB | **16.608 ± 0.009 MiB** | 1.0001×; 9/30 candidate wins | -0.002 to +0.006 MiB |

At 16× scale, the same frozen binaries retained all ten pairs:

| Scaled 2,048-family A/B, 10 pairs | Baseline | Import-free gate | Result | Paired 95% CI |
|---|---:|---:|---:|---:|
| Wall | 1870.621 ± 37.754 ms | **1768.735 ± 56.141 ms** | **1.0576×; 10/10 candidate wins** | **+70.251 to +129.207 ms** |
| CPU | 1849.246 ± 29.039 ms | **1751.735 ± 45.407 ms** | **1.0557×; 10/10 candidate wins** | **+69.581 to +121.979 ms** |
| Peak RSS | 121.575 ± 0.010 MiB | **119.505 ± 6.557 MiB** | 1.0173×; 2/10 candidate wins | -0.009 to +6.220 MiB |

One candidate RSS sample was 20.734 MiB below its pair, so the scale memory
mean is not treated as an established reduction; its paired interval crosses
zero. The complete ReleaseFast checker, driver, and CLI suites pass, as do all
95 benchmark-harness tests. All 20 positive and negative workload admissions
pass against TypeScript 6.0.3, the single native TypeScript 7.0.2 (`tsgo`)
competitor, and the frozen candidate; the admission-only artifact is
`20260901T163600Z`.

A separate final checkpoint uses verified unchanged compiler provenance,
three warmups, 30 rotating-order rounds, and every retained sample:

| Final interface-composition checkpoint | Mean ± sample SD | Paired detail |
|---|---:|---:|
| TypeScript 6.0.3 | 222.4 ± 13.0 ms | — |
| Native TypeScript 7.0.2 | 69.5 ± 6.9 ms | Fastest competitor |
| Home at `83c44368c` | **33.2 ± 1.0 ms** | **2.09× faster; 30/30 wins; TS7-minus-Home CI +34.526 to +39.086 ms** |

Frozen binaries, exact outputs, the excluded loaded set, and every accepted
A/B round remain under
`import-free-virtual-import-gate.20260901T161554Z/`; all 30 competitor rounds
and verified provenance remain under `20260901T163632Z/`. TS 7 and `tsgo`
remain one native competitor throughout.

### Prototype-assignment marker gate (rejected)

A fresh ten-second sample of the accepted binary on an independently generated
8,192-family copy of `interface_composition` recorded 271 exclusive samples in
`scriptObjectExpandoHasPrototypeAssignment`. The rejected one-line candidate
returned an exact miss when attached source bytes could not contain the
`.prototype` spelling already tracked by the checker's conservative source
marker index. Sources containing that spelling and source-less HIR retained the
original whole-root scan. The optimization did not cache a semantic answer or
alter the benchmark corpus.

The fixed accepted baseline binary is SHA-256
`47956122c70a686db1f1b9bc410efeb9af9997d1bec0dab385f4affd32e7da6e`;
the candidate is
`59de1b1c793eaef5aa6ce32f31792ecb5f133ed1fe72753d642d4bfa3986b567`.
Both binaries are 12,026,760 bytes and exit zero with byte-identical empty
stdout and stderr on the unchanged official 128-family project.

The first ten-pair screen is retained separately. An unrelated optimized Zig
build occupied a full core throughout, Spotlight used roughly 70% CPU, and a
transient Typesense process appeared between the load snapshots. Wall time was
32.053 ± 2.049 ms for the baseline and 35.239 ± 9.658 ms for the candidate
(0.910×, 6/10 candidate wins, paired 95% interval -8.687 to +2.315 ms).
Process CPU was 31.132 ± 1.868 ms versus 33.331 ± 7.516 ms, with an interval of
-6.268 to +1.870 ms. No samples were filtered.

After those identified transient processes exited, one separately labeled
replacement screen retained all ten reversed-order pairs after three
alternating warmup pairs. Two unrelated Zig library builds occupied two cores
throughout both replacement snapshots:

| Official 128-family replacement A/B, 10 pairs | Baseline | Marker gate | Result | Paired 95% CI |
|---|---:|---:|---:|---:|
| Wall | **31.648 ± 0.477 ms** | 31.780 ± 0.956 ms | 0.9958×; 5/10 candidate wins | -0.813 to +0.549 ms |
| CPU | **30.695 ± 0.465 ms** | 30.781 ± 0.930 ms | 0.9972×; 5/10 candidate wins | -0.792 to +0.621 ms |
| Peak RSS | **16.694 ± 0.011 MiB** | 16.697 ± 0.011 MiB | 0.9998×; 0/10 candidate wins | -0.008 to +0.002 MiB |

The cleanest available means still regressed and both timing intervals crossed
zero, so the marker gate was fully reverted. No confirmation, scale timing,
correctness suite, source commit, or competitor checkpoint was admitted. The
profile, frozen binaries, exact outputs, both load snapshots, and every timing
round remain under
`bench/vs_tsgo/results/script-expando-prototype-gate.20260902T211936Z/`.

### Import-free module-namespace gate (rejected)

The same accepted-code 8,192-family profile recorded 236 exclusive samples in
`moduleNamespaceTypeForLocalImport`. The rejected one-line candidate returned
an exact miss when attached source bytes could not contain an import
declaration, reusing the conservative `source_may_have_import_declaration` fact
already used by the accepted virtual-import gate. Import-bearing sources and
source-less HIR retained the complete module namespace, CommonJS, and interop
resolution path.

The fixed accepted baseline binary is SHA-256
`47956122c70a686db1f1b9bc410efeb9af9997d1bec0dab385f4affd32e7da6e`;
the candidate is
`6a9c934dc2276f17ef4639dd17a327745ba1f1742ff4c23ed91c4196f7791f92`.
Both binaries are 12,026,760 bytes and exit zero with byte-identical empty
stdout and stderr on the unchanged official 128-family project.

The official screen retained every reversed-order pair after three alternating
warmup pairs. Two unrelated Zig builds occupied two full cores throughout both
load snapshots:

| Official 128-family A/B, 10 pairs | Baseline | Import-free gate | Result | Paired 95% CI |
|---|---:|---:|---:|---:|
| Wall | **33.200 ± 0.695 ms** | 33.275 ± 1.053 ms | 0.9978×; 5/10 candidate wins | -0.816 to +0.667 ms |
| CPU | **31.856 ± 0.506 ms** | 31.931 ± 0.781 ms | 0.9977×; 6/10 candidate wins | -0.575 to +0.425 ms |
| Peak RSS | 16.688 ± 0.007 MiB | **16.684 ± 0.010 MiB** | 1.0002×; 3/10 candidate wins | -0.004 to +0.010 MiB |

Both timing means regressed and both intervals crossed zero, so the candidate
was fully reverted. No replacement screen, confirmation, scale timing,
correctness suite, source commit, or competitor checkpoint was admitted. The
profile, frozen binaries, exact outputs, both load snapshots, and every timing
round remain under
`bench/vs_tsgo/results/import-free-module-namespace-gate.20260902T212617Z/`.

### Type-alias heritage fallback gate (rejected)

The accepted-code 8,192-family profile recorded 211 exclusive samples in
`findTypeAliasDeclForHeritageCycle`. The rejected one-line candidate reused the
existing conservative type-alias source fact after the normal scoped lookup
returned no declaration, avoiding the fallback whole-root scan only when
attached source bytes could not contain type-alias syntax. Type-alias-bearing
sources and source-less HIR retained the complete original lookup.

The fixed accepted baseline binary is SHA-256
`47956122c70a686db1f1b9bc410efeb9af9997d1bec0dab385f4affd32e7da6e`;
the candidate is
`25f9b4f471626fafef269c4ec53f8415ae7bc5a84bb4c6d22dcb229f12ae8113`.
Both binaries are 12,026,760 bytes and exit zero with byte-identical empty
stdout and stderr on the unchanged official 128-family project.

The first ten-pair screen retained every reversed-order pair after three
alternating warmup pairs. Two unrelated Zig links occupied two full cores in
both snapshots. Wall time was 34.963 ± 1.549 ms for the baseline and
34.010 ± 0.875 ms for the candidate (1.0280×, 7/10 candidate wins, paired 95%
interval -0.406 to +2.311 ms). Process CPU was 33.363 ± 1.486 ms versus
32.462 ± 0.617 ms, with an interval of -0.428 to +2.230 ms. The promising mean
did not establish an improvement because both intervals crossed zero.

After both identified links exited, one predeclared replacement retained all
ten pairs. The host did not remain clean: ten unrelated test shards appeared
before measurement, and another Zig link appeared by the final snapshot.

| Official 128-family replacement A/B, 10 pairs | Baseline | Fallback gate | Result | Paired 95% CI |
|---|---:|---:|---:|---:|
| Wall | 39.621 ± 6.899 ms | **38.878 ± 5.739 ms** | 1.0191×; 6/10 candidate wins | -1.744 to +3.229 ms |
| CPU | 36.736 ± 3.598 ms | **36.329 ± 3.970 ms** | 1.0112×; 5/10 candidate wins | -1.717 to +2.530 ms |
| Peak RSS | 16.683 ± 0.011 MiB | 16.683 ± 0.008 MiB | 1.0000×; 2/10 candidate wins | -0.007 to +0.007 MiB |

Neither retained set established a timing improvement, so the candidate was
fully reverted rather than rerunning until noise favored it. No confirmation,
scale timing, correctness suite, source commit, or competitor checkpoint was
admitted. The profile, frozen binaries, exact outputs, load snapshots, and
every timing round remain under
`bench/vs_tsgo/results/type-alias-heritage-fallback-gate.20260902T213124Z/`.

### Free-type traversal generation marks (rejected)

After the root memo failed, the same retained profile still showed hash-table
`getOrPut` work inside `containsFreeTypeParameter`'s cycle detector. The
rejected follow-up kept the graph walk and every query boundary unchanged, but
used each dense TypeId as an index into a checker-local generation-mark array.
The first form used `u32` marks. A second form used byte epochs and cleared the
array on generation 255, reducing the dense scratch footprint by 75%. This was
not a semantic result cache: every query still traversed its reachable graph.
Allocation failure continued to return the original conservative answer.

The fixed accepted baseline binary is SHA-256
`cf7fab7977de31aaaf298cf54a316082ab3e0dd6523f1b37ec53b99e2f0dfc71`.
The `u32` candidate was
`06b0551f2960e047f91f905aee9e291854d3b72b12c058e3e6f6163b0f9620da`;
the byte candidate was
`b78ee20f1a2513e62406a5c578a613bd1191d166809e11249f64e957206a5759`.
The focused ReleaseFast cyclic-graph regression passed for positive and
negative answers, and the byte form additionally forced the rollover path.
Baseline and both candidates exited zero with byte-identical empty stdout and
stderr on the unchanged official project.

The `u32` screen retained all ten reversed-order pairs after three alternating
warmup pairs:

| Official 2,048-family `u32` A/B, 10 pairs | Baseline | Candidate | Result | Paired 95% CI |
|---|---:|---:|---:|---:|
| Wall | 217.880 ± 2.309 ms | **216.312 ± 2.383 ms** | 1.0072×; 6/10 candidate wins | -0.207 to +3.489 ms |
| CPU | 216.859 ± 2.201 ms | **215.214 ± 2.372 ms** | 1.0076×; 7/10 candidate wins | -0.064 to +3.470 ms |
| Peak RSS | **75.372 ± 0.307 MiB** | 75.667 ± 0.008 MiB | 0.9961×; 0/10 candidate wins | **-0.473 to -0.117 MiB** |

The timing intervals crossed zero and RSS was conclusively higher, so that
representation failed. The byte refinement passed its ten-pair screen:

| Official 2,048-family byte A/B, 10 pairs | Baseline | Candidate | Result | Paired 95% CI |
|---|---:|---:|---:|---:|
| Wall | 219.519 ± 4.105 ms | **214.639 ± 2.170 ms** | **1.0227×; 10/10 candidate wins** | **+2.584 to +7.245 ms** |
| CPU | 218.253 ± 3.884 ms | **213.514 ± 1.971 ms** | **1.0222×; 10/10 candidate wins** | **+2.563 to +6.991 ms** |
| Peak RSS | 75.089 ± 0.008 MiB | **74.977 ± 0.117 MiB** | 1.0015×; 5/10 candidate wins | **+0.044 to +0.183 MiB** |

The required independent 30-pair confirmation did not reproduce a certain
timing improvement:

| Official 2,048-family byte A/B, 30 pairs | Baseline | Candidate | Result | Paired 95% CI |
|---|---:|---:|---:|---:|
| Wall | 219.443 ± 3.498 ms | **218.508 ± 6.756 ms** | 1.0043×; 23/30 candidate wins | -1.382 to +2.543 ms |
| CPU | 218.265 ± 3.408 ms | **217.191 ± 6.019 ms** | 1.0049×; 23/30 candidate wins | -0.868 to +2.469 ms |
| Peak RSS | 75.080 ± 0.011 MiB | **74.975 ± 0.111 MiB** | 1.0014×; 15/30 candidate wins | **+0.069 to +0.142 MiB** |

No repository test workload was active in either screen or at the start of
confirmation. An unrelated `tools/test_representative_matrix.ts` process
appeared in the final confirmation snapshot. Every sample remains retained;
paired order reversal and the failed timing intervals avoid attributing or
discarding individual rounds. Both source forms and the rollover regression
were fully reverted, and no scale run, source commit, or competitor checkpoint
was admitted. Frozen binaries, exact outputs, load snapshots, and all timing
rounds are retained under
`bench/vs_tsgo/results/free-type-parameter-generation-marks.20260901T105309Z/`
and
`bench/vs_tsgo/results/free-type-parameter-byte-generation-marks.20260901T111418Z/`.

### Free-type-parameter root memo (rejected)

The retained profile showed repeated `containsFreeTypeParameter` graph walks in
inference and assignability. The rejected probe memoized completed root-query
results by TypeId. Positive answers are monotonic and were always eligible;
negative answers were cached only when the traversal saw no memberless object,
because an empty object can be a reserved namespace identity whose members are
completed later. Primitive and direct type-parameter fast paths stayed ahead of
the memo lookup. A focused cyclic-graph regression covered cached positive and
negative answers.

The fixed accepted baseline binary is SHA-256
`8bc94b0b9187865ab8ff38a29b1e25a57f8eb9f603453b3177ca5b41ec79f8b0`;
the experimental candidate was
`8d814b9fe6b41ed280a8f7a078861b8d601dc6194f8c1f61e0833c58e324a316`.
The focused regression passed, and baseline and candidate exited zero with
byte-identical empty stdout and stderr on the unchanged official project.

The official screen used three alternating warmup pairs, reversed process
order in every measured pair, and retained every successful finite sample.
Paired intervals are baseline-minus-candidate:

| Official 2,048-family A/B, 10 pairs | Baseline | Candidate | Result | Paired 95% CI |
|---|---:|---:|---:|---:|
| Wall | **216.023 ± 2.201 ms** | 217.643 ± 4.010 ms | 0.9926×; 4/10 candidate wins | -3.836 to +0.372 ms |
| CPU | **214.927 ± 2.140 ms** | 216.599 ± 4.005 ms | 0.9923×; 4/10 candidate wins | -3.795 to +0.246 ms |
| Peak RSS | **75.139 ± 0.060 MiB** | 75.197 ± 0.015 MiB | 0.9992×; 0/10 candidate wins | **-0.094 to -0.022 MiB** |

No repository test workload was active in the starting load snapshot. An
unrelated zig-js regression command appeared by the final snapshot. Every
sample remains in the result; the candidate's higher timing means and 10/10
RSS losses already fail the primary gate without attributing selected rounds
to that late load. The source probe and regression were fully reverted, and no
confirmation, scale run, source commit, or competitor checkpoint was admitted.
Frozen binaries, exact outputs, load snapshots, and all timing rounds are
retained under
`bench/vs_tsgo/results/free-type-parameter-root-memo.20260901T104559Z/`.

### Primitive type-name dispatch (rejected)

The retained profile showed byte equality checks as its hottest leaf, including
the unresolved-signature path's repeated primitive-name chain. The rejected
probe routed those checks through the existing primitive classifier and changed
that classifier to dispatch first by exact byte length and, for six-byte names,
the first byte. It accepted exactly the same twelve lowercase primitive names;
there was no source gate, cache, allocation, result shortcut, or workload
special case.

The fixed accepted baseline binary is SHA-256
`8bc94b0b9187865ab8ff38a29b1e25a57f8eb9f603453b3177ca5b41ec79f8b0`;
the experimental candidate was
`07eae0070563974803b18518db03e29e23052832a256a3d1e8460c6c41d1887d`.
The focused classifier regression, complete ReleaseFast `ts_checker` and TS
driver suites, all **95/95** benchmark-harness tests, `zig fmt --check`, and
`git diff --check` passed. Baseline and candidate exited zero with
byte-identical empty stdout and stderr on the unchanged official project and a
deterministic 32,768-family copy.

Every set used three alternating warmup pairs, reversed process order in every
measured pair, and retained every successful finite sample. Paired intervals
are baseline-minus-candidate:

| Predicate A/B | Metric | Baseline | Candidate | Result | Paired 95% CI |
|---|---|---:|---:|---:|---:|
| Official 2,048 families, 10-pair screen | Wall | 215.440 ± 1.922 ms | **214.456 ± 1.507 ms** | **1.0046×; 6/10 wins** | **+0.170 to +1.824 ms** |
| Official 2,048 families, 10-pair screen | CPU | 214.179 ± 1.879 ms | **213.282 ± 1.398 ms** | **1.0042×; 6/10 wins** | **+0.174 to +1.656 ms** |
| Official 2,048 families, 30-pair confirmation | Wall | 239.333 ± 11.059 ms | **234.229 ± 6.926 ms** | **1.0218×; 20/30 wins** | **+1.983 to +8.664 ms** |
| Official 2,048 families, 30-pair confirmation | CPU | 236.861 ± 7.378 ms | **232.208 ± 6.089 ms** | **1.0200×; 22/30 wins** | **+2.150 to +7.167 ms** |
| Diagnostic 32,768 families, 10 pairs | Wall | 3893.608 ± 78.673 ms | **3883.171 ± 131.193 ms** | 1.0027×; 7/10 wins | -74.299 to +74.560 ms |
| Diagnostic 32,768 families, 10 pairs | CPU | 3883.077 ± 76.470 ms | **3861.250 ± 100.959 ms** | 1.0057×; 7/10 wins | -42.135 to +74.755 ms |

Peak RSS favored the candidate by 0.009 MiB in the screen, 0.008 MiB in the
confirmation, and 0.017 MiB at scale; all three paired RSS intervals were
positive. Timing evidence, rather than RSS alone, controls admission.

The screen overlapped a single unrelated zig-js benchmark at its start. A new
`threadfuzz` shard started between the confirmation preflight and its first
load snapshot, reaching 439.5% CPU; it remained active throughout that set.
The queued fuzz workload had no idle gap, so the scale set ran under its next
stable `broad` mode, which occupied 52.9% CPU at the start. By the end that
shard had exited and unrelated Typesense and macOS services had started. No
sample was filtered, replaced, or selectively rerun.

Although both official sets cleared their gates, both required scale timing
intervals cross zero. The candidate therefore failed the precommitted scale
rule and was fully reverted. No source commit or TypeScript 6.0.3 versus native
TypeScript 7.0.2 competitor checkpoint was admitted. The temporary 50 MB
corpus was moved to Trash after recording exact outputs. Frozen binaries,
load snapshots, and all 50 timing pairs are retained under
`bench/vs_tsgo/results/primitive-type-name-dispatch.20260901T102051Z/`.

### Stable pool-index inference (rejected)

The retained post-reservation profile attributed 19 direct samples in
`inferFromPair` to copying object-member slices. Those copies prevent recursive
inference from retaining a slice across interner growth, because growth can
relocate the backing array. The rejected probe instead copied each current
member value immediately before recursion and re-fetched the next value using
the payload's stable pool offset. It applied the same representation rule to
parameter unions, parameter intersections, argument unions, and parameter
objects; no inference branch, member order, or diagnostic rule changed.

The fixed accepted baseline binary is SHA-256
`8bc94b0b9187865ab8ff38a29b1e25a57f8eb9f603453b3177ca5b41ec79f8b0`;
the experimental candidate was
`9d98cec9ef1b1c8a6928a9ad57c8975d750a2ee21779c2bdbc4e80d0802fee51`.
A focused recursive-inference regression and the complete ReleaseFast
`ts_checker` suite passed. Baseline and candidate also exited zero with
byte-identical empty stdout and stderr on the unchanged official project.

The official screen and independent confirmation each used three alternating
warmup pairs, reversed process order in every measured pair, and retained
every successful finite sample. Paired intervals are
baseline-minus-candidate:

| Official 2,048-family A/B | Metric | Baseline | Candidate | Result | Paired 95% CI |
|---|---|---:|---:|---:|---:|
| 10-pair screen | Wall | 215.851 ± 2.596 ms | **213.636 ± 2.078 ms** | **1.0104×; 10/10 wins** | **+1.473 to +2.968 ms** |
| 10-pair screen | CPU | 214.688 ± 2.529 ms | **212.560 ± 2.045 ms** | **1.0100×; 10/10 wins** | **+1.484 to +2.824 ms** |
| 30-pair confirmation | Wall | 222.219 ± 13.030 ms | **218.938 ± 8.714 ms** | 1.0150×; 20/30 wins | -1.575 to +8.838 ms |
| 30-pair confirmation | CPU | 219.641 ± 7.267 ms | **217.443 ± 7.563 ms** | 1.0101×; 20/30 wins | -1.203 to +5.471 ms |

Mean peak RSS favored the candidate in both sets. The screen measured 75.086
± 0.008 MiB versus 74.873 ± 0.229 MiB (baseline-minus-candidate interval
+0.084 to +0.341 MiB); confirmation measured 75.085 ± 0.010 MiB versus
74.874 ± 0.216 MiB (interval +0.139 to +0.284 MiB).

The screen began with Spotlight occupying one core and ended with an unrelated
Typesense process also using most of a core. By the confirmation's final load
snapshot, unrelated git, FSEvents, Typesense, and MySQL processes were active.
That activity plausibly widened the timing spread, but no sample was removed,
replaced, or selectively rerun. Because both confirmation timing intervals
cross zero, the candidate failed its precommitted admission rule. The source
probe and regression were fully reverted; no scale run, source commit, or
competitor checkpoint was admitted. Frozen binaries, exact outputs, load
snapshots, and all 40 timing pairs are retained under
`bench/vs_tsgo/results/inference-stable-pool-index.20260901T095901Z/`.

### Broad checker-directive marker gates (rejected)

After rejecting exact directive-marker expansion, a smaller follow-up reused
two broad markers already present in the shared source index. Files without
`@allow` returned before the exact `allowUnreachableCode` searches, and files
without any `@` returned before the exact `noImplicitThis` search. Files that
contained either broad marker retained the original exact substring searches,
so the probe changed neither recognized spellings nor the marker automaton.

The fixed baseline binary is SHA-256
`c4a4d99e5b2c945512519592b0ea905667554224cbbd4a29aad904efd84feab3`;
the candidate is
`47e02a823771540696c07484039213cf8b51668bf4c62f6d94ba0e985bb3042a`.
The complete ReleaseFast checker suite passed, including a focused test that
preserved `noImplicitThis: false` behavior. `zig fmt --check` and
`git diff --check` passed, and both binaries exited zero with byte-identical
empty stdout and stderr on the unchanged official 2,048-family project.

The primary screen used three alternating warmup pairs, reversed process
order in every measured pair, and retained all ten pairs. One unrelated
Typesense process and Spotlight remained active in the recorded load
snapshots. Paired intervals are baseline-minus-candidate:

| Official 2,048-family A/B, 10 pairs | Baseline | Candidate | Result | Paired 95% CI |
|---|---:|---:|---:|---:|
| Wall | **214.961 ± 1.612 ms** | 215.475 ± 3.620 ms | 0.9976×; 4/10 candidate wins | -2.748 to +1.359 ms |
| CPU | **213.774 ± 1.480 ms** | 214.255 ± 3.497 ms | 0.9978×; 6/10 candidate wins | -2.542 to +1.271 ms |
| Peak RSS | 75.084 ± 0.011 MiB | **75.081 ± 0.010 MiB** | 1.0000×; 2/10 candidate wins | +0.000 to +0.008 MiB |

The candidate has slightly higher wall and CPU means, and both timing
intervals cross zero. The probe therefore failed its primary gate and was
fully reverted without a confirmation, scale run, source commit, or competitor
checkpoint. Raw exact-output checks, load snapshots, and every timing round
are retained under
`bench/vs_tsgo/results/directive-broad-marker-gate.20260901T094320Z/`.

### Checker directive marker indexing (rejected)

The post-HIR-reservation 32,768-family profile showed three whole-source
searches after checking: the unreachable-code pass searched separately for
the true and false `allowUnreachableCode` spellings, and the final diagnostic
cleanup searched for `noImplicitThis`. The rejected probe registered the five
exact accepted spellings in the driver's existing one-pass source-marker
index and reused their recorded first positions. This preserved the previous
substring semantics and removed those three scans from the post-change
profile; it was a general source-size optimization, not a predicate-specific
shortcut.

The fixed baseline binary is SHA-256
`c66959f3321a4649d607dffb1d095cc1146454a4ac400420930f55b962cdbe06`.
The exact final-source candidate is
`65c2f95f8733ad569d00bfa25edb72bcafebc18257fdf77c68eddb55de4b2339`.
The complete ReleaseFast checker and TS driver suites passed, as did all
**95/95** benchmark-harness tests, `zig fmt --check`, and `git diff --check`.
A focused behavioral test preserved `noImplicitThis: false` suppression.
Baseline and candidate both exited zero with byte-identical empty stdout and
stderr on the unchanged official 2,048-family project and the deterministic
32,768-family diagnostic copy.

The first exact-final-source official set was directionally positive but
inconclusive. Before seeing another result, the decision rule was fixed to one
additional independent 30-pair set and an aggregate over all 60 final-binary
pairs, retaining the first set. Every set used three alternating warmup pairs,
reversed process order in every measured pair, and retained every sample.
Paired intervals are baseline-minus-candidate:

| Official 2,048-family A/B | Metric | Baseline | Candidate | Result | Paired 95% CI |
|---|---|---:|---:|---:|---:|
| First final-source set, 30 pairs | Wall | 227.277 ± 3.927 ms | **226.107 ± 5.174 ms** | 1.0052×; 20/30 wins | -0.348 to +2.503 ms |
| First final-source set, 30 pairs | CPU | 225.707 ± 3.890 ms | **224.550 ± 5.147 ms** | 1.0051×; 20/30 wins | -0.327 to +2.446 ms |
| Second final-source set, 30 pairs | Wall | 231.640 ± 9.081 ms | **227.141 ± 4.851 ms** | 1.0198×; 24/30 wins | **+1.415 to +8.487 ms** |
| Second final-source set, 30 pairs | CPU | 229.561 ± 6.919 ms | **225.522 ± 4.584 ms** | 1.0179×; 25/30 wins | **+1.520 to +7.024 ms** |
| All final-source pairs, 60 pairs | Wall | 229.459 ± 7.277 ms | **226.624 ± 5.000 ms** | **1.0125×; 44/60 wins** | **+1.070 to +4.996 ms** |
| All final-source pairs, 60 pairs | CPU | 227.634 ± 5.895 ms | **225.036 ± 4.857 ms** | **1.0115×; 45/60 wins** | **+1.109 to +4.274 ms** |

Peak RSS was statistically flat across the 60 official pairs: 75.071 ± 0.011
MiB for both rounded means, with a baseline-minus-candidate interval of
-0.003 to +0.004 MiB.

The separately required final-source 32,768-family set did not clear the
precommitted wall-time gate:

| Diagnostic 32,768-family A/B, 10 pairs | Baseline | Candidate | Result | Paired 95% CI |
|---|---:|---:|---:|---:|
| Wall | 5697.627 ± 1502.489 ms | **5584.008 ± 1722.591 ms** | 1.0203×; 7/10 wins | **-416.122 to +760.379 ms** |
| CPU | 5052.219 ± 903.888 ms | **4849.417 ± 907.554 ms** | 1.0418×; 7/10 wins | +0.428 to +550.640 ms |
| Peak RSS | 964.639 ± 48.742 MiB | **956.275 ± 67.481 MiB** | 1.0087×; 4/10 wins | +0.005 to +25.072 MiB |

The retained host snapshots explain the extreme dispersion but do not erase
it. A Zig build was already using one core at the start; by the end, ten
unrelated `zig-js` test processes each occupied roughly 80–91% of a core.
Individual paired wall differences ranged from -1473.438 to +2517.279 ms.
No observation was filtered, replaced, or selectively rerun. Because the
final scale wall interval crosses zero, the probe was rejected and completely
reverted despite the positive official aggregate. Raw profiles, exact-output
checks, preliminary evidence, both final official sets, the 60-pair aggregate,
and the final scale set are retained under
`bench/vs_tsgo/results/directive-marker-index.20260901T090828Z/`.

### Token-count HIR reservation

Commit `ed8bf949b`, tracked in
[#416](https://github.com/home-lang/home/issues/416), reserves parse-time HIR
storage once the lexer has produced the exact token count. HIR appends every
node to five parallel hot columns (`kind`, span, parent, type, and payload) and
stores variable-arity child edges in a sixth array. Previously each array grew
independently and copied its accumulated prefix several times. The accepted
change uses `tokens + 1` as one source-proportional capacity hint for all six
arrays before parsing. It changes capacity only: sentinel lengths, NodeIds,
parent links, payload order, recovery behavior, and diagnostics are unchanged.
Parser recovery can exceed the hint and retains ordinary exact ArrayList
growth.

The fixed accepted baseline binary is SHA-256
`9e86ee995ca30484ae41d0f0adafea23a386d1ad57fd932b4941909c20d4711d`;
the accepted candidate is
`c66959f3321a4649d607dffb1d095cc1146454a4ac400420930f55b962cdbe06`.
The complete HIR, TS driver, TS parser, and ReleaseFast `ts_checker` suites
pass, as do all **95/95** benchmark-harness tests. A focused HIR invariant test
proves reservation preserves sentinel lengths and the first allocated NodeId.
Both binaries also exited zero with byte-identical empty stdout and stderr on
the unchanged 2,048-family predicate project and deterministic 32,768- and
65,536-family copies generated by changing only the family count.

Every A/B set used three alternating warmup pairs, reversed process order in
every measured pair, retained every sample, and reports untrimmed mean ± sample
standard deviation. The 30-pair official confirmation was independent of the
screen. The diagnostic 32,768-family run changed only generator scale and
removed its validated 48 MB temporary corpus after recording exact outputs and
all timing rounds. Paired intervals are baseline-minus-candidate:

| Predicate A/B | Metric | Baseline | Candidate | Result | Paired 95% CI |
|---|---|---:|---:|---:|---:|
| Official 2,048 families, 10-pair screen | Wall | 219.647 ± 4.992 ms | **216.064 ± 3.003 ms** | **1.0166×; 10/10 wins** | **+2.015 to +5.291 ms** |
| Official 2,048 families, 10-pair screen | CPU | 218.469 ± 4.785 ms | **214.882 ± 2.929 ms** | **1.0167×; 10/10 wins** | **+2.146 to +5.167 ms** |
| Official 2,048 families, 30-pair confirmation | Wall | 222.721 ± 9.704 ms | **218.584 ± 3.863 ms** | **1.0189×; 26/30 wins** | **+1.456 to +7.648 ms** |
| Official 2,048 families, 30-pair confirmation | CPU | 220.865 ± 7.730 ms | **217.313 ± 3.780 ms** | **1.0163×; 27/30 wins** | **+1.420 to +6.333 ms** |
| Diagnostic 32,768 families, 10 pairs | Wall | 3885.596 ± 133.312 ms | **3859.890 ± 113.374 ms** | **1.0067×; 8/10 wins** | **+1.671 to +50.651 ms** |
| Diagnostic 32,768 families, 10 pairs | CPU | 3874.683 ± 123.916 ms | **3852.885 ± 110.856 ms** | **1.0057×; 8/10 wins** | **+0.138 to +44.724 ms** |

On the official workload, reservation increases peak RSS by **0.509 MiB** in
the 30-pair confirmation (74.559 ± 0.516 MiB to 75.068 ± 0.013 MiB; paired
interval +0.337 to +0.681 MiB for candidate-minus-baseline). At 32,768
families the candidate instead lowers mean peak RSS by **3.147 MiB**
(1001.611 ± 2.482 MiB to 998.464 ± 4.146 MiB; baseline-minus-candidate interval
+0.786 to +5.509 MiB), because the single estimate avoids geometric-growth
overcapacity. Substantial unrelated Spotlight, git, FSEvents, and application
activity remains visible in the retained load snapshots. Alternating order and
independent positive decision intervals, rather than filtered samples, support
acceptance.

The independent focused schema-3 checkpoint `20260901T084648Z` verified every
compiler and tool payload before and after 30 rotating-order rounds:

| Focused workload | tsc 6.0.3 | native TS 7.0.2 | Home 0.1.0 | Home vs fastest competitor |
|---|---:|---:|---:|---:|
| `type_predicates_large` | 1006.1 ± 35.5 ms | 350.3 ± 11.1 ms | **221.7 ± 6.0 ms** | **1.58× faster** |

Home wins all 30 focused wall pairs against both references. The
native-TS-7-minus-Home paired wall interval is **+125.455 to +132.086 ms**;
process CPU also favors Home in all 30 pairs. The subsequent complete
schema-3 checkpoint `20260901T084835Z`, published as the [current
snapshot](#current-snapshot), verifies the same immutable candidate across all
20 workloads: Home has the lowest mean in **20/20**, wins all **600/600** wall
pairs against native TS 7.0.2, and every paired interval is positive. The
narrowest interval lower bound is **+21.109 ms** on `reexport_graph`. Raw A/B
evidence is retained under
`bench/vs_tsgo/results/hir-token-reservation.20260901T133000Z/`; both competitor
checkpoints retain verified metadata and every round file in their timestamped
result directories.

### Default-export merge bucket records

Commit `1a7ac8a7a`, tracked in
[#416](https://github.com/home-lang/home/issues/416), reduces temporary
allocation and copying in `checkDefaultExportMerges`. That pass groups every
top-level merging declaration by its interned name and virtual source section.
Each bucket previously maintained five parallel dynamic arrays for declaration
nodes, owner nodes, export flags, and declaration spaces. Even a unique name
therefore allocated and grew five buffers before the pass discovered that no
merge existed.

Each bucket now appends one record containing the four facts actually consumed
by merge analysis. Grouping keys, insertion order, declaration-space unions,
diagnostic conditions, and diagnostic order are unchanged; the unused owner
entry is gone. The common unique-name bucket performs one allocation instead
of five, while genuine merge buckets retain the same exact records in the same
order. This is a general representation improvement, not a source marker,
workload gate, cache, or benchmark mode.

The fixed accepted baseline binary is SHA-256
`ca0bda46834cc05f9c5f57bac5dd5bdec88af388cf6b7c6fc39fcce9b60604ae`;
the accepted candidate is
`9e86ee995ca30484ae41d0f0adafea23a386d1ad57fd932b4941909c20d4711d`.
Both exited zero with byte-identical empty stdout and stderr on the unchanged
2,048-, 32,768-, and 65,536-family predicate projects. Focused default-export
and TS2395 merge tests pass, as do the complete ReleaseFast `ts_checker` suite
and all **95/95** benchmark-harness tests.

Every A/B set used three alternating warmup pairs, reversed process order in
every measured pair, retained every sample, and reports untrimmed mean ± sample
standard deviation. The 30-pair confirmation was independent of the screen.
Paired intervals are baseline-minus-candidate:

| Predicate A/B | Metric | Baseline | Candidate | Result | Paired 95% CI |
|---|---|---:|---:|---:|---:|
| Official 2,048 families, 10-pair screen | Wall | 241.374 ± 14.475 ms | **235.917 ± 10.657 ms** | **1.0231×; 9/10 wins** | **+0.330 to +10.584 ms** |
| Official 2,048 families, 10-pair screen | CPU | 238.947 ± 13.544 ms | **233.828 ± 10.180 ms** | **1.0219×; 9/10 wins** | **+0.354 to +9.884 ms** |
| Official 2,048 families, 30-pair confirmation | Wall | 240.368 ± 12.673 ms | **233.717 ± 14.413 ms** | **1.0285×; 24/30 wins** | **+3.677 to +9.625 ms** |
| Official 2,048 families, 30-pair confirmation | CPU | 237.972 ± 11.798 ms | **231.652 ± 12.909 ms** | **1.0273×; 25/30 wins** | **+3.520 to +9.121 ms** |
| Diagnostic 32,768 families, 10 pairs | Wall | 3974.070 ± 96.984 ms | 3903.403 ± 138.051 ms | 1.0181×; 9/10 wins | -48.164 to +189.498 ms |
| Diagnostic 32,768 families, 10 pairs | CPU | 3965.214 ± 94.695 ms | **3873.200 ± 82.108 ms** | **1.0238×; 9/10 wins** | **+10.202 to +173.825 ms** |
| Diagnostic 65,536 families, 10 pairs | Wall | 8722.056 ± 513.095 ms | 8392.079 ± 529.550 ms | 1.0393×; 7/10 wins | -113.024 to +772.979 ms |
| Diagnostic 65,536 families, 10 pairs | CPU | 8584.237 ± 389.892 ms | 8320.124 ± 474.210 ms | 1.0317×; 7/10 wins | -61.514 to +589.739 ms |

The independent official confirmation is decisive for both metrics, and the
32,768-family CPU interval independently clears zero. The 32,768 wall result
and both 65,536 metrics retain lower candidate means but are explicitly
inconclusive because their intervals cross zero. They were neither filtered
nor used to strengthen the acceptance claim.

The independent schema-3 checkpoint `20260901T065015Z` version-verified
JavaScript TypeScript 6.0.3 and native TypeScript 7.0.2, hashed every compiler
and tool payload before and after timing, and retained 30 rotating-order rounds
after three warmups:

| Focused workload | tsc 6.0.3 | native TS 7.0.2 | Home 0.1.0 | Home vs fastest competitor |
|---|---:|---:|---:|---:|
| `type_predicates_large` | 1004.8 ± 26.3 ms | 347.4 ± 9.4 ms | **224.5 ± 10.1 ms** | **1.55× faster** |

Home wins all 30 focused wall pairs against both references. The
native-TS-7-minus-Home paired 95% interval is **+118.439 to +127.422 ms**;
process CPU also favors Home in all 30 pairs. At admission, the subsequent
complete schema-3 checkpoint `20260901T065201Z` verified that accepted binary
across all 20 workloads: Home had the lowest mean in **20/20**, won all
**600/600** paired rounds against native TS 7, and every paired interval was
positive. Raw A/B
evidence is retained under
`bench/vs_tsgo/results/default-export-bucket-records.20260901T074000Z/`; both
competitor checkpoints retain their metadata and every round file in their
timestamped result directories.

### Rejected recovered-parameter identity reuse

The accepted-binary 65,536-family profile put `string_interner.internAt` at
the top of the stack and sampled it directly below
`recoveredSourceParameterAnnotationType`. The source-recovery index scans
simple parameter annotations so malformed legacy HIR can recover an annotation
that lost its parameter ownership. A representation probe reused the existing
HIR `StringId` for well-formed, unqualified, argument-free `type_ref`
annotations instead of hashing and looking up the same source bytes again. It
kept source interning for annotations without that exact HIR identity. The
probe also consulted the completed recovery-name index before walking lexical
parents, because a missing name proves that the fallback cannot apply.

The fixed accepted baseline binary is SHA-256
`9e86ee995ca30484ae41d0f0adafea23a386d1ad57fd932b4941909c20d4711d`;
the experimental candidate was
`b7b91c25a92f5835b224425e4f16d7370bc532cc34e87c2a7e5fdcdbb8f9a10d`.
Focused recovered-parameter tests, the complete ReleaseFast `ts_checker`
suite, all **95/95** benchmark-harness tests, formatting, and diff checks
passed. Both binaries also exited zero with byte-identical empty stdout and
stderr on the unchanged 2,048-family predicate project and deterministic
32,768- and 65,536-family copies generated by changing only the family count.

Every timing set used three alternating warmup pairs, reversed process order
in every measured pair, retained every sample, and reports untrimmed mean ±
sample standard deviation. The 30-pair official confirmation was independent
of the initial screen. The diagnostic 65,536-family run used the identical
generator and flags with only the family count changed; its 97 MB temporary
corpus was removed after recording the exact outputs and timing rounds. Paired
intervals are baseline-minus-candidate:

| Predicate A/B | Metric | Baseline | Candidate | Result | Paired 95% CI |
|---|---|---:|---:|---:|---:|
| Official 2,048 families, 10-pair screen | Wall | 219.909 ± 2.905 ms | **218.676 ± 2.388 ms** | **1.0056×; 7/10 wins** | **+0.215 to +2.298 ms** |
| Official 2,048 families, 10-pair screen | CPU | 218.790 ± 2.899 ms | **217.510 ± 2.292 ms** | **1.0059×; 7/10 wins** | **+0.371 to +2.251 ms** |
| Official 2,048 families, 30-pair confirmation | Wall | 221.980 ± 3.399 ms | 221.056 ± 3.515 ms | 1.0042×; 18/30 wins | -0.657 to +2.625 ms |
| Official 2,048 families, 30-pair confirmation | CPU | 220.665 ± 2.747 ms | 219.834 ± 3.315 ms | 1.0038×; 17/30 wins | -0.573 to +2.267 ms |
| Diagnostic 65,536 families, 10 pairs | Wall | 7852.527 ± 49.921 ms | 7841.785 ± 39.109 ms | 1.0014×; 8/10 wins | -7.949 to +27.006 ms |
| Diagnostic 65,536 families, 10 pairs | CPU | 7842.963 ± 49.594 ms | 7829.558 ± 37.970 ms | 1.0017×; 8/10 wins | -5.089 to +29.924 ms |

The screen separated in the candidate's favor, but neither the predeclared
official confirmation nor the larger scaling run established pair direction:
all four decision intervals crossed zero. Load snapshots also retained
substantial unrelated Spotlight activity, plus transient MySQL or Typesense
work in individual sets; no sample was filtered or rerun selectively. The
probe therefore failed the acceptance gate despite lower candidate means in
all six rows. The source change was fully reverted and the accepted binary
restored. Frozen binaries, all exact outputs, every timing round, and load
snapshots are retained under
`bench/vs_tsgo/results/recovered-parameter-identity-reuse.20260901T123000Z/`.

### Rejected namespace declaration-pass gate

The accepted-binary profile attributed 223 top-of-stack samples to
`checkDeclarationSpaceDiagnosticsImpl`. Four child passes independently scan
the same statement list but can only act on namespace, module, or global
declarations. An exact necessary-condition probe used the existing source
marker fact to skip all four when attached source contained none of those
spellings. False-positive source text still ran the original passes, while
source-less/HIR-only integrations always retained the original path. Focused
tests covered reopened namespace interface merging, sibling namespace class
and function diagnostics, ambient-module collisions, and an explicit HIR-only
fallback regression. The complete ReleaseFast `ts_checker` suite also passed.

The fixed accepted baseline binary is SHA-256
`9e86ee995ca30484ae41d0f0adafea23a386d1ad57fd932b4941909c20d4711d`;
the experimental candidate was
`5b5f4e3f32a962786332699b97da30ff50312bbefbe7f8a138fd657861f78709`.
Both exited zero with byte-identical empty stdout and stderr on the unchanged
2,048-family predicate project and deterministic 32,768- and 65,536-family
copies generated by changing only the family count.

The first 10-pair set used three alternating warmup pairs, reversed order in
every measured pair, and retained every sample. Its snapshots showed an
unrelated Bun job consuming 116% CPU at the start but absent at the end, while
Time Machine began by the end. The whole set was therefore retained but
excluded before deciding; it reported wall 222.545 ± 4.547 ms versus
223.395 ± 3.662 ms (1.0038× slower, 5/10 wins, paired CI -4.897 to
+3.197 ms) and CPU 221.348 ± 4.361 ms versus 222.156 ± 3.624 ms
(1.0037× slower, 5/10 wins, paired CI -4.602 to +2.984 ms).

One predeclared rerun used the same frozen binaries and protocol after those
loads cleared. Its before/after snapshots contained only stable system and
application activity; no sample was filtered or restarted. Paired intervals
are baseline-minus-candidate:

| Predicate A/B | Metric | Baseline | Candidate | Result | Paired 95% CI |
|---|---|---:|---:|---:|---:|
| Official 2,048 families, 10-pair rerun | Wall | 218.447 ± 2.484 ms | 218.034 ± 2.028 ms | 1.0019×; 6/10 wins | -1.380 to +2.207 ms |
| Official 2,048 families, 10-pair rerun | CPU | 217.430 ± 2.401 ms | 216.850 ± 1.979 ms | 1.0027×; 7/10 wins | -1.109 to +2.269 ms |

Neither clean-rerun metric established pair direction and both intervals
crossed zero. The initial gate therefore failed; no confirmation, scale
timing, or compiler checkpoint was admitted. The source probe and regression
were fully reverted and the accepted binary restored. Frozen binaries, exact
outputs, both complete screens, and load snapshots are retained under
`bench/vs_tsgo/results/namespace-declaration-pass-gate.20260901T111500Z/`.

### Rejected local-boundary NodeId keys

The accepted-binary profile attributed 73 top-of-stack samples to
`findLocalValueDeclBeforeExpression` and another 28 to growth of its statement
boundary map. That map keyed each boundary by both its globally unique HIR
`NodeId` and virtual-section start. An exact representation probe keyed the
boundary ordinal by `NodeId` alone; declaration keys remained partitioned by
virtual section, and every ordinal comparison and allocation-failure fallback
was unchanged. The focused index suite compares indexed and slow-scanner
results for every node and name across multiple virtual files, export
wrappers, nested scopes, and declarations, and it passed alongside the
complete ReleaseFast `ts_checker` suite.

The fixed accepted baseline binary is SHA-256
`9e86ee995ca30484ae41d0f0adafea23a386d1ad57fd932b4941909c20d4711d`;
the experimental candidate was
`095293d6e08b0c264027bc86cd4577365d0db57f44f2398993bb8ceb07782494`.
Both exited zero with byte-identical empty stdout and stderr on the unchanged
2,048-family predicate project and deterministic 32,768- and 65,536-family
copies generated by changing only the family count.

The official screen used three alternating warmup pairs, reversed process
order in every measured pair, retained every sample, and reports untrimmed
mean ± sample standard deviation. A separate one-core `zig-js` parent/candidate
benchmark remained present in both load snapshots. Paired intervals are
baseline-minus-candidate:

| Predicate A/B | Metric | Baseline | Candidate | Result | Paired 95% CI |
|---|---|---:|---:|---:|---:|
| Official 2,048 families, 10-pair screen | Wall | 228.922 ± 3.841 ms | 228.610 ± 2.939 ms | 1.0014×; 6/10 wins | -1.605 to +2.229 ms |
| Official 2,048 families, 10-pair screen | CPU | 227.242 ± 3.518 ms | 227.108 ± 2.872 ms | 1.0006×; 6/10 wins | -1.398 to +1.665 ms |

The candidate's resident-set mean was 0.3% lower, but only five of ten memory
pairs favored it and neither timing metric established pair direction. The
initial gate therefore failed; no confirmation, scale timing, or compiler
checkpoint was admitted. The source probe was fully reverted and the accepted
binary restored. Frozen binaries, exact outputs, every screen round, and load
snapshots are retained under
`bench/vs_tsgo/results/local-boundary-node-keys.20260901T102500Z/`.

### Rejected duplicate-class second-pass gate

The accepted-binary profile sampled the declaration map in
`checkInterfacesMergedWithDuplicateClasses`. After building the complete class
map, that pass rescanned every statement for interfaces even when no class key
had reached the duplicate threshold, a state in which the second scan cannot
emit a diagnostic. An exact probe tracked whether any class group became a
duplicate and returned only when none did. The class scan, map contents,
duplicate counts, first-declaration anchors, and reporting path were unchanged.
A focused regression covered three same-name classes interleaved with two
merged interfaces, ensuring the reporting path still runs and produces all
five TS2300 diagnostics.

The fixed accepted baseline binary is SHA-256
`9e86ee995ca30484ae41d0f0adafea23a386d1ad57fd932b4941909c20d4711d`;
the experimental candidate was
`2d62489c7daf2d5d1fa44d5aff3c40f2e75b09d8fbf9c2d7bf8c7fc331cfbf40`.
Both exited zero with byte-identical empty stdout and stderr on the unchanged
2,048-family predicate project and deterministic 32,768- and 65,536-family
copies generated by changing only the family count. The focused regression
and complete ReleaseFast `ts_checker` suite passed.

The official screen used three alternating warmup pairs, reversed process
order in every measured pair, retained every sample, and reports untrimmed
mean ± sample standard deviation. A separate one-core `zig-js` benchmark was
present in both load snapshots; its worker changed while the load class
remained present. Paired intervals are baseline-minus-candidate:

| Predicate A/B | Metric | Baseline | Candidate | Result | Paired 95% CI |
|---|---|---:|---:|---:|---:|
| Official 2,048 families, 10-pair screen | Wall | 225.297 ± 3.702 ms | 223.708 ± 2.394 ms | 1.0071×; 5/10 wins | -0.394 to +3.571 ms |
| Official 2,048 families, 10-pair screen | CPU | 223.789 ± 3.469 ms | 222.307 ± 2.316 ms | 1.0067×; 7/10 wins | -0.355 to +3.319 ms |

Neither metric established pair direction and both intervals crossed zero.
The initial gate therefore failed; no confirmation, scale timing, or compiler
checkpoint was admitted. The source probe and regression were fully reverted
and the accepted binary restored. Frozen binaries, exact outputs, every screen
round, and load snapshots are retained under
`bench/vs_tsgo/results/duplicate-class-second-pass-gate.20260901T094500Z/`.

### Rejected duplicate-class threshold flag

The accepted-binary profile attributed repeated samples to the declaration
map used by `checkInterfacesMergedWithDuplicateClasses`. Its `ClassGroup`
stored a full `usize` count even though downstream logic only distinguishes
one class from two-or-more classes. An exact probe replaced that count with a
`has_duplicate` flag while retaining the first declaration anchor, key,
iteration order, and diagnostic condition. A focused regression covered three
same-name classes interleaved with two merged interfaces, ensuring that every
declaration still receives TS2300 exactly once.

The fixed accepted baseline binary is SHA-256
`9e86ee995ca30484ae41d0f0adafea23a386d1ad57fd932b4941909c20d4711d`;
the experimental candidate was
`6efc4fd1744b01a7efb49fe59ccd9d127b53fb1e699332918260a0d89535504e`.
Both exited zero with byte-identical empty stdout and stderr on the unchanged
2,048-family predicate project and deterministic 32,768- and 65,536-family
copies generated by changing only the family count. The focused regression
and complete ReleaseFast `ts_checker` suite passed.

The first 10-pair set used three alternating warmup pairs, reversed order in
every measured pair, and retained every sample. Its load snapshots showed an
unrelated Bun job consuming 34% CPU at the start but absent at the end. That
whole set was therefore retained but excluded before making the decision; it
reported wall 225.065 ± 6.758 ms versus 224.671 ± 7.567 ms (1.0018×, 7/10
wins, paired CI -1.872 to +2.661 ms) and CPU 223.756 ± 6.406 ms versus
223.151 ± 7.142 ms (1.0027×, 7/10 wins, paired CI -1.592 to +2.802 ms).

One predeclared rerun used the same frozen binaries and protocol. A separate
test262 shard and Spotlight each held approximately one core throughout; the
test262 worker PID rotated, but its load class remained present in both
snapshots. No sample was filtered or restarted. Paired intervals are
baseline-minus-candidate:

| Predicate A/B | Metric | Baseline | Candidate | Result | Paired 95% CI |
|---|---|---:|---:|---:|---:|
| Official 2,048 families, 10-pair rerun | Wall | **226.580 ± 2.854 ms** | 228.710 ± 4.979 ms | 1.0094× slower; 4/10 wins | -4.636 to +0.375 ms |
| Official 2,048 families, 10-pair rerun | CPU | **225.118 ± 2.760 ms** | 227.103 ± 4.789 ms | 1.0088× slower; 4/10 wins | -4.247 to +0.278 ms |

The designated rerun was directionally slower and neither paired interval
established a candidate benefit. The initial gate therefore failed; no scale
timing, confirmation, or compiler checkpoint was admitted. The source probe
and regression were fully reverted and the accepted binary restored. Frozen
binaries, exact outputs, both complete screens, and load snapshots are
retained under
`bench/vs_tsgo/results/duplicate-class-flag.20260901T091500Z/`.

### Rejected type-alias merge inline-first targets

The post-bucket profile under
`predicate-post-bucket-profile.20260901T070000Z` attributed 223 top-of-stack
samples to `checkDeclarationSpaceDiagnosticsImpl`. One child pass,
`checkTypeAliasDeclarationMergeDiagnostics`, stored a dynamic list for every
class/interface name even when the group contained only one declaration. An
exact probe kept the first target inline in the map value and allocated an
overflow list only for genuine multi-target groups. Target order and the
alias-to-every-target diagnostic loop were unchanged; a focused regression
covered an alias conflicting with both a class and its merged interface.

The fixed accepted baseline binary is SHA-256
`9e86ee995ca30484ae41d0f0adafea23a386d1ad57fd932b4941909c20d4711d`;
the experimental candidate was
`d0e1896e83807ca257b7bd45fce2d1e72a02c7f1c935c8daac6871db15b185f6`.
Both exited zero with byte-identical empty stdout and stderr on the unchanged
2,048-, 32,768-, and 65,536-family predicate projects. The focused type-alias
checker suite passed, including the multi-target overflow regression.

The official screen retained all ten reversed-order pairs after three
alternating warmup pairs. Two unrelated Zig test shards in another repository
held a stable two-core load throughout; no sample was filtered or restarted.
Paired intervals are baseline-minus-candidate:

| Predicate A/B | Metric | Baseline | Candidate | Result | Paired 95% CI |
|---|---|---:|---:|---:|---:|
| Official 2,048 families, 10-pair screen | Wall | 232.604 ± 14.432 ms | 230.552 ± 5.974 ms | 1.0089×; 6/10 wins | -5.243 to +9.348 ms |
| Official 2,048 families, 10-pair screen | CPU | 229.749 ± 11.273 ms | 228.636 ± 5.582 ms | 1.0049×; 5/10 wins | -4.146 to +6.371 ms |

The external load may widen variance, but neither metric established pair
direction and both intervals crossed zero. The initial gate therefore failed;
no confirmation, scale timing, or competitor checkpoint was run. The source
probe was fully reverted and the accepted binary restored. Raw binaries,
exact outputs, and every screen round are retained under
`bench/vs_tsgo/results/type-alias-merge-inline-first.20260901T083000Z/`.

### Exact diagnostic-reconciliation marker gate

Commit `587c64343`, tracked in
[#416](https://github.com/home-lang/home/issues/416), avoids an unnecessary
post-check source scan on ordinary files. Sampling the unchanged 65,536-family
`type_predicates_large` project identified
`applyCompilerCorpusExactDiagnosticReconciliations` as the dominant sampled
checker leaf. That compatibility pass searched every source separately for a
small set of exact upstream-corpus constructs even though none occur in the
valid predicate workload.

The checker now includes one necessary sentinel for every reconciliation
branch in the source marker index already built by `prepareSource`. If none of
those exact sentinels is present, the reconciliation pass returns immediately;
if any is present, every original exact condition and diagnostic action still
runs. The uncached checker path retains exact `indexOf` fallback behavior. This
is a general necessary-condition gate over real source text, not a workload
name, result cache, diagnostic shortcut, or benchmark-only mode.

The fixed baseline binary is SHA-256
`5748ad8edbbb55ad43bfa84a11d3f87c10ae1994e9de01b138640d970977e5f3`;
the accepted candidate is
`ca0bda46834cc05f9c5f57bac5dd5bdec88af388cf6b7c6fc39fcce9b60604ae`.
Both exit zero with byte-identical empty stdout and stderr on the unchanged
official 2,048-family project and deterministic 32,768- and 65,536-family
copies generated with only the family count changed. A focused test covers
every sentinel through both indexed and fallback lookup paths. The complete
ReleaseFast `ts_checker` suite and all 95 benchmark-harness tests pass.

Every A/B set used three alternating warmup pairs, reversed process order in
each measured round, retained every sample, and reports untrimmed mean ± sample
standard deviation. Paired intervals are baseline-minus-candidate; intervals
wholly above zero favor the candidate.

| Predicate A/B | Metric | Baseline | Candidate | Result | Paired 95% CI |
|---|---|---:|---:|---:|---:|
| Official 2,048 families, 10-pair screen | Wall | 249.171 ± 2.809 ms | **243.385 ± 2.695 ms** | **1.0238×; 9/10 wins** | **+2.831 to +8.742 ms** |
| Official 2,048 families, 10-pair screen | CPU | 246.565 ± 2.789 ms | **240.868 ± 2.462 ms** | **1.0237×; 9/10 wins** | **+2.846 to +8.548 ms** |
| Official 2,048 families, 30-pair confirmation | Wall | 248.825 ± 3.471 ms | **242.644 ± 8.619 ms** | **1.0255×; 28/30 wins** | **+2.540 to +9.822 ms** |
| Official 2,048 families, 30-pair confirmation | CPU | 246.300 ± 3.345 ms | **239.937 ± 7.287 ms** | **1.0265×; 29/30 wins** | **+3.228 to +9.499 ms** |
| Diagnostic 32,768 families, 10 pairs | Wall | 4370.414 ± 50.111 ms | **4271.202 ± 42.435 ms** | **1.0232×; 10/10 wins** | **+69.986 to +128.437 ms** |
| Diagnostic 32,768 families, 10 pairs | CPU | 4347.483 ± 47.148 ms | **4247.370 ± 36.548 ms** | **1.0236×; 10/10 wins** | **+75.027 to +125.199 ms** |
| Diagnostic 65,536 families, 10 pairs | Wall | 9299.204 ± 186.830 ms | 9173.403 ± 254.585 ms | 1.0137×; 8/10 wins | -44.569 to +296.173 ms |
| Diagnostic 65,536 families, 10 pairs | CPU | 9194.124 ± 162.523 ms | 9078.005 ± 220.901 ms | 1.0128×; 8/10 wins | -48.866 to +281.103 ms |

The official screen and independent 30-pair confirmation are decisive, as is
the 32,768-family scale check. The retained 65,536-family set has lower
candidate means but is explicitly inconclusive because both paired intervals
cross zero; it was neither filtered nor used as the acceptance gate.

The schema-3 competitor checkpoint `20260901T051415Z` independently admitted
the official workload against JavaScript TypeScript 6.0.3 and native
TypeScript 7.0.2 (`tsgo`), verified compiler and tool payloads before and after
timing, and ran 30 rotating-order rounds after three warmups:

| Focused workload | tsc 6.0.3 | native TS 7.0.2 | Home 0.1.0 | Home vs fastest competitor |
|---|---:|---:|---:|---:|
| `type_predicates_large` | 1178.4 ± 145.4 ms | 401.6 ± 32.8 ms | **267.2 ± 55.9 ms** | **1.50× faster** |

Home had the lower wall time in 29/30 pairs against native TS 7 and all 30
pairs against TS 6. Its native-TS-7-minus-Home paired wall interval is
**+120.576 to +148.318 ms**; process CPU favored Home in all 30 pairs against
both references. Raw profile, exact-output, and A/B evidence is retained under
`bench/vs_tsgo/results/predicate-current-profile.20260901T045324Z/` and
`bench/vs_tsgo/results/exact-diagnostic-marker-gate.20260901T045636Z/`;
the pinned-competitor rounds and verified provenance are under
`bench/vs_tsgo/results/20260901T051415Z/`.

### Rejected parser JSDoc-presence reuse

The post-marker-gate 65,536-family profile under
`predicate-post-gate-profile.20260901T052300Z` showed 255 top-of-stack samples
in `reportJSDocTypeArgumentSyntaxDiagnostics`. The logical probe supplied the
parser with the exact `/**` presence fact already computed by the shared source
marker index. Indexed callers could skip the parser's standalone byte scan only
when absence was proven, while direct parser callers retained the existing
fallback. A positive-path driver regression preserved real JSDoc diagnostics.

The fixed accepted baseline binary is SHA-256
`ca0bda46834cc05f9c5f57bac5dd5bdec88af388cf6b7c6fc39fcce9b60604ae`;
the experimental candidate was
`46bb697b636891de8b8d9e3472260525c85d267d4880cebbed8183593446711a`.
Both exit zero with byte-identical empty stdout and stderr on unchanged 2,048-,
32,768-, and 65,536-family predicate projects. The complete parser and driver
test suites passed. These correctness results do not substitute for a measured
performance admission.

Every set below retained every sample after three alternating warmup pairs and
reversed process order in each measured pair. Paired intervals are
baseline-minus-candidate. No interval clears zero, so none supports acceptance:

| Predicate A/B | Metric | Baseline | Candidate | Result | Paired 95% CI |
|---|---|---:|---:|---:|---:|
| Official 2,048 families, 10-pair screen | Wall | 256.561 ± 9.732 ms | 252.491 ± 10.873 ms | 1.0161×; 9/10 wins | -2.739 to +10.877 ms |
| Official 2,048 families, 10-pair screen | CPU | 252.042 ± 8.962 ms | 248.436 ± 9.805 ms | 1.0145×; 8/10 wins | -2.884 to +10.096 ms |
| Official 2,048 families, 30-pair confirmation | Wall | 254.126 ± 6.418 ms | 252.085 ± 8.404 ms | 1.0081×; 21/30 wins | -1.091 to +5.173 ms |
| Official 2,048 families, 30-pair confirmation | CPU | 248.771 ± 4.054 ms | 246.934 ± 5.092 ms | 1.0074×; 20/30 wins | -0.401 to +4.076 ms |
| First 32,768-family set, 10 pairs | Wall | 4593.952 ± 222.426 ms | 4514.325 ± 254.702 ms | 1.0176×; 6/10 wins | -119.839 to +279.092 ms |
| First 32,768-family set, 10 pairs | CPU | 4487.025 ± 191.128 ms | 4424.545 ± 235.388 ms | 1.0141×; 5/10 wins | -113.987 to +238.947 ms |
| Independent 32,768-family set, 10 pairs | Wall | 4096.643 ± 154.747 ms | 4421.331 ± 961.984 ms | 0.9266×; 5/10 wins | -1034.897 to +385.522 ms |
| Independent 32,768-family set, 10 pairs | CPU | 4063.062 ± 132.979 ms | 4257.522 ± 600.774 ms | 0.9543×; 5/10 wins | -645.169 to +256.249 ms |

The first scale set overlapped four unrelated CPU-saturating test shards. After
those cleared, new test and service startup overlapped rounds 7–8 of the
independent set; the two candidate wall samples were 4999.780 and 7011.918 ms.
Those outliers remain in the table and raw files. The result is treated as an
environmental admission failure rather than filtered, pooled, or reframed as a
speed claim. Because the official confirmation also remained inconclusive, the
source probe was reverted and the accepted baseline binary restored. Raw
evidence is retained under
`bench/vs_tsgo/results/jsdoc-parser-presence-gate.20260901T053000Z/`.

### Rejected parser virtual-section fact reuse

The driver already records exact `@filename:` and `@Filename:` presence in the
shared source-marker index. A logical probe added an explicit parser
constructor for that fact so driver-prepared sources could avoid the two
standalone `indexOf` calls in `Parser.init`; direct parser callers retained the
original discovery path. A mixed-file regression exercised the explicit-fact
constructor with uppercase `@Filename:` sections.

The fixed accepted baseline binary is SHA-256
`ca0bda46834cc05f9c5f57bac5dd5bdec88af388cf6b7c6fc39fcce9b60604ae`;
the experimental candidate was
`3e902387bd0adccbb4642407467f90e7ce3f2de29faccc8d602fa1f24c54d378`.
Both produced byte-identical output at the unchanged 2,048-, 32,768-, and
65,536-family predicate scales. They also returned the same nonzero status and
byte-identical 348-byte diagnostic output for a mixed `.d.ts`/`.js` virtual
fixture. The complete parser and driver suites passed.

Each retained set used three alternating warmup pairs and reversed process
order in every measured pair. Paired intervals are baseline-minus-candidate:

| Predicate A/B | Metric | Baseline | Candidate | Result | Paired 95% CI |
|---|---|---:|---:|---:|---:|
| Official 2,048 families, 10-pair screen | Wall | 242.047 ± 5.350 ms | 240.399 ± 4.425 ms | 1.0069×; 8/10 wins | -2.942 to +6.237 ms |
| Official 2,048 families, 10-pair screen | CPU | 239.772 ± 5.028 ms | 238.133 ± 3.994 ms | 1.0069×; 8/10 wins | -2.714 to +5.992 ms |
| Diagnostic 32,768 families, 10 pairs | Wall | 4069.149 ± 128.847 ms | 4062.120 ± 115.320 ms | 1.0017×; 4/10 wins | -44.382 to +58.439 ms |
| Diagnostic 32,768 families, 10 pairs | CPU | 4045.291 ± 122.162 ms | 4034.395 ± 105.810 ms | 1.0027×; 4/10 wins | -43.525 to +65.318 ms |

The unchanged larger project did not amplify the apparent official-screen
gain: both means were near ties, only four candidate wins occurred, and both
paired intervals crossed zero. The source probe was therefore rejected and
fully reverted without a confirmation or competitor checkpoint. Every sample
is retained under
`bench/vs_tsgo/results/parser-virtual-section-fact.20260901T055116Z/`.

### Rejected reconciliation-sentinel root-set pruning

The accepted exact diagnostic-reconciliation gate added ten rare sentinels to
the shared Aho–Corasick source-marker index. Six introduced first bytes not
used by the original 39 markers, which expanded the root-state byte set used
by `indexOfAnyPos`. This exact probe replaced only those six sentinels with
necessary suffixes whose first bytes already occurred in the original set.
The complete branch-specific conditions in
`applyCompilerCorpusExactDiagnosticReconciliations` remained unchanged, so a
suffix could only trigger the existing exact reconciliation checks; it could
not suppress or create a diagnostic by itself.

The fixed accepted baseline binary is SHA-256
`ca0bda46834cc05f9c5f57bac5dd5bdec88af388cf6b7c6fc39fcce9b60604ae`;
the experimental candidate was
`cafc7e811c5dc8e1c1c1ef729dd22ca1c2e037edefe6e7700156cb2067104748`.
Both exited zero with byte-identical empty stdout and stderr on the unchanged
2,048-, 32,768-, and 65,536-family predicate projects. Focused source-marker
and exact reconciliation-gate tests passed, including indexed and fallback
paths plus coverage of every sentinel.

Every retained set used three alternating warmup pairs, reversed process order
in every measured pair, retained every finite sample, and reports untrimmed
mean ± sample standard deviation. The 30-pair confirmation was independent of
the initial screen. Paired intervals are baseline-minus-candidate:

| Predicate A/B | Metric | Baseline | Candidate | Result | Paired 95% CI |
|---|---|---:|---:|---:|---:|
| Official 2,048 families, 10-pair screen | Wall | 229.344 ± 2.895 ms | **226.531 ± 1.847 ms** | **1.0124×; 9/10 wins** | **+0.383 to +5.243 ms** |
| Official 2,048 families, 10-pair screen | CPU | 227.708 ± 2.940 ms | **224.807 ± 2.114 ms** | **1.0129×; 9/10 wins** | **+0.406 to +5.396 ms** |
| Official 2,048 families, 30-pair confirmation | Wall | 227.299 ± 2.680 ms | 226.574 ± 1.759 ms | 1.0032×; 18/30 wins | -0.338 to +1.788 ms |
| Official 2,048 families, 30-pair confirmation | CPU | 225.448 ± 2.758 ms | 224.687 ± 1.783 ms | 1.0034×; 16/30 wins | -0.316 to +1.838 ms |
| Diagnostic 32,768 families, 10 pairs | Wall | **3911.739 ± 25.827 ms** | 3918.677 ± 15.862 ms | 0.9982×; 5/10 wins | -31.177 to +17.302 ms |
| Diagnostic 32,768 families, 10 pairs | CPU | **3896.615 ± 25.726 ms** | 3904.611 ± 15.054 ms | 0.9980×; 5/10 wins | -30.283 to +14.292 ms |

The promising initial screen did not reproduce decisively: the independent
confirmation shrank to about 0.3%, both paired intervals crossed zero, and
pair direction was nearly even. The unchanged 32,768-family scale then had
higher candidate means and only five wins for both metrics. The optimization
was therefore rejected and fully reverted without a competitor checkpoint.
Raw binaries, exact outputs, and every A/B round are retained under
`bench/vs_tsgo/results/reconciliation-root-set.20260901T060254Z/`.

### Rejected union flatten-buffer elision

The post-gate profile retained allocation and copying inside
`Interner.internUnion`. The existing canonicalizer always expands its inputs
into a temporary list before making the separate sortable copy, even when no
input is itself a union. An exact probe kept the caller's immutable slice in
that common case and allocated the expansion list only after finding a nested
union. Nested-union flattening, sorting, deduplication, flag folding, and
interner publication remained unchanged.

The fixed accepted baseline binary is SHA-256
`ca0bda46834cc05f9c5f57bac5dd5bdec88af388cf6b7c6fc39fcce9b60604ae`;
the experimental candidate was
`7a509d9a7537b1d5d95b9d37ca110d5702d6d4a643161fd208fcdbcb370cef8e`.
Both exited zero with byte-identical empty stdout and stderr on the unchanged
2,048-, 32,768-, and 65,536-family predicate projects. The focused ReleaseFast
union-interner tests passed, including sort/dedup canonicalization, flag
folding, and single and multiple nested unions.

The official screen used three alternating warmup pairs, reversed process
order in every measured pair, retained every sample, and reports untrimmed
mean ± sample standard deviation. Paired intervals are
baseline-minus-candidate:

| Predicate A/B | Metric | Baseline | Candidate | Result | Paired 95% CI |
|---|---|---:|---:|---:|---:|
| Official 2,048 families, 10-pair screen | Wall | 244.818 ± 18.098 ms | 243.463 ± 12.739 ms | 1.0056×; 6/10 wins | -9.806 to +12.516 ms |
| Official 2,048 families, 10-pair screen | CPU | 241.483 ± 14.992 ms | 240.638 ± 11.692 ms | 1.0035×; 6/10 wins | -8.621 to +10.312 ms |

Neither metric cleared zero or established convincing pair direction. The
initial admission gate therefore failed; no scale timing, confirmation, or
competitor checkpoint was run. The source probe was fully reverted and the
accepted binary restored. Raw binaries, exact outputs, and every screen round
are retained under
`bench/vs_tsgo/results/union-flatten-buffer.20260901T063000Z/`.

### Rejected prepared parser source-fact bundle

The post-gate profile attributed separate scan costs to the parser's JSDoc
diagnostic pre-pass and its two virtual-section presence searches. The driver
already computes exact `/**`, `@filename:`, and `@Filename:` presence in the
shared source-marker index. A combined API probe supplied both facts to
driver-created parsers, skipped the JSDoc pre-pass only when absence was
proven, and retained the original discovery scans for every direct parser
caller. This deliberately tested the coherent bundle after the individual
JSDoc and virtual-section probes were inconclusive.

The fixed accepted baseline binary is SHA-256
`ca0bda46834cc05f9c5f57bac5dd5bdec88af388cf6b7c6fc39fcce9b60604ae`;
the experimental candidate was
`7f71fe50dd77096c5be83bc968f0162ab1d09ecaedf1ad29e22c46ec39ecf742`.
Both exited zero with byte-identical empty stdout and stderr on the unchanged
2,048-, 32,768-, and 65,536-family predicate projects. The complete parser and
driver test suites passed, including direct-parser fallback, prepared-source
JSDoc diagnostics, and virtual-section behavior.

The official screen used three alternating warmup pairs, reversed process
order in every measured pair, retained every sample, and reports untrimmed
mean ± sample standard deviation. Paired intervals are
baseline-minus-candidate:

| Predicate A/B | Metric | Baseline | Candidate | Result | Paired 95% CI |
|---|---|---:|---:|---:|---:|
| Official 2,048 families, 10-pair screen | Wall | 259.053 ± 20.896 ms | 258.442 ± 26.555 ms | 1.0024×; 5/10 wins | -15.021 to +16.244 ms |
| Official 2,048 families, 10-pair screen | CPU | 252.151 ± 15.066 ms | 250.722 ± 16.447 ms | 1.0057×; 5/10 wins | -8.944 to +11.802 ms |

Removing all three redundant scans together still produced nearly even pair
direction and no interval support. The initial admission gate therefore
failed; no scale timing, confirmation, or competitor checkpoint was run. The
source probe was fully reverted and the accepted binary restored. Raw
binaries, exact outputs, and every screen round are retained under
`bench/vs_tsgo/results/parser-prepared-source-facts.20260901T070000Z/`.

### JSDoc import-type scan pruning

Commit `532373ee1`, tracked in
[#416](https://github.com/home-lang/home/issues/416), removes a quadratic path
from checked-JavaScript files with many ordinary JSDoc blocks. The
`checkJSDocImportTypeModuleTargets` pass previously parsed every block and then
called `jsDocCommentAnchor` before determining whether the block contained an
`import(...)` or `typeof import(...)` type. That anchor lookup scans the
top-level statements, so a file with many comments and statements but no
import types paid a comments-by-statements cost.

The checker now reuses the exact `import` source marker already built during
source preparation. A source without that substring cannot contain either
import-type spelling, so the pass returns without parsing comments. In a mixed
source that does contain `import`, the checker resolves and reuses an anchor
only after encountering a relevant tag. The tag parser, type lowering,
diagnostic order, and resolution behavior at every relevant tag are unchanged;
no result cache or benchmark-only gate was added.

The locally rebuilt baseline binary is SHA-256
`f8a583689b452b8205ab4ebe977fcdafde85e7f29660bd1661e4a2e9b68277b4`;
the accepted candidate is
`5748ad8edbbb55ad43bfa84a11d3f87c10ae1994e9de01b138640d970977e5f3`.
Both exit zero with byte-identical empty stdout and stderr on the unchanged
official 128-family `checkjs_jsdoc` project and on a deterministic
4,096-family project produced by the same generator with only its family count
changed. Focused `ts_checker` tests matching `JSDoc import` pass, including
cross-module type resolution, script-versus-CommonJS behavior, import tags,
export-equals aliases, and invalid import forms. `zig fmt --check` also passes.

Each A/B set used three alternating warmup pairs, reversed process order in
every measured round, retained every sample, and reports untrimmed mean ±
sample standard deviation. The paired interval is baseline-minus-candidate,
so an interval wholly above zero favors the candidate.

| CheckJS/JSDoc A/B | Metric | Baseline | Candidate | Result | Paired 95% CI |
|---|---|---:|---:|---:|---:|
| Official 128 families, 10-pair screen | Wall | 34.465 ± 0.598 ms | **33.918 ± 0.649 ms** | **1.0161×; 8/10 wins** | **+0.147 to +0.946 ms** |
| Official 128 families, 10-pair screen | CPU | 33.394 ± 0.507 ms | **32.901 ± 0.565 ms** | **1.0150×; 8/10 wins** | **+0.255 to +0.731 ms** |
| Official 128 families, first 30-pair confirmation | Wall | 36.928 ± 12.098 ms | 36.574 ± 14.660 ms | 1.0097×; 23/30 wins | -0.660 to +1.368 ms |
| Official 128 families, first 30-pair confirmation | CPU | 34.785 ± 6.213 ms | 34.809 ± 10.612 ms | 0.9993×; 24/30 wins | -1.694 to +1.645 ms |
| Official 128 families, independent 30-pair confirmation | Wall | 35.297 ± 1.198 ms | **34.793 ± 1.071 ms** | **1.0145×; 20/30 wins** | **+0.035 to +0.971 ms** |
| Official 128 families, independent 30-pair confirmation | CPU | 34.235 ± 1.072 ms | **33.702 ± 0.894 ms** | **1.0158×; 19/30 wins** | **+0.151 to +0.916 ms** |
| Diagnostic 4,096 families, 10 pairs | Wall | 6454.022 ± 78.338 ms | **5312.256 ± 67.011 ms** | **1.2149×; 10/10 wins** | **+1086.273 to +1197.257 ms** |
| Diagnostic 4,096 families, 10 pairs | CPU | 6412.810 ± 62.141 ms | **5281.181 ± 55.399 ms** | **1.2143×; 10/10 wins** | **+1084.489 to +1178.770 ms** |

The first confirmation began during transient shared-host activity and retained
all 30 noisy pairs; it is shown separately and was neither filtered nor pooled.
Because its 12–15 ms standard deviations were far above the screen, a second
independent 30-pair confirmation was run and also retained in full. Its wall
and CPU intervals both clear zero. The unchanged larger diagnostic then
confirmed the expected scaling improvement with 10/10 wins.

The schema-3 competitor checkpoint `20260901T044935Z` independently validated
the official workload, compiler versions, rejection controls, and executable
hashes before and after 30 rotating-order rounds following three warmups:

| Focused workload | tsc 6.0.3 | native TS 7.0.2 | Home 0.1.0 | Home vs fastest competitor |
|---|---:|---:|---:|---:|
| `checkjs_jsdoc` | 241.3 ± 59.1 ms | 64.7 ± 19.5 ms | **39.8 ± 16.9 ms** | **1.63× faster** |

Home had the lower wall time in 29/30 pairs against native TS 7 and all 30
pairs against TS 6; its native-TS-7-minus-Home paired wall interval is
**+21.947 to +27.861 ms**. Process CPU favored Home in 30/30 pairs against
both references. Raw A/B evidence is retained under
`bench/vs_tsgo/results/checkjs-import-type-gate.20260901T043158Z/`; pinned
competitor rounds and verified provenance are under
`bench/vs_tsgo/results/20260901T044935Z/`.

### Program import-resolution reuse

Commit `49641900e`, tracked in
[#416](https://github.com/home-lang/home/issues/416), removes repeated module
resolution from cross-file program-export matching. A single import can be
compared with many candidate CommonJS owners, exported classes, values, types,
or augmentations. Previously every comparison called the external resolver
again and, after a non-match, allocated another `std.fs.path.resolve` result.

The checker now caches the immutable resolution for each exact
`(import node, specifier)` pair. The entry retains both the external-resolver
answer and the existing filesystem fallback, normalized with the same
extension stripping already used by `programModulePathMatches`. It does not
cache a target-specific true/false answer: every candidate owner still goes
through the original exact normalized-path comparison. The cache is cleared
when the source, external resolver, or importer path changes and is released
with the checker.

The fixed accepted baseline binary has SHA-256
`0d2aed7253152acb66965e5148d09c5a50bf7512e9062faecee0daa70caa3f60`;
the candidate is
`ec99b3fcca63f39d97f147bbe2ad5139bf5e53a22f885e25bd1f6eb971386789`.
Both exit 0 with byte-identical empty stdout and stderr on the unchanged
2,048-owner, 2,050-source checked-JavaScript project. That project is the same
deterministic `commonjs_graph` generator scaled only in family count: every
owner exports two concrete class instances and the root consumes their nested
fields through real `require` edges.

Each A/B scale used three alternating warmup pairs, reversed process order in
every measured round, retained every sample, and reports untrimmed mean ±
sample standard deviation. The paired interval is baseline-minus-candidate,
so an interval wholly above zero favors the candidate.

| Scale and gate | Baseline | Candidate | Result | Paired 95% CI |
|---|---:|---:|---:|---:|
| Standard 128 owners, wall, 30 pairs | 36.5 ± 3.1 ms | **30.1 ± 2.0 ms** | **1.212×; 30/30 wins** | **+5.3 to +7.5 ms** |
| Standard 128 owners, CPU, 30 pairs | 51.6 ± 2.9 ms | **44.9 ± 2.9 ms** | **1.149×; 30/30 wins** | **+5.5 to +7.8 ms** |
| Scaled 2,048 owners, wall screen, 10 pairs | 3050.4 ± 111.2 ms | **1433.7 ± 74.6 ms** | **2.128×; 10/10 wins** | **+1516.3 to +1717.2 ms** |
| Scaled 2,048 owners, CPU screen, 10 pairs | 3215.3 ± 99.2 ms | **1609.4 ± 40.6 ms** | **1.998×; 10/10 wins** | **+1540.6 to +1671.2 ms** |
| Scaled 2,048 owners, wall confirmation, 20 pairs | 3471.2 ± 261.2 ms | **1565.2 ± 183.4 ms** | **2.218×; 20/20 wins** | **+1810.0 to +2001.9 ms** |
| Scaled 2,048 owners, CPU confirmation, 20 pairs | 3489.9 ± 166.4 ms | **1705.6 ± 140.4 ms** | **2.046×; 20/20 wins** | **+1728.7 to +1840.0 ms** |

The standard schema-3 competitor checkpoint `20260901T012536Z` independently
validated the unmodified 128-owner workload, verified compiler/tool payloads
before and after timing, and used 30 interleaved rounds after three warmups:

| Focused workload | tsc 6.0.3 | native TS 7.0.2 | Home 0.1.0 | Home vs fastest competitor |
|---|---:|---:|---:|---:|
| `commonjs_graph` | 263.0 ± 48.8 ms | 83.9 ± 27.9 ms | **42.9 ± 10.5 ms** | **1.95× faster** |

Home won 30/30 paired rounds against both references. The paired native-TS-7
minus Home interval is **+32.3 to +49.7 ms**. This focused admission run was
followed by the full qualified snapshot above; it separately isolates the
changed workload on the same host.

Correctness gates passed the full ReleaseFast checker suite, all 95 benchmark
harness tests, and three untimed cross-compiler audits: 198 CommonJS instance
checks, 132 static-require discovery checks, and 720 graph-type checks, with
zero failures against TS 6.0.3, native TS 7.0.2, and Home. Raw local evidence
is retained under
`bench/vs_tsgo/results/commonjs-import-resolution-cache.20260901T011915Z/`;
the pinned-competitor rounds and provenance are in
`bench/vs_tsgo/results/20260901T012536Z/`.

### Prepared source-marker reuse

Commit `5efbd19df`, tracked in
[#416](https://github.com/home-lang/home/issues/416), removes a duplicate
whole-program source scan. `ts_driver.prepareSource` already builds one exact
multi-pattern marker index per file; Program now borrows that immutable index
for its cross-file discovery pass instead of scanning every source again with
a second matcher. The shared index gained the two Program-only markers,
`interface` and `exports`. Pre-compilation callers retain an owned-index path,
and dropping a compilation clears a borrowed view before freeing its storage.
A regression test verifies that prepared files point at the exact
`Compilation.source_markers` index.

The fixed before binary has SHA-256
`150c2206d8d38990a2d0054d03c8939357960d5a26c0e6c0b9ca560d7fc8581b`;
the accepted candidate is
`0d2aed7253152acb66965e5148d09c5a50bf7512e9062faecee0daa70caa3f60`.
Both exit 0 with byte-identical stdout and stderr on the unchanged 32,768- and
65,536-family predicate projects. Focused marker tests, the full ReleaseFast
Program suite, the full ReleaseFast checker suite, and all 95 benchmark-harness
tests pass.

Each A/B scale used three alternating warmup pairs followed by measured pairs
whose process order reversed every round. Times are untrimmed mean ± sample
standard deviation. The paired interval is for before-minus-after time, so an
interval wholly above zero favors the candidate.

| Source-marker A/B | Metric | Before | After | Speedup | After wins | Paired 95% CI |
|---|---|---:|---:|---:|---:|---:|
| 32,768 families, 20 pairs | Wall | 5389.9 ± 460.6 ms | **4961.4 ± 296.3 ms** | **1.086×** | 19/20 | +242.7 to +614.2 ms |
| 32,768 families, 20 pairs | CPU | 5256.2 ± 355.2 ms | **4856.8 ± 236.2 ms** | **1.082×** | 19/20 | +255.4 to +543.4 ms |
| 65,536 families, 20 pairs | Wall | 10967.9 ± 968.4 ms | **10533.7 ± 979.8 ms** | **1.041×** | 12/20 | +4.4 to +864.0 ms |
| 65,536 families, 20 pairs | CPU | 10703.8 ± 782.2 ms | **10202.3 ± 746.9 ms** | **1.049×** | 16/20 | +187.9 to +815.0 ms |

The 65,536-family wall result is noisy because unrelated builds began during
the run. No sample was removed; both its wall and process-CPU intervals remain
positive. A separate 10-pair screen at 32,768 families also favored the
candidate on wall (1.035×, 9/10, CI +62.7 to +294.8 ms) and CPU (1.047×,
9/10, CI +132.1 to +333.0 ms). Raw A/B evidence is retained in
`bench/vs_tsgo/results/program-source-marker-reuse.Ii55xS/`.

Two marker-index follow-ups were measured and rejected. First, 39 independent
exact `indexOf` searches were compared directly with the single Aho–Corasick
pass on the unchanged 100,993,656-byte source. Each invocation used ten
alternating in-process rounds. The current pass averaged 311.855, 266.118, and
268.457 ms across three invocations; independent searches took 1367.862,
1389.771, and 1424.940 ms. Replacing the combined pass would be roughly five
times slower, so no production candidate was created.

Second, the 244-state automaton was specialized to `u8` transitions while
retaining `u16` for larger generic matcher instantiations. Its direct marker
times improved to 240.446, 250.990, and 240.570 ms, and the focused 3/3 tests
plus exact compiler output at both scales passed. The fixed compiler candidate
(`733a59fe4fcb1cadf0cd5b0c23d2bdb6af9af26499a33230c4c2379e638422b3`)
initially showed a 1.0085× wall and 1.0084× CPU improvement in ten pairs. The
prespecified 20-pair confirmation did not reproduce a reliable whole-compiler
win: wall was 4553.0 ± 160.8 ms before versus 4523.3 ± 139.6 ms after
(1.0066×, 10/20, paired interval -17.5 to +77.0 ms), while CPU was
4529.0 ± 149.5 ms versus 4502.1 ± 135.6 ms (1.0060×, 10/20, interval -13.6
to +67.4 ms). The representation change was fully reverted. Raw rounds remain
under `bench/vs_tsgo/results/source-marker-state-width.iZsnJ1/`.

Two exact prefix-trie replacements were also measured and rejected. Unlike the
39-search probe, each trie still made one outer pass over the source: the first
row stayed hot, and deeper rows were visited only after a real marker prefix.
The second version additionally stored the marker set reachable below each
state so already-found prefix subtrees could be skipped. Isolated ten-round
screens on the unchanged 100,993,656-byte source suggested substantial local
scan savings: the accepted Aho–Corasick binary measured 390.109 ms in that
session, the plain trie 148.670 ms, and the pruned trie 96.587 ms. These
single-binary screens were used only to decide whether to build full compiler
candidates; host load moved between invocations, so they are not acceptance
evidence.

The fixed baseline remained
`0d2aed7253152acb66965e5148d09c5a50bf7512e9062faecee0daa70caa3f60`.
The plain-trie compiler was
`e07847318a52844f4222433db674027b9c2a4604cea3963f496a09c489da2e1c`;
the pruned-trie compiler was
`1657f5c3532fcfd2d4fe97ef3a2754ff62f128fc2c9055f987e5aaa5d619ffbb`.
Both candidates exited 0 with byte-identical stdout and stderr at 32,768 and
65,536 families. The focused marker tests, full ReleaseFast checker suite,
full ReleaseFast Program suite, and all 95 harness tests passed for each
candidate.

Every A/B below used three alternating warmup pairs, reversed process order on
each measured round, and retained every sample. The interval is paired
baseline-minus-candidate time; an interval crossing zero fails admission.

| Trie probe | Metric | Baseline | Candidate | Speedup | Candidate wins | Paired 95% CI |
|---|---|---:|---:|---:|---:|---:|
| Plain trie, 32,768 screen, 10 pairs | Wall | 4823.2 ± 191.1 ms | 4831.4 ± 239.8 ms | 0.9983× | 4/10 | -83.6 to +67.2 ms |
| Plain trie, 32,768 screen, 10 pairs | CPU | 4776.5 ± 165.5 ms | 4774.2 ± 209.0 ms | 1.0005× | 4/10 | -69.9 to +74.5 ms |
| Plain trie, 32,768 confirmation, 20 pairs | Wall | 4827.5 ± 324.7 ms | 4770.7 ± 310.9 ms | 1.0119× | 14/20 | -8.0 to +121.5 ms |
| Plain trie, 32,768 confirmation, 20 pairs | CPU | 4754.0 ± 256.0 ms | 4707.1 ± 269.6 ms | 1.0100× | 13/20 | -8.4 to +102.2 ms |
| Plain trie, 65,536 screen, 10 pairs | Wall | 10054.7 ± 488.8 ms | 9711.8 ± 417.9 ms | 1.0353× | 7/10 | +69.7 to +616.3 ms |
| Plain trie, 65,536 screen, 10 pairs | CPU | 9920.3 ± 424.1 ms | 9597.7 ± 362.6 ms | 1.0336× | 8/10 | +84.3 to +561.0 ms |
| Pruned trie, 32,768 screen, 10 pairs | Wall | 4666.1 ± 238.8 ms | 4628.9 ± 239.4 ms | 1.0080× | 5/10 | -70.4 to +144.7 ms |
| Pruned trie, 32,768 screen, 10 pairs | CPU | 4615.8 ± 206.1 ms | 4561.1 ± 167.1 ms | 1.0120× | 6/10 | -28.9 to +138.2 ms |
| Pruned trie, 65,536 screen, 10 pairs | Wall | 9417.7 ± 179.4 ms | 9318.2 ± 165.7 ms | 1.0107× | 4/10 | -116.6 to +315.6 ms |
| Pruned trie, 65,536 screen, 10 pairs | CPU | 9355.6 ± 162.9 ms | 9252.8 ± 145.2 ms | 1.0111× | 4/10 | -91.5 to +297.0 ms |

The plain trie produced one positive larger-scale screen, but its independent
32,768-family confirmation remained inconclusive. The pruned variant did not
reproduce the larger-scale interval and also remained inconclusive at 32,768.
Neither candidate met the whole-compiler admission rule, so both were fully
reverted and the accepted Aho–Corasick implementation remains in production.
Raw evidence is retained under
`bench/vs_tsgo/results/source-marker-trie.20260831T153305.99359/` and
`bench/vs_tsgo/results/source-marker-pruned-trie.20260831T160024.69935/`.

A parser-local exact-name cache was measured next and rejected. The 64-entry
direct-mapped cache retained source offsets, the exact Wyhash, and the stable
`StringId`; a possible hit still required equal length and full source-byte
equality. A miss used the same precomputed hash for the canonical shared
interner lookup, so identity, ownership, and concurrent publication remained
unchanged. The focused ReleaseFast parser and string-interner suites passed,
and the fixed candidate exited 0 with byte-identical stdout and stderr at both
large scales. Its SHA-256 was
`60ceb2f534ee01859e27f4ac3fabbd6630679b7361e90852f423bbdec087d97a`
against baseline
`0d2aed7253152acb66965e5148d09c5a50bf7512e9062faecee0daa70caa3f60`.

The 32,768-family screen used three alternating warmup pairs and ten measured
pairs with reversed order and no filtering. Wall time was 4716.3 ± 154.9 ms
for the baseline versus 4721.7 ± 276.3 ms for the candidate (0.9989×, 5/10
candidate wins, paired interval -123.8 to +112.9 ms). Process CPU was
4665.3 ± 127.3 ms versus 4666.0 ± 234.1 ms (0.9999×, 5/10, interval -99.6
to +98.2 ms). The initial gate failed, so no confirmation or 65,536 timing was
run. The cache and prehashed public API were fully reverted. Raw evidence is
retained under
`bench/vs_tsgo/results/parser-local-interner-cache.20260831T162449.18110/`.

Conservative source-marker gates around declaration-space sibling passes were
also measured and rejected. The candidate skipped namespace, class/interface,
enum, or type-alias merge scans only when attached source made that declaration
kind impossible; marker false positives retained the existing scan, and
source-less checker callers retained every pass. The merge-focused ReleaseFast
checker gate passed, and the fixed compiler produced byte-identical output at
both large scales. Candidate SHA-256 was
`41b9d70b977818d1548ae375d98ff3858a4a02e266b11c40130babfc6b984ad5`
against baseline
`0d2aed7253152acb66965e5148d09c5a50bf7512e9062faecee0daa70caa3f60`.

The 32,768-family initial screen retained all ten reversed-order pairs after
three alternating warmup pairs. Wall time regressed from 4699.2 ± 166.2 ms to
4810.0 ± 287.3 ms (0.9770×, 3/10 candidate wins, paired interval -318.8 to
+97.1 ms). Process CPU moved from 4656.6 ± 143.0 ms to 4736.5 ± 221.4 ms
(0.9831×, 3/10, interval -248.6 to +88.7 ms). The initial gate failed, so no
confirmation or 65,536 timing was run; the gates were fully reverted. Raw
evidence remains under
`bench/vs_tsgo/results/declaration-pass-gates.20260831T163650.42200/`.

After accepting the program import-resolution cache, a fresh sample of the
current binary on the unchanged 32,768-family predicate project confirmed that
the earlier source-preparation hotspot had moved: `ts_driver.prepareSource`
fell from 316 to 23 exclusive samples. Repeated structural annotation lookup
was now visible at 68 exclusive samples in
`visibleAnnotatedIdentifierTypeNode`. A 256-entry checker-local direct-mapped
cache was tested for that exact `(identifier node -> annotation node or miss)`
query. Hits verified the full NodeId, collisions used the unchanged parent
walk, the cache allocated no memory, and source or bound-module replacement
cleared every slot.

The fixed accepted baseline was
`ec99b3fcca63f39d97f147bbe2ad5139bf5e53a22f885e25bd1f6eb971386789`;
the cache candidate was
`5e0969b8ee1cf0fb2716e40678327f6e99a346aa26c16ed50f8c906f9b818353`.
Both exited 0 with byte-identical empty stdout and stderr on the 32,768-family
project, and the focused ReleaseFast type-predicate checker gate passed. The
screen retained all ten reversed-order pairs after three alternating warmup
pairs. Wall time was 5155.6 ± 318.3 ms for the baseline versus
5175.6 ± 235.3 ms for the candidate (0.9961×, 5/10 candidate wins, paired
interval -295.3 to +255.3 ms). Process CPU was 5024.3 ± 250.2 ms versus
5014.0 ± 151.9 ms (1.0021×, 5/10, interval -181.4 to +202.1 ms). Both
intervals cross zero and wall mean regressed, so the cache was fully reverted
without a confirmation or larger-scale run. Raw evidence remains under
`bench/vs_tsgo/results/visible-annotation-hot-cache.20260901T020323Z/`; the
fresh accepted-binary profile is under
`bench/vs_tsgo/results/predicate-current-profile.20260901T014600Z/`.

### Dependency-free declaration schemas

Commit `e0f2fb6d7`, tracked in
[#416](https://github.com/home-lang/home/issues/416), avoids constructing the
program declaration-schema graph when the resolved program has no file
dependencies. Those schemas transfer types across file boundaries. A program
with no resolved dependency has no cross-file consumer: local declarations
continue through their owner's HIR and symbol tables, global scripts use the
bound-global index, and CommonJS uses its separate program facts. Any resolved
file dependency retains the complete existing collector. The full export
snapshot helper is also unchanged for callers that explicitly request it.

The regression proves both sides of that boundary. Checking-time collection is
empty for a dependency-free generic module, while its explicit export snapshot
still contains the factory value and interface type. A full check retains local
generic inference, emits the deliberate TS2322 control, and does not emit the
TS2304 missing-name failure. The ReleaseFast Program suite, focused
type-predicate checker suite, all **95/95** harness tests, and every positive and
negative admission gate for all 20 benchmark workloads pass.

The immutable baseline is SHA-256
`ec99b3fcca63f39d97f147bbe2ad5139bf5e53a22f885e25bd1f6eb971386789`;
the accepted candidate is
`83f48045ba8dc697177eb2d6d453409cb06ae44167d094b6d70ed6e1dec25e7e`.
Both exit zero with byte-identical empty stdout and stderr on the official
2,048-family predicate workload and unchanged 32,768- and 65,536-family scale
projects. The official `recursive_generics` output is also exact.

The decisive unchanged official `type_predicates_large` A/B retained all 30
reversed-order pairs after three alternating warmup pairs. No sample was
filtered. Wall time falls from **258.315 ± 7.221 ms** to
**246.859 ± 4.718 ms** (**1.0464×**, 30/30 candidate wins), with a paired 95%
interval of **+9.586 to +13.325 ms**. Process CPU falls from
**256.033 ± 7.037 ms** to **244.838 ± 4.605 ms** (**1.0457×**, 30/30), with
an interval of **+9.428 to +12.962 ms**.

The noisy larger-scale screens are retained rather than pooled or trimmed.
At 32,768 families, wall measured 4498.5 ± 291.2 ms versus
4511.5 ± 502.2 ms and CPU measured 4456.8 ± 252.2 ms versus
4389.7 ± 341.0 ms; both paired intervals cross zero. At 65,536 families, the
candidate has lower means—10363.7 ± 621.5 ms versus 10156.9 ± 1021.6 ms wall,
and 10160.0 ± 414.0 ms versus 9975.6 ± 900.0 ms CPU—but both intervals again
cross zero. The short `recursive_generics` confirmation is also neutral. These
secondary observations neither strengthen nor weaken the accepted standard
workload result. Raw evidence is under
`bench/vs_tsgo/results/dependency-free-declarations.20260901T022352Z/`.

### Source-marker root-gap fast-forward

Commit `7ca9946c8`, tracked in
[#416](https://github.com/home-lang/home/issues/416), keeps the accepted exact
Aho–Corasick source-marker matcher and fast-forwards only gaps that are proven
to remain at its root. The matcher computes the distinct first bytes of every
registered marker at compile time. While the automaton is at state zero,
`std.mem.indexOfAnyPos` skips to the next possible first byte in bulk. Every
possible prefix, failure transition, overlapping match, suffix match, and
first-occurrence position still uses the unchanged automaton. This is not the
previous rejected trie replacement and does not add a semantic feature gate.

The immutable accepted baseline is SHA-256
`83f48045ba8dc697177eb2d6d453409cb06ae44167d094b6d70ed6e1dec25e7e`;
the root-gap candidate is
`60e10affa923acd3265511f91f248277cf7bbf70e28508ff1bf903b8761bf2a2`.
Both exit zero with byte-identical empty stdout and stderr on the official
2,048-family and unchanged 65,536-family predicate projects. The focused exact
marker tests, full ReleaseFast checker, driver, and Program suites, all
**95/95** harness tests, and every positive and negative admission gate for all
20 workloads pass.

The unchanged official `type_predicates_large` A/B retained all 30
reversed-order pairs after three alternating warmup pairs. No sample was
filtered. Wall time falls from **240.611 ± 3.256 ms** to
**237.311 ± 5.460 ms** (**1.0139×**, 27/30 candidate wins), with a paired 95%
interval of **+1.558 to +5.040 ms**. Process CPU falls from
**238.928 ± 3.153 ms** to **235.592 ± 4.990 ms** (**1.0142×**, 26/30), with
an interval of **+1.716 to +4.956 ms**.

The independent 65,536-family screen retained all ten pairs with the starting
order reversed. Wall falls from 8747.426 ± 109.663 ms to
8626.257 ± 116.604 ms (**1.0140×**, 8/10), with a paired interval of
**+40.535 to +201.804 ms**. Process CPU falls from
8715.280 ± 81.749 ms to 8591.872 ± 96.556 ms (**1.0144×**, 9/10), with an
interval of **+65.075 to +181.743 ms**. Raw exact outputs and every A/B round
remain under
`bench/vs_tsgo/results/source-marker-root-skip.20260901T025847Z/`.

The independent focused three-compiler checkpoint `20260901T031352Z` compares
version-verified TS 6.0.3, native TS 7.0.2, and the latest immutable Home binary:

| Focused `type_predicates_large` | tsc 6.0.3 | native TS 7.0.2 | Home 0.1.0 | Home vs fastest competitor |
|---|---:|---:|---:|---:|
| 30 interleaved rounds | 1242.7 ± 414.8 ms | 413.2 ± 84.6 ms | **267.8 ± 36.4 ms** | **1.54× faster** |

Home beats native TS 7 in 29/30 focused pairs and TS 6 in 30/30. The paired
native-TS-7-minus-Home 95% interval is +111.6 to +179.2 ms. All 30 round files
/ 90 successful finite samples are retained, and compiler provenance is
unchanged before and after measurement. The immediately preceding complete
20-workload checkpoint is the [current snapshot](#current-snapshot); all 20
admission gates pass on this newer binary, while its focused timing remains
separate rather than replacing or being pooled with that full checkpoint.

### Rejected larger string-interner hint

The post-root-gap profile still showed the shared string interner as a material
owned cost, so its existing exact 64-entry direct-mapped hint was tested at 256
entries per shard. This is distinct from the earlier rejected parser-local
cache: it changes only the capacity of the canonical shared hint. Every
possible hit still takes the shard lock and verifies full byte equality; every
miss still uses the unchanged prehashed canonical table. The tested size would
increase total hint storage from 32 KiB to 128 KiB.

The immutable baseline is SHA-256
`60e10affa923acd3265511f91f248277cf7bbf70e28508ff1bf903b8761bf2a2`;
the fixed 256-entry candidate is
`793144e3a19604c96673c97d42fdf6d63a93ba27fc48b8615841adea73165b1e`.
Both exit zero with byte-identical empty stdout and stderr on the official
2,048-family and unchanged 32,768-family predicate projects. The ReleaseFast
string-interner suite also passes.

The 32,768-family screen retained all ten reversed-order pairs after three
alternating warmup pairs, with no filtering. Wall time regressed from
7727.518 ± 414.303 ms to 8069.492 ± 701.373 ms (0.9576× baseline/candidate,
4/10 candidate wins), with a baseline-minus-candidate paired 95% interval of
-706.254 to +22.306 ms. Process CPU regressed from 6215.600 ± 107.917 ms to
6307.875 ± 115.115 ms (0.9854×, 4/10), with an interval of -209.220 to
+24.670 ms. The initial gate therefore failed; no confirmation was run, and
the 64-entry production capacity was restored. Raw exact outputs, binaries,
and every measured pair remain under
`bench/vs_tsgo/results/string-interner-cache-capacity.20260901T033000Z/`.

### Rejected special-identifier classification

The same post-root-gap profile attributed part of `mem.eqlBytes` to
`typeOfIdentifier`, which tests ordinary names against `this`, `await`,
`arguments`, and `new.target` along different fallback paths. An exact probe
classified those mutually exclusive spellings once by length plus full byte
equality and reused the result in the existing branches. It added no cache or
feature gate and did not change lookup or diagnostic order.

The immutable baseline is SHA-256
`60e10affa923acd3265511f91f248277cf7bbf70e28508ff1bf903b8761bf2a2`;
the fixed candidate is
`340bcab7683acf3ab4e1b951c13dc6814818e036535fae4c65904e24d4a19721`.
Both exit zero with byte-identical empty stdout and stderr on the official
2,048-family and unchanged 32,768-family predicate projects.

The official-workload screen retained all ten reversed-order pairs after three
alternating warmup pairs, with no filtering. Wall measured
246.588 ± 9.418 ms for the baseline versus 243.908 ± 5.698 ms for the
candidate (1.0110×, 6/10 candidate wins), with a paired 95% interval of
-6.114 to +11.473 ms. Process CPU measured 244.176 ± 8.272 ms versus
241.710 ± 5.238 ms (1.0102×, 6/10), with an interval of -5.188 to
+10.121 ms. The means were lower but neither interval nor pair direction
cleared the initial gate, so no larger-scale timing or confirmation was run and
the probe was fully reverted. Raw binaries, exact outputs, and every screen
round remain under
`bench/vs_tsgo/results/special-identifier-classification.20260901T035000Z/`.

### Rejected declaration-map pre-sizing

`checkDeclarationSpaceDiagnosticsImpl` owns three temporary hash maps for
ordinary declaration collisions, interface merges, and function
implementations. A semantic-neutral probe counted the corresponding HIR
declaration kinds, reserved each map's final upper-bound capacity, and then ran
the unchanged diagnostic passes and insertion logic. The additional count was
linear, allocation failure remained explicit, and diagnostic contents and
order were unchanged.

The immutable baseline is SHA-256
`60e10affa923acd3265511f91f248277cf7bbf70e28508ff1bf903b8761bf2a2`;
the fixed candidate is
`c01cd4bf76e85650830292dc52d6ed958bf6166ca34ff6586695cfd2735b9dde`.
Both exit zero with byte-identical empty stdout and stderr on the official
2,048-family predicate project.

The initial screen retained ten reversed-order pairs after three alternating
warmup pairs, with no filtering. Wall measured 327.868 ± 16.578 ms versus
318.948 ± 17.585 ms (1.0280×, 8/10 candidate wins), but its paired 95%
interval was -10.141 to +27.981 ms. CPU measured 316.272 ± 13.006 ms versus
307.522 ± 9.762 ms (1.0285×, 8/10), with an interval of -2.358 to
+19.858 ms. That signal admitted an independent confirmation; it was not
pooled with the screen.

The confirmation retained all 30 reversed-order pairs after a fresh set of
three alternating warmup pairs. Wall measured 250.214 ± 9.998 ms versus
248.246 ± 13.890 ms (1.0079×, 23/30), with a paired interval of -3.764 to
+7.700 ms. CPU measured 246.950 ± 8.510 ms versus
244.955 ± 10.931 ms (1.0081×, 24/30), with an interval of -2.315 to
+6.305 ms. The independent confirmation did not clear the paired-mean rule,
so the probe was fully reverted and no scale timing was run. Raw binaries,
exact output, and every screen and confirmation round remain under
`bench/vs_tsgo/results/declaration-map-presize.20260901T041500Z/`.

### Rejected identifier declaration-slot reuse

The accepted profile showed material exclusive time in `typeOfIdentifier`.
That function can ask whether the same immutable HIR node is a declaration
name at many fallback branches, so an exact probe evaluated
`isDeclNameSlot(node)` once at its first use and reused the boolean in the 36
later branches. Early `await`, private-name, constructor-field, and `this`
exits remained before the computation. No cache, semantic gate, lookup
reordering, or diagnostic reordering was introduced.

The immutable baseline is SHA-256
`60e10affa923acd3265511f91f248277cf7bbf70e28508ff1bf903b8761bf2a2`;
the fixed candidate is
`6df9a6db988911be719b9f0079296fa815b18a6d0e17d60e629140472de37b81`.
Both exit zero with byte-identical empty stdout and stderr on the official
2,048-family and unchanged 32,768-family predicate projects.

The official-workload screen retained all ten reversed-order pairs after three
alternating warmup pairs, with no filtering. Wall time regressed from
292.454 ± 28.421 ms to 300.577 ± 30.022 ms (0.9730× baseline/candidate,
4/10 candidate wins), with a paired 95% interval of -33.078 to +16.832 ms.
Process CPU was effectively flat to worse at 283.171 ± 19.615 ms versus
284.514 ± 15.643 ms (0.9953×, 5/10), with an interval of -19.859 to
+17.172 ms. The initial gate failed, so no confirmation or scale timing was
run and the probe was fully reverted. Raw binaries, exact outputs, and every
screen round remain under
`bench/vs_tsgo/results/identifier-decl-slot-reuse.20260901T035734Z/`.

A 2026-09-12 profile follow-up independently rediscovered the same exact probe
against current parent `b164b747e`. The ReleaseFast object confirmed that the
change removed 36 call relocations to `isDeclNameSlot`, and both binaries again
accepted the unchanged generated predicate project silently. The larger frozen
diagnostic workload contained 32,768 families in 50,252,408 bytes with SHA-256
`d924932d25ebc8b6f8e78c89e0da6922ef8436f588d01d1879c5b7c16af0c9af`.
Its 20 alternating AB/BA pairs retained every sample after three warmups each:
the parent measured 6.207927 ± 1.853128 seconds and the candidate measured
5.625798 ± 0.978428 seconds, with 15/20 candidate wins. The paired improvement
was 0.582129 seconds, but its 95% interval was -0.055687 to +1.219945 seconds,
so it still failed the pre-existing paired-mean admission rule. The candidate
was reverted again. The run stayed under the fixed 3,840 MB ceiling (996 MB
observed peak; 35% host low-water), and no official competitor checkpoint was
admitted from this inconclusive scale retest.

### Rejected parser identifier escape-flag reuse

The scanner already records whether an identifier token contains a consumed
Unicode escape. `internToken` nevertheless searched the raw identifier slice
again for `\\` before entering its existing escape decoder. A one-line exact
probe reused `TokenFlags.has_escape` for that decision while retaining the
same `.identifier` kind guard, decoder, allocation fallback, and interner call.
Scanner behavior and token layout were unchanged.

The immutable baseline is SHA-256
`60e10affa923acd3265511f91f248277cf7bbf70e28508ff1bf903b8761bf2a2`;
the fixed candidate is
`59beef049b14e6a8ebc314f1c7ff408f96d3e6d43052d447436b120e63081c56`.
Both exit zero with byte-identical empty stdout and stderr on the official
2,048-family and unchanged 32,768- and 65,536-family predicate projects. The
full ReleaseFast parser suite passes, including bare identifiers, `\\uXXXX`,
brace-form escapes, escaped enum members, and invalid escaped starts.

The official-workload screen retained all ten reversed-order pairs after three
alternating warmup pairs, with no filtering. Wall time regressed from
440.866 ± 24.461 ms to 452.033 ± 25.669 ms (0.9753× baseline/candidate,
5/10 candidate wins), with a paired 95% interval of -34.149 to +11.814 ms.
Process CPU regressed from 377.824 ± 11.665 ms to 383.668 ± 19.005 ms
(0.9848×, 5/10), with an interval of -24.280 to +12.592 ms. The initial gate
failed, so no confirmation or scale timing was run and the probe was fully
reverted. Raw binaries, exact outputs, and every screen round remain under
`bench/vs_tsgo/results/parser-escape-flag-reuse.20260901T040925Z/`.

## Linux ARM64 container checkpoint

Measured 2026-08-29 at commit `6ac9b5e59` in a pinned Debian Bookworm
container on a native Linux ARM64 ext4 volume. The host was an Ubuntu 26.04
ARM64 Lima/VZ VM with 4 vCPUs and 8 GB RAM; the measured container reported
Linux 7.0.0-28-generic, aarch64, and glibc 2.36. The container image is
`node:24.18.0-bookworm-slim` at digest
`sha256:6f7b03f7c2c8e2e784dcf9295400527b9b1270fd37b7e9a7285cf83b6951452d`,
with Node 24.18.0, Hyperfine 1.20.0, and Python 3.11.2. The complete raw-result
identifier is `20260829T035150Z`.

The same admission rules, generated corpus, and 30-round interleaved schedule
were used with TS **6.0.3**, native TS **7.0.2**, and Home. All **600 round
files / 1,800 successful finite samples** are retained without filtering.
Compiler and tool provenance was hashed before admission and again after
measurement. The Home ARM64 ReleaseFast binary has SHA-256
`9512c02505248c031beb75ab304e65bde9e018bf93d340adf56bd164a5eb31bb`.

| Workload | tsc 6.0.3 | native TS 7.0.2 | Home 0.1.0 | Home vs fastest competitor |
|---|---:|---:|---:|---:|
| `checkjs_jsdoc` | 241.3 ± 9.7 ms | 38.0 ± 1.4 ms | **37.3 ± 0.9 ms** | **1.02× faster; narrow** |
| `class_hierarchy` | 208.0 ± 2.7 ms | 35.5 ± 1.1 ms | **28.1 ± 0.3 ms** | **1.27× faster** |
| `commonjs_graph` | 162.9 ± 2.9 ms | 29.1 ± 1.4 ms | **27.7 ± 0.6 ms** | **1.05× faster** |
| `control_flow` | 221.3 ± 6.1 ms | 42.8 ± 1.5 ms | **36.3 ± 4.1 ms** | **1.18× faster** |
| `deep_types` | 137.4 ± 2.6 ms | 34.3 ± 1.0 ms | **25.0 ± 0.3 ms** | **1.37× faster** |
| `destructuring` | 155.3 ± 2.6 ms | 30.4 ± 1.3 ms | **19.5 ± 0.3 ms** | **1.56× faster** |
| `generic_calls` | 202.2 ± 2.7 ms | 38.0 ± 0.9 ms | **21.9 ± 0.5 ms** | **1.74× faster** |
| `import_graph` | 149.1 ± 47.3 ms | 28.7 ± 5.3 ms | **20.9 ± 1.3 ms** | **1.37× faster** |
| `interface_composition` | 235.6 ± 23.6 ms | 47.5 ± 1.6 ms | **44.6 ± 0.9 ms** | **1.07× faster** |
| `many_files` | 230.1 ± 29.7 ms | 35.5 ± 3.2 ms | **22.4 ± 0.7 ms** | **1.58× faster** |
| `null_safe_access` | 223.8 ± 8.9 ms | 42.0 ± 1.0 ms | **40.7 ± 0.8 ms** | **1.03× faster; narrow** |
| `overload_resolution` | 233.6 ± 3.3 ms | 49.1 ± 2.4 ms | **29.7 ± 0.8 ms** | **1.65× faster** |
| `recursive_generics` | 159.6 ± 2.9 ms | 54.5 ± 1.0 ms | **27.5 ± 0.2 ms** | **1.98× faster** |
| `reexport_graph` | 97.7 ± 3.0 ms | 22.2 ± 1.1 ms | **11.8 ± 0.6 ms** | **1.88× faster** |
| `startup` | 52.9 ± 1.1 ms | 17.9 ± 0.8 ms | **0.8 ± 0.1 ms** | **21.67× faster** |
| `structural_objects` | 212.2 ± 3.6 ms | 42.1 ± 1.4 ms | **29.3 ± 0.5 ms** | **1.44× faster** |
| `tsx_components` | 180.5 ± 2.9 ms | 29.6 ± 0.9 ms | **21.7 ± 0.4 ms** | **1.37× faster** |
| `type_predicates` | 283.4 ± 3.8 ms | 57.0 ± 0.9 ms | **44.3 ± 0.5 ms** | **1.29× faster** |
| `type_predicates_large` | 1181.5 ± 27.8 ms | 388.4 ± 13.8 ms | **355.5 ± 12.2 ms** | **1.09× faster** |
| `variadic_tuples` | 316.4 ± 68.2 ms | 67.0 ± 7.5 ms | **47.2 ± 7.5 ms** | **1.42× faster** |

Home records lower means on **20/20 admitted workloads** in this Linux
checkpoint. The narrow CheckJS row has 19/30 paired wins and medians of 37.0
ms for Home versus 37.6 ms for the fastest competitor; it is documented as a
narrow result, not a universal claim. Null-safe access has 25/30 paired wins
and CommonJS has 27/30. All other rows have at least 29/30 paired wins.

## Fairness and measurement

- Compiler versions are pinned in `bench/vs_tsgo/corpus.toml`. The runner rejects
  an installed TS 6 or TS 7 version that differs from its exact pin before
  recording results; rerun `setup` after changing a pin. Native TS 7 is the
  single `tsgo` entry, not an additional competitor.
- JavaScript TypeScript 6 and native TypeScript 7 are installed in separate
  tool prefixes so npm cannot replace one implementation with the other.
- The corpus is generated deterministically and is shared by all compilers.
- Every command receives `--noEmit -p <same tsconfig.json>`.
- Every project enables `strict`, `noLib`, `skipLibCheck`, and `pretty: false`.
  `noLib` isolates frontend work from differences in bundled standard-library
  size and availability.
- Before timing, every compiler must exit successfully without stdout or
  stderr. A compiler cannot win by rejecting or skipping the input.
- Destructuring also has five automatic negative controls in an untimed
  temporary project copy: nested properties, tuple elements, object-rest
  fields, defaults, and omitted rest properties must produce exactly four
  `TS2322` diagnostics and one `TS2339` in every compiler.
- Both predicate sizes have four automatic controls inside the guard branch and
  after the assertion call. Invalid narrowed-property assignments and reads
  of excluded union members must produce two `TS2322` and two `TS2339`
  diagnostics in every compiler, using an untimed temporary project copy.
- Both ES-module graphs must reject a wrong imported-property assignment and a
  missing-member read. Variadic tuples have equivalent tuple-element controls.
- `commonjs_graph` uses a temporary copy and requires exactly three `TS2322`
  and three `TS2339` diagnostics, distributed across the first, middle, and
  last checked owner. Timing cannot begin, or create its result directory,
  unless every selected workload passes every applicable control in all three
  compilers.
- Measurements are process-cold and filesystem-cache-warm. Each timed sample
  launches a new compiler process after explicit warmups.
- A measured round contains all three compilers. Their order rotates each round
  so changing workstation load cannot consistently favor one implementation.
- Hyperfine supplies the process timer. Reported uncertainty is the sample
  standard deviation, not a confidence interval.

The Linux checkpoint uses the repository Dockerfile from the repository root.
The root `.dockerignore` limits the build context to the entrypoint, while the
repository and a native Linux ReleaseFast `home-tsc` are mounted at runtime.
The benchmark workspace must live on a native Linux filesystem; macOS-shared
VirtioFS measurements are diagnostic only because their file-access behavior
is not representative. The entrypoint installs the exact manifest pins,
regenerates the corpus, runs admission, and then measures. This container path
is tracked in [issue #464](https://github.com/home-lang/home/issues/464).

## Workloads

| Workload | Generated shape | Cost represented |
|---|---:|---|
| `startup` | One small source file plus a minimal declaration file | CLI and frontend startup |
| `many_files` | 256 independent source files plus a minimal declaration file | File discovery, loading, scheduling, parsing, and checking many modules |
| `deep_types` | One source file with 240 repeated generic models | Conditional, mapped, indexed, recursive, and template-literal type work |
| `import_graph` | 128 modules in a relative-import chain | Module resolution, export lookup, import closure, and cross-file generic checking |
| `reexport_graph` | 64 leaf modules projected through eight barrels | Recursive export-star projection, module resolution, and ambiguity checking |
| `tsx_components` | One module with 256 typed generic component declarations and JSX trees | TSX scanning, parsing, contextual props, expressions, and checking |
| `generic_calls` | One module with 256 typed generic call groups | Constrained inference, `keyof`, indexed access, mapped returns, and contextual callbacks |
| `control_flow` | One module with 256 exhaustive discriminated-union functions | Narrowing, branch joins, definite assignment, exhaustive switches, property reads, and typed object returns |
| `type_predicates` | One module with 256 independent predicate families | User-defined type predicates, assertion functions, call-driven narrowing, nested property reads, and typed consumption |
| `type_predicates_large` | The identical generator with 2,048 independent predicate families | Scaling behavior at eight times the original size, with the same feature mix, compiler options, and negative controls |
| `null_safe_access` | One module with 256 independent nullable object families | Optional property, element, and call chains, nullish coalescing, non-null assertions, and typed consumption |
| `destructuring` | One module with 128 independent object families | Nested object and tuple bindings, defaults, object rest, spread reconstruction, and typed consumption |
| `overload_resolution` | One module with 128 groups of eight typed overload calls | Literal-discriminated overload selection, generic inference, object and tuple payloads, callbacks, and typed result consumption |
| `class_hierarchy` | One module with 128 independent generic base/derived/interface families | Class heritage resolution, generic substitution, constructors, overrides, protected members, interface compatibility, and typed instance consumption |
| `structural_objects` | One module with 128 independent source/target object families | Nested structural compatibility, optional and readonly members, tuples, intersections, generic function properties, excess source members, assignments, and typed argument passing |
| `interface_composition` | One module with 128 independent generic interface and namespace families | Multi-base interface heritage, repeated declaration merging, namespace/type/value merging, nested exported interfaces, generic functions, structural values, and typed consumption |
| `variadic_tuples` | One module with 256 independent readonly tuple families | Variadic tuple concat, readonly inference, conditional head/tail extraction, generic rest and spread, indexed reads, and typed consumption |
| `checkjs_jsdoc` | One checked-JavaScript module with 128 independent JSDoc families | JSDoc typedefs, constrained templates, callbacks, classes, property reads, and typed consumption |

The suite intentionally uses dependency-free synthetic projects so its inputs
stay stable and auditable. It does not replace benchmarks of pinned real-world
applications. A real project belongs in the suite only when all three compilers
can validate the same source graph and configuration.

## Reproduce

From the repository root:

```sh
./pantry/.bin/zig build home-tsc -Doptimize=ReleaseFast
./bench/vs_tsgo/run.sh setup
./bench/vs_tsgo/run.sh corpus
./bench/vs_tsgo/run.sh cold --runs 30 --warmup 3
./bench/vs_tsgo/run.sh report
```

The harness records compiler versions, host metadata, timing configuration,
and raw per-round Hyperfine JSON under
`bench/vs_tsgo/results/<UTC timestamp>/`. Results are ignored by Git because
they are machine-specific; the reviewed snapshot above is the durable record.

An independent confirmation of a selected workload uses the same validation
and interleaved timing rules:

```sh
./bench/vs_tsgo/run.sh cold --runs 30 --warmup 3 --workload type_predicates_large
```

The selection is recorded in metadata. Repeat `--workload` to select several
cases; omitting it runs the full suite. Targeted runs supplement the full
report, never replace it or justify discarding an earlier result.

## Improvements behind this result

The current result comes from general compiler changes rather than
workload-specific shortcuts:

- release builds use the production thread-safe allocator while Debug retains
  leak detection;
- parser and checker feature probes cache source-level facts instead of
  repeatedly scanning whole files;
- identifier scanning tests the common ASCII continuation case before the
  UTF-8 whitespace tables, while escaped identifiers and non-ASCII whitespace
  retain their complete scanner paths;
- builtin object-type lowering uses an exact index of the 44 supported names
  to reject ordinary user-defined names before the specialized recipe chain;
- driver preparation computes the exact source-marker index once and reuses it
  for conservative directive/reference gates and checker source facts;
- JSDoc and triple-slash reference presence reuse the existing one-pass source
  marker index instead of rescanning large files;
- visible type declarations are indexed per lexical scope while retaining the
  original resolver as an allocation-failure fallback;
- source loading reuses one I/O runtime per compilation;
- string interning computes Wyhash once and reuses it for shard selection,
  optimistic lookup, write-lock verification, and insertion;
- module resolution reuses one filesystem runtime, preserves extension order
  while snapshotting directories, and caches repeated package-boundary queries;
- optimized builds compile sufficiently large programs with a bounded worker
  pool, while small programs remain serial to avoid thread startup overhead;
- cross-file export queries reuse bind-only module analyses and immutable
  per-export answers;
- resolver mutation is synchronized separately from export-analysis caches so
  independent cache misses can parse and bind concurrently;
- export-star ambiguity checks enumerate and cache real projected names instead
  of rescanning modules or guessing from the number of barrel declarations;
- JSX namespace, pragma, and source-feature probes reuse immutable per-source
  facts; and
- recovered parameter annotations are indexed from actual HIR parameter nodes,
  reusing interned parameter names and excluding object-property lookalikes
  while retaining the same source-syntax validation;
- identifier resolution skips evolving-`any` flow walks when the source has no
  eligible declarations, reuses its lexical annotation lookup, and avoids
  declaration scans for function-arity checks against non-callable targets;
- checker compatibility paths use conservative source-feature facts to skip
  impossible UMD, import, CommonJS, namespace, class, enum, and expando scans;
- simple annotated bindings and their active lexical lookups reuse indexed,
  virtual-section-aware declarations and already-resolved types for ordinary
  reads while declared-type lookups retain their full semantic path;
- overload resolution rejects definite exact-literal mismatches before generic
  inference and substitution, while composite, contextual, spread, enum, and
  ambiguous candidates retain the complete resolver; and
- successful class heritage instance, static, and constructor resolutions are
  cached by extends expression while unresolved and forward-reference paths
  retain the complete resolver;
- conservative source facts skip impossible enum and JavaScript prototype
  searches, `this` and `super` member assignments avoid irrelevant function
  expando discovery, and top-level annotation lookup reuses the existing
  virtual-section-aware declaration index; and
- DOM library availability is computed once per source and reused while
  lowering annotations, preserving `@noLib`, `reference lib`, and explicit
  `@lib` semantics without repeatedly scanning the entire file; and
- named types maintain a validated reverse display-name index instead of
  repeatedly iterating the complete forward name table;
- visible namespaces and simple annotated declarations reuse lexical,
  virtual-section-aware indexes, including a conservative dotted-namespace
  fact that avoids impossible fallback scans;
- interface declaration merging records the real predecessor chain so generic
  and non-generic back-patching touches only declarations in the merge; and
- module augmentation, type-alias, and class/interface compatibility paths use
  syntax facts before performing root-level searches, while allocation failure
  retains the original semantic resolver; and
- program-level declaration, namespace, interface, class, and CommonJS
  collectors skip files whose source cannot contain the syntax they collect;
- generic-instantiation inference skips parameters without free type variables,
  while the full recursive inference path remains active for inferable pairs;
- visible same-name values are indexed by lexical container and virtual source
  section;
- function-expando and plain-import recovery stop before scope walks when HIR
  or source facts prove the relevant syntax is absent; and
- checked-JavaScript analysis indexes named JSDoc declarations, prior typed
  assignments, annotated values, and owning functions; reuses immutable
  typedef and callback types; and skips prototype, import, expando, and
  accessibility searches only when exact source facts prove they cannot apply;
- JSDoc parser diagnostics discover tags once per comment and run only the
  semantically applicable validation passes, preserving every individual
  diagnostic scanner for comments that contain its triggering tag; and
- object-rest inference avoids source-annotation recovery only when the source
  binding is already semantically proven non-nullish, retaining the complete
  recovery path for nullable and ambiguous declarations;
- type aliases and parameter annotations use exact-name indexes, root variable
  recovery reuses binder declarations, and direct named object types reuse
  their reverse display-name mapping and successful structural-name matches;
- CommonJS detection matches `require` as an identifier rather than a
  substring, while import, class, enum, namespace, and type-declaration
  fallbacks stop only when conservative source facts make the search
  impossible;
- source-annotation recovery stops when the nearest lexical parameter and its
  following source token prove there is no annotation to recover, while
  explicit annotations, comments, destructuring, and ambiguous syntax retain
  the complete fallback;
- source-function ownership uses sorted nested function spans for first-time
  position queries, preserving the original full scan for malformed crossing
  ranges or allocation failure and the original NodeId tie-breaking; and
- source-parameter recovery lazily caches immutable containment ranges per
  annotation candidate instead of repeating raw source scans for each use,
  with exhaustive position-pair equivalence and source-reset tests; and
- unsuccessful named-object-shape searches are cached separately for each
  class-preference mode, with a generation guard that expires misses when
  a type name is inserted or rebound; and
- function-declaration lookup indexes the first eligible binding per statement
  container, preserving caller scope walks and binder precedence and retaining
  the original scanner on allocation failure;
- named-shape lookup indexes necessary member facts at type-name registration,
  rejecting impossible searches while retaining the original full comparison
  for possible matches, stale facts, and hash collisions;
- member facts also identify candidate names, using the smallest queried
  bucket; unique full matches return directly, while ambiguous matching names
  retain the original table scan and diagnostic-name order;
- local value-declaration lookup indexes first bindings and exact statement
  boundaries per container and virtual section, preserving the original scan
  on allocation failure;
- exact type-name fallback skips never-registered TypeIds using monotonic
  membership, preserving scan order for possible matches and disabling the
  filter if an allocation fails;
- builtin-name membership uses a compile-time static lookup over the unchanged
  spelling list, retaining source-dependent exceptions; and
- `instanceof` fallthrough-join analysis stops before flow and annotation
  lookup when the existing one-pass source marker index proves that spelling
  cannot occur, while sources containing it retain the complete semantic path;
- one- and two-statement lexical containers use the existing bounded direct
  annotated-value scan instead of allocating two persistent hash-index entries,
  while larger containers retain the indexed path and allocation failures still
  retain the direct resolver;
- the lockless relation cache retains a 4,096-entry working set and inserts new
  relations with one hash-table probe instead of two; both relation-cache
  levels reclaim deletion tombstones at existing FIFO eviction boundaries.

### Recovered-parameter index checkpoint

Commit `18bd0c4ee`, tracked by
[#416](https://github.com/home-lang/home/issues/416), replaces the recovered
parameter index's whole-source identifier scan with iteration over actual HIR
parameter nodes. It retains the existing ASCII name, optional marker, type
identifier, and declaration-delimiter checks. The checker reuses each
parameter's interned HIR name, interns only its recovered type name, and no
longer admits object-property syntax as a candidate before containment
filtering.

The isolated Home A/B uses the unchanged 16,384-family predicate stress project
and identical compiler arguments. The exact published strict-marker binary
(SHA-256 `ba83523099e133f1aab69283304f3568c31f947069c29455b849b70eca01b5b6`)
is the baseline; the candidate binary has SHA-256
`faccb14ac520cd8a37d14246635089d36345ddf3c6d40d8630c59fcf5a73849e`.
After three alternating warmup pairs, 20 measured pairs reverse process order
each round. All 40 finite samples are retained.

| 16,384 predicate-family Home A/B | Whole-source baseline | Parameter-node index | Baseline / candidate | Lower candidate time |
|---|---:|---:|---:|---:|
| Same project and settings | 2749.3 ± 27.7 ms | **2717.8 ± 33.4 ms** | **1.0116×** | **16/20 pairs** |

The mean paired reduction is 31.5 ms with a 95% paired t confidence interval of
11.7–51.4 ms; the exact two-sided sign-test result is `p = 0.0118`. A fresh
1 ms sampling profile reduces
`recoveredSourceParameterAnnotationType` leaf samples from 31 to 10; candidate
index construction is below the report's five-sample display threshold. These
diagnostics explain the mechanism; the official cross-compiler results reported
above remain the publication gate.

The independent 30-round confirmation is `20260831T000811Z`: TS 6.0.3 takes
1048.0 ± 23.2 ms, native TS 7.0.2 takes 365.3 ± 6.8 ms, and Home takes
**322.0 ± 5.1 ms**, a **1.13×** lead with 30/30 paired wins. The complete
post-index 20-workload result is `20260831T000957Z`: Home has the lower mean
on 20/20 rows and the lower individual time in 599/600 rounds. Both runs
preserve all samples and verify compiler artifacts before admission and after
measurement; they remain a separate checkpoint rather than being pooled with
the current snapshot.

### `instanceof` fallthrough marker checkpoint

Commit `238cc88fc`, tracked by
[#416](https://github.com/home-lang/home/issues/416), adds the exact
`instanceof` substring to the existing one-pass source marker automaton.
Member-access checking skips its specialized fallthrough-join analysis only
when attached source bytes cannot contain that operator spelling. Sources that
contain it—including conservative comment and string matches—retain the full
flow, declared-annotation, intersection, and class-union checks.

The isolated A/B uses the same unchanged 16,384-family predicate stress project,
which contains no `instanceof` substring. The published HIR-index binary
(SHA-256 `faccb14ac520cd8a37d14246635089d36345ddf3c6d40d8630c59fcf5a73849e`)
is the baseline; the marker candidate has SHA-256
`842310b6c24e1e788c33d756bbff0e7df0b0bc60c261d4dcb8552f8c09ccb2cd`.
After three alternating warmup pairs, 20 measured pairs reverse process order
each round and retain all 40 finite samples.

| 16,384 predicate-family Home A/B | HIR-index baseline | `instanceof` guard | Baseline / candidate | Lower candidate time |
|---|---:|---:|---:|---:|
| Same project and settings | 2738.5 ± 31.3 ms | **2704.2 ± 38.5 ms** | **1.0127×** | **15/20 pairs** |

The mean paired reduction is 34.3 ms with a 95% paired t confidence interval of
15.0–53.6 ms; the exact two-sided sign-test result is `p = 0.0414`. In a fresh
1 ms sampling profile, the baseline enters
`identifierHasInstanceofFallthroughJoin` and descends through visible
annotation lowering, while the candidate remains at the marker guard and that
downstream stack disappears.

The independent 30-round confirmation is `20260831T005513Z`: TS 6.0.3 takes
1048.1 ± 15.7 ms, native TS 7.0.2 takes 365.1 ± 8.1 ms, and Home takes
**318.1 ± 4.6 ms**, a **1.15×** lead with 30/30 paired wins. The complete
20-workload result is `20260831T005639Z`, reported in the
[current snapshot](#current-snapshot): Home has the lower mean on 20/20 rows
and the lower individual time in 598/600 rounds. Both official runs retain
every sample and verify unchanged compiler provenance before admission and
after measurement.

### Tiny annotated-scope index checkpoint

Commit `96d05423e`, tracked by
[#416](https://github.com/home-lang/home/issues/416), keeps one- and
two-statement containers on the checker’s existing direct lexical scan instead
of allocating entries in both the annotated-declaration index and the set that
records indexed containers. The scan is bounded by two statements. Containers with three or
more statements retain the indexed path, including virtual-source-section keys,
and all callers retain their existing direct fallback. A focused regression
test verifies both the TS2322 result of an annotated local read and that its
two-statement function body does not build the index.

The isolated Home A/B uses the unchanged 16,384-family predicate stress project
and identical `--noEmit -p` arguments. The published `instanceof`-guard binary
(SHA-256 `842310b6c24e1e788c33d756bbff0e7df0b0bc60c261d4dcb8552f8c09ccb2cd`)
is the baseline; the measured candidate has SHA-256
`1b401eb95d51702a1a3467c80aede41dfe4107defb690c34f2420194cc2f4fdf`.
After three alternating warmup pairs, 20 measured pairs reverse process order
each round. All 40 finite samples are retained in
`tiny-visible-index-ab.kxWhRg`; none is filtered.

| 16,384 predicate-family Home A/B | Indexed tiny scopes | Bounded direct scan | Baseline / candidate | Lower candidate time |
|---|---:|---:|---:|---:|
| Same project and settings | 2699.9 ± 54.0 ms | **2651.6 ± 42.2 ms** | **1.0182×** | **16/20 pairs** |

The mean paired reduction is 48.3 ms with a 95% paired t confidence interval of
23.5–73.1 ms; the exact two-sided sign-test result is `p = 0.0118`. The focused
ReleaseFast test and complete ReleaseFast checker suite pass. The final
published Home binary, including that test, has SHA-256
`09fa07634b31ba0eb0a8671bf8c1e1fe85c69a22b7581f693f821703e10a8d6d`.

The independent 30-round confirmation is `20260831T012734Z`: TS 6.0.3 takes
1053.2 ± 18.7 ms, native TS 7.0.2 takes 365.7 ± 7.8 ms, and Home takes
**314.6 ± 4.8 ms**, a **1.16×** lead with 30/30 paired wins. The complete
20-workload result is `20260831T012857Z`, reported in the
[current snapshot](#current-snapshot): Home has the lower mean on 20/20 rows
and the lower individual time in 599/600 rounds. Both official runs retain
every sample and verify unchanged compiler provenance before admission and
after measurement.

### Prepared source-marker reuse checkpoint

Commit `1ae4ecfa6`, tracked by
[#416](https://github.com/home-lang/home/issues/416), computes the exact
one-pass source-marker index once during driver preparation and passes that
same index into the checker. Driver probes for source directives, triple-slash
references, and virtual filenames use conservative marker-presence gates;
sources containing the relevant sentinel retain the original parsing and
diagnostic paths. Compiler-option type references remain unconditional because
they can originate outside source text.

The isolated Home A/B uses the unchanged 16,384-family predicate stress project
and identical `--noEmit -p` arguments. The published tiny-scope binary
(SHA-256 `09fa07634b31ba0eb0a8671bf8c1e1fe85c69a22b7581f693f821703e10a8d6d`)
is the baseline; the marker-reuse candidate has SHA-256
`161e0142518e25a29cc2f60cff18364a2dbcff0719b89a9fec795dba9a195bfa`.
After three alternating warmup pairs, 20 measured pairs reverse process order
each round. All 40 finite samples are retained in
`source-marker-reuse-ab.OFleQk`; none is filtered.

| 16,384 predicate-family Home A/B | Repeated scans | Prepared marker reuse | Baseline / candidate | Lower candidate time |
|---|---:|---:|---:|---:|
| Same project and settings | 2666.8 ± 35.7 ms | **2596.0 ± 34.1 ms** | **1.0273×** | **20/20 pairs** |

The mean paired reduction is 70.8 ms with a 95% paired t confidence interval of
57.2–84.4 ms; the exact two-sided sign-test result is `p = 0.0000019`.
The focused ReleaseFast driver suite, supplied-marker checker regression,
Pickier, formatting, and diff checks pass. The unchanged benchmark project
also produces byte-identical stdout, stderr, and exit status with both Home
binaries.

The independent 30-round confirmation is `20260831T020935Z`: TS 6.0.3 takes
1051.0 ± 22.2 ms, native TS 7.0.2 takes 367.2 ± 6.5 ms, and Home takes
**305.2 ± 3.7 ms**, a **1.20×** lead with 30/30 paired wins. The complete
20-workload result is `20260831T021055Z`, reported in the
[current snapshot](#current-snapshot): Home has the lower mean on 20/20 rows
and the lower individual time in 600/600 rounds. Both official runs retain
every sample and verify unchanged compiler provenance before admission and
after measurement.

### Exact import-equals presence checkpoint

Commit `3454bbaa1`, tracked by
[#416](https://github.com/home-lang/home/issues/416), replaces a repeated
import-equals negative search with one cached exact HIR fact. The existing
source marker conservatively admits any file containing both `import` and `=`.
That includes ordinary named imports followed by unrelated assignments. Such a
file previously rescanned enclosing and root statement lists for every type
reference even though no `import local = Qualified.Name` or
`import local = require(...)` declaration could be found. A real import-equals
declaration still uses the original resolution and diagnostic paths unchanged;
HIR-only checker setups also retain the unfiltered path.

The isolated Home A/B uses the benchmark suite's unchanged recursive-generic
generator at 4,096 families and identical `--noEmit -p` arguments. This scaled
diagnostic corpus exposes the asymptotic repeated scan; it does not replace or
alter the standard 256-family competitor workload. Both binaries exit zero
with byte-identical empty stdout and stderr. The published prepared-marker
binary (SHA-256
`161e0142518e25a29cc2f60cff18364a2dbcff0719b89a9fec795dba9a195bfa`)
is the baseline; the exact final candidate has SHA-256
`6182abe599c8ee69a16161f061010ea7fc0232928748a887201321c9048491f3`.
After three alternating warmup pairs, 20 measured pairs reverse process order
each round. All 40 finite samples are retained in
`import-equals-exact-final-ab.4096`; none is filtered.

| 4,096 recursive-family Home A/B | Repeated statement scans | Cached exact HIR fact | Baseline / candidate | Lower candidate time |
|---|---:|---:|---:|---:|
| Same generated project and settings | 2063.9 ± 199.4 ms | **1205.9 ± 115.5 ms** | **1.7115×** | **20/20 pairs** |

The mean paired reduction is 858.0 ms with a 95% paired t confidence interval
of 774.6–941.3 ms; the exact two-sided sign-test result is `p = 0.0000019`.
The focused exact-fact test, the existing ReleaseFast import-equals test group,
the ReleaseFast production build, scoped Pickier lint, formatting, and diff
checks pass.

The independent 30-round standard-workload confirmation is
`20260831T030019Z`: TS 6.0.3 takes 175.6 ± 51.9 ms, native TS 7.0.2 takes
81.5 ± 24.3 ms, and Home takes **17.1 ± 2.3 ms**, a **4.76×** lead with
30/30 paired wins. The complete 20-workload result is `20260831T030052Z`,
reported in the [current snapshot](#current-snapshot): Home has the lower mean
on 20/20 rows and the lower individual time in 598/600 rounds. Both official
runs retain every sample and verify unchanged compiler provenance before
admission and after measurement.

### JSDoc global duplicate-name index checkpoint

Commit `800fff78b`, tracked by
[#416](https://github.com/home-lang/home/issues/416), replaces an all-pairs
scan in checked-JavaScript global duplicate diagnostics with source-ordered
same-name chains. The previous pass compared every JSDoc typedef and top-level
value with every later entry, then rejected almost every pair because the names
differed. The index links only equal names while the outer source-order walk is
unchanged, so every semantically relevant pair and its diagnostic order remain
the same.

The isolated Home A/B uses the benchmark suite's unchanged CheckJS/JSDoc
generator at 2,048 families and identical `--noEmit -p` arguments. This scaled
diagnostic corpus exposes the asymptotic duplicate scan; it does not replace or
alter the standard 128-family competitor workload. Both binaries exit zero
with byte-identical empty stdout and stderr. A separate invalid multi-file
fixture also produces byte-identical diagnostics and ordering. The published
exact-import binary (SHA-256
`6182abe599c8ee69a16161f061010ea7fc0232928748a887201321c9048491f3`)
is the baseline; the exact final candidate has SHA-256
`b02ecda7944783f0437b8c205177fb66b4b09aa6e9ddaf5d331161114626a633`.
After three alternating warmup pairs, 20 measured pairs reverse process order
each round. All 40 finite samples are retained in
`jsdoc-same-name-chain-final-ab.2048`; none is filtered.

| 2,048 CheckJS-family Home A/B | All-pairs name scan | Source-ordered same-name chains | Baseline / candidate | Lower candidate time |
|---|---:|---:|---:|---:|
| Same generated project and settings | 1857.4 ± 94.4 ms | **1793.6 ± 48.8 ms** | **1.0356×** | **17/20 pairs** |

The mean paired reduction is 63.9 ms with a 95% paired t confidence interval
of 24.1–103.7 ms; the exact two-sided sign-test result is `p = 0.0026`.
Independent process CPU time is 3.25% lower with the same 17/20 direction and
a 26.7–88.1 ms paired 95% interval. The focused diagnostic-order regression,
broader ReleaseFast `JSDoc typedef` checker subset, ReleaseFast production
build, scoped Pickier lint, formatting, and diff checks pass.

The independent 30-round standard-workload confirmation is
`20260831T040831Z`: TS 6.0.3 takes 245.1 ± 92.0 ms, native TS 7.0.2 takes
59.7 ± 3.1 ms, and Home takes **40.7 ± 9.4 ms**, a **1.47×** lead with
29/30 paired wins. The complete 20-workload result is `20260831T040903Z`,
reported in the [current snapshot](#current-snapshot): Home has the lower mean
on 20/20 rows and the lower individual time in 600/600 rounds. Both official
runs retain every sample and verify unchanged compiler provenance before
admission and after measurement.

### ASCII identifier scanner checkpoint

Commit `12e4f73ef`, tracked by
[#416](https://github.com/home-lang/home/issues/416), changes the identifier
scanner's dispatch order without changing its accepted syntax. The previous
loop probed both UTF-8 whitespace tables for every byte before testing whether
an ordinary ASCII letter or digit continues the identifier. The new path tests
ASCII continuation first. Backslash escapes still use the complete escape
path, and non-ASCII bytes still run both Unicode whitespace and line-terminator
checks. A focused regression verifies that U+00A0 and U+2028 terminate an
identifier and that U+2028 preserves the following token's newline flag.

The exact-final Home A/B uses the suite's unchanged type-predicate generator
at 32,768 families with identical `--noEmit -p` arguments. This is a scaled
diagnostic corpus for the scanner hotspot, not a replacement for the standard
2,048-family competitor row. Both binaries exit zero with byte-identical empty
stdout and stderr. The published JSDoc-index binary (SHA-256
`b02ecda7944783f0437b8c205177fb66b4b09aa6e9ddaf5d331161114626a633`)
is the baseline; the committed candidate has SHA-256
`aae87472b82685d59b37aa53218173120f8e6df190a473ca04477cf3b46637d6`.
After three alternating warmup pairs, 20 measured pairs reverse process order
each round. All 40 finite samples remain in
`ascii-identifier-fast-path-final-ab.32768`; none is filtered.

| 32,768 predicate-family Home A/B | UTF-8 probes before ASCII | ASCII continuation first | Baseline / candidate | Lower candidate time |
|---|---:|---:|---:|---:|
| Process CPU | 7353.4 ± 112.6 ms | **7129.1 ± 108.2 ms** | **1.0315×** | **20/20 pairs** |
| Wall clock | 8126.3 ± 277.9 ms | **8010.6 ± 689.5 ms** | **1.0145×** | **17/20 pairs** |

The CPU paired reduction is 224.3 ms with a 95% paired t confidence interval
of 178.9–269.7 ms; its exact two-sided sign-test result is `p = 0.0000019`.
Wall clock retains two early candidate machine-stall outliers, so its paired
t interval crosses zero (-125.4–357.0 ms) even though the direction is lower
in 17/20 pairs (`p = 0.0026` by the exact two-sided sign test). An independent
pre-test-layout build of the same production scanner logic measured a 1.0418×
wall reduction with a positive 100.7–326.8 ms paired interval. The shorter
8,192-family exact-final confirmation was directionally lower but inconclusive
under contemporaneous host variance (13/20 wall and CPU wins); its samples are
retained in `ascii-identifier-fast-path-final-ab.8192` rather than discarded.
The ReleaseFast lexer suite, Unicode regression, ReleaseFast production build,
formatting, and diff checks pass.

The exact committed-binary 30-round confirmation is `20260831T050122Z`: TS
6.0.3 takes 1017.3 ± 46.6 ms, native TS 7.0.2 takes 351.6 ± 8.1 ms, and Home
takes **288.4 ± 5.7 ms**, a **1.22×** lead. The complete 20-workload result is
`20260831T050307Z`, reported in the [current snapshot](#current-snapshot): Home
has the lower mean on 20/20 rows and the lower individual time in 600/600
rounds. Both official runs retain every sample and verify candidate SHA-256
`aae87472b82685d59b37aa53218173120f8e6df190a473ca04477cf3b46637d6`
before admission and after measurement.

### Builtin object name gate checkpoint

Commit `43e1f1ea8`, tracked by
[#416](https://github.com/home-lang/home/issues/416), adds an exact name gate
before builtin object-type lowering. Previously, every failed user-defined
type name traversed the long chain of builtin recipes and string comparisons.
The static index contains all and only the 44 names recognized by those
existing specialized and fallback paths. A matching name still runs its
original recipe unchanged; a nonmatching name now returns before the chain.

The exact-final Home A/B uses the suite's unchanged type-predicate generator
at 32,768 families with identical `--noEmit -p` arguments. Both binaries exit
zero with byte-identical empty stdout and stderr. The committed ASCII-scanner
binary (SHA-256
`aae87472b82685d59b37aa53218173120f8e6df190a473ca04477cf3b46637d6`)
is the baseline; the builtin-gate candidate has SHA-256
`58b48a6b39d76c7ffa6cf3343490bd7da423692135076f3cbee6da8b54aa8206`.
After three alternating warmup pairs, 20 measured pairs reverse process order
each round. All 40 finite samples remain in
`builtin-object-name-gate-final-ab.32768`; none is filtered.

| 32,768 predicate-family Home A/B | Recipe chain for every name | Exact 44-name gate | Baseline / candidate | Lower candidate time |
|---|---:|---:|---:|---:|
| Wall clock | 4981.9 ± 172.9 ms | **4890.1 ± 149.9 ms** | **1.0188×** | **17/20 pairs** |
| Process CPU | 4960.5 ± 157.6 ms | **4866.9 ± 135.7 ms** | **1.0192×** | **16/20 pairs** |

The wall-clock mean paired reduction is 91.9 ms with a 95% paired t
confidence interval of 30.2–153.6 ms; its exact two-sided sign-test result is
`p = 0.0025768`. Process CPU time is lower by a paired mean of 93.6 ms with a
39.2–148.0 ms interval and `p = 0.0118179`. An independent pre-test-layout
build of the same production logic also measured lower wall and CPU means:
1.0207× and 1.0202× respectively, each with 19/20 lower candidate pairs and
positive paired confidence intervals. The focused completeness regression
resolves all 44 builtin recipes and rejects prefix and suffix lookalikes. A
mechanical audit reports 44 gated and 44 recognized names with no missing or
extra entries; the broader ReleaseFast checker builtin subset, ReleaseFast
production build, formatting, and diff checks pass.

The exact committed-binary 30-round confirmation is `20260831T053315Z`: TS
6.0.3 takes 999.6 ± 27.0 ms, native TS 7.0.2 takes 349.9 ± 11.5 ms, and Home
takes **280.7 ± 6.7 ms**, a **1.25×** lead. The complete 20-workload result is
`20260831T053521Z`, reported in the [current snapshot](#current-snapshot): Home
has the lower mean on 20/20 rows and the lower individual time in 600/600
rounds. Both official runs retain every sample and verify candidate SHA-256
`58b48a6b39d76c7ffa6cf3343490bd7da423692135076f3cbee6da8b54aa8206`
before admission and after measurement.

### Prehashed string interner checkpoint

Commit `94a5b3589`, tracked by
[#416](https://github.com/home-lang/home/issues/416), removes repeated hashing
from the shared string interner. Previously, `intern` computed Wyhash to choose
one of 64 shards and the shard's string map recomputed the same hash for its
optimistic read, exclusive-lock double-check, and insertion. `lookup` likewise
hashed for both shard selection and the map probe. The new adapted map key
carries the original Wyhash through those operations. The identical low bits
still select the shard; byte equality, locks, stable IDs, allocation ordering,
and owned key storage are unchanged.

The exact Home A/B uses the suite's unchanged predicate generator and identical
`--noEmit -p` arguments. Both binaries exit zero with byte-identical empty
stdout and stderr at both scales. The builtin-name-gate binary (SHA-256
`58b48a6b39d76c7ffa6cf3343490bd7da423692135076f3cbee6da8b54aa8206`)
is the baseline; the committed prehash candidate has SHA-256
`977e3cc7ab65ff1c0e1f7f382aebd8258e45baea5ed1fb2b03892b44c11fa9f0`.
Each confirmatory run uses three alternating warmup pairs and 20 measured pairs
whose process order reverses every round. All 80 finite samples remain in the
two raw directories; none is filtered or pooled across scales.

| Home A/B | Repeated Wyhash | Reused exact Wyhash | Baseline / candidate | Lower candidate time |
|---|---:|---:|---:|---:|
| 32,768 families, process CPU | 4730.5 ± 34.8 ms | **4706.2 ± 45.5 ms** | **1.0052×** | **13/20 pairs** |
| 32,768 families, wall clock | 4738.5 ± 35.7 ms | **4718.4 ± 48.6 ms** | **1.0043×** | **12/20 pairs** |
| 65,536 families, process CPU | 9824.1 ± 84.5 ms | **9764.4 ± 73.6 ms** | **1.0061×** | **15/20 pairs** |
| 65,536 families, wall clock | 9865.2 ± 95.2 ms | **9806.4 ± 86.4 ms** | **1.0060×** | **14/20 pairs** |

At 32,768 families, the CPU paired reduction is 24.3 ms with a 95% paired t
confidence interval of 0.5–48.2 ms; its exact two-sided sign-test result is
`p = 0.2632`. The wall interval is -5.6–45.8 ms. At 65,536 families, CPU is
lower by a paired mean of 59.8 ms with a 4.7–114.9 ms interval and 15/20 lower
candidate pairs (`p = 0.0414` by the exact two-sided sign test). Its wall mean
is lower by 58.8 ms, with a -2.3–119.9 ms interval. A separate ten-pair
32,768-family screen, retained but not pooled, measured 1.0108× lower wall and
CPU means with 9/10 lower candidate pairs and positive paired intervals.

A fresh 1 ms sampling profile confirms the intended mechanism: the duplicated
string-map `get` leaf disappears, Wyhash leaf samples fall from 34 to 16, and
byte-equality leaves fall from 334 to 291. These profile counts explain the
change and are not timing claims. Validation passes the ReleaseFast interner
suite (shared ownership, concurrency, deterministic sharding, and allocation
failure), the ReleaseFast type-predicate checker subset, the ReleaseFast
production build, formatting, and diff checks.

Two adjacent ideas were measured and fully reverted. Adding `@target` to the
one-pass marker automaton was effectively flat over 20 pairs: wall measured
4849.1 ± 202.1 ms versus 4848.9 ± 147.6 ms (8/20 lower candidate pairs, paired
interval -74.2–74.5 ms), while CPU was slightly higher. A compile-time-derived
builtin terminal-byte prefilter was also flat in its ten-pair screen: wall
measured 5233.9 ± 234.5 ms versus 5225.5 ± 269.3 ms (5/10 pairs, interval
-108.2–125.1 ms), with the same 5/10 direction for CPU. Neither probe appears
in the committed compiler or contributes to the accepted measurements.

The exact committed-binary 30-round standard-workload confirmation is
`20260831T063321Z`: TS 6.0.3 takes 980.1 ± 15.5 ms, native TS 7.0.2 takes
342.9 ± 7.2 ms, and Home takes **274.2 ± 3.7 ms**, a **1.25×** lead. The
complete 20-workload result is `20260831T063443Z`, reported in the
[current snapshot](#current-snapshot): Home has the lower mean on 20/20 rows
and the lower individual time in 600/600 rounds. Both official runs retain
every sample and verify candidate SHA-256
`977e3cc7ab65ff1c0e1f7f382aebd8258e45baea5ed1fb2b03892b44c11fa9f0`
before admission and after measurement.

### Prehashed type interner checkpoint

Commit `79b6b6360`, tracked by
[#416](https://github.com/home-lang/home/issues/416), applies the same exact-hash
reuse to structural type keys. Previously, each `TypeKey` was hashed once to
choose one of 64 shards and again inside every optimistic read, exclusive-lock
double-check, and insertion. The adapted probe now carries that original hash
through scalar keys, owned tuple and instantiation keys, template literals,
and canonical union/intersection slices. Structural `TypeKey.eql` remains the
collision check; shard selection, owned key storage, locks, stable TypeIds, and
pool contents are unchanged. Shard-table capacity is reserved before pool
publication, so inserting the already-published type requires no allocation.

The exact Home A/B uses the unchanged predicate generator and identical
`--noEmit -p` commands. Both binaries exit zero with byte-identical empty
stdout and stderr at 32,768 and 65,536 families. The prehashed-string binary
(SHA-256
`977e3cc7ab65ff1c0e1f7f382aebd8258e45baea5ed1fb2b03892b44c11fa9f0`)
is the baseline; the committed type-prehash candidate has SHA-256
`e313cd557ae66e601792c947eff07a06c8a19b3421c7537623be3d2f9f85899b`.
Each confirmatory run uses three alternating warmup pairs and 20 measured pairs
whose process order reverses every round. All 80 finite samples remain under
`type-interner-prehash.FxAMAs/final-ab.{32768,65536}`; none is filtered or
pooled across scales.

| Home A/B | Repeated TypeKey hash | Reused exact hash | Baseline / candidate | Lower candidate time |
|---|---:|---:|---:|---:|
| 32,768 families, process CPU | 4681.0 ± 27.3 ms | **4639.9 ± 32.7 ms** | **1.0089×** | **16/20 pairs** |
| 32,768 families, wall clock | 4689.7 ± 29.9 ms | **4648.9 ± 33.4 ms** | **1.0088×** | **16/20 pairs** |
| 65,536 families, process CPU | 9664.1 ± 93.1 ms | **9596.5 ± 72.6 ms** | **1.0070×** | **16/20 pairs** |
| 65,536 families, wall clock | 9679.6 ± 100.9 ms | **9611.4 ± 77.8 ms** | **1.0071×** | **16/20 pairs** |

At 32,768 families, the paired CPU reduction is 41.1 ms with a 95% paired t
confidence interval of 19.9–62.3 ms; wall clock is lower by 40.8 ms with a
19.8–61.8 ms interval. At 65,536 families, CPU is lower by 67.6 ms with a
21.3–114.0 ms interval; wall clock is lower by 68.2 ms with a 16.3–120.1 ms
interval. Every row has 16/20 lower candidate pairs and an exact two-sided
sign-test result of `p = 0.0118`. A separate unpooled ten-pair screen at 32,768
families measured 1.0110× lower wall and 1.0100× lower CPU means, with positive
paired intervals.

A fresh 1 ms sampling profile confirms the intended mechanism: the previous
58-sample `TypeKey` map `getIndex` leaf disappears; ordinary map growth remains.
This profile observation explains the change and is not a timing claim.
Validation passes the ReleaseFast type-interner groups, including concurrent
deduplication and allocation-failure coverage, the ReleaseFast type-predicate
checker subset, the ReleaseFast production build, exact output checks at both
scales, formatting, and diff checks.

One adjacent cleanup was measured and fully reverted. Removing a second
top-level annotated-variable lookup produced a positive ten-pair screen at
32,768 families (1.0108× lower wall and 1.0106× lower CPU means, 10/10 lower
candidate pairs, positive paired intervals), but the independent confirmations
did not clear the paired-mean acceptance bar. At 32,768 families, wall measured
4638.4 ± 41.2 ms versus 4611.3 ± 48.4 ms (1.0059×, 15/20 pairs, paired interval
-7.0–61.1 ms); CPU measured 4631.7 ± 39.5 ms versus 4603.9 ± 45.9 ms (1.0060×,
15/20 pairs, interval -5.0–60.6 ms). At 65,536 families, wall measured
9632.2 ± 79.7 ms versus 9582.9 ± 75.1 ms (1.0052×, 13/20 pairs, interval
-6.9–105.6 ms); CPU measured 9619.1 ± 72.4 ms versus 9568.6 ± 69.9 ms
(1.0053×, 14/20 pairs, interval -1.5–102.5 ms). Both binaries preserved exact
output at both scales, and the focused annotation suite passed, but positive
means with intervals crossing zero are not a retained performance result. All
raw rounds remain under `annotated-root-lookup.3jRs1g`; the probe is absent
from the compiler.

The exact committed-binary 30-round standard-workload confirmation is
`20260831T071216Z`: TS 6.0.3 takes 977.9 ± 10.1 ms, native TS 7.0.2 takes
343.3 ± 7.9 ms, and Home takes **274.5 ± 8.4 ms**, a **1.25×** lead. The
complete 20-workload result is `20260831T071413Z`, reported in the
[current snapshot](#current-snapshot): Home has the lower mean on 20/20 rows
and the lower individual time in 600/600 rounds. Both official runs retain
every sample and verify candidate SHA-256
`e313cd557ae66e601792c947eff07a06c8a19b3421c7537623be3d2f9f85899b`
before admission and after measurement.

### Hot string-interner cache checkpoint

Commit `7f02a93dd`, tracked by
[#416](https://github.com/home-lang/home/issues/416), adds a 64-entry
direct-mapped lookup hint to each of the 64 string-interner shards. The cache
occupies 32 KiB in total and stores only a 32-bit hash fingerprint plus a local
index. Every possible hit is checked against the canonical owned bytes while
holding the existing shard lock. Slot and fingerprint collisions therefore
fall through to the canonical prehashed map; string identity, stable IDs,
owned storage, sharding, and locking semantics are unchanged. Map hits refresh
the hint, and new entries become visible only after their canonical string and
table entry have been published.

The exact Home A/B uses the unchanged predicate generator and identical
`--noEmit -p` commands. Both binaries exit zero with byte-identical empty
stdout and stderr at 32,768 and 65,536 families. The type-prehash binary
(SHA-256
`e313cd557ae66e601792c947eff07a06c8a19b3421c7537623be3d2f9f85899b`)
is the baseline; the committed hot-cache candidate has SHA-256
`be09b86b82af35703a8f812dad92014ddf5250e0c9e721c2078bc82a791ac35d`.
Each confirmatory run uses three alternating warmup pairs and 20 measured pairs
whose process order reverses every round. All 80 finite samples remain under
`string-interner-hot-cache.T0d2PQ/final-ab.{32768,65536}`; none is filtered or
pooled across scales.

| Home A/B | Canonical map only | Hot cache + canonical fallback | Baseline / candidate | Lower candidate time |
|---|---:|---:|---:|---:|
| 32,768 families, process CPU | 4706.6 ± 50.2 ms | **4575.0 ± 47.7 ms** | **1.0288×** | **20/20 pairs** |
| 32,768 families, wall clock | 4715.4 ± 52.3 ms | **4583.7 ± 51.2 ms** | **1.0287×** | **19/20 pairs** |
| 65,536 families, process CPU | 9720.4 ± 90.0 ms | **9465.3 ± 111.8 ms** | **1.0269×** | **19/20 pairs** |
| 65,536 families, wall clock | 9776.2 ± 93.6 ms | **9527.9 ± 122.3 ms** | **1.0261×** | **18/20 pairs** |

At 32,768 families, the paired CPU reduction is 131.7 ms with a 95% paired t
confidence interval of 98.5–164.9 ms; wall clock is lower by 131.7 ms with a
97.1–166.3 ms interval. At 65,536 families, CPU is lower by 255.1 ms with a
176.9–333.2 ms interval; wall clock is lower by 248.2 ms with a 162.2–334.3 ms
interval. The exact two-sided sign-test results range from `p = 0.0000019` to
`p = 0.0004025`. A separate unpooled ten-pair screen at 32,768 families
measured 1.0242× lower wall and 1.0247× lower CPU means, with 10/10 lower
candidate pairs and positive paired intervals.

A fresh 1 ms sampling profile confirms the intended mechanism:
`string_interner.Interner.internAt` leaf samples fall from 220 to 92, while
byte-equality leaf samples remain essentially flat at 207 versus 205. This is
consistent with avoiding canonical map probes while retaining full-byte
verification; the profile counts are explanatory, not timing claims.
Validation passes the complete ReleaseFast string-interner suite, the
ReleaseFast type-predicate checker subset, the ReleaseFast production build,
exact output checks at both scales, formatting, and diff checks.

One follow-on memoization was measured and fully reverted. Caching
`containsFreeTypeParameter` results in a checker-local hash map preserved exact
output and passed the focused ReleaseFast predicate suite, but its ten-pair
32,768-family screen was slightly slower. Wall clock measured 4497.1 ± 37.4 ms
for the accepted binary versus 4517.5 ± 79.8 ms for the candidate (0.9955×,
4/10 lower candidate pairs, paired interval -88.2–47.5 ms). Process CPU
measured 4486.4 ± 35.9 ms versus 4501.7 ± 64.9 ms (0.9966×, 3/10 pairs,
interval -71.1–40.4 ms). The map lookup and maintenance cost did not justify
the avoided graph walks. All raw rounds remain under
`free-type-param-cache.Npjpjh/preliminary-ab.32768`; the memoization is absent
from the compiler.

The exact committed-binary 30-round focused confirmation is
`20260831T081314Z`: TS 6.0.3 takes 985.8 ± 14.9 ms, native TS 7.0.2 takes
342.1 ± 5.5 ms, and Home takes **257.3 ± 3.1 ms**, a **1.33×** lead. The
complete 20-workload result is `20260831T081507Z`, reported in the
[current snapshot](#current-snapshot): Home has the lower mean on 20/20 rows
and the lower individual time in 599/600 rounds. Both official runs retain
every sample and verify the candidate SHA-256 shown above before admission and
after measurement.

### ASCII trivia-boundary checkpoint

Commit `efdf8b574`, tracked by
[#416](https://github.com/home-lang/home/issues/416), removes unnecessary
Unicode-whitespace probes at ordinary ASCII token boundaries. Every supported
non-ASCII whitespace and line terminator begins with a high byte, so
`skipTrivia` can return immediately when its otherwise-unrecognized current
byte is ASCII. The existing UTF-8 recognition, tokenization, diagnostics, and
source traversal are unchanged.

The exact Home A/B again uses the unchanged predicate generator and identical
`--noEmit -p` commands. Both binaries exit zero with byte-identical empty
stdout and stderr at 32,768 and 65,536 families. The hot string-cache binary
(SHA-256
`be09b86b82af35703a8f812dad92014ddf5250e0c9e721c2078bc82a791ac35d`)
is the baseline; the committed ASCII-boundary candidate has SHA-256
`150c2206d8d38990a2d0054d03c8939357960d5a26c0e6c0b9ca560d7fc8581b`.
Each confirmatory run uses three alternating warmup pairs and 20 measured pairs
whose process order reverses every round. The reported rows are independent
and are not pooled across scales.

| Home A/B | Unicode probe at every boundary | ASCII boundary fast path | Baseline / candidate | Lower candidate time |
|---|---:|---:|---:|---:|
| 32,768 families, process CPU | 4466.5 ± 34.6 ms | **4426.8 ± 42.4 ms** | **1.0090×** | **18/20 pairs** |
| 32,768 families, wall clock | 4477.4 ± 35.9 ms | **4435.1 ± 44.3 ms** | **1.0096×** | **18/20 pairs** |
| 65,536 families, process CPU | 9200.4 ± 53.6 ms | **9064.6 ± 51.2 ms** | **1.0150×** | **20/20 pairs** |
| 65,536 families, wall clock | 9212.7 ± 55.0 ms | **9079.2 ± 52.4 ms** | **1.0147×** | **20/20 pairs** |

At 32,768 families, the paired CPU reduction is 39.7 ms with a 95% paired t
confidence interval of 14.3–65.1 ms; wall clock is lower by 42.4 ms with a
15.9–68.8 ms interval. At 65,536 families, CPU is lower by 135.8 ms with a
104.2–167.4 ms interval; wall clock is lower by 133.5 ms with a 101.0–166.1 ms
interval. Exact two-sided sign-test results are `p = 0.0004025` at 32,768 and
`p = 0.0000019` at 65,536. A separate unpooled ten-pair screen at 32,768
families measured 1.0091× lower wall and 1.0094× lower CPU means, with positive
paired intervals.

The first 65,536-family confirmation is also retained without filtering. It
contains an 11.51-second baseline wall outlier: wall measured
9357.5 ± 511.1 ms versus 9133.1 ± 49.3 ms (1.0246×, 19/20 pairs, paired
interval -5.9–454.6 ms), while CPU measured 9300.7 ± 327.1 ms versus
9118.4 ± 45.5 ms (1.0200×, 19/20 pairs, interval 31.7–333.0 ms). The
independent repeat above reversed the starting process order and supplies the
clean positive wall and CPU intervals; the noisy run remains part of the
record rather than being substituted or trimmed.

A fresh 1 ms sampling profile on the doubled workload records only three total
`unicodeWhitespaceLengthAt` stack occurrences, versus 35 leaf samples in the
previous accepted 32,768-family profile. The counts confirm that ordinary
ASCII boundaries no longer enter the Unicode probe; they are explanatory, not
timing claims. Validation passes the complete ReleaseFast lexer suite,
ReleaseFast parser suite, ReleaseFast type-predicate checker subset, the
ReleaseFast production build, exact output checks at both scales, formatting,
and diff checks. All A/B rounds and the profile remain under
`ascii-trivia-fast-path.IbEFgd/`.

One adjacent keyword-lookup replacement was measured and fully reverted.
Zig's compile-time `StaticStringMap` preserved all keyword and lexer tests plus
exact compiler output, but its ten-pair 32,768-family screen was slightly
slower than the existing compile-time length buckets. Wall clock measured
4425.8 ± 44.9 ms for the accepted binary versus 4441.2 ± 40.6 ms for the
candidate (0.9965×, 6/10 lower candidate pairs, paired interval
-61.2–30.4 ms). Process CPU measured 4415.4 ± 43.2 ms versus
4432.3 ± 40.5 ms (0.9962×, 5/10 pairs, interval -61.0–27.1 ms). All raw
rounds remain under `static-keyword-map.7qVurl/preliminary-ab.32768`; the
static map is absent from the compiler. The existing lookup documentation now
correctly records that the largest length bucket contains 16 candidates.

A purpose-built collision-free keyword index was also measured and fully
reverted. A compile-time-verified 256-byte table used keyword length, the first
two bytes, and the final byte to select one candidate, followed by an exact
byte comparison. It preserved the complete keyword and lexer suite plus exact
compiler output, but its ten-pair 32,768-family screen did not justify the
runtime arithmetic and table load. Wall clock measured 4701.1 ± 166.1 ms for
the accepted binary versus 4749.8 ± 303.7 ms for the candidate (0.9897×,
5/10 lower candidate pairs, paired interval -229.5–132.1 ms). Process CPU
measured 4666.3 ± 148.6 ms versus 4700.7 ± 253.9 ms (0.9927×, 5/10 pairs,
interval -180.4–111.6 ms). The host was slower than the earlier static-map
screen, so only paired within-batch differences are interpreted. All raw
rounds remain under `perfect-keyword-index.YBAnkb/preliminary-ab.32768`; the
perfect index is absent from the compiler.

An exact source-marker gate for the legacy inline `@target` scan was measured
and fully reverted as well. The candidate used the already-computed exact
Aho–Corasick marker index to prove that `@target` was absent whenever a source
contained no `@`; sources containing `@` retained the original directive
parser. Both fixed binaries produced byte-identical output at 32,768 and
65,536 families. After three alternating warmup pairs, the ten-pair
32,768-family screen measured 5133.2 ± 503.0 ms for the accepted binary and
5178.6 ± 505.6 ms for the candidate in wall time (0.9912×, 5/10 lower
candidate pairs, paired interval -242.1–151.3 ms). Process CPU measured
5027.4 ± 401.3 ms versus 5020.1 ± 321.2 ms (1.0015×, 6/10 pairs, paired
interval -140.5–155.2 ms). The variable host makes the paired interval the
decision criterion, and neither metric justified the branch. Raw rounds remain
under `target-option-gate.shBw7j/preliminary-ab.32768`; the gate is absent from
the compiler.

Passing the already-indexed virtual-section fact into `Parser.init` was also
measured and fully reverted. This removed two exact full-source searches for
`@filename:` and `@Filename:` from the program driver while preserving the
fallback initializer for direct parser callers. ReleaseFast parser and driver
suites passed, and fixed binaries produced byte-identical output at both
scales. A ten-pair 32,768-family screen favored the candidate by 1.0178× wall
and 1.0153× process CPU, but both paired intervals crossed zero. An independent
20-pair repeat still showed lower candidate means (5076.6 ± 248.2 ms versus
4977.2 ± 235.4 ms wall; 4968.7 ± 187.6 ms versus 4895.9 ± 188.4 ms CPU),
yet its paired intervals remained -17.9–216.8 ms and -19.5–165.1 ms. The
decisive 65,536-family run did not reproduce the margin: wall measured
10054.8 ± 378.2 ms versus 10039.3 ± 372.8 ms (1.0015×, 13/20 pairs,
interval -120.8–151.7 ms), and CPU measured 9911.9 ± 309.1 ms versus
9908.9 ± 323.3 ms (1.0003×, 10/20 pairs, interval -107.2–113.3 ms). All raw
rounds remain under `parser-virtual-section-fact.BUr50C`; the API change is
absent from the compiler.

A declaration-diagnostic pass census was measured and fully reverted. The
candidate classified top-level HIR declaration kinds once, then skipped each
of eight specialized merge passes only when its required kinds were provably
absent. It passed the full ReleaseFast checker suite and produced byte-identical
output at both scales, but the added census merely offset the avoided empty
passes. The ten-pair 32,768-family screen measured 4762.9 ± 84.4 ms for the
accepted binary versus 4757.8 ± 128.0 ms for the candidate in wall time
(1.0011×, 6/10 lower candidate pairs, paired interval -107.5–117.8 ms).
Process CPU measured 4732.5 ± 60.6 ms versus 4725.7 ± 101.0 ms (1.0014×,
6/10 pairs, interval -81.3–94.9 ms). Raw rounds remain under
`declaration-pass-gates.4tu8mP/preliminary-ab.32768`; the census is absent from
the compiler.

The exact committed-binary 30-round focused confirmation is
`20260831T091833Z`: TS 6.0.3 takes 980.2 ± 14.7 ms, native TS 7.0.2 takes
345.0 ± 13.2 ms, and Home takes **256.2 ± 8.2 ms**, a **1.35×** lead. The
complete 20-workload result is `20260831T091953Z`, reported in the
[current snapshot](#current-snapshot): Home has the lower mean on 20/20 rows
and the lower individual time in 599/600 rounds. Both official runs retain
every sample and verify the candidate SHA-256 shown above before admission and
after measurement.

## Historical workload milestones

The comparisons below retain each recorded milestone and its snapshot ID;
they are not replacements for the latest unfiltered table above.

The `control_flow` workload was deliberately added before these optimizations.
Its five-run red baseline (`20260826T203831Z`) measured Home at
2,927.8 ± 159.6 ms versus native TypeScript 7 at 81.5 ± 21.8 ms. The unchanged
workload measured 41.6 ± 0.7 ms in snapshot `20260827T151143Z`: a 70.4×
Home improvement and a 1.34× win over the fastest competitor. The improvement
came from removing repeated general-purpose source and HIR scans; the corpus,
compiler options, validity gate, and measurement schedule were not weakened.

The `overload_resolution` workload was likewise frozen before its optimization.
Its five-run red baseline (`20260826T221712Z`) measured Home at
126.9 ± 0.9 ms versus native TypeScript 7 at 70.3 ± 1.1 ms. The unchanged
workload measured 36.2 ± 0.5 ms in snapshot `20260827T151143Z`: a 3.51×
Home improvement and a 1.69× win over the fastest competitor. The optimized
path only eliminates candidates whose fixed primitive literal parameter is
provably incompatible with the corresponding literal expression.

The `class_hierarchy` workload was also frozen before optimization. Its
five-run red baseline (`20260826T232221Z`) measured Home at 79.4 ± 2.8 ms
versus native TypeScript 7 at 59.6 ± 1.5 ms. The unchanged workload measured
34.8 ± 1.6 ms in snapshot `20260827T151143Z`: a 2.28× Home improvement
and a 1.48× win over the fastest competitor. The optimization caches successful
general-purpose heritage resolutions and removes source or HIR scans only when
conservative facts prove the searched construct cannot apply; the source,
compiler options, validity gate, and schedule are unchanged.

The `structural_objects` workload was frozen before optimization. Its five-run
red baseline (`20260826T234904Z`) measured Home at 160.9 ± 4.5 ms versus
native TypeScript 7 at 62.7 ± 2.7 ms. The unchanged workload measured
35.2 ± 1.5 ms in snapshot `20260827T151143Z`: a 4.57× Home improvement and
a 1.58× win over the fastest competitor. Profiling found that DOM library
availability was rescanning the complete source for every relevant annotation;
the result now uses the checker's existing per-source fact lifecycle. The
corpus, compiler options, validity gate, and measurement schedule were not
weakened.

The `interface_composition` workload was frozen before optimization. Its
five-run red baseline (`20260827T000848Z`) measured Home at 117.3 ± 3.0 ms
versus native TypeScript 7 at 65.3 ± 0.8 ms. The unchanged workload measured
47.1 ± 1.2 ms in snapshot `20260827T151143Z`: a 2.49× Home improvement
and a 1.29× win over the fastest competitor. The implementation replaces
repeated namespace, declaration-merge, annotation, and type-name searches with
validated indexes and conservative source facts. The generated source, compiler
options, silent-success validity gate, and interleaved schedule remain
unchanged.

The `variadic_tuples` workload was frozen before optimization. Its five-run red
baseline (`20260827T072451Z`) measured Home at 209.4 ± 4.8 ms versus native
TypeScript 7 at 100.7 ± 3.3 ms. The exact same generated project measured
48.5 ± 0.8 ms in snapshot `20260827T151143Z`: a 4.32× Home improvement and a
1.50× win over the fastest competitor. The general changes prune non-inferable
generic pairs, index lexical value declarations, retain the relation working
set, and skip syntax-inapplicable scans.
The corpus, compiler options, silent-success validity gate, and interleaved
schedule were not changed after the baseline was recorded.

The `checkjs_jsdoc` workload was accepted and frozen only after Home, `tsc`,
and `tsgo` all checked the same JavaScript project successfully and all three
rejected a preserved invalid variant with `TS2322`. The first semantically
valid Home implementation was impractically slow because it repeatedly found
the owning function and JSDoc declaration for each use; at 64 generated
families it took roughly 14 seconds and its growth made a 128-family timing
run unsuitable as a benchmark baseline. A direct development comparison after
the first general indexing pass still measured Home at 150.7 ± 17.5 ms versus
native TypeScript 7 at 111.4 ± 8.7 ms and `tsc` at 555.0 ± 74.8 ms. The
unchanged accepted workload measured 49.3 ± 1.0 ms in interleaved snapshot
`20260827T151143Z`, a 3.06× Home improvement from that intermediate result
and a 1.06× win over the fastest competitor. The implementation indexes named
JSDoc declarations and their owning functions, memoizes immutable physical
typedef and callback types, reuses binder and lexical indexes, and uses exact
source facts to avoid searches that cannot apply. Virtual sections and scoped
fallback resolution retain their complete semantic paths.

The `type_predicates` workload was frozen at SHA-256
`8b04ff5b9ae889c940facb652e5c925c7ff2aa6350058292208ca29020192350`
before optimization. Home, `tsc` 6.0.3, and native TypeScript 7.0.2 all accept
the same 13,312-line project silently, and all three reject a preserved variant
that assigns a narrowed string property to `number` with `TS2322`. Its
five-run red baseline (`20260827T133314Z`) measured Home at 132.3 ± 1.8 ms
versus native TypeScript 7 at 79.8 ± 1.4 ms. The unchanged workload measured
69.0 ± 4.9 ms in snapshot `20260827T151143Z`: a 1.92× Home improvement
and a 1.01× win over the fastest competitor. The general implementation uses
exact token-aware source facts, lexical declaration indexes, parameter-name
buckets, binder-backed root lookups, and successful named-shape caches; it does
not recognize the benchmark's generated names or family count.

The `null_safe_access` workload was frozen at 8,192 lines and 245,538 bytes,
with SHA-256
`22559101b63ff7129383baa604a006d33a37cd0ba4aa499a849ffd26894ff57c`.
All three compilers accept the same project silently and reject a preserved
invalid tuple string-to-number assignment with `TS2322`. Its five-run red
baseline (`20260827T152206Z`) measured Home at 1166.8 ± 11.0 ms versus native
TypeScript 7 at 62.1 ± 1.6 ms: an 18.79× loss. In the unchanged 30-run
snapshot `20260827T154256Z`, Home measures 51.1 ± 14.1 ms versus 71.3 ± 26.9
ms for native TypeScript 7, a 22.83× Home improvement and a 1.40× mean win.
Profiling found source-annotation recovery repeatedly searching unrelated
typed signatures for contextually typed, unannotated arrow parameters. The
general lexical/source guard removes only that impossible search. A scaled
1,024-family profiling copy dropped from 71.70 seconds to 0.32 seconds; the
accepted corpus, configuration, validity gate, and timing schedule stayed
unchanged. The complete checker gate passes 4,192 tests including the new
source-recovery regression.

The checked-JavaScript margin follow-up retained the losing snapshot
`20260827T154256Z` rather than filtering its slow sample. Profiling a
2,048-family same-shape copy showed that first-time JSDoc comment ownership
queries still scanned every HIR node. Commit `332e22826` builds a sorted,
nested function-span index and resolves those positions by binary search plus
the enclosing-span chain. Its regression compares indexed and original-scan
answers at every source position in nested function, arrow, and function
expression input, and checks source-state invalidation. The scaled profile
copy fell from 4.55 seconds to 2.31 seconds; the unchanged accepted 128-family
source (SHA-256
`898573fc0f2567653fef3edb3675d768f825abd80b83e708e7d57d29049c03ec`)
measures 40.1 ± 0.9 ms versus native TypeScript 7 at 51.7 ± 1.1 ms in snapshot
`20260827T155812Z`, a 1.29× mean win. All three compilers still accept the
valid project silently and reject the preserved string-to-number JSDoc variant
with `TS2322`; the complete checker gate passes 4,193 tests.

The `destructuring` workload was frozen at 4,032 lines and 122,226 bytes,
with SHA-256
`17049403e0a09a25e1f5ca78d730a7a683e78fd375681aaf1af92c460bbde673`.
All three compilers accept the source silently and pass the five automatic
negative controls described above. Its five-run baseline (`20260827T160641Z`)
measured Home at 97.6 ± 0.4 ms versus native TypeScript 7 at 45.3 ± 2.1 ms:
a 2.15× loss. The same baseline also recorded a type-predicate loss, Home
71.4 ± 8.5 ms versus native TypeScript 7 at 68.2 ± 0.4 ms; those results
remain part of the record.

Profiling a 1,024-family same-shape copy found that source-annotation recovery
repeated raw containment scans for each identifier use, including repeated
rejection of object properties that resemble typed parameters. Commit
`06baa9965` materializes each queried name's candidate ranges once and reuses
them, without changing which candidates are accepted. The regression compares
cached and original scan results at every declaration/use position pair in
nested, default-parameter, object-literal, incomplete, and string-containing
sources, and verifies invalidation when source facts change. The scaled
diagnostic run fell from 34.44 seconds to 2.74 seconds; this single-run profile
measurement is not a suite speedup claim. The complete checker gate passes
4,194 tests and the ReleaseFast build passes. The accepted corpus, compiler
configuration, and interleaved timing schedule are unchanged. In the complete
30-run snapshot `20260827T162037Z`, the accepted destructuring project measures
47.8 ± 14.0 ms for Home versus 63.4 ± 25.2 ms for native TypeScript 7: a
1.32× mean win, with the substantial variance explicitly retained.
This milestone is tracked in
[issue #453](https://github.com/home-lang/home/issues/453).

The type-predicate margin follow-up
([issue #455](https://github.com/home-lang/home/issues/455)) retains snapshot
`20260827T162037Z`: Home 78.1 ± 2.3 ms versus native TypeScript 7 at
82.3 ± 7.4 ms, only a 1.05× mean lead. A 2,048-family same-shape profiling
copy measured 1.23 seconds before this follow-up and exposed repeated failed
named-object-shape searches during narrowing. Commit `2de4f7670` caches
negative lookup results with the type-name table generation, separately for
each class-preference mode.
Inserting or rebinding a type name invalidates those misses, while re-registering
the same binding does not. The original shape comparison and successful
lookup behavior are unchanged. Regression coverage checks registration,
same-count rebinding, no-op updates, source reset, and class/non-class
preference separation. The accepted type-predicate source hash is unchanged;
the four automatic negative controls strengthen the gate without adding work
to the timed project. The complete checker gate passes 4,196 tests, the
ReleaseFast build passes, and all three compilers pass all 17 positive projects
plus the nine automatic predicate/destructuring negative controls.

The same scaled diagnostic copy then measured 0.99 seconds, with retired
instructions falling from 16.582 billion to 13.298 billion. These single-run
profiling observations are not the suite comparison. A short, preliminary
10-sample comparison remained noisy (Home 78.9 ± 19.7 ms versus native
TypeScript 7 at 80.3 ± 9.8 ms). Follow-up sampling still identifies first-time
shape searches and function-declaration scans as remaining general costs.

The complete 30-run snapshot `20260827T163618Z` records Home at 87.7 ± 13.5 ms
versus native TypeScript 7 at 93.4 ± 17.1 ms, a 1.07× mean lead. The timing
variance does not establish a robust margin, so issue #455 remains open for
those remaining costs. All 17 workloads have lower Home means in this snapshot;
all samples, including the high-variance null-safe-access row, are retained.

The next #455 follow-up targets repeated function-declaration searches, which
appear at the top of 133 of 495 sampled stacks in the post-cache profiling
trace. A per-container index now retains the first eligible function binding
by name, including exported declarations and variable-bound function/arrow
initializers. Caller scope walks and binder precedence are unchanged; empty
and singleton lists still use the constant-size scan. Indexes are published
only after construction succeeds, and allocation failure uses the original
scanner. Regressions compare indexed and scanned results across overloads,
nested namespaces and blocks, exported bindings, and missing/non-function
names; they also verify source reset and failure at both index allocation
stages. The accepted benchmark source and compiler options remain unchanged.
The full checker suite passes 4,198 tests; the ReleaseFast build, all 17
three-compiler positive gates, and all nine automatic negative controls pass.

Commit `983c2c532` implements the function index. Alternating the preserved
pre-index and new release binaries on the accepted 256-family source gives
72.19 ± 3.12 ms before versus 70.12 ± 3.42 ms after (30 samples per binary,
three warmups). The 2,048-family copy gives 1,056.42 ± 59.81 ms before versus
850.96 ± 23.82 ms after (five samples per binary, two warmups). These are
interleaved before/after development measurements, not competitor results.

That larger input also exposes a remaining scaling loss. A preliminary
five-run, three-warmup round-robin comparison gives Home 801.0 ± 22.4 ms,
native TypeScript 7 at 369.4 ± 15.4 ms, and JavaScript TypeScript 6 at
1,063.8 ± 43.0 ms: Home is 2.17× slower than the faster competitor. All three
compilers accept it silently and reject all four guard/assertion controls.
The workload is now included separately as `type_predicates_large`, with
106,496 lines, 3,032,376 bytes, and SHA-256
`9966d3e8933894a6a67f4f28c606765df0a7650f6cef429a758797151c2f6bca`.
It uses the same generator and configuration; the original 256-family source
is unchanged. [Issue #457](https://github.com/home-lang/home/issues/457)
tracks this scaling gap alongside the smaller-workload margin in #455.
The full 30-run snapshot `20260827T165255Z` preserves the loss: Home
855.8 ± 42.1 ms versus native TypeScript 7 at 382.3 ± 25.1 ms, or 2.24× slower.
The smaller predicate workload measures 67.6 ± 2.6 ms versus 74.7 ± 6.0 ms,
a 1.11× mean lead. All 18 projects pass the shared positive gate, and all 13
automatic negative controls pass in every compiler. Issues #455 and #457
remain open for the remaining general lookup and scaling costs.

Commit `0494dc6b6` for #457 indexes necessary named-shape member facts. Each
fact includes member count, string/number/symbol index-signature types, member
name/type, and optional/readonly/method flags. A missing fact proves that no
registered named object can satisfy the original shape comparison. Present
facts never accept a shape: the full comparison still handles combinations
from different objects, obsolete bindings, and hash collisions. This preserves
the original duplicate-member behavior without adding a quadratic uniqueness
scan. Facts follow the type-name table lifetime across source resets; an
allocation failure disables the filter. Regressions cover member order,
duplicates, modifiers, index signatures, ignored display metadata, rebinding,
false positives, source reset, and allocation failure.
The full checker suite passes 4,201 tests; the release build, all 18 shared
projects, and all 13 automatic negative controls pass for every compiler.
Alternating preserved before/after release binaries gives 67.73 ± 2.85 ms
versus 66.13 ± 6.46 ms on the small workload (30 samples per binary), and
800.16 ± 62.91 ms versus 645.06 ± 13.10 ms on the large workload (10 samples
per binary), each after three warmups. These development comparisons retain
every sample and are separate from the complete competitor snapshot.

Commit `3c6f4e69e` for #457 indexes local value declarations. A fresh profile on an
8,192-family diagnostic copy of the same generator identified local declaration
scans as the largest sampled leaf (357 samples); this diagnostic copy does not
replace either frozen benchmark. The index records first eligible declarations
and exact statement ordinals per container and virtual section. Lookups retain
the nearest-container rule, export-wrapper boundaries, and declaration-order
checks rather than comparing source spans. Empty and singleton containers keep
the original constant-sized scan. Failed index construction releases partial
state and falls back to the original scanner. Differential tests compare both
paths for every syntax node across nested blocks, namespaces, exports, multiple
virtual files, declaration kinds, shadowing, and missing names; allocation
failure tests cover each construction allocation and retry.
All 4,203 checker tests, the release build, 18 shared projects, and 13 negative
controls per compiler pass. Alternating preserved member-fact-only and
local-index binaries after three warmups measured 83.09 ± 20.83 versus
84.58 ± 26.97 ms for the small workload (30 samples each), and 740.15 ± 51.21
versus 632.05 ± 22.70 ms for the large workload (10 samples each). The small
comparison is noisy and does not show an improvement; all samples, including
the 206.09 ms new-binary observation, are retained. Concurrent unrelated
workstation jobs were observed during this development comparison.

The complete post-index snapshot `20260827T172600Z` retains all 30 interleaved
samples after three warmups across all 18 workloads. Home has lower means on
17 of 18; large predicates are 592.0 ± 14.6 ms versus native TypeScript 7 at
377.6 ± 18.3 ms and JavaScript TypeScript 6 at 1105.1 ± 100.4 ms, a 1.57×
loss to native TS 7. Small predicates are 74.1 ± 27.2 versus 91.7 ± 47.2 ms,
a noisy 1.24× mean lead. The full checker suite passes 4,203 tests, all 18
shared projects pass, and all 13 automatic negative controls pass in every
compiler. All 1,620 timed samples exit successfully. Issues #455 and #457
remain open: general type-display-name scans and relation-cache pressure
remain profiling targets, and this snapshot does not establish an everywhere
win or a reliable small-predicate margin.

Commit `403482530` for #457 avoids exact type-name scans for never-registered type
IDs. A fresh profile of the frozen large workload recorded 36 sampled leaves
in `knownTypeDisplayName`; the 8,192-family diagnostic recorded 406. A
monotonic set is populated at the single type-name registration path. Missing
membership proves no exact-ID match exists; obsolete membership only permits
the original scan. This deliberately does not infer absence from the reverse
display-name map: rebinding its selected name can remove that reverse entry
while another alias still refers to the original type. The set follows the
type-name table across source resets, and allocation failure disables the
filter. Regressions cover registration after a miss, alternate aliases after
rebinding, obsolete IDs, source lifetime, structural/class/alias precedence,
and allocation failure during registration.
All 4,206 checker tests, the release build, all 18 shared projects, and all 13
automatic negative controls per compiler pass. Alternating preserved binaries
after three warmups measured small predicates at 73.89 ± 15.23 versus
74.79 ± 20.16 ms (30 samples each), and large predicates at 679.77 ± 165.58
versus 556.70 ± 27.55 ms (10 samples each). These noisy development results
retain every observation, including a 1,128.47 ms old-binary large sample and
a 155.18 ms new-binary small sample; the small comparison shows no improvement.

Commit `8187216d7` addresses FIFO relation-cache tombstone accumulation.
A deterministic diagnostic used the production capacities, packed relation
keys, 16×capacity unique insertions, and the existing half-cache FIFO eviction.
Without maintenance, the 4,096-entry cache had 8,192 backing slots containing
4,096 live entries and 4,096 tombstones: no free slots to terminate misses.
The 16,384-entry cache had only one free slot among 32,768. Rehashing in place
at each existing eviction boundary retained the same live entries and restored
4,096 and 16,384 free slots respectively. Both cache levels now perform this
allocation-free maintenance without changing capacity, FIFO order, pending
markers, or promotion behavior. A regression first failed on retained
tombstones, then passed with rehashing; it checks 512 insertions per level,
all retained/evicted results, pending-to-final overwrites, unchanged overwrite
order, and zero allocation attempts after reserving capacity.
All 4,207 checker tests, the release build, the 18 shared projects, and all 13
negative controls per compiler pass. The isolated cache-maintenance comparison
ran under substantial concurrent workstation activity: small
predicates were 112.81 ± 19.02 versus 114.80 ± 29.86 ms (30 samples each), and
large predicates were 940.16 ± 112.91 versus 1009.84 ± 243.44 ms (10 samples
each), after three warmups. Both new-binary means are higher in this comparison;
it does not demonstrate a timing improvement. All observations are retained,
including the 225.53 ms small and 1,537.53 ms large new-binary samples. The
deterministic tombstone regression establishes the corrected cache behavior,
not an end-to-end speedup by itself.
A fresh 8,192-family diagnostic profile after both changes no longer lists
exact type-name scanning or relation-cache lookup/insert among its leading
sampled leaves. Named-object shape comparisons lead with 390 samples, followed
by string comparisons at 338. This identifies the next profiling target; the
different profiles are not interchangeable timing measurements.

The full post-maintenance snapshot `20260827T174752Z` records 17/18 lower
Home means. Large predicates remain a loss: Home 557.5 ± 157.8 ms versus
native TypeScript 7 at 380.1 ± 23.4 ms and JavaScript TypeScript 6 at
1152.4 ± 255.2 ms, or 1.47× slower than the faster competitor. Small
predicates are 66.6 ± 3.8 versus 82.4 ± 26.5 ms, a 1.24× mean lead.
All 1,620 timed samples exit successfully, after all 18 positive projects
and all 13 negative controls pass in each compiler. Both published tables
match the raw data, and the frozen predicate hashes are unchanged.
[Issue #455](https://github.com/home-lang/home/issues/455) and
[issue #457](https://github.com/home-lang/home/issues/457) stay open for the uncertain small margin and remaining scaling
loss. Named-object shape comparisons are the next profiled target; any further
index must preserve member-order/duplicate behavior, binding lifetime, class
preference, and diagnostic-name selection rather than changing checked work.

Commit `4fccb476d` for #457 upgrades necessary member facts into candidate
buckets backed by a contiguous list. A valid named shape must occur in every
queried member's bucket, so the smallest bucket is a complete candidate set.
The query still checks each current name-to-TypeId binding, class preference,
and the original complete shape comparison. Duplicate member facts, repeated
registrations, stale bindings, and hash collisions cannot accept an invalid
shape. A unique matching name can return directly; multiple distinct matching
names fall back to the original table scan, preserving its diagnostic-name
selection order. This avoids depending on hash-table layout or imposing a new
name preference. Candidate storage follows the type-name table lifetime across
source resets. Failed bucket or list allocation disables the index and keeps
the original scanner. Differential regressions cover ambiguity across table
growth, class preference, member permutations and duplicates, exact-self
exclusion, rebinding, source lifetime, forced collisions, and both allocation
failure points.
All 4,209 checker tests, the release build, all 18 shared projects, and all 13
negative controls per compiler pass. Alternating preserved binaries after
three warmups measured small predicates at 78.63 ± 16.01 versus 80.22 ± 21.36
ms (30 samples each), and large predicates at 547.59 ± 51.70 versus
535.67 ± 38.06 ms (10 samples each). All samples are retained, including the
156.78 ms new-binary small sample. The large mean difference is modest relative
to the variability; this development comparison does not establish a robust
end-to-end improvement, and the small mean is higher.

The follow-up 8,192-family diagnostic profile no longer lists named-shape
comparison among its leading sampled leaves. String comparison leads with
420 samples; `isBuiltinName` is a recurring caller and has 49 direct leaf
samples. Its fixed spelling list (308 entries, 266 distinct spellings) is now
represented by a compile-time static string set in commit `5a537e057`, preserving the exact list,
duplicates, and case-sensitive lookup
without runtime allocation. `ITextWriter` still checks the attached source's
first `@lib` line, and the existing `Iterator`, `fetch`, and `Image` exceptions
remain unchanged. Focused regressions exercise every original list entry,
prefixed/suffixed misses, case variants, empty and non-ASCII names, no-source
behavior, and library-directive changes across source resets.
All 4,211 checker tests, the release build, the 18 shared projects, and all 13
negative controls per compiler pass. Alternating preserved candidate-index
and static-builtin binaries after three warmups measured small predicates at
74.68 ± 5.84 versus 69.55 ± 5.19 ms (30 samples each), and large predicates at
550.26 ± 33.58 versus 501.64 ± 11.87 ms (10 samples each). Every observation
is retained; the full competitor snapshot remains the basis for suite claims.
The post-change diagnostic profile records only two string-equality samples
directly under `isBuiltinName`. Most remaining string-equality samples are
under substring searches (294), including source setup, driver setup, program
collection passes, and directive queries. The next investigation should
attribute these repeated whole-source searches and preserve their exact
matching semantics; these profile counts are not timing speedups.

The full snapshot `20260827T181303Z` retains all 30 interleaved samples after
three warmups across 18 workloads, with 17/18 lower Home means. Large predicates
remain slower: Home 549.4 ± 87.3 ms, native TypeScript 7.0.2 460.4 ± 126.6 ms,
and JavaScript TypeScript 6.0.3 1369.6 ± 302.2 ms, a 1.19× loss to the faster
competitor. Small predicates are 64.8 ± 3.7 versus 83.2 ± 5.9 ms, a 1.28×
mean lead. Several later workloads have substantial variance during unrelated
workstation activity; neither the narrower ratio nor cross-session absolute
times isolate an optimization's effect. All 1,620 timed samples succeeded,
both tables match the raw data, and all 18 positive projects plus 13 negative
controls passed in every compiler. The full checker suite passes 4,211 tests.
Issues #455 and #457 remain open. Next work will investigate repeated
whole-source searches in setup, program collection, and directive handling
without weakening their matching semantics or benchmark inputs.

Commit `b1fe7c9f4` for #457 shares exact source-marker searches. A compile-time
byte automaton records the first position of each fixed substring in one
allocation-free pass, replacing independent setup searches and supplying
positions to existing directive parsers. Comments, strings, identifier
substrings, overlapping matches, and non-ASCII bytes retain the behavior of
independent `std.mem.indexOf` calls. The `require` prefilter retains its
identifier-boundary check. Directive parsing is unchanged, including uppercase
`@noLib` precedence over lowercase `@nolib`, first valid `@checkJs`/`@allowJs`
selection, and their existing case rules. Source replacement rebuilds the
index and clears the original caches. Virtual-filename queries return early
only when the source has neither recognized filename marker.
Differential regressions cover arbitrary generated bytes, overlaps and suffixes,
every setup feature flag, source resets, no-source/index fallback, and directive
precedence and casing. All 4,216 checker tests, the release build, all 18 shared
projects, and all 13 negative controls per compiler pass. Both predicate source
hashes remain unchanged.

The alternating preserved-binary development comparison uses three warmups,
30 small-predicate samples and 10 large-predicate samples per binary. Small
predicates measure 76.87 ± 8.88 ms before and 72.92 ± 9.33 ms after; large
predicates measure 522.19 ± 26.59 and 511.00 ± 59.31 ms. Every observation is
retained, including the new-binary 667.54 ms large sample. These differences are
modest relative to the variability and do not establish a robust end-to-end
speedup. The full interleaved competitor snapshot is the basis for suite claims.

Commit `59b4ad1c8` also adds an exact compiler-version preflight. Its five
regressions cover matching pins, stale TS 6 installs, the old
`7.0.0-dev.20260707.2` native build, prerelease suffixes, and rejection before
any result directory or workload timing is created. Both installed compilers
verify as `Version 6.0.3` and `Version 7.0.2`; the benchmark corpus and measured
commands are unchanged.

The full snapshot `20260827T183613Z` retains all 30 interleaved samples after
three warmups across 18 workloads. Home has 17/18 lower means. Large predicates
remain slower: Home 491.0 ± 54.1 ms, native TypeScript 7.0.2 430.2 ± 40.9 ms,
and JavaScript TypeScript 6.0.3 1278.3 ± 203.3 ms, a 1.14× loss to the faster
competitor. Small predicates measure 76.1 ± 8.6 versus 127.7 ± 15.2 ms,
a 1.68× mean lead. The different workstation conditions and substantial
variance prevent attributing the cross-session ratio change to this commit
alone. All 1,620 timed samples succeeded; balanced compiler ordering, exact
versions, both complete published tables, and frozen predicate hashes were
verified against the raw data. All positive projects and negative controls
passed in each compiler, alongside 4,216 checker tests and five harness tests.
Issues #455 and #457 remain open.

A separate post-run 8,192-family diagnostic profile still attributes 151 of
188 string-equality samples to substring searches. Recurring non-memory
callers include checker and driver setup, program namespace/interface/class
collection, and source-based self-assignment checks. These sample counts guide
the next investigation; they are not speedup measurements or an additional
accepted benchmark. Next work should reuse immutable source facts across
driver/program collection and inspect the remaining prefix searches while
preserving directive parsing, source-update lifetimes, and full type checking.

Commit `f18dd5662` targets repeated driver directive-line scans. The diagnostic
profile attributed 32 scalar-search samples to compiler-option values, 14 to
boolean directives, six to simple directive values, and three to JSX directive
detection. Each parser previously split every source line, although any
accepted directive must contain `@`. An allocation-free candidate-line iterator
now jumps to the next `@` using byte search and returns its complete original
line exactly once. Parsing rules remain unchanged: the first `@` on a line,
case and identifier-boundary rules, malformed or empty values, duplicate-line
order, and parser-specific first-match behavior all retain their prior meaning.
This changes neither tokenization nor type checking and adds no source cache.

Differential tests compare candidate contents and source offsets with
`splitScalar` filtered for `@`, covering arbitrary generated bytes, repeated
lines, embedded markers, CRLF, lone CR, empty input, and EOF. Driver regressions
exercise differing value/boolean parser behavior and JSX directive precedence.
All 173 driver tests, five harness tests, the release build, all 18 shared
projects, and all 13 negative controls per compiler pass. Both predicate hashes
are unchanged.

Alternating preserved binaries after three warmups measured small predicates
at 57.39 ± 3.51 ms before and 54.55 ± 3.26 ms after (30 samples per binary),
and large predicates at 461.76 ± 56.34 versus 426.87 ± 25.74 ms (10 each).
All observations are retained, including the 613.49 ms baseline large sample.
The lower means favor the change, but the large-case variability and outlier
limit the strength of that end-to-end inference; the full interleaved competitor
snapshot remains the basis for suite claims.

The full snapshot `20260827T185149Z` retains all 30 interleaved samples after
three warmups across 18 workloads, with 17/18 lower Home means. Large predicates
remain slower: Home 399.7 ± 25.6 ms, native TypeScript 7.0.2 338.0 ± 16.1 ms,
and JavaScript TypeScript 6.0.3 969.2 ± 31.0 ms, a 1.18× loss to the faster
competitor. Small predicates measure 53.3 ± 0.8 versus 74.6 ± 2.8 ms,
a 1.40× mean lead. All 1,620 timed samples succeeded, and balanced ordering,
exact versions, both complete tables, and frozen predicate hashes were
verified. All 18 positive projects and 13 negative controls pass per compiler;
173 driver tests and five harness tests pass. The unchanged 4,216-test checker
gate also passes from cache. No samples were removed. Some rows remain noisy,
and lower absolute times across sessions do not isolate this commit's effect.

The original small-predicate margin tracked in
[issue #455](https://github.com/home-lang/home/issues/455) is now materially
stronger than its initial 1.05× lead, with the accepted input and configuration
unchanged. This addresses that narrow issue, not universal performance:
[issue #457](https://github.com/home-lang/home/issues/457) remains open for the
large-case loss, and #416 continues to track broader coverage and optimization.

The separate post-run 8,192-family diagnostic profile records only five scalar
search samples under the three changed value/boolean directive parsers, while
program collection and other substring searches remain recurring callers.
Raw builtin lowering has 109 inclusive samples, with leading stacks in the
fixed `Function` signature construction invoked by predicate matching.
Source-based self-conditional-assignment checks also remain prominent.
These are profiling observations, not speedup measurements. The next step is
to check which repeated builtin constructions can be safely reused while
preserving rest-signature metadata and allocation-failure behavior, alongside
the remaining program/source-prefix work.

Commit `b5b5bd938` reuses the fixed internal member recipe for builtin
`Function`: its private `any[]` parameter type and two rest signatures. The
outer object still receives a fresh TypeId on every request, preserving the
existing declaration-identity behavior. The cache is published only after
complete successful construction and shares the checker/interner lifetime;
source replacement does not invalidate these immutable components or their
rest-signature metadata. A cached construction now adds one type instead of
rebuilding all four constituent types.

Three regressions cover structural equivalence with the original constructor,
fresh outer identities, member/parameter/return types, diagnostic names,
rest metadata, source replacement, and cold/cached allocation-failure sweeps
with recovery and leak checks. All 4,219 checker tests, 173 driver tests,
five harness tests, and the release build pass. All 18 positive projects and
13 negative controls pass per compiler; both predicate hashes remain unchanged.

Alternating preserved binaries after three warmups measured large predicates
at 387.24 ± 4.63 ms before and 361.42 ± 7.86 ms after (10 samples each),
about 6.7% lower mean time. Small predicates measured 59.61 ± 25.74 versus
58.96 ± 33.74 ms (30 each), with medians of 52.20 and 48.58 ms. All samples
are retained, including baseline/candidate maxima of 168.10/222.29 ms.
The noisy small-case means do not establish a clear improvement. Unrelated
workstation activity was present, and a source-format check overlapped part
of the paired comparison; these observations are not a controlled estimate
of compiler-only execution time.

The identity audit also found a pre-existing semantic discrepancy tracked in
[issue #467](https://github.com/home-lang/home/issues/467): with a declared
global `Function` containing a `call` method, direct and aliased predicates
fail to narrow a number/function union in Home, although both pinned
competitors accept the typed calls. An empty global `Function` is a distinct
control that correctly retains the union in TS 6 and TS 7. Ordinary assignment
of a function to the nonempty global `Function` already succeeds in Home.
The optimization preserves the baseline's three diagnostics exactly; it does
not fix or conceal that discrepancy, and this diagnostic probe is not an
accepted or timed benchmark. The later
[shape-aware semantic checkpoint](#declared-function-predicate-narrowing-untimed)
closes #467.

The full snapshot `20260827T191750Z` retains all 30 interleaved samples after
three warmups across 18 workloads, with 17/18 lower Home means. Large predicates
measure Home 379.3 ± 15.8 ms, native TypeScript 7.0.2 356.0 ± 20.1 ms,
and JavaScript TypeScript 6.0.3 1012.4 ± 56.3 ms: Home remains 1.07× slower
than the faster competitor. Small predicates measure 47.4 ± 0.9 versus
69.5 ± 2.3 ms, a 1.47× mean lead. All 1,620 timed samples succeeded;
540 complete rounds, balanced compiler order, exact versions, both tables,
and frozen predicate hashes were verified. All positive projects and negative
controls passed before timing. No samples were discarded or replaced.
The large-case performance issue #457 and broader tracker #416 remain open.

A separate post-run 8,192-family diagnostic profile records 28 inclusive
samples in raw builtin lowering. Substring searches remain prominent, including
program collection and checker/driver setup, while source-based direct
self-conditional-assignment checks account for 34 top-of-stack samples.
These counts identify further investigation targets, not speedup estimates or
an additional accepted benchmark. Next work should inspect repeated program
collection and source-prefix scans while preserving declaration visibility,
source-update lifetimes, and semantic checks.

Commit `dad87a665` removes impossible direct self-conditional-assignment scans.
The existing helper can only return true if the preceding semicolon-delimited
segment contains `?` in the selected assignment's RHS. An exact source-level
absence check now reuses the shared byte-marker index, and a segment-level
absence check rejects other segments before searching for identifier text.
The original assignment, identifier-boundary, and RHS checks still run for
candidates. No tokenization or type-checking rule changes; question marks in
comments and strings retain their original byte-scanning behavior.

Two regressions compare against the original implementation at every source
offset, including beyond EOF, with multiple names, generated bytes, CRLF,
comments/strings, semicolons inside strings, assignment lookalikes, and repeated
assignment candidates. They cover both cached and uncached marker lookup,
positive matches, null source, and repeated source replacement. All 4,221
checker tests, 173 driver tests, five harness tests, and the release build
pass. All 18 shared projects and 13 negative controls pass per compiler;
both predicate hashes remain unchanged. The release toolchain is
Zig `0.17.0-dev.1441+d5181a9c9`, using `ReleaseFast`.

Alternating preserved binaries after three warmups measured small predicates
at 49.30 ± 0.32 ms before and 45.39 ± 0.37 ms after (30 samples each).
Large predicates measured 415.61 ± 44.11 versus 375.56 ± 46.66 ms (10 each),
with medians of 393.78 and 361.44 ms. All observations are retained, including
the 500.35 ms candidate sample. Control flow measured 36.30 ± 2.84 versus
35.45 ± 0.83 ms (30 each), with medians of 35.49 and 35.23 ms and a 50.46 ms
baseline maximum; this does not establish a robust control-flow improvement.
The small-predicate result is consistent, but the large-case variability and
concurrent workstation activity limit the strength of that mean comparison.

The full snapshot `20260827T193257Z` retains all 30 interleaved samples after
three warmups across 18 workloads. Home has a lower mean on all 18, but large
predicates are a near tie: Home 326.0 ± 10.0 ms versus native TypeScript 7.0.2
326.6 ± 8.3 ms, with JavaScript TypeScript 6.0.3 at 956.6 ± 37.9 ms. Home's
0.2% mean advantage is small relative to the observed variability; medians are
323.18 and 324.02 ms. This does not establish a convincing lead, so
[issue #457](https://github.com/home-lang/home/issues/457) remains open for a
robust large-case margin. Small predicates measure 42.8 ± 1.7 versus
68.4 ± 2.0 ms, a 1.60× mean lead. All 1,620 timed samples succeeded;
540 complete rounds, balanced compiler order, exact versions, both tables,
and frozen predicate hashes were verified. No samples were discarded.

Commit `999258e16` makes the report's rounded-equal ratios explicitly say
`1.00× (near tie)` instead of displaying a misleading directional win. Five
regressions cover equality, either direction, and the symmetric two-decimal
boundary; all ten harness/report tests pass. This only changes presentation,
not measurements or their aggregation, and does not claim statistical
significance for larger displayed ratios.

A separate post-run 8,192-family diagnostic profile records only two
inclusive samples in the filtered self-conditional-assignment helper.
Repeated substring searches remain in program ambient-interface, namespace,
class, and CommonJS collection, alongside checker/driver setup. These counts
guide the next investigation, not a speedup claim or a new accepted benchmark.
Next work should share exact program source facts while auditing source
replacement, redirects, and declaration visibility. At this historical
checkpoint, the broader #416 goal, the #457 narrow margin, #467 semantic
discrepancy, and #464 unvalidated container harness were open; the later
[shape-aware semantic checkpoint](#declared-function-predicate-narrowing-untimed)
closes #467.

Commit `d33019821` shares exact program-source marker searches across 19
existing collection prechecks. Nine byte markers cover namespace/global,
ambient interface, class, augmentation, and CommonJS collection. The existing
matcher implementation is reused; collection parsers, identifier rules, and
declaration visibility are unchanged. Matches inside comments, strings, and
larger identifiers retain the original byte-search meaning.

Each serial, streaming, or parallel compilation entry builds a transient
snapshot for non-redirected files and clears it on every exit. Redirect sources
are excluded before reading their bytes. Source replacement invalidates the
snapshot, and calls outside a collection pass retain the original searches.
Snapshot construction adds no allocation path or retained source ownership.

Four new regressions compare exact first positions on generated bytes,
nonempty metadata from all six affected collection categories with and without
snapshots, source replacement and redirect exclusion, and successful/error
cleanup in all three compilation entry points. All 99 program tests,
4,221 checker tests, 173 driver tests, ten harness/report tests, and the final
release build pass. All 18 shared projects and 13 negative controls pass per
compiler, with frozen predicate hashes unchanged.

Alternating preserved binaries after three warmups measured small predicates
at 46.73 ± 6.07 ms before and 43.23 ± 0.75 ms after (30 samples each),
with medians of 45.18 and 43.27 ms. Large predicates measured
355.52 ± 21.14 versus 332.16 ± 7.11 ms (10 each), with medians of
348.05 and 330.08 ms. Many files measured 32.21 ± 1.53 versus
30.88 ± 1.35 ms (30 each). Every observation is retained, including baseline
maxima of 77.06 ms on small predicates and 413.82 ms on large predicates.
The lower means and medians favor the change, but concurrent workstation
activity and baseline outliers limit the inference from these paired samples.

The lifetime audit separately identified pre-existing source-update risks,
tracked in [issue #472](https://github.com/home-lang/home/issues/472): failure
after removing the old source-map entry could leave inconsistent state, and
canonical source replacement did not refresh borrowed redirect slices. The
later [atomic source replacement audit](#atomic-incremental-source-replacement-untimed)
closes those ownership gaps with dedicated failure/recovery coverage; the
transient snapshot optimization itself did not claim to fix them.

The full snapshot `20260827T195539Z` records 18/18 lower Home means across
30 interleaved rounds after three warmups. Large predicates measure
323.8 ± 10.2 ms for Home, 351.4 ± 15.2 ms for native TypeScript 7.0.2,
and 1010.4 ± 25.3 ms for JavaScript TypeScript 6.0.3: a 1.09× Home mean lead.
Small predicates measure 41.9 ± 0.8 versus 70.9 ± 2.0 ms, a 1.69× lead.

The independent large-predicate confirmation was declared before inspecting
the full-run results. Snapshot `20260827T200026Z` retains another 30 rounds
after three warmups: Home 327.1 ± 10.4 ms, native TS 7 359.7 ± 14.2 ms,
and TS 6 1026.1 ± 37.1 ms, a 1.10× Home mean lead. Home was faster than
native TS 7 in 29/30 paired large-case rounds of the full run and 30/30 in
the confirmation. The full-run table above is not replaced or averaged with
the confirmation. Both runs retain every observation, including their
outliers and variability.

Commit `d8e32bd9d` adds reproducible workload selection for these confirmations.
Six regressions cover the unchanged full-suite default, requested order,
empty/unknown/duplicate rejection, and failure before creating result files.
All 16 harness/report tests pass. Selection does not alter project inputs,
negative controls, compiler flags, timing, or sample aggregation.

All 1,710 timed samples succeeded. The 540 full-suite and 30 confirmation
rounds, exact versions, balanced ordering, selected-workload metadata,
published tables, frozen predicate hashes, and preserved release binary were
verified. The repeated local lead addresses the frozen scaling case tracked
in [issue #457](https://github.com/home-lang/home/issues/457); it does not prove
performance on other projects or machines. The earlier losses and near tie
remain in this history.

A separate post-run 8,192-family diagnostic profile still shows repeated
checker/driver setup and remaining ambient-interface collection searches.
These counts guide further work and are not timing claims. The broader #416
goal remains open: next coverage is dedicated async/await type propagation
under [issue #473](https://github.com/home-lang/home/issues/473), followed by
validated real-world projects and cross-platform measurements. Semantic
issue #467 was open at this historical snapshot; the later
[shape-aware semantic checkpoint](#declared-function-predicate-narrowing-untimed)
closes it. The unvalidated container path #464 remains open.

<details>
<summary>Previous full snapshot: 20260827T195539Z, commit d33019821</summary>

| Workload | tsc 6.0.3 | native TS 7.0.2 | Home 0.1.0 | Home vs fastest competitor |
|---|---:|---:|---:|---:|
| `startup` | 66.7 ± 2.5 ms | 42.0 ± 9.6 ms | **3.6 ± 0.4 ms** | **11.73× faster** |
| `many_files` | 215.4 ± 3.3 ms | 56.7 ± 7.5 ms | **32.4 ± 6.3 ms** | **1.75× faster** |
| `deep_types` | 146.0 ± 8.6 ms | 58.3 ± 3.7 ms | **14.1 ± 0.8 ms** | **4.12× faster** |
| `import_graph` | 139.0 ± 4.4 ms | 49.8 ± 4.1 ms | **29.3 ± 2.0 ms** | **1.70× faster** |
| `reexport_graph` | 111.0 ± 46.4 ms | 47.0 ± 19.2 ms | **31.1 ± 6.1 ms** | **1.51× faster** |
| `tsx_components` | 178.0 ± 25.2 ms | 50.2 ± 1.6 ms | **23.3 ± 4.1 ms** | **2.16× faster** |
| `generic_calls` | 188.4 ± 12.9 ms | 57.3 ± 3.9 ms | **23.2 ± 2.0 ms** | **2.47× faster** |
| `control_flow` | 190.2 ± 4.8 ms | 59.5 ± 2.2 ms | **33.6 ± 5.4 ms** | **1.77× faster** |
| `type_predicates` | 237.8 ± 12.7 ms | 70.9 ± 2.0 ms | **41.9 ± 0.8 ms** | **1.69× faster** |
| `type_predicates_large` | 1010.4 ± 25.3 ms | 351.4 ± 15.2 ms | **323.8 ± 10.2 ms** | **1.09× faster** |
| `null_safe_access` | 191.9 ± 4.1 ms | 57.2 ± 1.1 ms | **38.7 ± 0.5 ms** | **1.48× faster** |
| `destructuring` | 138.4 ± 1.6 ms | 47.3 ± 1.0 ms | **34.4 ± 0.5 ms** | **1.37× faster** |
| `overload_resolution` | 203.1 ± 3.4 ms | 64.6 ± 1.4 ms | **29.1 ± 0.6 ms** | **2.22× faster** |
| `class_hierarchy` | 186.1 ± 7.9 ms | 53.4 ± 7.8 ms | **28.1 ± 0.4 ms** | **1.90× faster** |
| `structural_objects` | 185.8 ± 2.9 ms | 58.1 ± 1.6 ms | **30.3 ± 0.6 ms** | **1.92× faster** |
| `interface_composition` | 214.9 ± 41.7 ms | 64.7 ± 4.3 ms | **45.6 ± 6.0 ms** | **1.42× faster** |
| `variadic_tuples` | 252.9 ± 6.3 ms | 77.7 ± 2.5 ms | 42.4 ± 1.0 ms | Provisional: older admission schema |
| `checkjs_jsdoc` | 211.5 ± 27.6 ms | 54.3 ± 1.2 ms | **36.9 ± 0.9 ms** | **1.47× faster** |

</details>

### Async admission audit and primitive return contracts

Before adding async/await to the measured suite,
[issue #473](https://github.com/home-lang/home/issues/473) checks a candidate
project with identical strict, ES2022, `noLib`, `skipLibCheck`, and `noEmit`
options for all three compilers. Promise, PromiseLike, Awaited, and
PromiseConstructor declarations are extracted unchanged from TypeScript
6.0.3's `lib.es5.d.ts` and `lib.es2015.promise.d.ts`; the shared minimal
global declarations remain unchanged. The candidate exercises generic async
projections, thenable assimilation, optional/discriminated result consumption,
typed async returns, Promise chains, and readonly tuple inputs to Promise.all.
It is **not an accepted benchmark and has no published timing**.

The initial audit found both false rejection of a valid generic async
projection and false acceptance of wrong Promise-chain/tuple result types.
Those remain open in [#476](https://github.com/home-lang/home/issues/476) and
[#475](https://github.com/home-lang/home/issues/475). The workload will not be
weakened or timed while those correctness controls fail.

It also exposed a broader return-checking gap: ordinary primitive return
contracts were checked only in special cases, affecting synchronous functions
as well as async functions. Commit `9e45e105d`, tracked in
[#474](https://github.com/home-lang/home/issues/474), applies the existing
assignability check to canonical primitive returns generally, including
`unknown` sources and strict-null unions. Async bodies check the awaited
value against the awaited declared result. Block callbacks retain their
actual inferred returns so the enclosing call can reject an incompatible
signature instead of replacing its result with the expected type. Obsolete
paired-setter-specific gating was removed.

Five regression groups and independent release-CLI checks use the same source
for Home, TS 6.0.3, and native TS 7.0.2. Each TypeScript baseline produces the
expected diagnostics below; Home's pre-change counts use the preserved
`d33019821` compiler. The non-strict group explicitly disables strict null
checks for every compiler.

| Shared correctness probe | Expected from each TS baseline | Home before | Home after |
|---|---|---:|---:|
| Wrong synchronous primitive returns | 5 × TS2322 | 0 | 5 |
| Wrong direct, promised, awaited, branch, and arrow async returns | 5 × TS2322 | 1 | 5 |
| Unknown and strict nullish return values | 5 × TS2322 | 2 | 5 |
| Non-strict nullish and any return values | No errors | 0 | 0 |
| Valid constrained/narrowed returns plus one invalid block callback | 1 × TS2345 | 0 | 1 |

These are rejection and diagnostic-code checks, not byte-for-byte parity:
[#478](https://github.com/home-lang/home/issues/478) tracks async error text
that still names the syntactic Promise annotation instead of its awaited
target, including an expression-arrow discrepancy present before this fix.
All 4,226 checker tests, 99 program tests, 173 driver tests, and 16 benchmark
harness/report tests pass. All existing 18 positive projects and 13 negative
controls per compiler pass; the small and large predicate hashes remain
unchanged. No compiler options or timed project inputs were weakened.

The post-fix full snapshot `20260827T202656Z` retains 30 interleaved rounds
after three warmups for all 18 existing workloads. Home has a lower mean in
every row. Large predicates measure Home 322.1 ± 13.3 ms, native TS 7
348.8 ± 15.7 ms, and TS 6 1027.8 ± 117.6 ms: a 1.08× mean lead over the
faster competitor. Small predicates measure 46.5 ± 19.5 versus
72.4 ± 10.8 ms, a 1.56× lead. These are measurements with stronger return
validation, not a claim that the correctness fix itself made checking faster.

The separately predeclared confirmation `20260827T203044Z` retains another
30 large-predicate rounds after three warmups: Home 342.5 ± 29.3 ms,
native TS 7 370.2 ± 22.0 ms, and TS 6 1086.3 ± 96.2 ms, again a 1.08×
Home mean lead. Home was faster than native TS 7 in 29/30 paired large-case
rounds in the full suite and 26/30 in the confirmation. The confirmation
is neither substituted for nor averaged into the main table.

Every one of the 1,710 timed samples succeeded. All 540 full-suite rounds
and 30 confirmation rounds were checked for complete results, exact compiler
versions, balanced order, one retained sample per compiler, and successful
exit codes. The release binary and frozen predicate hashes were verified.
Variance remains material: the full-run TS 6 control-flow standard deviation
is 127.9 ms, and Home's small-predicate standard deviation is 19.5 ms.
Both runs, including every outlier, remain in the record. These local synthetic
results do not establish leadership on real projects or other platforms.
Issues #473, #475, #476, and #478 remain open before async coverage can be accepted.

### Promise chain and readonly Promise.all inference (untimed)

[Issue #475](https://github.com/home-lang/home/issues/475) covers two false
acceptances from the async admission audit. A fulfilled callback result was
erased by `Promise.then`, and `Promise.all([numeric, text] as const)` did not
retain the readonly tuple's positional awaited types. Home now evaluates
`then`, `catch`, and `finally` at the instance call site after normal argument
validation. This keeps generic result inference local to the call instead of
embedding checker-owned type parameters in the shared structural Promise
graph. `Awaited` also distributes over union members, and the Promise static
path unwraps a readonly `as const` array expression before collecting tuple
elements.

The production-corpus gate exposed a separate interner lifetime bug while
validating this change: recursive iterable-element discovery retained a slice
into the shared member pool across calls that could grow and relocate that
pool. Union and intersection member IDs are now copied before recursion. This
is an ownership fix, not a crash suppression or a relaxed diagnostic path.

| Untimed correctness gate | TypeScript 6.0.3 | Native TypeScript 7.0.2 | Home |
|---|---:|---:|---:|
| Wrong assignment after `await pending.then(value => value.label)` | 1 × TS2322 | 1 × TS2322 | **1 × TS2322** |
| Wrong first-slot assignment after readonly `Promise.all` | 1 × TS2322 | 1 × TS2322 | **1 × TS2322** |
| Extended chain/default/rejection matrix | — | — | **7 × TS2322; 0 × TS2345; 0 × TS7006** |
| Full checker suite | — | — | **4,410/4,410** |
| Zod 4.5.2 21-file core proxy | 1 shared TS2307 | 1 shared TS2307 | **1 shared TS2307; 0 added** |

The final ReleaseSafe Zod run completed without a crash at 1,360 MB peak
supervised tree footprint. The ReleaseSafe compiler build peaked at 2,627 MB,
and the full checker run peaked at 2,258 MB. These figures are memory-safety
observations from guarded validation, not performance measurements. No timing
samples were collected, and async admission remains blocked on the other open
semantic controls under #473.

### Generic receiver callback validation (untimed)

Commit [`0612a9071`](https://github.com/home-lang/home/commit/0612a9071fd4231f0fce1f3e15c948ec2a3d503d)
fixes [#479](https://github.com/home-lang/home/issues/479), an underlying
generic-call failure found during the async admission audit. A callback such
as `mapper.project(value => value.label)` now retains the instantiated receiver
parameter and infers its actual return type. Previously, an unresolved method
return parameter prevented contextual parameter typing, and later re-lowering
of the declaration discarded the receiver's substitutions.

The fix operates on instantiated types, carries context into nested arrows and
explicit generic calls, and retains key-dependent indexed accesses until their
keys are inferred. Uniform string dictionaries still reduce to their
key-independent value type. Already-checked callbacks with identical contextual
types are reused; repeated checks do not duplicate an identical return error.

The six [regression sources](https://github.com/home-lang/home/blob/0612a9071fd4231f0fce1f3e15c948ec2a3d503d/packages/ts_checker/src/check.zig#L232408)
were checked with TS 6.0.3, native TS 7.0.2, and Home, each as both a global
script and an export-marked module. Every compiler receives identical
strict/noEmit/noLib/skipLibCheck/ES2022 inputs, the shared minimal library, and
unchanged Promise declarations from TS 6.0.3's `lib.es5.d.ts` and
`lib.es2015.promise.d.ts`. These declarations also prevent missing-global-type
errors during callback compatibility checks; they are not simplified facades.

| Untimed regression family | Expected diagnostics per invalid project | TS 6 / TS 7 / Home |
|---|---|---|
| Inferred receiver callback result | 1 × TS2322 | All match |
| Block, function-expression, and explicit callbacks | 3 × TS2322 | All match |
| Nested callbacks and distinct receiver types | 3 × TS2322 | All match |
| Constraints, defaults, and shadowed type parameters | 4 × TS2322 | All match |
| Incompatible callback arguments and missing properties | TS2322, TS2345, TS2339 | All match |
| Inferred indexed rest payloads | 3 × TS2322 | All match |

Removing only the deliberately invalid statements produces twelve valid
projects per compiler; all are accepted. Each compiler also reports the
expected diagnostic-code multisets for all twelve invalid projects, totaling
72 CLI checks across the three compilers. This verifies acceptance and
diagnostic codes, not byte-for-byte diagnostic parity. The local audit directory
is `bench/vs_tsgo/results/receiver-audit.eg3jPC`.

All 4,232 checker tests, 99 program tests, 173 driver tests, and 16 benchmark
harness/report tests pass. The final ReleaseFast binary also passes validation
of all 18 existing workloads and all 13 existing negative controls per compiler.
Both frozen predicate source hashes are unchanged. The focused checker cases
can be reproduced with:

```sh
./pantry/.bin/zig build test -Dfilter=ts_checker -Dts-checker-test-filter='generic interface callbacks'
```

No new timings were collected during the concurrent workstation build/test
activity. The main table and README therefore remain the measured
`9e45e105d` snapshot, not measurements of `0612a9071`. Removing redundant
callback checks is not, by itself, evidence of an end-to-end speedup.

The post-fix async audit still finds that Home accepts the invalid Promise
chain and `Promise.all` result controls rejected by both baselines
([#475](https://github.com/home-lang/home/issues/475)), and rejects the valid
generic async projection accepted by both
([#476](https://github.com/home-lang/home/issues/476)). A separate ordinary
interface/static-method probe confirms that global-script declarations are
erased to `any` while module declarations retain their types; this is tracked in
[#480](https://github.com/home-lang/home/issues/480), without Promise-specific
exceptions. Those issues and the async diagnostic-text issue
[#478](https://github.com/home-lang/home/issues/478) remain open under
[#473](https://github.com/home-lang/home/issues/473). Async remains untimed, and
the accepted workload count remains 18.

### Global declaration and graph admission audit (untimed)

The cross-file audit exposed a flaw in the earlier admission evidence: positive
projects can pass when imported types have been erased to `any`. Two existing
workloads fail direct negative controls, tracked in
[#487](https://github.com/home-lang/home/issues/487):

| Existing workload, invalid statements appended to a temporary copy | TS 6.0.3 / native TS 7.0.2 | Home |
|---|---|---|
| `import_graph`: assign `result.current` to `number`; read `result.missing` | TS2322 and TS2339 | Incorrectly accepts |
| `reexport_graph`: assign `value0.value` to `string`; read `value0.missing` | TS2322 and TS2339 | Incorrectly accepts |

The original projects are unchanged. These controls exercise the imported
generic types, not locally redeclared substitutes. Both controls are now part
of workload validation. The full selection must pass before any timing,
warmup, result directory, or metadata is created. The actual default run was
checked to stop at `import_graph` without creating results. The graph workloads
remain in the default suite; they are not silently removed to produce a pass.

New runs record admission schema 2 after validation. The report generator
retains all old graph measurements but labels pre-schema-2 graph comparisons
ineligible. The main table and README withdraw those two speed claims, and the
same correction applies to historical tables above. Other workloads need
broader rejection coverage; the remaining sixteen rows are not a claim of
sixteen proven-equivalent semantic workloads. The predicate and destructuring
controls remain useful evidence for their specific checks.

No new timing results were collected under the concurrent workstation load.
The old `9e45e105d` times and raw observations are retained unchanged. Fixing
cross-file types and re-running admission are prerequisites to graph retiming,
not evidence of a speedup themselves. The local evidence directory is
`bench/vs_tsgo/results/global-audit.TExK7j`.

The implementation checkpoint consists of
[`98176963c`](https://github.com/home-lang/home/commit/98176963c5ab6422c86e12139cc459f202aa1c05)
(resolve actual/forward declarations before global-name fallback),
[`6cba2f248`](https://github.com/home-lang/home/commit/6cba2f248445646302d1df6a02e07a299c4a2c1a)
(keep narrowed runtime values separate from type lookup), and
[`8a737cdb2`](https://github.com/home-lang/home/commit/8a737cdb208c0bab3ca518880eaf8c486705ba13)
(resolve explicit project files relative to the config directory, fixing
[#483](https://github.com/home-lang/home/issues/483)). The graph gate and
historical-report correction are in
[`16f84e743`](https://github.com/home-lang/home/commit/16f84e74365d42296bee71195dc645f5e0def376).

The [reproducible global audit](https://github.com/home-lang/home/blob/50abd827a75cbd94bdb29acb37f79ca39b88f369/bench/vs_tsgo/audit_globals.py)
uses identical strict/noEmit/noLib/skipLibCheck projects and the shared minimal
library. Same-file cases cover ordinary/generic methods, aliases, forward
declarations, merging, type/value-name coexistence, and module-local isolation.
Cross-file cases cover interfaces, same-named local values, generic static
methods, declared variables, and merging, each with declarations explicitly
listed before and after the app. Positive controls retain the declarations and
remove only the invalid statements. Passes below mean acceptance or the expected
diagnostic-code multiset, not byte-for-byte diagnostic parity.

| Untimed audit | TS 6.0.3 | Native TS 7.0.2 | Home |
|---|---:|---:|---:|
| Same-file declarations: 12 valid + 12 invalid projects | 24/24 | 24/24 | 24/24 |
| Cross-file globals: 10 valid + 10 invalid projects | 20/20 | 20/20 | 6/20 |
| Project/build/positional path controls | 6/6 | 6/6 | 6/6 |
| Existing generic receiver callback controls | 24/24 | 24/24 | 24/24 |

The default global audit performs 132 checks and intentionally exits nonzero:
all fourteen failures are Home cross-file cases. It does not waive or hide
known failures. Both root orders expose the same gaps. The path checks run from
outside the project, include relative, parent-relative, and absolute file
entries, and preserve positional-file behavior with explicit `--ignoreConfig`.
The missing TS5112 diagnostic when that flag is absent is separately tracked in
[#486](https://github.com/home-lang/home/issues/486).

```sh
python3 bench/vs_tsgo/audit_globals.py
python3 bench/vs_tsgo/audit_globals.py --family same-file
python3 -m unittest discover -s bench/vs_tsgo -p 'test_*.py'
```

The final source passes 4,232 checker tests, 101 program tests, 173 driver tests,
69 CLI tests, and 25 harness/report tests. The ReleaseFast binary's SHA-256 is
`7fd2c7e10e2471de753e474fca44abba8f00cfe4bf851284fe1b114653c756ce`.
All eighteen positive workloads still validate. With the stronger gates, Home
passes sixteen workload admissions and fails both graphs; both TypeScript
baselines pass all eighteen. The frozen predicate source hashes are unchanged.

[#480](https://github.com/home-lang/home/issues/480) remains open for real
cross-file declaration/type ownership; a same-file fix does not solve it.
[#487](https://github.com/home-lang/home/issues/487) tracks graph readmission
and broader coverage. Promise result erasure and the valid generic async
projection failure remain reproducible under
[#475](https://github.com/home-lang/home/issues/475) and
[#476](https://github.com/home-lang/home/issues/476), with the diagnostic-text
gap in [#478](https://github.com/home-lang/home/issues/478). Async remains untimed
under [#473](https://github.com/home-lang/home/issues/473).

### Checked-type ownership and assertion returns (untimed)

Commit [`091f15129`](https://github.com/home-lang/home/commit/091f1512954bf216b86556d9f892b6e59134e752)
moves core declaration/signature metadata into the stable `Compilation` result
before destroying its temporary checker. This fixes the retained relation
engine borrowing a destroyed rest-signature table. The transfer moves existing
maps, rather than cloning type graphs, and rebinds the engine as part of the
same operation. Type IDs, string IDs, and declaration nodes still belong to the
source compilation; equal numeric IDs from separate files are not interchangeable.

Post-compilation tests exercise rest-tuple assignability in both directions,
incompatible parameters, generic constraints/defaults and return members,
optional arguments, explicit `this`, predicate metadata, overloads, source
nodes, and independent compilation lifetimes. These tests also exposed
[#489](https://github.com/home-lang/home/issues/489): assertion signatures were
incorrectly lowered as boolean guards. Commit
[`134a9102d`](https://github.com/home-lang/home/commit/134a9102d4e9f022035033bbec058e385405a0d6)
preserves `void` for assertions and `boolean` for ordinary guards in declaration,
function-type, and low-level type lowering. Identical parameter lists remain in
the tests, so the guard/assertion collision is exercised rather than avoided.

| Untimed assertion family, valid and invalid scripts/modules | TS 6.0.3 | Native TS 7.0.2 | Home |
|---|---:|---:|---:|
| Function declarations | 4/4 | 4/4 | 4/4 |
| Function-type aliases | 4/4 | 4/4 | 4/4 |
| Interface methods | 4/4 | 4/4 | 4/4 |

These 36 shared CLI checks use identical strict/noEmit/noLib/skipLibCheck
projects and the minimal library. Invalid inputs must report two TS2322 errors:
using an assertion's result as boolean and assigning its signature to a
boolean-returning function. Removing only those two statements yields valid
controls. Before the fix, Home instead rejected the valid `void` result and
accepted the invalid boolean uses. The low-level tests additionally cover
`asserts value` without an `is` target.

The final functional source passes 4,236 checker tests, 175 driver tests,
101 program tests, 69 CLI tests, and 25 harness/report tests. All 72 earlier
generic-callback checks still pass. The local evidence directory is
`bench/vs_tsgo/results/type-ownership.DvClDP`; the ReleaseFast binary SHA-256 is
`2d1bd9e91307373ffe28b5f0af3f9efb11ea96039df3b2ad77c9540e60fee942`.

This was an ownership prerequisite, not completed cross-file type linkage.
At this checkpoint, [#488](https://github.com/home-lang/home/issues/488) remained
open for interpretation tables such as `NoInfer`, `this` markers,
readonly/pattern index metadata, and tuple/array origins. The following
checkpoint extends that ownership coverage. The global audit still has 14 Home failures out of 132
checks; Home still fails both imported-graph rejection gates. Sixteen workload
gates pass, but neither graph is readmitted and the other rows remain provisional.
No timing run or new speed claim was made under concurrent workstation load.
The published timings and frozen predicate sources are unchanged.

### Semantic metadata ownership and tuple admission (untimed)

Commit [`304fd5d06`](https://github.com/home-lang/home/commit/304fd5d0697ed8b2ee691bc80e4199413b0abb29),
the follow-up to [#488](https://github.com/home-lang/home/issues/488), retains
113 checked-metadata tables with the owning compilation. Structural type
payloads alone do not encode the following information:

| Retained category | Representative post-compilation coverage |
|---|---|
| Inference/context markers | `NoInfer<T>` targets and `ThisType<T>` receivers |
| Index signatures | Readonly flags, parameter/declaration names, template-pattern keys and values |
| Tuple/array interpretation | Origin flags, trailing rest elements, ordered symbolic spreads |
| Generator protocols | Yield, return, and next types |
| Nominal declarations | Class/enum origins, base links, visibility, abstract members, accessor writes, constructor overloads |
| Alias/signature provenance | Generic arguments, display names, predicates, overloads, and source-node IDs |

Allocator-owned maps and nested containers move intact. Six maps contain
borrowed leaf slices (display strings or concrete type arguments); capture
copies those leaves before any ownership changes, without copying type graphs
or retaining the diagnostic arena. Exhaustive allocation-failure injection
checks that a failed capture leaves the checker, empty destination, and relation
engine binding unchanged. Further tests read metadata after checker destruction
and after freeing the caller's source text. All IDs remain relative to the
owning HIR/interner: this does not implement foreign-ID remapping, module
resolution, declaration merging across files, or cycle/file-order handling.
Those remain under [#480](https://github.com/home-lang/home/issues/480) and
[#487](https://github.com/home-lang/home/issues/487).

Commit [`cbc757dcc`](https://github.com/home-lang/home/commit/cbc757dcc)
([#492](https://github.com/home-lang/home/issues/492)) adds a permanent
rejection gate for the existing variadic-tuple workload. The independent audit
uses seven valid/invalid pairs, retaining the full workload and changing only
one appended statement at a time:

| Untimed tuple control, positive + negative | TS 6.0.3 | Native TS 7.0.2 | Home |
|---|---:|---:|---:|
| Inferred concatenation result | 2/2 | 2/2 | 2/2 |
| Conditional head | 2/2 | 2/2 | 2/2 |
| Conditional tail | 2/2 | 2/2 | 2/2 |
| Captured spread | 2/2 | 2/2 | 2/2 |
| Consumed tuple result | 2/2 | 2/2 | 2/2 |
| Readonly element write | 2/2 | 2/2 | 2/2 |
| Out-of-bounds element | 2/2 | 2/2 | 2/2 |

All 42 controls pass both before and after the ownership change. The permanent
gate appends all seven invalid statements to a temporary copy and requires
exactly five TS2322 errors, one TS2493, and one TS2540, with compiler exit 1 or 2.
The original positive project must pass first. Schema 3 records this gate and
preserves the schema-2 graph gates; validation still precedes result-directory
creation, warmups, and all timing. Legacy tuple observations remain provisional,
not retroactively validated by this newer binary. The timed corpus is unchanged.

The final source passes 4,237 checker tests, 178 driver tests, 101 program tests,
69 CLI tests, and 29 benchmark-harness/report tests. The 36 assertion controls
still pass. All eighteen positive workloads pass; sixteen complete workload
gates pass and both graph gates fail. The global audit remains 44/44 for each
TypeScript baseline and 30/44 for Home (14 failures across 132 total checks).
Neither graph is readmitted. No new timings were collected under concurrent
workstation load.

Local evidence is retained in `bench/vs_tsgo/results/semantic-ownership.JD0NXP`.
The ReleaseFast binary SHA-256 is
`9e4957a5a17dab0ea15a7334ba09ac8044c6f2894101f180718ed190e314e99d`.
The unchanged tuple source SHA-256 is
`78105a6b28024f5ac1dd32cc81d3aa065a3a99a1972927e1880f0a28eec5324f`;
both frozen predicate source hashes also match the preceding checkpoint.

### Canonical type-graph transfer (untimed)

Commit [`e4c0a4caa`](https://github.com/home-lang/home/commit/e4c0a4caaf65c3a2177a66f7af65492e3ca0bbf3)
implements the payload-transfer primitive tracked in
[#494](https://github.com/home-lang/home/issues/494). It returns an owned
source-to-destination TypeId map, resolving structural dependencies iteratively
through the destination's canonical interner. A raw-copy prototype failed an
actual literal-assignability test because equal literals had different IDs;
the implementation now reuses canonical structural keys without changing the
relation engine. Declaration-scoped objects, type parameters, and enum literals
retain distinct identities across owners.

The caller supplies consistent string-content and declaration-owner mappings.
The transfer preserves all stored payload kinds, including shared/recursive
object and parameter edges, generic signature arguments, tuple flags,
conditional distribution, mapped modifiers, and enum identities. It validates
references and rejects unsupported unanchored cycles among immutable structural
keys instead of substituting `any`. Failure removes newly published intern keys
and enum entries before restoring payload-column lengths. Retained allocation
capacity and caller-owned string/provenance allocations are not rolled back.

Seven focused tests cover payloads after source destruction, overlapping IDs
from independent owners, real string/literal/signature relations, reuse of
fourteen existing structural keys, an 8,192-node forward dependency chain,
invalid mappings/references, and exhaustive allocation-failure rollback. The
focused runner passes 8/8 including its module test root.

Fault injection also exposed two initialization leaks, fixed in
[`99a8b7866`](https://github.com/home-lang/home/commit/99a8b7866b67a39c0c3c83b99cacda7ec5f237dc)
([#498](https://github.com/home-lang/home/issues/498)). `Pool.init` now cleans up
partially initialized columns; `Interner.init` releases its pool if initial
header reservation fails. Before-fix probes leaked 144 bytes on the first
failing column append and, with pool cleanup alone, 3,072 bytes in 21 allocations
on header-reservation failure. Both exhaustive initialization tests now pass.
These are ownership fixes, not measured speedups.

The full suites pass 4,246 checker tests, 178 driver tests, 101 program tests,
69 CLI tests, and 29 benchmark-harness/report tests. A fresh ReleaseFast binary
was checked against version-verified TS 6.0.3 and native TS 7.0.2:

| Untimed CLI audit | TS 6.0.3 | Native TS 7.0.2 | Home |
|---|---:|---:|---:|
| Existing positive workloads | 18/18 | 18/18 | 18/18 |
| Variadic tuple controls | 14/14 | 14/14 | 14/14 |
| Assertion-return controls | 12/12 | 12/12 | 12/12 |
| Same-file global declarations | 24/24 | 24/24 | 24/24 |
| Cross-file global declarations | 20/20 | 20/20 | 6/20 |

Home still passes sixteen workload gates and fails both imported-graph gates;
the global audit still reports fourteen failures across 132 checks. The transfer
primitive is **not yet called by program checking**. It does not transfer the
113 checked-metadata tables, construct real HIR/source provenance, resolve
imports or global merges, handle module cycles, or invalidate owner-specific
caches. These are prerequisites to integration under
[#480](https://github.com/home-lang/home/issues/480) and graph readmission under
[#487](https://github.com/home-lang/home/issues/487). Neither graph is readmitted,
and the other timing rows remain provisional.

Local evidence is retained in `bench/vs_tsgo/results/type-transfer.FHPXSf`.
The final ReleaseFast binary SHA-256 is
`860760ccee9bd0935b3371da534756bf148c733bce540d51c86714e96dce962c`.
The tuple and both predicate source hashes match the previous checkpoint.
No timings were collected during concurrent workstation activity; the published
timing snapshot is unchanged. Reproduce the focused checks and permanent
admission audit with:

```sh
./pantry/.bin/zig build test -Dfilter=ts_checker -Dts-checker-test-filter='type transfer'
./pantry/.bin/zig build test -Dfilter=ts_checker -Dts-checker-test-filter='initialization'
python3 -m unittest discover -s bench/vs_tsgo -p 'test_*.py'
HOME_TSC="$PWD/zig-out/bin/home-tsc" python3 bench/vs_tsgo/audit_globals.py
```

The last command intentionally exits nonzero while the fourteen known Home
failures remain; they are not skipped or waived.

### Owner-scoped semantic transfer and imported-owner audit (untimed)

Commit [`778597026`](https://github.com/home-lang/home/commit/7785970261d70ff50b2be710d09d78015a44a3c7)
adds a deep, owner-scoped clone of all 113 retained checked-metadata tables
([#500](https://github.com/home-lang/home/issues/500)). An exhaustive schema
distinguishes type, string, and declaration IDs from parameter positions,
argument counts, flags, and source-relative virtual-section offsets. Adding an
unclassified table or nested record field fails compilation. Slices, display
text, and nested containers are independently owned. Invalid references,
unmapped names/nodes, and many-to-one keys within a table fail explicitly;
the source stays unchanged and no partial result is returned. Callback
allocations and the previously transferred type pool remain caller-owned.

Each result must stay associated with its source owner. Canonical structural
signatures do not uniquely identify declaration-specific predicates or source
locations. Commit
[`84dc71ca5`](https://github.com/home-lang/home/commit/84dc71ca522ed33d0262aa5c3dbba25956eae960)
tests two independently compiled modules with same-named declarations against
one destination type interner. Both guards reuse an existing canonical
`(unknown) => boolean` signature, while their string/number predicates and real
source-owner/node references remain separate. It also checks constrained
generics, private class and enum origins, `NoInfer`, readonly pattern indexes,
symbolic tuple layouts, and positive/negative rest-signature assignability
after destroying the source semantic tables. Source HIR and text stay alive
for provenance lookup; registry handles are not fabricated local HIR nodes.

The focused checker runner passes 4/4 (three tests plus its module root),
including every table populated, exhaustive allocation-failure injection,
source destruction, mixed key fields, sentinel preservation, invalid mappings,
collisions, and successful retry. The full checker suite passes 4,249/4,249,
driver 179/179, program 101/101, CLI 69/69, and benchmark-harness/report 33/33
tests.

Commit [`50ff4add4`](https://github.com/home-lang/home/commit/50ff4add4552ef64e01826f00a59e9bd1c5f78ca)
adds the permanent [imported-owner audit](https://github.com/home-lang/home/blob/50ff4add4552ef64e01826f00a59e9bd1c5f78ca/bench/vs_tsgo/audit_owners.py).
Each family imports same-named declarations from two real modules. Valid and
invalid projects share every declaration and compiler option; only invalid
statements are appended to the negative app. Each pair runs with the app
explicitly listed before and after both declaration files. All three compilers
receive identical strict/noEmit/noLib/skipLibCheck inputs and the same minimal
library. Success requires acceptance of valid inputs or the exact expected
diagnostic-code multiset and failure exit status, not merely any rejection.

| Imported-owner audit: valid + invalid, both root orders | TS 6.0.3 | Native TS 7.0.2 | Home |
|---|---:|---:|---:|
| Constrained generic results and arguments | 4/4 | 4/4 | 2/4 |
| Distinct predicates on same-shaped signatures | 4/4 | 4/4 | 0/4 |
| Private class declaration origins | 4/4 | 4/4 | 2/4 |
| Ordered rest-tuple arguments | 4/4 | 4/4 | 2/4 |
| Readonly and mutable imported members | 4/4 | 4/4 | 2/4 |

Both the preceding `e4c0a4caa` binary and the fresh ReleaseFast audit find twelve
Home failures across sixty checks. Generic, rest, and readonly invalid programs
are incorrectly accepted. Valid predicate narrowing is rejected; invalid
predicate cases have extra/wrong diagnostics because values remain `unknown`.
Private-class assignments are rejected with TS2741 rather than the required
TS2322, so those failures are diagnostic mismatches, not false acceptance.
Both root orders produce the same outcomes. These are untimed correctness
controls, not additional speed rows or evidence that program integration works.

Neither transfer operation is called by program checking yet. The next step
must connect real source-aware declaration lookup and owner-scoped semantic
records to typed resolution, including merging, cycles, and invalidation under
[#480](https://github.com/home-lang/home/issues/480) and
[#487](https://github.com/home-lang/home/issues/487). Blindly merging these
records or treating their provenance handles as local HIR nodes would be
incorrect. Publication must also coordinate the separately transactional type
payload transfer and metadata clone; a failed metadata clone does not roll back
the caller's previously transferred type pool. The broader owner audit remains
part of readmission evidence; known failures are not waived. Historical timings
remain unchanged.

```sh
./pantry/.bin/zig build test -Dfilter=ts_checker -Dts-checker-test-filter='checked transfer'
./pantry/.bin/zig build test -Dfilter=ts_driver
python3 -m unittest discover -s bench/vs_tsgo -p 'test_*.py'
HOME_TSC="$PWD/zig-out/bin/home-tsc" python3 bench/vs_tsgo/audit_owners.py
```

## Program-wide name identity and bound global ownership (untimed)

Every prepared `Program` source now retains a reference-counted handle to one
sharded name store. Per-file HIR, binder symbols, declarations, NodeIds, and
TypeIds remain separate: equal StringIds are meaningful across the program,
but foreign local IDs are never interpreted through another source. Serial,
parallel, streaming, bind-only, incremental, and cached-emission paths retain
the store explicitly, and recompilation preserves existing name IDs.

Program-level global discovery now indexes actual root binder maps by name and
value/type/namespace meaning. Each entry retains its source owner and symbol,
including merged declaration NodeIds. Presence-only checker inputs are
projections of that index, replacing raw scans which only recognized the first
plain `var` declarator and mistook comment text for module syntax. The binder
hoists block and loop `var` declarations to the nearest variable environment
while keeping `let` and `const` lexical. CommonJS export discovery also reuses
the prepared syntax owner instead of compiling every source a second time.

The permanent untimed audit uses six visible declaration shapes (plain,
comma-separated, destructured, block-hoisted, comment-adjacent, and escaped)
and five isolation shapes (inline external module, function, namespace,
lexical block, and lexical loop). Every case runs with its declaration root
both before and after the consumer. Visible declarations have positive,
missing-name, and wrong-type controls; isolated declarations have positive and
negative controls. Negative projects only append an invalid use, exact
diagnostic-code multisets are required, and all compilers receive identical
projects and configurations.

| Bound-global ownership audit | TS 6.0.3 | Native TS 7.0.2 | Home before | Home after |
|---|---:|---:|---:|---:|
| Visible declaration and rejection controls | 36/36 | 36/36 | 4/36 | 24/36 |
| Module and lexical isolation controls | 20/20 | 20/20 | 18/20 | 20/20 |
| Total | 56/56 | 56/56 | 22/56 | 44/56 |

All twelve remaining Home failures are deliberately retained wrong-type
controls: the declaration name is visible, but its foreign TypeId is not yet
linked. This result therefore does not readmit either graph workload or change
any timing claim. Typed global/import resolution remains tracked in
[#480](https://github.com/home-lang/home/issues/480) and
[#487](https://github.com/home-lang/home/issues/487); shared identity and bound
ownership are tracked in
[#515](https://github.com/home-lang/home/issues/515).

Implementation commits
[`ac52b6203`](https://github.com/home-lang/home/commit/ac52b6203),
[`0a296c1de`](https://github.com/home-lang/home/commit/0a296c1de), and
[`347693b72`](https://github.com/home-lang/home/commit/347693b72) establish the
shared store, correct variable-environment binding, and add the source-owned
declaration index respectively. The audit itself landed in
[`3f1c34ee9`](https://github.com/home-lang/home/commit/3f1c34ee9).

The interner suite passes 16/16, binder 21/21, driver 187/187, and program
109/109, including allocation-failure cleanup, concurrent retention,
independent lifetimes, every execution mode, incremental recompilation, and
module isolation. The benchmark harness has 38 structural tests. Raw evidence
is retained in `bench/vs_tsgo/results/program-identities.4udJSv`. The
pre-change ReleaseFast binary is `callable-unions.2pCgVc/home-v5`, SHA-256
`462eaf0f83137f05205ac50705c5b4878c0e24f18a7b69fcb1804dc1a03a30dc`.
The final ReleaseFast binary is `program-identities.4udJSv/home-final`,
SHA-256
`0b7289905e110f79611a967097cab671ef1726e5ae06a60cfaf7bb8a26b604ea`.

```sh
python3 -m unittest discover -s bench/vs_tsgo -p 'test_*.py'
HOME_TSC="$PWD/zig-out/bin/home-tsc" python3 bench/vs_tsgo/audit_bound_globals.py
```

Local evidence is retained in `bench/vs_tsgo/results/checked-transfer.IO4A4Q`.
The final ReleaseFast binary SHA-256 is
`4ad8003e751e1471db6f7ea855c3bf8a3822063e89ddb793b85d3714efe93393`.
The fresh release also passes all 42 tuple controls and 36 assertion controls;
the global audit remains 30/44 for Home versus 44/44 for each TypeScript baseline
(fourteen failures across 132 total checks). All eighteen existing positive
workloads pass; Home passes sixteen workload gates and still fails both graph
gates. Neither graph is readmitted, and passing sixteen gates does not establish
sixteen equivalent semantic workloads. The tuple and both predicate source
hashes are unchanged. No timing run was made during concurrent workstation
activity.

### Atomic owner publication and source provenance (untimed)

Commit [`9d8be00d7`](https://github.com/home-lang/home/commit/9d8be00d7b1f61f487f559c863ce7cbc826e0d09)
adds a prepare/commit boundary to payload transfer. A pending transfer is
exclusively owned and cancelled on destruction unless committed. The combined
checked-transfer operation clones the complete semantic record before committing
payloads. Failure therefore restores the destination's original payload-column
lengths, intern keys, and enum entries, including when failure occurs only after
the entire payload graph has been prepared. Previously existing keys remain
valid. Retained allocation capacity is still owned by the destination.

Commit [`202f24b9a`](https://github.com/home-lang/home/commit/202f24b9ae2a56cabdae311533fd603bcb596ce5)
adds the production source-owner registry and replaces the earlier test-only
provenance mapper in the independently compiled owner regression. An owner
borrows immutable HIR, source text, strings, types, and checked metadata. Every
registration denotes a distinct owner/revision even when its path or memory
address is reused. Declaration handles resolve to the actual source owner,
node, span, path, and text. Unregistering the owner before destroying its
storage invalidates old handles; replacement sources cannot inherit those IDs.

Registry import coordinates declaration mappings with the combined
payload/semantic transaction. Failed imports remove newly created declaration
mappings while preserving earlier owners and handles. The caller's string
interner may retain unused strings and allocation capacity, but no failed type
or declaration mapping is published. A checked-owner view is available only
after semantic checking and metadata capture complete: bind-only results are
rejected. Completed checking with diagnostics remains distinct from an
unchecked source; valid empty programs also produce checked-owner views.
Readiness records phase completion, not imported-type parity or benchmark
eligibility.

| Untimed regression | Verified coverage |
|---|---|
| Pending transfer lifecycle | Explicit cancellation, repeated cleanup, commit, prior canonical keys and enum entries |
| Combined publication | Exhaustive allocation failures across payload and semantic preparation; late invalid mappings/collisions; successful retry |
| Source provenance | Real HIR/text lookup, same-path replacement, invalid spans/nodes, and stale-owner rejection |
| Coordinated registry rollback | Existing mappings survive; newly prepared mappings and types disappear together on failure |
| Compiled owners | Distinct predicates on a shared canonical signature, generic constraints, nominal origins, readonly/index metadata, tuples, and rest relations |
| Readiness | Bind-only compilation cannot be published as checked; empty and diagnostic-bearing checked results are distinguished |

The focused transfer runner passes 14/14, including its module test root.
The full checker suite passes 4,252/4,252, driver 183/183, program 101/101,
CLI 69/69, and benchmark harness/report 33/33 tests. The source registry's
failure tests include errors after the object header has already created its
real declaration mapping.

This completes the publication/provenance prerequisite in
[#504](https://github.com/home-lang/home/issues/504), not source-aware program
resolution. The shared transfer pool must use one registry's declaration
handles for **all** declaration-bearing types, including the local owner;
owner-local HIR IDs and another registry's handles must not be mixed into it.
Handles are not local HIR indices. Program lookup still needs owner-aware
interpretation, declaration merging, module-cycle handling, and dependency
invalidation under [#480](https://github.com/home-lang/home/issues/480) and
[#487](https://github.com/home-lang/home/issues/487). Unregistering a source
invalidates provenance; callers must also stop using its dependent semantic
records. The registry does not yet implement that program-wide invalidation.

```sh
./pantry/.bin/zig build test -Dfilter=ts_checker -Dts-checker-test-filter='transfer:'
./pantry/.bin/zig build test -Dfilter=ts_driver
python3 -m unittest discover -s bench/vs_tsgo -p 'test_*.py'
HOME_TSC="$PWD/zig-out/bin/home-tsc" python3 bench/vs_tsgo/audit_globals.py
HOME_TSC="$PWD/zig-out/bin/home-tsc" python3 bench/vs_tsgo/audit_owners.py
```

Local evidence is retained in `bench/vs_tsgo/results/owner-publication.xWNTr8`.
The final ReleaseFast binary SHA-256 is
`6d6b278c9df4db5a67171436def69c720fbe4d91e3171e8221c6d9cb161f4134`.
Fresh CLI audits against version-verified TS 6.0.3 and native TS 7.0.2 retain
the preceding checkpoint's results: all 42 tuple and 36 assertion controls
pass; the global audit has fourteen Home failures (30/44 versus 44/44 for each
baseline), and the imported-owner audit has twelve (8/20 versus 20/20).
All eighteen positive workloads pass; Home passes sixteen workload gates and
fails both graph rejection gates. Passing those sixteen gates is not proof of
sixteen semantically equivalent workloads.
The tuple and both frozen predicate source hashes are unchanged.
No timing claim follows from these ownership tests; historical timings remain
unchanged, and neither graph is readmitted.

### Prepared program discovery and expanded global audit (untimed)

Commit [`4693c6277`](https://github.com/home-lang/home/commit/4693c6277)
separates source preparation (parse/bind) from one-shot checking and emit.
Preparation retains the original HIR, tokens, binder symbols, declaration-file
flag, syntactic-error flag, and JSX comma-recovery spans. The parser can be
destroyed before checking begins. Checked-owner publication still occurs only
after semantic checking and metadata capture; preparation alone is not a typed
source owner. Failed checking is deinitializable and must not be retried on the
partially checked object.

Commit [`83d145926`](https://github.com/home-lang/home/commit/83d145926)
uses that boundary in the program pipeline. Import/reference discovery performs
parse/bind only and skips semantic fact collection during discovery rounds.
After the graph stops expanding, checking reuses its bound sources against the
final program facts. Conformance no longer reparses/rebinds/checks the complete
graph a second time. Serial, parallel, and streaming paths share the per-file
lifecycle. Streaming reference checks also receive the final known-path list.
If a caller explicitly checked an incomplete graph before expanding it, those
semantic results are invalidated and rebuilt; unchanged repeated discovery
retains the checked owners. This is not dependency-aware incremental checking.

The driver suite passes 186/186, program 105/105, and CLI 69/69. Regressions
cover retained binder/token identity, emit/check idempotence, declaration-file
and parser-recovery state, multi-hop discovery, serial/parallel/streaming
results, zero-worker fallback, expansion invalidation, and allocation-failure
cleanup/retry. The conformance suite passes 1,417/1,417. The unchanged checker
test target was a cache hit; no fresh checker execution is claimed here.

A separate CLI probe lists only the minimal library and `app.ts` as roots:

```ts
// app.ts
/// <reference path="./bridge.d.ts" />
globalThis.lateValue;
// bridge.d.ts
/// <reference path="./definitions.d.ts" />
// definitions.d.ts
declare var lateValue: number;
```

These are three separate source files, not concatenated input. Every compiler
uses the same strict/noEmit/noLib project and minimal library. Two invalid
variants append statements to the unchanged app: one adds `missingValue; const
bad: string = 1;`, and the other adds `const wrong: string =
globalThis.lateValue;`. Diagnostic multisets and exit status must match.

| Untimed transitive-reference probe | TS 6.0.3 | Native TS 7.0.2 | Home before | Home after |
|---|---|---|---|---|
| Valid project | Pass | Pass | False TS6053 × 2 and TS7017 | Pass |
| Invalid local code | TS2304 + TS2322 | TS2304 + TS2322 | Expected errors plus false reference/global errors | TS2304 + TS2322 |
| Invalid global property assignment | TS2322 | TS2322 | Incorrect reference/global diagnostics | Incorrectly accepted |

This proves the scheduling correction, **not** typed-global parity. The earlier
binary is the preceding checkpoint's `home-final` (SHA-256 `6d6b278c9df4db5a67171436def69c720fbe4d91e3171e8221c6d9cb161f4134`).
The before/after probe has twelve checks including that older Home binary:
four fail, three in the older Home and one in the new Home.

Commits [`bebe678de`](https://github.com/home-lang/home/commit/bebe678de) and
[`445422c60`](https://github.com/home-lang/home/commit/445422c60) extend the
permanent global audit with sibling ambient `let` and `const` bindings and
typed `globalThis` reads, each positive/negative and with both
declaration-before/after-app orders. The lexical cases report false TS2304;
the invalid `globalThis` assignments are accepted. Neither failure is waived.
The original 44 controls retain their prior results; the larger denominator
reflects twelve added controls, not a timing or correctness regression.

| Fresh untimed audit | TS 6.0.3 | Native TS 7.0.2 | Home |
|---|---:|---:|---:|
| Expanded globals | 56/56 | 56/56 | 32/56 |
| Imported owners | 20/20 | 20/20 | 8/20 |
| Tuple controls | 14/14 | 14/14 | 14/14 |
| Assertion controls | 12/12 | 12/12 | 12/12 |

All eighteen positive benchmark workloads pass. Home still fails both graph
rejection gates and passes the other sixteen gates; that is not evidence of
sixteen semantically equivalent workloads. Both graph timing claims remain
ineligible. The tuple and both predicate corpus hashes are unchanged, and no
timings were collected during concurrent workstation activity.

```sh
./pantry/.bin/zig build test -Dfilter=ts_driver
./pantry/.bin/zig build test -Dfilter=ts_program
./pantry/.bin/zig build test -Dfilter=ts_conformance
python3 -m unittest discover -s bench/vs_tsgo -p 'test_*.py'
HOME_TSC="$PWD/zig-out/bin/home-tsc" python3 bench/vs_tsgo/audit_globals.py
HOME_TSC="$PWD/zig-out/bin/home-tsc" python3 bench/vs_tsgo/audit_owners.py
```

The harness suite passes 33/33. Local evidence, including the independent
discovery probe and raw diagnostics, is retained in
`bench/vs_tsgo/results/prepared-program.Wx2zap`. The fresh ReleaseFast binary
SHA-256 is `a3eddac96fe1b07d7876defc63a2cda06b9f13210b333e8dc57e2b38e8a0ea12`.
This addresses the scheduling/reuse work in
[#505](https://github.com/home-lang/home/issues/505). Actual owner-aware global
and import type resolution, declaration merging, and module-cycle semantics
remain open in [#480](https://github.com/home-lang/home/issues/480) and
[#487](https://github.com/home-lang/home/issues/487), under the performance
tracker [#416](https://github.com/home-lang/home/issues/416).

### Callable identity and scoped inference (untimed)

The audit added in [`d4e63ff6c`](https://github.com/home-lang/home/commit/d4e63ff6c)
exposes a declaration-identity bug tracked in
[#507](https://github.com/home-lang/home/issues/507): signatures with equal
parameter and return types shared a TypeId even though their predicates,
optional/rest parameters, generic binders, and declaration metadata differed.
For example, the predicate and ordinary boolean methods below must not share
narrowing behavior:

```ts
interface Guards {
  number(value: unknown): value is number;
  plain(value: unknown): boolean;
}
declare const guards: Guards;
declare let value: unknown;
const plain = guards.plain;
if (plain(value)) { const bad: number = value; } // TS2322
```

The earlier Home binary accepts that invalid assignment; both pinned TS
compilers reject it. The permanent audit has seven families: predicate aliases,
direct calls, wrapper objects, predicate assignments, rest parameters, optional
parameters, and generic arity. Every family includes valid/invalid pairs in
both declaration orders and script/module scopes: 56 cases per compiler.
Only invalid statements are appended to each positive project. All compilers
receive identical files, flags, and the minimal library; exit status and exact
diagnostic-code multisets must agree. No failures are skipped and no timings
are taken by this audit.

Commit [`15f050f23`](https://github.com/home-lang/home/commit/15f050f23)
changes callable creation to allocate distinct identities without an erased-shape
hash entry. Structural relations still decide compatibility. Creation reserves
all pool columns before publishing lengths, and retains offsets when its input
parameters borrow the same pool. Type transfer preserves distinct imported
callables while still deduplicating immutable keys.

Related checker corrections explicitly preserve predicates/generic metadata
during inference, prevent local generic callback binders from becoming outer
inference candidates, retain identity for unaffected substitutions, and use
structural subtype reduction for conditional objects with callable members.
Argument context snapshots remain valid while checking earlier arguments grows
the signature pool. These replace dependencies on accidental TypeId sharing;
they do not add name-specific or benchmark-specific exceptions.

| Callable family | TS 6.0.3 | Native TS 7.0.2 | Home before | Home after |
|---|---:|---:|---:|---:|
| Predicate alias | 8/8 | 8/8 | 4/8 | 8/8 |
| Predicate direct call | 8/8 | 8/8 | 4/8 | 8/8 |
| Predicate wrapper | 8/8 | 8/8 | 4/8 | 8/8 |
| Predicate assignment | 8/8 | 8/8 | 4/8 | 8/8 |
| Rest parameters | 8/8 | 8/8 | 4/8 | 8/8 |
| Optional parameters | 8/8 | 8/8 | 2/8 | 8/8 |
| Generic arity | 8/8 | 8/8 | 4/8 | 8/8 |
| Total | 56/56 | 56/56 | 26/56 | 56/56 |

The fresh release also passes all 14 tuple controls and 12 assertion controls.
The global and imported-owner audits remain at 32/56 and 8/20 respectively;
their individual pass/fail results and diagnostic-code multisets are unchanged.
All eighteen positive benchmark workloads pass, but Home still accepts the
invalid imported-property controls for both module graphs. Both graph timing
claims remain ineligible. Passing the other sixteen admission gates does not
establish semantic equivalence for all their language features.

The checker suite passes 4,257/4,257, conformance 1,417/1,417, driver 186/186,
program 105/105, CLI 69/69, and harness tests 35/35. Tests cover distinct callable identities, pool growth,
allocation-failure publication, transfer relations and metadata, unaffected
substitution, hidden predicate targets, and scoped callback binders. The two
existing overload-context fixtures also match both pinned compilers' complete
diagnostic-code multisets in a separate CLI probe (six checks, no failures).
The transitive-reference probe remains at 2/3 for Home and 3/3 for each TS
baseline. Repository-wide Pickier aborted at its 100,000-file safety limit
(177,405 files discovered); targeted lint of the changed files passes with
one pre-existing README link-fragment warning.

```sh
./pantry/.bin/zig build test -Dfilter=ts_checker
./pantry/.bin/zig build test -Dfilter=ts_driver
./pantry/.bin/zig build test -Dfilter=ts_program
./pantry/.bin/zig build test -Dfilter=ts_conformance
./pantry/.bin/zig build home-tsc -Doptimize=ReleaseFast
python3 -m unittest discover -s bench/vs_tsgo -p 'test_*.py'
HOME_TSC="$PWD/zig-out/bin/home-tsc" python3 bench/vs_tsgo/audit_callables.py
HOME_TSC="$PWD/zig-out/bin/home-tsc" python3 bench/vs_tsgo/audit_globals.py
HOME_TSC="$PWD/zig-out/bin/home-tsc" python3 bench/vs_tsgo/audit_owners.py
```

Local raw evidence is retained in
`bench/vs_tsgo/results/signature-identity.6jiDkG`. The before binary SHA-256 is
`a3eddac96fe1b07d7876defc63a2cda06b9f13210b333e8dc57e2b38e8a0ea12`;
the fresh ReleaseFast binary is
`d7ecf960b76ef1f61b3e9acf4ebb97cad70fc3d087db20c5a5cdce03d82e6ffc`.
Both installed baseline versions were verified exactly before the audits.
Predicate and tuple corpus hashes are unchanged. No new timings were collected,
so this checkpoint makes no speedup or universal-leadership claim. Actual
cross-file type resolution remains open in
[#480](https://github.com/home-lang/home/issues/480) and
[#487](https://github.com/home-lang/home/issues/487).

### Callable union predicates and receivers (untimed)

The follow-up audit in
[`79d9ce2ca`](https://github.com/home-lang/home/commit/79d9ce2ca), tracked in
[#511](https://github.com/home-lang/home/issues/511), tests the semantic work
required when choosing between callable values. Distinct callable identities
alone do not prevent an erased-shape subtype check from discarding a branch:

```ts
declare function guard(value: unknown): value is number;
declare function plain(value: unknown): boolean;
declare let value: unknown;
const selected = [guard, plain];
if (selected[0](value)) { const bad: number = value; } // TS2322
```

The previous Home binary accepts this invalid narrowing. Conversely, unions
of genuine guards lose their shared narrowing information in several paths,
rejecting valid uses. A callable union also requires a receiver satisfying
every possible branch, rather than any one branch as for an overload set.

The permanent audit contains four families, each tested with declaration and
branch order varied independently, arrays and conditional expressions, bare
callables and object wrappers, script/module scope, and valid/invalid pairs.
That is 64 cases per family and 256 per compiler. Negative projects only append
an invalid use to the corresponding positive project. Files, compiler flags,
and minimal library are identical for all three compilers. Exact installed
versions, exit statuses, and diagnostic-code multisets are checked; no failures
are waived. These are untimed controls, not new timed workloads.

| Callable union family | TS 6.0.3 | Native TS 7.0.2 | Home before | Home after |
|---|---:|---:|---:|---:|
| Predicate plus ordinary boolean | 64/64 | 64/64 | 60/64 | 64/64 |
| Different predicate targets | 64/64 | 64/64 | 12/64 | 64/64 |
| Same predicate target | 64/64 | 64/64 | 16/64 | 64/64 |
| Explicit receiver requirements | 64/64 | 64/64 | 32/64 | 64/64 |
| Total | 256/256 | 256/256 | 120/256 | 256/256 |

Commit [`7d16f7ab8`](https://github.com/home-lang/home/commit/7d16f7ab8)
consults predicate and receiver metadata before reducing
callable unions. Resolved signatures combine predicate targets only when
every branch promises a compatible predicate kind and argument position.
Combined targets have no fabricated source annotation. Receiver checking uses
the union's combined signatures, which intersect receiver requirements; the
zero-argument and two-branch restrictions are removed. A previous receiver
substitution based on accidentally shared signature identity is also removed.
Arity is captured before interning can invalidate borrowed parameter storage,
and union-member traversal retains its own stable IDs. Matching retains the
selected common parameter contract instead of substituting a longer branch's
parameters, preserving required/minimum and maximum argument counts. Result
overloads are deduplicated by their complete parameter/receiver contracts,
not by the partial compatibility used to find cross-branch candidates.

The two baseline versions agree on every audit case. A separate diagnostic
probe found that a direct, non-union receiver missing one required property
produces TS2684 in TS 6 and TS2741 in native TS 7. The existing native-style
elaboration is retained; this disagreement is not hidden by relaxing the audit.

The final release also passes all 56 callable-identity controls, 14 tuple
controls and 12 assertion controls. Four additional checker-fixture comparisons
cover five-way union arity, valid optional/rest calls, conditional minimum
arity, and three-way predicate/receiver composition: all twelve compiler/fixture
checks match the pinned baselines. All eighteen positive workloads pass and
sixteen rejection gates pass. The two graph gates still fail; global controls
remain 32/56, imported-owner controls 8/20, and transitive-reference checks 2/3
for Home. Those gaps are not waived by the new callable results.

The full checker suite passes 4,261/4,261, including the original arity
regressions unchanged and the new predicate/receiver tests. Conformance passes
1,417/1,417. Driver passes
186/186, program 105/105, CLI 69/69, and harness 37/37. Repository-wide Pickier
aborts at its 100,000-file safety limit (177,457 files discovered); targeted
lint has no errors and one pre-existing README fragment warning.

Raw evidence is retained in `bench/vs_tsgo/results/callable-unions.2pCgVc`;
final compiler verification logs use the `-v5.log` suffix. The frozen pre-change binary
is `signature-identity.6jiDkG/home-final`, SHA-256
`d7ecf960b76ef1f61b3e9acf4ebb97cad70fc3d087db20c5a5cdce03d82e6ffc`.
The final ReleaseFast binary is `callable-unions.2pCgVc/home-v5`, SHA-256
`462eaf0f83137f05205ac50705c5b4878c0e24f18a7b69fcb1804dc1a03a30dc`.
Earlier candidate runs, including failed regression runs, are retained too.
Predicate and tuple workload hashes are unchanged. No new timings were
collected and both graph speed claims remain ineligible. Actual typed global
and imported declaration linkage remains open in
[#480](https://github.com/home-lang/home/issues/480) and
[#487](https://github.com/home-lang/home/issues/487).

```sh
./pantry/.bin/zig build test -Dfilter=ts_checker
./pantry/.bin/zig build test -Dfilter=ts_conformance
./pantry/.bin/zig build home-tsc -Doptimize=ReleaseFast
python3 -m unittest discover -s bench/vs_tsgo -p 'test_*.py'
HOME_TSC="$PWD/zig-out/bin/home-tsc" python3 bench/vs_tsgo/audit_callable_unions.py
HOME_TSC="$PWD/zig-out/bin/home-tsc" python3 bench/vs_tsgo/audit_callables.py
HOME_TSC="$PWD/zig-out/bin/home-tsc" python3 bench/vs_tsgo/audit_globals.py
HOME_TSC="$PWD/zig-out/bin/home-tsc" python3 bench/vs_tsgo/audit_owners.py
```

### Checked-owner lifetime and typed-global consumer contract (untimed)

The next checkpoint for [#480](https://github.com/home-lang/home/issues/480)
and [#487](https://github.com/home-lang/home/issues/487) establishes source
lifetime and checker lookup boundaries. Commit
[`33d8c15c5`](https://github.com/home-lang/home/commit/33d8c15c5) registers each
checked program-file revision with its source-owner registry and tombstones
that identity before replacement or destruction. Parallel publication is
serialized; incremental recompilation retains unaffected owners and assigns
fresh identities to replacements. Commit
[`76d6a8b2d`](https://github.com/home-lang/home/commit/76d6a8b2d) leaves scanner
recovery results without checked type storage unregistered, instead of
asserting that every diagnostic-bearing result has a typed source view.

Commit [`a142705f1`](https://github.com/home-lang/home/commit/a142705f1)
lets the checker accept explicit value/type bindings already relocated into
its receiving type pool and string keyspace. Local and forward declarations
take precedence. A separate property flag distinguishes global `var`-style
bindings from lexical bindings for dotted, bracketed, and indexed-`typeof`
access through `globalThis`; local bindings named `globalThis` still shadow
the global object. Focused tests cover primitive and structural object types,
call signatures, wrong assignments, missing members, invalid arguments,
non-generic type arguments, and lexical isolation.

This is a consumer contract, **not automatic cross-file type transfer**.
Program compilation still supplies presence-only names. Publishing real
bindings requires owner-aware declaration and semantic metadata, including
generic parameters, predicates, nominal identity, declaration merging, and
resolution independent of source order and cycles. The contract does not
authorize foreign local node IDs or incomplete metadata to be treated as local.

The unchanged audits were rerun against the frozen ReleaseFast binary and
exact installed baselines. Each compiler receives the same files and options;
valid cases must succeed silently, and invalid cases must match the expected
diagnostic-code multiset. Failures remain visible:

| Untimed correctness gate | TS 6.0.3 | Native TS 7.0.2 | Home |
|---|---:|---:|---:|
| Global declaration controls | 56/56 | 56/56 | 32/56 |
| Bound-global discovery controls | 56/56 | 56/56 | 44/56 |
| Imported-owner controls | 20/20 | 20/20 | 8/20 |
| Import/re-export graph admission | 2/2 | 2/2 | 0/2 |

These results are unchanged from the prior checkpoint. Both graph projects
still accept invalid imported-property uses in Home, so neither is readmitted
for timing. The full admission check passes 16/18 workloads, with only those
two failures. No new timings were collected and no speedup is claimed.

The full checker suite passes 4,264/4,264, conformance 1,417/1,417,
program 110/110, driver 187/187, and harness 38/38. Zig formatting checks pass.
Targeted Pickier has no errors
and one pre-existing README fragment warning.

Raw logs and the frozen binary are retained locally in
`bench/vs_tsgo/results/global-consumer.xZ8NXj`. The final binary SHA-256 is
`f401735aa016d571c2aa4def48f47f4ff435a100af98c3d37c5d61afab392f09`.
The installed compilers report `Version 6.0.3` and `Version 7.0.2`; the old
`7.0.0-dev.20260707.2` version is explicitly rejected by harness tests.
Native TS 7 is one baseline, not separate `tsc 7` and `tsgo` competitors.

```sh
./pantry/.bin/zig build test -Dfilter=ts_checker
./pantry/.bin/zig build test -Dfilter=ts_program
./pantry/.bin/zig build test -Dfilter=ts_driver
./pantry/.bin/zig build test -Dfilter=ts_conformance
./pantry/.bin/zig build home-tsc -Doptimize=ReleaseFast
python3 -m unittest discover -s bench/vs_tsgo -p 'test_*.py'
HOME_TSC="$PWD/zig-out/bin/home-tsc" python3 bench/vs_tsgo/audit_globals.py
HOME_TSC="$PWD/zig-out/bin/home-tsc" python3 bench/vs_tsgo/audit_bound_globals.py
HOME_TSC="$PWD/zig-out/bin/home-tsc" python3 bench/vs_tsgo/audit_owners.py
```

### Re-export discovery and declaration origins (untimed)

Issue [#520](https://github.com/home-lang/home/issues/520) isolates two
prerequisites for the typed graph work in
[#487](https://github.com/home-lang/home/issues/487): loading the complete
static dependency graph and recognizing the actual declaration behind an
export. These controls are not additional timed workloads.

The discovery audit has 28 cases: imports, named/star/namespace/type-only
re-exports, cycles, and diamonds, each tested with entry-only and all-files
roots. A negative case only appends a wrong local assignment in the leaf.
This detects an omitted source file without depending on imported type
inference. Pre-change Home passes 13/28; both pinned TypeScript baselines
pass 28/28. Commit
[`d440dbee6`](https://github.com/home-lang/home/commit/d440dbee6) loads static
re-export targets and rebuilds unique, current dependency edges. Program
tests also check repeated resolution, source replacement, and include
provenance.

The origin audit has 32 paired cases. It accepts two paths to the same
declaration while retaining genuine TS2308 conflicts and TS2305 missing-name
errors. It also checks default-import aliases, type-only function identity,
and runtime rejection through direct, named-barrel, and star-barrel aliases.
Local parameters that shadow an import remain usable. Both baselines pass
32/32; pre-change Home passes 4/32. Every compiler receives identical source
files, roots, and strict/noEmit/noLib/skipLibCheck options. Positive cases
must succeed silently; negative cases must match the diagnostic-code
multiset, not merely exit unsuccessfully.

The final ReleaseFast binary passes both new audits:

| Untimed correctness gate | TS 6.0.3 | Native TS 7.0.2 | Home before | Home after |
|---|---:|---:|---:|---:|
| Re-export discovery controls | 28/28 | 28/28 | 13/28 | 28/28 |
| Export-origin controls | 32/32 | 32/32 | 4/32 | 32/32 |
| Original imported graph admission | 2/2 | 2/2 | 0/2 | 0/2 |

The unchanged global, bound-global, and imported-owner audits remain
32/56, 44/56, and 8/20 for Home; both TypeScript baselines pass every case.
Full workload admission remains 16/18 for Home and 18/18 for each baseline,
with only the two original imported graph failures. No new timing run was
started, and no workload or negative control was removed to improve the result.

Commit [`2e1f795f9`](https://github.com/home-lang/home/commit/2e1f795f9)
implements the origin resolver and its checker/CLI integration. It uses a
visited worklist over source paths, names, lookup
mode, and value visibility. It follows aliases and cycles in the declaration's
own bound source, with a 96-module-chain regression test. Same-origin equality
requires actual overlapping declaration meanings; missing, incomplete, or
ambiguous resolutions cannot prove equality. The CLI retains immutable bound
source views across origin queries. Type-only paths retain symbol identity
for `typeof`, while recording whether the runtime restriction originated at
`import type` (TS1361) or `export type` (TS1362). Restriction positions retain
their source path, rather than becoming fabricated local node IDs.

This is **not automatic cross-file checked-type transfer**. The existing
legacy export-fact/name enumeration paths still have separate recursion
limits; the worklist test does not establish unlimited resolution throughout
the CLI. Generic parameters, predicates, nominal identity, and declaration
merging still require source-owned semantic linkage. The original graph
negative controls remain mandatory before either graph timing is eligible.

Raw evidence is retained in
`bench/vs_tsgo/results/reexport-discovery.rFhIvz`, including pre-change,
intermediate, failed, and superseded runs. `audit-before.log` is the discovery
baseline; `origins-before-final.log` is the final 32-case origin baseline.
The frozen pre-change binary is `global-consumer.xZ8NXj/home-final`, SHA-256
`f401735aa016d571c2aa4def48f47f4ff435a100af98c3d37c5d61afab392f09`.
The final binary is `reexport-discovery.rFhIvz/home-final`, SHA-256
`bff8e072e39c79f0d44e360b0b36ed5b984fd71183debb8e8736efa1aa6e6e3c`.
Its successful build log is `release-v4.log`; final audit logs use the
`-final.log` suffix. The original imported graph negatives are still accepted
without diagnostics by Home, so neither graph is readmitted for timing.
Runs marked TERM were stopped after source revisions and are not counted as
successful final verification. No new timings are reported here.

The final checker suite passes 4,266/4,266, conformance 1,417/1,417,
Program 117/117, driver 187/187, CLI 69/69, and the benchmark harness 41/41.
Zig formatting checks pass. Targeted Pickier reports no errors
and one pre-existing README fragment warning.

```sh
HOME_TSC="$PWD/zig-out/bin/home-tsc" python3 bench/vs_tsgo/audit_graph_discovery.py
HOME_TSC="$PWD/zig-out/bin/home-tsc" python3 bench/vs_tsgo/audit_export_origins.py
python3 -m unittest discover -s bench/vs_tsgo -p 'test_*.py'
```

### Imported nominal identity without synthetic properties (untimed)

Tracked in [#521](https://github.com/home-lang/home/issues/521), under
[#487](https://github.com/home-lang/home/issues/487) and
[#416](https://github.com/home-lang/home/issues/416). The installed baseline
binaries were verified again as `Version 6.0.3` and `Version 7.0.2`.
The harness rejects the superseded native dev build; native TS 7 and `tsgo`
are one competitor, not two separate compiler results.

Audit commits [`ab691caf7`](https://github.com/home-lang/home/commit/ab691caf7)
and [`e40a4d546`](https://github.com/home-lang/home/commit/e40a4d546) retain the
failing controls and enforce fairness. The implementation is
[`4ae69562e`](https://github.com/home-lang/home/commit/4ae69562e).

Home previously added a required `__home_class_origin_...` property to imported
classes with non-public members. That implementation detail leaked into missing
property diagnostics (TS2741). The checker now attaches source-qualified origin
metadata to the real non-public members, without creating a property. Recursive
identity and assignability checks compare that metadata, including nested
objects, arrays, signatures, and intersections. Generic substitution preserves
it, and type transfer relocates its string ID independently of HIR node IDs.
The legacy source-path/module/class key is length-prefixed to prevent delimiter
collisions. This does not replace the legacy class projection with complete
source-owned checked declarations.

The new audit has 52 controls: 13 families, each with positive and appended-only
negative variants, checked with the app before and after declaration roots.
All compilers receive identical files, roots, and strict/noEmit/noLib/skipLibCheck
options. Successful controls must be silent; rejection controls must match the
exact diagnostic-code multiset. No failure is skipped or relabeled as a pass.

| Untimed correctness gate | TS 6.0.3 | Native TS 7.0.2 | Home before | Home after |
|---|---:|---:|---:|---:|
| Imported nominal-identity controls | 52/52 | 52/52 | 30/52 | 36/52 |
| Existing imported-owner controls | 20/20 | 20/20 | 8/20 | 10/20 |
| Re-export discovery controls | 28/28 | 28/28 | 28/28 | 28/28 |
| Export-origin controls | 32/32 | 32/32 | 32/32 | 32/32 |
| Global declaration controls | 56/56 | 56/56 | 32/56 | 32/56 |
| Bound-global controls | 56/56 | 56/56 | 44/56 | 44/56 |
| Original imported graph admission | 2/2 | 2/2 | 0/2 | 0/2 |

The six newly passing nominal controls cover direct private/protected identity
and a public structural object assigned to a private class. The existing nested
object, array, function, and public-structural controls remain passing. Remaining
failures cover static-private imports (2 controls), generic arguments (2),
re-exported class aliases (2), private `keyof` (2), and private/protected inheritance
(8). Static member metadata is preserved when supplied, but Program's class
projection still omits the static-private declarations exercised here. Positive
inheritance failures are counted, not hidden by the corresponding negative case.

Full workload admission remains 16/18 for Home and 18/18 for each baseline.
Both original imported graphs still accept invalid uses and remain ineligible
for timing. No new performance measurement or speed claim is made. The new
member metadata has not yet been evaluated in a fresh timing/memory comparison.

The frozen pre-change binary is `reexport-discovery.rFhIvz/home-final`, SHA-256
`bff8e072e39c79f0d44e360b0b36ed5b984fd71183debb8e8736efa1aa6e6e3c`.
Evidence for this checkpoint is in `bench/vs_tsgo/results/nominal-origins.doZaNi`:
`audit-before-expanded.log` and `audit-final.log` use all 52 controls;
`audit-before.log` retains the initial 48-case run before static-private controls
were added. The final binary is `home-final`, SHA-256
`3cc741571c00fa3682fb3b4c4931273b0f57a910f12a61c022112ed780f7a245`;
its build log is `release.log`. Audit source SHA-256:
`98dcd584f5dc651d19c80fe28cd538e34b0bb3de176af87be067e64dbd400ea1`.

The checker suite passes 4,270/4,270, conformance 1,417/1,417, driver 187/187,
Program 117/117, CLI 69/69, focused origin tests 5/5 (including the test root),
and the benchmark harness 44/44. Fresh callable-identity and callable-union
audits remain 56/56 and 256/256 for all three compilers. Zig formatting checks
pass; targeted Pickier reports zero errors and the pre-existing README
fragment warning.

```sh
HOME_TSC="$PWD/zig-out/bin/home-tsc" python3 bench/vs_tsgo/audit_nominal_origins.py
HOME_TSC="$PWD/zig-out/bin/home-tsc" python3 bench/vs_tsgo/audit_owners.py
python3 -m unittest discover -s bench/vs_tsgo -p 'test_*.py'
```

### Bound class declarations and export aliases (untimed)

Tracked in [#522](https://github.com/home-lang/home/issues/522), under
[#521](https://github.com/home-lang/home/issues/521),
[#487](https://github.com/home-lang/home/issues/487), and
[#416](https://github.com/home-lang/home/issues/416). All runs below verify the
installed compilers as TS **6.0.3** and native TS **7.0.2**. The old native
`7.0.0-dev.20260707.2` build is rejected, not treated as another competitor.

Audit commits [`79f43d107`](https://github.com/home-lang/home/commit/79f43d107)
and [`cce32867b`](https://github.com/home-lang/home/commit/cce32867b) define 52
controls across 13 families. Each has a valid program and an appended-only
negative variant, with identical inputs/options for all compilers and both app
root orders. Valid controls must be silent; invalid controls must match the
exact diagnostic-code multiset. Type-only aliases must preserve class identity
without permitting runtime construction.

Implementation commits
[`226da3863`](https://github.com/home-lang/home/commit/226da3863) and
[`b45b038e0`](https://github.com/home-lang/home/commit/b45b038e0) replace the
source-text class scanner with already-bound declaration traversal. Export
binding names/paths are separate from declaration names/paths/positions. Alias
queries and a visited star-export candidate worklist retain the actual owner
through renaming, defaults, cycles, and explicit shadows. Class fields use HIR
static/visibility flags; comments are not members and quoted keyword names are
ordinary public properties. Namespace declaration context is retained in HIR,
and `keyof` excludes non-public class members.

| Untimed correctness gate | TS 6.0.3 | Native TS 7.0.2 | Home before | Home after |
|---|---:|---:|---:|---:|
| Bound-class export controls | 52/52 | 52/52 | 22/52 | 48/52 |
| Imported nominal-identity controls | 52/52 | 52/52 | 36/52 | 40/52 |
| Existing imported-owner controls | 20/20 | 20/20 | 10/20 | 10/20 |
| Re-export discovery controls | 28/28 | 28/28 | 28/28 | 28/28 |
| Export-origin controls | 32/32 | 32/32 | 32/32 | 32/32 |
| Global declaration controls | 56/56 | 56/56 | 32/56 | 32/56 |
| Original imported graph admission | 2/2 | 2/2 | 0/2 | 0/2 |

The four remaining class-export failures are negative static-member and
merged-namespace visibility uses, each in both root orders. The collected facts
are retained, but the consumer still falls back to `any` for these imported
values. The nominal audit still fails private-static identity (2 controls),
generic arguments (2), and private/protected inheritance (8). Alias identity
and private `keyof` now pass. Full workload admission remains 16/18 for Home
and 18/18 for each baseline; the two original graphs remain ineligible for timing.

This is not complete cross-file checked-type transfer. Complex member types,
method/constructor signatures, generic constraints, heritage, ambient class
export aliases, and computed names still need source-owned semantic linkage.
The existing relative module namespace-augmentation text collector remains a
separate legacy boundary. No new timings or speed/memory claims are made.

Raw evidence is in `bench/vs_tsgo/results/bound-classes.8s4Xq1`.
`bindings-before-type-only.log` and `bindings-v1.log` contain the final 52-case
before/after audit; earlier 40/44-case runs are retained but are not mixed into
the table. The frozen baseline is `nominal-origins.doZaNi/home-final`, SHA-256
`3cc741571c00fa3682fb3b4c4931273b0f57a910f12a61c022112ed780f7a245`.
The final ReleaseFast binary is `bound-classes.8s4Xq1/home-v1`, SHA-256
`7f71d18f3a1648032b346183267382573f02475b824f5db8c30e0cc463568bd2`;
its successful build log is `release-final.log`. Other audit logs use `-v1.log`.
Audit source SHA-256:
`97f9bdc75c50957c33e4139f05b66eb21750fad2fa51741a990b6525449ea6ea`.
Debug, failed, interrupted, and superseded runs remain separately labeled and
are not counted as final release verification.

The checker suite passes 4,271/4,271, conformance 1,417/1,417, Program 119/119,
driver 187/187, CLI 69/69, parser 897/897, HIR 12/12, and benchmark harness
47/47. Fresh bound-global controls remain 44/56 for Home and 56/56 for each
baseline. Callable-identity and callable-union controls remain 56/56 and 256/256
for all three compilers. Zig formatting checks pass.

```sh
HOME_TSC="$PWD/zig-out/bin/home-tsc" python3 bench/vs_tsgo/audit_class_bindings.py
HOME_TSC="$PWD/zig-out/bin/home-tsc" python3 bench/vs_tsgo/audit_nominal_origins.py
python3 -m unittest discover -s bench/vs_tsgo -p 'test_*.py'
```

### Imported static values and module namespace consumers (untimed)

Tracked in [#523](https://github.com/home-lang/home/issues/523), following
[#522](https://github.com/home-lang/home/issues/522), under
[#521](https://github.com/home-lang/home/issues/521),
[#487](https://github.com/home-lang/home/issues/487), and
[#416](https://github.com/home-lang/home/issues/416). The harness verifies
TS **6.0.3** and native TS **7.0.2** before every run. Native TS 7 and `tsgo`
remain one competitor; the superseded dev build is rejected.

The main implementation is
[`cdcb60b41`](https://github.com/home-lang/home/commit/cdcb60b41).

Audit commits [`232961504`](https://github.com/home-lang/home/commit/232961504),
[`170613d01`](https://github.com/home-lang/home/commit/170613d01), and
[`89698128c`](https://github.com/home-lang/home/commit/89698128c) define the final
84 controls: 21 families, each with positive and appended-only negative variants
in both app root orders. All compilers receive identical files, roots, and
strict/noEmit/noLib/skipLibCheck options. Positive controls must be silent;
negative controls must match the exact diagnostic-code multiset.

The audit covers named/default imports, aliases, module namespaces, captured
namespaces and constructors, destructuring, element access, mixed exports,
lexical shadowing, unqualified-name isolation, static-private identity,
merged-namespace visibility, type-only restrictions, constructor prototypes,
cyclic namespace aliases, and a 41-link star-export chain. Neither cycles nor
long chains are omitted when they expose a failure.

Named imports now use known class/value facts before presence-only `any`
fallbacks. Module namespace values contain the complete known runtime export
inventory, including non-class exports and default exports. Bound export queries
separate value availability from type-only bindings and identify namespace alias
owners. Namespace class members do not register bare class names in the importing
scope. Constructor values retain their instance type through `prototype`.

Namespace identities are reserved and completed before publication, preserving
cycles through ordinary object consumption. A cycle exposed a non-terminating
free-type-parameter walk; it now uses a visited worklist with reusable scratch
storage. Export-name enumeration also uses a visited worklist rather than a
fixed depth limit ([`bca0fad95`](https://github.com/home-lang/home/commit/bca0fad95)).
Recursive object completion is separately tested
([`c2331bab6`](https://github.com/home-lang/home/commit/c2331bab6)).

| Untimed correctness gate | TS 6.0.3 | Native TS 7.0.2 | Home before | Home after |
|---|---:|---:|---:|---:|
| Imported static-value controls | 84/84 | 84/84 | 52/84 | 84/84 |
| Bound-class export controls | 52/52 | 52/52 | 48/52 | 52/52 |
| Imported nominal-identity controls | 52/52 | 52/52 | 40/52 | 42/52 |
| Existing imported-owner controls | 20/20 | 20/20 | 10/20 | 10/20 |
| Re-export discovery controls | 28/28 | 28/28 | 28/28 | 28/28 |
| Export-origin controls | 32/32 | 32/32 | 32/32 | 32/32 |
| Global declaration controls | 56/56 | 56/56 | 32/56 | 32/56 |
| Bound-global controls | 56/56 | 56/56 | 44/56 | 44/56 |
| Original imported graph admission | 2/2 | 2/2 | 0/2 | 0/2 |

The nominal audit still fails generic arguments (2 controls) and
private/protected inheritance (8); both positive and negative inheritance
failures are retained. Full workload admission remains **16/18 for Home** and
**18/18 for each baseline**. Both original graph negative controls are still
accepted without diagnostics by Home, so neither graph is eligible for timing.
No new speed or memory claim is made.

This remains a projection of supported source-owned facts, not automatic
cross-file checked-type transfer. Complex members, method/constructor signatures,
generic constraints and heritage still need semantic linkage. Unsupported
exported value types retain their existing limits; a known export inventory is
not proof that every member has a complete checked type. Unavailable namespace
shapes, including JavaScript files outside the bound query's coverage, are kept
unknown and cached as such, not published as incomplete empty objects.

Evidence is retained in `bench/vs_tsgo/results/static-values.csYPot`.
`audit-before-final.log` and `static_values-final.log` use all 84 controls.
Earlier 68/76-case and Debug runs are retained separately; they are not mixed
into the table. The initial cyclic test was stopped after non-termination;
`focused-sample.txt` records its recursive traversal. The passing replacement
is recorded in `checker-focused-v2.log`.

The frozen pre-change binary is `bound-classes.8s4Xq1/home-v1`, SHA-256
`7f71d18f3a1648032b346183267382573f02475b824f5db8c30e0cc463568bd2`.
The final ReleaseFast binary is `static-values.csYPot/home-final`, SHA-256
`9fb67479dbd422678c617facf686d4a09317658e7c4a871084db906bf12572c1`;
its build log is `release.log`. Other final audit logs use `-final.log`.
Audit source SHA-256:
`301fe1b661ab781e6cde0c4ee3eac8074d14d653361d682329c5a7a9239812e5`.

The checker suite passes 4,274/4,274, conformance 1,417/1,417, Program 120/120,
driver 187/187, CLI 69/69, and the benchmark harness 50/50. Fresh callable-identity and callable-union audits
remain 56/56 and 256/256 for all three compilers. Zig formatting checks pass;
targeted Pickier reports no errors and one pre-existing README fragment warning.

```sh
HOME_TSC="$PWD/zig-out/bin/home-tsc" python3 bench/vs_tsgo/audit_static_values.py
HOME_TSC="$PWD/zig-out/bin/home-tsc" python3 bench/vs_tsgo/audit_class_bindings.py
HOME_TSC="$PWD/zig-out/bin/home-tsc" python3 bench/vs_tsgo/audit_nominal_origins.py
python3 -m unittest discover -s bench/vs_tsgo -p 'test_*.py'
```

### Imported generic-class baseline and source-owned metadata (untimed)

Tracked in [#524](https://github.com/home-lang/home/issues/524), under
[#521](https://github.com/home-lang/home/issues/521),
[#487](https://github.com/home-lang/home/issues/487), and
[#416](https://github.com/home-lang/home/issues/416).
Audit commit [`d7f80bd89`](https://github.com/home-lang/home/commit/d7f80bd89)
adds 100 controls: 25 families, each with a positive and appended-only negative
variant in both app root orders. Files, roots and compiler options are identical
across compilers. Positive controls must be silent; negatives must match the
exact diagnostic-code multiset. No timing is collected.

The suite covers named/default/namespace imports, renamed and re-exported
bindings, nested arrays/objects/tuples/unions/functions, method calls, same-owner
and different-owner compatibility, importer-local name isolation, defaults,
dependent defaults and constraints, required/excess argument counts, owner-local
and imported aliases, and recursive aliases. Unsupported cases stay in the audit.

| Untimed correctness gate | TS 6.0.3 | Native TS 7.0.2 | Home baseline |
|---|---:|---:|---:|
| Imported generic-class controls | 100/100 | 100/100 | 50/100 |

The frozen Home baseline is `static-values.csYPot/home-final`, SHA-256
`9fb67479dbd422678c617facf686d4a09317658e7c4a871084db906bf12572c1`.
The 300 compiler/case checks produce 50 failures, all Home failures.
Evidence is `bench/vs_tsgo/results/generic-classes.9vD3xi/audit-before.log`;
audit source SHA-256 is
`19a07655d38308109c36714aaa6d9db10638f7758feac67c2ca3404118f8a2e7`.

The metadata foundation
([`af11e4ebf`](https://github.com/home-lang/home/commit/af11e4ebf)) retains parameter identities, defaults, constraints,
variance, nested annotations, declaration origins and recursive references from
the defining source. Imported aliases are resolved in that owner's bound scope;
unsupported forms remain explicit rather than becoming `any` or incomplete
objects. Class-field optional/readonly modifiers are now retained in HIR
([`f0d84813d`](https://github.com/home-lang/home/commit/f0d84813d)), including
comments between a field name, `?` and `:`. This is preparation for the imported
consumer, not a claim that generic instantiation is fixed. The collector is
tested independently and is not yet invoked during production class collection;
unused schemas are not allocated on the compilation path.

The foundation passes 129/129 Program tests (including nine schema controls),
898/898 parser tests, 187/187 driver tests, 69/69 CLI tests and 53/53 benchmark
harness tests. These are targeted foundation checks, not a new full-checker or
conformance checkpoint. Zig formatting passes; targeted Pickier reports no
errors and one pre-existing README link-fragment warning.

An experimental Debug run with schema collection enabled still passes 50/100
generic controls (`audit-foundation-debug.log`); it is not the frozen baseline
or a timing result. The same Debug binary passes all 84 static-value controls
(`static-foundation-debug.log`), as do both pinned baselines. Collection remains disabled in the committed production
path until a checked consumer can use it.

The compiler pins and installed binaries are TS **6.0.3** and native TS **7.0.2**.
The harness rejects `7.0.0-dev.20260707.2` and stable-version suffix mismatches
before collecting results. Native TS 7 and `tsgo` are the same competitor.
The original imported graph admission remains **0/2** for Home; the timing
snapshot above is unchanged and no new performance claim is made.

```sh
HOME_TSC="$PWD/zig-out/bin/home-tsc" python3 bench/vs_tsgo/audit_generic_classes.py
python3 -m unittest discover -s bench/vs_tsgo -p 'test_*.py'
```

### Imported generic-class instantiation (untimed)

Tracked in [#524](https://github.com/home-lang/home/issues/524), under
[#521](https://github.com/home-lang/home/issues/521),
[#487](https://github.com/home-lang/home/issues/487), and
[#416](https://github.com/home-lang/home/issues/416).
The source-owned schema collector is now enabled for generic classes. Imported
type annotations instantiate the defining declaration with the consumer's
actual arguments; defaults, dependent constraints and member expressions resolve
in the declaration's scope. Repeated instances are cached by source declaration
identity and effective arguments. Recursive object aliases with unchanged
arguments retain their object identity, optional members and concrete types.
Non-public members retain declaration origins without synthetic brand fields.
Implementation:
[`0a1e5afe8`](https://github.com/home-lang/home/commit/0a1e5afe8) and
[`33ddbef63`](https://github.com/home-lang/home/commit/33ddbef63).

The audit grew from the historical 100 cases above to **120**: 30 families,
each with a positive and appended-only negative control in both root orders.
The additional families cover growing recursive aliases, unused (phantom) type
parameters, explicit method receivers, resolved `unknown` constraints and weak
optional-object constraints. They were added in
[`96d0da00c`](https://github.com/home-lang/home/commit/96d0da00c),
[`71023f916`](https://github.com/home-lang/home/commit/71023f916),
[`65ea1e895`](https://github.com/home-lang/home/commit/65ea1e895), and
[`bb6f55301`](https://github.com/home-lang/home/commit/bb6f55301).
All compilers receive identical files and options. Positives must be silent;
negatives must match the exact diagnostic-code multiset. No cases are excluded
and no timing is collected.

| Untimed correctness gate | TS 6.0.3 | Native TS 7.0.2 | Home before | Home after |
|---|---:|---:|---:|---:|
| Imported generic-class controls | 120/120 | 120/120 | 62/120 | 118/120 |
| Imported nominal-identity controls | 52/52 | 52/52 | 42/52 | 44/52 |
| Imported static-value controls | 84/84 | 84/84 | 84/84 | 84/84 |
| Bound-class export controls | 52/52 | 52/52 | 52/52 | 52/52 |
| Original workload admission | 18/18 | 18/18 | 16/18 | 16/18 |
| Imported graph admission (subset above) | 2/2 | 2/2 | 0/2 | 0/2 |

The full 120-case baseline was rerun against the same frozen pre-consumer Home
binary used above; **62/120 is not a reinterpretation of the historical 50/100**.
The new release passes every original 100-case control and 18 of the 20 added
controls. Same-owner phantom parameters remain structurally compatible;
different-owner private members remain incompatible. A detached method with an
explicit `this` requirement is rejected. Resolved `unknown` arguments no longer
bypass constraints. Weak-constraint checking uses apparent object types,
including the declared BigInt wrapper when available; it does not invent
required properties or make primitive `bigint` satisfy the `object` constraint.

Both remaining generic failures are the negative growing-recursion controls:
`Link<X> = { item: X; next?: Link<X[]> }` needs lazy parameterized expansion.
An eager finite graph cannot represent every instantiation. This form remains
unsupported and visible in the audit; there is no fixed-depth truncation or
new `any` substitution to manufacture a passing result. The nominal suite's
eight remaining failures concern private/protected inheritance. Generic
constructors, heritage, generic methods, unsupported annotation forms and full
cross-file checked-type transfer are not established by this checkpoint.
Variance metadata is retained, not a claim of complete variance enforcement.
Issue #524 remains open. Both imported graph timing claims remain ineligible.

Evidence is under `bench/vs_tsgo/results/generic-classes.9vD3xi/`:

- `audit-before-120.log`: 360 compiler/case checks, 58 failures, all Home.
- `audit-final-120.log`: 360 checks, two failures, both Home growing-recursion negatives.
- `nominal_origins-final.log`, `static_values-final.log` and `class_bindings-final.log`: adjacent release audits.
- `admission-final.log`: every original workload checked, including required rejection controls.
- `release-final-v2.log`: successful ReleaseFast build; `home-final`: frozen release binary.

The baseline SHA-256 is
`9fb67479dbd422678c617facf686d4a09317658e7c4a871084db906bf12572c1`.
The new release SHA-256 is
`5a4127f13c8901a1899686b09ca7d62d9bf338f41ff8ea5b43c08d179d35bbb7`.
The 120-case audit source SHA-256 is
`4fa967df7188d6f1b5928e8a8cb1ccfeb5bd25b9b56fed93e0f0f69f10a2a377`.
Version preflight verifies the executable outputs, not just the manifest:
TS **6.0.3** and native TS **7.0.2**. TS 7 and `tsgo` are one competitor;
the old `7.0.0-dev.20260707.2` binary is rejected.

Full verification passes **4,279/4,279 checker**, **1,417/1,417 conformance**,
**130/130 Program**, **187/187 driver**, **69/69 CLI** and **53/53 harness**
tests. Logs are `checker-final.log`, `conformance-final.log`,
`program-final.log`, `driver-final.log`, `cli-final.log` and
`harness-final-120.log`. Fresh release audits also retain callable identity
56/56, callable unions 256/256, graph discovery 28/28 and export origins 32/32
for all three compilers. Home's imported-owner 10/20, global 32/56 and
bound-global 44/56 results remain unchanged; both pinned competitors pass all
of those controls. Logs use the audit's underscore-separated name plus
`-final.log`. Zig formatting checks pass. Targeted Pickier reports zero errors
and one pre-existing README fragment warning (`lint-final.log`).
These are correctness results; the existing timing snapshot is unchanged.

```sh
HOME_TSC="$PWD/bench/vs_tsgo/results/generic-classes.9vD3xi/home-final" python3 bench/vs_tsgo/audit_generic_classes.py
HOME_TSC="$PWD/bench/vs_tsgo/results/generic-classes.9vD3xi/home-final" python3 bench/vs_tsgo/audit_nominal_origins.py
python3 -m unittest discover -s bench/vs_tsgo -p 'test_*.py'
```

### Recursive generic-consumer baseline (untimed)

Follow-up to [#524](https://github.com/home-lang/home/issues/524), with parents
[#521](https://github.com/home-lang/home/issues/521),
[#487](https://github.com/home-lang/home/issues/487), and tracker
[#416](https://github.com/home-lang/home/issues/416).
Audit commits [`6576ff855`](https://github.com/home-lang/home/commit/6576ff855)
and [`42452f823`](https://github.com/home-lang/home/commit/42452f823)
add **216** controls: 16 recursive consumer families and two nonrecursive
calibration families, each tested with a local declaration,
a named import and a namespace import, with paired positive/appended-only
negative uses in both app root orders. All three compilers receive identical
files and options. Positive controls must be silent; negative controls must
produce exactly one TS2322. No cases are excluded and no timing is collected.

| Recursive generic placement | TS 6.0.3 | Native TS 7.0.2 | Home baseline |
|---|---:|---:|---:|
| Local declarations | 72/72 | 72/72 | 16/72 |
| Named imports | 72/72 | 72/72 | 40/72 |
| Namespace imports | 72/72 | 72/72 | 40/72 |
| Total | 216/216 | 216/216 | 96/216 |

The families cover fixed recursion, growing array arguments at depths 1, 4 and
12, growing object arguments, mutually recursive aliases, parameter permutation,
recursive method returns and array members, optional unions, indexed access,
`keyof`, generic inference, destructuring, finite structural targets and
structurally matching distinct recursive origins. Depth variants exercise the
same semantics at different use depths; they do not define an implementation
cutoff. The local controls demonstrate that the remaining problem is not only
cross-file name resolution. The direct-parameter and nonrecursive-member
calibration families pass all 24 controls for all three compilers, distinguishing
the recursive failures from ordinary generic value/member access. All failures
remain visible.

The baseline is the previously verified ReleaseFast binary
`bench/vs_tsgo/results/generic-classes.9vD3xi/home-final`, from implementation
[`33ddbef63`](https://github.com/home-lang/home/commit/33ddbef63), SHA-256
`5a4127f13c8901a1899686b09ca7d62d9bf338f41ff8ea5b43c08d179d35bbb7`.
Evidence: `bench/vs_tsgo/results/recursive-generics.mlQve8/audit-before-216.log`
(648 compiler/case checks, 120 failures, all Home). The initial 192-case run
is separately retained in `audit-before.log` (Home 72/192); the 24 calibration
controls add passes without removing any failures. Final audit source SHA-256:
`65550d718a6369f850474f6699a3d0ec3733da302373fd99ffcb56e31124ff04`.
Executable preflight verifies TS **6.0.3** and native TS **7.0.2**; TS 7 and
`tsgo` remain one competitor.

This **96/216** baseline is not a regression from, or a replacement for, the
distinct **118/120** imported generic-class audit above. Both suites are retained.
Original workload admission remains 16/18, imported graph admission remains
0/2, and the timing snapshot is unchanged. No recursive-generic speed claim is
eligible from this correctness baseline.

The representation foundation
([`c6c6c6652`](https://github.com/home-lang/home/commit/c6c6c6652)) introduces pool-owned generic definitions: a
distinct declaration identity, its declaration-scoped parameter TypeIds, and a
symbolic body. Recursive instantiation references can point back to that
identity without unfolding the body. Construction is two-phase and unpublished
until complete; allocation failure cannot publish a partial parameter list.
Type-pool transfer relocates definitions, parameters, recursive edges and source
provenance together, and rejects incomplete definitions. Separate declarations
remain distinct even when their parameter names or body shapes match.

This is prerequisite representation work. Production lowering still uses the
existing consumer from the preceding checkpoint; shared lazy evaluation and
member/relation/indexed-access consumers have not been connected to the new
definition representation. The audit failures are not claimed fixed, and no
fixed-depth expansion or new permissive fallback is introduced.

Verification passes **4,282/4,282 checker**, **1,417/1,417 conformance**,
**130/130 Program**, **187/187 driver**, **69/69 CLI** and **56/56 harness**
tests. The focused definition tests pass 4/4 and transfer tests 10/10, including
allocation-failure rollback and recursive graph preservation after releasing
the source pool. Evidence is in `recursive-generics.mlQve8/` under
`checker-definitions.log`, `conformance-definitions.log`,
`program-definitions.log`, `driver-definitions.log`, `cli-definitions.log`,
`harness.log`, `definitions-focused.log` and `transfer-focused.log`.
Zig formatting passes; targeted Pickier reports zero errors and the existing
README fragment warning (`lint.log`).

The foundation's ReleaseFast binary is frozen as
`recursive-generics.mlQve8/home-definitions`, SHA-256
`95ababead014327b0e3bc97b7909eae88aeabaf5b2542612ba79fb74ffc6e173`
(`release-definitions.log`). Its fresh 216-case audit retains **96/216** for
Home and **216/216** for both competitors (`audit-definitions-216.log`): all
648 compiler/case outcomes match the pre-foundation baseline. The separate
imported-class suite retains **118/120** for Home and **120/120** for both
competitors (`generic-classes-definitions.log`). Original workload admission
is freshly verified at **16/18** for Home and **18/18** for both competitors
(`admission-definitions.log`); the same two graph rejection gates still fail.

```sh
HOME_TSC="$PWD/bench/vs_tsgo/results/generic-classes.9vD3xi/home-final" python3 bench/vs_tsgo/audit_recursive_generics.py
python3 -m unittest discover -s bench/vs_tsgo -p 'test_*.py'
```

### Lazy source-owned generic consumers

Work for [#524](https://github.com/home-lang/home/issues/524), parents
[#521](https://github.com/home-lang/home/issues/521) and
[#487](https://github.com/home-lang/home/issues/487), tracker
[#416](https://github.com/home-lang/home/issues/416).
[`220a62d57`](https://github.com/home-lang/home/commit/220a62d57) expands the
preceding audit from 216 to **288** controls by adding private-to-module local
declarations. This fourth placement uses the same 18 families, two root orders,
and positive/appended-only-negative pairs. All prior controls remain. Every
compiler receives identical files/options; positive programs must be silent and
negative programs must produce exactly one TS2322. These are correctness
controls, not a recursive-generic throughput benchmark.

The frozen foundation ReleaseFast binary (`c6c6c6652`, SHA-256
`95ababead014327b0e3bc97b7909eae88aeabaf5b2542612ba79fb74ffc6e173`) passes
**112/288**: 16/72 for each local placement and 40/72 for each import placement.
Both TS 6.0.3 and native TS 7.0.2 pass **288/288**. Evidence is
`bench/vs_tsgo/results/lazy-generics.2H3YDX/recursive-before-288.log`.
The added placement exposes 56 additional Home failures; it does not remove or
reclassify any failure from the 216-case baseline. Audit source SHA-256:
`361a6c796efca23e5ef11a76efc119d8d4c7f0b07ecdfbf51acec46d3253ca15`.

Implementation [`3b7f0ea93`](https://github.com/home-lang/home/commit/3b7f0ea93)
builds a declaration-owned symbolic body once, retaining
fresh formal parameter identities. Instantiation substitutes the requested
arguments but leaves nested references symbolic. Member access, indexed access,
expression consumers and structural relations request the same cached expansion;
growing recursion no longer requires eager unfolding. Local generic class
metadata follows the same path without becoming an exported import binding.
Definition identity is based on source owner and declaration position, not a
display name. Transparent aliases preserve the identity of the type they reuse.
No fixed-depth unrolling or new permissive `any` recovery is introduced.

The dedicated growing-recursion test follows 64 requested surfaces and verifies
their concrete arguments, cache reuse and a single generic definition. This test
depth is not an implementation limit. Other focused controls cover owner
separation, dependent defaults, constraints, local export visibility and display
name collisions. Unsupported schema forms remain explicit; this checkpoint does
not establish general imported-function/heritage/mapped-type support or repair
the original graph admission gates by itself.

The final ReleaseFast candidate passes the complete recursive audit:

| Placement or separate audit | TS 6.0.3 | Native TS 7.0.2 | Home before | Home after |
|---|---:|---:|---:|---:|
| Local exported declarations | 72/72 | 72/72 | 16/72 | 72/72 |
| Local non-exported declarations | 72/72 | 72/72 | 16/72 | 72/72 |
| Named imports | 72/72 | 72/72 | 40/72 | 72/72 |
| Namespace imports | 72/72 | 72/72 | 40/72 | 72/72 |
| Recursive total | 288/288 | 288/288 | 112/288 | 288/288 |
| Imported generic classes (separate suite) | 120/120 | 120/120 | 118/120 | 120/120 |
| Nominal identity (separate suite) | 52/52 | 52/52 | 44/52 | 44/52 |
| Original workload admission | 18/18 | 18/18 | 16/18 | 16/18 |

Evidence is under `bench/vs_tsgo/results/lazy-generics.2H3YDX/`, using the
immutable `release-v5/bin/home-tsc` binary, SHA-256
`267691e33056e2c4a8b23b757bc3eed19c8b3d90fa9407120b8985834a844ccd`.
Logs: `recursive-release-v5.log`, `audit_generic_classes-release-v5.log`,
`audit_nominal_origins-release-v5.log`, and `admission-release-v5.log`.
The 288-case audit makes 864 compiler/case checks with zero failures; the
imported-class audit makes 360 checks with zero failures. Eight Home nominal
inheritance failures and both original graph rejection failures remain visible.

The separate throughput workload
([`de72563b3`](https://github.com/home-lang/home/commit/de72563b3)) consumes 256
distinct payload interfaces through an imported `Box<T>` and four requested
levels of `Link<T[]>`. Every family checks both its complete array container
and its numeric leaf. Before timing, a temporary copy appends nine invalid uses
at the first, middle and last payload: wrong leaf type, wrong nested container,
and missing property. Admission requires exactly six TS2322 and three TS2339
diagnostics; crashes, silent acceptance and incomplete rejection fail the gate.
The original positive corpus is never mutated or replaced for the negative run.

The frozen foundation accepts these invalid uses (`recursive-workload-before.log`)
and is therefore **ineligible** for a before/after timing comparison on this new
workload. All three current compilers pass its positive and negative checks
(`admission-release-v5.log`). The expanded manifest admits 17/19 workloads for
Home and 19/19 for each competitor, while the original 18-workload set remains
16/18 for Home. Adding a passing workload does not repair either failing graph.

Exact committed-source verification passes **4,285/4,285 checker**,
**1,417/1,417 conformance**, **131/131 Program**, **187/187 driver**,
**69/69 CLI**, **9/9 source-owned focus**, and **60/60 benchmark harness** tests.
Logs are `checker-v5.log`, `conformance-v5.log`, `ts_program-v5.log`,
`ts_driver-v5.log`, `ts_cli-v5.log`, `focused-v5.log` and
`harness-recursive-final.log` in the evidence directory above. Earlier
interrupted verification attempts are not counted as passes. Zig formatting
and targeted Pickier checks pass, apart from the pre-existing README fragment
warning (`lint-docs.log`).

Reporting fix [`74d11634e`](https://github.com/home-lang/home/commit/74d11634e)
subsequently raises the harness total to **66/66**
(`harness-report-integrity.log`). Interleaved reports now require the exact
metadata-declared workload/round file set, the rotating compiler order, and one
successful finite positive timing per compiler per round. An unfinished run
cannot print partial averages under a completed-run heading. Missing/extra
rounds, malformed JSON, duplicate compilers and failed samples are rejected,
not filtered. The historical complete report still validates
(`historical-report-check.log`).

Fresh release audits also retain callable identity 56/56, callable unions
256/256, static values 84/84, bound-class exports 52/52, graph discovery 28/28,
and export origins 32/32 for all three compilers. Home's imported-owner 10/20,
global 32/56 and bound-global 44/56 results remain unchanged; each competitor
passes every control in those suites. Logs use `audit_<name>-release-v5.log`.

```sh
HOME_TSC="$PWD/bench/vs_tsgo/results/lazy-generics.2H3YDX/release-v5/bin/home-tsc" python3 bench/vs_tsgo/audit_recursive_generics.py
HOME_TSC="$PWD/bench/vs_tsgo/results/lazy-generics.2H3YDX/release-v5/bin/home-tsc" python3 bench/vs_tsgo/run.py cold --runs 30 --warmup 3 --workload recursive_generics
python3 -m unittest discover -s bench/vs_tsgo -p 'test_*.py'
```

### Lazy generic checkpoint performance

The full current checkpoint uses compiler `3b7f0ea93` and the frozen release
binary identified above. Raw result directory:
`bench/vs_tsgo/results/20260828T221149Z`; execution log:
`lazy-generics.2H3YDX/timing-release-v5.log`. Apple M3 Pro, arm64, macOS 27.0,
Zig `0.17.0-dev.1441+d5181a9c9`, TS **6.0.3**, native TS **7.0.2**.
TS 7 and tsgo are one competitor. All 17 selected workloads pass current
schema-3 admission before timing. The two failing original graphs are explicitly
excluded, not silently omitted from an all-workload success claim.

Each compiler receives the same generated project, minimal library, strict
checking, `noLib` and `noEmit` options. Three warmups precede 30 fresh-process
timings per compiler/workload, with compiler order rotating in every round.
The complete report validates **510 round files / 1,530 successful samples**.
No measurements are discarded, replaced or trimmed. Means and sample standard
deviations are shown below; ratios compare Home with the faster competitor.

These are **shared-workstation measurements**, not an isolated-host experiment.
This task's builds, tests and audits completed before measurement, but unrelated
CPU and filesystem activity continued. Observed load averages were
13.34 / 37.27 / 42.65 at the start and 9.88 / 21.73 / 34.34 after the run.
Several rows have substantial variance. Interleaving balances order but does
not remove contention or prove statistical significance; the narrow large-case
predicate margin is especially uncertain. Earlier historical timings are retained
elsewhere in this document, not treated as a controlled before/after experiment.

| Workload | TS 6.0.3 | Native TS 7.0.2 | Home | Home vs faster competitor |
|---|---:|---:|---:|---:|
| Startup | 63.1 ± 1.3 ms | 38.2 ± 1.0 ms | 3.4 ± 0.2 ms | 11.30× faster |
| 256 files | 206.7 ± 2.9 ms | 54.2 ± 2.5 ms | 31.5 ± 0.8 ms | 1.72× faster |
| Deep types | 146.1 ± 58.4 ms | 58.8 ± 19.1 ms | 30.1 ± 11.1 ms | 1.95× faster |
| 128-module import graph | — | — | — | Ineligible: rejection gate fails |
| 64-leaf barrel graph | — | — | — | Ineligible: rejection gate fails |
| TSX components | 161.7 ± 5.2 ms | 47.9 ± 3.1 ms | 23.1 ± 4.7 ms | 2.08× faster |
| Generic calls | 197.7 ± 49.6 ms | 60.7 ± 18.9 ms | 25.6 ± 8.7 ms | 2.37× faster |
| Control flow | 219.0 ± 78.6 ms | 67.6 ± 18.4 ms | 39.9 ± 18.3 ms | 1.69× faster |
| Type predicates | 322.9 ± 151.3 ms | 88.1 ± 33.6 ms | 53.5 ± 16.9 ms | 1.65× faster |
| Large type predicates | 1120.0 ± 211.7 ms | 393.6 ± 94.1 ms | 377.0 ± 100.9 ms | 1.04× lower mean; noisy |
| Null-safe access | 223.1 ± 75.3 ms | 69.7 ± 26.0 ms | 52.0 ± 25.9 ms | 1.34× faster |
| Destructuring | 156.0 ± 18.2 ms | 50.7 ± 4.0 ms | 37.7 ± 7.1 ms | 1.34× faster |
| Overload resolution | 224.9 ± 27.2 ms | 70.2 ± 6.5 ms | 33.6 ± 9.5 ms | 2.09× faster |
| Class hierarchy | 335.8 ± 90.2 ms | 76.8 ± 17.7 ms | 45.3 ± 14.8 ms | 1.69× faster |
| Structural objects | 229.8 ± 28.9 ms | 71.1 ± 12.3 ms | 35.5 ± 4.9 ms | 2.01× faster |
| Interface composition | 241.4 ± 39.7 ms | 73.6 ± 13.5 ms | 52.5 ± 10.3 ms | 1.40× faster |
| Variadic tuples | 275.0 ± 12.9 ms | 84.3 ± 5.7 ms | 48.0 ± 7.9 ms | 1.76× faster |
| Checked JavaScript/JSDoc | 210.3 ± 9.9 ms | 56.4 ± 7.2 ms | 39.8 ± 6.4 ms | 1.42× faster |
| Recursive generic payloads | 151.7 ± 2.2 ms | 71.8 ± 1.1 ms | 29.7 ± 0.2 ms | 2.42× faster |

Home has lower means on **17/17 timed workloads**, while expanded admission
remains **17/19**. In paired rounds Home beats native TS 7 in 30/30 recursive
rounds and 24/30 large-predicate rounds. These observations are not proof of
universal, real-project or cross-platform leadership. This correctness
implementation is not claimed to accelerate the old compiler: its predecessor
fails the new recursive workload's rejection controls, so that speed comparison
would not represent equivalent semantic work.

```sh
# Run all currently eligible workloads; failing graph gates stay explicitly excluded.
HOME_TSC="$PWD/bench/vs_tsgo/results/lazy-generics.2H3YDX/release-v5/bin/home-tsc" python3 -c 'import sys; sys.path.insert(0,"bench/vs_tsgo"); import run; run.cmd_cold(30, 3, [w for w in run.manifest()["workloads"] if w not in ("import_graph", "reexport_graph")])'
python3 bench/vs_tsgo/compare.py bench/vs_tsgo/results/20260828T221149Z
```

After the full run, an independent 30-round confirmation was declared for the
new recursive workload and the narrowest mean margin, large predicates. It uses
the same frozen binary, three warmups, pinned competitors and admission gates.
Results are retained separately in `20260828T221611Z`
(`lazy-generics.2H3YDX/timing-confirmation-v5.log`):

| Confirmation workload | TS 6.0.3 | Native TS 7.0.2 | Home | Home vs faster competitor |
|---|---:|---:|---:|---:|
| Large type predicates | 1151.5 ± 272.4 ms | 392.7 ± 83.0 ms | 349.9 ± 17.0 ms | 1.12× faster |
| Recursive generic payloads | 156.6 ± 14.2 ms | 73.1 ± 3.9 ms | 29.6 ± 0.7 ms | 2.47× faster |

All **60 round files / 180 samples** validate. Home beats native TS 7 in
28/30 paired large-predicate rounds and 30/30 recursive rounds. These numbers
do not replace, get averaged into, or erase the first run's noisy 1.04× margin.
The shared-host and incomplete-coverage qualifications still apply.

```sh
HOME_TSC="$PWD/bench/vs_tsgo/results/lazy-generics.2H3YDX/release-v5/bin/home-tsc" python3 bench/vs_tsgo/run.py cold --runs 30 --warmup 3 --workload type_predicates_large --workload recursive_generics
python3 bench/vs_tsgo/compare.py bench/vs_tsgo/results/20260828T221611Z
```

### Source-owned exported factory contracts (untimed)

Commit `de8fe28f1`, issue [#534](https://github.com/home-lang/home/issues/534), under
[#487](https://github.com/home-lang/home/issues/487) and
[#416](https://github.com/home-lang/home/issues/416), extends the source-owned
graph to exported interfaces, type aliases, annotated variables and functions.
The old exported-value collector scanned declaration-file lines and discarded
generic signatures. The replacement resolves bound export identities, including
aliases and export-star paths, and shares one annotation graph before checking
consumers. Function signatures retain formal parameter identities, constraints,
ordered defaults, required/rest parameters, receiver types and parameterized
returns. It does not infer missing owner annotations or publish a partial
overload/merged-interface graph as a complete type.

`audit_graph_types.py` retains **240** controls: twelve semantic families across
local, named-import, namespace-import and two two-hop barrel placements, both
root orders, each with a positive and appended-only negative program. Both
compilers receive the same files and strict project configuration. Controls
exercise explicitly annotated interfaces, inferred factory results, wrong
property types, missing/readonly members, explicit type arguments, constraints,
required arity, ordinary/rest arguments, dependent defaults, captured factories
and consumer-local name collisions. A clean positive alone is not a pass:
the negative must emit exactly its expected diagnostic code.

| Untimed control | TS 6.0.3 | Native TS 7.0.2 | Home baseline `3b7f0ea93` | Home `de8fe28f1` Release |
|---|---:|---:|---:|---:|
| Factory contracts | 240/240 | 240/240 | 130/240 | 240/240 |
| Original graph admission | 2/2 | 2/2 | 0/2 | 2/2 |
| Static-value controls | 84/84 | 84/84 | 84/84 | 84/84 |
| Nominal-origin controls | 52/52 | 52/52 | 44/52 | 44/52 |
| Imported-owner controls | 20/20 | 20/20 | 10/20 | 12/20 |
| Recursive generic controls | 288/288 | 288/288 | 288/288 | 288/288 |
| Generic-class controls | 120/120 | 120/120 | 120/120 | 120/120 |
| Bound-class controls | 52/52 | 52/52 | 52/52 | 52/52 |
| Callable identity controls | 56/56 | 56/56 | 56/56 | 56/56 |
| Callable union controls | 256/256 | 256/256 | 256/256 | 256/256 |
| Graph discovery controls | 28/28 | 28/28 | 28/28 | 28/28 |
| Export-origin controls | 32/32 | 32/32 | 32/32 | 32/32 |
| Global controls | 56/56 | 56/56 | 32/56 | 32/56 |
| Bound-global controls | 56/56 | 56/56 | 44/56 | 44/56 |

Evidence is retained in `bench/vs_tsgo/results/graph-types.4EsbvV/`:
`audit-before.log`, `audit-v2.log`, `audit-v3.log`, `graphs-v2.log`,
`static_values-v2.log`, and `nominal_origins-v2.log`. The intermediate candidate
passed 220/240 factory controls; its twenty dependent-default failures remain
recorded. Applying defaults using owner-resolved type parameter payloads, in
declaration order, removes those failures without changing the controls.
Release repeats are in the corresponding `*-release-v3.log` files. The eight
inherited private/protected nominal-origin failures remain open, as do eight
imported-owner predicate/rest controls and the existing global-control failures.

All **19/19 workloads pass Release admission**, including the unchanged original
graph, tuple, destructuring, predicate and recursive-generic rejection controls
(`admission-release-v3.log`). Full relevant suites pass: **4,286/4,286 checker**,
**1,417/1,417 conformance**, **133/133 Program**, **187/187 driver**, **69/69 CLI**,
**10/10 source-owned focus**, and **69/69 benchmark-harness** tests. These are the
named repository suites, not a claim of complete upstream TypeScript parity.

The frozen binary is `graph-types.4EsbvV/release-v3/bin/home-tsc`, SHA-256
`9f5e333beaf9828a9720ce260ae05a872ebcea3bb51bf5785ffa3ccd7b72f1bc`.
These correctness results are **not timing claims**. The earlier measured
snapshot above still refers to its original frozen binary. A profile also
identified redundant source compilation in CommonJS export queries; follow-up
[#536](https://github.com/home-lang/home/issues/536) will use this corrected
version as its comparison baseline, never the previously ineligible graph run.

```sh
HOME_TSC="$PWD/bench/vs_tsgo/results/graph-types.4EsbvV/release-v3/bin/home-tsc" python3 bench/vs_tsgo/audit_graph_types.py
python3 -m unittest discover -s bench/vs_tsgo -p 'test_*.py'
```

### Exported-factory checkpoint performance

The complete run `20260828T224220Z` measures the frozen `de8fe28f1` ReleaseFast
binary above against **TS 6.0.3** and **native TS 7.0.2**. All **19/19 workloads**
pass admission before measurement, including the unchanged original graph
rejection controls. All **570 round files / 1,710 successful samples** pass the
reporter's coverage, rotating-order, exit-status and finite-duration checks.
Fresh generation independently matches all **513 measured corpus files** byte
for byte (`graph-types.4EsbvV/corpus-verified-v3.log`). No samples are discarded.

Environment: Apple M3 Pro, arm64, macOS 27.0, shared workstation; 30 interleaved
fresh-process measurements per compiler/workload after three warmups. This
task's builds, tests and audits finished before timing. Unrelated CPU and
filesystem activity continued, including another Zig compilation. Load averages
were 6.17 / 8.23 / 12.63 before the run and 6.79 / 7.03 / 10.92 afterward.
Interleaving balances order, not all contention. Means and sample standard
deviations below are observations, not statistical proof of universal leadership.

| Workload | TS 6.0.3 | Native TS 7.0.2 | Home | Home vs faster competitor |
|---|---:|---:|---:|---:|
| Startup | 68.9 ± 6.2 ms | 40.9 ± 0.9 ms | 3.6 ± 0.1 ms | 11.45× faster |
| 256 files | 220.8 ± 9.7 ms | 57.0 ± 5.4 ms | 34.8 ± 1.5 ms | 1.64× faster |
| Deep types | 131.5 ± 5.3 ms | 52.8 ± 1.7 ms | 26.5 ± 0.5 ms | 2.00× faster |
| 128-module import graph | 145.5 ± 35.6 ms | 50.8 ± 9.9 ms | 33.7 ± 7.4 ms | 1.51× faster |
| 64-leaf barrel graph | 97.2 ± 11.8 ms | 41.1 ± 1.1 ms | 25.1 ± 3.2 ms | 1.63× faster |
| TSX components | 160.4 ± 1.9 ms | 47.0 ± 1.0 ms | 26.3 ± 0.4 ms | 1.79× faster |
| Generic calls | 190.1 ± 21.9 ms | 56.5 ± 4.5 ms | 24.2 ± 1.2 ms | 2.34× faster |
| Control flow | 210.1 ± 37.7 ms | 63.2 ± 5.0 ms | 44.9 ± 7.0 ms | 1.41× faster |
| Type predicates | 259.9 ± 32.0 ms | 80.5 ± 16.2 ms | 50.5 ± 8.9 ms | 1.59× faster |
| Large type predicates | 1071.8 ± 87.3 ms | 380.6 ± 44.8 ms | 541.3 ± 50.7 ms | **1.42× slower** |
| Null-safe access | 198.3 ± 15.7 ms | 58.8 ± 3.1 ms | 41.9 ± 1.8 ms | 1.40× faster |
| Destructuring | 143.6 ± 4.6 ms | 49.8 ± 2.2 ms | 38.6 ± 4.5 ms | 1.29× faster |
| Overload resolution | 204.7 ± 11.0 ms | 66.7 ± 5.2 ms | 30.5 ± 1.4 ms | 2.19× faster |
| Class hierarchy | 193.5 ± 18.1 ms | 55.7 ± 4.2 ms | 29.9 ± 1.3 ms | 1.86× faster |
| Structural objects | 207.2 ± 19.7 ms | 63.9 ± 4.7 ms | 32.4 ± 1.8 ms | 1.97× faster |
| Interface composition | 214.1 ± 14.0 ms | 68.5 ± 6.1 ms | 47.8 ± 4.6 ms | 1.43× faster |
| Variadic tuples | 280.3 ± 21.4 ms | 85.8 ± 5.3 ms | 49.4 ± 4.0 ms | 1.74× faster |
| Checked JavaScript/JSDoc | 233.9 ± 21.7 ms | 60.0 ± 4.2 ms | 39.4 ± 0.8 ms | 1.52× faster |
| Recursive generic payloads | 166.8 ± 12.2 ms | 77.0 ± 7.5 ms | 30.9 ± 1.3 ms | 2.49× faster |

Home has lower means on **18/19**, not all workloads. It beats native TS 7 in
29/30 import-graph and 30/30 re-export-graph paired rounds, but **0/30 large
predicate rounds**. The losing row is retained and tracked by
[#537](https://github.com/home-lang/home/issues/537). Historical results suggest
a scaling regression worth investigating; they are not a controlled before/after
comparison. The cause must be established against a same-correctness baseline.
Broader rejection coverage, real-project and cross-platform measurements, and
the remaining correctness failures above still prevent an overall completion claim.

```sh
HOME_TSC="$PWD/bench/vs_tsgo/results/graph-types.4EsbvV/release-v3/bin/home-tsc" python3 bench/vs_tsgo/run.py cold --runs 30 --warmup 3
python3 bench/vs_tsgo/compare.py bench/vs_tsgo/results/20260828T224220Z
```

The full console record and rendered report are retained as
`graph-types.4EsbvV/timing-release-v3.log` and `report-release-v3.md`.

A separate same-host before/after diagnostic confirms the large-predicate
regression: frozen `3b7f0ea93` takes **351.0 ± 16.9 ms**, versus `de8fe28f1`
**533.8 ± 14.9 ms**, a **1.52× slowdown**. Both binaries first pass this same
workload's positive and unchanged predicate rejection controls. Three warmups
per binary precede thirty two-process rounds, alternating before/after order;
all **30 rounds / 60 successful samples** are retained in
`graph-types.4EsbvV/predicate-ab-v3/` with binary paths, versions and hashes.
The newer binary loses all thirty paired rounds. This diagnostic is not averaged
into the three-compiler table and says nothing about the old binary's eligibility
for the graph workloads. Source inspection identifies repeated whole-block
export-name scans as a candidate cost to investigate under #537. The subsequent
indexed-export checkpoint below implements and verifies that optimization.

### Indexed export queries and variable-list ownership

Commit `b7b9dd9ee`, follow-up [#537](https://github.com/home-lang/home/issues/537), replaces repeated
whole-source export/import scans with an index of each prepared owner's bound
declarations and unresolved alias/star edges. The index is built once per owner;
queries still traverse relevant edges with their own visibility and cycle state.
It does not cache a permissive answer or skip type checking. Lexical edge order,
explicit-export precedence, default exports, type-only restrictions, merged
symbols and declaration provenance are preserved.

An operation-count regression proves the repeated work independently of timing:
resolving 128 exports from a 256-statement source previously visited **65,536**
root statements; the indexed query visits **256**, including subsequent missing
and hidden-name queries. Test-only accounting is absent from production builds.
The original failing test output is retained as
`export-index.NVcIdu/program-before.log`; the indexed/ownership Program suite
passes **137/137**, including ambiguity, cycles, destructured declarations,
provenance and allocation-failure cleanup.

Those tests also exposed an existing parser bug: trailing declarators in
`export const first = 1, second = 2` were emitted as unexported siblings.
Commit `d6878e880` ([#538](https://github.com/home-lang/home/issues/538)) preserves export ownership
for every declarator, without inferring it from source text in the index.
The parser suite passes **891/891** tests.

The `audit_export_lists.py` gate now has 128 untimed cases across
const/let/var/declare-var, named/namespace/two-hop barrel imports, both root
orders, and identical positives with appended wrong-type, hidden-binding, or
renamed-hidden-binding negatives. Every compiler receives the same explicit
root set and exact expected diagnostic-code multiset. The
[#540](https://github.com/home-lang/home/issues/540) candidate carries prepared
owner-local declaration and renamed-export facts through the resolver; it does
not reopen source or check the owner from the consumer. Direct hidden imports
therefore refine a trusted export-table miss to TS2459/TS2460, while a barrel
that does not itself declare the name remains TS2305.

| Export-list control | TS 6.0.3 | Native TS 7.0.2 | Home before #540 | Home after #540 |
|---|---:|---:|---:|---:|
| Valid trailing-member consumption | 32/32 | 32/32 | 32/32 | 32/32 |
| Wrong trailing-member type | 32/32 | 32/32 | 32/32 | 32/32 |
| Hidden name through a barrel (TS2305) | 16/16 | 16/16 | 16/16 | 16/16 |
| Hidden name imported directly (TS2459) | 16/16 | 16/16 | 0/16 | 16/16 |
| Renamed hidden name through a barrel (TS2305) | 16/16 | 16/16 | 0/16 | 16/16 |
| Renamed hidden name imported directly (TS2460) | 16/16 | 16/16 | 0/16 | 16/16 |
| **Total** | **128/128** | **128/128** | **80/128** | **128/128** |

That is **384/384 compiler checks with zero failures** after the fix, versus 48
Home failures before it. This is a correctness/admission result, not a timing
claim. Frozen evidence is retained under `local-import-facts.zSUp41/`: the
pristine `078363fa4` before binary is SHA-256
`ae96066ab6cb5b205d4dd6132024a587bf2b16bda3293fee1ca593118693c13e` and the
after binary is
`1ad8f6bd5d1959ca9f236776453b83407f2296af428edd3b527f4bcd9623e921`, with one
complete before log and two byte-identical after logs (SHA-256
`2f911dc51b73577f69c7c729f000a2b030b32dc5308660fc3775fee1008c8c`). The earlier 96-case evidence remains in
`export-index.NVcIdu/export-lists-before.log` and `export_lists-v3.log`.

All **19/19 workloads pass admission**. Existing release audits retain their
previous scores: factory 240/240, recursive 288/288, generic classes 120/120,
static 84/84, bound classes 52/52, callable identity 56/56, callable unions 256/256,
graph discovery 28/28, export origins 32/32, owners 12/20, nominal origins 44/52,
globals 32/56 and bound globals 44/56. No pre-existing failure is removed.
Relevant suites pass: checker **4,286/4,286**, conformance **1,417/1,417**,
Program **137/137**, parser **891/891**, driver **187/187**, CLI **69/69**,
emitter **499/499**, and benchmark harness **72/72**. Disk-space-failed build logs
are retained; successful retries are separately named `*-v3-retry.log`.

The frozen ReleaseFast binary is
`export-index.NVcIdu/release-v3/bin/home-tsc`, SHA-256
`615e9fa1f78c2cad17a0b8911b897ede73c00422138d6ecbb2b74801d4564f14`.

```sh
HOME_TSC="$PWD/bench/vs_tsgo/results/local-import-facts.zSUp41/after/bin/home-tsc" python3 bench/vs_tsgo/audit_export_lists.py
HOME_TSC="$PWD/bench/vs_tsgo/results/export-index.NVcIdu/release-v3/bin/home-tsc" python3 bench/vs_tsgo/audit_export_lists.py
HOME_TSC="$PWD/bench/vs_tsgo/results/export-index.NVcIdu/release-v3/bin/home-tsc" python3 bench/vs_tsgo/run.py cold --runs 30 --warmup 3
```

The controlled large-predicate before/after run uses frozen `de8fe28f1` and
`b7b9dd9ee`, both of which first pass this workload and its unchanged predicate
rejection controls. After three warmups per binary, thirty rounds alternate the
before/after process order. All **30 round files / 60 successful finite samples**
are retained in `export-index.NVcIdu/predicate-ab-v3/`, with paths, versions and
SHA-256 hashes; console summary: `predicate-ab-v3.log`.

The previous build averages **525.6 ± 12.4 ms** and the indexed build
**353.5 ± 10.5 ms**: **32.7% less time**, with the new build faster in **30/30**
paired rounds. This comparison is restricted to an input on which both builds
pass the same semantic controls. It is separate from the earlier regression
measurement and from the full three-compiler run; results are not averaged
together. The operation-count test and same-correctness measurement support
removing the repeated export-query scans, not skipping semantic work.

### Indexed-export checkpoint performance

The complete `b7b9dd9ee` checkpoint, `20260828T231439Z`, uses the frozen binary
above on an Apple M3 Pro, arm64, macOS 27.0 shared workstation. The harness
verifies **TS 6.0.3 and native TS 7.0.2** before admission; TS 7 and `tsgo` are
one competitor. All 19 positive workloads and their unchanged rejection gates
pass on all three compilers before measurement. After three warmups, 30 rounds
rotate compiler order for every workload. Integrity validation accepts all
**570 round files / 1,710 successful finite samples**. Fresh generation after
timing matches all **513 measured corpus files byte-for-byte**.

Own builds, tests and audits had finished before timing, but unrelated shared-host
activity remained. Load averages before/after were 5.51 / 15.13 / 14.10 and
4.72 / 10.21 / 12.23. No rounds or outliers were discarded. Times below are
mean ± sample standard deviation; ratios use unrounded means and the faster
competitor (native TS 7 for every row).

| Workload | TS 6.0.3 | Native TS 7.0.2 | Home | Home vs fastest competitor |
|---|---:|---:|---:|---:|
| `startup` | 65.3 ± 3.2 ms | 39.5 ± 2.9 ms | 3.3 ± 0.2 ms | 11.82× faster |
| `many_files` | 216.5 ± 18.0 ms | 57.0 ± 4.9 ms | 38.1 ± 12.4 ms | 1.50× faster |
| `deep_types` | 137.5 ± 12.3 ms | 55.2 ± 4.3 ms | 28.2 ± 2.6 ms | 1.96× faster |
| `import_graph` | 140.7 ± 14.4 ms | 49.2 ± 5.8 ms | 33.3 ± 4.4 ms | 1.48× faster |
| `reexport_graph` | 99.1 ± 4.3 ms | 44.1 ± 8.9 ms | 25.6 ± 3.1 ms | 1.72× faster |
| `tsx_components` | 162.8 ± 6.6 ms | 47.5 ± 1.3 ms | 23.8 ± 3.3 ms | 1.99× faster |
| `generic_calls` | 181.4 ± 13.4 ms | 56.1 ± 4.2 ms | 23.0 ± 0.8 ms | 2.44× faster |
| `control_flow` | 194.3 ± 10.4 ms | 61.3 ± 7.7 ms | 36.5 ± 1.9 ms | 1.68× faster |
| `type_predicates` | 248.1 ± 8.2 ms | 74.0 ± 1.8 ms | 45.4 ± 1.2 ms | 1.63× faster |
| `type_predicates_large` | 1053.4 ± 204.0 ms | 377.7 ± 66.4 ms | 371.6 ± 125.5 ms | 1.02× lower mean; noisy |
| `null_safe_access` | 189.6 ± 8.8 ms | 61.1 ± 23.1 ms | 39.7 ± 1.0 ms | 1.54× faster |
| `destructuring` | 145.0 ± 20.3 ms | 49.5 ± 9.2 ms | 36.6 ± 6.8 ms | 1.35× faster |
| `overload_resolution` | 194.1 ± 4.0 ms | 62.5 ± 1.5 ms | 29.1 ± 0.8 ms | 2.15× faster |
| `class_hierarchy` | 178.9 ± 19.5 ms | 50.6 ± 1.9 ms | 28.2 ± 3.0 ms | 1.79× faster |
| `structural_objects` | 180.0 ± 14.9 ms | 56.2 ± 1.2 ms | 29.2 ± 0.9 ms | 1.92× faster |
| `interface_composition` | 191.7 ± 1.7 ms | 60.4 ± 1.1 ms | 42.9 ± 0.4 ms | 1.41× faster |
| `variadic_tuples` | 242.4 ± 6.7 ms | 76.1 ± 2.7 ms | 42.9 ± 1.3 ms | 1.77× faster |
| `checkjs_jsdoc` | 204.9 ± 6.4 ms | 54.7 ± 2.4 ms | 38.0 ± 1.5 ms | 1.44× faster |
| `recursive_generics` | 157.2 ± 10.9 ms | 73.9 ± 3.5 ms | 30.2 ± 1.7 ms | 2.45× faster |

Home has lower means on **19/19**, but this is not universal or statistically
established benchmark leadership. Large predicates lead by only 1.02× with
substantial variance and **25/30 paired wins** over TS 7. Import graph, re-export
graph and many-files paired wins are 29/30, 30/30 and 29/30 respectively.
Real projects, additional platforms and the outstanding correctness gaps above
remain unvalidated. The earlier losing checkpoint stays documented separately.

An independent large-predicate confirmation, `20260828T231856Z`, uses the same
binary, unchanged controls, three warmups and 30 rotating-order rounds. All
**30 round files / 90 successful samples** validate. Home has the lower time
in **29/30 paired rounds**; the margin remains narrow. This targeted run is
reported separately, not substituted for the full-run row or pooled with it:

| Confirmation workload | TS 6.0.3 | Native TS 7.0.2 | Home | Home vs fastest competitor |
|---|---:|---:|---:|---:|
| `type_predicates_large` | 950.2 ± 6.6 ms | 331.4 ± 4.6 ms | 320.4 ± 2.8 ms | 1.03× faster |

```sh
HOME_TSC="$PWD/bench/vs_tsgo/results/export-index.NVcIdu/release-v3/bin/home-tsc" python3 bench/vs_tsgo/run.py cold --runs 30 --warmup 3
python3 bench/vs_tsgo/compare.py bench/vs_tsgo/results/20260828T231439Z
HOME_TSC="$PWD/bench/vs_tsgo/results/export-index.NVcIdu/release-v3/bin/home-tsc" python3 bench/vs_tsgo/run.py cold --runs 30 --warmup 3 --workload type_predicates_large
python3 bench/vs_tsgo/compare.py bench/vs_tsgo/results/20260828T231856Z
```

Full-run, confirmation and input-integrity logs are retained locally as
`export-index.NVcIdu/timing-v3.log`, `confirmation-v3.log` and
`corpus-verified-v3.log`. Raw round files and metadata remain in their named
result directories under `bench/vs_tsgo/results/`; they are not combined with
any earlier checkpoint.

### Prepared CommonJS export queries

Commit `1cfc33c1a`, follow-up [#536](https://github.com/home-lang/home/issues/536), removes a repeated
compilation in the empty-name export query. The CLI previously read the file
and ran a complete parse/bind/check to find a CommonJS constructor name before
obtaining its already cached bound module. The query now borrows that prepared
owner's HIR and bindings directly; the conformance adapter retains prepared
owners for both shape and export-table queries as well. The source-only API
prepares bindings but no longer checks merely to answer this shape question.

Raw `module.exports` substring recovery is removed. Display names come from
bound class constructors and const aliases, not comments, strings, unbound
names or unrelated function constructors. Local `module` bindings are
distinguished from the CommonJS wrapper binding. Multiple export assignments
do not get flattened into the first class's name: this single-class display
fact is absent when the actual union type is needed. This metadata query does
not replace semantic type checking or supply an `any` type.

The new audit in commit `d95dfaac1` also exposes a separate cross-file typing
gap, tracked by [#541](https://github.com/home-lang/home/issues/541). It includes
11 source forms, both root orders, valid consumption, and the identical program
with an appended wrong-type or missing-member use. Every configuration
explicitly lists the JavaScript files and enables strict `allowJs`/`checkJs`.
Both pinned compilers pass **66/66**; frozen Home `b7b9dd9ee` passes **22/66**:

| Untimed CommonJS control | TS 6.0.3 | Native TS 7.0.2 | Home baseline |
|---|---:|---:|---:|
| Valid instance consumption | 22/22 | 22/22 | 22/22 |
| Wrong consumed member type (TS2322) | 22/22 | 22/22 | 0/22 |
| Missing member (TS2339) | 22/22 | 22/22 | 0/22 |

The missing 44 diagnostics are retained, not waived. CommonJS instance
consumption is **not a timed workload**. Reassignment can produce union types;
TS 6 and TS 7 differ in union ordering/display for some probes, so the shared
audit compares exact diagnostic-code multisets, not an invented common wording.

```sh
python3 bench/vs_tsgo/audit_commonjs.py
python3 -m unittest discover -s bench/vs_tsgo -p 'test_*.py'
```

Evidence is retained locally in `bench/vs_tsgo/results/commonjs-query.hyU20d/`:
`audit-before.log` records the 198 checks. `probe-roots-before.log` includes
diagnostic wording. The initial `probe-before.log` accidentally excluded JS
via a TS-only include and is **not valid admission evidence**; the replacement
uses explicit JS roots, and harness tests now enforce those roots and flags.

The ReleaseFast candidate is `commonjs-query.hyU20d/release-v1/bin/home-tsc`,
SHA-256 `573257a819a178c9387f6d02a7992c08f995185f5dbc94034eb5eadc0ae956c0`.
All **19/19** existing workload admission gates pass before timing. The complete
15-audit comparison checks case identities as well as totals: **every previously
passing case still passes**. Home's CommonJS result remains 22/66 and all other
audit scores remain unchanged, including exported factories 240/240, recursive
generics 288/288, exported variable lists 80/96, nominal origins 44/52, owners
12/20, globals 32/56 and bound globals 44/56. Both competitors pass every case.

Program **140/140**, conformance **1,418/1,418**, CLI **69/69** and harness
**75/75** tests pass; unchanged checker and driver targets verify from cache.
Program tests cover bound aliases,
shadowing, comments/strings, multiple assignments, and 128 repeated queries with
an unchanged HIR/type pool and no checked-owner state. Conformance adds cache
identity checks in both JavaScript modes. Three disk-interrupted audit logs are
retained alongside complete `*-v1-retry.log` replacements; the final per-case
verification is `verification-final.log`. No incomplete audit was counted as
passing, and no source, frozen compiler or benchmark evidence was deleted.
The first conformance command returned success but lost its console output
during disk exhaustion; the complete successful retry is retained as
`conformance-v1-retry.log`.

### Static CommonJS dependency discovery (untimed)

Commits `0ebdba7ef` and `eaf86ee56`, tracked by
[#545](https://github.com/home-lang/home/issues/545), add an untimed graph audit
and make Program closure discovery follow static JavaScript `require` calls.
The implementation traverses parsed HIR, accepts exactly one string-literal-like
argument (including a no-substitution template), and preserves lexical edge
order. It does not scan source text. Comments, strings, computed specifiers,
property calls, interpolated templates and multiple-argument calls remain
excluded. Cycles and diamonds retain unique current edges after recompilation.

The audit contains 44 projects and runs each through all three compilers, for
132 exact diagnostic-code checks. Six followed families cover binding, nested,
template, transitive, cyclic and diamond graphs. Five decoy families cover
comments, strings, dynamic specifiers, property calls and multiple arguments.
Every family has entry-only and all-file roots, plus a positive project and an
otherwise identical negative that only appends TS2322 to the leaf. This makes
dependency inclusion observable without treating an absent error as success.

| Untimed static-`require` controls | TS 6.0.3 | Native TS 7.0.2 | Frozen Home before | Home after |
|---|---:|---:|---:|---:|
| Followed graph shapes | 24/24 | 24/24 | 18/24 | 24/24 |
| Ignored lookalikes | 20/20 | 20/20 | 20/20 | 20/20 |
| **Total** | **44/44** | **44/44** | **38/44** | **44/44** |

The frozen before binary is the `1cfc33c1a` release used by the prepared-query
checkpoint. The immutable after binary is
`commonjs-discovery.JMl1yj/release-v1/bin/home-tsc`, SHA-256
`31679b8aeb0a6279880dbdd140e25fd891a07e7967a36e92324f82b3776df5e7`.
Program **143/143**, the 78-test Python harness, checker, driver, CLI and the
conformance target pass. The conformance target reports smoke **16/16**, named
categories **86/86** and baseline-aware categories **586/586**. Raw before,
after, conformance and unchanged-gap logs are retained locally in
`bench/vs_tsgo/results/commonjs-discovery.JMl1yj/`.

This is a correctness result, not a timed workload or a performance claim. At
this checkpoint the separate CommonJS instance audit remained TS 6 **66/66**,
native TS 7 **66/66**, Home **22/66**. Static graph discovery was the
prerequisite for the checked-owner transfer documented in the next section; it
was not itself a substitute for that transfer.

### Checked CommonJS export type transfer (untimed)

Follow-up [#541](https://github.com/home-lang/home/issues/541) transfers the
checked declaration owner's actual `module.exports` types into each requiring
consumer. The projection starts from the owner's checked type IDs, preserving
inferred fields, literal widening, reassignment unions, functions, tuples,
arrays, plain objects and class declaration identity. Unsupported shapes remain
explicitly unsupported; the implementation does not infer types from source
spelling or add diagnostic-only recovery.

Program resolves the bound dependency graph before checking and checks owners
before consumers. Serial and streaming execution use the same dependency order.
Parallel execution retains the ordinary parallel path for programs that do not
need whole CommonJS export transfer and uses dependency order when those checked
owner schemas are required. Tests cover all three execution modes and both
owner/app insertion orders.

The unchanged 66-case audit verifies exact diagnostic-code multisets with
version-checked TS **6.0.3** and native TS **7.0.2**. Eleven source families each
run in both root orders with a valid consumer, an otherwise identical TS2322
control, and an otherwise identical TS2339 control:

| Untimed CommonJS control | TS 6.0.3 | Native TS 7.0.2 | Frozen Home before | Home after |
|---|---:|---:|---:|---:|
| Valid instance consumption | 22/22 | 22/22 | 22/22 | 22/22 |
| Wrong consumed member type (TS2322) | 22/22 | 22/22 | 0/22 | 22/22 |
| Missing member (TS2339) | 22/22 | 22/22 | 0/22 | 22/22 |
| **Total** | **66/66** | **66/66** | **22/66** | **66/66** |

The audit performs **198/198** compiler/case checks with zero failures. The
static-`require` discovery audit also remains **132/132** checks with zero
failures. The final immutable ReleaseFast candidate is
`commonjs-linkage.gyKMKg/release-v6/bin/home-tsc`, SHA-256
`3820830f2cd4c4f680164dc7cd1c87ac3294ef803c37e9c44cab7a76559c2c14`.
Raw audit and harness logs are retained locally under
`bench/vs_tsgo/results/commonjs-linkage.gyKMKg/`.

Program **145/145**, the 82-test Python harness, checker, driver and CLI suites
pass. The conformance target reports smoke **16/16**, named categories
**86/86**, and baseline-aware categories **586/586**. This is a correctness
benchmark only; no CommonJS timing is admitted by this result.

### Checked CommonJS graph performance

Issue [#546](https://github.com/home-lang/home/issues/546) adds the first timed
CommonJS graph only after the checked-owner transfer above reached full audit
parity. The deterministic project has 128 checked-JavaScript owners and one
consumer. Each owner exports an inferred service object, then reassigns
`module.exports` to an alternate shape so the consumer must use the real
cross-file union. The admission copy injects wrong-label and missing-member
uses into the first, middle, and last owner. TS 6.0.3, native TS 7.0.2, and Home
must each emit exactly three `TS2322` and three `TS2339` diagnostics before any
timing directory can be created.

The first admitted result, `20260829T010034Z`, retained the loss: Home took
62.8 ± 1.2 ms versus native TS 7 at 51.1 ± 2.1 ms, or 1.23× longer. The
general fixes resolve dependency edges once, schedule dependency-ready files in
parallel batches, avoid redundant graph resolution and irrelevant schema scans,
index actual HIR `var` declarations instead of repeatedly scanning source text,
and cache the immutable Node reference-directive fact. These changes preserve
the checked schema and do not add recovery, source-spelling inference, or a
benchmark-specific fast path.

The exact same-correctness Home A/B compares the original correct release-v2
binary with release-v6. It uses three warmups and 30 alternating-order rounds;
all 30 round files and 60 finite samples are retained, with none removed:

| `commonjs_graph` Home A/B | Correct release-v2 | Optimized release-v6 | After / before | Lower after time |
|---|---:|---:|---:|---:|
| 128 owners + consumer | 62.33 ± 1.49 ms | **42.96 ± 0.92 ms** | **0.689 (31.1% less time)** | **30/30 rounds** |

The complete admitted result is **`20260829T013535Z`**. It uses the same Apple
M3 Pro arm64/macOS 27.0 host, three warmups, 30 rotating-order rounds, and the
exact pins TS **6.0.3** and native TS **7.0.2**. TS 7 and `tsgo` are one
competitor. The full 20-row table is the [current snapshot](#current-snapshot).
Home records the lower mean on **20/20** rows. On `commonjs_graph`, TS 6 takes
148.9 ± 2.5 ms, native TS 7 takes 48.3 ± 1.4 ms, and Home takes
**42.1 ± 0.7 ms**, a **1.15×** lead with 30/30 paired wins. Integrity
validation retains **600 round files / 1,800 successful finite samples** with
no omitted row or discarded sample.

The 1.01× `type_predicates_large` mean margin has only 24/30 paired wins and
must be treated as narrow. `generic_calls` and `overload_resolution` each have
29/30 paired wins and visible variance. The other 17 rows have 30/30 paired
wins. This checkpoint establishes the local admitted synthetic result, not
universal leadership; real-project, cross-platform, and broader semantic
coverage remain open.

The final candidate is
`bench/vs_tsgo/results/commonjs-linkage.gyKMKg/release-v6/bin/home-tsc`, SHA-256
`3820830f2cd4c4f680164dc7cd1c87ac3294ef803c37e9c44cab7a76559c2c14`.
Evidence is retained in `bench/vs_tsgo/results/commonjs-linkage.gyKMKg/` and
`bench/vs_tsgo/results/20260829T013535Z/`, including the release-v2/release-v6
A/B, the initial loss, complete report, commands, audits, and harness logs.

```sh
HOME_TSC="$PWD/bench/vs_tsgo/results/commonjs-linkage.gyKMKg/release-v6/bin/home-tsc" python3 bench/vs_tsgo/run.py cold --runs 30 --warmup 3
python3 bench/vs_tsgo/compare.py bench/vs_tsgo/results/20260829T013535Z
```

Verification for the final source and candidate: CommonJS transfer **198/198**
checks, static CommonJS discovery **132/132** checks, Python harness **82/82**,
Program **145/145**, checker, driver, and CLI suites green; conformance smoke
**16/16**, named categories **86/86**, and baseline-aware categories **586/586**.

### Prepared-query checkpoint performance

The same-correctness before/after diagnostic compares frozen `b7b9dd9ee` with
`1cfc33c1a`. Both first pass the original import and re-export graph positives
and their unchanged negative controls. Each workload has three warmups per
binary followed by 30 rounds alternating process order. All **60 round files /
120 successful finite samples** are retained in
`commonjs-query.hyU20d/graph-ab-v1/`, including commands, versions and hashes.

| Paired graph comparison | Before | Prepared query | After / before | Lower after time |
|---|---:|---:|---:|---:|
| `import_graph` | 32.4 ± 1.7 ms | 28.4 ± 0.6 ms | 0.876 (12.4% less time) | 30/30 rounds |
| `reexport_graph` | 27.9 ± 5.2 ms | 27.3 ± 4.2 ms | 0.977 (2.3% less time) | 17/30 rounds |

The import-graph improvement is consistent across this run. The small barrel
mean difference is noisy and does **not** establish a reliable improvement.
This comparison is separate from the full three-compiler run; the measurements
are not averaged together. Before-run load averages were 5.43 / 7.41 / 8.00 on
the shared Apple M3 Pro workstation, after our builds, tests and audits finished.

The checkpoint also records resolved compiler artifacts outside timed commands:
both Home binaries, the actual native TS 7 executable, TS 6's compiler payload
(`lib/_tsc.js`), launchers and Node runtime. The native compiler is distinguished
from its JavaScript launcher. Evidence: `provenance-before.json` and the
checkpoint-local `provenance.py`; automatic harness-wide provenance remains
tracked by [#544](https://github.com/home-lang/home/issues/544).

The complete three-compiler measurement is **`20260828T234350Z`**, on the same
Apple M3 Pro arm64 / macOS 27.0 shared workstation. Verified versions are
**TS 6.0.3 and native TS 7.0.2**; native TS 7/`tsgo` is one competitor. All 19
workloads pass admission before three warmups and 30 rotating-order rounds.
Integrity validation accepts **570 round files / 1,710 successful finite
samples**. No sample is discarded. Fresh generation matches all **513 corpus
files byte-for-byte**, and the recorded compiler/runtime/launcher paths and
hashes match after measurement (`provenance-after.json`).

Our builds, tests and audits had finished before timing; unrelated shared-host
activity persisted. Full-run load averages before/after were 4.89 / 7.16 / 7.89
and 6.37 / 7.56 / 7.94. Times below are mean ± sample standard deviation;
ratios use unrounded means and the faster competitor (native TS 7 in every row).

| Workload | TS 6.0.3 | Native TS 7.0.2 | Home | Home vs fastest competitor |
|---|---:|---:|---:|---:|
| `startup` | 65.7 ± 1.2 ms | 40.0 ± 1.1 ms | 3.6 ± 0.1 ms | 11.26× faster |
| `many_files` | 214.6 ± 2.7 ms | 57.2 ± 1.8 ms | 34.8 ± 1.0 ms | 1.65× faster |
| `deep_types` | 132.6 ± 17.7 ms | 53.1 ± 2.5 ms | 27.1 ± 1.1 ms | 1.96× faster |
| `import_graph` | 131.0 ± 2.1 ms | 47.0 ± 1.3 ms | 28.1 ± 1.1 ms | 1.67× faster |
| `reexport_graph` | 102.7 ± 14.8 ms | 42.7 ± 1.3 ms | 25.6 ± 2.5 ms | 1.67× faster |
| `tsx_components` | 167.9 ± 1.9 ms | 48.0 ± 0.9 ms | 23.3 ± 0.2 ms | 2.06× faster |
| `generic_calls` | 182.8 ± 3.2 ms | 56.3 ± 1.7 ms | 23.2 ± 0.4 ms | 2.42× faster |
| `control_flow` | 288.2 ± 93.7 ms | 86.9 ± 35.4 ms | 46.7 ± 11.7 ms | 1.86× faster |
| `type_predicates` | 434.7 ± 102.3 ms | 142.9 ± 87.0 ms | 67.7 ± 15.1 ms | 2.11× faster |
| `type_predicates_large` | 1023.2 ± 72.0 ms | 362.2 ± 30.4 ms | 340.5 ± 18.2 ms | 1.06× lower mean; narrow |
| `null_safe_access` | 187.3 ± 2.2 ms | 57.0 ± 1.8 ms | 39.6 ± 0.4 ms | 1.44× faster |
| `destructuring` | 137.7 ± 2.1 ms | 47.6 ± 1.4 ms | 35.3 ± 0.7 ms | 1.35× faster |
| `overload_resolution` | 196.8 ± 10.6 ms | 63.7 ± 1.8 ms | 29.5 ± 0.7 ms | 2.16× faster |
| `class_hierarchy` | 233.5 ± 135.8 ms | 62.6 ± 39.5 ms | 34.2 ± 18.4 ms | 1.83× faster |
| `structural_objects` | 186.2 ± 11.0 ms | 59.1 ± 4.4 ms | 30.6 ± 1.7 ms | 1.93× faster |
| `interface_composition` | 200.3 ± 5.2 ms | 63.9 ± 1.8 ms | 44.8 ± 1.2 ms | 1.43× faster |
| `variadic_tuples` | 240.3 ± 5.6 ms | 74.8 ± 2.3 ms | 43.1 ± 2.6 ms | 1.74× faster |
| `checkjs_jsdoc` | 200.8 ± 4.6 ms | 53.6 ± 1.3 ms | 37.1 ± 0.6 ms | 1.45× faster |
| `recursive_generics` | 150.7 ± 3.7 ms | 71.1 ± 1.8 ms | 29.1 ± 0.5 ms | 2.44× faster |

Home records lower means on **19/19**. Large predicates lead by only 1.06×
and win 29/30 paired rounds. Small predicates and class hierarchy also win
29/30; every other row wins 30/30. Control-flow, small-predicate and class rows
show substantial variance. These observations are not universal or statistically
established leadership: real projects, other platforms and the outstanding
CommonJS/global/owner/diagnostic gaps remain unvalidated. Earlier checkpoints
and their losses stay documented separately.

```sh
HOME_TSC="$PWD/bench/vs_tsgo/results/commonjs-query.hyU20d/release-v1/bin/home-tsc" python3 bench/vs_tsgo/run.py cold --runs 30 --warmup 3
python3 bench/vs_tsgo/compare.py bench/vs_tsgo/results/20260828T234350Z
```

Console/report evidence: `commonjs-query.hyU20d/timing-v1.log` and
`report-v1.md`; unchanged input verification: `corpus-verified-v1.log`.

The independent large-predicate confirmation **`20260828T234818Z`** uses the
same frozen compiler and unchanged admission gates, three warmups and 30
rotating-order rounds. All **30 round files / 90 successful finite samples**
validate. Home has the lower time in **30/30 paired rounds**; the margin is
still modest. This confirmation is separate, not pooled with or substituted
for the full-run row:

| Confirmation workload | TS 6.0.3 | Native TS 7.0.2 | Home | Home vs fastest competitor |
|---|---:|---:|---:|---:|
| `type_predicates_large` | 1111.8 ± 54.4 ms | 388.5 ± 16.7 ms | 358.6 ± 11.7 ms | 1.08× faster |

```sh
HOME_TSC="$PWD/bench/vs_tsgo/results/commonjs-query.hyU20d/release-v1/bin/home-tsc" python3 bench/vs_tsgo/run.py cold --runs 30 --warmup 3 --workload type_predicates_large
python3 bench/vs_tsgo/compare.py bench/vs_tsgo/results/20260828T234818Z
```

The console record is `commonjs-query.hyU20d/confirmation-v1.log`.
`provenance-confirmation.json` verifies that all recorded artifact hashes still
match the pre-measurement snapshot. Raw full-run and confirmation JSON remain
in their separately named directories under `bench/vs_tsgo/results/`.

### Returned imported callable context

Issue [#617](https://github.com/home-lang/home/issues/617), under the pinned
Zod admission issue [#548](https://github.com/home-lang/home/issues/548), fixes
a source-owned contextual-type loss. An annotation such as
`() => errors.$ZodErrorMap` now carries the imported callable interface into a
returned arrow, including both namespace-qualified and direct type imports.
The Program schema proves that the callable parameter's readable keys survive
its homomorphic utility pipeline; it does not special-case Zod, inspect source
spelling, suppress `noImplicitAny`, or expose the projection as a general type.
Unsupported property leaves remain opaque, local names win over imported names,
and a cycle guard bounds recursive declaration lowering.

The focused strict NodeNext reduction uses the same `types.ts`, `consumer.ts`,
and configuration for TypeScript 6.0.3, native TypeScript 7.0.2, and Home. Both
valid imported-factory forms are silent. The deliberately invalid forms retain
the reference diagnostic-code multiset:

| Returned-callable control | TypeScript 6.0.3 | Native TypeScript 7.0.2 | Home before #617 | Home after #617 |
|---|---:|---:|---:|---:|
| Direct and qualified factories reading `issue.code` | 2/2 pass | 2/2 pass | 0/2 (TS7006) | 2/2 pass |
| Unknown `issue.missing` access | TS2339 | TS2339 | not enforced | TS2339 |
| Numeric callback return | TS2322 | TS2322 | not enforced | TS2322 |

The regression also shadows `ErrorMap` locally and performs 32 repeated queries
after clearing the prepared owner's source text. Its node, type, and diagnostic
counts remain unchanged and the owner is not checked. The dedicated TypeScript
Program suite passes **172/172** tests.

The exact real-project A/B uses frozen parent `5ac3860e2`, the final #617 code
and test candidate `c70c49550`, ReleaseFast builds, and the unchanged 106 production
TypeScript files in Zod 4.5.2 `src/v4`. Both compilers receive the same strict,
no-emit, NodeNext project; upstream tests are excluded identically. Two complete
runs per binary produce byte-identical diagnostic output within each arm after
removing only `/usr/bin/time`'s three-line trailer:

| Zod 4.5.2 diagnostic gate | Parent `5ac3860e2` | #617 candidate | Change |
|---|---:|---:|---:|
| All diagnostics | 1,148 | **1,088** | **−60** |
| TS7006 | 443 | **383** | **−60** |
| Every non-TS7006 diagnostic | 705 | 705 | unchanged |
| Added normalized diagnostics | — | **0** | none |
| Wall seconds, runs 1 / 2 | 27.32 / 26.62 | 26.53 / 26.01 | means 26.97 / 26.27 |

The normalized parent output SHA-256 is
`9f707d2c0bf1908bcc7e204864c1aa6c97d8a0688859fb2d75be10fe7905462b`;
the candidate output is
`b25a8ef800e405367139b2e9c383d7aa960bdea889a535cb860fde55cc1116cf`.
The frozen ReleaseFast binaries are respectively
`1aa7ea72a4ae236bf5802648b8ea5ceda71eb4aaba82af43efc992c88d43b1f9`
and `ff57be82352fd70e76c0aa0086b33e026cc73c66491cd0f1368f09c0414bb578`.
The two-run timing sample is recorded for transparency, not admitted as a speed
claim. The graph still emits 1,088 diagnostics, so Zod remains ineligible for
the three-compiler timing table and #548 stays open.

```sh
zig build home-tsc -Doptimize=ReleaseFast
/usr/bin/time -p ./zig-out/bin/home-tsc --project /path/to/zod-4.5.2/tsconfig.benchmark.json
```

### Polymorphic mapped receiver context

Issue [#619](https://github.com/home-lang/home/issues/619), under
[#548](https://github.com/home-lang/home/issues/548) and
[#416](https://github.com/home-lang/home/issues/416), follows the returned
callable work with the mapped prototype argument used by Zod constructors. A
concrete `T[K]` now reads only the selected direct member instead of expanding
the receiver's full recursive graph. Direct overload sets remain intact and
conditional inference uses their final signature. Literal-key indexed chains
at argument boundaries resolve member by member. A selected member containing
polymorphic `this` remains deferred.

For contextual object-literal methods, a missing member can also be projected
through local interface heritage to one exact member of a qualified imported
base. The lookup validates the visible local declaration, walks local bases
with a cycle guard, and lowers only the requested source-owned member in its
generic environment. It does not publish an approximate whole interface,
special-case Zod or method names, infer from source spelling, or suppress
assignment diagnostics.

Two strict four-file reductions cover namespace-qualified and direct imports,
a barrel, a local explicit type argument, a sibling returning polymorphic
`this`, an overloaded mapped method, inherited imported receiver fields, and
deliberately invalid property/return controls. TypeScript **6.0.3**, native
TypeScript **7.0.2**, and Home agree on the diagnostic codes and locations:

| Mapped-receiver control | TypeScript 6.0.3 | Native TypeScript 7.0.2 | Home |
|---|---:|---:|---:|
| Valid contextual parameters, overload tuple and inherited `this` members | pass | pass | pass |
| Unknown parameter property | TS2339 | TS2339 | TS2339 |
| Wrong mapped-method return | TS2322 | TS2322 | TS2322 |

The real-project comparison uses exact parent `77deef967`, the #619 candidate,
ReleaseFast builds, and the unchanged 106 production files selected by
`tsconfig.benchmark.json` from pinned Zod **4.5.2**. Both binaries run from the
same extracted graph with strict checking, no emit, and identical exclusions.
Diagnostic identities normalize to `path:line:column:code`; timing removes only
the `/usr/bin/time` trailer. No result or sample is filtered.

| Zod 4.5.2 exact-parent A/B | Parent `77deef967` | #619 candidate | Change |
|---|---:|---:|---:|
| All diagnostics | 1,088 | **976** | **−112** |
| Added normalized diagnostics | — | **0** | none |
| Removed normalized diagnostics | — | **112** | toward the TS 6 zero-diagnostic oracle |
| Wall seconds, runs 1 / 2 | 9.28 / 10.57 | **6.00 / 5.48** | both candidate runs lower |
| Mean wall time | 9.925 s | **5.740 s** | **42.2% lower** |

An additional exact-parent run under the final machine load took 9.95 seconds.
The two candidate runs produced byte-identical normalized diagnostic sets. This
is a same-correctness Home A/B, not a cross-compiler Zod speed claim: Home still
emits 976 diagnostics while TypeScript 6.0.3 emits zero, so Zod remains outside
the admitted three-compiler timing table.

The final source passes Program **172/172**, checker **4,334/4,334**,
`git diff --check`, and scoped `pickier` on both changed Zig files. The
repository-wide `pickier` command remains red on pre-existing vendored and
upstream findings. Full commands and normalized-set evidence are recorded in
[#619](https://github.com/home-lang/home/issues/619#issuecomment-5546027783).

```sh
zig build home-tsc -Doptimize=ReleaseFast
/usr/bin/time -p ./zig-out/bin/home-tsc --project /path/to/zod-4.5.2/tsconfig.benchmark.json
```

### Mapped prototype parameter tuples and contextual receivers

Issue [#624](https://github.com/home-lang/home/issues/624), under
[#548](https://github.com/home-lang/home/issues/548) and
[#416](https://github.com/home-lang/home/issues/416), continues the exact Zod
admission audit after #619. The failing shape is a conditional `ProtoOf<T>`
mapped over a constructor prototype: its selected methods must retain optional,
generic, and rest parameter tuples, while object-literal implementations must
still receive the concrete polymorphic `this` type.

The fix preserves signature-level contextual-receiver metadata through mapped
materialization and substitution, carries source-member declaration provenance,
and re-lowers the declared return in the interface and method type-parameter
environment. A return accepted through the ordinary object relation is retained
only when the inferred implementation return is the contextual receiver and the
explicit receiver arguments satisfy the declaration's variance. This is a
general declaration-backed proof: it does not inspect Zod source spelling or
method names, and it does not suppress a failed primary relation.

The strict four-file Program reduction covers optional parameters, generic
parameters and defaults, rest tuples, overloads, inherited prototype members,
and polymorphic receiver returns. It also keeps six deliberate failures: five
TS2322 assignability controls (including primitive, unrelated-generic, and
narrower-intersection returns) plus one TS2339 missing-property control. TS7006,
TS7019, TS2349, TS2304, TS2493, and TS2532 remain absent from the valid paths.
A separate pinned TypeScript 5.9.2 oracle probe accepts the valid classic-schema
shape and rejects the invalid return controls.

The real-project diagnostic comparison uses exact parent `ad4ae6291`, final
semantic candidate `babca3e64`, ReleaseFast builds, and the unchanged 106
production files selected by `tsconfig.benchmark.json` from pinned Zod 4.5.2.
Both binaries run from the same extracted tree with the same strict, no-emit
configuration. Diagnostic identities normalize to `path:line:column:code`.

| Zod 4.5.2 exact-parent diagnostic A/B | Parent `ad4ae6291` | #624 `babca3e64` | Change |
|---|---:|---:|---:|
| All diagnostics | 976 | **833** | **−143 (14.7%)** |
| TS7006 removed | — | **127** | contextual parameters restored |
| TS7019 removed | — | **16** | rest parameters restored |
| Added normalized diagnostics | — | **0** | none |

Three alternating transparency samples took 4.38 / 4.43 / 4.36 seconds for
the parent and 5.22 / 5.14 / 5.05 seconds for the semantic candidate: medians
4.38 and 5.14 seconds, respectively. That 17.4% increase is not admitted as a
speed comparison because the candidate performs different, more complete type
checking. It is recorded so the correctness improvement does not hide its cost.

A separate performance-only probe moved the contextual-receiver proof behind
ordinary signature and return checks. Before/after outputs were byte-identical
at 833 diagnostics. Ten counterbalanced AB/BA pairs gave medians of 5.26 seconds
before and 5.36 seconds after; the reorder won only 3/10 pairs. The probe was
therefore rejected and removed rather than shipped as an optimization.

The final source passes Program **174/174**, checker **4,334/4,334**, ReleaseFast
`home-tsc`, `zig fmt`, and `git diff --check`. Scoped `pickier` covers this
Markdown record. Full evidence and issue progress are linked from
[#624](https://github.com/home-lang/home/issues/624).

The raw parent and candidate diagnostic SHA-256 values are
`6a84880a00f1e22816610e546a964e5e5ce88e78b2e1baefcc9c7c461a699c8a` and
`94ecd8b025e5248c1ab3f84d32ae560eaabf3119c5e7e844c654fbe0f740b6d5`.
The normalized diagnostic-key hashes are
`c3effc18a013210ee3f0129e6f4aa10e609d6dedf9276c4e9f2cc52ac921fc7b` and
`6bbfaf9ca1acef7e056c09def0d162daab7fd918f324deaadecf11eed9f331b3`.
The frozen ReleaseFast binary hashes are
`0b74892a0b7acad79bdc6380cc5c4a0e990aa52b8b0e7e2c7144a5a26bb29a98` and
`d0b2a9c3cdf37aaee5412212e0b569b32c064f5775ca2855574de26b8ebe84ad`.

```sh
zig build home-tsc -Doptimize=ReleaseFast
./zig-out/bin/home-tsc --project /path/to/zod-4.5.2/tsconfig.benchmark.json
```

### Imported graph ownership completion (untimed)

Issue [#487](https://github.com/home-lang/home/issues/487), under the
correctness and performance tracker
[#416](https://github.com/home-lang/home/issues/416), completes the owner
semantics required by the timed import and re-export graphs. Commit
[`e24967873`](https://github.com/home-lang/home/commit/e24967873) preserves
imported rest-tuple call contracts. Commit
[`0660cd590`](https://github.com/home-lang/home/commit/0660cd590) retains the
base reference and the source-owned body of inherited nominal classes, so
private and protected ownership remains nominal across direct and barrel
imports. Commit
[`a572f3acd`](https://github.com/home-lang/home/commit/a572f3acd) prevents a
function-local interface from merging with a same-named top-level interface
while preserving legitimate namespace and module declaration merging.

The graph type audit covers 12 declaration families, five import placements,
both app orders, and positive/negative variants. Every project is compiled by
all three pinned compilers, so its 240 logical cases produce 720 process
checks. The adjacent audits independently verify graph discovery, export
origin ambiguity, generic/rest/readonly imported owners, and direct/inherited
private and protected nominal origins.

| Untimed owner audit | TypeScript 6.0.3 | Native TypeScript 7.0.2 | Home | Total process checks |
|---|---:|---:|---:|---:|
| Graph type ownership | 240/240 | 240/240 | **240/240** | 720/720 |
| Graph discovery | 28/28 | 28/28 | **28/28** | 84/84 |
| Export origins | 32/32 | 32/32 | **32/32** | 96/96 |
| Imported owners | 20/20 | 20/20 | **20/20** | 60/60 |
| Nominal origins | 52/52 | 52/52 | **52/52** | 156/156 |

These are rejection controls, not throughput samples. No diagnostic is waived,
and invalid cases append only the targeted misuse to their matching positive
program. The complete ReleaseFast checker and Program suites pass on the final
source, along with the version-pinned workload admission gate.

### CommonJS and qualified-projection performance recovery

The full-suite readmission after typed global ownership deliberately exposed
two independent regressions. Issue
[#651](https://github.com/home-lang/home/issues/651) found that CommonJS
providers were being published as script globals, causing every provider owner
to be relocated into every peer compilation. On the unchanged 128-owner
positive graph, the then-current `a572f3acd` remained CPU-active for more than
seven minutes and reached about 7 GiB during sampling. Every worker was in
`Program.importProgramGlobals`. Commit
[`d0b9ef0aa`](https://github.com/home-lang/home/commit/d0b9ef0aa) classifies
whole exports, property exports, and `Object.defineProperty` exports as modules
before global publication, while preserving script semantics when `module`,
`exports`, or `Object` is locally shadowed. A loaded-host diagnostic run then
completed in 0.22 seconds at about 35 MiB peak. Those single runs classify the
algorithmic fault and fix; they are not comparative benchmark claims.

The first complete 30-round schema-3 screen after that fix, result
`20260905T223009Z`, retained all samples and honestly reported only **17/20**
lower Home means. Its CommonJS row was restored and won at 33.4 ± 3.3 ms versus
57.0 ± 4.0 ms for native TS 7, but three script-heavy rows lost:

| Rejected-as-final discovery screen | Native TS 7.0.2 | Home | Result |
|---|---:|---:|---:|
| `null_safe_access` | **67.1 ± 7.7 ms** | 77.4 ± 5.6 ms | Home 1.15× slower |
| `type_predicates` | **77.2 ± 3.2 ms** | 96.7 ± 9.5 ms | Home 1.25× slower |
| `type_predicates_large` | **431.8 ± 120.8 ms** | 4875.7 ± 790.3 ms | Home 11.29× slower |

Issue [#652](https://github.com/home-lang/home/issues/652) profiled the exact
106,496-line large-predicate project. About 85% of samples were in
`programQualifiedIndexedAssertionDestructuredArrayType`: an imported-array
recovery fallback scanned the complete HIR for ordinary member reads even when
the receiver already had a concrete type. Commit
[`e4e9d16c2`](https://github.com/home-lang/home/commit/e4e9d16c2) limits that
fallback to its intended unresolved `any` receiver. A permanent regression
also proves that a prior projected destructuring name cannot override a known,
same-named local object.

A diagnostic before/after on the unchanged large project fell from
82,408,298,769 to 3,092,449,057 retired instructions, **26.6× fewer**. The
corresponding loaded-host single runs were 4.49 and 0.63 seconds and remain
diagnostic evidence only. The admitted targeted result `20260905T225340Z`
then recorded Home at **290.6 ± 53.1 ms** versus native TS 7 at
456.4 ± 40.8 ms, a **1.57×** Home lead across all 30 rounds.

The final complete result `20260905T225537Z`, reported in the
[current snapshot](#current-snapshot), passed every positive and exact negative
admission control before timing. Home has the lower mean on **20/20** rows and
the lower paired time in **600/600** rounds. The narrowest mean lead is
**1.60×** on `type_predicates_large`; `commonjs_graph` leads by **1.87×**.
The final Home executable SHA-256 is
`d13449766d7496dd8e1232bd6103c20a6b6b37f3e0450f7f877c0f03b78124d7`.

All final untimed matrices pass without exclusions: graph types **720/720**,
graph discovery **84/84**, export origins **96/96**, imported owners **60/60**,
nominal origins **156/156**, globals **180/180**, bound globals **168/168**,
CommonJS types **198/198**, and CommonJS discovery **132/132**. Issue
[#653](https://github.com/home-lang/home/issues/653) updates the structural
export-list harness expectations to its existing 128-case design; the audit
passes **384/384** and all **95/95** benchmark harness tests pass. No benchmark
input, compiler oracle, diagnostic expectation, workload name, identifier, or
family count is special-cased by either performance fix.

```sh
python3 bench/vs_tsgo/run.py cold --runs 30 --warmup 3
python3 bench/vs_tsgo/run.py report bench/vs_tsgo/results/20260905T225537Z
python3 bench/vs_tsgo/audit_graph_types.py
python3 bench/vs_tsgo/audit_owners.py
python3 bench/vs_tsgo/audit_nominal_origins.py
python3 bench/vs_tsgo/audit_commonjs.py
python3 bench/vs_tsgo/audit_commonjs_discovery.py
python3 -m unittest discover -s bench/vs_tsgo -p 'test_*.py'
```

### Generic member-assigned callback context

Issue [#627](https://github.com/home-lang/home/issues/627), under
[#548](https://github.com/home-lang/home/issues/548) and
[#416](https://github.com/home-lang/home/issues/416), continues the frozen Zod
4.5.2 admission audit after #624. The isolated shape is a callback passed to a
generic constructor that assigns another callback through a nested member such
as `inst._zod.processJSONSchema`. The constructor's type argument may be
explicit or supplied by the receiving variable annotation, and the leaf member
may be an optional `function | undefined` union.

The checker now recovers that concrete call-site type argument, projects only
the requested local/imported member path, and follows Program-schema heritage
in contextual mode. Unsupported generic siblings become opaque only during the
isolated traversal; no approximate whole interface is published. A projected
signature is accepted only when it is unambiguous, has no free type parameters,
and returns `void`. Failed speculative projections roll back their own
diagnostics. Contextual return diagnostics also copy object-member storage
before inference can grow and relocate the interner pool.

The focused checker reductions cover annotation-inferred and explicit type
arguments, an optional callable union, an unsupported `Set` sibling, an
ambiguous callable-union control, a missing-property control, and stable member
iteration during contextual return inference. The cross-file Program reduction
adds an imported `DateInternals<Date>` heritage chain with the same two
provenance modes. TypeScript 6.0.3 and native TypeScript 7.0.2 both accept the
valid oracle paths, report TS2339 and TS2322 for the deliberate invalid paths,
and retain TS7006 for the ambiguous union.

The production comparison uses exact parent `4deb785cc`, semantic candidate
`d846dbe1b`, ReleaseFast `home-tsc` builds, and the unchanged 106 production
files selected by the pinned Zod 4.5.2 `tsconfig.benchmark.json`. Diagnostic
identities normalize to `path:line:column:code:message`. This is an untimed
correctness gate; the one candidate execution is not presented as a speed
comparison because no counterbalanced same-parent timing pair was collected.

| Zod 4.5.2 exact-parent diagnostic A/B | Parent `4deb785cc` | #627 `d846dbe1b` | Change |
|---|---:|---:|---:|
| All diagnostics | 833 | **710** | **−123 (14.8%)** |
| TS7006 | 241 | **118** | **−123 (51.0%)** |
| Added normalized diagnostics | — | **0** | none |

All 123 removed identities are the three implicit parameters on the 41
`processJSONSchema` assignments selected in #627; no other diagnostic identity
changed. The final source passes Program **175/175**, the full checker suite,
ReleaseSafe and ReleaseFast `home-tsc`, `zig fmt`, and `git diff --check`.

The raw parent and candidate diagnostic SHA-256 values are
`94ecd8b025e5248c1ab3f84d32ae560eaabf3119c5e7e844c654fbe0f740b6d5` and
`a32aa20198a39a7f89c3e2353ceff0850bb7b7c35a20d49e674a633ef7fed93e`.
The normalized diagnostic-key hashes are
`adc0a1ef5e90ac1bc4417cab81b140583e14160b1d00c42230d250087ef087d4` and
`e3a14e0141bdb1e24c10606d5fe79b2261b35198844bbbb0b30e7831c10a718a`.
The candidate ReleaseFast binary hash is
`04a2de299a5ea84629d7490267300de231805bb001c657cebe7fd5699c368f1f`.

```sh
zig build home-tsc -Doptimize=ReleaseFast
./zig-out/bin/home-tsc --project /path/to/zod-4.5.2/tsconfig.benchmark.json
```

### Dependent generic defaults

Issue [#633](https://github.com/home-lang/home/issues/633), under the Zod
admission issue [#548](https://github.com/home-lang/home/issues/548) and
correctness tracker [#416](https://github.com/home-lang/home/issues/416),
continues from #627's frozen 710-diagnostic baseline. A later generic default
is now instantiated in declaration order with every earlier effective
argument. For example, `Family<T = unknown, U = Box<T>>` resolves `U` to
`Box<unknown>` for `Family` and `Box<number>` for `Family<number>`, rather than
leaving the declaration's `T` free inside `U`. The same helper drives all four
existing default-fill sites.

The supporting semantic fixes remain general: `every` and `some` callbacks
accept truthy non-boolean returns like current `lib.d.ts`; unconstrained type
parameters relate to `unknown` in interface heritage; narrowed nullable unions
retain `any`; nested member-assigned callbacks can use non-void contextual
signatures without rechecking their bodies outside the original flow state;
speculative contextual diagnostics always roll back; provisional iterator
diagnostics are reconciled after contextual checking; and overload
applicability snapshots borrowed signature parameters before recursive
interning. Constraint checking also verifies an object constraint against each
target-union branch and uses visible interface declaration identity only when
the source property's generic interface explicitly extends the target
property's declaration. No Zod symbol or member name is special-cased.

The focused strict reduction covers bare and partially supplied defaults, a
valid generic argument whose constraint reaches one object-union branch, and
three invalid controls: a concrete missing object shape, a scalar constraint,
and a nested unrelated object constraint. TypeScript 6.0.3, native TypeScript
7.0.2, and Home agree on every accepted and rejected location. TypeScript 7
uses TS2741 rather than TS2344 for the concrete missing-property control; the
semantic outcome is the same.

| Dependent-default control | TypeScript 6.0.3 | Native TypeScript 7.0.2 | Home |
|---|---:|---:|---:|
| Bare and partially supplied dependent defaults | pass | pass | pass |
| Declaration-backed object-union constraint | pass | pass | pass |
| Concrete missing object shape | TS2344 | TS2741 | TS2344 |
| Invalid scalar and nested constraints | 2× TS2344 | 2× TS2344 | 2× TS2344 |

The real-project gate uses frozen parent `2de0edbc9`, the final #633 source,
ReleaseFast builds, and the unchanged 106 production files selected by the
pinned Zod 4.5.2 `tsconfig.benchmark.json`. Both arms use the same strict,
no-emit configuration. Diagnostic identities normalize to the complete sorted
`path:line:column - error TS code` set; no diagnostic, file, or sample is
filtered.

| Zod 4.5.2 dependent-default audit | Frozen post-#627 parent | #633 candidate | Change |
|---|---:|---:|---:|
| All diagnostics | 710 | **604** | **−106 (14.9%)** |
| TS2430 | baseline | **67 removed** | invalid interface-extension cascades removed |
| TS2345 | baseline | **21 removed** | valid constructor arguments restored |
| TS7006 | baseline | **18 removed** | contextual parameters restored |
| Added normalized diagnostics | — | **0** | none |
| Wall seconds, runs 1 / 2 | — | 23.46 / 22.97 | transparency only |

TypeScript 6.0.3 reports zero diagnostics on this frozen graph, so Zod remains
outside the admitted cross-compiler timing table. The two candidate timings
are recorded only for transparency: no counterbalanced same-semantics timing
A/B was collected, and #633 intentionally performs more correct checking.

The frozen configuration SHA-256 is
`bc11625162272f50c164dd7fb9a245c15870692c5d6d275df72de36369014a70`.
The sorted baseline diagnostic-key hash is
`937b52579d8bc1fed1eafd7f649c9081fa272aac65331f0fde87d7f6569482dd`;
both candidate runs produce
`b1507875d4327b4df2dce0fed41123d3d409d8f85aca7b05fcaf6d3777c29210`.
The final ReleaseFast binary hash is
`e0b666a06f0f11736406a6fb11cee7ab4769d052675abc947bf7cdcdfeda3f3d`.

The final source passes the focused TypeScript oracle, the full **4,346-test**
checker suite in Debug, ReleaseSafe, and ReleaseFast, the TypeScript Program
suite, `zig fmt`, and `git diff --check`. Symbolic indexed-access defaults are
tracked separately in [#634](https://github.com/home-lang/home/issues/634).
The recursive generic fixed-point limitation found during negative-control
validation is recorded with its TypeScript 6/7 oracle in
[#639](https://github.com/home-lang/home/issues/639); it was not hidden by a
global diagnostic exception or proof-time declaration re-lowering.

```sh
zig build test -Dfilter=ts_checker
zig build test -Dfilter=ts_checker -Doptimize=ReleaseSafe
zig build test -Dfilter=ts_checker -Doptimize=ReleaseFast
zig build test -Dfilter=ts_program
zig build home-tsc -Doptimize=ReleaseFast
./zig-out/bin/home-tsc --project /path/to/zod-4.5.2/tsconfig.benchmark.json
```

### Symbolic indexed-access generic defaults

Issue [#634](https://github.com/home-lang/home/issues/634), under
[#548](https://github.com/home-lang/home/issues/548) and
[#416](https://github.com/home-lang/home/issues/416), separates a second kind
of dependent default from #633. A default such as
`D = T["state"]["definition"]` previously resolved through `T`'s constraint
while its declaration was lowered. That permanently stored the base
definition and prevented `Constructor<UserSchema>` from recovering
`UserSchema["state"]["definition"]`.

The checker now scopes default lowering explicitly. Any indexed-access graph
that still contains a declaration type parameter is retained as existing
interned TypeIds. #633's declaration-order substitution later replaces the
earlier effective arguments and the normal indexed-access reducer selects the
concrete members. No syntax node or declaration HIR is stored, revisited, or
re-lowered at a use site, and ordinary indexed accesses outside parameter
defaults keep their existing eager behavior.

The strict same-file oracle covers bare defaults, partial application,
explicit override, a valid nested projection, and three invalid controls.
TypeScript 6.0.3, native TypeScript 7.0.2, and Home agree on every accepted and
rejected location. The compilers differ only in whether the missing `id`
argument is expressed as TS2345 or TS2741.

| Indexed-default control | TypeScript 6.0.3 | Native TypeScript 7.0.2 | Home |
|---|---:|---:|---:|
| Bare, partial, explicit, and nested valid uses | pass | pass | pass |
| Object argument missing `id` | TS2345 | TS2741 | TS2741 |
| Invalid primitive assignment | TS2322 | TS2322 | TS2322 |
| Invalid unrelated object assignment | TS2741 | TS2741 | TS2741 |

A two-file Program reduction exports the generic declaration and imports it
into a consumer that owns the concrete schema. The valid bare and partial
uses remain accepted across the serialized declaration boundary, while the
same three invalid locations remain rejected.

The production gate compares current post-#633 main `c5c3fd009` with the #634
candidate on the unchanged 106 production files selected by the pinned Zod
4.5.2 strict, no-emit configuration. Complete diagnostic identities normalize
to the sorted `path:line:column - error TS code` set; no diagnostic, file, or
sample is filtered.

| Zod 4.5.2 symbolic indexed-default audit | Post-#633 main | #634 candidate | Change |
|---|---:|---:|---:|
| All diagnostics | 604 | **604** | **0** |
| Normalized diagnostic identities | 604 | **604** | **0 added; 0 removed** |
| Final candidate wall seconds | — | 23.02 | transparency only |

Both sides have normalized diagnostic-key SHA-256
`b1507875d4327b4df2dce0fed41123d3d409d8f85aca7b05fcaf6d3777c29210`.
The final candidate ReleaseFast binary SHA-256 is
`0ae28e7b700ac0effb7e6ec6ee7012ee23bc9387077a61d123bdc3260d4de163`.
The single final-artifact timing is not a counterbalanced same-semantics A/B,
so it is not admitted as a speed comparison.

The final source passes the focused oracle, the full **4,347-test** checker
suite in Debug, ReleaseSafe, and ReleaseFast, the complete Program suite,
`zig fmt`, scoped `pickier`, and `git diff --check`. Recursive generic default
fixed points remain separately tracked in
[#639](https://github.com/home-lang/home/issues/639).

```sh
zig build test -Dfilter=ts_checker
zig build test -Dfilter=ts_checker -Doptimize=ReleaseSafe
zig build test -Dfilter=ts_checker -Doptimize=ReleaseFast
zig build test -Dfilter=ts_program
zig build home-tsc -Doptimize=ReleaseFast
./zig-out/bin/home-tsc --project /path/to/zod-4.5.2/tsconfig.benchmark.json
```

### Recursive generic-default fixed points

Issue [#639](https://github.com/home-lang/home/issues/639), under the Zod
admission issue [#548](https://github.com/home-lang/home/issues/548) and
correctness tracker [#416](https://github.com/home-lang/home/issues/416),
closes the recursive fixed-point gap separated from #633 and #634. A fully
defaulted interface such as
`Type<O = unknown, S extends State<O> = State<O>>` can refer back to `Type`
through `State<O>`'s base. The first recursive interface pass previously kept
the provisional `unknown` constraint/default payloads even after the
self-recheck had completed them. Constraint checking then treated the retained
declaration parameter as a genuinely free use-site parameter and deferred a
decidable mismatch.

The checker now refreshes the original stable parameter identities from the
completed self-recheck with the existing cycle-pruned substitution walk. A
separate closure walk replaces only parameters proven to belong to another
declaration and to have a stored default. Parameters owned by the current HIR
declaration, parameters without defaults, and parameters with unknown
provenance remain unresolved. Imported Program declarations carry the same
ownership provenance explicitly because their source nodes do not belong to
the consumer HIR. Substituted objects retain interface identity, Program
display identity, readonly index state, array origin, and tuple origin. No HIR
syntax is stored or re-lowered at the proof site, and free-parameter deferral
is not globally disabled.

The strict focused oracle includes the original valid default, a concrete
invalid argument, a constrained invalid argument, and readonly-array controls.
The same semantic cases also cross a two-file Program boundary. A separate
checker-internal control proves that the closure walk still leaves a genuinely
owner-local parameter unresolved. Fresh runs of the harness-pinned TypeScript
6.0.3 and native TypeScript 7.0.2 compilers differ only in the diagnostic
family for the concrete missing-property case.

| Recursive-default control | TypeScript 6.0.3 | Native TypeScript 7.0.2 | Home |
|---|---:|---:|---:|
| Fully defaulted valid `Good` | pass | pass | pass |
| Concrete invalid `Tuple<{ nope: number }>` | TS2344 | TS2741 | TS2344 |
| Constrained invalid `Tuple<R>` with `R extends WrongShape` | TS2344 | TS2344 | TS2344 |
| Readonly recursive-default controls | pass | pass | pass |

The checker-internal owner-local control remains unresolved as designed; it
does not represent a standalone TypeScript source diagnostic and is therefore
not included as a cross-compiler row.

The real-project gate compares exact post-#634 parent `773af2405` with semantic
candidate `7d7cf23f8`. Both ReleaseFast binaries check the unchanged 106
production files selected by the pinned Zod 4.5.2 strict, no-emit
`tsconfig.benchmark.json`. Complete diagnostic identities normalize to the
sorted `path:line:column - error TS code` set after removing only the common
absolute corpus prefix. No diagnostic, file, code, or sample is filtered.

| Zod 4.5.2 recursive-default audit | Post-#634 parent | #639 candidate | Change |
|---|---:|---:|---:|
| All diagnostics | 604 | **600** | **4 removed (0.7%)** |
| TS2345 at the four recursive constructor sites | 4 | **0** | **4 removed** |
| Added normalized diagnostics | — | **0** | none |
| Wall seconds, one run per arm | 25.24 | 25.05 | transparency only |

The removed identities are
`src/v4/core/schemas.ts:4395:77`, `:4397:53`, `:4401:77`, and `:4403:53`, all
TS2345. The parent normalized identity SHA-256 is
`b1507875d4327b4df2dce0fed41123d3d409d8f85aca7b05fcaf6d3777c29210`;
the candidate hash is
`f093515438ca8b68df2a1fea133f3e247d21574900579902513adac4636ecfe2`.
The final candidate ReleaseFast binary SHA-256 is
`a201e6d7c5c20f046a9b591ef43d8c47f9679653981d61027d6340fd5ebaab80`.
One run per arm is insufficient for a speed claim, so the wall times are not
admitted to the cross-compiler performance table.

An earlier candidate artifact was rejected after the complete identity diff
found three added readonly-to-mutable TS2344 diagnostics. That audit exposed
missing readonly side metadata in the bounded object substitution path; the
general metadata propagation fix and readonly controls removed all three.
The accepted final artifact has zero added identities.

The final source passes the focused checker and Program reductions plus the
complete checker and Program suites in Debug, ReleaseSafe, and ReleaseFast.
End-to-end compile-and-test validation times were 266.98/57.88 seconds,
173.84/163.88 seconds, and 170.59/178.43 seconds, respectively. These timings
describe verification cost, not frontend throughput. `zig fmt`, scoped
`pickier`, and `git diff --check` complete the source gates.

```sh
zig build test -Dfilter=ts_checker
zig build test -Dfilter=ts_program
zig build test -Dfilter=ts_checker -Doptimize=ReleaseSafe
zig build test -Dfilter=ts_program -Doptimize=ReleaseSafe
zig build test -Dfilter=ts_checker -Doptimize=ReleaseFast
zig build test -Dfilter=ts_program -Doptimize=ReleaseFast
zig build home-tsc -Doptimize=ReleaseFast
./zig-out/bin/home-tsc --project /path/to/zod-4.5.2/tsconfig.benchmark.json
```

### Explicit-file CLI boolean integrity

Issue [#645](https://github.com/home-lang/home/issues/645) was isolated while
refreshing the pinned compiler oracle for #639. The generic unknown-option
heuristic treated the source path after `--skipLibCheck` or `--ignoreConfig`
as a possible option value. That produced an empty positional file list,
switched the invocation into repository-project discovery, and eventually
exited 139 while checking the wrong graph. The exact post-#639 parent and the
[#645](https://github.com/home-lang/home/issues/645) candidate use the same
two-line valid source and nearby config; there is no timeout, path filtering,
or reduced project substituted for the failing command.

Commit [`d318b0c28`](https://github.com/home-lang/home/commit/d318b0c2801d40c5d581ebd8726508de055f8200)
gives both flags typed boolean storage. A present flag defaults to `true`, an
immediately following `true` or `false` is consumed, and every other following
argument remains positional. `ignoreConfig` suppresses config discovery only
when explicit files are present; with no files, the nearby project still
loads. `skipLibCheck` overrides the config in either direction. Declaration
files remain bound and checked so their resolved metadata survives the driver
pass, while their semantic diagnostics are omitted at the diagnostic boundary.
Lexer and parser diagnostics remain visible.

The strict oracle contains a valid `entry.ts`, a referenced declaration file
with an unresolved `MissingType`, and a nearby config whose only root has a
TS2322 error. Fresh harness-pinned TypeScript 6.0.3 and native TypeScript 7.0.2
runs establish the expected outcomes. TypeScript's different nonzero exit
codes are not normalized into semantic results.

| Explicit-file control | TypeScript 6.0.3 | Native TypeScript 7.0.2 | Post-#639 parent | #645 candidate |
|---|---:|---:|---:|---:|
| `--ignoreConfig entry.ts` | TS2304 | TS2304 | exit 139 | TS2304 |
| `--ignoreConfig --skipLibCheck entry.ts` | pass | pass | exit 139 | pass |
| explicit `true` for both flags | pass | pass | exit 139 | pass |
| `--ignoreConfig --skipLibCheck false entry.ts` | TS2304 | TS2304 | exit 139 | TS2304 |
| `--ignoreConfig` with no files | config TS2322 | config TS2322 | config TS2322 | config TS2322 |
| malformed declaration with `skipLibCheck` | syntax error | syntax error | exit 139 | syntax error |

Issue [#486](https://github.com/home-lang/home/issues/486) closes the
complementary absent-`ignoreConfig` branch. Like TypeScript 6.0.3 and native
TypeScript 7.0.2, Home now searches upward for the nearest `tsconfig.json` when
positional files are present. If one exists, Home reports byte-identical TS5112
and exits 1 without loading the config. Explicit `--ignoreConfig` skips that
search; a positional file with no discoverable config still compiles normally.
The existing TS5042 check keeps precedence for `-p` mixed with positional files,
and normal `-p` loading is unchanged.

The oracle below is untimed CLI correctness evidence, not a throughput
benchmark. Every compiler receives the same files, working directory, and
arguments. The Home parent is the frozen source-matched binary with SHA-256
`bfba4f9e94731d4e9639094e53fea1e707fd1c4c160157474ee2de86ba1275b3`;
the candidate binary has SHA-256
`2ab2f15d4ef0a2aef5675ffbf911a8a8612f29e2b9132860c29f88d02119db0d`.

| Positional-config control | TypeScript 6.0.3 | Native TypeScript 7.0.2 | Frozen Home parent | #486 candidate |
|---|---:|---:|---:|---:|
| nearby config + `entry.ts` | TS5112, exit 1 | TS5112, exit 1 | pass | **TS5112, exit 1** |
| nearby config + `--ignoreConfig entry.ts` | pass | pass | pass | **pass** |
| no config + `entry.ts` | pass | pass | pass | **pass** |
| `-p tsconfig.json entry.ts` | TS5042 | TS5042 | TS5042 | **TS5042** |
| `-p tsconfig.json` | pass | pass | pass | **pass** |

The guarded ReleaseSafe build peaked at 2,820 MB and the focused `ts_cli` test
target passed at 272 MB, both below the fixed 3,840 MB process-tree ceiling.

The complete post-#639 Zod 4.5.2 graph is also checked unchanged with exact
parent `df4dff88f` and candidate ReleaseFast binaries. Diagnostic identities
normalize to the sorted `path:line:column - error TS code` set after removing
only the common absolute corpus prefix. No file, diagnostic code, or sample is
filtered.

| Zod 4.5.2 CLI-option audit | Post-#639 parent | #645 candidate | Change |
|---|---:|---:|---:|
| All diagnostics | 600 | **600** | **0 added; 0 removed** |
| Normalized identity SHA-256 | `f093…fe2` | `f093…fe2` | identical |
| Wall seconds, one run per arm | 27.49 | 25.83 | transparency only |

The full identity SHA-256 for both arms is
`f093515438ca8b68df2a1fea133f3e247d21574900579902513adac4636ecfe2`.
The exact parent binary SHA-256 is
`1acadca6b41f3f9a17dbd3b3d883a55810bf806a9db2699e7997a7c42a136390`;
the candidate binary SHA-256 is
`26ce61627370b68e8a5ef27d88f425c24efa2f24ad2df25fad15377c852b29dd`.
One run per arm is insufficient for a speed claim, so these wall times are not
admitted to the cross-compiler performance table.

The source gates include focused parser, config-decision, and driver controls
plus the complete CLI, driver, and Program suites in Debug, ReleaseSafe, and
ReleaseFast. Their respective end-to-end compile-and-test times were
3.00/27.75/56.44 seconds, 12.66/171.49/155.22 seconds, and
10.14/169.95/198.30 seconds. These are verification costs, not frontend
throughput measurements. `zig fmt`, scoped `pickier`, and `git diff --check`
complete the changed-file gates.

```sh
zig build test -Dfilter=ts_cli
zig build test -Dfilter=ts_driver
zig build test -Dfilter=ts_program
zig build test -Dfilter=ts_cli -Doptimize=ReleaseSafe
zig build test -Dfilter=ts_driver -Doptimize=ReleaseSafe
zig build test -Dfilter=ts_program -Doptimize=ReleaseSafe
zig build test -Dfilter=ts_cli -Doptimize=ReleaseFast
zig build test -Dfilter=ts_driver -Doptimize=ReleaseFast
zig build test -Dfilter=ts_program -Doptimize=ReleaseFast
zig build home-tsc -Doptimize=ReleaseFast
./zig-out/bin/home-tsc --ignoreConfig --noEmit --skipLibCheck entry.ts
./zig-out/bin/home-tsc --project /path/to/zod-4.5.2/tsconfig.benchmark.json
```

### Inherited generic members and loop-flow narrowing

Issues [#534](https://github.com/home-lang/home/issues/534) and
[#654](https://github.com/home-lang/home/issues/654), under the pinned Zod
admission issue [#548](https://github.com/home-lang/home/issues/548), close a
related set of exact type-information losses. Commit
[`197ee079f`](https://github.com/home-lang/home/commit/197ee079f) preserves
generic substitutions while following imported interface heritage, resolves
inherited members across union and intersection constituents, and lowers an
explicitly requested member through a qualified recursive alias even when an
unrelated leaf of the complete object is not yet representable. The lookup is
declaration-backed and member-specific; it does not approximate the whole
object, depend on an identifier spelling, or suppress a diagnostic.

The same commit centralizes the builtin object-name contract used by the
checker and Program schema, including `RegExp`, and transports those exact
objects across compilation boundaries. Concrete nested indexed accesses are
reduced only after their object no longer contains a free type parameter.
Interface data-property overrides use the ordinary structural assignability
relation, which already models recursive generic objects, conditional and
indexed projections, and declared variance. Callable properties remain on the
dedicated heritage path so strict function and method-bivariance behavior is
unchanged. A full-suite regression found and prevented a draft union fallback
from reconstructing properties across distinct private or protected
declarations; only public direct constituents can participate when an
inherited union member is completed.

Commit [`2e749f76c`](https://github.com/home-lang/home/commit/2e749f76c)
completes the control-flow side. `for..in` and `for..of` bindings now enter the
same narrowable-value analysis as ordinary lexical bindings, and an `if`
branch ending in `continue` or `break` applies its false guard to the reachable
fallthrough. Negative member guards read the current narrowed receiver and
use union-aware member projection. Subtracting a unit literal removes only
that unit; for example, rejecting `"__proto__"` from `string | symbol` does
not incorrectly remove the entire `string` constituent.

The focused sources are ordinary strict TypeScript reductions. TypeScript
6.0.3 and native TypeScript 7.0.2 both accept the recursive generic heritage
and post-`continue` for-of cases with zero diagnostics, and Home now does the
same. A two-file Program reduction verifies inherited generic defaults and
union projections across a serialized declaration boundary. Another
reduction imports the real recursive JSON-schema alias and projects only its
`type` member; it is also clean.

The production audit checks the unchanged 106 files selected by the pinned
Zod 4.5.2 strict, no-emit configuration. The immutable pre-change output has
602 diagnostics and 597 unique `path:line:column:TS-code` identities. The
ReleaseFast binaries run the complete graph without file, code, diagnostic,
or path filtering.

| Zod 4.5.2 inherited-member and flow audit | Pre-change main | `197ee079f` + `2e749f76c` | Change |
|---|---:|---:|---:|
| All diagnostics | 602 | **523** | **79 removed (13.1%)** |
| Unique diagnostic identities | 597 | **518** | **79 removed; 0 added** |
| TS2345 | — | 206 | remaining, not timed |
| TS7006 | — | 100 | remaining, not timed |
| TS2339 | — | 95 | remaining, not timed |
| TS2344 | — | 43 | remaining, not timed |

The remaining 79 diagnostics are spread across smaller code families; the
full candidate distribution is retained in the issue evidence. The previously
new TS2352, two `to-json-schema.ts:453` TS2345 diagnostics, and `$ZodEnum`
TS2430 are absent from the final output. The exact identity diff contains no
candidate-only key. TypeScript 6.0.3 remains the zero-diagnostic oracle for the
production graph, so [#548](https://github.com/home-lang/home/issues/548) stays
open and no cross-compiler timing is admitted yet. Build and audit wall times
were observed under unrelated CPU load and are deliberately not presented as
performance results.

Final source gates pass the complete **4,353/4,353** checker suite and
**187/187** Program suite, the three focused ReleaseFast reductions, scoped
`pickier`, and `git diff --check`. The exact corpus evidence and provenance are
recorded on [#534](https://github.com/home-lang/home/issues/534#issuecomment-5556178735),
[#548](https://github.com/home-lang/home/issues/548#issuecomment-5556178799),
and [#654](https://github.com/home-lang/home/issues/654#issuecomment-5556178666).

```sh
zig build test -Dfilter=ts_checker
zig build test -Dfilter=ts_program
zig build home-tsc -Doptimize=ReleaseFast
./zig-out/bin/home-tsc --noEmit --strict --lib es2022 post-continue.ts
./zig-out/bin/home-tsc --noEmit --strict --lib es2022 recursive-heritage.ts
./zig-out/bin/home-tsc --project /path/to/zod-4.5.2/tsconfig.benchmark.json
```

### Unsupported owner-schema inherited member projection

Issue [#656](https://github.com/home-lang/home/issues/656) follows the
member-only inheritance work above through one more exact boundary. An
imported interface can contain readable primitive, builtin-object, and
callable members while an unrelated recursive indexed alias makes its complete
schema ineligible for consumer-wide lowering. A non-generic local interface
extending a generic local wrapper around that owner previously lost the HIR
declaration needed to continue member projection.

Commit [`ab86dadca`](https://github.com/home-lang/home/commit/ab86dadca)
recovers that declaration from the receiver's registered local type identity,
then validates the name against the exact declaration visible at the access
site. The existing identity-based heritage traversal does the remaining work.
Whole-schema admission is unchanged, no unsupported leaf becomes `any`, and
the normal union visibility rules still reject distinct private or protected
declarations.

The strict two-file oracle contains a circular type import, a recursive
`Record`-bearing alias, generic local and imported heritage, and a non-generic
child consumed through a source-owned factory default. TypeScript 6.0.3,
native TypeScript 7.0.2, and the ReleaseFast Home candidate all accept the
positive source with zero diagnostics. The Program fixture appends an invalid
assignment and unknown member and continues to require exactly TS2322 and
TS2339. Reversing root order preserves the same result.

The unchanged 106-file Zod 4.5.2 audit compares every complete
`path:line:column:TS-code` identity against both the post-#654 checkpoint and
the immutable 602-diagnostic baseline:

| Zod 4.5.2 unsupported-owner projection audit | Post-#654 main | #656 candidate | Change |
|---|---:|---:|---:|
| All diagnostics | 523 | **489** | **34 removed (6.5%)** |
| Unique diagnostic identities | 518 | **484** | **34 removed; 0 added** |
| TS2339 | 95 | **61** | **34 removed (35.8%)** |
| Unique identities versus immutable baseline | 597 | **484** | **113 removed; 0 added** |

Every current-parent removal is TS2339 on an inherited member such as
`pattern`, `abort`, or `check`; no candidate-only key exists. The complete
**4,353/4,353** checker suite and **187/187** Program suite pass, as do the
ReleaseFast oracle, scoped `pickier`, and `git diff --check`. Build and audit
wall times were observed under unrelated CPU load and are not admitted as
frontend performance evidence. The graph remains outside timing comparison
until [#548](https://github.com/home-lang/home/issues/548) reaches zero
diagnostics.

```sh
zig build test -Dfilter=ts_checker
zig build test -Dfilter=ts_program
zig build home-tsc -Doptimize=ReleaseFast
./zig-out/bin/home-tsc --project /path/to/cyclic-owner/tsconfig.json
./zig-out/bin/home-tsc --project /path/to/zod-4.5.2/tsconfig.benchmark.json
```

### Parameterized built-in callable transfer

Issue [#657](https://github.com/home-lang/home/issues/657) extends the exact
member projection from [#656](https://github.com/home-lang/home/issues/656)
to a callable whose signature contains a parameterized standard-library type.
The strict two-file source has a circular type import and the inherited method
`check(payload: LocalPayload<T>): T | Promise<T>`. Before the change, Home
retained the scalar siblings but reported TS2339 for `check` because Program
schemas could name checker-owned builtin objects only when they had no type
arguments.

Commit [`5f31fc7f1`](https://github.com/home-lang/home/commit/5f31fc7f1)
adds a source-owned builtin-reference expression carrying both the stable
identity and its argument expressions. The consumer lowers those arguments in
the declaration's substitution environment and reconstructs `Promise<T>` or
`PromiseLike<T>` through the same canonical constructors used for ordinary
annotations. A local declaration still wins resolution: the permanent tests
verify that a user-defined `Promise<T>` remains a declaration reference.

The support decision preserves three existing contracts. A lossless
parameterized expression may be lowered for one requested inherited member;
a contextual-only callable may retain that expression while its unrelated
opaque leaves keep the callable shell; and a non-contextual whole declaration
does not become eligible for eager structural substitution merely because its
thenable leaf is representable. This keeps unsupported owner data out of the
consumer-wide type registry without degrading the requested method to `any`.

The positive oracle is unchanged between engines. TypeScript 6.0.3, native
TypeScript 7.0.2, and ReleaseFast Home all report zero diagnostics. Its
appended negative file changes only four uses: an invalid literal assignment,
an invalid `string | Promise<string>` result assignment, a numeric payload for
`LocalPayload<string>`, and a genuinely absent member. Every engine reports
the same multiset: three TS2322 diagnostics and one TS2339. The Program fixture
runs the same graph in normal and reverse root order.

The unchanged 106-file Zod 4.5.2 graph was also the admission guard. Two draft
support policies were measured and rejected rather than hidden:

| Zod 4.5.2 parameterized-callable probe | Diagnostics | Unique identities | Delta from #656 | Decision |
|---|---:|---:|---:|---|
| Post-#656 parent | 489 | 484 | — | fixed comparison |
| All modeled generic builtin families admitted | 577 | 572 | 4 removed; **92 added** | rejected |
| Thenables projected, contextual callable contract disabled | 645 | 640 | 0 removed; **156 TS7006 added** | rejected |
| Final contextual/member-only split | **489** | **484** | **0 removed; 0 added** | accepted |
| Final versus immutable 602 baseline | **489** | **484** | **113 unique removed; 0 added** | retained |

The draft collection-family expansion also failed an existing opacity control
for `Set<T>`, so #657 certifies only `Promise<T>` and `PromiseLike<T>`. The
schema representation is extensible, but another family must independently
prove exact cross-Program semantics and pass the same corpus admission gate.
No wall-time result is reported: unrelated Zig optimizers shared the machine
during ReleaseFast builds, and this checkpoint changes correctness rather than
the timed frontend hot path.

Final gates pass **4,353/4,353** checker tests, **189/189** Program tests, the
positive and appended-negative three-engine oracles, scoped `pickier`, and
`git diff --check`. Complete evidence is retained on
[#657](https://github.com/home-lang/home/issues/657#issuecomment-5556500102).
The Zod zero-diagnostic gate [#548](https://github.com/home-lang/home/issues/548)
therefore remains open, and the graph is still excluded from timing.

```sh
zig build test -Dfilter=ts_checker
zig build test -Dfilter=ts_program
zig build home-tsc -Doptimize=ReleaseFast
./zig-out/bin/home-tsc --project /path/to/cyclic-callable/tsconfig.json
./zig-out/bin/home-tsc --project /path/to/cyclic-callable/tsconfig.invalid.json
./zig-out/bin/home-tsc --project /path/to/zod-4.5.2/tsconfig.benchmark.json
```

### Dependent generic-alias constraint instantiation

Issue [#658](https://github.com/home-lang/home/issues/658) addresses the next
coherent pinned-corpus cluster after #657. Zod's public parameter helpers bind
a schema type first, then constrain a later key with an expression such as
`Exclude<keyof T["_zod"]["def"], "type" | "checks" | "error">`. Home checked
each explicit argument against the constraint captured when the alias was
declared. That stored graph had already collapsed the indexed/keyof expression
to a non-free placeholder, so ordinary TypeId substitution could not recover
the supplied earlier `T`. Valid keys such as `"coerce"` and `"when"` therefore
produced TS2344.

Commit [`0ffa17565`](https://github.com/home-lang/home/commit/0ffa17565)
aligns both generic-alias validation paths with the existing function,
constructor, and Program behavior. Arguments are validated from left to right,
and each effective argument is added to the substitution environment only
after its own constraint check. For a local declaration-backed parameter, the
checker binds those earlier formal parameters in a narrow type scope and
re-lowers the original constraint syntax. This recovers the exact indexed,
keyof, conditional, and utility evaluation without matching `Exclude`, any
property spelling, or any Zod declaration name.

When the resolved bound is a finite string-literal union, TS2344 prose is now
rendered directly from those literal TypeIds. This prevents unrelated alias
display names from changing the bound while preserving the ordinary fallback
for symbolic constraints.

The strict same-file oracle defines a concrete schema with `coerce` and `when`
properties. TypeScript 6.0.3 and native TypeScript 7.0.2 accept both valid
instantiations and report exactly one TS2344 for an appended `"missing"` key,
with constraint `"coerce" | "when"`. ReleaseFast Home now matches that exact
code count and resolved constraint wording. Removing the invalid line leaves
all three compilers clean.

The unchanged 106-file Zod configuration supplies the production admission
gate:

| Zod 4.5.2 dependent-constraint audit | Post-#657 main | #658 candidate | Change |
|---|---:|---:|---:|
| All diagnostics | 489 | **448** | **41 removed (8.4%); 0 added** |
| Unique diagnostic identities | 484 | **443** | **41 removed; 0 added** |
| TS2344 | 43 | **2** | **41 removed (95.3%)** |
| Unique identities versus immutable baseline | 597 | **443** | **154 removed; 0 added** |

All 41 current-parent removals are TS2344 diagnostics in
`src/v4/core/api.ts`; the two remaining TS2344 diagnostics are the separate
`core.output<Key>` property-key constraint in `core/schemas.ts`. No
candidate-only identity exists. The Zod graph is still not a valid timing
input, so [#548](https://github.com/home-lang/home/issues/548) remains open.
ReleaseFast compilation also shared the host with unrelated Zig builds, and no
wall-time claim is admitted.

Final gates pass the focused three-engine positive/negative oracle, the broad
constraint-filtered checker suite, **4,354/4,354** complete checker tests,
**189/189** Program tests, scoped `pickier`, and `git diff --check`. Exact
evidence is retained on
[#658](https://github.com/home-lang/home/issues/658#issuecomment-5556603254).

```sh
zig build test -Dfilter=ts_checker -Dts-checker-test-filter=constraint
zig build test -Dfilter=ts_checker
zig build test -Dfilter=ts_program
zig build home-tsc -Doptimize=ReleaseFast
./zig-out/bin/home-tsc --project /path/to/dependent-constraint/tsconfig.json
./zig-out/bin/home-tsc --project /path/to/zod-4.5.2/tsconfig.benchmark.json
```

### Conditional indexed-alias base constraints

Issue [#659](https://github.com/home-lang/home/issues/659) closes the two
TS2344 diagnostics left by #658. Zod defines `core.output<T>` as a conditional
alias: a matching schema selects `T["_zod"]["output"]`, while the false branch
is `unknown`. Its record key is nevertheless safe because the outer `Key`
parameter is constrained to a schema whose output is
`string | number | symbol`. Home preserved the unresolved conditional but did
not re-evaluate it over that outer constraint, so both safe `Record` key uses
were rejected.

Commit [`1332e4e6f`](https://github.com/home-lang/home/commit/1332e4e6f)
extends the existing indexed-access base-constraint path rather than the
`Record` builtin. A deferred conditional TypeId is substituted with the
declared constraint of its check parameter and evaluated by the ordinary
conditional and indexed-access machinery. For source-local generic aliases,
the same analysis binds every formal parameter to its argument's effective
base constraint and re-lowers the alias body. Qualified aliases resolve by
declaration identity through namespace and import-equals paths. Cross-file
aliases use the already-transferred Program conditional graph. The
implementation contains no checks for `Record`, `_zod`, `output`, or Zod.

The strict same-file oracle covers unqualified `OutputOf<T>` and qualified
`core.output<T>` spellings. Each constrained positive uses
`Key extends Schema<string | number | symbol>`; each negative repeats the
same alias with an unconstrained `T`:

| Conditional indexed-alias control | TypeScript 6.0.3 | Native TypeScript 7.0.2 | ReleaseFast Home |
|---|---:|---:|---:|
| Unqualified constrained record key | 0 diagnostics | 0 diagnostics | **0 diagnostics** |
| Qualified constrained record key | 0 diagnostics | 0 diagnostics | **0 diagnostics** |
| Unqualified unconstrained record key | 1× TS2344 | 1× TS2344 | **1× TS2344** |
| Qualified unconstrained record key | 1× TS2344 | 1× TS2344 | **1× TS2344** |

The unchanged 106-file Zod 4.5.2 configuration is the production admission
gate:

| Zod 4.5.2 conditional indexed-alias audit | Post-#658 main | #659 candidate | Change |
|---|---:|---:|---:|
| All diagnostics | 448 | **446** | **2 removed; 0 added** |
| Unique diagnostic identities | 443 | **441** | **2 removed; 0 added** |
| TS2344 | 2 | **0** | **all remaining TS2344 removed** |
| Unique identities versus immutable baseline | 597 | **441** | **156 removed; 0 added** |

The two current-parent removals are exactly
`src/v4/core/schemas.ts:3089:20:TS2344` and
`src/v4/core/schemas.ts:3090:12:TS2344`; no candidate-only identity exists.
Zod still has 446 other diagnostics, so [#548](https://github.com/home-lang/home/issues/548)
remains open and this graph is not admitted to cross-compiler timing. The
ReleaseFast build shared the host with unrelated Zig work, so no wall-time
claim is reported.

Final gates pass the unqualified and qualified three-engine controls, the
broad constraint-filtered checker suite, **4,355/4,355** complete checker
tests, **189/189** Program tests, scoped `pickier`, `zig fmt --check`, and
`git diff --check`. Exact evidence is retained on
[#659](https://github.com/home-lang/home/issues/659#issuecomment-5556749453).

```sh
zig build test -Dfilter=ts_checker -Dts-checker-test-filter=constraint
zig build test -Dfilter=ts_checker
zig build test -Dfilter=ts_program
zig build -Doptimize=ReleaseFast
./zig-out/bin/home-tsc -p /path/to/conditional-key/tsconfig.json
./zig-out/bin/home-tsc -p /path/to/zod-4.5.2/tsconfig.benchmark.json
```

### Map-entry tuples through array callbacks

Issue [#660](https://github.com/home-lang/home/issues/660) follows the next
coherent Zod cluster after #659. A `Map<K, V>` iterator yields `[K, V]`, but
Home synthesized its entry as a generic array-like object with numeric index
`K | V`. Array spread therefore retained only the union for contextual
destructuring. The parser also discarded binding elisions, so `[, value]`
reached every positional consumer as a one-slot pattern.

Commit [`768ae2192`](https://github.com/home-lang/home/commit/768ae2192)
uses the checker's existing fixed-tuple constructor for mutable Map entries,
recognizes checker-created tuple origins during binding projection, and keeps
array-pattern elisions as empty HIR parameter slots. The binder and emitter
already treat an empty parameter slot as an elision. This restores the tuple
and source position instead of adding a Zod symbol, callback-chain, property,
or diagnostic-location exception.

The standalone strict, no-emit oracle uses the same two files and configs for
Home ReleaseFast, TypeScript 6.0.3, and native TypeScript 7.0.2. The negative
file differs only by changing the final annotation from `string[]` to
`number[]`:

| Map spread / callback control | TypeScript 6.0.3 | Native TypeScript 7.0.2 | ReleaseFast Home |
|---|---:|---:|---:|
| `[...Map<string, Flags>]`, `filter(([, flags]) => ...)`, `map(([key]) => key)`, assign to `string[]` | 0 diagnostics | 0 diagnostics | **0 diagnostics** |
| Same pipeline assigned to `number[]` | 1× TS2322 from `string[]` | 1× TS2322 from `string[]` | **1× TS2322 from `string[]`** |

The unchanged 106-file Zod 4.5.2 configuration supplies the production
admission gate:

| Zod 4.5.2 Map-entry tuple audit | Post-#659 main | #660 candidate | Change |
|---|---:|---:|---:|
| All diagnostics | 446 | **440** | **6 removed; 0 added** |
| Unique diagnostic identities | 441 | **435** | **6 removed; 0 added** |
| TS2345 | 206 | **203** | **3 removed** |
| TS2339 | 61 | **59** | **2 removed** |
| TS2322 | 13 | **12** | **1 removed** |
| Unique identities versus immutable baseline | 597 | **435** | **162 removed; 0 added** |

The six current-parent removals are the three Map-key TS2345 diagnostics at
`src/v4/core/schemas.ts:2827/2830`, the two `flags.l` / `flags.r` TS2339
diagnostics at `schemas.ts:2825`, and the Map-entry destructuring TS2322 at
`src/v4/core/compile.ts:262`. No candidate-only identity exists. The candidate
distribution is 203 TS2345, 100 TS7006, 59 TS2339, 16 TS1361, 16 TS2304, 12
TS2322, and fewer than five diagnostics for every remaining code.

Zod still has 440 diagnostics, so [#548](https://github.com/home-lang/home/issues/548)
remains open and the graph is not admitted to cross-compiler timing. The
ReleaseFast build ran on a contended shared host, so its wall time is excluded.

Final gates pass the three-engine positive/negative oracle, the focused
regression, **4,356/4,356** complete checker tests, the full parser suite,
**189/189** Program tests, ReleaseFast, scoped `pickier`, `zig fmt --check`,
and `git diff --check`. Exact evidence is retained on
[#660](https://github.com/home-lang/home/issues/660#issuecomment-5556844244).

```sh
zig build test -Dfilter=ts_checker -Dts-checker-test-filter='Map entry tuples retain positions through filter and map callbacks'
zig build test -Dfilter=ts_checker
zig build test -Dfilter=ts_parser
zig build test -Dfilter=ts_program
zig build -Doptimize=ReleaseFast
./zig-out/bin/home-tsc --project=/path/to/map-callback-tuples/tsconfig.json --pretty=false
./zig-out/bin/home-tsc --project=/path/to/zod-4.5.2/tsconfig.benchmark.json --pretty=false
```

### Default-lib aliases in nested type arguments

Issue [#661](https://github.com/home-lang/home/issues/661) addresses the four
remaining Zod TS2304 diagnostics for `PropertyKey`. Home already resolves this
default-lib alias in ordinary annotations, but the independent unresolved-name
sweep for parsed generic arguments did not consult the same default-lib
type-only registry. It therefore rejected `Record<PropertyKey, unknown>`
before the normal lowerer could produce `string | number | symbol`.

Commit [`f4aaf50a6`](https://github.com/home-lang/home/commit/f4aaf50a6)
adds the existing `isDefaultLibTypeOnlyFallbackName` predicate to that generic
argument resolution path. This is shared by all registered default-lib
type-only names. It does not special-case Zod, `Record`, `PropertyKey`, a file,
or a diagnostic location, and it does not classify arbitrary missing names as
resolved.

The strict, no-emit oracle exercises direct `PropertyKey`, nested
`Record<PropertyKey, unknown>`, interface members, function parameters and
returns, and value annotations. Its negative counterpart only adds
`Record<MissingKey, unknown>`:

| Default-lib type-name control | TypeScript 6.0.3 | Native TypeScript 7.0.2 | ReleaseFast Home |
|---|---:|---:|---:|
| Direct and nested `PropertyKey` uses | 0 diagnostics | 0 diagnostics | **0 diagnostics** |
| Same source plus nested `MissingKey` | 1× TS2304 on `MissingKey` | 1× TS2304 on `MissingKey` | **1× TS2304 on `MissingKey`** |

The unchanged 106-file Zod 4.5.2 graph supplies the production admission gate:

| Zod 4.5.2 nested default-lib alias audit | Post-#660 main | #661 candidate | Change |
|---|---:|---:|---:|
| All diagnostics | 440 | **436** | **4 removed; 0 added** |
| Unique diagnostic identities | 435 | **431** | **4 removed; 0 added** |
| TS2304 | 16 | **12** | **4 removed** |
| Unique identities versus immutable baseline | 597 | **431** | **166 removed; 0 added** |

The removals are exactly `src/v4/core/schemas.ts:3118:73:TS2304` and
`src/v4/core/util.ts:160:33:TS2304`, `400:53:TS2304`, and
`424:52:TS2304`; no candidate-only identity exists. The candidate distribution
starts with 203 TS2345, 100 TS7006, 59 TS2339, 16 TS1361, 12 TS2304, and 12
TS2322. Every remaining code has fewer than five diagnostics.

Zod still has 436 diagnostics, so [#548](https://github.com/home-lang/home/issues/548)
remains open and the graph is not admitted to cross-compiler timing. The
ReleaseFast build ran on a contended shared host, so its wall time is excluded.

Final gates pass the three-engine positive/negative oracle, the permanent
regression, **4,357/4,357** complete checker tests, **189/189** Program tests,
ReleaseFast, scoped `pickier`, `zig fmt --check`, and `git diff --check`.
Exact evidence is retained on
[#661](https://github.com/home-lang/home/issues/661#issuecomment-5556921199).

```sh
zig build test -Dfilter=ts_checker -Dts-checker-test-filter='default-lib aliases resolve as nested generic arguments'
zig build test -Dfilter=ts_checker
zig build test -Dfilter=ts_program
zig build -Doptimize=ReleaseFast
./zig-out/bin/home-tsc --project=/path/to/property-key/tsconfig.json --pretty=false
./zig-out/bin/home-tsc --project=/path/to/zod-4.5.2/tsconfig.benchmark.json --pretty=false
```

### Zod collection and generic-relation audit (#662–#664)

Issues [#662](https://github.com/home-lang/home/issues/662),
[#663](https://github.com/home-lang/home/issues/663), and
[#664](https://github.com/home-lang/home/issues/664) address six independent
false positives exposed by the unchanged 106-file Zod 4.5.2 graph. The fixes
are language-level changes with focused negative controls:

- Commit [`3e4f37c39`](https://github.com/home-lang/home/commit/3e4f37c39)
  resolves the default-lib `ReadonlyMap`, `ReadonlySet`, `WeakMap`, and
  `WeakSet` interfaces through the same generic type-reference path as the
  existing collection types. Read-only collections omit mutators, `WeakMap`
  lookup retains `undefined`, and genuinely missing collection names remain
  TS2304 errors.
- Commits [`127c714e0`](https://github.com/home-lang/home/commit/127c714e0)
  and [`7e2fcbdb4`](https://github.com/home-lang/home/commit/7e2fcbdb4)
  validate nullable generic and conditional object-spread sources by their
  reachable type domains. Mapped object shapes and branches proven unreachable
  by a conditional constraint are accepted; reachable primitive branches
  remain TS2698 errors.
- Commit [`a3a764ae0`](https://github.com/home-lang/home/commit/a3a764ae0)
  follows a source type parameter's transitive constraint before issuing the
  strict foreign-type-parameter argument diagnostic. A constrained schema
  parameter is accepted where its schema constraint is required, while a
  concrete incompatible argument remains TS2345.

The collection oracle has separate positive and negative projects. The
positive project exercises all four collection interfaces and their permitted
members. The negative project checks a missing name, forbidden `ReadonlyMap`
and `ReadonlySet` mutators, and the optional result of `WeakMap.get`:

| Collection control | TypeScript 6.0.3 | Native TypeScript preview | ReleaseFast Home |
|---|---:|---:|---:|
| Valid collection references and members | 0 diagnostics | 0 diagnostics | **0 diagnostics** |
| Invalid controls | TS2304, TS2339, TS2339, TS2322 | TS2304, TS2339, TS2339, TS2322 | **TS2304, TS2339, TS2339, TS2322** |

The conditional-spread oracle accepts nullable object constraints, recursive
mapped aliases, a full nested Zod-like conditional alias, and object-only
conditional branches. Its negative controls contain a primitive-only
conditional and a mixed object/primitive conditional:

| Object-spread control | TypeScript 6.0.3 | Native TypeScript preview | ReleaseFast Home |
|---|---:|---:|---:|
| Valid nullable, mapped, and object-only sources | 0 diagnostics | 0 diagnostics | **0 diagnostics** |
| Primitive-only and mixed conditionals | 2× TS2698 | 2× TS2698 | **2× TS2698** |

The relation oracle accepts `S extends Schema` when passed to a parameter of
type `Schema` and retains exactly one TS2345, with the same message, for the
`number` control in all three engines.

The unchanged production graph supplies the regression gate:

| Zod 4.5.2 collection and generic-relation audit | Post-#661 main | #662 / #663 / #664 main | Change |
|---|---:|---:|---:|
| All diagnostics | 436 | **430** | **6 removed; 0 added** |
| Unique diagnostic identities | 431 | **425** | **6 removed; 0 added** |
| Unique identities versus immutable baseline | 597 | **425** | **172 removed; 0 added** |

The six removed identities are
`src/v4/core/memoizer.ts:35:18:TS2304`,
`src/v4/core/registries.ts:30:9:TS2304`,
`src/v4/core/registries.ts:40:33:TS2345`,
`src/v4/core/registries.ts:66:25:TS2698`,
`src/v4/core/util.ts:150:5:TS2304`, and
`src/v4/core/util.ts:152:7:TS2304`. No candidate-only identity exists. The
final distribution is 202 TS2345, 100 TS7006, 59 TS2339, 16 TS1361, 12
TS2322, 8 TS2304, 4 TS7031, 4 TS2554, 4 TS2430, 3 TS2488, 3 TS2411, 2
TS4110, 2 TS2749, 2 TS2741, 2 TS2698, 2 TS2552, 2 TS2367, 2 TS18048, and
1 TS2571.

Zod still has 430 diagnostics while TypeScript reports zero, so
[#548](https://github.com/home-lang/home/issues/548) remains open and the
graph is not admitted to cross-compiler timing. Timing was deliberately
excluded because the ReleaseFast build and audits ran on a contended shared
host; this section makes no performance claim.

Final gates pass every three-engine positive/negative oracle, all three
focused regressions, the complete checker suite, the complete Program suite,
a clean-cache ReleaseFast build, `zig fmt --check`, and `git diff --check`.
Exact production evidence is retained on
[#662](https://github.com/home-lang/home/issues/662#issuecomment-5557350752),
[#663](https://github.com/home-lang/home/issues/663#issuecomment-5557348820),
and [#664](https://github.com/home-lang/home/issues/664#issuecomment-5557198840).

```sh
zig build test -Dfilter=ts_checker -Dts-checker-test-filter='default lib collection type refs preserve readonly and missing-name semantics'
zig build test -Dfilter=ts_checker -Dts-checker-test-filter='object spread rejects primitive-constrained type parameter'
zig build test -Dfilter=ts_checker -Dts-checker-test-filter='overload diagnostics honor transitive generic argument constraints'
zig build test -Dfilter=ts_checker
zig build test -Dfilter=ts_program
zig build -Doptimize=ReleaseFast
./zig-out/bin/home-tsc --project=/path/to/collections/tsconfig.json --pretty=false
./zig-out/bin/home-tsc --project=/path/to/conditional-spread/tsconfig.json --pretty=false
./zig-out/bin/home-tsc --project=/path/to/property-key/tsconfig.json --pretty=false
./zig-out/bin/home-tsc --project=/path/to/zod-4.5.2/tsconfig.benchmark.json --pretty=false
```

### Partially transferable imported-class methods

Issue [#665](https://github.com/home-lang/home/issues/665) addresses the
largest remaining Zod TS7006 family. A plain exported class previously carried
only shallow member names across a Program boundary. If an unrelated member
used an unsupported whole-class type graph, callable members therefore
degraded to `any` and their callback parameters lost contextual types.

Commit [`9fe50f37a`](https://github.com/home-lang/home/commit/9fe50f37a)
retains source-owned schemas for member projection while preserving the
existing safe whole-object fallback. When a called member's fallback is not
callable, the checker lowers only that requested member in contextual mode.
An exact recursive class reference maps back to the already materialized
receiver, so nested calls recover the same signature without expanding the
unsupported sibling graph. The implementation contains no checks for Zod,
`Doc`, `indented`, a source path, or a diagnostic location.

The first candidate incorrectly allowed those newly collected schemas to
enter whole-class substitution. Its standalone oracle and Program suite
passed, but the untouched Zod graph exited 139 before emitting diagnostics;
that design was rejected and never committed. The admitted projection-only
design preserves the pre-existing whole-class admission boundary and makes
the same graph complete normally.

The strict two-file oracle gives the imported class an unsupported mutable
`Record<string, unknown>` sibling and a self-referential callback method. It
checks both direct and recursively nested callbacks. Two negative controls
prove the inferred parameter is the imported class rather than `any`:

| Imported-class method control | TypeScript 6.0.3 | Native TypeScript preview | ReleaseFast Home |
|---|---:|---:|---:|
| Direct and nested callback parameters | no TS7006 | no TS7006 | **no TS7006** |
| Missing member and assignment to `number` | TS2339, TS2322 | TS2339, TS2322 | **TS2339, TS2322** |

The unchanged production graph supplies the admission gate:

| Zod 4.5.2 imported-class method audit | Post-#664 main | #665 main | Change |
|---|---:|---:|---:|
| All diagnostics | 430 | **400** | **30 removed; 0 added** |
| Unique diagnostic identities | 425 | **395** | **30 removed; 0 added** |
| TS7006 | 100 | **70** | **30 removed** |
| Unique identities versus immutable baseline | 597 | **395** | **202 removed; 0 added** |

All 30 removals are TS7006 callback parameters in
`src/v4/core/compile.ts`, at lines 1144, 1152, 1183, 1204, 1238, 1275,
1277, 1285, 1296, 1455, 1480, 1573, 1578, 1586, 1635, 1637, 1644, 1654,
1678, 1754, 1805, 1889, 1921, 1950, 1979, 1999, 2034, 2037, 2142, and 2152.
No candidate-only identity exists. The final distribution is 202
TS2345, 70 TS7006, 59 TS2339, 16 TS1361, 12 TS2322, 8 TS2304, 4 TS7031,
4 TS2554, 4 TS2430, 3 TS2488, 3 TS2411, 2 TS4110, 2 TS2749, 2 TS2741,
2 TS2698, 2 TS2552, 2 TS2367, 2 TS18048, and 1 TS2571.

Two production runs are byte-identical, with stderr SHA-256
`3212f2598cc37ba0eb8a98a14c0ddfe82158ee4797ee75ec8f5d8565d5414774`.
Zod still has 400 diagnostics while TypeScript reports zero, so
[#548](https://github.com/home-lang/home/issues/548) remains open and the
graph is not admitted to cross-compiler timing. All elapsed times are excluded
because the shared host was contended; this section makes no performance
claim.

Final gates pass the exact three-engine oracle, **190/190** complete Program
tests, the complete checker suite, ReleaseFast, `zig fmt --check`, and
`git diff --check`. The required repository-wide Pickier run remains red on
existing debt: 22,427 findings across 12,657 linted files.

```sh
zig build test -Dfilter=ts_program
zig build test -Dfilter=ts_checker
zig build -Doptimize=ReleaseFast
./zig-out/bin/home-tsc --project=/path/to/imported-method-context/tsconfig.json --pretty=false
./zig-out/bin/home-tsc --project=/path/to/zod-4.5.2/tsconfig.benchmark.json --pretty=false
```

### Imported mapped contextual members

Issue [#666](https://github.com/home-lang/home/issues/666), under
[#548](https://github.com/home-lang/home/issues/548), addresses contextual
typing for imported mapped object types whose property template is not a
direct indexed access. For example, in
`{ [K in Kind]?: (item: Item<K>, rewritten: boolean) => Item }`, the callback
assigned to property `a` must receive `Item<"a">`.

Before commit
[`d5292655c`](https://github.com/home-lang/home/commit/d5292655c), the checker
could recover a mapped key parameter only from a narrowly recognized
`Object[K]` template. A callable template carried `K` inside the generic
argument `Item<K>`, so imported object-literal projection left it generic and
reported a false key assignment plus a false whole-argument TS2345.

The mapped payload now stores the key parameter's declaration identity
directly. Interning, mapped substitution, Program schema lowering, and
cross-pool type transfer preserve that identity. Property projection binds it
to the concrete property string literal before contextualizing the member.
The mechanism applies to arbitrary nested templates and contains no checks for
an alias name, property name, source path, diagnostic location, or benchmark
package.

The strict two-file oracle imports an optional mapped handler type, assigns a
callback to property `a`, and keeps independent positive and negative controls:

| Imported mapped-handler control | TypeScript 6.0.3 | Native TypeScript preview | ReleaseFast Home |
|---|---:|---:|---:|
| Callback item type | `Item<"a">` | `Item<"a">` | **`Item<"a">`** |
| Implicit callback parameters | no TS7006 | no TS7006 | **no TS7006** |
| Whole object-literal argument | no TS2345 | no TS2345 | **no TS2345** |
| Assignment to `number`; missing member on `boolean` | TS2322, TS2339 | TS2322, TS2339 | **TS2322, TS2339** |

The unchanged pinned 106-file Zod 4.5.2 graph is an exact parent/candidate
admission guard. The parent is `bb52bd4ab`; the candidate is `d5292655c`.
Complete identities normalize to path, line, column, and diagnostic code:

| Zod 4.5.2 mapped contextual-member audit | Parent `bb52bd4ab` | #666 `d5292655c` | Change |
|---|---:|---:|---:|
| All diagnostics | 400 | **400** | **unchanged; 0 added** |
| Unique diagnostic identities | 395 | **395** | **unchanged; 0 added** |
| Unique identities versus immutable baseline | 597 | **395** | **202 removed overall; 0 added** |

The normalized identity sets are identical. Parent and candidate stderr are
also byte-identical, with SHA-256
`0590e3b2b593d2e2c0abb32f9f732d45f6d1701f3c2f906d07975ddf39c0bbc9`;
two independent candidate runs match as well. The diagnostic distribution is
202 TS2345, 70 TS7006, 59 TS2339, 16 TS1361, 12 TS2322, 8 TS2304, 4 TS7031,
4 TS2554, 4 TS2430, 3 TS2488, 3 TS2411, 2 TS4110, 2 TS2749, 2 TS2741,
2 TS2698, 2 TS2552, 2 TS2367, 2 TS18048, and 1 TS2571.

Zod still has diagnostics while TypeScript reports zero, so it remains outside
cross-compiler timing. Timing is also excluded because the release builds and
audits ran on a contended shared host; this section makes no performance
claim.

Final gates pass the exact three-engine oracle, the permanent imported
positive/negative Program regression, the complete Program and checker suites,
the focused cross-pool transfer regression, ReleaseFast, `zig fmt --check`,
and `git diff --check`. The required repository-wide Pickier run remains red
on existing debt: 22,427 findings (11,834 errors and 10,593 warnings).
Production evidence is retained on
[#666](https://github.com/home-lang/home/issues/666#issuecomment-5560759824).

```sh
zig build test -Dfilter=ts_checker -Dts-checker-test-filter='type transfer: every payload kind preserves shared recursive edges and mapped names'
zig build test -Dfilter=ts_checker
zig build test -Dfilter=ts_program
zig build -Doptimize=ReleaseFast
./zig-out/bin/home-tsc --project=/path/to/mapped-handler-context/tsconfig.json --pretty=false
./zig-out/bin/home-tsc --project=/path/to/zod-4.5.2/tsconfig.benchmark.json --pretty=false
bunx --bun pickier .
```

### Declared Function predicate narrowing (untimed)

Issue [#467](https://github.com/home-lang/home/issues/467) separates the
declared global `Function` shape from the checker's synthetic builtin marker.
Predicate narrowing now resolves that marker, and aliases of it, to the actual
global declaration before testing assignability. A callable declaration such
as `interface Function { call(thisArg: any, ...args: any[]): any }` therefore
narrows `number | (() => number)` to the function constituent in the positive
branch and to `number` in the negative branch. An empty `Function` declaration
does not claim callability and leaves the union intact.

The implementation uses semantic type identity and the declared `call`
signature. It does not special-case the spelling `Function`: aliases exercise
the same path, while ordinary assignment of a standalone function to the
callable declaration remains accepted. Permanent checker controls cover the
direct and aliased predicates, both branches, typed positive and negative
consumers, the callable and empty global shapes, and the standalone assignment.

| Untimed correctness gate | TypeScript 6.0.3 | Native TypeScript 7.0.2 | Home |
|---|---:|---:|---:|
| Callable `Function`, direct and alias | accepted | accepted | accepted |
| Deliberately invalid branch consumers | 4× TS2322 | 4× TS2322 | 4× TS2322 |
| Empty `Function`, direct and alias | 2× TS2349 + 2× TS2322 | 2× TS2349 + 2× TS2322 | 2× TS2349 + 2× TS2322 |
| Standalone function assignment | accepted | accepted | accepted |

A fresh stripped ReleaseSafe `home-tsc` also matches both pinned controls on
the standalone CLI oracle: the callable fixture exits cleanly, and the empty
fixture reports exactly TS2349 and TS2322. The complete checker suite passes
**4,409/4,409** and the default conformance suite passes **1,419/1,419**. The
guarded compiler build peaked at 2,592 MB, with all heavy jobs serialized under
the 3,840 MB ceiling.

This is a correctness result, not a timing claim. No benchmark inputs,
diagnostic admission rules, or existing performance measurements changed.

### Atomic incremental source replacement (untimed)

Issue [#472](https://github.com/home-lang/home/issues/472) covered two
ownership faults in `Program.updateSource`: an allocation failure after
removing the old source-map entry could leave a dangling `File.source`, and
redirect files continued borrowing the canonical file's freed source after a
successful replacement.

Source replacement now resolves redirects to their canonical file and
allocates the complete replacement before changing any published state. The
commit point is allocation-free: it replaces the existing source-map value in
place, invalidates the canonical compilation and owner, refreshes every sibling
redirect, clears stale imports and source-marker snapshots, and only then frees
the old bytes. The requested path's ID remains the return value, so callers do
not lose redirect identity. Incremental recompilation separately canonicalizes
and deduplicates changed paths, preventing a redirect and its canonical path
from compiling the same source twice.

A deterministic failing-allocator regression checks the old source-map value,
canonical and redirect pointers, marker snapshot, compilation pointer, owner
registration, and source bytes after forced allocation failure, then verifies
a successful retry. The existing duplicate-package fixture now updates through
the redirect path, preserves the package-ID mapping and redirect target, and
passes duplicate redirect/canonical paths to incremental recompilation while
requiring exactly one canonical compile.

The complete Program suite passes **225/225** under the guarded runner. The
final run peaked at 2,027 MB of conservatively summed process-tree footprint,
with a 35% host-memory low-water mark. This is an **untimed**
ownership and recovery result; it makes no compiler-performance claim.

### Imported overloaded object-literal context

Issue [#667](https://github.com/home-lang/home/issues/667), under
[#548](https://github.com/home-lang/home/issues/548), covers contextual object
literals passed to an imported overloaded function. Commit
[`b6f5eef4a`](https://github.com/home-lang/home/commit/b6f5eef4a) transfers a
multiply declared function as the ordered intersection of its bodyless
overload signatures. A concrete implementation body is excluded from the
public call surface, matching the existing local-overload rule.

Contextual checking first keeps arity-compatible signatures, then compares
only the object literal's declared property names with each corresponding
parameter. A signature is selected only when exactly one candidate can own
every declared property. Callback values are not evaluated during this
selection, so they cannot circularly choose the context that determines their
own types; ordinary overload resolution still owns complete applicability and
diagnostics. Unconstrained type parameters, `any`, `unknown`, dynamic computed
keys, and rest signatures remain possible candidates. The implementation has
no checks for a package, path, function, alias, property, or diagnostic.

The strict two-file oracle places a generic overload with an optional second
parameter before the optional mapped-handler overload. Property `a` must
select the latter and retain the mapped key specialization from #666:

| Imported overloaded-handler control | TypeScript 6.0.3 | Native TypeScript preview | ReleaseFast Home |
|---|---:|---:|---:|
| Callback item type | `Item<"a">` | `Item<"a">` | **`Item<"a">`** |
| Implicit callback parameters | no TS7006 | no TS7006 | **no TS7006** |
| Whole object-literal argument | no TS2345 | no TS2345 | **no TS2345** |
| Assignment to `number`; missing member on `boolean` | TS2322, TS2339 | TS2322, TS2339 | **TS2322, TS2339** |

Permanent negative controls cover two signatures that both own property `a`
and two signatures that both reject property `c`. The ambiguous case retains
the first declaration's contextual type, matching both TypeScript engines;
the mismatch leaves its callback parameter implicit-`any` instead of choosing
an inapplicable overload. Optional mapped members and generic overload-local
parameters are exercised in the positive control.

The unchanged pinned 106-file Zod 4.5.2 graph is the production admission
guard. Runs use the same `tsconfig.benchmark.json`; complete identities
normalize to path, line, column, and diagnostic code:

| Zod 4.5.2 imported-overload object audit | #666 main | #667 `b6f5eef4a` | Change |
|---|---:|---:|---:|
| All diagnostics | 400 | **400** | **unchanged; 0 added** |
| Unique diagnostic identities | 395 | **395** | **unchanged; 0 added** |
| Unique identities versus immutable baseline | 597 | **395** | **202 removed overall; 0 added** |

The baseline and two independent candidate runs are byte-identical, with
stderr SHA-256
`0590e3b2b593d2e2c0abb32f9f732d45f6d1701f3c2f906d07975ddf39c0bbc9`.
The normalized identity SHA-256 is
`86df9bf4b128d164b88a96d4dfa2441094dbeeaa514b2587fa73c5ac0f3cdab5`;
the exact delta is zero removals and zero additions. The distribution remains
202 TS2345, 70 TS7006, 59 TS2339, 16 TS1361, 12 TS2322, 8 TS2304, 4 TS7031,
4 TS2554, 4 TS2430, 3 TS2488, 3 TS2411, 2 TS4110, 2 TS2749, 2 TS2741,
2 TS2698, 2 TS2552, 2 TS2367, 2 TS18048, and 1 TS2571.

Zod's 16 `classic/in-out.ts` and `mini/in-out.ts` callback TS7006 diagnostics
remain. Its real `VisitHandlers` value template uses a deeper conditional
`Extract` declaration graph outside this overload-transfer slice; the exact
standalone overload shape is fixed without approximating that unsupported
graph. Zod still has diagnostics while TypeScript reports zero, so it remains
outside cross-compiler timing. Elapsed times are also excluded because the
shared host was contended; this section makes no performance claim.

Final gates pass the exact three-engine oracle, **193/193** complete Program
tests, the complete checker suite, ReleaseFast, `zig fmt --check`, and
`git diff --check`. The required repository-wide Pickier run remains red on
unchanged existing debt: 22,427 findings (11,834 errors and 10,593 warnings).
Production evidence is retained on
[#667](https://github.com/home-lang/home/issues/667#issuecomment-5560965638).

```sh
zig build test -Dfilter=ts_program
zig build test -Dfilter=ts_checker
zig build -Doptimize=ReleaseFast
./zig-out/bin/home-tsc --project=/path/to/overloaded-mapped-handler/tsconfig.json --pretty=false
./zig-out/bin/home-tsc --project=/path/to/zod-4.5.2/tsconfig.benchmark.json --pretty=false
bunx --bun pickier .
```

### Imported Extract conditional handlers

Issue [#668](https://github.com/home-lang/home/issues/668), under
[#548](https://github.com/home-lang/home/issues/548), isolates standard
`Extract<T, U>` inside an imported conditional mapped-handler alias. Commit
[`40160d029`](https://github.com/home-lang/home/commit/40160d029) represents
that utility losslessly in the Program declaration schema and lowers it
through the existing conditional evaluator as the distributive relation
`T extends U ? T : never`.

Only `Extract` receives this whole-schema admission because its complete
semantics are preserved. Existing contextual handling for `Partial`,
`Required`, `Readonly`, `Pick`, and `Omit` is unchanged. The source union is
resolved before evaluation, the target retains declaration-owned type
parameters until mapped-key substitution, and the normal conditional engine
performs distribution and structural assignability. There is no fabricated
member surface or check for a package, path, alias, property, or diagnostic.

The strict two-file oracle defines discriminated interfaces `A` and `B`, then
uses this source-owned alias under the imported overload from #667:

```ts
type ItemOfKind<K extends Kind> = [Extract<Item, { kind: K }>] extends [never]
  ? Item
  : Extract<Item, { kind: K }>;
type Handlers = { [K in Kind]?: (item: ItemOfKind<K>, rewritten: boolean) => Item };
```

Property `a` must retain only `A`. A second instantiation,
`ItemOfKind<never>`, exercises the true fallback branch and must recover the
complete `A | B` union:

| Imported Extract-handler control | TypeScript 6.0.3 | Native TypeScript preview | ReleaseFast Home |
|---|---:|---:|---:|
| Property `a` callback item | `A` | `A` | **`A`** |
| Nonmatching `B` member | absent | absent | **absent** |
| `ItemOfKind<never>` fallback | `Item` (`A \| B`) | `Item` (`A \| B`) | **`A \| B`** |
| Implicit callback parameters / whole call | no TS7006/TS2345 | no TS7006/TS2345 | **no TS7006/TS2345** |
| Invalid controls | TS2322 x2, TS2339 x2 | TS2322 x2, TS2339 x2 | **TS2322 x2, TS2339 x2** |

The schema regression also proves both `Extract` occurrences survive the
conditional graph beneath an optional mapped handler and the ordered imported
overload set. The Program regression owns the concrete cross-file behavior;
the ambiguity, generic overload, unrelated-property, and optional-member
controls from #667 remain green.

The unchanged pinned 106-file Zod 4.5.2 graph remains the production
admission guard:

| Zod 4.5.2 imported-Extract handler audit | #667 main | #668 `40160d029` | Change |
|---|---:|---:|---:|
| All diagnostics | 400 | **400** | **unchanged; 0 added** |
| Unique diagnostic identities | 395 | **395** | **unchanged; 0 added** |
| Unique identities versus immutable baseline | 597 | **395** | **202 removed overall; 0 added** |

The baseline and two independent candidate runs are byte-identical, with
stderr SHA-256
`0590e3b2b593d2e2c0abb32f9f732d45f6d1701f3c2f906d07975ddf39c0bbc9`.
The normalized identity SHA-256 remains
`86df9bf4b128d164b88a96d4dfa2441094dbeeaa514b2587fa73c5ac0f3cdab5`;
the exact delta is zero removals and zero additions. The distribution remains
202 TS2345, 70 TS7006, 59 TS2339, 16 TS1361, 12 TS2322, 8 TS2304, 4 TS7031,
4 TS2554, 4 TS2430, 3 TS2488, 3 TS2411, 2 TS4110, 2 TS2749, 2 TS2741,
2 TS2698, 2 TS2552, 2 TS2367, 2 TS18048, and 1 TS2571.

The unchanged output proves at least one additional edge in Zod's much larger
`VisitHandlers` source graph remains unsupported; this checkpoint does not
guess or approximate it. Zod still has diagnostics while TypeScript reports
zero, so it stays outside cross-compiler timing. Elapsed times are also
excluded because the shared host was contended; this section makes no
performance claim.

Final gates pass the exact three-engine oracle, **194/194** complete Program
tests, the complete checker suite, ReleaseFast, `zig fmt --check`, and
`git diff --check`. The required repository-wide Pickier run remains red on
unchanged existing debt: 22,427 findings (11,834 errors and 10,593 warnings).
Production evidence is retained on
[#668](https://github.com/home-lang/home/issues/668#issuecomment-5561082067).

```sh
zig build test -Dfilter=ts_program
zig build test -Dfilter=ts_checker
zig build -Doptimize=ReleaseFast
./zig-out/bin/home-tsc --project=/path/to/imported-conditional-handler/tsconfig.json --pretty=false
./zig-out/bin/home-tsc --project=/path/to/zod-4.5.2/tsconfig.benchmark.json --pretty=false
bunx --bun pickier .
```

### Imported indexed-access mapped key domains

Issue [#669](https://github.com/home-lang/home/issues/669), under
[#548](https://github.com/home-lang/home/issues/548), isolates mapped handler
keys named through a source-owned indexed-access alias. Commit
[`12e1c1d6c`](https://github.com/home-lang/home/commit/12e1c1d6c46347271311ac54205c242b2831f260)
resolves the transported mapped constraint before binding it to the mapped
parameter. When the indexed object resolves to a union, the checker now uses
the existing exact indexed-access relation, which requires every union member
to own the key and unions their value types. Non-union objects retain the
direct named-member path.

This is a general type-graph operation. It does not inspect a package, path,
alias, property spelling, source location, diagnostic, or callback value. A
failed access is not widened to `string`, `any`, or an invented property
domain. Commit
[`1ea1d2a7a`](https://github.com/home-lang/home/commit/1ea1d2a7a3a5071ddae1db3e2c06b663c2e74d72)
pins that rule directly: a complete two-member union resolves to `"a" | "b"`,
while a missing member and a partially covered union return no exact result in
both argument and conditional-infer paths.

The strict two-file oracle uses a nested discriminant matching Zod's public
shape without using Zod names or files:

```ts
interface A { _zod: { def: { type: "a" } }; a: number }
interface B { _zod: { def: { type: "b" } }; b: string }
type Item = A | B;
type Kind = Item["_zod"]["def"]["type"];
type ItemOfKind<K extends Kind> = Extract<Item, { _zod: { def: { type: K } } }>;
type Handlers = { [K in Kind]?: (item: ItemOfKind<K>, rewritten: boolean) => Item };
```

An imported overloaded `visit` call supplies property `a`. Independent
positive and negative controls verify the exact key domain, callback types,
and rejected operations:

| Imported indexed-domain control | TypeScript 6.0.3 | Native TypeScript preview | ReleaseFast Home |
|---|---:|---:|---:|
| Accepted `Kind` keys | `"a"`, `"b"` | `"a"`, `"b"` | **`"a"`, `"b"`** |
| Rejected key | TS2322 against `"a" \| "b"` | TS2322 against `"a" \| "b"` | **TS2322 against `"a" \| "b"`** |
| Property `a` callback item / rewritten value | `A` / `boolean` | `A` / `boolean` | **`A` / `boolean`** |
| Implicit callback parameters / whole call | no TS7006/TS2345 | no TS7006/TS2345 | **no TS7006/TS2345** |
| Complete invalid-control multiset | 2× TS2322, 2× TS2339 | 2× TS2322, 2× TS2339 | **2× TS2322, 2× TS2339** |

The unchanged pinned 106-file Zod 4.5.2 graph remains the production
admission guard:

| Zod 4.5.2 indexed mapped-key audit | #668 main | #669 `12e1c1d6c` | Change |
|---|---:|---:|---:|
| All diagnostics | 400 | **400** | **unchanged; 0 added** |
| Unique diagnostic identities | 395 | **395** | **unchanged; 0 added** |
| Unique identities versus immutable baseline | 597 | **395** | **202 removed overall; 0 added** |

The #668 baseline and two independent #669 candidate runs are byte-identical,
with stderr SHA-256
`0590e3b2b593d2e2c0abb32f9f732d45f6d1701f3c2f906d07975ddf39c0bbc9`.
The normalized identity SHA-256 remains
`86df9bf4b128d164b88a96d4dfa2441094dbeeaa514b2587fa73c5ac0f3cdab5`;
the exact delta is zero removals and zero additions. The distribution remains
202 TS2345, 70 TS7006, 59 TS2339, 16 TS1361, 12 TS2322, 8 TS2304, 4 TS7031,
4 TS2554, 4 TS2430, 3 TS2488, 3 TS2411, 2 TS4110, 2 TS2749, 2 TS2741,
2 TS2698, 2 TS2552, 2 TS2367, 2 TS18048, and 1 TS2571.

The focused gap is closed, but the unchanged corpus proves that another edge
in Zod's larger handler declaration graph remains unsupported. Zod therefore
stays outside cross-compiler timing until Home matches TypeScript's
zero-diagnostic result. Elapsed times are also excluded because the shared
host was contended; this section makes no performance claim.

Final gates pass the exact three-engine oracle, **195/195** complete Program
tests, the complete checker suite (including a second pass after the negative
guard), focused schema and indexed-access tests, ReleaseFast,
`zig fmt --check`, and `git diff --check`. The required repository-wide
Pickier run remains red on unchanged existing debt: 22,427 findings (11,834
errors and 10,593 warnings). Production evidence is retained on
[#669](https://github.com/home-lang/home/issues/669#issuecomment-5561267845).

```sh
zig build test -Dfilter=ts_program
zig build test -Dfilter=ts_checker
zig build -Doptimize=ReleaseFast
./zig-out/bin/home-tsc --project=/path/to/indexed-mapped-handler/tsconfig.json --pretty=false
./zig-out/bin/home-tsc --project=/path/to/zod-4.5.2/tsconfig.benchmark.json --pretty=false
bunx --bun pickier .
```

### Qualified namespace declaration graph admission

Issue [#670](https://github.com/home-lang/home/issues/670), under
[#548](https://github.com/home-lang/home/issues/548), isolates a three-module
Program boundary where an exported type graph refers to its dependencies
through a namespace import. Commit
[`24f4376f1`](https://github.com/home-lang/home/commit/24f4376f1ed1a1e3c668082f466d11c817ac5bc6)
replaces the former scalar-union-only rule with an identity-aware proof over
the complete qualified declaration graph.

The proof admits only expression forms already represented losslessly by the
Program schema: objects and indexed objects, arrays, tuples, callable types,
mapped and conditional types, indexed access, `keyof`, exact `Extract`, and
their declaration and parameter identities. It rejects opaque or unsupported
leaves, projection-only and contextual-projection edges, contextual-only
declarations, classes, declared functions, records, `typeof` classes,
unsupported utilities, and built-in generic approximations. It neither
flattens a namespace nor substitutes `any`. The existing callable-shell path
for a qualified opaque leaf remains contextual-only.

The strict oracle separates the declaration owner, the namespace-qualified
handler owner, and the consumer:

```ts
// schemas.ts
interface A { _zod: { def: { type: "a" } }; a: number }
interface B { _zod: { def: { type: "b" } }; b: string }
interface TypeDef { type: "a" | "b" }
type Types = A | B;

// visit.ts
import * as schemas from "./schemas.js";
type Kind = schemas.TypeDef["type"];
type TypeOfKind<K extends Kind> = Extract<
  schemas.Types,
  { _zod: { def: { type: K } } }
>;
type Handlers = { [K in Kind]?: (item: TypeOfKind<K>, rewritten: boolean) => schemas.Types };
```

An overloaded `visit` declaration and a third-file handler object retain the
exact key and callback types:

| Qualified three-module control | TypeScript 6.0.3 | Native TypeScript preview | ReleaseFast Home |
|---|---:|---:|---:|
| Accepted keys | `"a"`, `"b"` | `"a"`, `"b"` | **`"a"`, `"b"`** |
| Rejected key | TS2322 against `"a" \| "b"` | TS2322 against `"a" \| "b"` | **TS2322 against `"a" \| "b"`** |
| Callback item / rewritten value | `A` / `boolean` | `A` / `boolean` | **`A` / `boolean`** |
| Implicit callback parameters / whole call | no TS7006/TS2345 | no TS7006/TS2345 | **no TS7006/TS2345** |
| Complete invalid-control multiset | 2× TS2322, 2× TS2339 | 2× TS2322, 2× TS2339 | **2× TS2322, 2× TS2339** |

Permanent schema coverage also verifies that a fully supported qualified
object is no longer projection-only, while the existing qualified `Set`
callback retains its opaque contextual shell.

The unchanged pinned 106-file Zod 4.5.2 graph produces a real improvement:

| Zod 4.5.2 qualified declaration audit | #669 main | #670 `24f4376f1` | Change |
|---|---:|---:|---:|
| All diagnostics | 400 | **394** | **6 TS2339 removed; 0 added** |
| Unique diagnostic identities | 395 | **389** | **6 removed; 0 added** |
| Unique identities versus immutable baseline | 597 | **389** | **208 removed overall; 0 added** |

The six removed identities are all false TS2339 reports in
`src/v4/classic/errors.ts`: one at line 61, two at line 62, one at line 65,
and two at line 66. Two independent candidate runs are byte-identical, with
stderr SHA-256
`67875e08fc1bbe6fe9d18a9ac0396cbfe7afa166dd1b71830ab4cd3e705557e6`.
The normalized identity SHA-256 is
`dd266a4d67c6f5575d6ab19d80d37d0eec97fa06be26e8eb04cef5113596d643`.
The remaining distribution is 202 TS2345, 70 TS7006, 53 TS2339, 16 TS1361,
12 TS2322, 8 TS2304, 4 TS7031, 4 TS2554, 4 TS2430, 3 TS2488, 3 TS2411,
2 TS4110, 2 TS2749, 2 TS2741, 2 TS2698, 2 TS2552, 2 TS2367, 2 TS18048,
and 1 TS2571.

A disposable production control replaced only the relevant
`schemas.Qualified` type spellings in `core/visit.ts` with equivalent named
imports. Its normalized corpus identity set remains the same as the #670
candidate; only the edited file's line number shifts. The 16 callback TS7006
reports in `classic/in-out.ts` and `mini/in-out.ts` are therefore a separate
downstream graph gap, not attributed to this admission fix.

Zod still has diagnostics while TypeScript reports zero, so it remains
outside cross-compiler timing. Elapsed times are also excluded because the
shared host was contended; this section makes no performance claim.

Final gates pass the exact three-engine oracle, **196/196** complete Program
tests, the complete checker suite, ReleaseFast, `zig fmt --check`, and
`git diff --check`. The required repository-wide Pickier run remains red on
unchanged existing debt: 22,427 findings (11,834 errors and 10,593 warnings).
Production evidence is retained on
[#670](https://github.com/home-lang/home/issues/670#issuecomment-5561365837).

```sh
zig build test -Dfilter=ts_program
zig build test -Dfilter=ts_checker
zig build -Doptimize=ReleaseFast
./zig-out/bin/home-tsc --project=/path/to/qualified-handler/tsconfig.json --pretty=false
./zig-out/bin/home-tsc --project=/path/to/zod-4.5.2/tsconfig.benchmark.json --pretty=false
bunx --bun pickier .
```

### Contextual Extract paths beside opaque siblings

Issue [#671](https://github.com/home-lang/home/issues/671), under
[#548](https://github.com/home-lang/home/issues/548), follows the qualified
declaration admission from #670 into a stricter production shape. A useful
discriminant path and an unsupported sibling such as `Set<string>` can belong
to the same imported object. Previously the unsupported sibling collapsed the
mapped callback parameter to an opaque leaf, producing false TS7006 reports.
Commit
[`290487c0f`](https://github.com/home-lang/home/commit/290487c0fddb87063ac6463a6256294a079c0b16)
preserves the discriminant without treating the complete declaration as
lossless.

The schema builder enables declaration projection specifically while lowering
mapped callback values. The admitted reference must have a body and cannot be
a class or declared function. It remains contextual-only, so the unsupported
declaration is not published as an ordinary complete type.

For contextual `Extract`, the checker follows only paths present in the
structural target. Source objects retain their member names; target-relevant
members are projected recursively, unresolved relevant paths become
`unknown`, and unrelated sibling values remain locally opaque. Declaration
and generic-parameter identities carry substitutions across aliases. An
active-declaration set terminates cycles. The projected union then uses the
ordinary distributive conditional evaluator, so generic discriminants remain
symbolic until mapped-key specialization. There is no source-name check,
library-specific branch, or arbitrary recursion-depth limit.

The strict three-module oracle adds an unsupported sibling to both union
members while leaving the selected path nested beneath `_zod.def.type`:

```ts
// schemas.ts
interface A {
  _zod: { def: { type: "a" }; opaque: Set<string> };
  a: number;
}
interface B {
  _zod: { def: { type: "b" }; opaque: Set<string> };
  b: string;
}
type Types = A | B;

// visit.ts
import * as schemas from "./schemas.js";
type TypeOfKind<K extends "a" | "b"> = Extract<
  schemas.Types,
  { _zod: { def: { type: K } } }
>;
type Handlers = {
  [K in "a" | "b"]?: (item: TypeOfKind<K>, rewritten: boolean) => schemas.Types;
};
```

The consumer assigns the `a` callback item to `A`, rejects it as `number`,
reads the missing `b` member, reads a missing member from `rewritten`, and
includes one invalid mapped key. The exact result is:

| Opaque-sibling three-module control | TypeScript 6.0.3 | Native TypeScript preview | ReleaseFast Home |
|---|---:|---:|---:|
| Accepted mapped keys | `"a"`, `"b"` | `"a"`, `"b"` | **`"a"`, `"b"`** |
| Rejected mapped key | TS2322 | TS2322 | **TS2322** |
| Callback item / rewritten value | `A` / `boolean` | `A` / `boolean` | **`A` / `boolean`** |
| Implicit callback parameters / whole call | no TS7006/TS2345 | no TS7006/TS2345 | **no TS7006/TS2345** |
| Complete invalid-control multiset | 2× TS2322, 2× TS2339 | 2× TS2322, 2× TS2339 | **2× TS2322, 2× TS2339** |

The pinned 106-file Zod 4.5.2 graph confirms that the narrower projection is a
production improvement rather than a synthetic-only change:

| Zod 4.5.2 contextual-path audit | #670 main | #671 `290487c0f` | Change |
|---|---:|---:|---:|
| All diagnostics | 394 | **374** | **20 TS7006 removed; 0 added** |
| Unique diagnostic identities | 389 | **369** | **20 removed; 0 added** |
| Unique identities versus immutable baseline | 597 | **369** | **228 removed overall; 0 added** |

The removed identities are eight callback parameters in each of
`classic/in-out.ts` and `mini/in-out.ts`, plus two callback parameters in each
of `classic/deep-partial.ts` and `mini/deep-partial.ts`. No diagnostic identity
was added. Two independent candidate runs are byte-identical, with stderr
SHA-256
`5353246e2b9172390011adff013f5807c60da3019b28e34f3d814e50d80fcf80`.
The normalized identity SHA-256 is
`30f2defec18b4b81b6795a59a626cd00ffccb69bbdaface112ba1d7d25982bb7`.
The remaining distribution is 202 TS2345, 53 TS2339, 50 TS7006, 16 TS1361,
12 TS2322, 8 TS2304, 4 TS7031, 4 TS2554, 4 TS2430, 3 TS2488, 3 TS2411,
2 TS4110, 2 TS2749, 2 TS2741, 2 TS2698, 2 TS2552, 2 TS2367, 2 TS18048,
and 1 TS2571.

A bounded Zod closure that exposed crashes in discarded eager projections
completed normally in 20.57 seconds with the ReleaseFast candidate. Zod still
has diagnostics while TypeScript reports zero, so it remains outside
cross-compiler timing. The audit makes no cross-compiler performance claim.

Final gates pass the exact three-engine oracle, **201/201** complete Program
tests, the complete checker suite, ReleaseFast, `zig fmt --check`, and
`git diff --check`. The required repository-wide Pickier run remains red on
unchanged existing debt: 22,427 findings (11,834 errors and 10,593 warnings).
Production evidence is retained on
[#671](https://github.com/home-lang/home/issues/671#issuecomment-5561759700).

```sh
zig build test -Dfilter=ts_program
zig build test -Dfilter=ts_checker
zig build home-tsc -Doptimize=ReleaseFast
./zig-out/bin/home-tsc --project=/path/to/opaque-sibling-handler/tsconfig.json --pretty=false
./zig-out/bin/home-tsc --project=/path/to/zod-4.5.2/tsconfig.benchmark.json --pretty=false
bunx --bun pickier .
```

### Impossible truthy property branches

Issue [#672](https://github.com/home-lang/home/issues/672), under
[#548](https://github.com/home-lang/home/issues/548), isolates a core flow
error found while examining the remaining Zod locale diagnostics. A property
that is impossible on one union variant can have the static type
`never | T[] | undefined`. In a truthy branch, Home previously removed only
the nullish constituent and retained `never | T[]`, blocking normal array
member lookup and callback context.

Commit
[`673a648a9`](https://github.com/home-lang/home/commit/673a648a972f8aa3c6f1de4cfa2d1a027d1972aa)
routes stable member values through the checker's existing semantic truthy
partition. That partition removes impossible `never` and falsy unit
constituents while retaining broad primitives whose truthy subsets cannot be
represented as a narrower type. The fix does not inspect property names,
array methods, source text, or libraries.

The strict control combines a direct truthy branch with an `Array.isArray`
chain and one intentional assignment error:

```ts
type Primitive = string | number | boolean;
interface Present { options?: Primitive[] }
interface Impossible { options?: never }
declare const issue: Present | Impossible;

if (issue.options) {
  issue.options.map(value => value);
}

if (issue.options && Array.isArray(issue.options) && issue.options.length > 0) {
  issue.options.map(value => {
    const exact: Primitive = value;
    const wrong: never = value;
    return value;
  });
}
```

| Truthy-property control | TypeScript 6.0.3 | Native TypeScript preview | ReleaseFast Home |
|---|---:|---:|---:|
| Truthy `.map` access | accepted | accepted | **accepted** |
| `Array.isArray` length/map access | accepted | accepted | **accepted** |
| Callback value | `Primitive` | `Primitive` | **`Primitive`** |
| Complete invalid-control multiset | 1× TS2322 | 1× TS2322 | **1× TS2322** |
| False TS2339 / TS7006 | none | none | **none** |

The production A/B is deliberately reported as a negative result. Two pinned
106-file Zod 4.5.2 candidate runs are byte-identical to the exact #671 parent:

| Zod 4.5.2 truthy-property audit | #671 main | #672 `673a648a9` | Change |
|---|---:|---:|---:|
| All diagnostics | 374 | **374** | **unchanged; 0 added** |
| Unique diagnostic identities | 369 | **369** | **unchanged; 0 added** |
| Unique identities versus immutable baseline | 597 | **369** | **228 removed overall; 0 added** |

Raw stderr remains byte-identical with SHA-256
`5353246e2b9172390011adff013f5807c60da3019b28e34f3d814e50d80fcf80`.
The unchanged corpus disproves the initial hypothesis that this impossible
branch caused the 10 locale TS7006 reports; that family requires a separate
reduction. No performance claim is made while Home and TypeScript differ in
correctness on Zod.

Final gates pass the exact three-engine oracle, the focused permanent checker
test, the complete checker suite, **201/201** Program tests, ReleaseFast,
`zig fmt --check`, and `git diff --check`. The required repository-wide
Pickier run remains red on unchanged existing debt: 22,427 findings (11,834
errors and 10,593 warnings). Evidence is retained on
[#672](https://github.com/home-lang/home/issues/672#issuecomment-5561862625).

```sh
zig build test -Dfilter=ts_checker
zig build test -Dfilter=ts_program
zig build home-tsc -Doptimize=ReleaseFast
./zig-out/bin/home-tsc --project=/path/to/truthy-property/tsconfig.json --pretty=false
./zig-out/bin/home-tsc --project=/path/to/zod-4.5.2/tsconfig.benchmark.json --pretty=false
bunx --bun pickier .
```

### Imported homomorphic union callback context

Issue [#673](https://github.com/home-lang/home/issues/673), under
[#548](https://github.com/home-lang/home/issues/548) and
[#416](https://github.com/home-lang/home/issues/416), isolates imported
callback context lost through a distributive, homomorphic utility pipeline.
The source callback receives a union transformed by `Pick`, `Exclude`, a
partial mapped type, an intersection, and `Record<string, unknown>`. Home
previously retained the callback shell but lost the readable discriminant and
array member surface, producing false TS7006 and TS2339 diagnostics.

Commit
[`a730be062`](https://github.com/home-lang/home/commit/a730be062)
transfers the utility structure rather than recognizing an application or
identifier. Program schemas now describe `Exclude`, optional-key coverage,
and open string-index contributions. The checker reconstructs only the
proven readable surface, narrows imported unions by their discriminant,
preserves member `Array.isArray` flow, and resolves exact nested indexed
constraint proofs from their declaration syntax. Unsupported siblings remain
opaque and never become approximate whole types.

The strict three-module control mirrors the production ownership boundary:

```ts
type RawIssue<T extends IssueBase> = T extends any
  ? Flatten<
      MakePartial<T, "message" | "path"> &
        { readonly input: unknown } &
        Record<string, unknown>
    >
  : never;

export type ErrorMap<T extends IssueBase = Issue> =
  (issue: RawIssue<T>) => string | undefined;

export const error: () => ErrorMap = () => issue => {
  if (issue.code === "invalid_union" &&
      issue.options &&
      Array.isArray(issue.options) &&
      issue.options.length > 0) {
    return issue.options.map(value => {
      const exact: Primitive = value;
      const wrong: never = value;
      return `${value}`;
    }).join(" | ");
  }
  return undefined;
};
```

| Homomorphic-union three-module control | TypeScript 6.0.3 | Native TypeScript preview | ReleaseFast Home |
|---|---:|---:|---:|
| Callback `issue` parameter | contextual | contextual | **contextual** |
| Discriminated `options` member | accepted | accepted | **accepted** |
| Array callback `value` | `any` | `any` | **`any`** |
| Complete invalid-control multiset | 1× TS2322 | 1× TS2322 | **1× TS2322** |
| False TS7006 / TS2339 / TS2344 | none | none | **none** |

The constraint regression separately covers all five imported nested-index
forms used by Zod: base schema, check, optional check, string-format union,
and schema/check intersection. This caught and rejected an earlier broad
intersection implementation that changed nine unrelated diagnostic messages;
the retained traversal is confined to semantic constraint proofs.

The pinned 106-file Zod 4.5.2 graph provides the production A/B against the
exact post-#672 parent:

| Zod 4.5.2 homomorphic-union callback audit | #672 `307892be9` | #673 `a730be062` | Change |
|---|---:|---:|---:|
| All diagnostics | 374 | **350** | **24 removed (6.4%); 0 added** |
| Unique path/line/column/code identities | 369 | **345** | **24 removed; 0 added** |
| Removed identities | — | 11 TS7006, 9 TS2339, 4 TS2345 | **24 total** |

Two sequential ReleaseSafe candidate runs are byte-identical: stdout is empty
and stderr SHA-256 is
`62f115f3549509b7a392e0173a3a285b85b1691d81fc672bed435db4d566a2eb`.
Their wall times were 68.84 and 71.47 seconds. The remaining distribution is
198 TS2345, 44 TS2339, 39 TS7006, 16 TS1361, 12 TS2322, 8 TS2304,
4 TS7031, 4 TS2554, 4 TS2430, 3 TS2488, 3 TS2411, 2 TS4110,
2 TS2749, 2 TS2741, 2 TS2698, 2 TS2552, 2 TS2367, 2 TS18048,
and 1 TS2571.

The complete Program and checker targets pass, including all 4,364 checker
tests. ReleaseSafe and ReleaseFast builds, `zig fmt --check`, and
`git diff --check` pass. The repository-wide Pickier result is unchanged at
22,427 existing findings (11,834 errors and 10,593 warnings). Evidence is
retained on
[#673](https://github.com/home-lang/home/issues/673#issuecomment-5568630029).
Zod still differs from both TypeScript engines, so this audit makes no
cross-compiler timing claim.

```sh
zig build test -Dfilter=ts_program
zig build test -Dfilter=ts_checker
zig build home-tsc -Doptimize=ReleaseSafe
zig build home-tsc -Doptimize=ReleaseFast
./zig-out/bin/home-tsc --project=/path/to/homomorphic-union/tsconfig.json --pretty=false
./zig-out/bin/home-tsc --project=/path/to/zod-4.5.2/tsconfig.benchmark.json --pretty=false
bunx --bun pickier .
```

### Imported Promise-union returns and terminating guards (untimed)

Issue [#687](https://github.com/home-lang/home/issues/687), under
[#548](https://github.com/home-lang/home/issues/548) and
[#416](https://github.com/home-lang/home/issues/416), fixes the complete
cross-module path for `T | Promise<T>`. Commit
[`901c0d0ec`](https://github.com/home-lang/home/commit/901c0d0ec203e51c84a4a914d05976728a4b3bcf)
admits parameterized built-ins that the Program schema already serializes
losslessly, recognizes the checker's structural Promise marker when
subtracting an `instanceof Promise` branch, and compares the inferred return
union of a multi-statement assigned function instead of rejecting that body
shape unconditionally.

The fair oracle uses separate owner and consumer modules. The owner exports a
generic `MaybeAsync<T>` alias, payload and schema interfaces; the consumer
exercises a direct annotation, a generic contextual function alias, a direct
exported function return, and a member-assigned implementation with both
synchronous and Promise returns. The invalid control assigns the exact
`string` callback element to `number`, proving that silence is not caused by
`any`:

| Multi-module Promise-union oracle | TypeScript 6.0.3 | Native TypeScript preview | ReleaseSafe Home |
|---|---:|---:|---:|
| Valid diagnostics | 0 | 0 | **0** |
| Post-guard payload members | exact | exact | **exact** |
| Array callback parameter | `string` | `string` | **`string`** |
| Mixed sync/Promise implementation | accepted | accepted | **accepted** |
| Complete invalid-control multiset | 1× TS2322 | 1× TS2322 | **1× TS2322** |
| False TS7006 / TS2339 | none | none | **none** |

The unchanged pinned 106-file Zod 4.5.2 graph supplies the production
admission gate against the exact post-#673 parent:

| Zod 4.5.2 imported Promise-union audit | #673 `4d5d3d5a9` | #687 `901c0d0ec` | Change |
|---|---:|---:|---:|
| All diagnostics | 350 | **348** | **2 removed (0.6%); 0 added** |
| Unique path/line/column/code identities | 345 | **343** | **2 removed; 0 added** |
| Removed identities | — | 2 TS7006 | `core/schemas.ts:3167:45`, `3256:45` |

Two sequential ReleaseSafe candidate runs have empty stdout and byte-identical
diagnostic payloads after excluding the three timing lines. Their SHA-256 is
`11fa7bc0af25a25aa821eae7a0b26704a821f72b0bdca5adbd350a7f19deec13`;
wall times were 61.80 and 58.21 seconds. The remaining distribution is
198 TS2345, 44 TS2339, 37 TS7006, 16 TS1361, 12 TS2322, 8 TS2304,
4 TS7031, 4 TS2554, 4 TS2430, 3 TS2488, 3 TS2411, 2 TS4110,
2 TS2749, 2 TS2741, 2 TS2698, 2 TS2552, 2 TS2367, 2 TS18048,
and 1 TS2571.

The benchmark also rejected two broader approaches. Consumer-side resolved
type provenance did not change the imported oracle. Projecting a whole opaque
generic constraint on demand produced 356 diagnostics and 351 unique
identities: it removed six old identities but added twelve unrelated ones, so
none of that code was retained. Four `core/parse.ts` TS7006 sites remain after
the Promise path is exact because their nested
`ParsePayload.issues: errors.$ZodRawIssue[]` element type is still opaque; that
separate qualified-type transfer is tracked in
[#688](https://github.com/home-lang/home/issues/688).

The complete Program and checker targets pass (205 and 4,365 tests), as do
ReleaseSafe and ReleaseFast builds, `zig fmt --check`, and `git diff --check`.
Repository-wide Pickier remains at the unchanged baseline of 22,427 findings
(11,834 errors and 10,593 warnings). Full evidence is retained on
[#687](https://github.com/home-lang/home/issues/687#issuecomment-5570569763).
Zod still differs from both TypeScript engines, so this audit makes no
cross-compiler timing claim.

```sh
zig build test -Dfilter=ts_program
zig build test -Dfilter=ts_checker
zig build -Doptimize=ReleaseSafe
zig build -Doptimize=ReleaseFast
./zig-out/bin/home-tsc --project=/path/to/promise-union/tsconfig.json --pretty=false
./zig-out/bin/home-tsc --project=/path/to/zod-4.5.2/tsconfig.benchmark.json --pretty=false
bunx --bun pickier .
```

### Qualified Program constraints and contextual issue arrays (untimed)

Issue [#688](https://github.com/home-lang/home/issues/688), under
[#548](https://github.com/home-lang/home/issues/548) and
[#416](https://github.com/home-lang/home/issues/416), finishes the path that
[#687](https://github.com/home-lang/home/issues/687) left open: four Zod
`core/parse.ts` callbacks whose `issue` parameter stayed implicitly `any`
behind `ParsePayload.issues: errors.$ZodRawIssue[]`.

Three independent defects composed the failure:

- **Constraints.** A type parameter whose `extends` clause names a type
  reached through a qualified import (`<T extends schemas.Schema>`) lowered to
  `any`, so every member read off `T` widened. All five declaration forms that
  own type parameters (function types, function declarations, classes,
  interfaces, and type aliases) now lower the clause through one helper that
  resolves the qualified reference, or its contextual Program projection, only
  when plain lowering produced `any`.
- **Awaited unions.** Commit
  [`bb5e06956`](https://github.com/home-lang/home/commit/bb5e069569cafe2e854366876862e43f50fa1eb7)
  fixes `await` on `A | Promise<A>`, which left the union intact.
  `Awaited<T>` distributes over unions, so each constituent is awaited and the
  results are rejoined (`Promise<A> | Promise<B>` awaits to `A | B`). A union
  is no longer probed for a `then` member as a whole.
- **Projection scope.** The issue-array element type is available only as a
  contextual Program *read* projection. It now types callbacks passed to array
  methods on that member (`issues.map((issue) => ...)`) and is never
  substituted as the member's value type, which is how `main` already scopes
  `programImportedClassContextualMemberType`.

The acceptance oracle is the four-module graph at
`/private/tmp/home-goal-688-oracle`: separate `util`, `errors`, `schemas`, and
`consumer` modules; a namespace-qualified distributive raw-issue alias; a
direct annotation; and synchronous and `let`/`await` generic parse paths. Each
callback assigns the element to `number`, so exact context is proven rather
than inferred from silence:

| #688 oracle and controls (file:line:column:code) | TypeScript 6.0.3 | Native TypeScript 7.0.2 | ReleaseSafe Home | `main` |
|---|---:|---:|---:|---:|
| Acceptance oracle | 3× TS2322 (7:9, 18:11, 31:11) | **identical** | **identical** | 3× TS7006 |
| Function declaration and class constraints | 2× TS2322 (7:11, 19:13) | **identical** | **identical** | 2× TS7006 |
| Valid raw-issue pushes beside typed callbacks | 2× TS2322 (7:9, 18:11) | **identical** | **identical** | 2× TS7006 |
| `await` over `Payload \| Promise<Payload>` and `Promise<Payload> \| Promise<string>` | 2× TS2322 (7:9, 9:9) | **identical** | **identical** | 2× TS2339, TS7006, TS2322 |

The Program suite encodes the first three graphs and the checker suite the
fourth. The oracle test uses the on-disk modules verbatim.

The unchanged 21-file Zod 4.5.2 `core` graph (`tsconfig.core.json`) is the
production admission gate against `main` `65f80a525`:

| Zod 4.5.2 core, qualified constraints | `main` `65f80a525` | #688 | Change |
|---|---:|---:|---:|
| All diagnostics | 150 | **146** | **4 removed (2.7%); 0 added** |
| Unique path/line/column/code identities | 145 | **141** | **4 removed; 0 added** |
| Removed identities | — | 4 TS7006 | `core/parse.ts:30:63`, `54:62`, `81:66`, `101:44` |

Every other code count is unchanged: 44 TS2345, 21 TS7006, 20 TS2339,
16 TS1361, 11 TS2322, 5 TS2304, 4 TS7031, 4 TS2554, 4 TS2430, 3 TS2488,
3 TS2411, 2 TS2749, 2 TS2741, 2 TS2552, 2 TS2367, 2 TS18048, and 1 TS2571.

Three other shapes were measured first:

- The inherited candidate substituted the contextual read projection as the
  issue array's value type. It removed the same four TS7006 but added twelve
  TS2345 identities at `core/schemas.ts` string-format checks
  (`payload.issues.push({ code: "invalid_format", ... })`). The displayed
  projection keeps `path` and `message` required, whereas `$ZodRawIssue` makes
  them optional, and every valid push tested failed. The substitution was
  replaced by the contextual-only scope above.
- Exposing flow narrowings below a function's lookup floor to contextual
  signature probes was unnecessary once constraints resolved. It also leaked
  narrowings into nested functions and added `core/schemas.ts:2002:9` TS2322,
  so it was removed.
- Routing only the function-type constraint site passed the acceptance oracle
  but left function declarations and classes at TS7006, so the helper now
  serves all five sites.

Bisection against `main` attributes the additions. The candidate
`class_schema.zig` alone adds three TS2801 identities (`core/checks.ts:821:9`,
`core/schemas.ts:2975:9`, `3789:14`). The full candidate without the
distributive `await` still adds `core/checks.ts:821:9`, and with it none remain.
The candidate `check.zig` alone, with `main`'s schema, adds exactly the twelve
TS2345.

The complete Program and checker targets pass (210 and 4,371 tests), as do
ReleaseSafe and ReleaseFast `home-tsc` builds, `zig fmt --check`, and
`git diff --check`. The distributive `await` commit was verified on its own
first: 4,371 checker and 205 Program tests, a ReleaseSafe build, exact
three-engine parity on its focused graph, and an unchanged Zod core
(150 diagnostics, 145 identities; none added or removed). No timing is
claimed.

### Annotated receivers of imported Program types (untimed)

Issue [#751](https://github.com/home-lang/home/issues/751), under
[#548](https://github.com/home-lang/home/issues/548) and
[#416](https://github.com/home-lang/home/issues/416), continues
[#688](https://github.com/home-lang/home/issues/688). A constraint naming an
imported type now resolves, but the same type written as an ordinary
annotation did not: a parameter, a declared binding, a written type argument,
a class parameter property, or a named import left the value `any`, so every
callback read through it reported a false TS7006.

Two changes carry the fix, and neither is observable alone.

- **Member scope.** A receiver whose checked type is `any` keeps that type;
  only the members it explicitly reads are lowered from the owning
  declaration. This is the scope `main` already gives a qualified assertion
  (`programQualifiedAssertionMemberType`), extended to the written type of a
  binding, a class field, and interface members reached through bound type
  arguments (`holder: Holder<schemas.Schema>` makes `holder.schema` name
  `schemas.Schema`). Relations never observe an approximate whole type.
- **Definition rollback.** Lowering a declaration that contains an
  unsupported leaf raises `UnsupportedProgramType`, and the failure previously
  cleared *every* Program cache, including completed imported-class
  registrations. Type identities are allocated monotonically, so the rollback
  now drops only entries at or above the identity watermark taken when the
  attempt began.

Publishing the whole projection as the annotation's type was measured and
rejected: it added 38 Zod identities (30 TS7006 in `core/compile.ts`, plus
TS2322, TS2345, TS2559, and TS18048 approximation mismatches), because
assignments and contextual typing then observe the approximation. Member
scope without the rollback still added 29 of those TS7006: reading
`schema._zod` on Zod's `SomeType` fails, and the old blanket clear discarded
the `Doc` class registration that types `doc.indented((d) => ...)`.

| #751 annotation positions (file:line:column:code) | TypeScript 6.0.3 | Native TypeScript 7.0.2 | ReleaseSafe Home | `main` |
|---|---:|---:|---:|---:|
| Parameter annotation | TS2322 at 6:11 | **identical** | **identical** | TS7006 |
| Declared binding | TS2322 at 7:11 | **identical** | **identical** | TS7006 |
| Written type argument | TS2322 at 7:11 | **identical** | **identical** | TS7006 |
| Class parameter property | TS2322 at 8:13 | **identical** | **identical** | TS7006 |
| Named (unqualified) import | TS2322 at 6:11 | **identical** | **identical** | TS7006 |
| Writes into the same types | none | **none** | **none** | none |
| Failed lowering beside an imported class | none | **none** | **none** | none |

Each read assigns the projected element to `number`, so the single TS2322 is
a deliberate control rather than silence. The Program suite encodes all seven
graphs.

The Zod 4.5.2 `core` graph is unchanged against #688 `cfdec2ea3`:

| Zod 4.5.2 core, annotated receivers | #688 `cfdec2ea3` | #751 | Change |
|---|---:|---:|---:|
| All diagnostics | 146 | **146** | **0 added; 0 removed** |
| Unique path/line/column/code identities | 141 | **141** | **0 added; 0 removed** |

That measurement covers the 21 `src/v4/core/**/*.ts` files only. The pinned
tree's `src/v4/locales` shard was deleted by the host's periodic
`/private/tmp` cleanup during this work, so the graph resolves one fewer
module: it reproduces every core identity of the #688 run and differs from it
only by `locales/he.ts:126:47` TS7006 giving way to `core/index.ts:11:26`
TS2307. The locale shard's own identities were unmeasured at that checkpoint;
the restored-source audit below closes that outstanding validation item.

The complete Program and checker targets pass (212 and 4,371 tests), as do
ReleaseSafe and ReleaseFast `home-tsc` builds, `zig fmt --check`, and
`git diff --check`. Removing either half fails a test: without the rollback
only the failed-lowering graph regresses; without member scope the annotation
graphs and both #688 read tests regress. No timing is claimed.

An object literal assigned to one of these annotations still leaves its nested
callback parameters implicitly `any` (`const s: schemas.Schema = { _zod: { run:
(payload) => ... } }`), which both engines type. That contextual-write
position is tracked separately.

#### Restored core and locale validation (2026-10-07)

The exact #688 parent `cfdec2ea3` and #751 fix `8c587f6fb` were rebuilt from
their unchanged Git trees with Zig `0.17.0-dev.1441+d5181a9c9`, ReleaseSafe,
and the existing symbol-stripping option. The standalone TypeScript target
uses `enable_jsc=false` on both revisions. Both builds and every project check
used the same 3,840 MB footprint ceiling. The unstripped parent attempt was
stopped at 3,868 MB; stripped builds completed at 2,853 and 2,901 MB without
raising the limit.

A fresh npm Zod 4.5.2 archive matches the checked-in SHA-512 exactly and
contains all 106 production files. The identical strict NodeNext no-emit
configurations select the 21 core roots and 63 locale roots separately;
ordinary import closure discovery remains enabled. Both TypeScript 6.0.3
and native TypeScript 7.0.2 exit successfully with zero diagnostics on both
projects. All Home runs exit normally with diagnostic status 1.

| Restored historical #751 gate | Parent `cfdec2ea3` | Fix `8c587f6fb` | Complete identity multiset delta |
|---|---:|---:|---:|
| Core roots, all diagnostics / unique identities | 146 / 141 | **146 / 141** | **0 added; 0 removed** |
| Locale roots, all diagnostics / unique identities | 145 / 140 | **145 / 140** | **0 added; 0 removed** |
| TypeScript 6.0.3 and native 7.0.2 | 0 diagnostics | 0 diagnostics | both root selections accepted |

The Hebrew identity `src/v4/locales/he.ts:126:47` TS7006 is present on both
historical revisions, and the missing-module TS2307 from the deleted shard
is absent. The complete diagnostic multisets match, including duplicates.
Sorted unique corpus-relative `path:line:column:code` identity hashes are
`f3d1d7e08a3a587f2b212a518f26d198f52121fff41a5f3317fc1d7674487d7e`
for core and
`44e4149a5a7917e0a0f802b4a85dacb42d6feeeffb55f9622daf3bc9a57a0c73`
for locales. Home project peaks were 2,625 / 2,630 MB for core and
2,669 / 2,600 MB for locales (parent / fix).

The [checksum-covered evidence archive](https://github.com/home-lang/home/raw/main/bench/vs_tsgo/evidence/20261007T203624Z-zod-restored-751.tar.gz)
retains all eight project-check logs, both configurations, compiler hashes,
exit records, counts, and footprint peaks. Private path prefixes in published
logs are normalized; diagnostic text and source excerpts are retained.
Archive SHA-256:
`b74d020f5b7f30507f6b39f8d8637bc32ae4c8c1fbf9649cbd3750f07d49fa91`.
This closes #751's restored-locale acceptance gap. These historical results
are untimed and do not replace current-source full-Zod admission under #548.

### Object literals written against imported Program types (untimed)

Issue [#754](https://github.com/home-lang/home/issues/754), under
[#548](https://github.com/home-lang/home/issues/548) and
[#416](https://github.com/home-lang/home/issues/416), completes
[#751](https://github.com/home-lang/home/issues/751). Members *read* through
an imported type that could only be transferred as a projection resolve, but
values *written* into one did not: an object literal assigned to such an
annotation, passed as a call argument, or written with method shorthand left
its nested callback parameters implicitly `any`.

The literal takes its contextual target from the type that was written rather
than from its checked type: a binding's annotation, the callee's parameter
annotation, or the enclosing literal's member, walked syntactically until a
reference to an imported declaration is reached. An overload set or a name
that walk cannot resolve uniquely yields nothing rather than a guess.

Only the member the literal actually writes is lowered, and only as
*context*. The literal's own type and every assignability check still see
`any`, which is the same scope the read side uses. Publishing the projection
as the annotation's type was measured and rejected under #751 at 38 added Zod
identities, because the approximation then becomes an assignment target.
Context cannot reject a program that plain `any` accepted: it only replaces an
implicit `any` parameter with the declared one.

| #754 write positions (file:line:column:code) | TypeScript 6.0.3 | Native TypeScript 7.0.2 | ReleaseSafe Home | #751 `8c587f6fb` |
|---|---:|---:|---:|---:|
| Binding annotation | TS2322 at 5:13 | **identical** | **identical** | TS7006 at 4:11 |
| Call argument | TS2322 at 6:13 | **identical** | **identical** | TS7006 at 5:11 |
| Method shorthand | TS2322 at 5:13 | **identical** | **identical** | TS7006 at 4:9 |

Each callback assigns its `payload` parameter to `number`, so the single
TS2322 proves the declared type arrived rather than an implicit `any` being
silenced. The #751 read positions and the #688 oracle are unchanged.

Against #751 `8c587f6fb` on the same 21-file Zod 4.5.2 `core` graph:

| Zod 4.5.2 core, written object literals | #751 `8c587f6fb` | #754 | Change |
|---|---:|---:|---:|
| All diagnostics | 146 | **140** | **6 removed (4.1%); 0 added** |
| Unique path/line/column/code identities | 141 | **135** | **6 removed; 0 added** |
| Removed identities | — | 6 TS7006 | `core/api.ts:1850:56`, `core/memoizer.ts:97:9`, `97:16`, `97:25`, `107:9`, `121:10` |

Both removals are the shape the change targets: `const memo: $ZodMemoizer = {
alloc(_inst, payload, empty) { ... } }` is a binding annotation with method
shorthand, and `const def: schemas.$ZodCustomStringFormatDef = { fn: (val) =>
... }` is a binding annotation with an arrow property.

TypeScript 6.0.3 and native 7.0.2 both report exactly one diagnostic on this
graph — the `locales` module the shard omits — and no TS7006 anywhere, so
every diagnostic Home still emits here is a false positive and the six
removals are unambiguous. That also bounds the claim: the measurement covers
the 21 `src/v4/core/**/*.ts` files only, because the pinned tree's
`src/v4/locales` shard was deleted by the host's periodic `/private/tmp`
cleanup during #751. The shard's own identities remain unmeasured.

The complete Program and checker targets pass (213 and 4,371 tests), as do
ReleaseSafe and ReleaseFast `home-tsc` builds, `zig fmt --check`, and
`git diff --check`. The added test fails against `8c587f6fb`, which reports
TS7006 at each of the three positions instead. No timing is claimed.

### Indexed access over a type parameter stays deferred (untimed)

Under [#548](https://github.com/home-lang/home/issues/548) and
[#416](https://github.com/home-lang/home/issues/416). Zod declares
`output<T> = T extends { _zod: { output: any } } ? T["_zod"]["output"] :
unknown` and uses it inside generic internals such as
`$ZodMapInternals<Key extends SomeType = $ZodType>`. When substitution
replaced one type parameter with another, it resolved `Key["_zod"]` at once
through `Key`'s constraint `SomeType`, whose internals declare no `output`.
The result, `SomeType["_zod"]["output"]`, no longer mentioned `Key`, so the
default argument supplied later could not repair it. The access never
resolved, and a `$ZodMap` was rejected against a parameter of type
`$ZodMap`, which prints identically.

TypeScript's `getIndexedAccessType` keeps an access deferred while its
object is generic (`isGenericObjectType`), and reaches the constraint only
when a relation needs one. Home now does the same in four places:

1. Substitution keeps `T[K]` deferred while the substituted object is still a
   type parameter, a deferred access or conditional, or a mapped type over a
   generic constraint.
2. The relation engine relates a deferred `S[K]` source through its base
   constraint, supplied by the checker's existing `indexedAccessBaseConstraint`.
   An indexed-access target is left to the existing rules.
3. A deferred conditional source whose union target no single member accepts
   still reaches the rule that relates both of its branches.
4. The checker's branch-by-branch approximation for a deferred conditional
   argument first asks the engine, which matches two conditionals with
   identical `extends` component-wise. Home can lower one declared,
   constrained type parameter twice; when the target's check type is such a
   copy of the source's, it is renamed back before that comparison.

Rules 2–4 are what the old eager answer used to hide. With deferral alone
(rule 1) the gate below removed the same 45 identities but added 2:
`$ZodDiscriminatedUnion` failed its heritage check through an `optin`
conditional over `Options[number]`, and `_catch` rejected `output<T>` against
its own re-instantiation. Resolving concrete accesses inside the relation
engine instead, before the cause was found, changed nothing. Relating `S[K]`
to `T[J]` component-wise, as TypeScript does, was also measured and dropped:
the engine is lenient toward type-parameter targets, so `Partial<T>[keyof T]`
passed for `T[keyof T]` and a generic `NonNullable` assignment that both
engines reject was accepted. Without it, a namespace-qualified call such as
`util.initialize(catchValue)` with `catchValue: core.output<T>` and
`T extends core.Ztype` reported a false TS2345 that `0d09d38cd` did not,
because the call meets a second lowering of `T`; the renaming in rule 4
closes that case instead.

| Focused oracle (file:line:column:code) | TypeScript 6.0.3 | Native TypeScript 7.0.2 | ReleaseSafe Home | `0d09d38cd` |
|---|---:|---:|---:|---:|
| `h(x)` with `x: Zmap` into `Zmap` | — | **identical** | **identical** | TS2345 at 10:3 |
| `const leaked: number = x._zod.out` | TS2322 at 11:7 | **identical** | **identical** | TS2322 at 11:7 |
| `WrongInternals` pattern from `tag` | TS2430 at 20:11 | **identical** | **identical** | TS2430 at 20:11 |

The TS2322 proves that `out` resolves to `unknown` rather than being
silenced, and the TS2430 proves that the new constraint rule still rejects a
member whose constraint does not fit.

Against `0d09d38cd` on the 21-file Zod 4.5.2 `core` graph:

| Zod 4.5.2 core, deferred indexed access | `0d09d38cd` | Home main | Change |
|---|---:|---:|---:|
| All diagnostics | 140 | **95** | **45 removed (32.1%); 0 added** |
| Unique path/line/column/code identities | 135 | **90** | **45 removed; 0 added** |
| Removed TS2345 | 44 | 3 | 27 `util.defineLazyInternal(inst, ...)`; 14 `handle*Result(..., inst, ...)`, `.then`, `.init`, and `transform` calls |
| Removed TS2430 | 4 | 0 | `$ZodExactOptionalInternals`, `$ZodCodecDef`, `$ZodPreprocessInternals`, `$ZodPreprocess` |

TypeScript 6.0.3 and native 7.0.2 report only the omitted `locales` module
on this graph, so every removal is a false positive gone. One gap is
unchanged: `const wrong: number = util.constantCatch(catchValue)` with
`catchValue: core.output<T>` reports TS2322 in both engines and nothing in
Home, before and after this change.

The complete checker and Program targets pass (4,372 and 214 tests). The
added checker test's source reports the false TS2345 at 10:3 under
`0d09d38cd`'s `home-tsc`, and an extra TS2430 at 17:11 with rule 1 alone.
The added Program test's source reports two TS2345 without rule 4's renaming,
where `0d09d38cd` and both engines report none. The generic `NonNullable`
checker test, which the dropped component-wise rule broke, passes. The #754
and #751 write-context oracles are unchanged. No timing is claimed.

### A local binding shadows a type-only import (untimed)

Under [#548](https://github.com/home-lang/home/issues/548) and
[#416](https://github.com/home-lang/home/issues/416). Zod's `core/util.ts`
imports `import type * as checks` and then writes `const checks =
currDef.checks; const hasChecks = checks && checks.length > 0;` inside
`pick`, `omit`, `extend`, and `partial`. `core/json-schema-processors.ts`
does the same with `const schemas: Record<...> = {}` beside
`import type * as schemas`. Home reported every use of the local as TS1361,
"cannot be used as a value because it was imported using 'import type'".

TypeScript resolves an identifier by walking the value-meaning locals of each
enclosing block, function, and namespace outward, so a local that shadows the
import is found first and is an ordinary value. Home instead decided TS1361
by matching the name against the file's top-level imports, before its own
lexical lookup ran. Only a local that had already recorded a flow narrowing
escaped, which is why an annotated object, an `any`-typed initializer, a
parameter, or a property write was reported and a plainly typed read was not.

Every TS1361 and TS1362 path now asks one shared question first: is a value
binding of that name visible at the use from a nearer scope than the imports?
The binder's scopes say where a symbol is stored, which is wider than where
it is visible: a catch variable is stored for the whole `try`, a case
clause's `let` in the enclosing block, a static block's `var` and every
member in the class. Each declaration is therefore judged by TypeScript's
own containers: a block, `for` head, case block, catch clause, function,
namespace, or class static block, with `var` belonging to the nearest
function-like container. Class members never shadow a bare name, and neither
does a method's own name inside its body. A namespace has a value only when
some statement in it is not a type (TypeScript's `getModuleInstanceState`).
A parameter initializer sees the function's parameters and body function
declarations but not its body variables, classes, or enums, and a parameter
decorator is resolved outside the method. A named function expression sees
its own name. When the
lexical walk misses such a binding, the use no longer falls back to the
import's namespace type. The check that already guarded external type-only
origins now shares this one; its inline walk also counted class scopes. A
genuine type-only value use is reported once per identifier for TS1361 and
TS1362, where narrowing used to re-read the identifier and report it again.

A first version decided shadowing from binder scope membership alone. An
adversarial review with three independent lenses, each finding checked by a
skeptic against both engines, confirmed that it hid real TS1361s in a `try`
or `finally` beside a catch variable, after a case clause's `const`, and for
a type-only namespace inside a namespace. A second round re-ran every
confirmed finding against the reworked check (16 fixed, 9 already wrong the
same way before this change, 4 improved) and a fresh hunter found three more
that the rework itself introduced: a method named like the import, a
namespace made a value by a statement, and a body class seen from a parameter
initializer. All of those cases are in the test below.

| Focused oracle (line:column) | TypeScript 6.0.3 | Native TypeScript 7.0.2 | ReleaseSafe Home | `41d59384a` |
|---|---:|---:|---:|---:|
| Shadowed: `any`, `Record`, and object locals, a parameter, a class expression, a static-block `var`, a named function expression, a nested-block `var`, a namespace instantiated by a statement (lines 3–6, 12, 16–18, 20) | — | **identical** | **identical** | 13× TS1361 at 10 positions |
| Not shadowed: no local, a closed block, a parameter initializer against a body variable or class, a class member, module level, `try`/`finally` beside `catch`, after a case clause, a type-only namespace, a method or accessor sharing the name (lines 7–11, 13–15, 19, 21) | 13× TS1361 at 7:30, 8:65, 9:32, 10:43, 11:18, 11:28, 13:34, 13:91, 14:95, 15:83, 19:37, 19:64, 21:33 | **identical** | **identical** | 13 positions, 3 reported twice |

Against `41d59384a` on the 21-file Zod 4.5.2 `core` graph:

| Zod 4.5.2 core, shadowed type-only imports | `41d59384a` | Home main | Change |
|---|---:|---:|---:|
| All diagnostics | 95 | **79** | **16 removed (16.8%); 0 added** |
| Unique path/line/column/code identities | 90 | **79** | **11 removed; 0 added** |
| Removed identities | — | 11 TS1361 | `core/util.ts:645`, `675`, `706`, `771` (2 each); `core/json-schema-processors.ts:724:18`, `729:7`, `734:14` |

TypeScript 6.0.3 and native 7.0.2 report only the omitted `locales` module
on this graph, so each removal is a false positive gone; the 5 further raw
diagnostics were duplicates of the same identities.

The complete checker and Program targets pass (4,373 and 214 tests). The
added checker test binds the file, so the per-declaration visibility rules
run exactly as `home-tsc` runs them. The earlier oracles for the indexed-access
change, #754, and #751 are unchanged. Several gaps that were already wrong
the same way are left for later: a type parameter or merged namespace export
named like the import, a use after a `for (let ...)` loop or a typeof guard,
names inside functions nested in expressions (which the binder does not
scope), parameter scope changes below ES2020, and the missing TS2440 beside
a top-level declaration. No timing is claimed.

### Callbacks reported as implicit any (untimed)

Under [#758](https://github.com/home-lang/home/issues/758),
[#548](https://github.com/home-lang/home/issues/548) and
[#416](https://github.com/home-lang/home/issues/416). After `832f68544` the
21-file Zod 4.5.2 `core` shard carried 12 TS7006 "Parameter 'x' implicitly
has an 'any' type" and 4 TS7031 "Binding element 'x' implicitly has an
'any' type", none of which TypeScript 6.0.3 or native 7.0.2 reports, plus
2 TS2554 from the same built-in declarations. Every one comes from a
receiver or callee that Home typed `any`: TypeScript reports TS7006 for a
callback contextually typed by `any` too, so each fix gives the value its
real type rather than suppressing the diagnostic. Five land here:

1. **The `Promise` statics returned `any`** (9 sites: `util.ts:365`,
   `schemas.ts:2425`, `:2507`, `:3725`, `:4841`, and the destructured
   `Promise.all([left, right])` pairs at `schemas.ts:2721` and `:3359`).
   Home's built-in `Promise` value models `resolve`, `all`, `race` and
   `any` as `(any) => any`, so `.then` had no contextual parameter type.
   They now return the structural `Promise<T>` their lib signatures
   describe: elements are awaited (`MaybeAsync<T> = T | Promise<T>`
   included, since `Awaited` distributes over a union), an array literal or
   tuple argument infers a tuple as the `readonly unknown[] | []`
   constraint makes TypeScript infer one, an array infers `Awaited<E>[]`,
   and inferred literals widen. A call that has a contextual type keeps the
   old fallback: TypeScript infers from that type back into the arguments,
   so `const p: Promise<"a"> = Promise.resolve("a")` keeps `"a"` and
   `const r: [A, B][] = await Promise.all(xs.map(async …))` turns the
   callback's array literal into tuples. Home cannot replay that, and
   guessing would add false errors.
2. **`Array.from` dropped its `mapfn`** (`compile.ts:1802`, one TS7006 and
   one TS2554). The built-in took a single argument, so
   `Array.from(values, (value) => …)` was both an arity error and an
   uncontextualized callback. The lib overloads' optional `mapfn` and
   `thisArg` are declared now. `Object.create`'s optional property map is
   declared for the same reason (`util.ts:325`, one TS2554).
3. **The `Object.defineProperty` descriptor was `any`** (`util.ts:313`).
   TypeScript's third parameter is `PropertyDescriptor & ThisType<any>`,
   and it is `set?(v: any): void` that types `set(v)`. Declaring it exposed
   two Home-specific traps. `internObjectType` does not deduplicate, so the
   `ThisType<any>` marker the checker registers must be the very one the
   descriptor carries; `LibCache` now holds it. And tsc declares
   `interface ThisType<T> {}` — an empty interface — so a marker must
   impose no structural obligation: the relation engine skips markers when
   an intersection target otherwise demands every member, which is the rule
   the excess-property check already applied. Without that, every
   descriptor value reported a false TS2345.
4. **A later generic function declaration provided no callback context**
   (`api.ts:1696`). `_superRefine<T>` calls `_check<T>((payload) => ...)`
   before `_check<O>` is checked, and the value lookup deliberately declined
   to build a generic signature inside the caller's type-parameter scope.
   The call now reads the selected parameter annotation as context only,
   binding explicit type arguments, simple value-parameter inferences,
   defaults and constraints for that query. It does not publish or cache an
   early callee type. That boundary matters for Program types: two broader
   candidates were rejected because they froze signatures before their local
   declaration dependencies were checked or cached transferred conditional
   payloads in the wrong compilation, producing 65 checker failures and a
   bounds panic on the Zod graph. The contextual query keeps the ordinary
   declaration-order check authoritative and leaves complete forward value
   and overload resolution tracked in
   [#765](https://github.com/home-lang/home/issues/765).
5. **An unsupported imported value declaration was discarded**
   (`api.ts:1732` and `:1745`). `checks.$ZodCheck` is declared as
   `core.$constructor<$ZodCheck<any>>`, but the instance graph reaches
   leaves such as `Set<string>`, `Record<string, unknown>`, `typeof version`,
   polymorphic `this`, and cycles that cannot be transferred losslessly.
   Publishing that approximate constructor as a normal value was measured
   and rejected earlier: it added 38 Zod diagnostics. The declaration graph
   now retains unsupported values as projection-only metadata. When an
   assignment value needs context, the checker can follow an unannotated
   local back through `new checks.$ZodCheck(...)` and project only the
   requested member chain (`_zod.onattach`). The constructor, instance and
   assignment target remain `any` to ordinary reads and relations, so the
   approximation cannot reject code. Malformed source files still publish
   only their independently safe literal recovery surface. This completes
   [#763](https://github.com/home-lang/home/issues/763).

The remaining cause is tracked separately: `Record`/`Pick` in a cross-file
signature, plus a mapped type over `any`, collapse `util.normalizeParams`
([#764](https://github.com/home-lang/home/issues/764), `api.ts:1784` and
`:1785`, which also drive the sibling TS2411s).

Known gap kept visible: Home still reports nothing for a descriptor member
of the wrong type (`{ enumerable: 1 }` is TS2322 in tsgo).

Measured on the unchanged shard against the `832f68544` baseline, with the
checker suite at 4,379 tests and the Program suite at 217:

| Zod 4.5.2 implicit-any audit | `832f68544` | Home main | Change |
|---|---:|---:|---:|
| Core diagnostics (21-file shard) | 59 | **43** | **16 removed (27.1%); 0 added** |
| Unique path/line/column/code identities | 59 | **43** | **10 TS7006 + 4 TS7031 + 2 TS2554 removed; 0 added** |
| TS7031 left on the shard | 4 | **0** | — |
| TS7006 left on the shard | 12 | **2** | #764 |

### Properties reported missing that exist (untimed)

Under [#548](https://github.com/home-lang/home/issues/548) and
[#416](https://github.com/home-lang/home/issues/416). After `95e2f20ba` the
21-file Zod 4.5.2 `core` shard still carried 20 TS2339 "Property 'x' does
not exist on type 'T'", none of which TypeScript 6.0.3 or native 7.0.2
reports. They had six independent causes, each isolated to a minimal
repro checked against both engines. Four are fixed here:

1. **Members of an imported base whose type cannot be transferred** (10
   sites: `inst._zod.check` and `inst._zod.onattach` in the string-format,
   IPv6, CIDRv6, Base64, credit-card, JWT, custom, and ISO date-time
   constructors). `$Zod*Internals` inherits them through
   `checks.$ZodCheckStringFormatInternals`, whose graph reaches a `Set` and
   `Pick`, which a Program declaration cannot carry. A member whose exact
   type failed to lower was treated as undeclared. TypeScript finds a
   property by its declared name whatever its type, so the member is now
   read through the contextual projection, whose untransferable leaves are
   `any`, and as `any` only when even that fails. A member the base does
   not declare is still missing. The two TS7006 on the callbacks written
   into `check` and `onattach` go with it.
2. **A negative optional-chain discriminant narrowed to `never`** (4 sites).
   `params?.message !== undefined` over an `any` local and
   `ctx?.direction === "backward"`'s false branch over an intersection
   parameter removed the receiver entirely. TypeScript's discriminant
   narrowing applies only when the reference's declared type is a union (or
   a type parameter constrained to one), so any other receiver is left as
   it is. On a union it still filters the current type, including a single
   member left by earlier narrowing, which can reach `never`; an
   intersection member is judged by its discriminant, and a member without
   the property is kept.
3. **`NonNullable` over a nested deferred access** (2 sites, `InferInput`
   and `InferOutput` in `standard-schema.ts`). `NonNullable<Schema["~standard"]["types"]>["input"]`
   could not find the constraint of a two-level access; it now walks every
   level, as `indexedAccessBaseConstraint` already does. A key the
   constraint does not declare is still rejected.
4. **`any` did not absorb a union** (2 sites, `const { libraryOptions,
   target } = params ?? {}`). `??`, `||`, `&&`, and a const conditional
   initializer now reduce a union containing `any` to `any`, as TypeScript's
   `getUnionType` does. `unknown ?? {}` is unchanged.

Two are tracked separately. `(val) => fnOrRegex.test(val)` in the false
branch of `typeof fnOrRegex === "function"` needs narrowing to cross into a
closure for a parameter that is never reassigned (TypeScript 5.4's
preserved narrowing), a broad change to closure checking. And
`inst.constructor.name` needs the inherited `.constructor` to be
TypeScript's global `Function` type: giving its stand-in the `Function`
members was measured and dropped, because Home does not relate function and
constructor types to `Function` structurally, so `c.constructor === String`
and `this.constructor as new () => C` became false TS2367 and TS2352.

Each fix went through an adversarial review: two parity hunters and a code
reader over the diff, each finding re-run against both engines by a
skeptic. It confirmed the `.constructor` regression above, three narrowing
regressions in the first discriminant rule (a union narrowed to one member
no longer reaching `never`, intersection members kept whole, and a type
parameter constrained to a union left unnarrowed), a base referenced with
the wrong number of type arguments inheriting members it should not, and an
unbounded recursion in the new constraint walk. All are fixed and in the
tests. Three differences that `95e2f20ba` also had are left: an overloaded
base method collapses to its first overload, an inherited member loses its
optional and readonly modifiers, and a conditional or `keyof` over an
untransferable leaf is evaluated over `any`.

Against `95e2f20ba` on the same shard:

| Zod 4.5.2 core, missing properties | `95e2f20ba` | Home main | Change |
|---|---:|---:|---:|
| All diagnostics | 79 | **59** | **20 removed (25.3%); 0 added** |
| Unique path/line/column/code identities | 79 | **59** | **20 removed; 0 added** |
| Removed identities | — | 18 TS2339, 2 TS7006 | `core/schemas.ts` ×12, `core/util.ts:562–563` ×3, `core/compile.ts:138`, `core/standard-schema.ts:27, 30`, `core/to-json-schema.ts:845` ×2 |

Both engines report only the omitted `locales` module on this graph, so
every removal is a false positive gone. No timing is claimed.

### Positive `instanceof` assignment fallthrough (untimed)

Issue [#738](https://github.com/home-lang/home/issues/738), found while
reducing [#688](https://github.com/home-lang/home/issues/688), completes the
positive counterpart to the terminating and negated `instanceof` flow rules.
For `if (value instanceof Promise) value = await value`, the false path
excludes `Promise` while the true path carries the assigned awaited payload;
the fallthrough type is their structural join. This is implemented as normal
control-flow analysis, with no library or source-name special case.

The strict oracle contains an exact `string` assignment plus deliberately
invalid `number` and missing-property controls after the guard:

| Positive-guard assignment oracle | TypeScript 6.0.3 | Native TypeScript 7.0.2 | ReleaseSafe Home |
|---|---:|---:|---:|
| False TS7006 | 0 | 0 | **0** |
| Invalid assignment | TS2322 at 13:11 | TS2322 at 13:11 | **TS2322 at 13:11** |
| Missing property | TS2339 at 14:11 | TS2339 at 14:11 | **TS2339 at 14:11** |
| Complete diagnostic multiset | 2 | 2 | **2** |

The independently pinned Zod 4.5.2 `src/v4/core/**/*.ts` shard remains
exactly diagnostic-identical to the `origin/main` baseline: **150 diagnostics,
zero additions, and zero removals**. The full checker suite and stripped
ReleaseSafe `home-tsc` build pass. The guarded build peaked at 3,149 MB and the
Zod shard at 2,595 MB under the fixed 3,840 MB process-tree ceiling.

A broader #688 projection experiment was rejected before commit: one version
bus-faulted on the Zod core shard, while a bounded variant added 14 diagnostics.
The qualified imported issue-array work therefore remains open in #688. This
checkpoint makes no timing claim.

```sh
zig build test -Dfilter=ts_checker
zig build home-tsc -Doptimize=ReleaseSafe -Dhome-tsc-strip=true
./zig-out/bin/home-tsc -p /path/to/positive-instanceof/tsconfig.json
./zig-out/bin/home-tsc -p /path/to/zod-4.5.2/tsconfig.core.json
```

### Deferred imported Normalize member reads (untimed)

Issue [#764](https://github.com/home-lang/home/issues/764), under
[#548](https://github.com/home-lang/home/issues/548), completes the remaining
`normalizeParams` callback gap without admitting its mapped and conditional
declaration graph as an ordinary cross-file value type. The Program schema
marks only proven filtered function results for deferred reads. The receiving
checker gives each result a checker-local identity and resolves only the
member requested by the consumer from the source declaration and concrete
type arguments. Homomorphic `{ [K in keyof T]: T[K] }` identities reduce to
their source after instantiation. No source name, diagnostic code, Zod path,
or benchmark-only branch participates in the rule.

This keeps unsupported declaration machinery out of foreign checker pools,
which is the ownership boundary violated by the earlier candidate that
crashed the parallel Zod graph. Substitution propagates the declaration
origin and concrete arguments, while reads through unions, intersections,
`Pick`, `Omit`, `Partial`, mapped keys, indexed accesses, and distributive
conditionals lower only the requested leaf. The placeholder remains
permissive for unrelated whole-type relations; it is not treated as the
materialized mapped object.

The unchanged two-file reduction was run against JavaScript TypeScript 6.0.3,
native TypeScript 7.0.2, and stripped ReleaseSafe and ReleaseFast Home. Both
controls and both Home builds emit zero diagnostics. A permanent Program test
adds two deliberately invalid callback assignments and requires exactly two
TS2322 diagnostics while forbidding TS2411 and TS7006.

| Zod 4.5.2 core, deferred Normalize reads | Parent `e32642e0f` | #764 `6f26046fe` | Change |
|---|---:|---:|---:|
| Diagnostics | 13 | **8** | **5 removed; 0 added** |
| Unique path/line/column/code identities | 13 | **8** | **3 TS2411 + 2 TS7006 removed; 0 added** |
| Focused valid oracle | 3 TS2411 + 2 TS7006 | **clean** | exact clean three-engine parity |
| Program suite | 218 before new controls | **220/220** | two positive/negative regressions added |
| Checker suite | — | **4,395/4,395** | full suite passes |

The ReleaseSafe Zod gate completed four serial runs with byte-identical
normalized identity sets (SHA-256
`1e17af71d03b553a5f036464f6fc787dc2b6540936085ce1ac5d3d25fabd918b`),
then ReleaseFast reproduced the same set. The parent identity hash was
`815ad7a8b5bcc5a0a161840cb59bdff9e46db4cca97f6ad9385b028e969176e8`;
the set difference is exactly `core/api.ts:1760:3`, `:1761:3`, and `:1767:3`
TS2411 plus `:1784:36` and `:1785:34` TS7006. ReleaseSafe and ReleaseFast
builds passed under the fixed 3,840 MB guard at 2,766 MB and 2,866 MB peak,
respectively. The Zod runs peaked between 1,396 MB and 1,516 MB in
ReleaseSafe and at 560 MB in ReleaseFast. This checkpoint makes no timing
claim.

```sh
zig build test -Dfilter=ts_program --summary failures
zig build test -Dfilter=ts_checker --summary failures
zig build home-tsc -Doptimize=ReleaseSafe -j1 -Dhome-tsc-strip=true
zig build home-tsc -Doptimize=ReleaseFast -j1 -Dhome-tsc-strip=true
./zig-out/bin/home-tsc -p /path/to/normalize-reduction/tsconfig.json
~/.cache/home-ts-parity/tools/gate751.sh ./zig-out/bin/home-tsc /private/tmp/home-764
```

### Bigint arithmetic, merged namespaces, and mapped-key contracts (untimed)

Issues [#775](https://github.com/home-lang/home/issues/775),
[#776](https://github.com/home-lang/home/issues/776), and
[#777](https://github.com/home-lang/home/issues/777), under the Zod admission
tracker [#548](https://github.com/home-lang/home/issues/548), cover three
independent type-identity failures found after the deferred-Normalize work.
This is a correctness checkpoint; no timing result is claimed.

Commit [`d1d9abb0b`](https://github.com/home-lang/home/commit/d1d9abb0b88b2ed365cd8347155e21699b265865)
keeps arithmetic in the `bigint` domain when both effective operands are
bigint-like, adds `undefined` for optional access only when the receiver is
possibly nullish, and transfers exported nested declarations from merged
interface/namespace symbols through their exact namespace path. The preserved
Zod 4.5.2 core gate moved from eight identities to six: the only removals were
the false TS2367 at `core/checks.ts:194:52` and false TS2741 at
`core/schemas.ts:339:3`; no identity was added.

Commit [`f9548c289`](https://github.com/home-lang/home/commit/f9548c289f1ecf653f8f54722c1869739d04a265)
then repairs mapped-type substitution. A deferred mapped type now rebuilds its
key binder and remaps the original key in the same substitution walk. Concrete
properties compose outer substitutions with `K -> property` while
specializing the original template, and `keyof (Fixed & T)` remains deferred
until `T` is known without erasing the callable contract of a lone constrained
type parameter. Empty positional signature substitutions are true identities;
they no longer re-intern union/intersection parameters and discard
declaration-scoped relation metadata.

The permanent Program oracle uses the full recursive eleven-member issue union
that exposed the production failure. A valid assignment to
`RefinementCtx.addIssue` is accepted, while an explicit `(issue: number)`
assignment still produces exactly one TS2322. The two tests failing on exact
`origin/main` control `5d6e7cbc2` also pass: defaulted indexed namespace
callbacks and mapped prototype conditionals with optional generic/rest
parameters.

| Admission evidence | Exact control | Final candidate | Result |
|---|---:|---:|---|
| Program suite | 218/220 | **222/222** | two existing regressions fixed; two permanent tests added across #775–#777 |
| Full checker suite | pass | **pass** | no regression |
| Zod 4.5.2 core diagnostics / identities | 6 / 6 | **6 / 6** | byte-identical normalized set |
| Zod normalized SHA-256 | `64abd7817175b2885f805e3580a8ed0b74727e15f456dde3d85ba9ee3c528d19` | **same** | zero additions/removals |

The stripped ReleaseSafe `home-tsc` build passed at a guarded 2,603 MB peak;
the unchanged Zod gate passed at 1,248 MB under the fixed 3,840 MB process-tree
ceiling. ReleaseFast was not admitted on this host: two normal attempts and a
single-job attempt were terminated cleanly by the same guard at 3,845 MB,
3,874 MB, and 3,843 MB. The ceiling was not raised. A Debug Zod run was also
stopped at 3,843 MB, after which the documented ReleaseSafe gate supplied the
successful semantic result above.

A broader `Record` materialization experiment was rejected before commit: it
expanded the six-identity Zod baseline to 25, adding 19 diagnostics. The final
implementation does not special-case Zod, source paths, member names, or
diagnostic codes, and it does not suppress errors or rewrite the corpus.

```sh
zig build test -Dfilter=ts_program
zig build test -Dfilter=ts_checker
zig build -j1 home-tsc -Doptimize=ReleaseSafe -Dhome-tsc-strip=true
~/.cache/home-ts-parity/tools/gate751.sh ./zig-out/bin/home-tsc /private/tmp/home-775-777-final-releasesafe
```

### Function guards and rest-array callback assignment (untimed)

Under the Zod admission tracker [#548](https://github.com/home-lang/home/issues/548),
this checkpoint compares the unchanged, frozen Zod 4.5.2 21-file core proxy
against TypeScript 6.0.3, native TypeScript 7.0.2, and Home. It is a
correctness result, not a performance claim. The two TypeScript controls
report only `core/index.ts:11:26 TS2307`: the reduced proxy excludes the
referenced `../locales/index.js`. That shared proxy-boundary diagnostic is
not a Home compiler defect and is not hidden by changing the corpus.

Home had compared the `typeof`-function predicate's target against a newly
allocated `Function` type ID. Since built-in lowering creates a fresh ID on
each call, the comparison never matched, and an `any`-typed callback value
was incorrectly narrowed to the broad `Function` type. The checker now
compares the recorded built-in name and preserves `any`; `unknown` still
narrows to `Function`. Separately, a source signature with an open
`...args: E[]` now compares each fixed target argument to `E`, rather than
to the entire array. Tuple-rest, minimum-arity, and return-type checks are
retained. These are general type rules, with no Zod-specific branch.

| Frozen core diagnostic identities | Before | After | Delta |
|---|---:|---:|---|
| Total | 6 | **4** | 2 removed; 0 added |
| Home-only | 5 | **3** | false TS2345 at `core/schemas.ts:4772:45` and `:4774:40` removed |
| Shared proxy-boundary TS2307 | 1 | 1 | unchanged |

The exact normalized after-set is `core/index.ts:11:26 TS2307`,
`core/schemas.ts:4779:5 TS2322`, `core/schemas.ts:4879:19 TS2741`, and
`core/visit.ts:34:21 TS2571` (SHA-256
`b76cec6192d95acc99611c9c40610a1e5e7f7dc20b931d3340ad7b0a166b9631`).
The rest-array correction passes a standalone generic-overload reduction but
does **not** remove the richer Zod assignment at `:4779`; that identity
remains open. Likewise, the remaining TS2741 and TS2571 are not claimed
fixed.

Pinned TypeScript 6.0.3 and native 7.0.2 controls agree on the positive and
negative probes: `any` remains callable under a function guard while
`unknown` and `Function` are rejected where a constrained callback is
required; an `any[]` or `unknown[]` rest-source signature accepts a fixed
object parameter, whereas a `string[]` source, wrong return, and excess
required arguments remain errors. Home matches those exact diagnostics after
the changes. A cross-file Program test checks the guarded callback through
an imported constructor and preserves the two intentional TS2345 errors.

The full checker suite passed **4,403/4,403** and the Program suite passed
**223/223**. A stripped ReleaseSafe `home-tsc` build passed at a 2,648 MB
peak; the frozen core gate passed at 1,249 MB. Each heavy run was serialized
under the fixed 3,840 MB process-tree memory ceiling. The unmodified
106-file Zod graph and timing comparison remain outside admission until
the Home-only identities are resolved; the 21-file proxy result must not be
presented as a full-graph benchmark.

### Open-rest generic overload assignability (untimed)

The next [#548](https://github.com/home-lang/home/issues/548) checkpoint
keeps the pinned Zod 4.5.2 core proxy and its TypeScript 6.0.3 / native 7.0.2
controls unchanged. An open `(...args: any[])` implementation can cover a
generic fixed-arity overload when its argument elements and return type are
assignable for every instantiation. Home previously rejected the second
`$ZodFunction.input` overload before its full rest-parameter relation ran.
The checker now evaluates that complete relation ahead of the generic
type-parameter mismatch precheck. It also relates `any` to a free type
parameter in a same-generic-instance comparison and applies declared
generic variance to a contextual callback return before expanding its
substituted structural members. `unknown` and concrete sources do not gain
the `any` rule; wrong callback returns and constrained parameter types remain
errors.

| Frozen 21-file core identities | Prior main | Candidate | Delta |
|---|---:|---:|---|
| Total | 4 | **3** | `core/schemas.ts:4779:5 TS2322` removed; 0 added |
| Home-only | 3 | **2** | `core/schemas.ts:4879:19 TS2741` and `core/visit.ts:34:21 TS2571` remain |
| Shared proxy-boundary TS2307 | 1 | 1 | `core/index.ts:11:26`, also reported by both controls |

The exact after-set SHA-256 is
`d0b900373c14def43cf1e6efd3827691c560f0825fc516f300cea69e805c0376`.
Both pinned TypeScript controls and Home report the same six intentional
TS2322 errors on the covariant, contravariant, and invariant `any`/`unknown`
negative-control oracle. A separate open-rest overload reduction accepts the
valid implementation and rejects the wrong return and argument type. The
complete checker and Program test suites pass, as do `zig fmt --check`, a
guarded stripped ReleaseSafe build (2,655 MB peak), and the frozen gate
(1,342 MB peak). The guard ceiling was 3,840 MB; all heavy processes were
serialized.

This is correctness evidence, **not** a timing result or full Zod admission.
Another standalone overloaded-property oracle still has two Home-only false
positives, so generic overload parity is not claimed complete. The unchanged
106-file Zod graph and fair timing comparison remain gated on the remaining
Home-only identities and consumer negative controls.

### Contextual generic constructor and indexed getter inference (untimed)

Issue [#820](https://github.com/home-lang/home/issues/820), under the Zod
admission tracker [#548](https://github.com/home-lang/home/issues/548), covers
the next frozen-core checkpoint. A generic constructor callback is provisionally
checked before its contextual parameters are fully known. Home retained a
missing-property error from that provisional pass. The final contextual pass
now owns those diagnostics, while imported copies of written generic arguments
receive the same substitutions as their declaration parameters. Separately,
when an earlier call argument has fixed an object's indexed member, a later
getter return is checked against that member rather than widening the object
to make the getter valid.

| Exact 21-file Zod 4.5.2 core proxy | Previous main | Candidate | Delta |
|---|---:|---:|---|
| Diagnostic identities | 3 | **2** | false `core/schemas.ts:4879:19 TS2741` removed; 0 added |
| Home-only identities | 2 | **1** | `core/visit.ts:34:21 TS2571` remains ([#821](https://github.com/home-lang/home/issues/821)) |
| Shared proxy-boundary TS2307 | 1 | 1 | `core/index.ts:11:26`, also in both pinned controls |

A separate three-file `core.ts` / `util.ts` / `acceptance.ts` oracle keeps both
invalid `defineLazy` getters in place. Pinned TypeScript 6.0.3, native
TypeScript 7.0.2, and the guarded Home ReleaseSafe CLI each report exactly
two TS2322 errors at `acceptance.ts:15` and `:19`; the valid constructor
callback remains accepted. Checker regressions also assert the invalid
parameterless getter return for both a concrete object and an interface, and
that a genuine missing-property TS2741 inside a contextual callback survives
the provisional-diagnostic cleanup.

The complete checker suite passed under the 3,840 MB guard (2,141 MB peak),
and a stripped ReleaseSafe `home-tsc` build completed under the same guard
(2,731 MB peak). The frozen-core and fresh cross-file CLI checks used that
newly built binary. The Program suite also passed with a permanent three-file
virtual-module regression, whose resolver reads export facts from the fixture
sources rather than supplying invented export names.

This is an **untimed** correctness result, not a 106-file Zod admission or
performance claim. The full graph and fair timing comparison remain gated on
the unresolved Home-only diagnostics and complete consumer controls.

### Contextual visitor keys and source-owned member chains (untimed)

Issue [#821](https://github.com/home-lang/home/issues/821), under the Zod
admission tracker [#548](https://github.com/home-lang/home/issues/548), covers
the final Home-only diagnostic in the unchanged 21-file core proxy. Two
independent precision losses combined in `core/visit.ts`: the finite
string-literal union behind `$ZodTypeDef["type"]` degraded to `any`, and the
unannotated visitor callback lost the source occurrence of its `VisitFn`
contract when another structurally identical signature shared its TypeId.

Home now admits only independently representable finite string-literal
members from projection-only imported declarations. Object-valued indexed
members remain excluded, so an approximate imported object never becomes a
general assignment target. For contextual callbacks nested in conditional or
comma expressions, member chains are projected from the explicitly typed
variable's source annotation. Default generic arguments are instantiated
against the contextual declaration owner, preserving nested source-owned
members without publishing intermediate object approximations.

| Exact 21-file Zod 4.5.2 core proxy | Previous main | Candidate | Delta |
|---|---:|---:|---|
| Diagnostic identities | 2 | **1** | `core/visit.ts:34:21 TS2571` removed; 0 added |
| Home-only identities | 1 | **0** | the proxy has no remaining Home-only diagnostic |
| Shared proxy-boundary TS2307 | 1 | 1 | `core/index.ts:11:26`, also reported by both pinned controls |

The permanent two-file Program regression uses an opaque imported type with
three defaulted generic parameters, a finite mapped handler key set, and the
same conditional visitor construction. It accepts the valid handler and
member-chain lookup, rejects an invalid kind with TS2322, rejects an unknown
handler key with TS2353, and forbids TS2571/TS7053. This checkpoint remains
untimed; the unmodified 106-file graph and consumer gates are the next
admission stage before any Zod performance claim.

### Typed cross-file global ownership and cyclic provenance (untimed)

Issue [#480](https://github.com/home-lang/home/issues/480), under
[#548](https://github.com/home-lang/home/issues/548) and
[#416](https://github.com/home-lang/home/issues/416), replaces the program's
name-only global fallback with checked source-owner types. Commit
[`592b9ff3a`](https://github.com/home-lang/home/commit/592b9ff3aadd43abfdc8975010bf49fb6ec76ab6)
relocates real value and type bindings into each receiving compilation,
including structural members, generic signature metadata, lexical globals,
`globalThis` properties, interface merging, destructured declaration slots,
and separate type/value namespaces. Serial, parallel, and streaming checking
use the same dependency-derived provider order. External modules remain
isolated, and CommonJS providers retain their separate import scheduler.

The first expanded cyclic audit exposed a real transitive-owner fault: an
imported declaration handle and a local HIR NodeId occupied the same numeric
domain. A third compilation could therefore reinterpret foreign provenance as
an unrelated local node. Commit
[`af08e7e61`](https://github.com/home-lang/home/commit/af08e7e61a7502019f81d01fef5ad6d11ca35b30)
tags registry declaration handles, preserves them across subsequent owner
transfers, rejects stale handles, and limits syntax-only checker inspection to
nodes that actually belong to the current HIR. The provenance is retained;
it is not replaced with a fabricated local node or shallow benchmark shape.
Commit
[`6ec121877`](https://github.com/home-lang/home/commit/6ec121877929782fa72e70498a9fd257ca015e37)
keeps the cyclic positive/negative programs as permanent CLI controls.

Every audit creates fresh strict, no-emit, no-lib projects and gives the same
files and explicit root order to Home, TypeScript 6.0.3, and native TypeScript
7.0.2. The negative sources only append invalid uses to their positive
counterparts and require the exact diagnostic-code multiset. Crashes, usage
errors, clean invalid programs, and diagnostics on valid programs all fail.
The cyclic family splits mutually recursive `Left` and `Right` interfaces from
their consumer and reverses the entire explicit root order.

| Untimed global control | TypeScript 6.0.3 | Native TypeScript 7.0.2 | Pre-change Home `5cbf35e3b` | Home `592b9ff3a` | Final Home `6ec121877` |
|---|---:|---:|---:|---:|---:|
| Same-file globals | 24/24 | 24/24 | 24/24 | 24/24 | 24/24 |
| Existing cross-file globals | 32/32 | 32/32 | 8/32 | 32/32 | 32/32 |
| New cyclic-owner controls | 4/4 | 4/4 | not run | 0/4 (owner import error) | **4/4** |
| Expanded global total | 60/60 | 60/60 | not comparable | 56/60 | **60/60** |
| Bound-global visibility | 56/56 | 56/56 | 44/56 | 56/56 | **56/56** |

The final global process total is **180/180** checks and the independent
bound-global process total is **168/168** checks. The unchanged pinned Zod
4.5.2 graph remains exactly **600 diagnostics**, so this change does not move
that separate real-project count. At this #480 checkpoint, the adjacent
imported-owner audit was **16/20** for Home and the nominal-origin audit was
**44/52**. The subsequent [#487 completion](#imported-graph-ownership-completion-untimed)
brings those unchanged audits to 20/20 and 52/52 per compiler, respectively.

Final source gates for this checkpoint pass: **4,348/4,348 checker**,
**179/179 Program**, **187/187 driver**, **69/69 CLI**, and **6/6** directly
modified global audit tests. ReleaseFast and `zig fmt` pass. At this point the
repository-wide benchmark test discovery passed 92/95; the later
[#653 harness update](#commonjs-and-qualified-projection-performance-recovery)
aligns the three stale export-list expectations with the existing 128-case
audit and brings the suite to 95/95. The required repository-wide Pickier run
remains red on existing debt: 20,869 findings across 12,036 files. The final
ReleaseFast `home-tsc` SHA-256 for #480 is
`92f6cb3f52c05c5791e83ee9c30d077d34dbaef960adbf8e04c8f1452a4c6d5d`.

This is a correctness checkpoint, not a timing claim. ReleaseFast compilation
ran while another repository suite loaded the same workstation, so its wall
time is deliberately excluded from the performance table.

```sh
python3 bench/vs_tsgo/audit_globals.py
python3 bench/vs_tsgo/audit_bound_globals.py
python3 bench/vs_tsgo/audit_owners.py
python3 bench/vs_tsgo/audit_nominal_origins.py
zig build test -Dfilter=ts_checker
zig build test -Dfilter=ts_program
zig build test -Dfilter=ts_driver
zig build test -Dfilter=ts_cli
zig build -Doptimize=ReleaseFast
bunx --bun pickier .
```
