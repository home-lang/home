"""Untimed complete-process parent/candidate diagnostic parity controls."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
sys.path.insert(0, str(repo / 'bench/vs_tsgo'))
import run

sources = {
    'overloads': '''function f(x: number): number;
function f(x: string): string;
function f(x: any) { return x; }
function accept(callback: (x: number) => number) { return callback(1); }
const valid: number = accept(f);
const invalid: boolean = accept(f);
f(true);
''',
    'scopes': '''function f(x: number): number;
function f(x: any) { return x; }
function accept(callback: (x: number) => number) { return callback(1); }
function outer() {
  function f(x: string): string;
  function f(x: any) { return x; }
  { const wrong: boolean = accept(f); }
}
namespace N {
  export function f(x: boolean): boolean;
  export function f(x: any) { return x; }
  const wrong: string = accept(f);
}
const named = function f(x: number) { return x; };
function parameter(f: (x: string) => string) { accept(f); }
''',
    'exports': '''export function f(x: number): number;
export function f(x: string): string;
export function f(x: any) { return x; }
function accept(callback: (x: boolean) => boolean) { return callback(true); }
const wrong: number = accept(f);
f(false);
''',
    'checked-js': '''// @ts-check
/** @param {number} x @returns {number} */
function f(x) { return x; }
/** @param {(x: number) => number} callback @returns {number} */
function accept(callback) { return callback(1); }
/** @type {string} */ const wrong = accept(f);
f("wrong");
''',
}
output = root / 'complete-diagnostic-parity'
output.mkdir(exist_ok=False)
records = []
for name, source in sources.items():
    folder = output / name
    run.write(folder / 'tsconfig.json', run.shared_config(check_js=name == 'checked-js'))
    run.generate_minimal_lib(folder)
    extension = 'js' if name == 'checked-js' else 'ts'
    run.write(folder / ('src/control.' + extension), source)
    rows = []
    for compiler in ('parent', 'candidate'):
        binary = root / ('home-tsc-' + compiler)
        command = [str(binary), '--noEmit', '-p', str(folder / 'tsconfig.json')]
        result = subprocess.run(command, capture_output=True, text=True)
        row = {'compiler': compiler, 'binary_sha256': run.sha256_file(binary),
               'command': command, 'exit': result.returncode,
               'stdout': result.stdout, 'stderr': result.stderr}
        rows.append(row)
        (output / (name + '-' + compiler + '.json')).write_text(json.dumps(row, indent=2) + '\n')
    assert rows[0]['exit'] == rows[1]['exit'] == 1, rows
    assert rows[0]['stdout'] == rows[1]['stdout'], rows
    assert rows[0]['stderr'] == rows[1]['stderr'], rows
    assert 'error TS' in rows[0]['stdout'] + rows[0]['stderr'], rows
    records.append({'case': name, 'source_sha256': hashlib.sha256(source.encode()).hexdigest(),
                    'complete_output_equal': True, 'records': rows})
(root / 'diagnostic-parity.json').write_text(json.dumps(records, indent=2) + '\n')
print('All four untimed full-process diagnostic controls match exactly.')
