import hashlib
import json
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
parent = 'dad1ea95f27a724574772bb2882a34576d7282bb'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip() == parent
assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=repo).decode().splitlines() == [' M packages/ts_checker/src/check.zig']
patch = subprocess.check_output(['git', 'diff', '--', 'packages/ts_checker/src/check.zig'], cwd=repo)
assert patch == (root / 'original-experiment/final-draft.patch').read_bytes()
assert patch == (root / 'final-draft.patch').read_bytes()
assert not (root / 'current-source-freeze.json').exists()
original_protocol = json.loads((root / 'original-experiment/protocol.json').read_text())
current_protocol = json.loads((root / 'protocol.json').read_text())
assert original_protocol.pop('parent_source') == 'aea27323599a13051ce1bfb8a98a19f4de457d1d'
assert current_protocol.pop('parent_source') == parent
assert original_protocol == current_protocol, 'No timing, acceptance or semantic rule may change during reconciliation'
record = {'source_parent': parent,
          'parent_binary_sha256': hashlib.sha256((root / 'home-tsc-parent').read_bytes()).hexdigest(),
          'protocol_sha256': hashlib.sha256((root / 'protocol.json').read_bytes()).hexdigest(),
          'final_draft_patch_sha256': hashlib.sha256(patch).hexdigest(),
          'timing_not_started': True,
          'required_gates': ['checker', 'binder', 'program', 'driver', 'cli', 'entrypoint', 'build', 'harness', 'diagnostic-parity', 'zod-parent', 'zod-candidate'],
          'runners': {name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in ['paired.py', 'paired-interface-risk.py', 'verify_pairs.py', 'decide.py']}}
(root / 'current-source-freeze.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))
