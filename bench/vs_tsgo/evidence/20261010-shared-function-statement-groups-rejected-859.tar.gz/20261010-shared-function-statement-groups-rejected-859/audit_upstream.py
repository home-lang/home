"""Read-only Git input comparison; this does not replace clean native proof."""
import hashlib
import json
from pathlib import Path
import subprocess

repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
root = Path(__file__).resolve().parent
parent = 'aea27323599a13051ce1bfb8a98a19f4de457d1d'
upstream = subprocess.check_output(['git', 'rev-parse', 'origin/main'], cwd=repo).decode().strip()
paths = ['build.zig', 'build.zig.zon', 'package.json', 'bunfig.toml', 'bench/vs_tsgo',
         'packages/ts_checker', 'packages/ts_program', 'packages/ts_driver', 'packages/ts_cli',
         'packages/binder', 'packages/hir', 'packages/ts_parser', 'packages/ts_lexer',
         'packages/string_interner', 'packages/ts_resolver', 'packages/tsconfig',
         'packages/ts_emit', 'packages/ts_diagnostics', 'packages/ts_watch',
         'packages/ts_lsp', 'packages/ts_lsp_server', 'packages/d_hm', 'packages/ts_cache']
trees = {ref: subprocess.check_output(['git', 'ls-tree', '-r', ref, '--', *paths], cwd=repo)
         for ref in (parent, upstream)}
assert trees[parent] == trees[upstream]
changes = subprocess.check_output(['git', 'diff', '--name-status', parent, upstream], cwd=repo).decode().splitlines()
record = {'original_source': parent, 'observed_upstream': upstream,
          'checked_paths': paths, 'tracked_tree_records_equal': True,
          'tree_records_sha256': hashlib.sha256(trees[parent]).hexdigest(),
          'upstream_changes': changes, 'clean_parent_native_proof_still_required': True,
          'candidate_native_proof_still_required': True, 'no_timings_started': True}
destination = root / ('upstream-input-audit-' + upstream[:12] + '.json')
assert not destination.exists()
destination.write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({key: value for key, value in record.items() if key != 'upstream_changes'}))
