import hashlib
import json
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
name = sys.argv[1]
assert name in ('initial-invalid-test-type', 'corrected-first', 'six-controls', 'nine-controls')
parent = 'aea27323599a13051ce1bfb8a98a19f4de457d1d'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip() == parent
patch = subprocess.check_output(['git', 'diff', '--', 'packages/ts_checker/src/check.zig'], cwd=repo)
assert not (root / (name + '.patch')).exists()
(root / (name + '.patch')).write_bytes(patch)
record = {'parent_source': parent, 'patch_sha256': hashlib.sha256(patch).hexdigest(),
    'parent_native_sha256': hashlib.sha256((root / 'home-tsc-parent').read_bytes()).hexdigest(),
    'scope': 'Recorded development draft; final semantic controls, all module gates and frozen native/protocol required before any timing'}
(root / (name + '-provenance.json')).write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))
