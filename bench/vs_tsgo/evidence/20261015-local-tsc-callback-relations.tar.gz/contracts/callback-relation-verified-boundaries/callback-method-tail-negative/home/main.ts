interface Left{run(cb:(n:number)=>void,flag:string):void}interface Right{run(cb:(n:number)=>void,flag:number):void}declare const left:Left;const wrong:Right=left;
