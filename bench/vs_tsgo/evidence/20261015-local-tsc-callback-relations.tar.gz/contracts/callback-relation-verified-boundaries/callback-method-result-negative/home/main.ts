interface Left{run(cb:(n:number)=>void):string}interface Right{run(cb:(n:number)=>void):number}declare const left:Left;const wrong:Right=left;
