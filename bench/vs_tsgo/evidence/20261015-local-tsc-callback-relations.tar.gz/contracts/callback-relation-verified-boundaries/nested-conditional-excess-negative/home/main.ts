type PickValue<T>={known:T extends string?number:boolean};declare function take<T>(value:PickValue<T>):void;function use<T>():void{take<T>({known:null as any,extra:true});}
