type Shape<T>={known:number;maybe:T extends string?number:boolean};declare function take<T>(value:Shape<T>):void;function use<T>():void{take<T>({known:"bad",maybe:null as any});}
