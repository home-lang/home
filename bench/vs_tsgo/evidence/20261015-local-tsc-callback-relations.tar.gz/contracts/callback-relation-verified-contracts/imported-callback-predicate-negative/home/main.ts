import type {Left,Right} from "./owner";declare let left:Left;declare let right:Right;left=right;right=left;
