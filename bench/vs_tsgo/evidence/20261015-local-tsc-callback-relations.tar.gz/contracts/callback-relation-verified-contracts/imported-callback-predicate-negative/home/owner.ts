export interface A{a:number}export interface B extends A{b:number}export interface Left{run(listener:(value:A)=>value is A):void}export interface Right{run(observer:(value:B)=>value is B):void}
