type Shape<T>={nested:{known:T extends string?number:boolean}};declare function take<T>(value:Shape<T>):void;function use<T>():void{take<T>({nested:{known:null as any,extra:true}});}
