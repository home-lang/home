type Shape<T>={known:T extends string?number:boolean};declare function take<T>(value:Shape<T>):void;function use<T>():void{take<T>({known:null as any});}
