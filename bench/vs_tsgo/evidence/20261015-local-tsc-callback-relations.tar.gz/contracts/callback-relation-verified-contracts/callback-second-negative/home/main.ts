interface Left{run(flag:boolean,listener:(n:string)=>void):void}interface Right{run(flag:boolean,observer:(n:number)=>void):void}declare const left:Left;const wrong:Right=left;
