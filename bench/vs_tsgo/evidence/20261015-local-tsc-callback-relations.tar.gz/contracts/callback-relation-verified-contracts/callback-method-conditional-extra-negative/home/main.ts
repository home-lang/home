type Shape<T>={read():T extends string?number:boolean};declare function take<T>(value:Shape<T>):void;function use<T>():void{take<T>({read:()=>null as any,extra:true});}
