interface Left{run(listener:(n:number)=>void,...tail:string[]):void}interface Right{run(observer:(n:number)=>void,...tail:number[]):void}declare const left:Left;const wrong:Right=left;
