interface Left{run(listener:(n:number)=>void,flag?:boolean):void}interface Right{run(observer:(n:number)=>void):void}declare const left:Left;const good:Right=left;
