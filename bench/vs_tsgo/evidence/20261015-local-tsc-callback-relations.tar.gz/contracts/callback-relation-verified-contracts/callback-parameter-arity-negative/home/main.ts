interface Left{run(listener:(n:number)=>void):void}interface Right{run(observer:(n:number,m:number)=>void):void}declare const left:Left;const wrong:Right=left;
