type One<T>={set(...values:T[]):void};type Two<T>={set(...values:T[]):void};declare let left:One<(value:unknown)=>void>;declare let right:Two<(value:string)=>void>;left=right;right=left;
