interface Left{run(listener:(n:number)=>string):void}interface Right{run(observer:(n:number)=>number):void}declare const left:Left;const wrong:Right=left;
