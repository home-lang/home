export type One<T>={set(value:T):void};export type Two<T>={set(value:T):void};
