import type {One,Two} from "./owner";declare let left:One<(value:unknown)=>void>;declare let right:Two<(value:string)=>void>;left=right;right=left;
