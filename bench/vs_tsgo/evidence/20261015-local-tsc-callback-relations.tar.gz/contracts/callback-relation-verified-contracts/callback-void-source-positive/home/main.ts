interface Left{run(listener:(n:number)=>void):void}interface Right{run(observer:(n:number)=>number):void}declare const left:Left;const good:Right=left;
