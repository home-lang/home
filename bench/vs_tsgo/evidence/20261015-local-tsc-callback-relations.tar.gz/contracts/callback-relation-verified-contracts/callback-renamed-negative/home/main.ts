interface Left{run(listener:(n:string)=>void):void}interface Right{run(observer:(n:number)=>void):void}declare const left:Left;const wrong:Right=left;
