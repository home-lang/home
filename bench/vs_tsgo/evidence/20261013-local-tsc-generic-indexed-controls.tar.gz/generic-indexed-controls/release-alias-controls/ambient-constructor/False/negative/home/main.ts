const item = new Api.Item('ok'); const value: string = item.value;
export {};
const wrong: number = item.value;
