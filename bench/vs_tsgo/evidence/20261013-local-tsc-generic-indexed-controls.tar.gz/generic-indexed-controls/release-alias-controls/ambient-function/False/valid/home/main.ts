const text: string = Api.convert(1);
export {};
