const text: string = Api.convert(1);
export {};
const wrong: number = Api.convert(1);
