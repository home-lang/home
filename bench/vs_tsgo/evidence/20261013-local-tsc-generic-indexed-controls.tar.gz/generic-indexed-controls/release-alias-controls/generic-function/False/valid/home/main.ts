const text: string = Api.identity('ok');
export {};
