const text: string = Api.identity('ok');
export {};
const wrong: number = Api.identity('bad');
