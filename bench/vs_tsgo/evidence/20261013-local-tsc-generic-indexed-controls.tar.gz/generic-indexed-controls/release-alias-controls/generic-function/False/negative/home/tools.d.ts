export declare function identity<T>(value: T): T;
