export declare class Item { constructor(value: string); value: string; }
