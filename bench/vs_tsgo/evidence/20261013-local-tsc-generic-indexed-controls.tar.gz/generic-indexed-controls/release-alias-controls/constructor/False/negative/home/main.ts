const item = new Api.Item('ok'); const text: string = item.value;
export {};
const wrong: number = item.value;
