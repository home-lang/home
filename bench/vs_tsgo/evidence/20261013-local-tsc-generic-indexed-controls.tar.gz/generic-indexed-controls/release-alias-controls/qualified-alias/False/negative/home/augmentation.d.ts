import * as Module from "./tools";
declare global { export import Api = Module.Nested; }
