export declare namespace Nested { function convert(value: number): string; }
