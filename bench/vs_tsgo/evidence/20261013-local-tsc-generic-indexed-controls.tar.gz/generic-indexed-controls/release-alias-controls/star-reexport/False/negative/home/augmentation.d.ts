import * as Module from "./barrel";
declare global { export import Api = Module; }
