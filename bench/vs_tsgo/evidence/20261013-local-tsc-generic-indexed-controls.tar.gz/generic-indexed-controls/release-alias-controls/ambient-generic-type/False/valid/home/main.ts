declare const box: Api.Box<number>;
const value: number = box.value;
