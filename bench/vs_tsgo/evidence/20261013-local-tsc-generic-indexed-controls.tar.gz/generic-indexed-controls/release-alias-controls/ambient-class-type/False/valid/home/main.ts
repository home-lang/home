declare const item: Api.Item;
const value: string = item.value;
