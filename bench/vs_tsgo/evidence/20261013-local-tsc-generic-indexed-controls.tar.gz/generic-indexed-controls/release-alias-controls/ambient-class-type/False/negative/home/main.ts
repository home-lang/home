declare const item: Api.Item;
const value: string = item.value;
const wrong: number = item.value;
