import * as Module from "tool-api";
declare global { export import Api = Module; }
