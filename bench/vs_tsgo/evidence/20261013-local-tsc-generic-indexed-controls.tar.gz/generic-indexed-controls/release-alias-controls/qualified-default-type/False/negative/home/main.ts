declare const box: Api.Box;
const value: number = box.value;
const wrong: string = box.value;
