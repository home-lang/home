export declare function convert(value: number): string;
