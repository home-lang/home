interface O { value?: number }
declare function pick<T extends O>(o: T): T["value"];
const result = pick({});
const n: number | undefined = result;
