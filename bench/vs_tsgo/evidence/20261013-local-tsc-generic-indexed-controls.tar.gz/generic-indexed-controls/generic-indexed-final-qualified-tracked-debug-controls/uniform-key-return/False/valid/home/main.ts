interface O { a: number; b: number }
function read<K extends keyof O>(): O[K] { return 1; }
