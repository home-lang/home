interface O { value?: number }
declare function pick<T extends O>(o: T): T["value"];
const n: number = pick({value: 1});
function wrong<T extends O>(): T["value"] { return "wrong"; }
