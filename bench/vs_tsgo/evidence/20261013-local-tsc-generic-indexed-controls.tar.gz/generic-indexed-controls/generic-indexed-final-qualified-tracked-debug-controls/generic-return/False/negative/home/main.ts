interface O { value: number }
function read<T extends O>(o: T): T["value"] { return o["value"]; }
function wrong<T extends O>(v: string): T["value"] { return v; }
