import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
sys.path.insert(0, str(repo / 'bench/vs_tsgo'))
import run

commands = run.compiler_commands()
versions = run.verified_compiler_versions(commands)
project = root / 'source/package/tsconfig.benchmark.json'
provenance = json.loads((root / 'corpus-provenance.json').read_text())
for relative, expected in provenance['inputs'].items():
    assert hashlib.sha256((project.parent / relative).read_bytes()).hexdigest() == expected
assert hashlib.sha256(project.read_bytes()).hexdigest() == provenance['config_sha256']
records = []
for compiler, command in commands.items():
    argv = command + ['--noEmit', '-p', str(project)]
    if compiler == 'home':
        argv.append('--home-list-unmodeled-any')
    result = subprocess.run(argv, capture_output=True, text=True)
    output = result.stdout + result.stderr
    record = {'compiler': compiler, 'command': argv, 'exit': result.returncode,
              'stdout': result.stdout, 'stderr': result.stderr,
              'diagnostic_counts': {code: len(re.findall(r'\b' + code + r':', output))
                                    for code in sorted(set(re.findall(r'\b((?:TS|HM)\d+):', output)))},
              'silent_success': result.returncode == 0 and not output}
    records.append(record)
    (root / 'corpus-admission.json').write_text(json.dumps({'versions': versions, 'records': records}, indent=2) + '\n')
    print(compiler, result.returncode, record['diagnostic_counts'], flush=True)
print('Untimed admission only; original production source hashes verified.')
