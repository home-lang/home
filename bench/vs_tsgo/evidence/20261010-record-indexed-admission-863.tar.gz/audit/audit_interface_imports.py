"""Untimed general import/type-space reproductions; pinned production untouched."""
import json
from pathlib import Path
import subprocess
import sys

root=Path(__file__).resolve().parent
repo=Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
sys.path.insert(0,str(repo/'bench/vs_tsgo'))
import run

commands=run.compiler_commands()
run.verified_compiler_versions(commands)
output=root/'interface-import-probes'
output.mkdir(exist_ok=False)
records=[]
for barrel in (False,True):
    for merged in (False,True):
        for type_only in (False,True):
            name=f'{"barrel" if barrel else "direct"}-{"merged" if merged else "type"}-{"typeimport" if type_only else "valueimport"}'
            folder=output/name
            run.write(folder/'tsconfig.json',run.shared_config())
            run.generate_minimal_lib(folder)
            owner='export interface BaseError<T = unknown> { type: T; issues: string[]; name: string; message: string; }\n'
            if merged:
                owner+='export declare const BaseError: { init(instance: BaseError, issues: string[]): void };\n'
            run.write(folder/'src/owner.ts',owner)
            run.write(folder/'src/barrel.ts','export * from "./owner.js";\n')
            target='barrel' if barrel else 'owner'
            consumer=f'import {"type " if type_only else ""}{{ BaseError }} from "./{target}.js";\n'
            consumer+='interface Derived<T = unknown> extends BaseError<T> { format(): string; }\ndeclare const error: Derived<number>;\nconst issue: string = error.issues[0];\nconst message: string = error.name + error.message;\nconst value: number = error.type;\nconst formatted: string = error.format();\nvoid issue; void message; void value; void formatted;\n'
            run.write(folder/'src/consumer.ts',consumer)
            for compiler,command in commands.items():
                result=subprocess.run(command+['--noEmit','-p',str(folder/'tsconfig.json')],capture_output=True,text=True)
                records.append({'case':name,'compiler':compiler,'command':command+['--noEmit','-p',str(folder/'tsconfig.json')],
                                'exit':result.returncode,'stdout':result.stdout,'stderr':result.stderr,
                                'silent_success':result.returncode==0 and not result.stdout and not result.stderr})
(root/'interface-import-probes.json').write_text(json.dumps(records,indent=2)+'\n')
for row in records:
    print(row['case'],row['compiler'],'exit',row['exit'],'silent_success',row['silent_success'],flush=True)
print('Untimed characterization only; no production graph modified or compiler gain claimed.')
