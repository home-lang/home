import type * as api from "./owner.js";
export function node(): api.Node {
  const value: api.Node = { kind: "node", payload: 1 };
  return value;
}
export function leaf(): api.Leaf {
  const value: api.Leaf = { kind: "leaf", payload: "data" };
  return value;
}
