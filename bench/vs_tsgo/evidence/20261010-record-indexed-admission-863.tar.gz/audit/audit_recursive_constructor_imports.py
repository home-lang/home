import json
from pathlib import Path
import re
import shutil
import subprocess
import sys

root=Path(__file__).resolve().parent
repo=Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
sys.path.insert(0,str(repo/'bench/vs_tsgo'))
import run

commands=run.compiler_commands()
run.verified_compiler_versions(commands)
output=root/'recursive-constructor-import-probes'
output.mkdir(exist_ok=False)
records=[]
for dollar in (False,True):
    for heritage in (False,True):
        for constructor in (False,True):
            name=f'{"dollar" if dollar else "normal"}-{"error" if heritage else "flat"}-{"constructor" if constructor else "declare"}'
            folder=output/name
            symbol='$BaseError' if dollar else 'BaseError'
            run.write(folder/'tsconfig.json',run.shared_config())
            run.generate_minimal_lib(folder)
            run.write(folder/'src/error.d.ts','interface Error { name: string; message: string; stack?: string; }\n')
            owner='export interface Trait { state: { definition: unknown; output?: unknown; }; }\n'
            owner+=f'export interface {symbol}<T = unknown> {"extends Error " if heritage else ""}{{ type: T; issues: string[]; name: string; message: string; state: {{ definition: string[]; output: T; }}; }}\n'
            if constructor:
                owner+='export interface Constructor<T extends Trait, D = T["state"]["definition"]> { new(definition: D): T; init(instance: T, definition: D): void; }\n'
                owner+='export declare function make<T extends Trait, D = T["state"]["definition"]>(name: string, initializer: (instance: T, definition: D) => void): Constructor<T, D>;\n'
                owner+=f'export const {symbol}: Constructor<{symbol}> = make("Error", (instance, issues) => {{ instance.name = "Error"; instance.issues = issues; instance.message = "message"; }});\n'
            else:
                owner+=f'export declare const {symbol}: {{ init(instance: {symbol}, issues: string[]): void; }};\n'
            run.write(folder/'src/owner.ts',owner)
            run.write(folder/'src/barrel.ts','export * from "./owner.js";\n')
            consumer=f'import {{ {symbol} }} from "./barrel.js";\ninterface Derived<T = unknown> extends {symbol}<T> {{ format(): string; }}\ndeclare const error: Derived<number>;\nconst issue: string = error.issues[0];\nconst message: string = error.name + error.message;\nconst value: number = error.type;\nconst formatted: string = error.format();\nvoid issue; void message; void value; void formatted;\n'
            run.write(folder/'src/consumer.ts',consumer)
            negative=output/(name+'-negative')
            shutil.copytree(folder,negative)
            run.write(negative/'src/consumer.ts',consumer+'const wrong: string = error.type;\nerror.missing;\nvoid wrong;\n')
            for kind,project in [('positive',folder),('negative',negative)]:
                for compiler,command in commands.items():
                    argv=command+['--noEmit','-p',str(project/'tsconfig.json')]
                    result=subprocess.run(argv,capture_output=True,text=True)
                    text=result.stdout+result.stderr
                    codes=sorted(re.findall(r'error TS(\d+):',text))
                    records.append({'case':name,'kind':kind,'compiler':compiler,'command':argv,
                                    'exit':result.returncode,'stdout':result.stdout,'stderr':result.stderr,
                                    'codes':codes,'silent_success':result.returncode==0 and not text,
                                    'expected_negative_codes':['2322','2339']})
(root/'recursive-constructor-import-probes.json').write_text(json.dumps(records,indent=2)+'\n')
for row in records:
    print(row['case'],row['kind'],row['compiler'],'exit',row['exit'],'codes',row['codes'],flush=True)
print('General untimed positive/negative probes only, production unchanged; failures retained.')
