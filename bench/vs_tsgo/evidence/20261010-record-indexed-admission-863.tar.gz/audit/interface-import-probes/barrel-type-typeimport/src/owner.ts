export interface BaseError<T = unknown> { type: T; issues: string[]; name: string; message: string; }
