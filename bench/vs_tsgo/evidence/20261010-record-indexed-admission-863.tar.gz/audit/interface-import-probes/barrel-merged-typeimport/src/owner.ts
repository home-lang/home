export interface BaseError<T = unknown> { type: T; issues: string[]; name: string; message: string; }
export declare const BaseError: { init(instance: BaseError, issues: string[]): void };
