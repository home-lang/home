import { BaseError } from "./owner.js";
interface Derived<T = unknown> extends BaseError<T> { format(): string; }
declare const error: Derived<number>;
const issue: string = error.issues[0];
const message: string = error.name + error.message;
const value: number = error.type;
const formatted: string = error.format();
void issue; void message; void value; void formatted;
