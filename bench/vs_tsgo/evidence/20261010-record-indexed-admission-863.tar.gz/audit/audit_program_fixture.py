import json
from pathlib import Path
import re
import shutil
import subprocess
import sys

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
sys.path.insert(0, str(repo / 'bench/vs_tsgo'))
import run

source = (repo / 'packages/ts_program/src/ts_program.zig').read_text()
source = source.split('test "Program: imported interfaces retain exact Record index domains" {', 1)[1].split('\ntest ', 1)[0]
fixtures = {}
for name in ['owner', 'barrel', 'consumer', 'invalid']:
    declaration = re.search(r'    const ' + name + r' =(.*?)\n    ;', source, re.DOTALL)
    assert declaration, name
    text = '\n'.join(line.split('\\\\', 1)[1] for line in declaration[1].splitlines() if '\\\\' in line) + '\n'
    if name == 'invalid':
        text = fixtures['consumer'] + text
    fixtures[name] = text
output = root / 'program-record-fixture'
output.mkdir(exist_ok=False)
run.write(output / 'tsconfig.json', run.shared_config())
run.generate_minimal_lib(output)
run.write(output / 'src/record.d.ts', 'type Record<K extends keyof any, T> = { [P in K]: T };\ntype Readonly<T> = { readonly [P in keyof T]: T[P] };\n')
for name in ['owner', 'barrel', 'consumer']:
    run.write(output / ('src/' + name + '.ts'), fixtures[name])
negative = root / 'program-record-fixture-negative'
shutil.copytree(output, negative)
run.write(negative / 'src/consumer.ts', fixtures['invalid'])
commands = run.compiler_commands()
versions = run.verified_compiler_versions(commands)
records = []
for kind, folder in [('positive', output), ('negative', negative)]:
    for compiler in ['tsc', 'tsgo']:
        argv = commands[compiler] + ['--noEmit', '-p', str(folder / 'tsconfig.json')]
        result = subprocess.run(argv, capture_output=True, text=True)
        text = result.stdout + result.stderr
        codes = sorted(re.findall(r'error TS(\d+):', text))
        records.append({'kind': kind, 'compiler': compiler, 'command': argv,
                        'exit': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr, 'codes': codes})
(root / 'program-record-fixture-references.json').write_text(json.dumps({'versions': versions, 'records': records}, indent=2) + '\n')
for row in records:
    print(row['kind'], row['compiler'], row['exit'], row['codes'], flush=True)
