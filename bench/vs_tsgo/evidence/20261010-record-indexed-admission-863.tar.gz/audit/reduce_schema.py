"""Untimed diagnostic reduction; no production/benchmark graph edits."""
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
sys.path.insert(0, str(repo / 'bench/vs_tsgo'))
import run

binary = repo / 'zig-out/bin/home-tsc'
assert hashlib.sha256(binary.read_bytes()).hexdigest() == '8c5ead99d476113ca1bbb0610a5c469c405dc8b9b80e3e42f0d4692a80d48fe8'
source = (root / 'source/package/src/v4/core/json-schema.ts').read_text()
body = source.split('export type JSONSchema = {\n', 1)[1].split('\n};', 1)[0]
properties = re.split(r'(?=^  [\w$\[][^\n]*[?:])', body, flags=re.MULTILINE)
properties = [part for part in properties if part.strip()]
consumer = (root / 'isolated-exact-json-schema/src/consumer.ts').read_text()
folder = root / 'schema-reduction-object'
folder.mkdir(exist_ok=False)
records = []

def check(indices):
    case = folder / str(len(records))
    run.write(case / 'tsconfig.json', run.shared_config())
    run.generate_minimal_lib(case)
    run.write(case / 'src/record.d.ts', 'type Record<K extends keyof any, T> = { [P in K]: T };\n')
    owner = 'export type _JSONSchema = boolean | JSONSchema;\nexport type SchemaType = "object" | "array" | "string" | "number" | "boolean" | "null" | "integer";\n'
    owner += 'export type JSONSchema = {\n' + ''.join(properties[index] for index in indices) + '\n};\n'
    owner += 'export interface ObjectSchema extends JSONSchema { type: "object"; }\nexport interface StringSchema extends JSONSchema { type: "string"; }\n'
    run.write(case / 'src/json-schema.ts', owner)
    run.write(case / 'src/consumer.ts', consumer)
    argv = [str(binary), '--noEmit', '-p', str(case / 'tsconfig.json')]
    result = subprocess.run(argv, capture_output=True, text=True)
    text = result.stdout + result.stderr
    signature = 'consumer.ts(3,9): error TS2322:' in text
    reference_checks = []
    if signature:
        for compiler, command in run.compiler_commands().items():
            if compiler == 'home':
                continue
            reference = subprocess.run(command + ['--noEmit', '-p', str(case / 'tsconfig.json')], capture_output=True, text=True)
            reference_checks.append({'compiler': compiler, 'exit': reference.returncode, 'stdout': reference.stdout, 'stderr': reference.stderr})
            if reference.returncode or reference.stdout or reference.stderr:
                signature = False
    records.append({'indices': indices, 'project': str(case), 'command': argv, 'exit': result.returncode,
                    'stdout': result.stdout, 'stderr': result.stderr, 'signature': signature, 'reference_checks': reference_checks})
    (root / 'schema-reduction-object-progress.json').write_text(json.dumps(records, indent=2) + '\n')
    print(len(records), len(indices), result.returncode, signature, flush=True)
    return signature

current = list(range(len(properties)))
mandatory = {index for index, block in enumerate(properties) if block.lstrip().startswith('[k: string]')}
assert len(mandatory) == 1
assert check(current), 'Reduced declaration prefix did not preserve failure'
granularity = 2
while len(current) >= 2:
    partitions = [current[index::granularity] for index in range(granularity)]
    reduced = False
    for partition in partitions:
        subset = [index for index in current if index not in partition or index in mandatory]
        if subset == current:
            continue
        if subset and check(subset):
            current = subset
            granularity = max(2, granularity - 1)
            reduced = True
            break
    if reduced:
        continue
    if granularity >= len(current):
        break
    granularity = min(len(current), granularity * 2)
assert check(current)
final = Path(records[-1]['project'])
commands = run.compiler_commands()
commands['parent'] = [str(root / 'parent-home-tsc')]
references = []
for compiler, command in commands.items():
    argv = command + ['--noEmit', '-p', str(final / 'tsconfig.json')]
    result = subprocess.run(argv, capture_output=True, text=True)
    references.append({'compiler': compiler, 'exit': result.returncode, 'command': argv,
                       'stdout': result.stdout, 'stderr': result.stderr})
(root / 'schema-reduction-object.json').write_text(json.dumps({'property_blocks': properties,
    'minimal_indices': current, 'records': records, 'references': references}, indent=2) + '\n')
print('MINIMAL OWNER\n' + (final / 'src/json-schema.ts').read_text(), flush=True)
for result in references:
    print(result['compiler'], result['exit'], (result['stdout'] + result['stderr'])[:1800], flush=True)
