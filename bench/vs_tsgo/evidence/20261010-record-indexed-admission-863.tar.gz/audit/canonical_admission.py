"""Use the unchanged benchmark protocol's complete admission, without timing."""
import hashlib
import json
from pathlib import Path
import sys

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
sys.path.insert(0, str(repo / 'bench/vs_tsgo'))
import run
import competitors

revision = sys.argv[1] if len(sys.argv) > 1 else 'indexed-fixed'
build = json.loads((root / (revision + '-build.json')).read_text())
assert build['exit'] == 0
expected = build['native_sha256']
assert hashlib.sha256((repo / 'zig-out/bin/home-tsc').read_bytes()).hexdigest() == expected
profiles = competitors.load_profiles(repo / 'bench/vs_tsgo/profiles/darwin-arm64.json')
commands = run.compiler_commands(profiles)
versions = run.verified_compiler_versions(commands, profiles)
workloads = run.selected_workloads(None)
before = run.benchmark_provenance(commands, profiles)
trace = []
record = {'validation_schema': 4, 'workloads': workloads, 'versions': versions,
          'native_sha256': expected, 'before': before, 'records': trace, 'timings_taken': False, 'passed': False}
try:
    for workload in workloads:
        run.validate(commands, workload, profiles=profiles, trace=trace)
        (root / (revision + '-canonical-admission.json')).write_text(json.dumps(record, indent=2) + '\n')
        print(workload, 'admitted', flush=True)
    after = run.benchmark_provenance(commands, profiles)
    record['after'] = after
    assert after == before, 'Benchmark artifacts changed during admission'
    assert len(trace) == 145 and all(row['passed'] for row in trace)
    record['passed'] = True
except BaseException as error:
    record['error'] = str(error)
    raise
finally:
    (root / (revision + '-canonical-admission.json')).write_text(json.dumps(record, indent=2) + '\n')
print('All 145 protocol-4 admissions passed; no timers invoked.', flush=True)
