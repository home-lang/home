export interface Trait { state: { definition: unknown; output?: unknown; }; }
export interface $BaseError<T = unknown> { type: T; issues: string[]; name: string; message: string; state: { definition: string[]; output: T; }; }
export declare const $BaseError: { init(instance: $BaseError, issues: string[]): void; };
