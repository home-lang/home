export interface Trait { state: { definition: unknown; output?: unknown; }; }
export interface BaseError<T = unknown> extends Error { type: T; issues: string[]; name: string; message: string; state: { definition: string[]; output: T; }; }
export interface Constructor<T extends Trait, D = T["state"]["definition"]> { new(definition: D): T; init(instance: T, definition: D): void; }
export declare function make<T extends Trait, D = T["state"]["definition"]>(name: string, initializer: (instance: T, definition: D) => void): Constructor<T, D>;
export const BaseError: Constructor<BaseError> = make("Error", (instance, issues) => { instance.name = "Error"; instance.issues = issues; instance.message = "message"; });
