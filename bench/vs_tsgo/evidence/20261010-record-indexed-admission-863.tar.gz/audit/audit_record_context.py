import json
from pathlib import Path
import shutil
import subprocess
import sys

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
sys.path.insert(0, str(repo / 'bench/vs_tsgo'))
import run
mode = sys.argv[1] if len(sys.argv) > 1 else 'plain'
indexed = mode != 'plain'
name = mode + '-record-context-probe' if indexed else 'record-context-probe'
folder = root / name
run.write(folder / 'tsconfig.json', run.shared_config())
run.generate_minimal_lib(folder)
run.write(folder / 'src/record.d.ts', 'type Record<K extends keyof any, T> = { [P in K]: T };\n')
owner = 'export type Schema = { [key: string]: unknown; type?: "object" | "string"; properties?: Record<string, boolean | Schema>; };\n' if indexed else 'export interface Schema { type?: "object" | "string"; properties?: Record<string, boolean | Schema>; }\n'
specialized = 'export interface ObjectSchema extends Schema { type: "object"; }\n' if mode == 'indexed-interface' else 'export type ObjectSchema = Schema & { type: "object" };\n'
run.write(folder / 'src/owner.ts', owner + specialized)
consumer = 'import type * as api from "./owner.js";\ndeclare const properties: Record<string, boolean | api.Schema>;\nconst object: api.ObjectSchema = { type: "object", properties };\nvoid object;\n'
run.write(folder / 'src/consumer.ts', consumer)
negative = root / (name + '-negative')
shutil.copytree(folder, negative)
run.write(negative / 'src/consumer.ts', consumer + 'const wrong: api.ObjectSchema = { type: "string", properties };\nconst badProperties: api.ObjectSchema = { type: "object", properties: { wrong: 12 } };\nvoid wrong; void badProperties;\n')
commands = run.compiler_commands()
commands['parent'] = [str(root / 'parent-home-tsc')]
records = []
for kind, project in [('positive', folder), ('negative', negative)]:
    for compiler, command in commands.items():
        argv = command + ['--noEmit', '-p', str(project / 'tsconfig.json')]
        result = subprocess.run(argv, capture_output=True, text=True)
        records.append({'kind': kind, 'compiler': compiler, 'exit': result.returncode, 'command': argv,
                        'stdout': result.stdout, 'stderr': result.stderr})
(root / (name + '.json')).write_text(json.dumps(records, indent=2) + '\n')
for row in records:
    print(row['kind'], row['compiler'], row['exit'], (row['stdout'] + row['stderr'])[:800], flush=True)
