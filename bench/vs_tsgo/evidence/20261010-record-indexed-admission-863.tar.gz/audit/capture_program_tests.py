import hashlib
import json
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
binary = repo / '.zig-cache/o/dd2d562e84429dae541b95bc38c01a03/root'
result = subprocess.run([str(binary), '--seed=0x8170adce'], capture_output=True, text=True)
(root / 'first-candidate-program-tests.log').write_text(result.stdout + result.stderr)
(root / 'first-candidate-program-tests.json').write_text(json.dumps({
    'command': [str(binary), '--seed=0x8170adce'], 'exit': result.returncode,
    'binary_sha256': hashlib.sha256(binary.read_bytes()).hexdigest(),
    'purpose': 'Capture full correctness failure output after terminal truncation; no timing or changed build'}, indent=2) + '\n')
for line in (result.stdout + result.stderr).splitlines():
    if 'FAIL' in line or 'Expected' in line or 'passed;' in line:
        print(line, flush=True)
raise SystemExit(result.returncode)
