import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess

root=Path(__file__).resolve().parent
repo=Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
spec=importlib.util.spec_from_file_location('ratchet',repo/'scripts/ts-unmodeled-any-ratchet.py')
ratchet=importlib.util.module_from_spec(spec)
spec.loader.exec_module(ratchet)
baseline=ratchet.load_baseline(repo/'.github/ts-unmodeled-any-baseline.json')
archive=ratchet.obtain_archive(baseline['corpus'],None,root/'zod-4.5.2.tgz')
package=ratchet.extract_archive(archive,root/'source')
sources=ratchet.production_sources(package)
assert len(sources)==baseline['corpus']['production_files']==106
project=ratchet.write_project(package)
record={'corpus':baseline['corpus'],'production_files':len(sources),
        'source_parent':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo).decode().strip(),
        'native_sha256':hashlib.sha256((repo/'zig-out/bin/home-tsc').read_bytes()).hexdigest(),
        'config_sha256':hashlib.sha256(project.read_bytes()).hexdigest(),
        'inputs':{str(path.relative_to(package)):hashlib.sha256(path.read_bytes()).hexdigest() for path in sources},
        'production_sources_modified':False,'compiler_executed':False}
(root/'corpus-provenance.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({key:value for key,value in record.items() if key!='inputs'}))
