from pathlib import Path
import subprocess
import sys
root = Path(__file__).resolve().parent
with (root / 'second-candidate-program-tests.log').open('w') as output:
    result = subprocess.run([sys.executable, '/Users/chris/.cache/home-ts-843.3BeUMH/module_tests.py', 'program'], stdout=output, stderr=subprocess.STDOUT)
text = (root / 'second-candidate-program-tests.log').read_text()
for line in text.splitlines():
    if 'FAIL' in line or 'error:' in line or 'passed' in line or 'Expected' in line:
        print(line, flush=True)
raise SystemExit(result.returncode)
