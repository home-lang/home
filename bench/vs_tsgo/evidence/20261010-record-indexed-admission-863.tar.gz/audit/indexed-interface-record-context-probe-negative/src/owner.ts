export type Schema = { [key: string]: unknown; type?: "object" | "string"; properties?: Record<string, boolean | Schema>; };
export interface ObjectSchema extends Schema { type: "object"; }
