import type * as api from "./owner.js";
declare const properties: Record<string, boolean | api.Schema>;
const object: api.ObjectSchema = { type: "object", properties };
void object;
const wrong: api.ObjectSchema = { type: "string", properties };
const badProperties: api.ObjectSchema = { type: "object", properties: { wrong: 12 } };
void wrong; void badProperties;
