from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
command = [sys.executable, '-m', 'unittest', 'discover', '-s', 'bench/vs_tsgo', '-p', 'test_*.py']
with (root / 'final-harness.log').open('w') as output:
    result = subprocess.run(command, stdout=output, stderr=subprocess.STDOUT)
print((root / 'final-harness.log').read_text()[-300:], flush=True)
raise SystemExit(result.returncode)
