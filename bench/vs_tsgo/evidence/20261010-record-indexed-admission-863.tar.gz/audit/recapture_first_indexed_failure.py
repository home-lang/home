import hashlib
import json
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
binary = root / 'first-failed-indexed-interface-tests'
assert hashlib.sha256(binary.read_bytes()).hexdigest() == '94580401ad427249a98cda01381423844154c3a2989a827f27fd0aef98b35a57'
command = [str(binary), '--seed=0xc4878b4e']
result = subprocess.run(command, capture_output=True, text=True)
(root / 'first-indexed-interface-failure-recaptured.log').write_text(result.stdout + result.stderr)
(root / 'first-indexed-interface-failure-recaptured.json').write_text(json.dumps({
    'command': command, 'exit': result.returncode, 'binary_sha256': hashlib.sha256(binary.read_bytes()).hexdigest(),
    'purpose': 'Preserve complete original failing-test output from its exact retained binary and seed after the probe runner reused its output path; untimed correctness evidence only'}, indent=2) + '\n')
assert result.returncode == 1
print('Original failing binary/seed recaptured; exit 1 retained.', flush=True)
