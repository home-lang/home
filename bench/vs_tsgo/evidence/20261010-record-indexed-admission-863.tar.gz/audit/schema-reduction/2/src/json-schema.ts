export type _JSONSchema = boolean | JSONSchema;
export type SchemaType = "object" | "array" | "string" | "number" | "boolean" | "null" | "integer";
export type JSONSchema = {
  $anchor?: string;
  $vocabulary?: Record<string, boolean>;
  additionalItems?: _JSONSchema;
  contains?: _JSONSchema;
  patternProperties?: Record<string, _JSONSchema>;
  then?: _JSONSchema;
  oneOf?: JSONSchema[];
  exclusiveMaximum?: number | boolean;
  minLength?: number;
  uniqueItems?: boolean;
  minProperties?: number;
  const?: string | number | boolean | null;

  // metadata
  default?: unknown;
  nullable?: boolean;
  contentEncoding?: string;

};
export interface ObjectSchema extends JSONSchema { type: "object"; }
export interface StringSchema extends JSONSchema { type: "string"; }
