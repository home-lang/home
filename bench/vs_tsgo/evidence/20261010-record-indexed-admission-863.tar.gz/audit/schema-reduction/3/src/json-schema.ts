export type _JSONSchema = boolean | JSONSchema;
export type SchemaType = "object" | "array" | "string" | "number" | "boolean" | "null" | "integer";
export type JSONSchema = {
  $vocabulary?: Record<string, boolean>;
  contains?: _JSONSchema;
  then?: _JSONSchema;
  exclusiveMaximum?: number | boolean;
  uniqueItems?: boolean;
  const?: string | number | boolean | null;

  // metadata
  nullable?: boolean;

};
export interface ObjectSchema extends JSONSchema { type: "object"; }
export interface StringSchema extends JSONSchema { type: "string"; }
