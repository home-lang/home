import json
import os
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
revision = sys.argv[1] if len(sys.argv) > 1 else 'indexed-fixed'
records = []
for target in ['program', 'checker', 'driver', 'cli', 'entrypoint']:
    command = ['perl', 'scripts/run-bounded.pl', '600', sys.executable,
               '/Users/chris/.cache/home-ts-843.3BeUMH/module_tests.py', target]
    environment = dict(os.environ, HOME_RUN_MAX_MB='3840', HOME_RUN_LABEL='ts-' + revision + '-' + target + '-tests')
    log = revision + '-' + target + '-tests.log'
    with (root / log).open('w') as output:
        result = subprocess.run(command, cwd=repo, env=environment, stdout=output, stderr=subprocess.STDOUT)
    records.append({'target': target, 'command': command, 'exit': result.returncode, 'log': log})
    (root / (revision + '-gates.json')).write_text(json.dumps(records, indent=2) + '\n')
    print(target, 'exit', result.returncode, flush=True)
    text = (root / log).read_text()
    for line in text.splitlines():
        if 'FAIL' in line or 'error:' in line or 'tests passed' in line or 'passed;' in line or 'run-bounded:' in line:
            print(line, flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)
