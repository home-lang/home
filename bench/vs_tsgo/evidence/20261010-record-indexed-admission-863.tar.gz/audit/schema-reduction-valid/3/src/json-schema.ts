export type _JSONSchema = boolean | JSONSchema;
export type SchemaType = "object" | "array" | "string" | "number" | "boolean" | "null" | "integer";
export type JSONSchema = {
  [k: string]: unknown;
  $schema?:
    | "https://json-schema.org/draft/2020-12/schema"
    | "http://json-schema.org/draft-07/schema#"
    | "http://json-schema.org/draft-04/schema#";
  $defs?: Record<string, JSONSchema>;
  unevaluatedProperties?: _JSONSchema;
  allOf?: JSONSchema[];
  exclusiveMinimum?: number | boolean;
  minContains?: number;
  title?: string;
  format?: string;

};
export interface ObjectSchema extends JSONSchema { type: "object"; }
export interface StringSchema extends JSONSchema { type: "string"; }
