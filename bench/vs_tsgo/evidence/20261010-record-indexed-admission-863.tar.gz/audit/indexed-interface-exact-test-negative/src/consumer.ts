import type * as api from "./owner.js";
const wrongNode: api.Node = { kind: "leaf" };
const wrongBase: api.Base = { kind: "other" };
export function wrongReturn(value: api.Leaf): api.Node { return value; }
void wrongNode; void wrongBase;
