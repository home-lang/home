export type Kind = "node" | "leaf";
export type Base = { [key: string]: unknown; kind?: Kind | Kind[]; };
export interface Node extends Base { kind: "node"; }
export interface Leaf extends Base { kind: "leaf"; }
