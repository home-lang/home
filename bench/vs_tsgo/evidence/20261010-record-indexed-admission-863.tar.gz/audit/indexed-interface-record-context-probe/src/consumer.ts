import type * as api from "./owner.js";
declare const properties: Record<string, boolean | api.Schema>;
const object: api.ObjectSchema = { type: "object", properties };
void object;
