export type _JSONSchema = boolean | JSONSchema;
export type SchemaType = "object" | "array" | "string" | "number" | "boolean" | "null" | "integer";
export type JSONSchema = {
  [k: string]: unknown;
  $id?: string;
  $dynamicAnchor?: string;
  type?: SchemaType | SchemaType[];
  items?: _JSONSchema | _JSONSchema[];
  properties?: Record<string, _JSONSchema>;
  if?: _JSONSchema;
  anyOf?: JSONSchema[];
  maximum?: number;
  maxLength?: number;
  minItems?: number;
  maxProperties?: number;
  enum?: Array<string | number | boolean | null>;
  description?: string;
  writeOnly?: boolean;
  contentMediaType?: string;

};
export interface ObjectSchema extends JSONSchema { type: "object"; }
export interface StringSchema extends JSONSchema { type: "string"; }
