export type _JSONSchema = boolean | JSONSchema;
export type SchemaType = "object" | "array" | "string" | "number" | "boolean" | "null" | "integer";
export type JSONSchema = {
  [k: string]: unknown;
  $schema?:
    | "https://json-schema.org/draft/2020-12/schema"
    | "http://json-schema.org/draft-07/schema#"
    | "http://json-schema.org/draft-04/schema#";
  $anchor?: string;
  $dynamicRef?: string;
  $vocabulary?: Record<string, boolean>;
  $defs?: Record<string, JSONSchema>;
  additionalItems?: _JSONSchema;
  prefixItems?: _JSONSchema[];
  contains?: _JSONSchema;
  unevaluatedProperties?: _JSONSchema;
  patternProperties?: Record<string, _JSONSchema>;
  propertyNames?: _JSONSchema;
  then?: _JSONSchema;
  allOf?: JSONSchema[];
  oneOf?: JSONSchema[];
  multipleOf?: number;
  exclusiveMaximum?: number | boolean;
  exclusiveMinimum?: number | boolean;
  minLength?: number;
  maxItems?: number;
  uniqueItems?: boolean;
  minContains?: number;
  minProperties?: number;
  dependentRequired?: Record<string, string[]>;
  const?: string | number | boolean | null;

  // metadata
  title?: string;
  default?: unknown;
  readOnly?: boolean;
  nullable?: boolean;
  format?: string;
  contentEncoding?: string;
  _prefault?: unknown;
};
export interface ObjectSchema extends JSONSchema { type: "object"; }
export interface StringSchema extends JSONSchema { type: "string"; }
