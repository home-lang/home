export type _JSONSchema = boolean | JSONSchema;
export type SchemaType = "object" | "array" | "string" | "number" | "boolean" | "null" | "integer";
export type JSONSchema = {
  [k: string]: unknown;
  $id?: string;
  $ref?: string;
  $dynamicAnchor?: string;
  $comment?: string;
  type?: SchemaType | SchemaType[];
  unevaluatedItems?: _JSONSchema;
  items?: _JSONSchema | _JSONSchema[];
  additionalProperties?: _JSONSchema;
  properties?: Record<string, _JSONSchema>;
  dependentSchemas?: Record<string, _JSONSchema>;
  if?: _JSONSchema;
  else?: _JSONSchema;
  anyOf?: JSONSchema[];
  not?: _JSONSchema;
  maximum?: number;
  minimum?: number;
  maxLength?: number;
  pattern?: string;
  minItems?: number;
  maxContains?: number;
  maxProperties?: number;
  required?: string[];
  enum?: Array<string | number | boolean | null>;
  id?: string;
  description?: string;
  deprecated?: boolean;
  writeOnly?: boolean;
  examples?: unknown[];
  contentMediaType?: string;
  contentSchema?: JSONSchema;

  // internal

};
export interface ObjectSchema extends JSONSchema { type: "object"; }
export interface StringSchema extends JSONSchema { type: "string"; }
