export type _JSONSchema = boolean | JSONSchema;
export type SchemaType = "object" | "array" | "string" | "number" | "boolean" | "null" | "integer";
export type JSONSchema = {
  [k: string]: unknown;

};
export interface ObjectSchema extends JSONSchema { type: "object"; }
export interface StringSchema extends JSONSchema { type: "string"; }
