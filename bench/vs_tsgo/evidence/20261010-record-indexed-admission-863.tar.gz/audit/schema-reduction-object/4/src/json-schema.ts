export type _JSONSchema = boolean | JSONSchema;
export type SchemaType = "object" | "array" | "string" | "number" | "boolean" | "null" | "integer";
export type JSONSchema = {
  [k: string]: unknown;
  $id?: string;
  type?: SchemaType | SchemaType[];
  properties?: Record<string, _JSONSchema>;
  anyOf?: JSONSchema[];
  maxLength?: number;
  maxProperties?: number;
  description?: string;
  contentMediaType?: string;

};
export interface ObjectSchema extends JSONSchema { type: "object"; }
export interface StringSchema extends JSONSchema { type: "string"; }
