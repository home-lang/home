import ast
import json
from pathlib import Path
import shlex
import subprocess

root = Path(__file__).resolve().parent
source = Path('/Users/chris/.cache/home-ts-843.3BeUMH/module_tests.py').read_text()
tree = ast.parse(source)
assignment = next(node for node in tree.body if isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and target.id == 'BUILD_COMMAND' for target in node.targets))
argv = shlex.split(ast.literal_eval(assignment.value))
modules = {}
deps = []
index = 2
while index < len(argv):
    token = argv[index]
    if token == '--dep':
        index += 1
        deps.append(argv[index])
    elif token.startswith('-M'):
        name, path = token[2:].split('=', 1)
        modules[name] = {'path': path, 'deps': deps}
        deps = []
    index += 1
target = 'ts_program'
reachable = {target}
pending = [target]
while pending:
    for name in modules[pending.pop()]['deps']:
        if name not in reachable:
            reachable.add(name)
            pending.append(name)
command = [argv[0], 'test', '-fstrip', '--test-filter', 'imported indexed interface retains literal context and return identity']
for name in [target] + [name for name in modules if name in reachable and name != target]:
    command += ['-OReleaseFast']
    for dep in modules[name]['deps']:
        command += ['--dep', dep]
    command += ['-M' + ('root' if name == target else name) + '=' + modules[name]['path']]
for flag in ['--cache-dir', '--global-cache-dir', '--zig-lib-dir']:
    command += [flag, argv[argv.index(flag) + 1]]
with (root / 'indexed-interface-internal-probe.log').open('w') as output:
    result = subprocess.run(command, stdout=output, stderr=subprocess.STDOUT)
(root / 'indexed-interface-internal-probe.json').write_text(json.dumps({'command': command, 'exit': result.returncode}, indent=2) + '\n')
print((root / 'indexed-interface-internal-probe.log').read_text(), flush=True)
raise SystemExit(result.returncode)
