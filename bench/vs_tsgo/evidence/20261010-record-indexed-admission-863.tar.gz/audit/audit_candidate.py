import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
binary = repo / 'zig-out/bin/home-tsc'
revision = sys.argv[1] if len(sys.argv) > 1 else 'candidate'
records = []
for source in ['interface-import-probes', 'recursive-constructor-import-probes', 'cyclic-import-probes', 'record-import-probes']:
    for parent in json.loads((root / (source + '.json')).read_text()):
        if parent['compiler'] != 'home':
            continue
        argv = [str(binary)] + parent['command'][1:]
        result = subprocess.run(argv, capture_output=True, text=True)
        text = result.stdout + result.stderr
        record = {'suite': source, 'case': parent['case'], 'kind': parent.get('kind', 'positive'),
                  'command': argv, 'exit': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr,
                  'codes': sorted(re.findall(r'error TS(\d+):', text)),
                  'silent_success': result.returncode == 0 and not text}
        records.append(record)
        (root / (revision + '-probe-progress.json')).write_text(json.dumps(records, indent=2) + '\n')
        print(source, record['case'], record['kind'], result.returncode, record['codes'], flush=True)
for source in ['program-record-fixture-references', 'indexed-interface-exact-test-references', 'isolated-exact-json-schema']:
    original = json.loads((root / (source + '.json')).read_text())
    if isinstance(original, dict):
        original = original['records']
    for reference in original:
        if reference['compiler'] != 'tsgo':
            continue
        argv = [str(binary)] + reference['command'][1:]
        result = subprocess.run(argv, capture_output=True, text=True)
        text = result.stdout + result.stderr
        record = {'suite': source, 'case': source, 'kind': reference['kind'], 'command': argv,
                  'exit': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr,
                  'codes': sorted(re.findall(r'error TS(\d+):', text)),
                  'silent_success': result.returncode == 0 and not text}
        records.append(record)
        (root / (revision + '-probe-progress.json')).write_text(json.dumps(records, indent=2) + '\n')
        print(source, record['kind'], result.returncode, record['codes'], flush=True)
provenance = json.loads((root / 'corpus-provenance.json').read_text())
package = root / 'source/package'
for relative, expected in provenance['inputs'].items():
    assert hashlib.sha256((package / relative).read_bytes()).hexdigest() == expected
project = package / 'tsconfig.benchmark.json'
assert hashlib.sha256(project.read_bytes()).hexdigest() == provenance['config_sha256']
argv = [str(binary), '--noEmit', '-p', str(project), '--home-list-unmodeled-any']
result = subprocess.run(argv, capture_output=True, text=True)
text = result.stdout + result.stderr
corpus = {'command': argv, 'exit': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr,
          'diagnostic_counts': {code: len(re.findall(r'\b' + code + r':', text))
                                for code in sorted(set(re.findall(r'\b((?:TS|HM)\d+):', text)))}}
(root / (revision + '-admission.json')).write_text(json.dumps({
    'native_sha256': hashlib.sha256(binary.read_bytes()).hexdigest(),
    'probe_records': records, 'corpus': corpus, 'timings_taken': False}, indent=2) + '\n')
print('Original Zod production hashes verified:', corpus['exit'], corpus['diagnostic_counts'], flush=True)
