type Record<K extends keyof any, T> = { [P in K]: T };
type Readonly<T> = { readonly [P in keyof T]: T[P] };
