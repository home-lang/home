export interface Base<T> {
  value: T;
  strings: Record<string, string>;
  numbers: Record<number, boolean>;
  symbols: Record<symbol, number>;
  mixed: Record<string | number | symbol, string>;
  frozen: Readonly<Record<string, number>>;
}
