import json
from pathlib import Path
import re
import shutil
import subprocess
import sys

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
sys.path.insert(0, str(repo / 'bench/vs_tsgo'))
import run

commands = run.compiler_commands()
run.verified_compiler_versions(commands)
output = root / 'cyclic-import-probes'
output.mkdir(exist_ok=False)
records = []
for cycle in (False, True):
    for namespace in (False, True):
        name = f'{"cyclic" if cycle else "acyclic"}-{"namespace" if namespace else "named"}'
        folder = output / name
        run.write(folder / 'tsconfig.json', run.shared_config())
        run.generate_minimal_lib(folder)
        run.write(folder / 'src/error.d.ts', 'interface Error { name: string; message: string; stack?: string; }\n')
        factory = 'import type * as errors from "./owner.js";\n' if cycle else ''
        factory += 'export interface Trait { state: { definition: unknown; output?: unknown; }; }\n'
        factory += 'export interface Constructor<T extends Trait, D = T["state"]["definition"]> { new(definition: D): T; init(instance: T, definition: D): asserts instance is T; }\n'
        factory += 'export declare function Constructor<T extends Trait, D = T["state"]["definition"]>(name: string, initializer: (instance: T, definition: D) => void): Constructor<T, D>;\n'
        if cycle:
            factory += 'export type Related = errors.BaseError<number>;\n'
        run.write(folder / 'src/factory.ts', factory)
        owner = 'import { Constructor } from "./factory.js";\n'
        owner += 'export interface BaseError<T = unknown> extends Error { type: T; issues: string[]; state: { definition: string[]; output: T; }; }\n'
        owner += 'const initializer = (instance: BaseError, issues: string[]): void => { instance.name = "Error"; instance.issues = issues; };\n'
        owner += 'export const BaseError: Constructor<BaseError> = Constructor("Error", initializer);\n'
        run.write(folder / 'src/owner.ts', owner)
        run.write(folder / 'src/barrel.ts', 'export * from "./factory.js";\nexport * from "./owner.js";\n')
        consumer = 'import * as api from "./barrel.js";\n' if namespace else ''
        consumer += 'import { BaseError } from "./barrel.js";\n'
        consumer += 'export interface Derived<T = unknown> extends BaseError<T> { format(): string; }\n'
        consumer += 'declare const error: Derived<number>;\nconst value: number = error.type;\nconst message: string = error.name + error.message;\nconst issue: string = error.issues[0];\nvoid value; void message; void issue;\n'
        if namespace:
            consumer += 'export const Derived: api.Constructor<Derived> = api.Constructor("Derived", (instance, issues) => { instance.issues = issues; });\n'
        run.write(folder / 'src/consumer.ts', consumer)
        negative = output / (name + '-negative')
        shutil.copytree(folder, negative)
        run.write(negative / 'src/consumer.ts', consumer + 'const wrong: string = error.type;\nerror.missing; void wrong;\n')
        for kind, project in [('positive', folder), ('negative', negative)]:
            for compiler, command in commands.items():
                argv = command + ['--noEmit', '-p', str(project / 'tsconfig.json')]
                result = subprocess.run(argv, capture_output=True, text=True)
                text = result.stdout + result.stderr
                records.append({'case': name, 'kind': kind, 'compiler': compiler, 'command': argv,
                                'exit': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr,
                                'codes': sorted(re.findall(r'error TS(\d+):', text)),
                                'silent_success': result.returncode == 0 and not text,
                                'expected_negative_codes': ['2322', '2339']})
(root / 'cyclic-import-probes.json').write_text(json.dumps(records, indent=2) + '\n')
for row in records:
    print(row['case'], row['kind'], row['compiler'], row['exit'], row['codes'], flush=True)
