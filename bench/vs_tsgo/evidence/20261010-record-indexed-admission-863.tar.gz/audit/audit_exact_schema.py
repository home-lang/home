import json
from pathlib import Path
import shutil
import subprocess
import sys

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
sys.path.insert(0, str(repo / 'bench/vs_tsgo'))
import run
folder = root / 'isolated-exact-json-schema'
run.write(folder / 'tsconfig.json', run.shared_config())
run.generate_minimal_lib(folder)
run.write(folder / 'src/record.d.ts', 'type Record<K extends keyof any, T> = { [P in K]: T };\n')
owner = root / 'source/package/src/v4/core/json-schema.ts'
run.write(folder / 'src/json-schema.ts', owner.read_text())
consumer = '''import type * as JSONSchema from "./json-schema.js";
export function folded(properties: Record<string, JSONSchema._JSONSchema>): JSONSchema.ObjectSchema {
  const object: JSONSchema.ObjectSchema = { type: "object", properties };
  return object;
}
export function file(): JSONSchema.StringSchema {
  const value: JSONSchema.StringSchema = { type: "string", format: "binary", contentEncoding: "binary" };
  return value;
}
'''
run.write(folder / 'src/consumer.ts', consumer)
negative = root / 'isolated-exact-json-schema-negative'
shutil.copytree(folder, negative)
run.write(negative / 'src/consumer.ts', consumer + 'const wrong: JSONSchema.ObjectSchema = { type: "string" };\nconst bad: JSONSchema.ObjectSchema = { type: "object", properties: { wrong: 12 } };\nvoid wrong; void bad;\n')
commands = run.compiler_commands()
commands['parent'] = [str(root / 'parent-home-tsc')]
records = []
for kind, project in [('positive', folder), ('negative', negative)]:
    for compiler, command in commands.items():
        argv = command + ['--noEmit', '-p', str(project / 'tsconfig.json')]
        result = subprocess.run(argv, capture_output=True, text=True)
        records.append({'kind': kind, 'compiler': compiler, 'exit': result.returncode, 'command': argv,
                        'stdout': result.stdout, 'stderr': result.stderr})
(root / 'isolated-exact-json-schema.json').write_text(json.dumps(records, indent=2) + '\n')
for row in records:
    print(row['kind'], row['compiler'], row['exit'], (row['stdout'] + row['stderr'])[:1500], flush=True)
