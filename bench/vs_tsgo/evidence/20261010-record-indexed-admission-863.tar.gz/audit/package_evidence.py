import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
verified = json.loads((root / 'verified-final-admission.json').read_text())
synced = json.loads((root / 'verified-main-sync.json').read_text())
assert verified['passed'] and synced['passed']
assert hashlib.sha256((repo / 'zig-out/bin/home-tsc').read_bytes()).hexdigest() == verified['native_sha256']
assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=repo).decode() == ''
output = repo / 'bench/vs_tsgo/evidence/20261010-record-indexed-admission-863.tar.gz'
assert not output.exists()
excluded = {'parent-home-tsc', 'indexed-fixed-home-tsc', 'first-failed-indexed-interface-tests',
            'indexed-safe-home-tsc', 'package-evidence.json', 'next-state.json'}
entries = {}
for path in sorted(root.rglob('*')):
    assert not path.is_symlink(), path
    if not path.is_file() or path.name in excluded or '__pycache__' in path.parts:
        continue
    entries['audit/' + str(path.relative_to(root))] = path.read_bytes()
source_paths = ['AGENTS.md', 'build.zig',
    'packages/ts_checker/src/check.zig', 'packages/ts_checker/src/program_schema.zig',
    'packages/ts_program/src/class_schema.zig', 'packages/ts_program/src/ts_program.zig',
    'bench/vs_tsgo/run.py', 'bench/vs_tsgo/compare.py', 'bench/vs_tsgo/competitors.py',
    'bench/vs_tsgo/corpus.toml', 'bench/vs_tsgo/profiles/darwin-arm64.json',
    '.github/ts-unmodeled-any-baseline.json', 'scripts/ts-unmodeled-any-ratchet.py', 'scripts/run-bounded.pl']
for relative in source_paths:
    entries['qualified-source/' + relative] = (repo / relative).read_bytes()
for path in sorted((repo / 'bench/vs_tsgo/corpus').rglob('*')):
    if path.is_file():
        entries['benchmark-inputs/' + str(path.relative_to(repo / 'bench/vs_tsgo/corpus'))] = path.read_bytes()
publication = {'source_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip(),
    'native_sha256': verified['native_sha256'], 'qualified_gate_source_parent': verified['source_parent'],
    'main_sync': synced, 'timings_taken': False, 'zod_admitted': False,
    'general_probes': 48, 'supported_general_checks': 46, 'unsupported_finite_record_checks': 2,
    'canonical_admissions': 145, 'zod_TS': 241, 'zod_HM9002': 2,
    'previous_failures_and_invalid_reductions_retained': True,
    'native_binaries_excluded': True, 'universal_leadership_proven': False}
entries['publication.json'] = (json.dumps(publication, indent=2) + '\n').encode()
checksums = {name: hashlib.sha256(data).hexdigest() for name, data in entries.items()}
entries['SHA256SUMS'] = ''.join(checksums[name] + '  ' + name + '\n' for name in sorted(checksums)).encode()
with output.open('xb') as raw:
    with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as archive:
            for name, data in sorted(entries.items()):
                info = tarfile.TarInfo(name)
                info.size = len(data)
                info.mode = 0o644
                archive.addfile(info, io.BytesIO(data))
with tarfile.open(output, 'r:gz') as archive:
    for name, expected in checksums.items():
        assert hashlib.sha256(archive.extractfile(name).read()).hexdigest() == expected, name
record = {'archive': str(output.relative_to(repo)), 'sha256': hashlib.sha256(output.read_bytes()).hexdigest(),
    'payload_checksums': len(checksums), 'bytes': output.stat().st_size, 'verified': True, 'publication': publication}
(root / 'package-evidence.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({key: value for key, value in record.items() if key != 'publication'}), flush=True)
