export interface Base<T> { value: T; metadata: Record<number, string>; }
