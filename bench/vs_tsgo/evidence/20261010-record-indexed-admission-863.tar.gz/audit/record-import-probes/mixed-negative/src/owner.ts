export interface Base<T> { value: T; metadata: Record<string | number | symbol, string>; }
