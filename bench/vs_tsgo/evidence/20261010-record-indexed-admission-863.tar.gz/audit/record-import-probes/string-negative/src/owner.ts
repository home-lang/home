export interface Base<T> { value: T; metadata: Record<string, string>; }
