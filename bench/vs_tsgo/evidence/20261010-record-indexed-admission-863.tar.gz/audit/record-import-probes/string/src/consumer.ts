import type { Base } from "./barrel.js";
interface Derived<T> extends Base<T> { extra: string; }
declare const item: Derived<number>;
const value: number = item.value; void value;
declare const key: string;
const text: string = item.metadata[key]; void text;
