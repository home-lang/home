export interface Base<T> { value: T; metadata: Record<"one" | "two", string>; }
