export interface Base<T> { value: T; metadata: Record<symbol, string>; }
