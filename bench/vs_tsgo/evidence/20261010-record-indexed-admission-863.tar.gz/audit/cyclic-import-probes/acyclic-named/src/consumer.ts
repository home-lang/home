import { BaseError } from "./barrel.js";
export interface Derived<T = unknown> extends BaseError<T> { format(): string; }
declare const error: Derived<number>;
const value: number = error.type;
const message: string = error.name + error.message;
const issue: string = error.issues[0];
void value; void message; void issue;
