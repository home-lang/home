import { Constructor } from "./factory.js";
export interface BaseError<T = unknown> extends Error { type: T; issues: string[]; state: { definition: string[]; output: T; }; }
const initializer = (instance: BaseError, issues: string[]): void => { instance.name = "Error"; instance.issues = issues; };
export const BaseError: Constructor<BaseError> = Constructor("Error", initializer);
