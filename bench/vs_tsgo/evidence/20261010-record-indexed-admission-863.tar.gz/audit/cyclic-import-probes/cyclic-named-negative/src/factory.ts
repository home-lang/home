import type * as errors from "./owner.js";
export interface Trait { state: { definition: unknown; output?: unknown; }; }
export interface Constructor<T extends Trait, D = T["state"]["definition"]> { new(definition: D): T; init(instance: T, definition: D): asserts instance is T; }
export declare function Constructor<T extends Trait, D = T["state"]["definition"]>(name: string, initializer: (instance: T, definition: D) => void): Constructor<T, D>;
export type Related = errors.BaseError<number>;
