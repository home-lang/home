import type { Base } from "./barrel.js";
import type * as api from "./barrel.js";
interface Derived<T> extends Base<T> { extra: string; }
declare const item: Derived<number>;
declare const qualified: api.Base<number>;
declare const key: symbol;
const value: number = item.value;
const text: string = item.strings["key"];
const flag: boolean = item.numbers[1];
const count: number = item.symbols[key];
const first: string = item.mixed["key"];
const second: string = item.mixed[1];
const third: string = item.mixed[key];
const frozen: number = item.frozen["key"];
const transferred: string = qualified.strings["key"];
void value; void text; void flag; void count;
void first; void second; void third; void frozen; void transferred;
