export interface Schema { type?: "object" | "string"; properties?: Record<string, boolean | Schema>; }
export type ObjectSchema = Schema & { type: "object" };
