import json
from pathlib import Path
import re
import shutil
import subprocess
import sys

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
sys.path.insert(0, str(repo / 'bench/vs_tsgo'))
import run

commands = run.compiler_commands()
run.verified_compiler_versions(commands)
output = root / 'record-import-probes'
output.mkdir(exist_ok=False)
records = []
for key in ['string', 'number', 'symbol', 'string | number | symbol', '"one" | "two"']:
    name = {'string': 'string', 'number': 'number', 'symbol': 'symbol', 'string | number | symbol': 'mixed', '"one" | "two"': 'literal'}[key]
    folder = output / name
    run.write(folder / 'tsconfig.json', run.shared_config())
    run.generate_minimal_lib(folder)
    run.write(folder / 'src/record.d.ts', 'type Record<K extends keyof any, T> = { [P in K]: T };\n')
    run.write(folder / 'src/owner.ts', f'export interface Base<T> {{ value: T; metadata: Record<{key}, string>; }}\n')
    run.write(folder / 'src/barrel.ts', 'export * from "./owner.js";\n')
    consumer = 'import type { Base } from "./barrel.js";\ninterface Derived<T> extends Base<T> { extra: string; }\ndeclare const item: Derived<number>;\nconst value: number = item.value; void value;\n'
    consumer += 'declare const key: ' + key + ';\nconst text: string = item.metadata[key]; void text;\n'
    run.write(folder / 'src/consumer.ts', consumer)
    negative = output / (name + '-negative')
    shutil.copytree(folder, negative)
    run.write(negative / 'src/consumer.ts', consumer + 'const wrong: boolean = item.metadata[key];\nconst wrongValue: string = item.value; item.missing; void wrong; void wrongValue;\n')
    for kind, project in [('positive', folder), ('negative', negative)]:
        for compiler, command in commands.items():
            argv = command + ['--noEmit', '-p', str(project / 'tsconfig.json')]
            result = subprocess.run(argv, capture_output=True, text=True)
            text = result.stdout + result.stderr
            records.append({'case': name, 'kind': kind, 'compiler': compiler, 'command': argv,
                            'exit': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr,
                            'codes': sorted(re.findall(r'error TS(\d+):', text)),
                            'silent_success': result.returncode == 0 and not text,
                            'expected_negative_codes': ['2322', '2322', '2339']})
(root / 'record-import-probes.json').write_text(json.dumps(records, indent=2) + '\n')
for row in records:
    print(row['case'], row['kind'], row['compiler'], row['exit'], row['codes'], flush=True)
