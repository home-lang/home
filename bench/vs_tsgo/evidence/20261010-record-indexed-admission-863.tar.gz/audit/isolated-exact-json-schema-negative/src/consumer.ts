import type * as JSONSchema from "./json-schema.js";
export function folded(properties: Record<string, JSONSchema._JSONSchema>): JSONSchema.ObjectSchema {
  const object: JSONSchema.ObjectSchema = { type: "object", properties };
  return object;
}
export function file(): JSONSchema.StringSchema {
  const value: JSONSchema.StringSchema = { type: "string", format: "binary", contentEncoding: "binary" };
  return value;
}
const wrong: JSONSchema.ObjectSchema = { type: "string" };
const bad: JSONSchema.ObjectSchema = { type: "object", properties: { wrong: 12 } };
void wrong; void bad;
