import hashlib
import json
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
revision = sys.argv[1] if len(sys.argv) > 1 else 'candidate'
command = ['/Users/chris/Code/Home/lang-bun-port/zig-out/toolchains/zig-aarch64-macos-0.17.0-dev.2163+89ff10d56/zig',
           'build', 'home-tsc', '-Doptimize=ReleaseFast', '-Dhome-tsc-strip=true', '-Denable_jsc=false', '-j1', '--summary', 'all']
with (root / (revision + '-build.log')).open('w') as output:
    result = subprocess.run(command, cwd=repo, stdout=output, stderr=subprocess.STDOUT)
record = {'command': command, 'exit': result.returncode,
          'source_diff': subprocess.check_output(['git', 'diff'], cwd=repo).decode()}
if result.returncode == 0:
    record['native_sha256'] = hashlib.sha256((repo / 'zig-out/bin/home-tsc').read_bytes()).hexdigest()
(root / (revision + '-build.json')).write_text(json.dumps(record, indent=2) + '\n')
print((root / (revision + '-build.log')).read_text(), flush=True)
raise SystemExit(result.returncode)
