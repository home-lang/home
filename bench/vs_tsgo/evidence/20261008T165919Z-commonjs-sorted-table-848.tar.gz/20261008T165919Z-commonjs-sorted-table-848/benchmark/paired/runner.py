#!/usr/bin/env python3
"""Temporary exact-parent paired benchmark runner for home-lang/home#848."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import shlex
import shutil
import statistics
import subprocess
import sys
import tempfile


REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO / "bench/vs_tsgo"))
import competitors  # noqa: E402
import run  # noqa: E402


def args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--parent", type=Path, required=True)
    parser.add_argument("--candidate", type=Path, required=True)
    parser.add_argument("--scale", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    return parser.parse_args()


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def command_output(argv: list[str]) -> str:
    result = subprocess.run(argv, check=True, capture_output=True, text=True)
    return (result.stdout + result.stderr).strip()


def artifact(path: Path) -> dict[str, object]:
    resolved = path.resolve(strict=True)
    return {
        "path": str(resolved),
        "size": resolved.stat().st_size,
        "sha256": run.sha256_file(resolved),
    }


def scale_admission(
    commands: dict[str, list[str]], scale: Path, trace: list[dict[str, object]]
) -> None:
    config = scale / "tsconfig.json"
    for name, command in commands.items():
        result = subprocess.run(
            command + ["--noEmit", "-p", str(config)],
            capture_output=True,
            text=True,
        )
        passed = result.returncode == 0 and not result.stdout and not result.stderr
        trace.append(
            {
                "compiler": name,
                "workload": "commonjs_graph_scale1024",
                "kind": "positive",
                "command": command + ["--noEmit", "-p", str(config)],
                "exit_code": result.returncode,
                "stdout": result.stdout,
                "stderr": result.stderr,
                "codes": [],
                "passed": passed,
            }
        )
        if not passed:
            raise SystemExit(f"{name} failed the scale positive admission")

    with tempfile.TemporaryDirectory(prefix="home-848-scale-negative-") as temporary:
        negative = Path(temporary) / "project"
        shutil.copytree(scale, negative)
        indices = (0, 512, 1023)
        invalid = "".join(
            f"/** @type {{boolean}} */ const wrongLabel{index} = service{index}.label;\n"
            f"const missing{index} = service{index}.missing;\n"
            for index in indices
        )
        source = negative / "src/index.js"
        source.write_text(source.read_text(encoding="utf-8") + invalid, encoding="utf-8")
        expected = sorted(["2322"] * 3 + ["2339"] * 3)
        for name, command in commands.items():
            argv = command + ["--noEmit", "-p", str(negative / "tsconfig.json")]
            result = subprocess.run(argv, capture_output=True, text=True)
            codes = sorted(re.findall(r"\berror TS(\d+):", result.stdout + result.stderr))
            passed = result.returncode in (1, 2) and codes == expected
            trace.append(
                {
                    "compiler": name,
                    "workload": "commonjs_graph_scale1024",
                    "kind": "negative",
                    "command": argv,
                    "exit_code": result.returncode,
                    "stdout": result.stdout,
                    "stderr": result.stderr,
                    "expected_codes": expected,
                    "codes": codes,
                    "passed": passed,
                }
            )
            if not passed:
                raise SystemExit(f"{name} failed the scale negative admission: {codes}")


def paired_workload(
    name: str,
    project: Path,
    commands: dict[str, list[str]],
    output: Path,
    rounds: int,
) -> dict[str, object]:
    print(f"benchmark {name}: {rounds} alternating pairs", flush=True)
    argv = {
        compiler: command + ["--noEmit", "-p", str(project)]
        for compiler, command in commands.items()
    }
    for _ in range(3):
        for command in argv.values():
            result = subprocess.run(command, check=True, capture_output=True)
            if result.stdout or result.stderr:
                raise SystemExit(f"non-silent warmup for {name}")

    samples: dict[str, list[float]] = {compiler: [] for compiler in commands}
    hyperfine = str(run.resolved_tool("hyperfine"))
    output.mkdir(parents=True, exist_ok=False)
    for index in range(rounds):
        order = list(commands)
        if index % 2:
            order.reverse()
        path = output / f"round-{index:03d}.json"
        invocation = [
            hyperfine,
            "--shell=none",
            "--runs",
            "1",
            "--style",
            "none",
            "--export-json",
            str(path),
        ]
        for compiler in order:
            invocation.extend(["--command-name", compiler, shlex.join(argv[compiler])])
        subprocess.run(invocation, check=True, stdout=subprocess.DEVNULL)
        records = json.loads(path.read_text(encoding="utf-8"))["results"]
        if [record["command"] for record in records] != order:
            raise SystemExit(f"hyperfine order mismatch for {name} round {index}")
        for record in records:
            if record["exit_codes"] != [0] or len(record["times"]) != 1:
                raise SystemExit(f"failed timed sample for {name} round {index}")
            samples[record["command"]].extend(record["times"])

    differences = [
        parent - candidate
        for parent, candidate in zip(samples["parent"], samples["candidate"])
    ]
    mean = statistics.mean(differences)
    critical = {10: 2.262, 30: 2.045}[rounds]
    half = critical * statistics.stdev(differences) / rounds**0.5
    summary = {
        "rounds": rounds,
        "warmups_per_binary": 3,
        "samples_seconds": samples,
        "parent_median_seconds": statistics.median(samples["parent"]),
        "candidate_median_seconds": statistics.median(samples["candidate"]),
        "candidate_wins": sum(value > 0 for value in differences),
        "paired_mean_saving_seconds": mean,
        "paired_mean_95pct_t_interval_seconds": [mean - half, mean + half],
    }
    (output / "summary.json").write_text(
        json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    return summary


def fingerprints(
    commands: dict[str, list[str]], projects: dict[str, Path], runner: Path
) -> dict[str, object]:
    return {
        "binaries": {name: artifact(Path(command[0])) for name, command in commands.items()},
        "inputs": {
            name: competitors.inventory_hash(
                competitors.payload_inventory(project.parent)
            )
            for name, project in projects.items()
        },
        "harness": {
            name: artifact(run.HERE / name)
            for name in ("run.py", "compare.py", "competitors.py")
        },
        "runner": artifact(runner),
        "hyperfine": artifact(run.resolved_tool("hyperfine")),
    }


def main() -> int:
    parsed = args()
    output = parsed.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    commands = {
        "parent": [str(parsed.parent.resolve(strict=True))],
        "candidate": [str(parsed.candidate.resolve(strict=True))],
    }
    manifest = run.manifest()
    workloads = list(manifest["workloads"])
    projects = {
        name: run.CORPUS / name / "tsconfig.json" for name in workloads
    }
    projects["commonjs_graph_scale1024"] = parsed.scale.resolve(strict=True) / "tsconfig.json"
    runner = Path(__file__).resolve(strict=True)
    before = fingerprints(commands, projects, runner)

    print("running 56 official and 4 scale admissions", flush=True)
    admission: list[dict[str, object]] = []
    for workload in workloads:
        run.validate(commands, workload, trace=admission)
    if len(admission) != 56 or not all(record["passed"] for record in admission):
        raise SystemExit("official admission count or status mismatch")
    scale_admission(commands, parsed.scale.resolve(strict=True), admission)
    if len(admission) != 60 or not all(record["passed"] for record in admission):
        raise SystemExit("combined admission count or status mismatch")
    (output / "admission.json").write_text(
        json.dumps({"records": admission}, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )

    families: dict[str, object] = {}
    for workload in workloads:
        families[workload] = paired_workload(
            workload,
            projects[workload],
            commands,
            output / "all-family" / workload,
            10,
        )

    confirmation = {
        "commonjs_graph": paired_workload(
            "commonjs_graph-confirmation",
            projects["commonjs_graph"],
            commands,
            output / "confirmation" / "commonjs_graph",
            30,
        ),
        "commonjs_graph_scale1024": paired_workload(
            "commonjs_graph_scale1024-confirmation",
            projects["commonjs_graph_scale1024"],
            commands,
            output / "confirmation" / "commonjs_graph_scale1024",
            10,
        ),
    }

    selected = [
        name
        for name, result in families.items()
        if result["candidate_median_seconds"]
        > result["parent_median_seconds"] * 1.03
    ]
    if "type_predicates_large" not in selected:
        selected.append("type_predicates_large")
    regression = {
        workload: paired_workload(
            f"{workload}-regression-confirmation",
            projects[workload],
            commands,
            output / "regression-confirmation" / workload,
            30,
        )
        for workload in selected
    }

    after = fingerprints(commands, projects, runner)
    if before != after:
        raise SystemExit("binary, input, harness, runner, or tool fingerprint changed")
    patch = subprocess.run(
        [
            "git",
            "diff",
            "--binary",
            "--",
            "packages/ts_checker/src/check.zig",
            "packages/ts_driver/src/ts_driver.zig",
            "packages/ts_program/src/ts_program.zig",
        ],
        cwd=REPO,
        check=True,
        stdout=subprocess.PIPE,
    ).stdout
    summary = {
        "schema": 1,
        "source_parent": command_output(["git", "-C", str(REPO), "rev-parse", "HEAD"]),
        "candidate_patch_sha256": sha256_bytes(patch),
        "host": run.host_metadata(),
        "python": platform.python_version(),
        "hyperfine_version": command_output([str(run.resolved_tool("hyperfine")), "--version"]),
        "schedule": {
            "warmups_per_binary": 3,
            "order": "parent,candidate on even rounds; candidate,parent on odd rounds",
            "sample_filtering": "none",
            "family_regression_threshold": "candidate median > 103% of parent median",
            "carried_forward_regression_family": "type_predicates_large",
        },
        "admissions": {"records": len(admission), "passed": len(admission)},
        "fingerprints_before": before,
        "fingerprints_after": after,
        "all_family": families,
        "confirmation": confirmation,
        "regression_confirmation": regression,
    }
    (output / "summary.json").write_text(
        json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(f"completed paired benchmark: {output}", flush=True)
    for name, result in confirmation.items():
        print(
            f"{name}: parent={result['parent_median_seconds'] * 1000:.3f}ms "
            f"candidate={result['candidate_median_seconds'] * 1000:.3f}ms "
            f"wins={result['candidate_wins']}/{result['rounds']}",
            flush=True,
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
