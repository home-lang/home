#!/usr/bin/env python3
"""Independent retained scale follow-up for home-lang/home#848."""

from __future__ import annotations

import argparse
import importlib.util
import json
from pathlib import Path


RUNNER = Path(__file__).with_name(".issue-848-paired.py")
SPEC = importlib.util.spec_from_file_location("issue_848_paired", RUNNER)
if SPEC is None or SPEC.loader is None:
    raise SystemExit("cannot load the paired runner")
paired = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(paired)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--parent", type=Path, required=True)
    parser.add_argument("--candidate", type=Path, required=True)
    parser.add_argument("--scale", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    commands = {
        "parent": [str(args.parent.resolve(strict=True))],
        "candidate": [str(args.candidate.resolve(strict=True))],
    }
    project = args.scale.resolve(strict=True) / "tsconfig.json"
    projects = {"commonjs_graph_scale1024": project}
    before = paired.fingerprints(commands, projects, Path(__file__).resolve())
    admission: list[dict[str, object]] = []
    paired.scale_admission(commands, args.scale.resolve(strict=True), admission)
    if len(admission) != 4 or not all(record["passed"] for record in admission):
        raise SystemExit("scale follow-up admissions failed")
    (output / "admission.json").write_text(
        json.dumps({"records": admission}, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    result = paired.paired_workload(
        "commonjs_graph_scale1024-independent-followup",
        project,
        commands,
        output / "rounds",
        30,
    )
    after = paired.fingerprints(commands, projects, Path(__file__).resolve())
    if before != after:
        raise SystemExit("follow-up fingerprint changed")
    summary = {
        "status": "independent follow-up retained alongside the original 10-pair result",
        "reason": "original scale paired-mean interval crossed zero after two candidate outliers",
        "source_parent": paired.command_output(
            ["git", "-C", str(paired.REPO), "rev-parse", "HEAD"]
        ),
        "admissions": {"records": len(admission), "passed": len(admission)},
        "fingerprints_before": before,
        "fingerprints_after": after,
        "result": result,
    }
    (output / "summary.json").write_text(
        json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(
        "scale follow-up: "
        f"parent={result['parent_median_seconds'] * 1000:.3f}ms "
        f"candidate={result['candidate_median_seconds'] * 1000:.3f}ms "
        f"wins={result['candidate_wins']}/{result['rounds']}",
        flush=True,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
