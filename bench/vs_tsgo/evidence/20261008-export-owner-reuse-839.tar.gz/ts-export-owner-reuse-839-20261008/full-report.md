# TypeScript frontend benchmark — 20261008T000856Z

Apple M3 Pro / Mac15,6; 11 logical cores; Darwin 27.0.0 (arm64); 30 runs after 3 warmups; tsc `Version 6.0.3`, tsgo `Version 7.0.2`, Home `Version 0.1.0`, tsc_rs `Version 7.1.0-dev`, bun_canary `1.4.3-canary.1+bd599f5af`.
Measurement tools: node `v26.10.0`, hyperfine `hyperfine 1.20.0`, python `3.9.6`.
Provenance: verified unchanged before admission and after measurement.

| Workload | tsc median | tsgo median | Home median | tsc_rs median | bun_canary median | Home vs fastest competitor |
|---|---:|---:|---:|---:|---:|---:|
| `checkjs_jsdoc` | 194.1 ms | 22.6 ms | 28.9 ms | 21.6 ms | 13.4 ms | 2.16× slower |
| `class_hierarchy` | 178.0 ms | 20.4 ms | 22.6 ms | 16.9 ms | 13.2 ms | 1.71× slower |
| `commonjs_graph` | 146.4 ms | 17.7 ms | 24.5 ms | 14.2 ms | 11.8 ms | 2.08× slower |
| `control_flow` | 188.9 ms | 27.4 ms | 25.4 ms | 23.7 ms | 16.0 ms | 1.59× slower |
| `deep_types` | 130.8 ms | 21.6 ms | 21.1 ms | 14.2 ms | 13.3 ms | 1.59× slower |
| `destructuring` | 135.8 ms | 16.4 ms | 15.1 ms | 14.5 ms | 10.9 ms | 1.39× slower |
| `generic_calls` | 179.4 ms | 22.9 ms | 22.8 ms | 19.0 ms | 14.4 ms | 1.58× slower |
| `import_graph` | 129.5 ms | 15.2 ms | 20.4 ms | 11.2 ms | 14.9 ms | 1.82× slower |
| `interface_composition` | 196.7 ms | 30.5 ms | 33.5 ms | 23.1 ms | 17.4 ms | 1.93× slower |
| `many_files` | 200.2 ms | 24.1 ms | 22.0 ms | 17.6 ms | 13.5 ms | 1.62× slower |
| `null_safe_access` | 184.4 ms | 26.0 ms | 31.4 ms | 21.7 ms | 16.0 ms | 1.97× slower |
| `overload_resolution` | 193.9 ms | 32.0 ms | 23.1 ms | 25.7 ms | 19.9 ms | 1.16× slower |
| `recursive_generics` | 149.9 ms | 38.9 ms | 14.1 ms | 31.7 ms | 9.5 ms | 1.48× slower |
| `reexport_graph` | 96.6 ms | 10.6 ms | 16.5 ms | 9.0 ms | 8.5 ms | 1.94× slower |
| `startup` | 64.7 ms | 7.4 ms | 2.9 ms | 5.8 ms | 6.2 ms | **2.00× faster** |
| `structural_objects` | 178.8 ms | 25.8 ms | 22.0 ms | 21.4 ms | 16.3 ms | 1.35× slower |
| `tsx_components` | 164.0 ms | 16.3 ms | 20.2 ms | 14.3 ms | 10.4 ms | 1.94× slower |
| `type_predicates` | 228.3 ms | 39.4 ms | 32.0 ms | 32.9 ms | 22.8 ms | 1.40× slower |
| `type_predicates_large` | 968.6 ms | 294.2 ms | 234.6 ms | 259.3 ms | 155.1 ms | 1.51× slower |
| `variadic_tuples` | 238.2 ms | 43.5 ms | 30.3 ms | 32.3 ms | 18.9 ms | 1.61× slower |

Times are medians of all retained fresh-process samples. Comparisons use the fastest median of every measured competitor.
Ratios rounding to 1.00× are labeled near ties; this is not a statistical significance test.
Legacy graph rows without schema-2 rejection controls are retained as timings, not fair speed claims (#487).
Legacy tuple rows without schema-3 rejection controls are provisional; schema 3 also retains the graph gates.
