import hashlib
import json
from pathlib import Path
import statistics
import subprocess
import sys

sys.path.insert(0, '/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang/bench/vs_tsgo')
import run

root = Path(__file__).resolve().parent
commands = {'parent': [str(root / 'home-tsc-parent-ef0174c05')],
            'candidate': [str(root / 'home-tsc-candidate-shared-names')]}
before = {name: run.sha256_file(Path(cmd[0])) for name, cmd in commands.items()}
for workload in run.manifest()['workloads']:
    run.validate(commands, workload)
projects = {'official': run.CORPUS / 'reexport_graph/tsconfig.json',
            'scale4096': root / 'reexport-scale-4096/tsconfig.json'}
output = root / 'paired-screen'
output.mkdir(exist_ok=False)
summaries = {}
for workload, config in projects.items():
    argv = {name: command + ['--noEmit', '-p', str(config)] for name, command in commands.items()}
    for _ in range(3):
        for command in argv.values(): subprocess.run(command, check=True, capture_output=True)
    samples = {name: [] for name in commands}
    for index in range(20 if workload == 'official' else 6):
        names = list(commands)
        if index % 2: names.reverse()
        path = output / f'{workload}-round-{index:03d}.json'
        import shlex
        command = ['hyperfine', '--shell=none', '--runs', '1', '--style', 'none', '--export-json', str(path)]
        for name in names: command += ['--command-name', name, shlex.join(argv[name])]
        subprocess.run(command, check=True)
        for result in json.loads(path.read_text())['results']:
            assert result['exit_codes'] == [0] and len(result['times']) == 1
            samples[result['command']].extend(result['times'])
    pairs = list(zip(samples['parent'], samples['candidate']))
    summaries[workload] = {'samples': samples, 'parent_median': statistics.median(samples['parent']),
                           'candidate_median': statistics.median(samples['candidate']),
                           'candidate_wins': sum(new < old for old, new in pairs)}
after = {name: run.sha256_file(Path(cmd[0])) for name, cmd in commands.items()}
assert before == after
print(json.dumps({'before': before, 'after': after, 'summaries': summaries}), flush=True)
