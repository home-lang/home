import hashlib
import json
from pathlib import Path
import re
import statistics
import sys
import tarfile

repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
sys.path.insert(0, str(repo / 'bench/vs_tsgo'))
import run

root = Path(__file__).resolve().parent
result = repo / 'bench/vs_tsgo/results/20261008T000856Z'
archive = repo / 'bench/vs_tsgo/evidence/20261008T000856Z.tar.gz'

def digest(data):
    return hashlib.sha256(data).hexdigest()

def verify_archive(path):
    with tarfile.open(path) as tar:
        entries = {item.name: tar.extractfile(item).read() for item in tar.getmembers() if item.isfile()}
    checksum_path = next(name for name in entries if name.endswith('/SHA256SUMS'))
    prefix = checksum_path.rsplit('/', 1)[0]
    rows = entries[checksum_path].decode().splitlines()
    for row in rows:
        expected, name = row.split('  ', 1)
        assert digest(entries[prefix + '/' + name]) == expected, name
    assert len(rows) == len(entries) - 1
    return entries, prefix, len(rows)

entries, prefix, checksum_count = verify_archive(archive)
assert checksum_count == 603
rounds = [name for name in entries if '-round-' in name and name.endswith('.json')]
assert len(rounds) == 600
samples = {}
for name in rounds:
    local = result / name.rsplit('/', 1)[1]
    assert local.read_bytes() == entries[name]
    workload = local.name.split('-round-')[0]
    for item in json.loads(entries[name])['results']:
        assert item['exit_codes'] == [0] and len(item['times']) == 1
        compiler, command_workload = item['command'].split(' ', 1)
        assert command_workload == workload
        samples.setdefault(workload, {}).setdefault(compiler, []).extend(item['times'])
assert sum(len(values) for group in samples.values() for values in group.values()) == 3000
metadata = json.loads(entries[prefix + '/metadata.json'])
assert metadata['provenance']['status'] == 'verified'
assert metadata['provenance']['before'] == metadata['provenance']['after']
admission_bytes = entries[prefix + '/admission.jsonl']
assert digest(admission_bytes) == metadata['admission']['sha256']
admissions = json.loads(admission_bytes)
assert admissions['passed'] is True
assert admissions['before'] == metadata['provenance']['before'] == admissions['after']
assert len(admissions['records']) == 140
assert all(record['passed'] is True for record in admissions['records'])
medians = {workload: {name: statistics.median(values) for name, values in group.items()} for workload, group in samples.items()}
wins = sum(group['home'] < min(value for name, value in group.items() if name != 'home') for group in medians.values())
go_wins = sum(group['home'] < group['tsgo'] for group in medians.values())
print(json.dumps({'checksums': checksum_count, 'admissions': len(admissions['records']), 'rounds': len(rounds), 'samples': 3000, 'home_wins': wins, 'home_vs_native_go_wins': go_wins, 'matrix_sha256': digest(archive.read_bytes())}))

def summary_from_log(name):
    lines = (root / name).read_text().splitlines()
    return json.loads(next(line for line in reversed(lines) if line.startswith('{')))

summaries = {}
for stage, log in [('paired-screen', 'paired-screen.log'), ('paired-confirmation', 'paired-confirmation.log'), ('paired-families', 'paired-families.log')]:
    summary = summary_from_log(log)
    assert summary['before'] == summary['after']
    if 'input_before' in summary:
        assert summary['input_before'] == summary['input_after']
    for workload, group in summary['summaries'].items():
        values = {'parent': [], 'candidate': []}
        paths = sorted((root / stage).glob(workload + '-round-*.json'))
        for index, path in enumerate(paths):
            records = json.loads(path.read_bytes())['results']
            assert [item['command'] for item in records] == (['parent', 'candidate'] if index % 2 == 0 else ['candidate', 'parent'])
            for item in records:
                assert item['exit_codes'] == [0] and len(item['times']) == 1
                values[item['command']].extend(item['times'])
        assert values == group['samples']
        assert statistics.median(values['parent']) == group['parent_median']
        assert statistics.median(values['candidate']) == group['candidate_median']
        differences = [old - new for old, new in zip(values['parent'], values['candidate'])]
        n = len(differences)
        critical = {6: 2.571, 10: 2.262, 20: 2.093, 30: 2.045}[n]
        mean = statistics.mean(differences)
        half = critical * statistics.stdev(differences) / n ** 0.5
        group['paired_mean_saving_seconds'] = mean
        group['paired_mean_95pct_t_interval_seconds'] = [mean - half, mean + half]
        group['candidate_wins'] = sum(value > 0 for value in differences)
    summaries[stage] = summary

def zod_identities(name):
    pattern = re.compile(r'^(.+?)\((\d+),(\d+)\): (?:error|warning) (TS\d+|HM\d+):')
    identities = []
    for line in (root / name).read_text().splitlines():
        match = pattern.match(line)
        if match:
            path, row, col, code = match.groups()
            assert '/package/' in path
            identities.append((path.split('/package/', 1)[1], int(row), int(col), code))
    assert len(identities) == 199
    assert sum(item[3] == 'HM9002' for item in identities) == 3
    return sorted(identities)

parent_identities = zod_identities('zod-parent-diagnostics.log')
assert parent_identities == zod_identities('zod-candidate-diagnostics.log')
for name, expected in [('home-tsc-parent-ef0174c05', 'c510235a37f9012bb7ebb62728e873bc22d927d04c4e81c8d81fcae3400eac9c'), ('home-tsc-candidate-shared-names', '2972a61a93d99b04844db10e4c018caddf581cf0fc9f928251e129ffd950e6e1')]:
    assert digest((root / name).read_bytes()) == expected

out_prefix = 'ts-export-owner-reuse-839-20261008'
members = {}
files = ['candidate-initial.patch', 'parent-build.log', 'candidate-build.log', 'program-tests-stripped.log', 'checker-tests-stripped.log', 'cli-tests-stripped.log', 'harness-final.log', 'pickier-candidate.log', 'paired-screen.log', 'paired-confirmation.log', 'paired-families.log', 'paired_screen.py', 'paired_confirmation.py', 'paired_families.py', 'zod-parent.json', 'zod-candidate.json', 'zod-parent-diagnostics.log', 'zod-candidate-diagnostics.log', 'zod-parent-guard.log', 'zod-candidate-guard.log', 'full-candidate-matrix.log', 'full-report.md', 'publish_evidence.py']
for name in files:
    members[out_prefix + '/' + name] = (root / name).read_bytes()
for directory in ['paired-screen', 'paired-confirmation', 'paired-families', 'reexport-scale-4096']:
    for path in sorted((root / directory).rglob('*')):
        if path.is_file():
            members[out_prefix + '/' + str(path.relative_to(root))] = path.read_bytes()
members[out_prefix + '/verified-summary.json'] = (json.dumps({'source_parent': 'ef0174c05b9ca978ec5f5887c86bd4e8def670cd', 'source_change_commit': 'b18f192035260d2a9e6bd0324c32e952a0679a62', 'measurement_source': 'ef0174c05 plus candidate-initial.patch (before rebase)', 'matrix': {'home_wins': wins, 'home_vs_native_go_wins': go_wins, 'sha256': digest(archive.read_bytes())}, 'paired_results': summaries, 'zod_diagnostic_multiset': parent_identities}, indent=2) + '\n').encode()
members[out_prefix + '/README.txt'] = b'''Exact-parent export-owner reuse evidence, issue #839.
The measured candidate is ef0174c05 plus candidate-initial.patch. The source change was later rebased and pushed as b18f19203; intervening compiler changes are not attributed these timings.
All round JSON files, logs, source patch and scripts are retained byte-for-byte. verified-summary.json is recomputed from every retained pair, including outliers; paired mean intervals use a two-sided 95% t interval.
Official graph: 64 leaves / 8 per barrel, unchanged. The secondary 4096-leaf graph uses the identical generator and is not a competitor leadership claim.
Full five-compiler evidence is separately published as 20261008T000856Z.tar.gz. No compiler binaries are redistributed here; their exact hashes are in the summaries/logs.
Logs retain local reproducibility paths. Tests were complete ReleaseFast module suites with native symbol emission stripped, not named-test filtering. Resource caps were not raised.
'''
members[out_prefix + '/SHA256SUMS'] = ''.join(f'{digest(data)}  {name.removeprefix(out_prefix + "/")}\n' for name, data in sorted(members.items())).encode()
destination = repo / 'bench/vs_tsgo/evidence/20261008-export-owner-reuse-839.tar.gz'
run.write_evidence_archive(destination, members)
_, _, paired_checksums = verify_archive(destination)
print(json.dumps({'paired_archive': str(destination), 'paired_sha256': digest(destination.read_bytes()), 'paired_checksums': paired_checksums, 'confirmation': summaries['paired-confirmation']['summaries']}))
