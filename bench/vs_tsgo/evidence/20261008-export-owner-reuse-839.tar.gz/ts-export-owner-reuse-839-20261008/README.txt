Exact-parent export-owner reuse evidence, issue #839.
The measured candidate is ef0174c05 plus candidate-initial.patch. The source change was later rebased and pushed as b18f19203; intervening compiler changes are not attributed these timings.
All round JSON files, logs, source patch and scripts are retained byte-for-byte. verified-summary.json is recomputed from every retained pair, including outliers; paired mean intervals use a two-sided 95% t interval.
Official graph: 64 leaves / 8 per barrel, unchanged. The secondary 4096-leaf graph uses the identical generator and is not a competitor leadership claim.
Full five-compiler evidence is separately published as 20261008T000856Z.tar.gz. No compiler binaries are redistributed here; their exact hashes are in the summaries/logs.
Logs retain local reproducibility paths. Tests were complete ReleaseFast module suites with native symbol emission stripped, not named-test filtering. Resource caps were not raised.
