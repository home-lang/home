import json
from pathlib import Path
import shlex
import statistics
import subprocess
import sys

sys.path.insert(0, '/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang/bench/vs_tsgo')
import run
import competitors

root = Path(__file__).resolve().parent
commands = {'parent': [str(root / 'home-tsc-parent-ef0174c05')],
            'candidate': [str(root / 'home-tsc-candidate-shared-names')]}
before = {'binaries': {n: run.sha256_file(Path(c[0])) for n,c in commands.items()},
          'inputs': competitors.inventory_hash(competitors.payload_inventory(run.CORPUS))}
output = root / 'paired-families'
output.mkdir(exist_ok=False)
summaries = {}
for workload in run.manifest()['workloads']:
    run.validate(commands, workload)
    argv = {name: command + ['--noEmit', '-p', str(run.CORPUS / workload / 'tsconfig.json')]
            for name,command in commands.items()}
    for _ in range(3):
        for command in argv.values(): subprocess.run(command, check=True, capture_output=True)
    samples = {name: [] for name in commands}
    for index in range(10):
        names = list(commands)
        if index % 2: names.reverse()
        path = output / f'{workload}-round-{index:03d}.json'
        command = ['hyperfine','--shell=none','--runs','1','--style','none','--export-json',str(path)]
        for name in names: command += ['--command-name',name,shlex.join(argv[name])]
        subprocess.run(command,check=True)
        for row in json.loads(path.read_text())['results']:
            assert row['exit_codes']==[0] and len(row['times'])==1
            samples[row['command']].extend(row['times'])
    summaries[workload]={'samples':samples,'parent_median':statistics.median(samples['parent']),
                         'candidate_median':statistics.median(samples['candidate'])}
after = {'binaries': {n: run.sha256_file(Path(c[0])) for n,c in commands.items()},
         'inputs': competitors.inventory_hash(competitors.payload_inventory(run.CORPUS))}
assert before==after
print(json.dumps({'before':before,'after':after,'summaries':summaries}),flush=True)
