import hashlib
import json
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts863-qualification-docs/lang')
expected = json.loads((root / 'performance-protocol.json').read_bytes())['candidate_patch_sha256']
records = []
for name in ['admit_extended.py', 'admit_protocol.py', 'compare_zod.py', 'admit_scales.py']:
    assert hashlib.sha256(subprocess.check_output(['git', 'diff', '--', 'packages/ts_checker/src/check.zig'], cwd=repo)).hexdigest() == expected
    print('Starting ' + name, flush=True)
    with (root / (name + '.log')).open('x') as stream:
        result = subprocess.run([sys.executable, str(root / name)], cwd=repo, stdout=stream, stderr=subprocess.STDOUT)
    records.append({'script': name, 'exit': result.returncode})
    with (root / 'admission-outcome.json').open('w') as stream:
        json.dump({'records': records, 'patch_sha256': expected, 'timing_started': False}, stream, indent=2)
    print(json.dumps(records[-1]), flush=True)
    if result.returncode:
        print((root / (name + '.log')).read_text()[-1800:], flush=True)
        raise SystemExit(result.returncode)
