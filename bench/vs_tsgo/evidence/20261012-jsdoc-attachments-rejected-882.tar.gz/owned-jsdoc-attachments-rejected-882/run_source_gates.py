import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
logs = root / 'capacity-recovered-gates'
repo = Path('/Users/chris/.codex/worktrees/ts863-qualification-docs/lang')
expected = 'e56746ac6e9e9c89c9cd551c1a6bd76adeed1ed02e7f027220268d30078ab612'
def source_hash():
    return hashlib.sha256(subprocess.check_output(['git', 'diff', '--', 'packages/ts_checker/src/check.zig'], cwd=repo)).hexdigest()
assert source_hash() == expected
if len(sys.argv) == 2:
    target = sys.argv[1]
    assert target in ['checker', 'program', 'driver', 'cli', 'entrypoint']
    assert logs.is_dir()
    with (logs / (target + '.log')).open('x') as stream:
        result = subprocess.run([sys.executable, '/Users/chris/.cache/home-ts-843.3BeUMH/module_tests.py', target],
                                cwd=repo, stdout=stream, stderr=subprocess.STDOUT)
    assert source_hash() == expected
    with (logs / (target + '.json')).open('x') as stream:
        json.dump({'target': target, 'exit': result.returncode, 'patch_sha256': expected, 'filtered': False}, stream, indent=2)
    print((logs / (target + '.log')).read_text()[-1500:], flush=True)
    raise SystemExit(result.returncode)
logs.mkdir(exist_ok=False)
records = []
for target in ['checker', 'program', 'driver', 'cli', 'entrypoint']:
    command = ['perl', 'scripts/run-bounded.pl', '600', sys.executable, str(Path(__file__)), target]
    environment = dict(os.environ, HOME_RUN_MAX_MB='3840', HOME_RUN_LABEL='ts882-full-' + target)
    print('Starting full ' + target, flush=True)
    with (logs / (target + '-guard.log')).open('x') as stream:
        result = subprocess.run(command, cwd=repo, env=environment, stdout=stream, stderr=subprocess.STDOUT)
    records.append({'target': target, 'exit': result.returncode})
    with (logs / 'source-gates.json').open('w') as stream:
        json.dump({'parent': 'e7ed4c0088dec5344b007d63ed55f448b918bc32', 'patch_sha256': expected,
                   'records': records, 'timing_started': False}, stream, indent=2)
    print(json.dumps(records[-1]), flush=True)
    print((logs / (target + '-guard.log')).read_text()[-900:], flush=True)
    if result.returncode:raise SystemExit(result.returncode)
