"""Fixed exact-parent phases: every sample retained, no measurement retries."""
import hashlib
import json
import math
from pathlib import Path
import shlex
import subprocess
import sys

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts863-qualification-docs/lang')
runner = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
sys.path.insert(0, str(runner / 'bench/vs_tsgo'))
import run
import competitors

kind, workload = sys.argv[1:]
assert kind in ['screen', 'confirm']
protocol = json.loads((root / 'performance-protocol.json').read_bytes())
assert protocol['official_workloads'] == run.selected_workloads(None)
allowed = protocol['official_workloads'] + ['jsdoc_' + str(value) for value in protocol['scales']]
assert workload in allowed
build = json.loads((root / 'candidate-build.json').read_bytes())
gates = json.loads((root / 'capacity-recovered-gates/source-gates.json').read_bytes())
assert len(gates['records']) == 5 and all(row['exit'] == 0 for row in gates['records'])
assert json.loads((root / 'extended-admission.json').read_bytes())['passed']
assert json.loads((root / 'verified-protocol.json').read_bytes())['passed']
assert json.loads((root / 'scaled-admission.json').read_bytes())['passed']
assert not json.loads((root / 'zod-delta.json').read_bytes())['added']
assert all(row['exit'] == 0 for row in json.loads((root / 'admission-outcome.json').read_bytes())['records'])
def source_hash():
    return hashlib.sha256(subprocess.check_output(['git', 'diff', '--', 'packages/ts_checker/src/check.zig'], cwd=repo)).hexdigest()
assert source_hash() == protocol['candidate_patch_sha256'] == build['source_patch_sha256']
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip() == protocol['source_parent']
commands = {'parent': [str(Path('/Users/chris/.cache/home-ts-root-binding-facts.03Mi49/baseline/bin/home-tsc'))], 'candidate': [str(root / 'candidate-home-tsc')]}
assert hashlib.sha256(Path(commands['parent'][0]).read_bytes()).hexdigest() == protocol['parent_native_sha256']
assert hashlib.sha256(Path(commands['candidate'][0]).read_bytes()).hexdigest() == build['native_sha256']
profiles = competitors.load_profiles(runner / 'bench/vs_tsgo/profiles/darwin-arm64.json')
all_commands = run.compiler_commands(profiles)
all_commands['home'] = commands['candidate']
all_commands['parent'] = commands['parent']
def provenance():
    result = run.benchmark_provenance(all_commands, profiles)
    result['compilers']['parent'] = {'command': commands['parent'], 'executable': run.artifact_provenance(Path(commands['parent'][0]))}
    return result
before = provenance()
assert before == json.loads((root / 'image-admission.jsonl').read_bytes())['after']
folder = root / (kind + '-' + workload)
folder.mkdir(exist_ok=False)
pairs = protocol['screen_pairs_per_workload'] if kind == 'screen' else protocol['independent_pairs_per_workload']
trace = []
scaled = json.loads((root / 'scaled-admission.json').read_bytes())
metadata = {'phase': kind, 'workload': workload, 'pairs': pairs, 'warmups': 3, 'status': 'running',
            'source_parent': protocol['source_parent'], 'patch_sha256': source_hash(),
            'protocol_sha256': hashlib.sha256((root / 'performance-protocol.json').read_bytes()).hexdigest(),
            'runner_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'parent_sha256': protocol['parent_native_sha256'], 'candidate_sha256': build['native_sha256'],
            'before': before, 'after': None, 'admissions': trace, 'sampling_reruns_allowed': False}
def write_new(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
write_new(folder / 'started.json', metadata)
try:
    if workload in protocol['official_workloads']:
        run.validate(commands, workload, trace=trace)
        project = run.CORPUS / workload
    else:
        context = scaled['projects'][workload]
        project = Path(context['positive'])
        for label in ['positive', 'negative']:
            path = Path(context[label])
            assert competitors.inventory_hash(competitors.payload_inventory(path)) == context['inputs'][label]
            for name, command in commands.items():
                _, passed = run.admission_process(name, command + ['--noEmit', '-p', str(path / 'tsconfig.json')], workload,
                    expected_codes=None if label == 'positive' else context['expected_negative_codes'], trace=trace)
                assert passed, 'Failed phase control retained; no smaller timing selection'
    argv = {name: command + ['--noEmit', '-p', str(project / 'tsconfig.json')] for name, command in commands.items()}
    names = list(commands)
    for index in range(3):
        order = names[index % 2:] + names[:index % 2]
        for name in order:
            result = subprocess.run(argv[name], capture_output=True, text=True)
            write_new(folder / f'warmup-{index:03d}-{name}.json',
                      {'command': argv[name], 'exit': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr})
            assert result.returncode == 0 and not result.stdout and not result.stderr
    for index in range(pairs):
        order = names[index % 2:] + names[:index % 2]
        path = folder / f'pair-{index:03d}.json'
        timer = ['hyperfine', '--shell=none', '--runs', '1', '--style', 'none', '--export-json', str(path)]
        for name in order:
            timer += ['--command-name', name + ' ' + workload, shlex.join(argv[name])]
        subprocess.run(timer, check=True)
        data = json.loads(path.read_bytes())
        assert [row['command'] for row in data['results']] == [name + ' ' + workload for name in order]
        for row in data['results']:
            assert row['exit_codes'] == [0] and len(row['times']) == 1
            assert type(row['times'][0]) in [int, float] and math.isfinite(row['times'][0]) and row['times'][0] > 0
    after = provenance()
    assert after == before and source_hash() == protocol['candidate_patch_sha256']
    if workload not in protocol['official_workloads']:
        for label in ['positive', 'negative']:
            assert competitors.inventory_hash(competitors.payload_inventory(Path(context[label]))) == context['inputs'][label]
        metadata['scaled_inputs'] = context['inputs']
    metadata.update(status='complete', after=after)
except BaseException as error:
    metadata.update(status='incomplete', error={'type': type(error).__name__, 'message': str(error)})
    raise
finally:
    write_new(folder / 'metadata.json', metadata)
print(json.dumps({'phase': kind, 'workload': workload, 'pairs': pairs, 'status': 'complete'}), flush=True)
