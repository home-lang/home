import hashlib
import json
from pathlib import Path
import subprocess
import sys

root=Path(__file__).resolve().parent
runner=Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
sys.path.insert(0,str(runner/'bench/vs_tsgo'))
import run
import compare
import competitors
def save(path,content):
    assert not path.exists(),path
    patch='*** Begin Patch\n*** Add File: '+str(path)+'\n'+''.join('+'+line+'\n' for line in content.splitlines())+'*** End Patch\n'
    subprocess.run(['apply_patch'],input=patch,text=True,check=True,capture_output=True)

build=json.loads((root/'candidate-build.json').read_text())
candidate=root/'candidate-home-tsc'
parent=Path('/Users/chris/.cache/home-ts-root-binding-facts.03Mi49/baseline/bin/home-tsc')
assert build['exit']==0
assert hashlib.sha256(candidate.read_bytes()).hexdigest()==build['native_sha256']
assert hashlib.sha256(parent.read_bytes()).hexdigest()=='b251b7273cd1e659946d073fa905ec5c8c690686c26c63a6fb1b3bf13f9d71bb'
profiles=competitors.load_profiles(runner/'bench/vs_tsgo/profiles/darwin-arm64.json')
commands=run.compiler_commands(profiles)
commands['home']=[str(candidate)]
versions=run.verified_compiler_versions(commands,profiles)
commands['parent']=[str(parent)]
def provenance():
    result=run.benchmark_provenance(commands,profiles)
    result['compilers']['parent']={'command':commands['parent'],'executable':run.artifact_provenance(parent)}
    return result
before=provenance()
workloads=run.selected_workloads(None)
trace=[]
failure=None
for workload in workloads:
    try:
        run.validate(commands,workload,profiles=profiles,trace=trace)
    except BaseException as error:
        failure=repr(error)
        break
    print(workload,'admitted',flush=True)
after=provenance()
record={'schema':1,'passed':failure is None and len(trace)==180 and all(row['passed'] for row in trace),
    'before':before,'after':after,'records':trace,'failure':failure,'timings_taken':False,'source_adopted':False}
save(root/'image-admission.jsonl',json.dumps(record,indent=2)+'\n')
assert before==after
assert record['passed'],'Complete failing observations retained; no adoption'
verification=root/'admission-verification'
verification.mkdir(exist_ok=False)
raw=(root/'image-admission.jsonl').read_bytes()
save(verification/'admission.jsonl',raw.decode())
metadata={'validation_schema':5,'admission':{'path':'admission.jsonl','records':180,'sha256':hashlib.sha256(raw).hexdigest()},
    'provenance':{'status':'verified','before':before,'after':after}}
compare.validate_admission(verification,metadata,list(commands),workloads)
save(root/'verified-protocol.json',json.dumps({'admissions':180,'passed':True,'versions':versions,
    'provenance_unchanged':True,'validation_schema':5,'native_sha256':build['native_sha256'],
    'source_patch_sha256':build['source_patch_sha256'],'timings_taken':False},indent=2)+'\n')
