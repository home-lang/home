import hashlib
import json
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
old = Path('/Users/chris/.cache/home-ts-root-binding-facts.03Mi49')
repo = Path('/Users/chris/.codex/worktrees/ts863-qualification-docs/lang')
gates = json.loads((root / 'capacity-recovered-gates/source-gates.json').read_bytes())
assert [r['target'] for r in gates['records']] == ['checker', 'program', 'driver', 'cli', 'entrypoint']
assert all(r['exit'] == 0 for r in gates['records'])
assert gates['patch_sha256'] == 'e56746ac6e9e9c89c9cd551c1a6bd76adeed1ed02e7f027220268d30078ab612'
names = ['build_candidate.py', 'admit_extended.py', 'admit_protocol.py', 'compare_zod.py', 'admit_scales.py',
         'run_admission.py', 'paired.py', 'verify_pairs.py', 'run_performance.py']
records = []
for name in names:
    content = (old / name).read_text()
    if name == 'build_candidate.py':
        content = content.replace("root / 'complete-gates.json'", "root / 'capacity-recovered-gates/source-gates.json'")
    if name in ['build_candidate.py', 'compare_zod.py', 'admit_scales.py', 'paired.py']:
        content = content.replace("root / 'baseline/bin/home-tsc'", "Path('/Users/chris/.cache/home-ts-root-binding-facts.03Mi49/baseline/bin/home-tsc')")
    if name == 'admit_protocol.py':
        content = content.replace(str(root / 'baseline/bin/home-tsc'), str(old / 'baseline/bin/home-tsc'))
    if name == 'paired.py':
        content = content.replace("root / 'complete-gates.json'", "root / 'capacity-recovered-gates/source-gates.json'")
        content = content.replace("str(root / 'baseline/bin/home-tsc')", "str(Path('/Users/chris/.cache/home-ts-root-binding-facts.03Mi49/baseline/bin/home-tsc'))")
    if name == 'verify_pairs.py':
        content = content.replace('random.Random(881)', 'random.Random(882)').replace("'seed': 881", "'seed': 882")
    content = content.replace("'ts881-", "'ts882-")
    target = root / name
    assert not target.exists()
    patch = '*** Begin Patch\n*** Add File: ' + str(target) + '\n' + ''.join('+' + line + '\n' for line in content.splitlines()) + '*** End Patch\n'
    subprocess.run(['apply_patch'], input=patch, text=True, check=True, capture_output=True)
    records.append({'script': name, 'current_sha256': hashlib.sha256(target.read_bytes()).hexdigest(), 'reference': str(old / name)})
with (root / 'qualification-tools.json').open('x') as stream:
    json.dump({'scripts': records, 'source_gates': gates, 'expectations_unchanged': True,
               'parent_image': str(old / 'baseline/bin/home-tsc'), 'seed': 882, 'timing_started': False}, stream, indent=2)
print('Prepared complete unchanged admission/pair verification with current parent and source qualification')
