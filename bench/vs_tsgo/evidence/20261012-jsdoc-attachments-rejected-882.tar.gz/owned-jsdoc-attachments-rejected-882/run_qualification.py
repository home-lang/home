import json
import os
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts863-qualification-docs/lang')
gates = json.loads((root / 'capacity-recovered-gates/source-gates.json').read_bytes())
assert len(gates['records']) == 5 and all(row['exit'] == 0 for row in gates['records'])
records = []
for label, script in [('candidate-build', 'build_candidate.py'), ('full-admission', 'run_admission.py')]:
    command = ['perl', 'scripts/run-bounded.pl', '600', sys.executable, str(root / script)]
    environment = dict(os.environ, HOME_RUN_MAX_MB='3840', HOME_RUN_LABEL='ts882-' + label)
    print('Starting unchanged guard ' + label, flush=True)
    with (root / (label + '-guard.log')).open('x') as stream:
        result = subprocess.run(command, cwd=repo, env=environment, stdout=stream, stderr=subprocess.STDOUT)
    records.append({'phase': label, 'exit': result.returncode})
    with (root / 'qualification-outcome.json').open('w') as stream:
        json.dump({'records': records, 'timing_started': False, 'source_adopted': False}, stream, indent=2)
    print(json.dumps(records[-1]), flush=True)
    if result.returncode:
        print((root / (label + '-guard.log')).read_text()[-2000:], flush=True)
        raise SystemExit(result.returncode)
print('Full source/build/admission qualification complete; no timing or adoption yet', flush=True)
