Rejected completed-result attachment memoization; source restored, never adopted.
All44 phases/880 pairs/264 warmups/136 phase admissions retained and independently verified.
Official target gain inconclusive; controlflow/overloads/recursivegenerics independent losses prohibit adoption.
All source/build/admission gates passed; unchanged Zod235 diagnostics remain unadmitted/untimed.
Parent B251 is retained separately under home-ts-root-binding-facts.03Mi49 and previous published#881 archive.
Every original record, candidate revision/image, protocol, failure and raw byte is preserved.
No reruns/filtering/negative weakening/layout tuning/body skipping or benchmark predicates.
