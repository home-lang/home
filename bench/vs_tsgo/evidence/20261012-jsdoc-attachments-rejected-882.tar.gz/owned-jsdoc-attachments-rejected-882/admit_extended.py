import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

root=Path(__file__).resolve().parent
repo=Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
sys.path.insert(0,str(repo/'bench/vs_tsgo'))
import run
import competitors

def save(path,content):
    assert not path.exists(),path
    patch='*** Begin Patch\n*** Add File: '+str(path)+'\n'+''.join('+'+line+'\n' for line in content.splitlines())+'*** End Patch\n'
    subprocess.run(['apply_patch'],input=patch,text=True,check=True,capture_output=True)

build=json.loads((root/'candidate-build.json').read_text())
candidate=root/'candidate-home-tsc'
assert build['exit']==0 and hashlib.sha256(candidate.read_bytes()).hexdigest()==build['native_sha256']
cases=[]
for path in [Path('/Users/chris/.cache/home-ts-main-flow-proof-integration.dYlSre/diagnostic-admission.json'),
             Path('/Users/chris/.cache/home-ts-forward-part-controls.lTzq5k/results.json'),
             Path('/Users/chris/.cache/home-ts-local-type-value-controls.xbVlrO/results.json'),
             Path('/Users/chris/.cache/home-ts-callback-body-controls-pinned.B9suaD/results.json'),
             Path('/Users/chris/.cache/home-ts-alias-ownership-controls.rKw5q2/results.json'),
             Path('/Users/chris/.cache/home-ts-projected-union-contracts.ZVQ5Hb/results.json')]:
    prior=json.loads(path.read_text())
    assert prior.get('after',prior.get('after_inputs'))==prior.get('before',prior.get('inputs'))
    for row in prior['records']:
        if row['compiler']!='tsc':continue
        argv=row['command'];project=Path(argv[argv.index('-p')+1]).parent
        assert row['passed']
        cases.append((str(project),project,row['expected_codes']))
assert len(cases)==98
before={name:competitors.inventory_hash(competitors.payload_inventory(project)) for name,project,_ in cases}
trace=[]
commands=run.compiler_commands()
commands['home']=[str(candidate)]
for name,project,codes in cases:
    for compiler,command in commands.items():
        result,passed=run.admission_process(compiler,command+['--noEmit','-p',str(project/'tsconfig.json')],
            name,expected_codes=codes,trace=trace)
        print(name,compiler,result.returncode,passed,trace[-1]['codes'],flush=True)
after={name:competitors.inventory_hash(competitors.payload_inventory(project)) for name,project,_ in cases}
assert before==after
record={'records':trace,'before':before,'after':after,'passed':all(row['passed'] for row in trace),
    'native_sha256':build['native_sha256'],'timings_taken':False,'source_adopted':False}
save(root/'extended-admission.json',json.dumps(record,indent=2)+'\n')
package=Path('/Users/chris/.cache/home-ts-zod-admission.RzJCwi/source/package')
library_before=competitors.inventory_hash(competitors.payload_inventory(package))
argv=[str(candidate),'--noEmit','-p',str(package/'tsconfig.benchmark.json'),'--home-list-unmodeled-any']
result=subprocess.run(argv,capture_output=True,text=True)
library_after=competitors.inventory_hash(competitors.payload_inventory(package))
assert library_before==library_after
save(root/'production-zod.json',json.dumps({'command':argv,'exit':result.returncode,'stdout':result.stdout,'stderr':result.stderr,
    'before':library_before,'after':library_after,'native_sha256':build['native_sha256'],
    'counts':{code:len(re.findall(r'\b'+code+r':',result.stdout+result.stderr)) for code in sorted(set(re.findall(r'\b((?:TS|HM)\d+):',result.stdout+result.stderr)))},
    'timings_taken':False,'admitted':result.returncode==0 and result.stdout=='' and result.stderr==''},indent=2)+'\n')
assert record['passed'],'All mismatches retained; no adoption'
