import hashlib
import json
from pathlib import Path
import sys
import tarfile

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts863-qualification-docs/lang')
sys.path.insert(0, str(repo / 'bench/vs_tsgo'))
import run
decision = json.loads((root / 'decision.json').read_bytes())
assert not decision['qualified'] and decision['all_fixed_phases_complete'] and decision['complete_pairs'] == 880
assert decision['independent_losses'] == ['control_flow', 'overload_resolution', 'recursive_generics']
rows = {}
for path in sorted(root.glob('*-*-statistics.json')):
    row = json.loads(path.read_bytes())
    assert row['verified']
    folder = root / (row['phase'] + '-' + row['workload'])
    for filename, digest in row['raw_sha256'].items():
        assert hashlib.sha256((folder / filename).read_bytes()).hexdigest() == digest
    rows[row['phase'] + '-' + row['workload']] = row
assert len(rows) == 44 and sum(row['pairs'] for row in rows.values()) == 880
assert len(list(root.glob('*-*/warmup-*.json'))) == 264
assert sum(row['admissions'] for row in rows.values()) == 136
with (root / 'rejection-summary.json').open('x') as stream:
    json.dump({'qualified': False, 'source_restored': True, 'pairs': 880, 'warmups': 264,
               'phase_admissions': 136, 'discarded_observations': 0, 'repeated_timings': 0, 'rows': rows}, stream, indent=2)
prefix = 'owned-jsdoc-attachments-rejected-882'
members = {prefix + '/' + path.relative_to(root).as_posix(): path.read_bytes()
           for path in sorted(root.rglob('*')) if path.is_file() and '__pycache__' not in path.parts}
members[prefix + '/README.txt'] = (
    'Rejected completed-result attachment memoization; source restored, never adopted.\n'
    'All44 phases/880 pairs/264 warmups/136 phase admissions retained and independently verified.\n'
    'Official target gain inconclusive; controlflow/overloads/recursivegenerics independent losses prohibit adoption.\n'
    'All source/build/admission gates passed; unchanged Zod235 diagnostics remain unadmitted/untimed.\n'
    'Parent B251 is retained separately under home-ts-root-binding-facts.03Mi49 and previous published#881 archive.\n'
    'Every original record, candidate revision/image, protocol, failure and raw byte is preserved.\n'
    'No reruns/filtering/negative weakening/layout tuning/body skipping or benchmark predicates.\n'
).encode()
members[prefix + '/SHA256SUMS'] = ''.join(f'{hashlib.sha256(raw).hexdigest()}  {name.removeprefix(prefix + "/")}\n' for name, raw in sorted(members.items())).encode()
output = repo / 'bench/vs_tsgo/evidence/20261012-jsdoc-attachments-rejected-882.tar.gz'
assert not output.exists()
run.write_evidence_archive(output, members)
with tarfile.open(output) as archive:
    for name, raw in members.items():assert archive.extractfile(name).read() == raw, name
print(json.dumps({'archive': str(output), 'sha256': hashlib.sha256(output.read_bytes()).hexdigest(),
                  'verified_payloads': len(members)-1, 'bytes': output.stat().st_size, 'pairs': 880}))
