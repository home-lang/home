"""Run the entire fixed22-workload decision once, preserving all adverse data."""
import json
import os
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts863-qualification-docs/lang')
protocol = json.loads((root / 'performance-protocol.json').read_bytes())
qualification = json.loads((root / 'qualification-outcome.json').read_bytes())
assert [row['phase'] for row in qualification['records']] == ['candidate-build', 'full-admission']
assert all(row['exit'] == 0 for row in qualification['records'])
workloads = protocol['official_workloads'] + ['jsdoc_' + str(value) for value in protocol['scales']]
assert len(workloads) == 22 and len(set(workloads)) == 22
with (root / 'timing-started.json').open('x') as stream:
    json.dump({'selection': workloads, 'phases': ['screen', 'confirm'], 'reruns_allowed': False, 'source_adopted': False}, stream, indent=2)
records = []
for kind in ['screen', 'confirm']:
    for workload in workloads:
        phase = kind + '-' + workload
        command = ['perl', 'scripts/run-bounded.pl', '600', sys.executable, str(root / 'paired.py'), kind, workload]
        environment = dict(os.environ, HOME_RUN_MAX_MB='3840', HOME_RUN_LABEL='ts882-' + phase)
        print('Starting fixed phase ' + phase, flush=True)
        with (root / (phase + '.guard.log')).open('x') as stream:
            result = subprocess.run(command, cwd=repo, env=environment, stdout=stream, stderr=subprocess.STDOUT)
        record = {'phase': phase, 'guard_exit': result.returncode}
        records.append(record)
        if result.returncode == 0:
            with (root / (phase + '.verification.log')).open('x') as stream:
                checked = subprocess.run([sys.executable, str(root / 'verify_pairs.py'), kind, workload], cwd=repo,
                                         stdout=stream, stderr=subprocess.STDOUT)
            record['verification_exit'] = checked.returncode
        with (root / 'performance-outcome.json').open('w') as stream:
            json.dump({'records': records, 'fixed_selection': workloads, 'source_adopted': False,
                       'no_reruns': True, 'all_observations_retained': True}, stream, indent=2)
        print(json.dumps(record), flush=True)
        if result.returncode or record.get('verification_exit') != 0:
            raise SystemExit(result.returncode or record.get('verification_exit', 1))
results = {name: json.loads((root / ('confirm-' + name + '-statistics.json')).read_bytes()) for name in workloads}
primary = results['checkjs_jsdoc']
losses = [name for name, row in results.items() if row['paired_mean_saving_95_interval'][1] < 0]
decision = {'qualified': primary['paired_mean_saving_95_interval'][0] > 0 and not losses,
            'primary': primary, 'independent_losses': losses, 'complete_pairs': 880,
            'all_fixed_phases_complete': True, 'source_adopted': False,
            'inconclusive_is_not_equivalence': True, 'universal_goal_complete': False}
with (root / 'decision.json').open('x') as stream:
    json.dump(decision, stream, indent=2)
print(json.dumps(decision), flush=True)
