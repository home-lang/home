import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

root = Path(__file__).resolve().parent
runner = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
sys.path.insert(0, str(runner / 'bench/vs_tsgo'))
import run
import competitors
protocol = json.loads((root / 'performance-protocol.json').read_bytes())
build = json.loads((root / 'candidate-build.json').read_bytes())
assert build['exit'] == 0 and build['source_patch_sha256'] == protocol['candidate_patch_sha256']
commands = run.compiler_commands()
commands['parent'] = [str(Path('/Users/chris/.cache/home-ts-root-binding-facts.03Mi49/baseline/bin/home-tsc'))]
commands['home'] = [str(root / 'candidate-home-tsc')]
before = run.benchmark_provenance(commands)
records = []
projects = {}
for families in protocol['scales']:
    positive = root / ('jsdoc-scale-' + str(families))
    negative = root / ('jsdoc-scale-' + str(families) + '-negative')
    assert not positive.exists() and not negative.exists()
    run.generate_checkjs_jsdoc(positive, families)
    shutil.copytree(positive, negative)
    invalid = ''.join(
        f'/** @type {{boolean}} */ const wrongId{i} = preserved{i}.id;\n'
        f'preserved{i}.missing;\n'
        f'/** @type {{number}} */ const wrongCallback{i} = project{i}(model{i});\n'
        f'store{i}.read(123);\n'
        f'/** @type {{Box{i}<Model{i}>}} */ const wrongBox{i} = {{ value: {{ id: "wrong", name: "x", meta: {{ active: true, label: "x" }} }}, label: "x" }};\n'
        for i in [0, families // 2, families - 1])
    source = negative / 'src/checkjs-jsdoc.js'
    run.write(source, source.read_text() + invalid)
    inputs = {name: competitors.inventory_hash(competitors.payload_inventory(path))
              for name, path in [('positive', positive), ('negative', negative)]}
    if families == 8192:
        assert inputs == {'positive': 'bfb2fb1bef4dcb4ad7df9bffa647b5d44bd35c6895b32772fb4044ce0ced829e',
                          'negative': '439cf46bb43c4386f85b07af49583ff7ae3ad1ba6b7e73989fa776dce372b467'}
    expected = ['2322'] * 9 + ['2339'] * 3 + ['2345'] * 3
    for kind, project in [('positive', positive), ('negative', negative)]:
        for name, command in commands.items():
            result, passed = run.admission_process(name, command + ['--noEmit', '-p', str(project / 'tsconfig.json')],
                'jsdoc_' + str(families), expected_codes=None if kind == 'positive' else expected, trace=records)
            with (root / 'scale-admission-progress.json').open('w') as stream:
                json.dump({'records': records, 'timing_started': False}, stream, indent=2)
            assert passed, 'Failed complete scale control retained; no timing'
    assert inputs == {name: competitors.inventory_hash(competitors.payload_inventory(path))
                      for name, path in [('positive', positive), ('negative', negative)]}
    projects['jsdoc_' + str(families)] = {'positive': str(positive), 'negative': str(negative), 'inputs': inputs,
                                         'expected_negative_codes': expected}
    print('Scale', families, 'all8 complete admissions passed', flush=True)
after = run.benchmark_provenance(commands)
assert before == after
with (root / 'scaled-admission.json').open('x') as stream:
    json.dump({'before': before, 'after': after, 'projects': projects, 'records': records,
               'passed': len(records) == 16 and all(row['passed'] for row in records), 'timing_started': False}, stream, indent=2)
