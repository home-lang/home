    fn aliasedGuardReferencesAreStable(self: *Checker, node: NodeId) CheckError!bool {
        if (self.guardReferencesAssignedIdentifier(node)) return false;
        return switch (self.hir.kindOf(node)) {
            .logical_op => blk: {
                const logical = hir_mod.logicalOf(self.hir, node);
                break :blk try self.aliasedGuardReferencesAreStable(logical.lhs) and
                    try self.aliasedGuardReferencesAreStable(logical.rhs);
            },
            .binary_op => blk: {
                const binary = hir_mod.binopOf(self.hir, node);
                const lhs = if (self.hir.kindOf(binary.lhs) == .unary_op and
                    hir_mod.unaryOf(self.hir, binary.lhs).op == .typeof)
                    hir_mod.unaryOf(self.hir, binary.lhs).operand
                else
                    binary.lhs;
                const rhs = if (self.hir.kindOf(binary.rhs) == .unary_op and
                    hir_mod.unaryOf(self.hir, binary.rhs).op == .typeof)
                    hir_mod.unaryOf(self.hir, binary.rhs).operand
                else
                    binary.rhs;
                break :blk try self.guardAccessObjectIsStable(lhs) and try self.guardAccessObjectIsStable(rhs);
            },
            .call_expr => blk: {
                for (hir_mod.callArgs(self.hir, node)) |arg| {
                    if (self.hir.kindOf(arg) == .member_access and
                        !try self.memberReferenceIsReadonlyStable(arg)) break :blk false;
                }
                break :blk true;
            },
            else => true,
        };
    }

