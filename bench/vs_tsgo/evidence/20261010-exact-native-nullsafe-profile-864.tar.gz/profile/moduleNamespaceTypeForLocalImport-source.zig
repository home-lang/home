    fn moduleNamespaceTypeForLocalImport(self: *Checker, name: hir_mod.StringId, anchor: NodeId) CheckError!?TypeId {
        const root = self.rootBlockFor(anchor);
        if (root == hir_mod.none_node_id or self.hir.kindOf(root) != .block_stmt) return null;
        for (hir_mod.blockStmts(self.hir, root)) |stmt| {
            if (self.hir.kindOf(stmt) != .import_decl) continue;
            const imp = hir_mod.importOf(self.hir, stmt);
            const binding = if (imp.namespace_binding != hir_mod.none_node_id)
                imp.namespace_binding
            else if (imp.default_binding != hir_mod.none_node_id and self.importDeclIsRequireAssignment(stmt))
                imp.default_binding
            else
                hir_mod.none_node_id;
            if (binding == hir_mod.none_node_id or self.hir.kindOf(binding) != .identifier) continue;
            const id = hir_mod.identifierOf(self.hir, binding);
            if (id.name != name) continue;
            if (self.importDeclIsRequireAssignment(stmt)) {
                if (try self.virtualExportAssignmentExpressionType(stmt, imp.module)) |expr_t| return expr_t;
                if (try self.virtualExportAssignmentTargetStaticType(stmt, imp.module)) |static_t| return static_t;
                if (try self.virtualCommonJsRepeatedWholeObjectExportType(stmt, imp.module)) |whole_t| return whole_t;
                if (try self.virtualCommonJsModuleExportObjectType(stmt, self.string_interner.get(imp.module))) |commonjs_t| return commonjs_t;
                if (try self.programCommonJsWholeExportType(stmt, self.string_interner.get(imp.module))) |whole_t| return whole_t;
                if (try self.programCommonJsNamedExportObjectType(stmt, self.string_interner.get(imp.module), false)) |commonjs_t| return commonjs_t;
            }
            if (imp.namespace_binding == binding and self.sourceDirectiveValueMentions("esModuleInterop", "true")) {
                const export_t = (try self.virtualExportAssignmentExpressionType(stmt, imp.module)) orelse
                    (try self.virtualExportAssignmentTargetStaticType(stmt, imp.module));
                if (export_t) |target_t| return try self.commonJsInteropNamespaceType(target_t);
            }
            if (imp.namespace_binding == binding) {
                if (try self.programCommonJsNamedExportObjectType(stmt, self.string_interner.get(imp.module), true)) |commonjs_t| return commonjs_t;
            }
            return try self.moduleNamespaceTypeForSpecifier(imp.module, stmt);
        }
        return null;
    }

    /// For a top-level CommonJS `exports.X = value`, `exports["X"] = value`,
    /// `module.exports.X = value`, or `module.exports["X"] = value` assignment, return the synthesized
    /// namespace member `X` typed as the assigned value's type. Returns
    /// null for any other assignment. Mirrors tsc's CommonJS module-shape
    /// inference (`modulePreserve4`'s `/g.js`).
