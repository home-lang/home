    fn checkFnSignatureOnly(self: *Checker, node: NodeId) CheckError!TypeId {
        try self.resolving_function_signatures.put(self.gpa, node, {});
        defer _ = self.resolving_function_signatures.remove(node);
        const f = hir_mod.fnDeclOf(self.hir, node);
        // Surface JS-file TS-only signature syntax. Type parameter
        // lists are syntax errors even without `@checkJs`; annotations
        // stay gated to checked JS below.
        try self.checkJsOnlySignatureAnnotations(node);
        try self.checkJsDocThisTagOnArrowFunction(node);
        try self.checkUnmatchedJsDocParameters(node);
        try self.checkJsDocTemplateBracketedName(node);
        const type_params = hir_mod.fnTypeParams(self.hir, node);
        const has_jsdoc_templates = self.fnHasJsDocTemplateTags(node);
        const prototype_constructor = self.enclosingPrototypeMethodConstructor(node);
        if (prototype_constructor) |constructor| {
            try self.reportPrototypeConstructorTemplateReferences(node, constructor);
        }
        try self.checkTypeParameterDeclList(type_params);
        try self.checkFunctionSignatureLocalTypeVisibility(node, type_params);
        if (type_params.len > 0 or has_jsdoc_templates) try self.pushNarrowScope();
        for (type_params) |tp| {
            if (self.hir.kindOf(tp) != .type_parameter) continue;
            const tpp = hir_mod.typeParameterOf(self.hir, tp);
            const placeholder = self.interner.internFreshTypeParameterWithFlags(
                tpp.name,
                types.Primitive.unknown,
                types.Primitive.none,
                types.Variance.fromHirBits(tpp.variance),
                tpp.is_const,
            ) catch return error.OutOfMemory;
            self.hir.setType(tp, placeholder);
            try self.recordNarrow(tpp.name, placeholder);
        }
        var captured_tp_ids: std.ArrayListUnmanaged(TypeId) = .empty;
        defer captured_tp_ids.deinit(self.gpa);
        for (type_params) |tp| {
            if (self.hir.kindOf(tp) != .type_parameter) continue;
            const tpp = hir_mod.typeParameterOf(self.hir, tp);
            const placeholder = self.hir.typeOf(tp);
            const constraint: TypeId = try self.typeParameterConstraintType(tpp.constraint);
            const def: TypeId = if (tpp.default != hir_mod.none_node_id)
                try self.lowerTypeParameterDefault(tpp.default)
            else
                types.Primitive.none;
            const tp_id = if (tpp.constraint == hir_mod.none_node_id and tpp.default == hir_mod.none_node_id)
                (self.lookupNarrow(tpp.name) orelse self.hir.typeOf(tp))
            else
                self.interner.internFreshTypeParameterWithFlags(
                    tpp.name,
                    constraint,
                    def,
                    types.Variance.fromHirBits(tpp.variance),
                    tpp.is_const,
                ) catch return error.OutOfMemory;
            if (placeholder != types.Primitive.none and placeholder != tp_id) {
                try self.type_parameter_placeholder_targets.put(self.gpa, placeholder, tp_id);
            }
            self.hir.setType(tp, tp_id);
            try self.recordNarrow(tpp.name, tp_id);
            try captured_tp_ids.append(self.gpa, tp_id);
        }
        try self.recordJsDocTemplateTypeParams(node, &captured_tp_ids);

        var param_types: std.ArrayListUnmanaged(TypeId) = .empty;
        defer param_types.deinit(self.gpa);
        var param_omittable: std.ArrayListUnmanaged(bool) = .empty;
        defer param_omittable.deinit(self.gpa);
        var param_display_omittable: std.ArrayListUnmanaged(bool) = .empty;
        defer param_display_omittable.deinit(self.gpa);
        var param_predicates: std.ArrayListUnmanaged(ParamPredicateEntry) = .empty;
        defer param_predicates.deinit(self.gpa);
        var param_nullish_array_defaults: std.ArrayListUnmanaged(bool) = .empty;
        defer param_nullish_array_defaults.deinit(self.gpa);
        const params = hir_mod.fnParams(self.hir, node);
        const malformed_closure_jsdoc_type = self.functionOrOwnerHasMalformedClosureJsDocTypeTag(node);
        const invalid_jsdoc_template_type = self.functionOrOwnerHasInvalidJsDocTemplateTypeCombination(node);
        const jsdoc_context_sig = if (malformed_closure_jsdoc_type or invalid_jsdoc_template_type)
            null
        else
            try self.jsDocContextualSignatureForFunction(node);
        const has_jsdoc_type_tag = try self.jsDocFunctionHasTypeTag(node);
        var has_rest_param = false;
        var explicit_this_t: TypeId = types.Primitive.none;
        var value_param_index: u16 = 0;
        var previous_jsdoc_optional_param = false;
        if (params.len == 0 and self.sourceHasCheckJsDirective()) try self.applyArgumentsJsDocParamTags(node);
        // Pre-scan: if this is an accessor (`get`/`set`) and any
        // parameter is a `this:` param (which is invalid ÃÂ¢ÃÂÃÂ TS2784
        // already fires), upstream tsc also suppresses TS7006 for any
        // accompanying (untyped) value parameters since the whole
        // signature shape is already malformed. Mirrors fixture
        // `thisTypeInAccessorsNegative`.
        var accessor_has_invalid_this = false;
        if (f.flags.is_getter or f.flags.is_setter) {
            for (params) |p_scan| {
                if (self.isThisParameter(p_scan)) {
                    accessor_has_invalid_this = true;
                    break;
                }
            }
        }
        for (params, 0..) |p, param_index| {
            const pp = hir_mod.parameterOf(self.hir, p);
            const is_this_param = self.isThisParameter(p) and !self.virtualSectionIsJsLike(node);
            try self.checkParameterDecoratorDiagnostics(p, node, param_index, is_this_param);
            if (f.body == hir_mod.none_node_id and pp.default_value != hir_mod.none_node_id) {
                try self.report(p, TsCodes.parameter_initializer_implementation_only, "A parameter initializer is only allowed in a function or constructor implementation.");
            }
            if (is_this_param and (param_index != 0 or pp.flags.is_rest)) {
                const report_node = if (pp.flags.is_rest and pp.name != hir_mod.none_node_id) pp.name else p;
                try self.report(report_node, TsCodes.this_parameter_must_be_first, "A 'this' parameter must be the first parameter.");
            }
            // TS2784 ÃÂ¢ÃÂÃÂ `get x(this: T): U {}` / `set x(this: T,
            // value: V) {}` are forbidden. Mirrors upstream
            // `thisTypeInAccessors.ts(8,11)`. Fire on the `this`
            // parameter node itself so the column matches.
            if (is_this_param and (f.flags.is_getter or f.flags.is_setter)) {
                try self.report(p, TsCodes.accessors_cannot_declare_this, "'get' and 'set' accessors cannot declare 'this' parameters.");
            }
            // TS2681 Ã¢ÂÂ a constructor declaration cannot declare a
            // `this` parameter. Mirrors upstream `checkParameter`,
            // which fires on the parameter node itself. Fires
            // regardless of position so it can co-occur with TS2680.
            if (is_this_param and f.flags.is_constructor) {
                try self.reportOnce(p, TsCodes.constructor_cannot_have_this_parameter, "A constructor cannot have a 'this' parameter.");
            }
            if (!is_this_param) {
                try param_nullish_array_defaults.append(
                    self.gpa,
                    pp.default_value != hir_mod.none_node_id and
                        (try self.nullishArrayLiteralTypeFromSyntax(pp.default_value)) != null,
                );
            }
            if (pp.flags.is_rest and !is_this_param) has_rest_param = true;
            const has_anno = pp.type_annotation != hir_mod.none_node_id;
            const js_default_is_empty_array = !has_anno and
                pp.default_value != hir_mod.none_node_id and
                self.sourceHasCheckJsDirective() and
                self.virtualSectionIsJsLike(node) and
                self.hir.kindOf(pp.default_value) == .array_literal and
                hir_mod.arrayLiteralElements(self.hir, pp.default_value).len == 0;
            const js_default_is_loose_nullish = !has_anno and
                pp.default_value != hir_mod.none_node_id and
                self.sourceHasCheckJsDirective() and
                self.virtualSectionIsJsLike(node) and
                !self.strict_flags.strict_null_checks and
                (self.hir.kindOf(pp.default_value) == .literal_null or
                    self.hir.kindOf(pp.default_value) == .literal_undefined);
            // Sweep param annotations for unresolved bare type-refs ÃÂ¢ÃÂÃÂ
            // for body-ful fns too. Mirrors upstream tsc, which fires
            // TS2304 on `function foo(x: V) { ... }` when `V` is not
            // declared anywhere. See
            // `typeParameterUsedAsTypeParameterConstraint4.ts`.
            if (has_anno) {
                try self.reportUnresolvedBodylessSignatureTypeRefs(pp.type_annotation, type_params);
            }
            const jsdoc_param_info: ?JsDocParamInfo = if (!has_anno and !is_this_param and self.sourceHasCheckJsDirective())
                if (pp.name != hir_mod.none_node_id and self.hir.kindOf(pp.name) == .identifier)
                    try self.jsDocParamInfoForFunctionParam(
                        node,
                        self.string_interner.get(hir_mod.identifierOf(self.hir, pp.name).name),
                    )
                else if (pp.name != hir_mod.none_node_id and
                    (self.hir.kindOf(pp.name) == .object_pattern or self.hir.kindOf(pp.name) == .array_pattern))
                    try self.jsDocParamInfoForFunctionParamIndex(node, value_param_index)
                else
                    null
            else
                null;
            const jsdoc_param_t: ?TypeId = if (jsdoc_param_info) |info| info.typ else null;
            const jsdoc_marks_optional = if (jsdoc_param_info) |info| info.optional else false;
            const has_jsdoc_param_type = jsdoc_param_t != null;
            if (pp.flags.is_rest and jsdoc_marks_optional) {
                const jsdoc = self.leadingJsDocBodyWithStart(self.source orelse "", self.hir.spanOf(node).start);
                const pos: ?u32 = if (jsdoc) |body|
                    @intCast(body.start + (std.mem.indexOf(u8, body.body, "@param") orelse 0))
                else
                    null;
                if (pos == null or !self.hasDiagnosticAtPosition(TsCodes.rest_parameter_cannot_be_optional, pos.?)) {
                    try self.reportAt(p, pos, TsCodes.rest_parameter_cannot_be_optional, "A rest parameter cannot be optional.");
                }
                try self.report(p, TsCodes.rest_parameter_must_be_array_type, "A rest parameter must be of an array type.");
            }
            if (f.flags.is_setter and jsdoc_marks_optional) {
                const jsdoc = self.leadingJsDocBodyWithStart(self.source orelse "", self.hir.spanOf(node).start);
                const pos: ?u32 = if (jsdoc) |body|
                    @intCast(body.start + (std.mem.indexOf(u8, body.body, "@param") orelse 0))
                else
                    null;
                if (pos == null or !self.hasDiagnosticAtPosition(1051, pos.?)) {
                    try self.reportAt(node, pos, 1051, "A 'set' accessor cannot have an optional parameter.");
                }
            }
            if (pp.name != hir_mod.none_node_id and
                (self.hir.kindOf(pp.name) == .object_pattern or self.hir.kindOf(pp.name) == .array_pattern) and
                jsdoc_marks_optional and
                pp.default_value == hir_mod.none_node_id and
                f.body != hir_mod.none_node_id)
            {
                try self.report(pp.name, TsCodes.binding_pattern_optional_parameter, "A binding pattern parameter cannot be optional in an implementation signature.");
            }
            if (!is_this_param and self.sourceHasCheckJsDirective()) {
                // A parameter marked optional via JSDoc (`@param {T} [name]`
                // or `@param {T=}`) is not "required", so it must not trip the
                // required-after-optional check (checkJsdocParamTag1).
                const is_required_now = !pp.flags.is_optional and
                    !pp.flags.is_rest and
                    pp.default_value == hir_mod.none_node_id and
                    !jsdoc_marks_optional;
                if (is_required_now and previous_jsdoc_optional_param) {
                    const anchor = if (pp.name != hir_mod.none_node_id) pp.name else p;
                    try self.report(anchor, TsCodes.required_parameter_after_optional, "A required parameter cannot follow an optional parameter.");
                }
                previous_jsdoc_optional_param = jsdoc_marks_optional;
            }
            // `f(x = literal)` ÃÂ¢ÃÂÃÂ when no annotation is present, the
            // default value's widened type seeds the parameter (tsc
            // does the same). Used by both the parameter typing pass
            // and the TS7006 implicit-any gate below; concrete types
            // (`number`, `string`, ÃÂ¢ÃÂÃÂ¦) suppress the diagnostic, but an
            // `any` default still falls through and reports.
            var inferred_from_default = false;
            const iife_context_t: ?TypeId = if (!has_anno and pp.default_value == hir_mod.none_node_id)
                try self.iifeParameterTypeFromCallArgument(node, param_index, pp.flags.is_rest)
            else
                null;
            const jsdoc_context_param_t: ?TypeId = if (!has_anno and !has_jsdoc_param_type and !is_this_param) blk: {
                const sig = jsdoc_context_sig orelse break :blk null;
                const sig_params = self.interner.signatureParams(sig);
                if (value_param_index >= sig_params.len) break :blk null;
                break :blk sig_params[value_param_index];
            } else null;
            const contextual_tuple_param_t: ?TypeId = if (!has_anno and
                !has_jsdoc_param_type and
                !is_this_param and
                !invalid_jsdoc_template_type)
            blk: {
                if (try self.contextualParameterTypeFromFunctionAnnotation(node, p)) |syntax_t| {
                    break :blk syntax_t;
                }
                const target_t = (self.contextualTupleElementTargetForFunction(node) catch null) orelse break :blk null;
                break :blk self.contextualParameterTypeForFunctionParam(node, p, target_t);
            } else null;
            const returned_function_context_t: ?TypeId = if (!has_anno and !has_jsdoc_param_type and !is_this_param) blk: {
                const parent = self.hir.parentOf(node);
                if (parent == hir_mod.none_node_id or self.hir.kindOf(parent) != .return_stmt) break :blk null;
                break :blk self.returnedFunctionContextualParameterType(parent, node, p);
            } else null;
            const contextual_param_t: ?TypeId = if (!has_anno and
                !has_jsdoc_param_type and
                !is_this_param and
                !malformed_closure_jsdoc_type and
                !invalid_jsdoc_template_type and
                pp.default_value == hir_mod.none_node_id)
            blk: {
                const parent = self.hir.parentOf(node);
                if (parent == hir_mod.none_node_id) break :blk null;
                var object_member_target: ?TypeId = null;
                var object_context_claimed = false;
                switch (self.hir.kindOf(parent)) {
                    .assignment, .var_decl, .let_decl, .const_decl => {},
                    .call_expr, .new_expr, .conditional, .binary_op, .arrow_fn => {},
                    .object_property => {
                        const property = hir_mod.objectPropertyOf(self.hir, parent);
                        if (property.value != node) break :blk null;
                        const object_node = self.hir.parentOf(parent);
                        if (object_node == hir_mod.none_node_id or self.hir.kindOf(object_node) != .object_literal) break :blk null;
                        const satisfies_target = try self.jsDocSatisfiesTypeForExpression(object_node);
                        object_context_claimed = satisfies_target != null;
                        const object_target = satisfies_target orelse
                            self.contextualTargetTypeForExpression(object_node) orelse break :blk null;
                        // An optional object-literal argument is contextually
                        // typed by `T | undefined`. Strip only the nullish
                        // wrapper; a real union still requires merged member
                        // context and is handled conservatively below.
                        const narrowed_object_target = self.subtractNullUndefined(object_target) catch object_target;
                        if (narrowed_object_target >= self.interner.pool.typeCount() or
                            self.interner.pool.flagsOf(narrowed_object_target).is_union) break :blk null;
                        const member_name = self.propertyNameFromKeyNode(property.key) orelse break :blk null;
                        object_member_target = try self.contextualObjectLiteralMemberTarget(narrowed_object_target, member_name);
                        if (object_member_target == null and !object_context_claimed) {
                            object_member_target = try self.programContextualObjectLiteralMemberType(object_node, member_name);
                        }
                    },
                    else => break :blk null,
                }
                if (try self.contextualParameterTypeFromFunctionAnnotation(node, p)) |syntax_t| {
                    break :blk syntax_t;
                }
                const target_t = object_member_target orelse if (object_context_claimed)
                    break :blk null
                else
                    self.contextualTargetTypeForFunction(node) orelse break :blk null;
                if (target_t >= self.interner.pool.typeCount()) break :blk null;
                const parameter_t = self.contextualParameterTypeForFunctionParam(node, p, target_t) orelse break :blk null;
                // An unresolved return type does not prevent contextual typing
                // of a parameter whose type is already known.
                if (self.containsEscapingContextualTypeParameter(target_t) and
                    self.containsEscapingContextualTypeParameter(parameter_t)) break :blk null;
                break :blk parameter_t;
            } else null;
            const contextual_default_param_t: ?TypeId = if (!has_anno and !has_jsdoc_param_type and !is_this_param and
                pp.default_value != hir_mod.none_node_id)
            blk: {
                const target_t = self.contextualTargetTypeForFunction(node) orelse break :blk null;
                const context_t = self.contextualParameterTypeForFunctionParam(node, p, target_t) orelse break :blk null;
                if (self.typeIncludesUndefined(context_t)) {
                    const without_undefined = self.subtractType(context_t, types.Primitive.undefined_t) catch context_t;
                    if (without_undefined != types.Primitive.never and without_undefined != types.Primitive.none) {
                        break :blk without_undefined;
                    }
                }
                break :blk context_t;
            } else null;
            // An un-annotated callback passed to a built-in array
            // iteration method (`arr.map((x) => ÃÂ¢ÃÂÃÂ¦)`) gets its first
            // parameter contextually typed to the array element type
            // ÃÂ¢ÃÂÃÂ mirroring tsc's generic callback inference. Only the
            // IIFE path takes precedence; otherwise this seeds `x`.
            const array_callback_context_t: ?TypeId = if (!has_anno and !is_this_param and
                !pp.flags.is_rest and pp.default_value == hir_mod.none_node_id and iife_context_t == null)
                try self.arrayCallbackParameterType(node, param_index)
            else
                null;
            const json_callback_context_t: ?TypeId = if (!has_anno and !is_this_param and
                !pp.flags.is_rest and pp.default_value == hir_mod.none_node_id)
                try self.jsonTransformCallbackParameterType(node, param_index)
            else
                null;
            var inferred_object_binding_pattern = false;
            const t: TypeId = if (has_anno) blk: {
                const lowered_annotation_t = try self.lowererLowerWithTypeParams(pp.type_annotation);
                break :blk if (self.typeAnnotationShouldBecomeErrorAny(pp.type_annotation))
                    types.Primitive.any
                else
                    lowered_annotation_t;
            } else if (jsdoc_param_t) |jt|
                jt
            else if (jsdoc_context_param_t) |jt|
                jt
            else if (contextual_tuple_param_t) |context_t|
                context_t
            else if (returned_function_context_t) |context_t|
                context_t
            else if (contextual_param_t) |context_t|
                context_t
            else if (contextual_default_param_t) |context_t|
                context_t
            else if (pp.default_value != hir_mod.none_node_id and
                pp.name != hir_mod.none_node_id and
                self.hir.kindOf(pp.name) == .array_pattern)
                try self.checkExpression(pp.default_value)
            else if (pp.name != hir_mod.none_node_id and
                self.hir.kindOf(pp.name) == .array_pattern and
                (pp.flags.is_rest or self.arrayBindingPatternHasRest(pp.name) or pp.default_value == hir_mod.none_node_id))
                try self.arrayBindingPatternParameterType(pp.name)
            else if (pp.name != hir_mod.none_node_id and
                self.hir.kindOf(pp.name) == .object_pattern and
                !is_this_param)
            // `function f({ x: [a, b] }) {}` ÃÂ¢ÃÂÃÂ tsc infers the
            // parameter type from the BINDING PATTERN's shape
            // (`{ x: [any, any] }`). A parent default can seed
            // element types, but the pattern itself still controls
            // which members exist. Mirrors
            // `destructuringWithLiteralInitializers` and keeps
            // destructured object parameters from collapsing to
            // `any` when no annotation/default is present.
            blk_object_pattern: {
                inferred_object_binding_pattern = true;
                break :blk_object_pattern try self.objectBindingPatternParameterTypeWithDefault(pp.name, pp.default_value);
            } else if (pp.default_value != hir_mod.none_node_id and !is_this_param) blk_default: {
                if (js_default_is_loose_nullish) break :blk_default types.Primitive.any;
                var default_t = if (try self.nullishArrayLiteralTypeFromSyntax(pp.default_value)) |nullish_array_t|
                    nullish_array_t
                else
                    try self.checkExpression(pp.default_value);
                if (self.hir.kindOf(pp.default_value) == .identifier) {
                    const declared_default_t = (try self.jsDocTypeForPreviousIdentifierDecl(pp.default_value)) orelse
                        self.visibleAnnotatedIdentifierType(pp.default_value) orelse
                        self.typeOfIdentifierDeclared(pp.default_value);
                    if (self.typeIncludesUndefined(declared_default_t)) {
                        const without_undefined = self.subtractType(declared_default_t, types.Primitive.undefined_t) catch declared_default_t;
                        if (without_undefined != types.Primitive.never and without_undefined != types.Primitive.none) {
                            default_t = without_undefined;
                        }
                    }
                }
                const widened = if (self.hir.kindOf(pp.default_value) == .array_literal and
                    self.arrayParameterElementTypeIsNullishOnly(default_t))
                    default_t
                else
                    self.widenForInference(default_t);
                if (!js_default_is_empty_array and
                    !self.typeIsAnyLike(widened) and widened != types.Primitive.none)
                {
                    inferred_from_default = true;
                }
                break :blk_default widened;
            } else if (iife_context_t) |context_t|
                context_t
            else if (array_callback_context_t) |context_t|
                context_t
            else if (json_callback_context_t) |context_t|
                context_t
            else
                types.Primitive.any;
            const declared_param_t = t;
            const has_contextual_parameter_type = jsdoc_context_param_t != null or
                contextual_tuple_param_t != null or
                returned_function_context_t != null or
                contextual_param_t != null or
                contextual_default_param_t != null or
                array_callback_context_t != null or
                json_callback_context_t != null;
            if (has_contextual_parameter_type and
                declared_param_t != types.Primitive.none and
                declared_param_t != types.Primitive.any and
                declared_param_t != types.Primitive.unknown)
            {
                try self.resolved_contextual_parameters.put(self.gpa, p, {});
                self.removePriorDiagnosticForNode(p, TsCodes.parameter_implicitly_any);
                self.removePriorDiagnosticForNode(p, TsCodes.rest_parameter_implicitly_any);
                self.removePriorDiagnosticForNode(p, TsCodes.parameter_implicitly_any_suggestion);
                self.removePriorDiagnosticForNode(p, TsCodes.rest_parameter_implicitly_any_suggestion);
            }
            if (!has_anno and pp.name != hir_mod.none_node_id and self.hir.kindOf(pp.name) == .object_pattern) {
                _ = if (inferred_object_binding_pattern)
                    try self.checkInferredObjectBindingComputedKeys(pp.name, declared_param_t)
                else
                    try self.checkObjectBindingComputedKeysAgainstType(pp.name, declared_param_t);
            }
            if (has_anno and pp.name != hir_mod.none_node_id) {
                const name_kind = self.hir.kindOf(pp.name);
                if (name_kind == .array_pattern or name_kind == .object_pattern) {
                    _ = try self.checkBindingPatternSourceType(pp.name, declared_param_t, hir_mod.none_node_id);
                }
            }
            if ((has_anno or jsdoc_context_param_t != null) and pp.default_value != hir_mod.none_node_id) {
                const default_t = try self.checkExpression(pp.default_value);
                const literal_ok = try self.literalExpressionAssignableToTarget(pp.default_value, declared_param_t);
                const array_literal_ok = self.hir.kindOf(pp.default_value) == .array_literal and
                    try self.arrayLiteralAssignableToTargetInner(pp.default_value, declared_param_t, false);
                const object_literal_ok = self.hir.kindOf(pp.default_value) == .object_literal and
                    (self.objectLiteralAssignableToTarget(pp.default_value, default_t, declared_param_t) catch false);
                const loose_nullish_ok = !self.strict_flags.strict_null_checks and
                    (default_t == types.Primitive.null_t or default_t == types.Primitive.undefined_t);
                if (!literal_ok and
                    !array_literal_ok and
                    !object_literal_ok and
                    !loose_nullish_ok and
                    (self.typeParameterAssignmentNeedsInstantiationCheck(default_t, declared_param_t) or
                        !(self.engine.isAssignableTo(default_t, declared_param_t) catch true)))
                {
                    // Plain parameters anchor at the parameter name,
                    // while constructor parameter properties anchor at
                    // the first property modifier (`public`, `readonly`,
                    // etc.) and underline the whole parameter property.
                    const anchor = if (jsdoc_context_param_t != null)
                        p
                    else if (pp.flags.is_parameter_property)
                        p
                    else if (pp.name != hir_mod.none_node_id)
                        pp.name
                    else
                        p;
                    try self.reportPlainTypeNotAssignable(
                        anchor,
                        default_t,
                        declared_param_t,
                        "Parameter initializer is not assignable to parameter type.",
                    );
                }
            }
            // TS2370 ÃÂ¢ÃÂÃÂ `function f(...x: T)` requires `T` to be an
            // array type (any tuple, `T[]`, `Array<T>`, etc.). The
            // syntax check covers `Array<T>` / `ReadonlyArray<T>`
            // even when the lib types haven't been bound for a
            // fixture; the type-level check handles bare
            // identifiers / aliases that resolve to array shapes
            // through the interner.
            if (pp.flags.is_rest and !is_this_param and has_anno and
                !self.restParamAnnotationLooksArrayLike(pp.type_annotation) and
                !self.restParamTypeIsValidArrayLike(declared_param_t))
            {
                try self.report(p, TsCodes.rest_parameter_must_be_array_type, "A rest parameter must be of an array type.");
            }
            // Without an annotation, tsc still emits TS2370 when the
            // inferred symbol type isn't assignable to a readonly any[]:
            //   * `function f(...bar = 0)` ÃÂ¢ÃÂÃÂ inferred from initializer
            //      (here `0` ÃÂ¢ÃÂÃÂ `number`), which fails the array check.
            //   * `(...arg?) => ÃÂ¢ÃÂÃÂ¦`         ÃÂ¢ÃÂÃÂ arrow-function rest with
            //      `?` widens to `any | undefined`, not an array
            //      (class methods don't trip this ÃÂ¢ÃÂÃÂ they resolve to
            //      plain `any` which IS assignable to `any[]`).
            // Mirrors `parserParameterList10.ts` and `parserParameterList11.ts`.
            if (pp.flags.is_rest and !is_this_param and !has_anno) {
                const malformed_initializer = inferred_from_default and
                    !self.restParamTypeIsValidArrayLike(declared_param_t);
                const optional_in_arrow = pp.flags.is_optional and
                    self.hir.kindOf(self.hir.parentOf(p)) == .arrow_fn;
                if (malformed_initializer or optional_in_arrow) {
                    try self.report(p, TsCodes.rest_parameter_must_be_array_type, "A rest parameter must be of an array type.");
                }
            }
            // `f(x?: T)` and `f(x: T = default)` both widen the
            // signature parameter type to include `undefined` so
            // callers can omit the arg. Inside the function body
            // however, an `?:` parameter is still observably
            // `T | undefined`, while a defaulted `= expr` parameter
            // is just `T` because the default fills in for undefined
            // before the body runs. Mirrors tsc's control-flow
            // narrowing for defaulted params.
            var signature_t: TypeId = t;
            if (pp.flags.is_optional or jsdoc_marks_optional or pp.default_value != hir_mod.none_node_id) {
                signature_t = self.unionWithUndefined(t) catch t;
            }
            const body_t: TypeId = if ((pp.flags.is_optional or jsdoc_marks_optional) and pp.default_value == hir_mod.none_node_id)
                signature_t
            else
                t;
            self.hir.setType(p, body_t);
            if (pp.name != hir_mod.none_node_id) self.hir.setType(pp.name, body_t);
            if (is_this_param) {
                if (f.flags.is_arrow) {
                    try self.report(p, TsCodes.arrow_function_cannot_have_this_parameter, "An arrow function cannot have a 'this' parameter.");
                }
                explicit_this_t = body_t;
                continue;
            }
            try param_types.append(self.gpa, signature_t);
            try param_omittable.append(self.gpa, pp.flags.is_rest or
                (!has_anno and
                    !has_jsdoc_param_type and
                    jsdoc_context_param_t == null and
                    !has_jsdoc_type_tag and
                    self.virtualSectionIsJsLike(node)) or
                pp.flags.is_optional or
                jsdoc_marks_optional or
                pp.default_value != hir_mod.none_node_id or
                self.parameterTypeAllowsVoidOmission(t));
            try param_display_omittable.append(self.gpa, pp.flags.is_rest or
                pp.flags.is_optional or
                jsdoc_marks_optional or
                pp.default_value != hir_mod.none_node_id or
                self.parameterTypeAllowsVoidOmission(t));
            if (self.signature_predicates.get(t)) |param_pred| {
                try param_predicates.append(self.gpa, .{ .param_index = value_param_index, .pred = param_pred });
            }
            value_param_index += 1;
            // Suppress TS7006 when the default-value initializer is
            // an `await` expression with no operand ÃÂ¢ÃÂÃÂ i.e. the parser
            // already emitted TS2524 + TS1109 for `f(a = await)` /
            // similar inside an async function. Mirrors tsc's
            // `asyncFunctionDeclaration6/7_es*` baselines which omit
            // the implicit-any diagnostic when the initializer parse
            // failed in this specific shape.
            const default_is_await_error_placeholder = pp.default_value != hir_mod.none_node_id and
                self.hir.kindOf(pp.default_value) == .await_expr and
                hir_mod.awaitExprOf(self.hir, pp.default_value).expr == hir_mod.none_node_id;
            // `function * foo(a = yield)` ÃÂ¢ÃÂÃÂ tsc emits TS2523 ("yield
            // expressions cannot be used in a parameter initializer.")
            // and SKIPS the outer TS7006 for the parameter itself.
            // The companion TS7057 on the yield expression is emitted
            // by the parser at the same TS2523 site (so the relative
            // ordering matches tsc, and parse-recovery shapes that
            // tsc treats as already-broken ÃÂ¢ÃÂÃÂ e.g. `a = yield => ÃÂ¢ÃÂÃÂ¦`
            // in `FunctionDeclaration10_es6` ÃÂ¢ÃÂÃÂ can skip the TS7057
            // without re-deriving the recovery from the HIR).
            const default_is_yield_in_param_initializer = pp.default_value != hir_mod.none_node_id and
                self.hir.kindOf(pp.default_value) == .yield_expr;
            // Implicit-any reporting fires under noImplicitAny (hard
            // error: TS7006/TS7019) OR, when suggestions are enabled and
            // noImplicitAny is OFF, as the `.suggestion`-category hint
            // (TS7044/TS7047 "a better type may be inferred from usage").
            // Mirrors tsc `reportImplicitAny`'s `errorOrSuggestion`.
            const param_implicit_any_report = self.strict_flags.no_implicit_any or
                (self.emit_implicit_any_suggestions and !self.strict_flags.no_implicit_any);
            const constructor_default_infers_this = f.flags.is_constructor and
                pp.default_value != hir_mod.none_node_id and
                self.expressionContainsThis(pp.default_value);
            const rest_has_contextual_signature = pp.flags.is_rest and
                self.functionHasContextualCallableType(node);
            const has_named_jsdoc_param = pp.name != hir_mod.none_node_id and
                self.hir.kindOf(pp.name) == .identifier and
                self.fnHasLeadingJsDocParam(
                    node,
                    self.string_interner.get(hir_mod.identifierOf(self.hir, pp.name).name),
                );
            if (!has_anno and !has_jsdoc_param_type and jsdoc_context_param_t == null and
                contextual_tuple_param_t == null and
                contextual_param_t == null and
                array_callback_context_t == null and
                json_callback_context_t == null and
                !inferred_from_default and param_implicit_any_report and
                !default_is_await_error_placeholder and
                !default_is_yield_in_param_initializer and
                !constructor_default_infers_this and
                !accessor_has_invalid_this and
                !self.parameterInEs5ObjectLiteralSetterWithSuper(p) and
                !self.functionIsObjectDefinePropertyDescriptorAccessor(node) and
                !((has_named_jsdoc_param or self.functionOrOwnerHasLeadingJsDocParamOrTypeTag(node)) and
                    !self.fnIsJsDocConstructorOverloadImplementation(node)) and
                !self.functionIsPrivateAmbientClassMember(node) and
                !rest_has_contextual_signature and
                !self.resolved_contextual_parameters.contains(p) and
                (!self.parameterHasContextualType(node, p) or
                    malformed_closure_jsdoc_type or
                    invalid_jsdoc_template_type))
            {
                // Binding-pattern parameters (`function f([a, b]) {}` /
                // `function f({a, b}) {}`) ÃÂ¢ÃÂÃÂ tsc reports one TS7031
                // per *named* binding element rather than a single
                // TS7006 for the whole anonymous parameter. The
                // `<anonymous>` placeholder we used here previously
                // produced a single spurious diagnostic with the
                // wrong code, span, and (typically) name.
                const name_kind: hir_mod.NodeKind = if (pp.name != hir_mod.none_node_id) self.hir.kindOf(pp.name) else .identifier;
                const param_is_suggestion = !self.strict_flags.no_implicit_any;
                if (pp.name != hir_mod.none_node_id and (name_kind == .array_pattern or name_kind == .object_pattern)) {
                    // tsc does NOT issue suggestions for binding elements
                    // (the codefix doesn't support them), so the per-element
                    // TS7031 family stays error-only.
                    if (param_is_suggestion) {
                        // no-op under !noImplicitAny
                    } else
                    // A parameter-level default supplies the binding
                    // pattern's contextual type, so tsc suppresses the
                    // per-element implicit-any diagnostics there
                    // (`function f([a] = [undefined]) {}`).
                    if (pp.default_value == hir_mod.none_node_id) {
                        try self.reportImplicitAnyBindingPatternElements(pp.name, &.{});
                    } else if (name_kind == .array_pattern and
                        self.hir.kindOf(pp.default_value) == .array_literal)
                    {
                        // `function f([x, y] = [1])` ÃÂ¢ÃÂÃÂ when the default is
                        // an array literal, tsc still emits TS7031 for any
                        // binding element whose index isn't filled in by
                        // the default. Pass the literal's element nodes so
                        // each slot can be checked individually. Mirrors
                        // `destructuringWithLiteralInitializers2` lines 2/3/7/8.
                        const init_values = hir_mod.arrayLiteralElements(self.hir, pp.default_value);
                        try self.reportImplicitAnyBindingPatternElements(pp.name, init_values);
                    } else if (name_kind == .object_pattern) {
                        try self.reportImplicitAnyEmptyArrayBindingDefaults(pp.name);
                    }
                } else {
                    const raw_param_name: []const u8 = if (pp.name != hir_mod.none_node_id and name_kind == .identifier)
                        self.string_interner.get(hir_mod.identifierOf(self.hir, pp.name).name)
                    else
                        "<anonymous>";
                    const param_name = if (raw_param_name.len == 0) "(Missing)" else raw_param_name;
                    // In `.js` files (or `// @allowJs` virtual sections),
                    // a leading JSDoc `@param {T} <name>` annotates the
                    // parameter and suppresses TS7006. Mirrors upstream tsc
                    // which treats the JSDoc tag as the parameter type.
                    if (self.sourceHasCheckJsDirective() and
                        self.fnHasLeadingJsDocParam(node, param_name))
                    {
                        // Skip ÃÂ¢ÃÂÃÂ JSDoc supplies the type.
                    } else if (self.fnIsObjectLiteralSetterWithPairedGetter(node)) {
                        // Skip — a paired getter supplies the setter
                        // parameter's type (thisTypeInAccessors.ts).
                    } else if (pp.flags.is_rest) {
                        // `function f(...a) {}` ÃÂ¢ÃÂÃÂ tsc emits TS7019
                        // ("Rest parameter 'X' implicitly has an
                        // 'any[]' type.") rather than the plain TS7006
                        // implicit-any. Anchor at the parameter span
                        // (starting at the `...` token) so the column
                        // matches upstream. Under !noImplicitAny the
                        // suggestion variant TS7047 fires instead.
                        const msg = if (param_is_suggestion)
                            try std.fmt.allocPrint(
                                self.diag_arena.allocator(),
                                "Rest parameter '{s}' implicitly has an 'any[]' type, but a better type may be inferred from usage.",
                                .{param_name},
                            )
                        else
                            try std.fmt.allocPrint(
                                self.diag_arena.allocator(),
                                "Rest parameter '{s}' implicitly has an 'any[]' type.",
                                .{param_name},
                            );
                        try self.diagnostics.append(self.gpa, .{
                            .node = p,
                            .code = if (param_is_suggestion)
                                TsCodes.rest_parameter_implicitly_any_suggestion
                            else
                                TsCodes.rest_parameter_implicitly_any,
                            .message = msg,
                            .category = if (param_is_suggestion) .suggestion else .error_,
                        });
                    } else {
                        // `function f(x = x)` ÃÂ¢ÃÂÃÂ when the default value
                        // references the parameter name itself, tsc
                        // upgrades the diagnostic to TS7022 ("'X'
                        // implicitly has type 'any' because it does
                        // not have a type annotation and is referenced
                        // directly or indirectly in its own initializer.")
                        // anchored on the parameter binding. The
                        // companion TS2372 ("Parameter 'X' cannot
                        // reference itself.") still fires at the
                        // reference site. Mirrors
                        // `FunctionDeclaration3_es6`.
                        const is_self_ref_default = blk_self: {
                            if (pp.default_value == hir_mod.none_node_id) break :blk_self false;
                            if (pp.name == hir_mod.none_node_id) break :blk_self false;
                            if (self.hir.kindOf(pp.name) != .identifier) break :blk_self false;
                            const pn = hir_mod.identifierOf(self.hir, pp.name).name;
                            var refs: std.ArrayListUnmanaged(NameRef) = .empty;
                            defer refs.deinit(self.gpa);
                            self.collectIdentifierRefsWithNodes(pp.default_value, &refs) catch break :blk_self false;
                            for (refs.items) |ref| {
                                if (ref.name == pn) break :blk_self true;
                            }
                            break :blk_self false;
                        };
                        // Suppress the self-reference TS7022 form under
                        // suggestion mode: tsc reports that as a hard error
                        // (it isn't routed through the usage-suggestion
                        // path), so when noImplicitAny is OFF we simply
                        // fall back to the plain parameter suggestion.
                        const emit_self_ref = is_self_ref_default and !param_is_suggestion;
                        const code: u32 = if (emit_self_ref)
                            TsCodes.variable_self_reference_implicitly_any
                        else if (param_is_suggestion)
                            TsCodes.parameter_implicitly_any_suggestion
                        else
                            TsCodes.parameter_implicitly_any;
                        const msg = if (emit_self_ref)
                            try std.fmt.allocPrint(
                                self.diag_arena.allocator(),
                                "'{s}' implicitly has type 'any' because it does not have a type annotation and is referenced directly or indirectly in its own initializer.",
                                .{param_name},
                            )
                        else if (!param_is_suggestion and js_default_is_empty_array)
                            try std.fmt.allocPrint(
                                self.diag_arena.allocator(),
                                "Parameter '{s}' implicitly has an 'any[]' type.",
                                .{param_name},
                            )
                        else if (param_is_suggestion)
                            try std.fmt.allocPrint(
                                self.diag_arena.allocator(),
                                "Parameter '{s}' implicitly has an 'any' type, but a better type may be inferred from usage.",
                                .{param_name},
                            )
                        else
                            try std.fmt.allocPrint(
                                self.diag_arena.allocator(),
                                "Parameter '{s}' implicitly has an 'any' type.",
                                .{param_name},
                            );
                        const anchor: NodeId = if (emit_self_ref and pp.name != hir_mod.none_node_id) pp.name else p;
                        if (!self.diagnosticExists(anchor, code)) {
                            try self.diagnostics.append(self.gpa, .{
                                .node = anchor,
                                .code = code,
                                .message = msg,
                                .category = if (param_is_suggestion) .suggestion else .error_,
                            });
                        }
                    }
                }
            }
        }

        // Detect a `arg is T` / `asserts arg is T` return-type
        // before lowering ÃÂ¢ÃÂÃÂ the predicate's target type is the
        // *return type* for assignability purposes (it always
        // returns boolean), but we record the predicate separately
        // so call sites can narrow the argument.
        const is_predicate = f.return_type != hir_mod.none_node_id and
            self.hir.kindOf(f.return_type) == .type_predicate_type;
        const jsdoc_predicate = if (!is_predicate)
            try self.jsDocPredicateForFunction(node, params)
        else
            null;
        if (is_predicate) {
            try self.checkTypePredicateConstraints(f.return_type, params);
        }
        // Bodyless-aware TS2304 sweep for return types ÃÂ¢ÃÂÃÂ fires
        // for any declared return-type annotation that references
        // an unresolved bare name (whether or not a body follows).
        // Mirrors upstream tsc, which surfaces TS2304 on return-type
        // refs like `function foo(): V` when `V` is not in scope.
        if (f.return_type != hir_mod.none_node_id) {
            try self.reportUnresolvedBodylessSignatureTypeRefs(f.return_type, type_params);
        }
        const contextual_jsdoc_is_async_target = if (f.flags.is_async)
            if (try self.jsDocDeclaredReturnForFunction(node)) |jsdoc_return|
                jsdoc_return.origin == .contextual_type or
                    jsdoc_return.origin == .contextual_type_owner
            else
                false
        else
            false;
        const ret_t: TypeId = if (f.return_type != hir_mod.none_node_id)
            (if (is_predicate)
                (if (hir_mod.typePredicateOf(self.hir, f.return_type).is_asserts) types.Primitive.void_t else types.Primitive.boolean_t)
            else if (self.typeAnnotationShouldBecomeErrorAny(f.return_type))
                types.Primitive.any
            else
                try self.lowerReturnTypeAnnotationWithCircularityGuard(node, f.return_type))
        else if (jsdoc_predicate) |pred|
            if (pred.is_asserts) types.Primitive.void_t else types.Primitive.boolean_t
        else if (jsdoc_context_sig) |sig|
            if (contextual_jsdoc_is_async_target)
                types.Primitive.any
            else
                self.interner.signatureReturn(sig) orelse types.Primitive.any
        else
            types.Primitive.any;
        if (f.body == hir_mod.none_node_id and f.return_type == hir_mod.none_node_id) {
            try self.reportImplicitAnySignatureReturn(node);
        }
        if (f.flags.is_generator and f.return_type != hir_mod.none_node_id) {
            if (ret_t == types.Primitive.void_t) {
                try self.report(f.return_type, TsCodes.generator_void_return, "A generator cannot have a 'void' type annotation.");
            } else if (self.generatorReturnAnnotationDefinitelyInvalid(ret_t)) {
                const target_name = (try self.allocSimpleTypeName(ret_t)) orelse "unknown";
                const generator_name = if (f.flags.is_async) "AsyncGenerator" else "Generator";
                const msg = try std.fmt.allocPrint(
                    self.diag_arena.allocator(),
                    "Type '{s}<any, any, unknown>' is not assignable to type '{s}'.",
                    .{ generator_name, target_name },
                );
                try self.report(f.return_type, TsCodes.type_not_assignable, msg);
            } else if (self.generatorReturnAnnotationHasConflictingYieldTypes(f.return_type)) {
                const target_name = (try self.allocSimpleTypeName(ret_t)) orelse "unknown";
                const yield_t = self.generatorYieldTypeFromAnnotation(f.return_type) orelse types.Primitive.any;
                const yield_name = (try self.allocSimpleTypeName(yield_t)) orelse "any";
                const generator_name = if (f.flags.is_async) "AsyncGenerator" else "Generator";
                const msg = try std.fmt.allocPrint(
                    self.diag_arena.allocator(),
                    "Type '{s}<{s}, any, any>' is not assignable to type '{s}'.",
                    .{ generator_name, yield_name, target_name },
                );
                try self.report(f.return_type, TsCodes.type_not_assignable, msg);
            } else if (self.generatorReturnAnnotationRequiresMissingGeneratorMembers(ret_t)) {
                if (self.generatorReturnAnnotationFirstRequiredExtraMember(ret_t)) |member| {
                    const target_name = (try self.allocSimpleTypeName(ret_t)) orelse "unknown";
                    const yield_t = self.generatorYieldTypeFromAnnotation(f.return_type) orelse
                        self.interner.objectNumberIndex(ret_t);
                    const yield_name = if (yield_t == types.Primitive.none)
                        "any"
                    else
                        (try self.allocSimpleTypeName(yield_t)) orelse "any";
                    const generator_name = if (f.flags.is_async) "AsyncGenerator" else "Generator";
                    const msg = try std.fmt.allocPrint(
                        self.diag_arena.allocator(),
                        "Property '{s}' is missing in type '{s}<{s}, any, any>' but required in type '{s}'.",
                        .{ self.string_interner.get(member.name), generator_name, yield_name, target_name },
                    );
                    try self.report(f.return_type, TsCodes.property_missing_required, msg);
                } else {
                    try self.report(f.return_type, TsCodes.type_not_assignable, "Generator return type is not assignable to the declared return type.");
                }
            }
        }

        const sig = if (explicit_this_t != types.Primitive.none)
            self.interner.internSignatureWithThisType(param_types.items, ret_t, false, false, explicit_this_t) catch return error.OutOfMemory
        else
            self.interner.internSignature(param_types.items, ret_t, false) catch return error.OutOfMemory;
        try self.recordGenericSignatureParams(sig, captured_tp_ids.items);
        for (param_nullish_array_defaults.items) |has_nullish_default| {
            if (has_nullish_default) {
                const owned = try self.gpa.dupe(bool, param_nullish_array_defaults.items);
                try self.signature_nullish_array_defaults.put(self.gpa, sig, owned);
                break;
            }
        }
        if (explicit_this_t != types.Primitive.none) try self.signature_this_params.put(self.gpa, sig, explicit_this_t);
        try self.recordSignatureMinArgs(sig, param_omittable.items);
        try self.recordSignatureDisplayMinArgs(sig, param_display_omittable.items);
        try self.recordSignatureParamNames(sig, params);
        try self.recordSignatureDeclNode(sig, node);
        self.hir.setType(node, sig);
        if (f.name != hir_mod.none_node_id) self.hir.setType(f.name, sig);
        // Record rest-parameter signatures so call-site argument
        // checking can expand the trailing rest into a variadic match
        // (the interner keys signatures only by their flat parameter
        // type list, so rest-ness lives in `rest_signatures`).
        if (has_rest_param) {
            try self.rest_signatures.put(self.gpa, sig, {});
        }
        for (param_predicates.items) |entry| {
            try self.signature_param_predicates.put(self.gpa, .{
                .signature = sig,
                .param_index = entry.param_index,
            }, entry.pred);
        }
        // Auto-infer variance for any type parameter that had no
        // explicit `in` / `out` modifier. We walk the signature ÃÂ¢ÃÂÃÂ
        // an occurrence of T in a param slot is contravariant, in
        // the return slot covariant. The result lives in the
        // `inferred_variance` side table since the interner keys
        // variance into the TypeId.
        if (captured_tp_ids.items.len > 0) {
            var tp_ix: usize = 0;
            for (type_params) |tp_node| {
                if (self.hir.kindOf(tp_node) != .type_parameter) continue;
                const tpp_h = hir_mod.typeParameterOf(self.hir, tp_node);
                if (tp_ix >= captured_tp_ids.items.len) break;
                const tp_id_v = captured_tp_ids.items[tp_ix];
                tp_ix += 1;
                if (tpp_h.variance != 0) continue; // explicit `in`/`out`
                const v = self.inferVariance(sig, tp_id_v);
                try self.inferred_variance.put(self.gpa, tp_id_v, v);
            }
        }
        // Record the function's generic type parameters keyed by name
        // so call sites with explicit type args (`f<T>(args)`) can
        // substitute directly. Drop any prior recording on shadow.
        if (captured_tp_ids.items.len > 0 and f.name != hir_mod.none_node_id and self.hir.kindOf(f.name) == .identifier) {
            const fn_name = hir_mod.identifierOf(self.hir, f.name).name;
            if (self.generic_fns.fetchRemove(fn_name)) |old| self.gpa.free(old.value);
            const owned = captured_tp_ids.toOwnedSlice(self.gpa) catch return error.OutOfMemory;
            try self.generic_fns.put(self.gpa, fn_name, owned);
        }
        // Overload tracking: when multiple `function f(...)` decls
        // share a name, we treat the body-less ones as overload
        // signatures. The body-bearing one is the implementation
        // (used only for body typing ÃÂ¢ÃÂÃÂ never picked by call-site
        // resolution). Ambient overload lists have no body, so every
        // signature stays visible.
        if (f.name != hir_mod.none_node_id and self.hir.kindOf(f.name) == .identifier) {
            const fn_name = hir_mod.identifierOf(self.hir, f.name).name;
            const has_body = f.body != hir_mod.none_node_id;
            if (has_body) try self.registerJsDocFunctionOverloads(node, fn_name);
            const gop = try self.overloads.getOrPut(self.gpa, fn_name);
            if (!gop.found_existing) gop.value_ptr.* = .empty;
            const dop = try self.overload_decls.getOrPut(self.gpa, fn_name);
            if (!dop.found_existing) dop.value_ptr.* = .empty;
            if (!has_body) {
                try gop.value_ptr.*.append(self.gpa, sig);
                try dop.value_ptr.*.append(self.gpa, node);
            } else {
                // Implementation signature: only append if there
                // are existing overloads ÃÂ¢ÃÂÃÂ a single-decl function
                // doesn't need overload resolution.
                if (gop.value_ptr.*.items.len > 0) {
                    try gop.value_ptr.*.append(self.gpa, sig);
                    try dop.value_ptr.*.append(self.gpa, node);
                    try self.overload_has_implementation.put(self.gpa, fn_name, {});
                }
            }
        }
        // Record the predicate so call sites can narrow.
        if (is_predicate) {
            const pred = hir_mod.typePredicateOf(self.hir, f.return_type);
            const target_t: TypeId = if (pred.target_type != hir_mod.none_node_id)
                (self.lowererLowerWithTypeParams(pred.target_type) catch types.Primitive.unknown)
            else
                types.Primitive.unknown;
            const fn_pred: FnPredicate = .{
                .param_index = self.normalizedPredicateParamIndex(hir_mod.fnParams(self.hir, node), pred.param_index),
                .target_type = target_t,
                .target_node = pred.target_type,
                .is_asserts = pred.is_asserts,
            };
            if (f.name != hir_mod.none_node_id and self.hir.kindOf(f.name) == .identifier) {
                try self.fn_predicates.put(self.gpa, hir_mod.identifierOf(self.hir, f.name).name, fn_pred);
            }
            try self.signature_predicates.put(self.gpa, sig, fn_pred);
        }
        if (jsdoc_predicate) |pred| {
            try self.signature_predicates.put(self.gpa, sig, pred);
            if (f.name != hir_mod.none_node_id and self.hir.kindOf(f.name) == .identifier) {
                try self.fn_predicates.put(self.gpa, hir_mod.identifierOf(self.hir, f.name).name, pred);
            }
        }
        return sig;
    }

