"""Deterministic diagnostic scale of the existing workload, not a new timed row."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
sys.path.insert(0, str(repo / 'bench/vs_tsgo'))
import run
import competitors

families = 32768
project = root / 'nullsafe-scale-32768'
negative = root / 'nullsafe-scale-32768-negative'
assert not project.exists() and not negative.exists()
run.generate_null_safe_access(project, families)
shutil.copytree(project, negative)
source = negative / 'src/null-safe-access.ts'
content = source.read_text()
indices = sorted({0, families // 2, families - 1})
for index in indices:
    start = content.index(f'function readNullable{index}(')
    anchor = content.index('  const fallback = value!.fallback;', start)
    controls = '''  const invalidLabel: boolean = label;
  const invalidScore: string = score;
  const invalidFormatted: number = formatted;
  const invalidFallback: number = value!.fallback;
  const invalidOptionalLabel: string = value?.profile?.label;
  const invalidOptionalCall: string = value?.profile?.format?.(label);
  value?.profile?.format?.(123);
  value?.profile?.metrics?.[2];
  value?.profile?.missing;
  void invalidLabel; void invalidScore; void invalidFormatted;
  void invalidFallback; void invalidOptionalLabel; void invalidOptionalCall;
'''
    content = content[:anchor] + controls + content[anchor:]
run.write(source, content)
inventory = {name: competitors.inventory_hash(competitors.payload_inventory(path))
             for name, path in [('positive', project), ('negative', negative)]}
record = {'families': families, 'indices': indices, 'project': str(project), 'negative': str(negative),
          'input_hashes': inventory, 'timings_taken': False, 'sampling_started': False,
          'source': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip(),
          'generator_sha256': hashlib.sha256((repo / 'bench/vs_tsgo/run.py').read_bytes()).hexdigest(),
          'purpose': '128x the unchanged 256-family benchmark structure to observe one native execution; no changed types, removed bodies or new compiler mode'}
(root / 'scale-project.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record), flush=True)
