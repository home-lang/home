import hashlib
import json
from pathlib import Path
import sys

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
sys.path.insert(0, str(repo / 'bench/vs_tsgo'))
import run
import competitors

scale = json.loads((root / 'scale-project.json').read_text())
assert hashlib.sha256((repo / 'zig-out/bin/home-tsc').read_bytes()).hexdigest() == 'd58ddc54a147b3ad8b177a98a6b5cda04fd4df77595c5ccf44da690de5d57b32'
commands = run.compiler_commands()
versions = run.verified_compiler_versions(commands)
trace = []
record = {'versions': versions, 'records': trace, 'timings_taken': False, 'sampling_started': False}
for kind, path in [('positive', Path(scale['project'])), ('negative', Path(scale['negative']))]:
    expected = None if kind == 'positive' else sorted(['2322'] * 18 + ['2339', '2345', '2493'] * 3)
    for name, command in commands.items():
        result, passed = run.admission_process(name, command + ['--noEmit', '-p', str(path / 'tsconfig.json')],
                                             'nullsafe32768', expected_codes=expected, trace=trace)
        (root / 'scale-admission.json').write_text(json.dumps(record, indent=2) + '\n')
        print(kind, name, 'exit', result.returncode, 'passed', passed, flush=True)
        assert passed, 'Preserve failed admission; do not start sampling'
after = {name: competitors.inventory_hash(competitors.payload_inventory(path))
         for name, path in [('positive', Path(scale['project'])), ('negative', Path(scale['negative']))]}
assert after == scale['input_hashes']
record['passed'] = True
record['input_hashes_unchanged'] = True
(root / 'scale-admission.json').write_text(json.dumps(record, indent=2) + '\n')
print('All six complete scale admissions pass; no timing or sampling.', flush=True)
