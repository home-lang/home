import hashlib
import json
from pathlib import Path
import re

root = Path(__file__).resolve().parent
mapping = json.loads((root / 'native-address-map.json').read_text())
expected = 'd58ddc54a147b3ad8b177a98a6b5cda04fd4df77595c5ccf44da690de5d57b32'
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
assert digest(root / 'home-tsc-current') == digest(Path(mapping['exact_cached_link_image'])) == expected
assert digest(Path(mapping['object_path'])) == mapping['object_sha256']
original = (root / 'object-text.bin').read_bytes()
native = (root / 'native-text.bin').read_bytes()
assert hashlib.sha256(original).hexdigest() == mapping['object_text_sha256']
assert hashlib.sha256(native).hexdigest() == mapping['native_text_sha256']
start = mapping['object_native_start'] - mapping['native_text_start']
linked = native[start:start + len(original)]
assert len(linked) == len(original) == mapping['object_text_size']
text = (root / 'object-relocations.txt').read_text().split('  Section __text {', 1)[1].split('\n  }', 1)[0]
relocations = re.findall(r'Relocation \{\s+Offset: (0x[0-9A-F]+).*?Length: (\d+).*?Type: (ARM64_RELOC_\w+)', text, re.DOTALL)
assert len(relocations) == text.count('Relocation {') == mapping['declared_relocations']
allowed = {'ARM64_RELOC_BRANCH26', 'ARM64_RELOC_PAGE21', 'ARM64_RELOC_PAGEOFF12',
           'ARM64_RELOC_GOT_LOAD_PAGE21', 'ARM64_RELOC_GOT_LOAD_PAGEOFF12',
           'ARM64_RELOC_TLVP_LOAD_PAGE21', 'ARM64_RELOC_TLVP_LOAD_PAGEOFF12',
           'ARM64_RELOC_ADDEND', 'ARM64_RELOC_UNSIGNED'}
mask = bytearray(len(original))
for offset, length, kind in relocations:
    assert kind in allowed and int(length) in (2, 3)
    position, width = int(offset, 16), 1 << int(length)
    assert 0 <= position and position + width <= len(original)
    mask[position:position + width] = b'\x01' * width
assert sum(mask) == mapping['declared_relocation_bytes']
assert all(left == right or mask[index] for index, (left, right) in enumerate(zip(original, linked)))
symbols = {}
for line in (root / 'object-symbols.txt').read_text().splitlines():
    match = re.match(r'^([0-9a-f]+) [tT] (.+)$', line)
    if match:
        address = int(match.group(1), 16)
        if mapping['object_text_start'] <= address < mapping['object_text_start'] + len(original):
            symbols.setdefault(address + mapping['link_delta'], []).append(match.group(2))
addresses = sorted(symbols)
assert len(addresses) == len(mapping['ranges']) == mapping['mapped_text_ranges']
for index, entry in enumerate(mapping['ranges']):
    assert entry['start'] == addresses[index]
    assert entry['end'] == (addresses[index + 1] if index + 1 < len(addresses) else mapping['object_native_end'])
    assert entry['symbols'] == sorted(symbols[entry['start']])
record = {'passed': True, 'native_sha256': expected, 'object_sha256': mapping['object_sha256'],
          'map_sha256': digest(root / 'native-address-map.json'), 'ranges': len(addresses),
          'undeclared_changed_bytes': 0, 'whole_relocation_word_bytes': sum(mask),
          'opcode_equivalence_within_masks_claimed': False, 'native_tail_bytes_unmapped': len(native) - len(original),
          'relinked': False, 'sampling_started': False}
(root / 'verified-map.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record), flush=True)
