import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
verified = json.loads((root / 'verified-profile.json').read_text())
assert verified['passed'] and verified['native_process_runs'] == 1 and verified['verified_admissions'] == 36
assert hashlib.sha256((repo / 'zig-out/bin/home-tsc').read_bytes()).hexdigest() == verified['native_sha256']
assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=repo).decode() == ''
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip() == verified['source']
excluded = {'home-tsc-current', 'native-dump-copy', 'object-dump-copy', 'next-state.json', 'package-profile.json'}
entries = {}
for path in sorted(root.rglob('*')):
    assert not path.is_symlink()
    if path.is_file() and path.name not in excluded and '__pycache__' not in path.parts:
        entries['profile/' + str(path.relative_to(root))] = path.read_bytes()
for name in ['run.py', 'compare.py', 'competitors.py', 'corpus.toml']:
    entries['harness/' + name] = (repo / 'bench/vs_tsgo' / name).read_bytes()
entries['harness/darwin-arm64.json'] = (repo / 'bench/vs_tsgo/profiles/darwin-arm64.json').read_bytes()
publication = {**verified, 'relinked_or_diagnostic_image_used': False,
               'whole_relocation_words_masked': True, 'mask_opcode_equivalence_claimed': False,
               'whole_run_CPU_share_claimed': False, 'benchmark_timing_samples': 0,
               'windows_revised_before_first_sampling': True, 'universal_leadership_proven': False}
entries['publication.json'] = (json.dumps(publication, indent=2) + '\n').encode()
checksums = {name: hashlib.sha256(data).hexdigest() for name, data in entries.items()}
entries['SHA256SUMS'] = ''.join(checksums[name] + '  ' + name + '\n' for name in sorted(checksums)).encode()
output = repo / 'bench/vs_tsgo/evidence/20261010-exact-native-nullsafe-profile-864.tar.gz'
assert not output.exists()
with output.open('xb') as raw:
    with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as tar:
            for name, data in sorted(entries.items()):
                info = tarfile.TarInfo(name)
                info.size, info.mode = len(data), 0o644
                tar.addfile(info, io.BytesIO(data))
with tarfile.open(output, 'r:gz') as tar:
    for name, digest in checksums.items():
        assert hashlib.sha256(tar.extractfile(name).read()).hexdigest() == digest
result = {'archive': str(output.relative_to(repo)), 'sha256': hashlib.sha256(output.read_bytes()).hexdigest(),
          'payload_checksums': len(checksums), 'bytes': output.stat().st_size, 'verified': True}
(root / 'package-profile.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result), flush=True)
