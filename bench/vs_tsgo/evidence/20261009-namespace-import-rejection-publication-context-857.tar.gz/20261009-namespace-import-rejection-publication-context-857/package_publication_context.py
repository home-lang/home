import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import tarfile

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
lint = json.loads((root / 'lint-command.json').read_text())
focused = json.loads((root / 'focused-lint-command.json').read_text())
assert lint['exit'] == 1
assert focused['exit'] == 0
assert focused['publication_file_sha256_before'] == focused['publication_file_sha256_after'] == lint['publication_file_sha256_after']
assert lint['publication_file_sha256_before'] == lint['publication_file_sha256_after']
for name, digest in lint['publication_file_sha256_after'].items():
    assert hashlib.sha256((repo / name).read_bytes()).hexdigest() == digest
counts = re.findall(r'(\d+) problems \((\d+) errors, (\d+) warnings\)', (root / 'lint.log').read_text())
assert counts
build = json.loads((root / 'publication-main-build.json').read_text())
assert build['exit'] == 0 and build['source_clean_before_and_after']
assert build['native_sha256'] == '68c6ed517f9125ae1b570ff2e585c5b368745389af828258f6621fe5e6e0311c'
record = {'source_at_lint': lint['source'], 'publication_file_sha256': lint['publication_file_sha256_after'],
    'repo_lint_exit': 1, 'repo_lint_errors': int(counts[-1][1]), 'repo_lint_warnings': int(counts[-1][2]),
    'measurement_session': {'session': 84718, 'status': 'terminal', 'exit': 0},
    'restoration_session': {'session': 73798, 'status': 'terminal', 'exit': 0},
    'post_upstream_build_session': {'session': 33584, 'status': 'terminal', 'exit': 0},
    'lint_session': {'session': 27752, 'status': 'terminal', 'exit': 1},
    'focused_final_docs_lint_exit': 0,
    'candidate_pushed': False, 'decision': 'rejected', 'reason': 'independent destructuring interval wholly negative',
    'rounds': 592, 'admissions': 660, 'excluded_samples': 0,
    'autofixes': False, 'guard_changes': False, 'measurement_reruns_to_pass': False,
    'publication_main_build': build,
    'primary_archive': json.loads((root / 'archive.json').read_text()),
    'whole_goal': 'incomplete; no universal performance, Zod, canonical C++ or other-platform admission claim'}
(root / 'publication-context.json').write_text(json.dumps(record, indent=2) + '\n')
names = ('lint.py', 'lint.log', 'lint-command.json', 'focused_lint.py', 'focused-lint.log', 'focused-lint-command.json', 'verify_docs.py', 'check_publication_main.py',
    'publication-main-build.log', 'publication-main-build.json', 'publication-context.json', 'package_publication_context.py')
entries = {name: (root / name).read_bytes() for name in names}
checksums = ''.join(hashlib.sha256(data).hexdigest() + '  ' + name + '\n' for name, data in sorted(entries.items()))
count = len(entries)
entries['SHA256SUMS'] = checksums.encode()
name = '20261009-namespace-import-rejection-publication-context-857'
archive = repo / 'bench/vs_tsgo/evidence' / (name + '.tar.gz')
assert not archive.exists()
with archive.open('wb') as output:
    with gzip.GzipFile(filename='', mode='wb', fileobj=output, mtime=0) as gz:
        with tarfile.open(fileobj=gz, mode='w') as tar:
            for name, data in sorted(entries.items()):
                item = tarfile.TarInfo('20261009-namespace-import-rejection-publication-context-857/' + name)
                item.size, item.mode, item.mtime = len(data), 0o644, 0
                tar.addfile(item, io.BytesIO(data))
with tarfile.open(archive) as tar:
    for line in checksums.splitlines():
        expected, name = line.split('  ', 1)
        assert hashlib.sha256(tar.extractfile('20261009-namespace-import-rejection-publication-context-857/' + name).read()).hexdigest() == expected
report = {'archive': str(archive), 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'payload_checksums': count}
(root / 'publication-archive.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report))
