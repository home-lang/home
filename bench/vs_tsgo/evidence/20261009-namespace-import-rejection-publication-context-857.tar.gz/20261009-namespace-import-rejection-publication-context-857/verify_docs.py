"""Check published values against the complete frozen native protocol."""
import json
from pathlib import Path

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
data = json.loads((root / 'verified-pairs.json').read_text())
decision = json.loads((root / 'decision.json').read_text())
archive = json.loads((root / 'archive.json').read_text())
assert data['complete'] and data['admissions'] == 660
assert data['rounds'] == 382 + 30 * len(data['independent_rechecks'])
assert decision['status'] in ('accepted', 'rejected') and decision['source_commit'] != 'pending'
docs = (repo / 'docs/docs/TS_PERFORMANCE.md').read_text()
readme = (repo / 'README.md').read_text()
readme_table = readme.split('| #857 namespace-import confirmation |', 1)[1].split('\n\n', 1)[0]
heading = '## Ordered namespace-import candidates (2026-10-09 UTC)'
section = docs.split(heading, 1)[1].split('\n## ', 1)[0]
for line in (root / 'tables.md').read_text().splitlines():
    if line.startswith('|'):
        assert line in section, line
assert archive['sha256'] in section and f"**{archive['payload_checksums']:,}**" in section
assert f"**{data['rounds']}**" in section and '**660**' in section
for key in ('parent_source', 'candidate_patch_sha256', 'protocol_sha256'):
    assert decision[key] in section
for digest in decision['binaries'].values():
    assert digest in section
for name in decision['independent_confirmed_regressions']:
    assert name.split('/', 1)[1] in section
assert 'not production admission' in section and '198' in section and '600' in section
assert 'inconclusive' in section and 'no' in section.lower() and 'universal' in section.lower()
if decision['status'] == 'rejected':
    assert 'never pushed' in section
else:
    assert decision['source_commit'] in section
for key in ('confirmation/checkjs_jsdoc', 'confirmation/checkjs512', 'recheck/destructuring', 'interface-risk/class_hierarchy', 'interface-risk/interface_composition'):
    for field in ('parent_median', 'candidate_median'):
        assert f"{data['summaries'][key][field] * 1000:,.3f} ms" in readme_table
    low, high = data['summaries'][key]['paired_saving_ci95']
    assert f'{low * 1000:+,.3f} to {high * 1000:+,.3f} ms' in readme_table
for field in ('parent_median', 'candidate_median'):
    assert f"{data['large_confirmation'][field] * 1000:,.3f} ms" in readme_table
low, high = data['large_confirmation']['paired_saving_ci95']
assert f'{low * 1000:+,.3f} to {high * 1000:+,.3f} ms' in readme_table
assert 'docs/docs/TS_PERFORMANCE.md#ordered-namespace-import-candidates-2026-10-09-utc' in readme
assert Path(archive['archive']).name in section and Path(archive['archive']).name in readme
print('All ordered namespace-import documentation tables, hashes, scope and README links verify.')
