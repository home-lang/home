import hashlib
import json
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
source = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip()
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=repo).decode()
assert subprocess.run(['git', 'diff', '--quiet', '1d50e79971dfd0beb244502505f3497f20b08b07', source, '--',
    'packages/ts_checker', 'packages/ts_driver', 'packages/ts_cli', 'packages/ts_program', 'packages/hir', 'bench/vs_tsgo'], cwd=repo).returncode == 0
command = ['env', 'HOME_RUN_MAX_MB=3840', 'HOME_RUN_LABEL=ts857-publication-main-build', 'perl', 'scripts/run-bounded.pl', '600',
    '/Users/chris/Code/Home/lang-bun-port/zig-out/toolchains/zig-aarch64-macos-0.17.0-dev.2163+89ff10d56/zig', 'build', 'home-tsc',
    '-Doptimize=ReleaseFast', '-Dhome-tsc-strip=true', '-Denable_jsc=false', '-j1', '--summary', 'all']
result = subprocess.run(command, cwd=repo, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
(root / 'publication-main-build.log').write_text(result.stdout)
digest = hashlib.sha256((repo / 'zig-out/bin/home-tsc').read_bytes()).hexdigest()
record = {'command': command, 'exit': result.returncode, 'source': source, 'native_sha256': digest,
    'source_clean_before_and_after': not subprocess.check_output(['git', 'status', '--porcelain'], cwd=repo).decode()}
(root / 'publication-main-build.json').write_text(json.dumps(record, indent=2) + '\n')
print(result.stdout[-2000:], flush=True)
assert result.returncode == 0 and record['source_clean_before_and_after']
assert digest == '68c6ed517f9125ae1b570ff2e585c5b368745389af828258f6621fe5e6e0311c'
print(json.dumps(record), flush=True)
