import hashlib
import json
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
source = '37b5225c2cf795e16bf3d20a436a606c0ae594e9'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip() == source
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=repo, text=True)
subprocess.run(['python3', str(root / 'logged.py'), 'restored-build'], check=True)
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip() == source
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=repo, text=True)
binary = root / 'home-tsc-restored-current-main'
assert binary.read_bytes() == (repo / 'zig-out/bin/home-tsc').read_bytes()
record = {'restored_source': source, 'binary_sha256': hashlib.sha256(binary.read_bytes()).hexdigest(),
          'source_clean_before_and_after': True,
          'compiler_inputs_equal_current_main': True,
          'rejected_candidate_in_production': False,
          'scope': 'Current-main build/restoration proof, not a new patch A/B or benchmark rank'}
(root / 'restored-current-main.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))
