"""Complete scoped gates, serialized through the shared bounded runner lock."""
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
for action in ('program', 'driver', 'cli', 'entrypoint', 'build', 'zod-parent', 'zod-candidate'):
    subprocess.run(['python3', str(root / 'logged.py'), action], check=True)
subprocess.run(['python3', str(root / 'harness.py')], check=True)
subprocess.run(['python3', str(root / 'verify_zod.py')], check=True)
