class Service496 {
  id = 496;
  label = "service-496";
  meta = { active: true, score: 496 };
}
class Alternate496 {
  id = 496;
  label = 496;
  meta = { active: true, score: 496 };
}
module.exports = new Service496();
module.exports = new Alternate496();
