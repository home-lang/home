class Service494 {
  id = 494;
  label = "service-494";
  meta = { active: true, score: 494 };
}
class Alternate494 {
  id = 494;
  label = 494;
  meta = { active: true, score: 494 };
}
module.exports = new Service494();
module.exports = new Alternate494();
