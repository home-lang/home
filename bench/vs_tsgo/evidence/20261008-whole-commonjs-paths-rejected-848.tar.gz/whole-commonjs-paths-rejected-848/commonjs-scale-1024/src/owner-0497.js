class Service497 {
  id = 497;
  label = "service-497";
  meta = { active: false, score: 497 };
}
class Alternate497 {
  id = 497;
  label = 497;
  meta = { active: false, score: 497 };
}
module.exports = new Service497();
module.exports = new Alternate497();
