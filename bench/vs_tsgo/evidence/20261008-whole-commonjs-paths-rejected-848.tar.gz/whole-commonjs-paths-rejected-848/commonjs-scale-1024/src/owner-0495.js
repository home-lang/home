class Service495 {
  id = 495;
  label = "service-495";
  meta = { active: false, score: 495 };
}
class Alternate495 {
  id = 495;
  label = 495;
  meta = { active: false, score: 495 };
}
module.exports = new Service495();
module.exports = new Alternate495();
