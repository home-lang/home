"""Remove only explicitly inventoried, rebuildable compiler outputs in this task's worktree."""
import json
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
cache = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang/.zig-cache/o')
identities = '''09c8e817a795b005056cfa02e15ee034 c4dfc56e70ceed80d0fbad7879a4d72a
965b449e4b386393b2d82ad894fafcd9 38ee9486fd75950465952ae824567076
bea5ca40cfa970019a7fc53d0fbfe737 65cc938fe331dd7bc6dc7b6f922a3e79
59652bf18fcfd6af5fc9288fb5c3415e 0e4a2cd547be6e709019f087205e8dd3
7bfe7be1b6f8212968140aca6f2f8243 c123d0274bc175e607e164e4f76cb17f
d1311c34283d0f1a272fae9bb6852afc ef2678fb7152424cc71c134fab56a8ba
7168172fe87afa1379b8d61db7522c35 89665911cca4265485c750d7e4d3c0be
227e8c316cc32f63afb2adb4d74ac529 c5e8808bcc38e62bf5a7e2f23758da1e
c600b429749db44b73eed99a694e3a3b 9d3f8908649c0099b7b3877511bd28eb
f1581250a1732809596d37d3119925ee 42b63a1459f5b09f1126c5a8a981e702
c9c52c90df2b983f9ace93b4f267e0ce 50296875d3d8e12dcf6e1f4cbfbf9615
f24ea6c4555f8f1c9e59c823dd334ff6 8e9db3c7c25da915cd84be21fb844d11
42b690d052dda5dbd6578306442f4428 63b59c1086cadff17727626fc715648e
cf2225c826d58c101b494b352106bf84 76fead1dd8a5738508fa78642f67b564
7ade3c24d9de602f86d50c93ce12728f 0957570fa240e220b0c883ca684bb8c1
8bb54b5b3a74ac450330b432a84c69bf 1a147484bebb879e3f2be20947fd68ca
7dcda35a5913dd86dac4200a0ed938b0 bb27acf71993424a7fa60c785df61a64
1726676ad0d3abed237209a241f69c64 b01f67f79a8f2287fcfaf8f31483e69b
140d32e32735667343a4eb733b3fd794 0ae3149cbad5094d31594a3faefab376
26e2f98f699934ebf90c1a88f0cce403 9cc40b27a783a7a73f6f0fab5e502268
80931853ef93fb7ce6e648c6e510e3fd 9d198518898f5c2d70c9455f491499c8
5fb0d00fd363e4eebd1fde1b9b9a8dc0 6727d60edb46f7af55075068fc33fcdc
fb7c7b83dde05a7f428d4ec046d5c9dd e20e9539a06f1939f82f57af6bcc9675
221cb6da5cdff58112902a2db8288f24 f2e647ec88bdfc8de80f702c764cee1e
7ad27566e396f32b76b64fa16b1c06d2 a19d84a3738c288965c50722d737da74'''.split()
assert len(identities) == len(set(identities))
allowed = {'root', 'root_zcu.o', 'home-tsc', 'home-tsc_zcu.o'}
files = []
directories = []
for identity in identities:
    path = cache / identity
    assert path.is_dir() and not path.is_symlink()
    children = list(path.iterdir())
    assert children and all(child.is_file() and not child.is_symlink() and child.name in allowed for child in children), path
    assert all(child.stat().st_mtime < 1791496888 for child in children), path
    files.extend(children)
    directories.append(path)
# Check current open files, not a stale machine-lock file.
opened = subprocess.run(['lsof', '-n', '-P', '-F', 'n', '+D', str(cache)], capture_output=True, text=True)
assert opened.returncode in (0, 1), opened.stderr
for path in files:
    assert 'n' + str(path) not in opened.stdout.splitlines(), path
manifest = {'scope': 'Explicit old native/unit-test cache outputs in this managed task worktree only; no source, raw logs/evidence, cached benchmark binaries or diagnostic profile objects removed',
    'recovery': 'Rebuild from archived source/toolchain pins; cache bytes are not trashed',
    'files': [{'path': str(path), 'bytes': path.stat().st_size} for path in files]}
manifest['bytes'] = sum(row['bytes'] for row in manifest['files'])
(root / 'old-cache-removal.json').write_text(json.dumps(manifest, indent=2) + '\n')
for path in files:
    path.unlink()
for path in directories:
    path.rmdir()
print(json.dumps({'removed_files': len(files), 'removed_directories': len(directories), 'rebuildable_bytes': manifest['bytes']}))
