import hashlib
import json
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
patch = subprocess.check_output(['git', 'diff', '--', 'packages/ts_checker/src/check.zig'], cwd=repo)
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip() == 'b513c85d39a00b9f0d7266ae8b46bc7de3cbc0cb'
assert not (root / 'first-draft.patch').exists()
(root / 'first-draft.patch').write_bytes(patch)
(root / 'initial-provenance.json').write_text(json.dumps({
    'source_parent': 'b513c85d39a00b9f0d7266ae8b46bc7de3cbc0cb',
    'first_draft_patch_sha256': hashlib.sha256(patch).hexdigest(),
    'parent_binary_sha256': hashlib.sha256((root / 'home-tsc-parent').read_bytes()).hexdigest(),
    'late_mapping': '/Users/chris/.cache/home-ts-merge-index.4GRFEn/late-mapping.json',
    'timing_acceptance': 'pending; no samples yet'}, indent=2) + '\n')
print('Preserved the initial complete source/test draft and exact accepted-parent provenance.')
