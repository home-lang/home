export interface Entity208<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity208<U>;
}

export type Result208<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap208<T> = T extends Result208<infer U, unknown> ? U : never;

export function transform208<T, U>(
  input: Entity208<T>,
  fn: (value: T) => U,
): Result208<Entity208<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker208: Result208<number> = { ok: true, value: 208 };
