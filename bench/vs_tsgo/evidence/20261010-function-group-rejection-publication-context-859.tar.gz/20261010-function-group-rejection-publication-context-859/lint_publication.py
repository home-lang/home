import json
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
for label, payload in [('repo-pickier', ['bunx', '--bun', 'pickier', '.']),
                       ('focused-pickier', ['bunx', '--bun', 'pickier', 'README.md', 'docs/docs/TS_PERFORMANCE.md'])]:
    command = ['env', 'HOME_RUN_MAX_MB=3840', 'HOME_RUN_LABEL=ts859-' + label,
               'perl', 'scripts/run-bounded.pl', '600', *payload]
    result = subprocess.run(command, cwd=repo, capture_output=True, text=True)
    output = result.stdout + result.stderr
    (root / (label + '.log')).write_text(output)
    (root / (label + '-command.json')).write_text(json.dumps({'command': command, 'exit': result.returncode}, indent=2) + '\n')
    print(label, 'exit', result.returncode, output[-2000:], flush=True)
    if label == 'focused-pickier':
        assert result.returncode == 0
