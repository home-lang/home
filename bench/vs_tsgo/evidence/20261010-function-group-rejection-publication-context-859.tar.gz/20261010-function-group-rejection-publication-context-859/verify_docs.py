import hashlib
import json
from pathlib import Path
import subprocess
import tarfile

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
data = json.loads((root / 'verified-pairs.json').read_text())
decision = json.loads((root / 'decision.json').read_text())
archive = json.loads((root / 'archive.json').read_text())
assert data['complete'] and data['rounds'] == 622 and data['admissions'] == 660
assert decision['status'] == 'rejected' and decision['source_commit'] == 'not-committed'
assert set(decision['independent_confirmed_regressions']) == {'recheck/type_predicates_large'}
markdown = (repo / 'docs/docs/TS_PERFORMANCE.md').read_text()
section = markdown.split('## Shared function statement groups 2026 10 10 UTC\n', 1)[1].split('\n## Ordered namespace-import candidates', 1)[0]
assert (root / 'tables.md').read_text().strip() in section
readme = (repo / 'README.md').read_text()
readme_section = readme.split('The shared function-statement candidate under ', 1)[1].split('These numbers were measured', 1)[0]
assert 'docs/docs/TS_PERFORMANCE.md#shared-function-statement-groups-2026-10-10-utc' in readme_section
for key in ('binaries',):
    for value in decision[key].values():
        assert value in section
for key in ('candidate_patch_sha256', 'protocol_sha256', 'parent_source'):
    assert decision[key] in section
assert archive['sha256'] in section and '1,892' in section
for term in ('622', '660', 'never pushed', 'unadmitted', 'not equivalence', '1/20', '12/20'):
    assert term.lower() in section.lower(), term
for key, label in [('confirmation/checkjs_jsdoc', 'Official checked JS, 30 pairs'),
                   ('confirmation/checkjs512', '512 families, 30 pairs'),
                   ('recheck/type_predicates_large', 'Large predicates, independent 30 pairs'),
                   ('interface-risk/class_hierarchy', 'Class hierarchy, 30 pairs'),
                   ('interface-risk/interface_composition', 'Interface composition, 30 pairs')]:
    values = data['summaries'][key]
    expected = [f"{values['parent_median']*1000:,.3f} ms", f"{values['candidate_median']*1000:,.3f} ms",
                f"{values['paired_saving_ci95'][0]*1000:+.3f}", f"{values['paired_saving_ci95'][1]*1000:+.3f}"]
    line = next(line for line in readme_section.splitlines() if line.startswith('| ' + label + ' |'))
    assert all(value in line for value in expected), (label, expected, line)
large = data['large_confirmation']
assert f"{large['parent_median']*1000:,.3f} ms" in readme_section
assert f"{large['candidate_median']*1000:,.3f} ms" in readme_section
path = Path(archive['archive'])
assert hashlib.sha256(path.read_bytes()).hexdigest() == archive['sha256']
prefix = path.name.removesuffix('.tar.gz')
with tarfile.open(path) as tar:
    sums = tar.extractfile(prefix + '/SHA256SUMS').read().decode().splitlines()
    assert len(sums) == archive['payload_checksums'] == 1892
    for line in sums:
        digest, name = line.split('  ', 1)
        assert hashlib.sha256(tar.extractfile(prefix + '/' + name).read()).hexdigest() == digest
assert subprocess.check_output(['git', 'diff', '--name-only', '--', 'packages'], cwd=repo).decode() == ''
subprocess.run(['git', 'diff', '--check'], cwd=repo, check=True)
assert hashlib.sha256((repo / 'zig-out/bin/home-tsc').read_bytes()).hexdigest() == decision['binaries']['parent']
(root / 'docs-verification.json').write_text(json.dumps({'all_complete_tables_exact': True,
    'readme_selected_rows_verified': True, 'archive_payloads_verified': len(sums),
    'source_unchanged_and_native_restored': True, 'claim_scope': 'Rejected Home A/B, not universal leadership'}, indent=2) + '\n')
print('Full tables, README rows/link,1,892 payloads, rejected scope and restored native verified.')
