import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
assert json.loads((root / 'focused-pickier-command.json').read_text())['exit'] == 0
assert json.loads((root / 'repo-pickier-command.json').read_text())['exit'] == 1
assert '11460 errors, 10613 warnings' in (root / 'repo-pickier.log').read_text()
verified = json.loads((root / 'docs-verification.json').read_text())
assert verified['archive_payloads_verified'] == 1892
names = ['repo-pickier.log', 'repo-pickier-command.json', 'focused-pickier.log',
         'focused-pickier-command.json', 'lint_publication.py', 'verify_docs.py',
         'docs-verification.json', 'restored-current-main.json', 'final-job-lifecycle.json',
         'archive.json', 'package_publication.py']
entries = {name: (root / name).read_bytes() for name in names}
checksums = ''.join(hashlib.sha256(data).hexdigest() + '  ' + name + '\n' for name, data in sorted(entries.items()))
entries['SHA256SUMS'] = checksums.encode()
prefix = '20261010-function-group-rejection-publication-context-859'
destination = repo / 'bench/vs_tsgo/evidence' / (prefix + '.tar.gz')
assert not destination.exists()
with destination.open('wb') as output:
    with gzip.GzipFile(filename='', mode='wb', fileobj=output, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as tar:
            for name, data in sorted(entries.items()):
                info = tarfile.TarInfo(prefix + '/' + name)
                info.size, info.mode, info.mtime = len(data), 0o644, 0
                tar.addfile(info, io.BytesIO(data))
with tarfile.open(destination) as tar:
    for name in names:
        assert tar.extractfile(prefix + '/' + name).read() == entries[name]
record = {'archive': str(destination), 'sha256': hashlib.sha256(destination.read_bytes()).hexdigest(),
          'payload_checksums': len(names), 'scope': 'Publication lint/verifier/restoration/lifecycle evidence; complete statistical raw data in separate1,892-payload archive'}
(root / 'publication-archive.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))
