interface Box<T>{value:T;}function local(){interface Box<U>{other:U;}const box:Box<boolean>={other:true};}
