type Wrapped<T=number>={item:T};
