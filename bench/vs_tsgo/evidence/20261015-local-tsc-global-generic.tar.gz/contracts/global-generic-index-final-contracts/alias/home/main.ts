export {};declare const wrapped:Wrapped;const good:number=wrapped.item;const wrong:string=wrapped.item;
