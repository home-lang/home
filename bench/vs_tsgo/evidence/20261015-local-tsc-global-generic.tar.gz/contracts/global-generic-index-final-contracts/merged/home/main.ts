export {};declare const box:Box<number>;const first:number=box.first;const second:number=box.second;const wrong:string=box.second;
