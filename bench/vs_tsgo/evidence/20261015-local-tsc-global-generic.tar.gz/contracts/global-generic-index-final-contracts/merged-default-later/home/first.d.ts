interface Box<T>{first:T;}
