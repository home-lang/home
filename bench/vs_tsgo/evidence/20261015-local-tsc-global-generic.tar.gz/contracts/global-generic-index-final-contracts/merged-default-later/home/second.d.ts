interface Box<T=string>{second:T;}
