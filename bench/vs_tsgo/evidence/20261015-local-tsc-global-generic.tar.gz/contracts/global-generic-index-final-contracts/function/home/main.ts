declare function from<T>(value:ArrayLike<T>):T[];declare const bytes:Uint8Array;const values=from(bytes);const good:number=values[0];const wrong:string=values[0];
