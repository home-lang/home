declare const bytes:Uint8Array;const values=Array.from(bytes,(v,k)=>v.toString(k));const good:string=values[0];const wrong:number=values[0];
