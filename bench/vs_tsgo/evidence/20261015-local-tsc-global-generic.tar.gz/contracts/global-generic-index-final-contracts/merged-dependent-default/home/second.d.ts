interface Box<T,U=T>{extra:U;}
