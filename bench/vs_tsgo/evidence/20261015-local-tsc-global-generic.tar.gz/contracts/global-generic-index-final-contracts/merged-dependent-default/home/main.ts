export {};declare const box:Box<string>;const first:string=box.first;const second:string=box.second;const extra:string=box.extra;const wrong:number=box.extra;
