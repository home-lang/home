interface Box<T,U>{first:T;second:U;}
