export {};interface Box{value:boolean;}declare const box:Box;const good:boolean=box.value;const wrong:string=box.value;
