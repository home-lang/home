declare const input:ArrayLike<number>;const values=Array.from(input);const good:number=values[0];const wrong:string=values[0];
