declare const values:Record<string,string>|undefined;const entries=Object.entries(values??{});const good:string=entries[0][0];
