export {};declare const box:Box;const exact:"default"=box.value;const wrong:number=box.value;type Invalid=Box<number>;
