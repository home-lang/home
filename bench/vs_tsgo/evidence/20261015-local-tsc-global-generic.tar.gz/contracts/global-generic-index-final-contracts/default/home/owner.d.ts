interface Box<T extends string="default">{value:T;}
