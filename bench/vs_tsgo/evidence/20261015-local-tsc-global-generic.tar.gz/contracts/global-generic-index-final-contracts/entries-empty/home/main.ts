const entries=Object.entries({});const good:string=entries[0][0];
