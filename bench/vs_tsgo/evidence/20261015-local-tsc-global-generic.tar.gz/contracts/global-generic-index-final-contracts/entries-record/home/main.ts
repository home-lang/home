declare const values:Record<string,string>;const entries=Object.entries(values);const good:string=entries[0][1];const wrong:number=entries[0][1];
