export {};declare const outer:Box;const exact:string=outer.value;function f(){const box:Box={value:true};const good:boolean=box.value;const wrong:string=box.value;interface Box{value:boolean;}}
