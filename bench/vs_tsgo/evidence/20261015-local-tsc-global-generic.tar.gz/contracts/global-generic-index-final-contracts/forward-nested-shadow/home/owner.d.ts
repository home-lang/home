interface Box<T=string>{value:T;}
