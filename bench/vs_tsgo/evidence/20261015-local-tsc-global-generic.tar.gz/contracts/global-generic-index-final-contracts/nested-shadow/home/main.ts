export {};function f(){interface Box{value:boolean;}const box={} as Box;const good:boolean=box.value;const wrong:string=box.value;}
