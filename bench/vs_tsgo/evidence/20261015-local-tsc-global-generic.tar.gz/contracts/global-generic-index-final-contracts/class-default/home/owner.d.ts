declare class Box<T=string>{value:T;}
