export {};declare const box:Box;const good:string=box.value;const wrong:number=box.value;
