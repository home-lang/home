const values=Array.from([1,2]);const good:number=values[0];const wrong:string=values[0];
