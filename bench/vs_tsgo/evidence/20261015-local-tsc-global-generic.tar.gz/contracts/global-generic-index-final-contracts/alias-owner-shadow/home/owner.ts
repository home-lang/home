type Box<T>={value:T};function local(){type Box<U>={other:U};const box:Box<boolean>={other:true};}
