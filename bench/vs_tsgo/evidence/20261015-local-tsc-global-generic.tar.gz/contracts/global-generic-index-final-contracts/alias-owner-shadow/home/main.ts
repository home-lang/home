export {};declare const box:Box<string>;const good:string=box.value;const wrong:number=box.value;
