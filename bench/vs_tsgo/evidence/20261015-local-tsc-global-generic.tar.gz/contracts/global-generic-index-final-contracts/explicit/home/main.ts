declare const bytes:Uint8Array;const values=Array.from<number>(bytes);const good:number=values[0];const wrong:string=values[0];
