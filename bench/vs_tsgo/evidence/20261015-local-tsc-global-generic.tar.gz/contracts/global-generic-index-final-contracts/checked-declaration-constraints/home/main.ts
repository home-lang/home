export {};const good:number=invalid.value;const wrong:string=invalid.value;
