interface Box<T extends string>{value:T;}declare const invalid:Box<number>;
