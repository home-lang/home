interface Pair<T,U=T>{first:T;second:U;}
