export {};declare const pair:Pair<string>;const good:string=pair.second;const wrong:number=pair.second;
