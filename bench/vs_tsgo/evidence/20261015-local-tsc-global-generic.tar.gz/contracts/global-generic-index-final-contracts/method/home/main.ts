interface Maker{from<T>(value:ArrayLike<T>):T[];}declare const maker:Maker;declare const bytes:Uint8Array;const values=maker.from(bytes);const good:number=values[0];const wrong:string=values[0];
