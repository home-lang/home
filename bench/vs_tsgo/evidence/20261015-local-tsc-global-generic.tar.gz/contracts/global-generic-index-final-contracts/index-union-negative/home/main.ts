declare function take(value:Record<string,string>|ArrayLike<string>):void;const bad={flag:true};take(bad);
