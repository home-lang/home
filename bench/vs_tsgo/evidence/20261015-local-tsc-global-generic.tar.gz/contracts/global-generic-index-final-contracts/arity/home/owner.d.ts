interface Box<T>{value:T;}
