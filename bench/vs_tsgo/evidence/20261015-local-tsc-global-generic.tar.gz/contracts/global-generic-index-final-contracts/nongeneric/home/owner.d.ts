interface Plain{value:number;}
