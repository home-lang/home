export {};declare const box:Box;const first:string=box.first;const second:string=box.second;const wrong:number=box.second;
