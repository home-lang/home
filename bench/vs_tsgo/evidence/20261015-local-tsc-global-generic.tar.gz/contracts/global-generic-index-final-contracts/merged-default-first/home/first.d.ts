interface Box<T=string>{first:T;}
