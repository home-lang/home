    fn memberAccessReceiverIsRequireAssignmentBinding(self: *Checker, obj: NodeId) bool {
        if (self.hir.kindOf(obj) != .identifier) return false;
        const name = hir_mod.identifierOf(self.hir, obj).name;
        const root = self.rootBlockFor(obj);
        if (root == hir_mod.none_node_id or self.hir.kindOf(root) != .block_stmt) return false;
        const has_sections = self.sourceHasVirtualFilenameSections();
        const obj_section = if (has_sections) self.virtualSectionStartForNode(obj) else 0;
        for (hir_mod.blockStmts(self.hir, root)) |stmt| {
            if (has_sections and self.virtualSectionStartForNode(stmt) != obj_section) continue;
            if (self.hir.kindOf(stmt) == .import_decl) {
                if (!self.importDeclIsRequireAssignment(stmt)) continue;
                const imp = hir_mod.importOf(self.hir, stmt);
                if (imp.default_binding == hir_mod.none_node_id or self.hir.kindOf(imp.default_binding) != .identifier) continue;
                if (hir_mod.identifierOf(self.hir, imp.default_binding).name == name) return true;
                continue;
            }
            const decl = self.unwrapExportDecl(stmt);
            const kind = self.hir.kindOf(decl);
            if (kind != .var_decl and kind != .let_decl and kind != .const_decl) continue;
            const variable = hir_mod.varDeclOf(self.hir, decl);
            if (variable.name == hir_mod.none_node_id or self.hir.kindOf(variable.name) != .identifier) continue;
            if (hir_mod.identifierOf(self.hir, variable.name).name != name) continue;
            if (self.requireCallSpecifier(variable.init) != null) return true;
        }
        return false;
    }

