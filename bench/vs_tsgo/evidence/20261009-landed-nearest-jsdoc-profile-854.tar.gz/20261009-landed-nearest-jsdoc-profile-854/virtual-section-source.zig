    fn virtualSectionStartForNode(self: *Checker, node: NodeId) usize {
        const src = self.source orelse return 0;
        if (!self.sourceHasVirtualFilenameSections()) return 0;
        if (self.virtual_section_start_cache.get(node)) |cached| return cached;
        const span = self.hir.spanOf(node);
        const limit = @min(span.start, src.len);
        var last: usize = 0;
        var line_start: usize = 0;
        while (line_start <= limit and line_start < src.len) {
            const line_end = std.mem.indexOfScalarPos(u8, src, line_start, '\n') orelse src.len;
            const line = src[line_start..line_end];
            if (std.mem.indexOf(u8, line, "@filename:") != null or
                std.mem.indexOf(u8, line, "@Filename:") != null)
            {
                last = line_start;
            }
            if (line_end >= limit or line_end == src.len) break;
            line_start = line_end + 1;
        }
        self.virtual_section_start_cache.put(self.gpa, node, last) catch {};
        return last;
    }

