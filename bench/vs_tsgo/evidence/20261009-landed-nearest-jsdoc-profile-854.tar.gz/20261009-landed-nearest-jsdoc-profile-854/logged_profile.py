import json
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
command = ['env', 'HOME_RUN_MAX_MB=3840', 'HOME_RUN_LABEL=ts854-landed-nearest-diagnostic-profile',
           'perl', 'scripts/run-bounded.pl', '600', 'python3', str(root / 'profile.py')]
result = subprocess.run(command, cwd=repo, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
(root / 'profile.log').write_text(result.stdout)
(root / 'profile-command.json').write_text(json.dumps({'command': command, 'exit': result.returncode}, indent=2) + '\n')
print(result.stdout[-4000:], flush=True)
raise SystemExit(result.returncode)
