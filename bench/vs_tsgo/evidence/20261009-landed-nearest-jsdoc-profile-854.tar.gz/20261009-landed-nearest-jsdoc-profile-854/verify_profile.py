import hashlib
import json
from pathlib import Path
import re
import subprocess

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
provenance = json.loads((root / 'provenance.json').read_text())
assert len(provenance['admissions']) == 62 and all(row['passed'] for row in provenance['admissions'])
assert not provenance['diagnostic_image_used_for_timing']
assert (root / 'original-text.bin').read_bytes() == (root / 'renamed-text.bin').read_bytes()
assert hashlib.sha256((root / 'original-text.bin').read_bytes()).hexdigest() == provenance['text_sha256']
record = json.loads((root / 'checkjs8192-profile.json').read_text())
assert record['compiler_exit'] == 0 and not record['stdout'] and not record['stderr']
assert record['input_hash_before'] == record['input_hash_after']
assert [row['label'] for row in record['samples']] == ['early', 'middle']
samples = {}
for row in record['samples']:
    assert row['sample_exit'] == 0
    data = Path(row['path']).read_text()
    main = re.search(r'^\s+(\d+) Thread_\d+\s+DispatchQueue_1:', data, re.MULTILINE)
    assert main
    top = data.split('Sort by top of stack, same collapsed (when >= 5):', 1)[1].split('Binary Images:', 1)[0]
    leaves = {}
    for line in top.splitlines():
        match = re.match(r'\s+(.+?)\s+\(in .+?\)\s+(\d+)\s*$', line)
        if match:
            leaves[match.group(1)] = int(match.group(2))
    samples[row['label']] = {'main_thread_observations': int(main.group(1)), 'leaf_observations_at_least_five': leaves}
source = subprocess.check_output(['git', 'show', provenance['source'] + ':packages/ts_checker/src/check.zig'], cwd=repo)
for name, begin, end in [('virtual-section-source.zig', '    fn virtualSectionStartForNode(', '    fn virtualSectionStartForPos('),
    ('require-binding-source.zig', '    fn memberAccessReceiverIsRequireAssignmentBinding(', '    fn ')]:
    start = source.index(begin.encode())
    stop = source.index(end.encode(), start + len(begin))
    (root / name).write_bytes(source[start:stop])
binary = root / 'home-tsc-profile'
for name, start, stop in [('virtual-section-loop', 0x100199aec, 0x10019a100),
    ('require-binding-loop', 0x10071f5e4, 0x10071f800)]:
    command = ['/Users/chris/.local/share/pantry/global/bin/llvm-objdump', '--disassemble',
        '--start-address=' + hex(start), '--stop-address=' + hex(stop), str(binary)]
    result = subprocess.run(command, capture_output=True, text=True, check=True)
    (root / (name + '-assembly.txt')).write_text(result.stdout)
    (root / (name + '-command.json')).write_text(json.dumps(command, indent=2) + '\n')
report = {'source': provenance['source'], 'native_sha256': provenance['binary_sha256'],
    'diagnostic_sha256': provenance['diagnostic_sha256'], 'text_sha256': provenance['text_sha256'],
    'admissions': 62, 'samples': samples,
    'interpretation': 'Separate one-second exploratory leaf counts, not whole-run CPU percentages or causal speed proof',
    'source_candidates': ['virtualSectionStartForNode', 'memberAccessReceiverIsRequireAssignmentBinding'],
    'virtual_section_symbol_start': '0x100199aec', 'virtual_section_sampled_offsets': [40, 52, 1424, 1432],
    'require_binding_symbol_start': '0x10071f5e4', 'require_binding_sampled_offsets': [288, 376],
    'timing_samples_from_diagnostic_image': 0}
(root / 'verified-profile.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
