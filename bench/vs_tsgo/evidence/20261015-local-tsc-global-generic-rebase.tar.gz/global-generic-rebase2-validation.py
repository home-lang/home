from pathlib import Path
import subprocess,json,hashlib,sys
r=Path.cwd();o=r/'.home-cache/owner-transfer';z=r/'.home-cache/toolchains/zig-aarch64-macos-0.17.0-dev.2163+89ff10d56/zig';old=o/'global-generic-index-final-release/bin/home-tsc';new=o/'global-generic-rebase2-release/bin/home-tsc';common=['-Denable_jsc=false','-j1','--summary','all','--cache-dir','.home-cache/generic-return-zig-cache'];report={'origin':subprocess.check_output(['git','rev-parse','origin/main'],text=True).strip(),'incoming_paths':subprocess.check_output(['git','diff','--name-only','1c34849ff3bc45b25d835404b626f199814d5c12..origin/main'],text=True).splitlines(),'runs':[]};assert all(p.startswith('packages/ffi/') for p in report['incoming_paths'])
for name,args in [('checker',['test','-Dfilter=ts_checker']),('driver',['test','-Dfilter=ts_driver']),('program',['test','-Dfilter=ts_program']),('build',['home-tsc','-Doptimize=ReleaseFast','-Dhome-tsc-strip=true','--prefix',str(new.parent.parent)])]:
 with (o/('global-generic-rebase2-unit-'+name+'.log')).open('w') as f:x=subprocess.run([str(z),'build',*args,*common],stdout=f,stderr=subprocess.STDOUT)
 report['runs'].append({'name':name,'exit':x.returncode});print(name+' exit '+str(x.returncode),flush=True)
 if x.returncode:sys.exit(x.returncode)
report['binary_sha256']=hashlib.sha256(new.read_bytes()).hexdigest();assert report['binary_sha256']==hashlib.sha256(old.read_bytes()).hexdigest();report['prior_fresh_table_controls_still_valid']=True;(o/'global-generic-rebase2-validation.json').write_text(json.dumps(report,indent=2)+'\n')
