from pathlib import Path
import json,subprocess,hashlib,sys
r=Path.cwd();o=r/'.home-cache/owner-transfer';z=r/'.home-cache/toolchains/zig-aarch64-macos-0.17.0-dev.2163+89ff10d56/zig';common=['-Denable_jsc=false','-j1','--summary','all','--cache-dir','.home-cache/generic-return-zig-cache'];base='0eeb52db173e462e53955a86d06bc5273203c32f';old=o/'global-generic-index-final-release/bin/home-tsc';new=o/'global-generic-rebase-release/bin/home-tsc'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
incoming=subprocess.check_output(['git','diff','--name-only',base+'..origin/main'],text=True).splitlines();freeze=json.loads((o/'global-generic-source-freeze.json').read_text());changed=[str(Path(n).relative_to(r)) for n,h in freeze.items() if digest(Path(n))!=h];assert set(changed)<=set(incoming);assert not any(p.startswith(('packages/ts_','scripts/tests/test-ts-')) for p in incoming)
report={'base':base,'origin':subprocess.check_output(['git','rev-parse','origin/main'],text=True).strip(),'incoming_paths':incoming,'frozen_input_count':len(freeze),'changed_frozen_inputs':changed,'runs':[]}
steps=[('checker',[z,'build','test','-Dfilter=ts_checker',*common]),('driver',[z,'build','test','-Dfilter=ts_driver',*common]),('program',[z,'build','test','-Dfilter=ts_program',*common]),('build',[z,'build','home-tsc','-Doptimize=ReleaseFast','-Dhome-tsc-strip=true',*common,'--prefix',new.parent.parent])]
for name,args in steps:
 print(name+' started',flush=True)
 with(o/('global-generic-rebase-unit-'+name+'.log')).open('w') as f:x=subprocess.run([str(a) for a in args],stdout=f,stderr=subprocess.STDOUT)
 report['runs'].append({'name':name,'exit':x.returncode});(o/'global-generic-rebase-validation.json').write_text(json.dumps(report,indent=2)+'\n');print(name+' exit '+str(x.returncode),flush=True)
 if x.returncode:sys.exit(x.returncode)
report['pre_rebase_binary_sha256']=digest(old);report['post_rebase_binary_sha256']=digest(new);assert digest(old)==digest(new)
s=(r/'.home-cache/table-replacement/replay-global-generic-index-final.py').read_text().replace('global-generic-index-final-release','global-generic-rebase-release').replace('global-generic-index-final','global-generic-rebase-verified-final')
p=r/'.home-cache/table-replacement/replay-global-generic-rebase-verified-final.py';p.write_text(s)
with(o/'global-generic-rebase-table.log').open('w') as f:x=subprocess.run(['python3',str(p)],stdout=f,stderr=subprocess.STDOUT)
report['runs'].append({'name':'table','exit':x.returncode});(o/'global-generic-rebase-validation.json').write_text(json.dumps(report,indent=2)+'\n');print('table exit '+str(x.returncode),flush=True);sys.exit(x.returncode)
