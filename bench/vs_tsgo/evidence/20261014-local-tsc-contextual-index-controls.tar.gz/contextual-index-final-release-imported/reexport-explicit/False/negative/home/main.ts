import { create } from "./index";
import type {Driver,Table} from "./types";
declare const driver: Driver<{id:number}>;
const table = create<{id:number}>({driver,index:"products",page:1,ranking:{rules:["ok"]}});
const check: Table<{id:number}> = table;
const id: number = table.search().id;
create({driver,index:"products",page:"bad"});
