import type {Options,Table} from "./types";
export declare function create<T>(options:Options<T>):Table<T>;
