export interface Request { index: string; page?: number; }
export interface Driver<T> { value: T; search: (request: Request) => T; }
export interface Options<T> extends Omit<Request, "index"> { index: string; driver: Driver<T>; ranking?: {rules: readonly string[]}; }
export interface Table<T> { readonly driver: Driver<T>; search: (request?: Omit<Request,"index">) => T; }
