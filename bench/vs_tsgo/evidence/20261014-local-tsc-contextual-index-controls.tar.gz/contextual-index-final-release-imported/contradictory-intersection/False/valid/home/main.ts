import { create } from "./factory";
import type {Driver,Table} from "./types";
declare const driver: Driver<{id:number}>;
const table = create({driver,index:"products",page:1,ranking:{rules:["ok"]}});
const check: Table<{id:number}> = table;
const id: number = table.search().id;
