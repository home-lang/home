export type Bad = { ["" + ""](): void; };
