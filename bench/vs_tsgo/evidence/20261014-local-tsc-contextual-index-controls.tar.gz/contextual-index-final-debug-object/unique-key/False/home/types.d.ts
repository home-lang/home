declare const key: unique symbol; interface Good { [key](): void }
