export interface Bad { ["" + ""](): void; }
