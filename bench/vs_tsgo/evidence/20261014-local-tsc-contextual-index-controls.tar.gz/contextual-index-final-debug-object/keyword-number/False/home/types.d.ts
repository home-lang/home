export interface I { [number: string]: number; }
export type A = { readonly [number: number]: string; };
export declare class C { [number: string]: boolean; }
