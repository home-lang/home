export interface I { [type: string]: number; }
export type A = { readonly [type: number]: string; };
export declare class C { [type: string]: boolean; }
