export interface I { [get: string]: number; }
export type A = { readonly [get: number]: string; };
export declare class C { [get: string]: boolean; }
