export interface I { [string: string]: number; }
export type A = { readonly [string: number]: string; };
export declare class C { [string: string]: boolean; }
