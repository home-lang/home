export interface I { [readonly: string]: number; }
export type A = { readonly [readonly: number]: string; };
export declare class C { [readonly: string]: boolean; }
