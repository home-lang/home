import type {I} from "./types";
declare const value:I;
const good:number=value.hello;
const wrong:string=value.hello;
