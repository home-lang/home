export interface I { [async: string]: number; }
export type A = { readonly [async: number]: string; };
export declare class C { [async: string]: boolean; }
