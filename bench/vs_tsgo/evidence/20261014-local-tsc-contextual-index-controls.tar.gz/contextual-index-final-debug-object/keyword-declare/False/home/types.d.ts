export interface I { [declare: string]: number; }
export type A = { readonly [declare: number]: string; };
export declare class C { [declare: string]: boolean; }
