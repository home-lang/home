declare module "node:ffi" { interface Signature { return?: string; arguments?: readonly string[]; } interface Definitions { [symbol: string]: Signature; } }
