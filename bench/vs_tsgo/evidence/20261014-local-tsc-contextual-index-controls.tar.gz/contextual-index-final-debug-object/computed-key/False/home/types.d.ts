declare const key: symbol; interface Bad { [key](): void }
