export interface I { [symbol: string]: number; }
export type A = { readonly [symbol: number]: string; };
export declare class C { [symbol: string]: boolean; }
