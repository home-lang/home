| Workload | tsc 6.0.3 median | native TS 7.0.2 median | Home median | Rust tsc-rs 0.1.0 median | Bun canary median | Home vs fastest competitor |
|---|---:|---:|---:|---:|---:|---:|
| `checkjs_jsdoc` | 198.5 ms | 22.9 ms | 26.8 ms | 22.3 ms | 13.8 ms | 1.95× slower |
| `class_hierarchy` | 181.3 ms | 21.0 ms | 22.8 ms | 17.5 ms | 13.8 ms | 1.66× slower |
| `commonjs_graph` | 147.6 ms | 17.4 ms | 24.1 ms | 14.5 ms | 12.2 ms | 1.98× slower |
| `control_flow` | 188.5 ms | 27.2 ms | 25.6 ms | 24.0 ms | 16.3 ms | 1.57× slower |
| `deep_types` | 130.9 ms | 21.4 ms | 21.3 ms | 14.1 ms | 13.4 ms | 1.58× slower |
| `destructuring` | 133.7 ms | 16.4 ms | 14.6 ms | 14.3 ms | 10.9 ms | 1.33× slower |
| `generic_calls` | 177.5 ms | 22.7 ms | 23.0 ms | 19.0 ms | 14.6 ms | 1.58× slower |
| `import_graph` | 129.1 ms | 14.7 ms | 20.4 ms | 10.9 ms | 14.6 ms | 1.87× slower |
| `interface_composition` | 197.5 ms | 30.9 ms | 33.3 ms | 23.3 ms | 17.7 ms | 1.88× slower |
| `many_files` | 194.5 ms | 21.5 ms | 21.4 ms | 15.5 ms | 12.6 ms | 1.70× slower |
| `null_safe_access` | 187.1 ms | 26.0 ms | 32.0 ms | 22.3 ms | 16.3 ms | 1.96× slower |
| `overload_resolution` | 196.5 ms | 31.9 ms | 23.4 ms | 25.9 ms | 20.0 ms | 1.17× slower |
| `recursive_generics` | 150.7 ms | 39.1 ms | 14.2 ms | 31.9 ms | 9.7 ms | 1.47× slower |
| `reexport_graph` | 95.7 ms | 10.3 ms | 12.1 ms | 8.7 ms | 8.7 ms | 1.40× slower |
| `startup` | 62.7 ms | 7.2 ms | 2.8 ms | 5.6 ms | 6.1 ms | **2.02× faster** |
| `structural_objects` | 183.5 ms | 26.5 ms | 22.4 ms | 22.2 ms | 16.8 ms | 1.33× slower |
| `tsx_components` | 160.4 ms | 15.9 ms | 20.0 ms | 14.1 ms | 10.5 ms | 1.90× slower |
| `type_predicates` | 233.4 ms | 40.1 ms | 32.8 ms | 34.0 ms | 23.4 ms | 1.40× slower |
| `type_predicates_large` | 981.7 ms | 299.3 ms | 238.4 ms | 263.4 ms | 156.7 ms | 1.52× slower |
| `variadic_tuples` | 243.1 ms | 43.6 ms | 30.6 ms | 32.9 ms | 19.1 ms | 1.60× slower |
