| Workload | tsc 6.0.3 median | native TS 7.0.2 median | Home median | Rust tsc-rs 0.1.0 median | Bun canary median | Home vs fastest competitor |
|---|---:|---:|---:|---:|---:|---:|
| Startup (one small file) | 62.7 ms | 7.2 ms | 2.8 ms | 5.6 ms | 6.1 ms | **2.02× faster** |
| 256 independent files | 194.5 ms | 21.5 ms | 21.4 ms | 15.5 ms | 12.6 ms | 1.70× slower |
| 128-module import chain | 129.1 ms | 14.7 ms | 20.4 ms | 10.9 ms | 14.6 ms | 1.87× slower |
| 64 modules through 8 barrel re-exports | 95.7 ms | 10.3 ms | 12.1 ms | 8.7 ms | 8.7 ms | 1.40× slower |
| Deep conditional / mapped / template types | 130.9 ms | 21.4 ms | 21.3 ms | 14.1 ms | 13.4 ms | 1.58× slower |
| Recursive generics | 150.7 ms | 39.1 ms | 14.2 ms | 31.9 ms | 9.7 ms | 1.47× slower |
| Checked JavaScript with JSDoc | 198.5 ms | 22.9 ms | 26.8 ms | 22.3 ms | 13.8 ms | 1.95× slower |
| Control-flow narrowing (256 unions) | 188.5 ms | 27.2 ms | 25.6 ms | 24.0 ms | 16.3 ms | 1.57× slower |
| 256 type-predicate families | 233.4 ms | 40.1 ms | 32.8 ms | 34.0 ms | 23.4 ms | 1.40× slower |
| 2,048 type-predicate families | 981.7 ms | 299.3 ms | 238.4 ms | 263.4 ms | 156.7 ms | 1.52× slower |
