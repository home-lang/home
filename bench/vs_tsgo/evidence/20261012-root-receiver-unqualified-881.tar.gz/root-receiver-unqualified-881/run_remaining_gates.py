import json
import os
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts863-qualification-docs/lang')
prior = json.loads((root / 'second-gates.json').read_bytes())
assert prior['records'] == [{'target': 'checker', 'exit': 0}]
assert 'All 4573 tests passed.' in (root / 'checker-second.log').read_text()
records = list(prior['records'])
for target in ['program', 'driver', 'cli', 'entrypoint']:
    command = ['perl', 'scripts/run-bounded.pl', '600', sys.executable, str(root / 'run_one_remaining_gate.py'), target]
    environment = dict(os.environ, HOME_RUN_MAX_MB='3840', HOME_RUN_LABEL='ts881-full-' + target)
    print('Starting unchanged full ' + target + ' guard', flush=True)
    with (root / (target + '-guard.log')).open('x') as stream:
        result = subprocess.run(command, cwd=repo, env=environment, stdout=stream, stderr=subprocess.STDOUT)
    records.append({'target': target, 'exit': result.returncode})
    with (root / 'complete-gates.json').open('w') as stream:
        json.dump({'source_parent': prior['source_parent'], 'patch_sha256': prior['patch_sha256'],
                   'records': records, 'completed_checker_repeated': False, 'timing_samples': 0}, stream, indent=2)
    print(json.dumps(records[-1]), flush=True)
    print((root / (target + '-guard.log')).read_text()[-950:], flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)
