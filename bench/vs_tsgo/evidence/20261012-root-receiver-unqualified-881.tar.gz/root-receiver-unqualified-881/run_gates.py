import hashlib
import json
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts863-qualification-docs/lang')
patch = subprocess.check_output(['git', 'diff', '--', 'packages/ts_checker/src/check.zig'], cwd=repo)
expected = hashlib.sha256(patch).hexdigest()
with (root / 'second-candidate.patch').open('xb') as stream:
    stream.write(patch)
records = []
for target in ['checker', 'program', 'driver', 'cli', 'entrypoint']:
    print('Starting complete ' + target, flush=True)
    with (root / (target + '-second.log')).open('x') as stream:
        result = subprocess.run([sys.executable, '/Users/chris/.cache/home-ts-843.3BeUMH/module_tests.py', target],
                                cwd=repo, stdout=stream, stderr=subprocess.STDOUT)
    record = {'target': target, 'exit': result.returncode}
    records.append(record)
    print(json.dumps(record), flush=True)
    print((root / (target + '-second.log')).read_text()[-700:], flush=True)
    assert hashlib.sha256(subprocess.check_output(['git', 'diff', '--', 'packages/ts_checker/src/check.zig'], cwd=repo)).hexdigest() == expected
    with (root / 'second-gates.json').open('w') as stream:
        json.dump({'source_parent': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip(),
                   'patch_sha256': expected, 'records': records, 'timing_samples': 0}, stream, indent=2)
    if result.returncode != 0:
        raise SystemExit(result.returncode)
