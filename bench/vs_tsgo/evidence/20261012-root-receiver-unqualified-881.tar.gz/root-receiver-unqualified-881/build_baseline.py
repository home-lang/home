import hashlib
import json
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts863-qualification-docs/lang')
parent = 'e00470f05c5918404ffdb6b2bac8933c38a15cd7'
retained = Path('/Users/chris/.cache/home-ts-owned-alias-inflight-interfaces.jHEAoG/candidate-home-tsc')
installed = repo / 'zig-out/bin/home-tsc'
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def git(*args):
    return subprocess.check_output(['git', *args], cwd=repo)
assert git('rev-parse', 'HEAD').decode().strip() == parent
assert not git('status', '--porcelain')
before = {str(path): digest(path) for path in [retained, installed]}
prefix = root / 'baseline'
assert not prefix.exists()
command = ['/Users/chris/Code/Home/lang-bun-port/zig-out/toolchains/zig-aarch64-macos-0.17.0-dev.2163+89ff10d56/zig',
           'build', 'home-tsc', '-Doptimize=ReleaseFast', '-Dhome-tsc-strip=true', '-Denable_jsc=false',
           '-j1', '--summary', 'all', '--prefix', str(prefix)]
with (root / 'baseline-build.log').open('x') as stream:
    result = subprocess.run(command, cwd=repo, stdout=stream, stderr=subprocess.STDOUT)
record = {'issue': 881, 'source_parent': parent, 'command': command, 'exit': result.returncode,
          'previous_images_before': before, 'previous_images_after': {str(path): digest(path) for path in [retained, installed]},
          'timing_samples': 0, 'candidate_implemented': False}
if result.returncode == 0:
    record.update(native=str(prefix / 'bin/home-tsc'), native_sha256=digest(prefix / 'bin/home-tsc'))
with (root / 'baseline-build.json').open('x') as stream:
    json.dump(record, stream, indent=2)
assert record['previous_images_before'] == record['previous_images_after']
assert git('rev-parse', 'HEAD').decode().strip() == parent and not git('status', '--porcelain')
print(json.dumps(record), flush=True)
raise SystemExit(result.returncode)
