Unqualified candidate, never adopted. Exact source patch and both frozen images retained.
All full source and complete CLI/protocol/scaled gates passed; unchanged Zod235 identities remain unadmitted.
All22 screens and21 independent phases complete,850 independently verified pairs.
Final8192 phase guard124 retains27 complete pairs plus one empty raw file; not a completed confirmation.
Official128-family independent confidence interval spanszero, so primary gain is not established.
Every original observation, warmup, failure, interrupted file and source revision is retained.
No repeats, filtering, layout tuning, cap changes, body skips or relaxed diagnostic expectations.
Metadata paths and all raw bytes are verbatim; no credential environment is captured.
