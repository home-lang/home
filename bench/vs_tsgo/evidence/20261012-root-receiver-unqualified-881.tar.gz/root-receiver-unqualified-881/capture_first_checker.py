import hashlib
import json
from pathlib import Path
import shutil
import subprocess

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts863-qualification-docs/lang')
original = repo / '.zig-cache/o/97be2ed43c47b8d3a39414c1b0468400/root'
retained = root / 'first-checker-tests'
assert not retained.exists()
shutil.copy2(original, retained)
patch = (root / 'first-candidate-frozen.patch').read_bytes()
with (root / 'first-candidate.patch').open('xb') as stream:
    stream.write(patch)
with (root / 'first-checker-recapture.log').open('x') as stream:
    result = subprocess.run([str(retained)], cwd=repo, stdout=stream, stderr=subprocess.STDOUT)
record = {'original_session': 13646, 'original_exit': 1, 'original_passed': 4572, 'original_failed': 1,
          'original_skipped': 0, 'original_peak_tree_mb': 3306, 'original_host_low_water_percent': 30,
          'same_binary_reexecution_for_complete_failure_log': True, 'exit': result.returncode,
          'binary_sha256': hashlib.sha256(retained.read_bytes()).hexdigest(),
          'source_patch_sha256': hashlib.sha256(patch).hexdigest(), 'benchmark_timing_samples': 0}
with (root / 'first-checker-outcome.json').open('x') as stream:
    json.dump(record, stream, indent=2)
print(json.dumps(record), flush=True)
for line in (root / 'first-checker-recapture.log').read_text().splitlines():
    if 'FAIL' in line or 'expected' in line or 'passed;' in line:
        print(line, flush=True)
raise SystemExit(result.returncode)
