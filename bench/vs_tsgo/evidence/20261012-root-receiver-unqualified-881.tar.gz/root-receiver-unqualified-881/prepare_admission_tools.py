import hashlib
import json
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
reference = Path('/Users/chris/.cache/home-ts-owned-alias-inflight-interfaces.jHEAoG')
sources = {}
for name in ['admit_extended.py', 'admit_protocol.py']:
    content = (reference / name).read_text()
    if name == 'admit_protocol.py':
        content = content.replace('/Users/chris/.cache/home-ts-main-flow-proof-integration.dYlSre/baseline-home-tsc', str(root / 'baseline/bin/home-tsc'))
        content = content.replace('180b0d83becb3a0fa3843c625f213f971578498f6af3fa50fd6d8109cdba21c3', 'b251b7273cd1e659946d073fa905ec5c8c690686c26c63a6fb1b3bf13f9d71bb')
    target = root / name
    assert not target.exists()
    patch = '*** Begin Patch\n*** Add File: ' + str(target) + '\n' + ''.join('+' + line + '\n' for line in content.splitlines()) + '*** End Patch\n'
    subprocess.run(['apply_patch'], input=patch, text=True, check=True, capture_output=True)
    sources[name] = {'reference': str(reference / name), 'current_sha256': hashlib.sha256(target.read_bytes()).hexdigest()}
with (root / 'admission-tools.json').open('x') as stream:
    json.dump({'scripts': sources, 'original_expectations_unchanged': True}, stream, indent=2)
print('Prepared original complete98-project/180-protocol admission with exact new parent; no expectation changes')
