"""Continue build/admission only after complete real source-gate success."""
import json
import os
from pathlib import Path
import subprocess
import sys
import time

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts863-qualification-docs/lang')
expected = ['checker', 'program', 'driver', 'cli', 'entrypoint']
print('Waiting for all five complete source gates; no timing or compiler adoption', flush=True)
while True:
    path = root / 'complete-gates.json'
    if path.exists():
        gates = json.loads(path.read_bytes())
        if any(row['exit'] != 0 for row in gates['records']):
            raise SystemExit('Source gate failed; build/admission stopped, evidence retained')
        if [row['target'] for row in gates['records']] == expected:
            break
    time.sleep(1)
records = []
for label, name in [('candidate-build', 'build_candidate.py'), ('full-admission', 'run_admission.py')]:
    command = ['perl', 'scripts/run-bounded.pl', '600', sys.executable, str(root / name)]
    environment = dict(os.environ, HOME_RUN_MAX_MB='3840', HOME_RUN_LABEL='ts881-' + label)
    print('Starting unchanged guard ' + label, flush=True)
    with (root / (label + '-guard.log')).open('x') as stream:
        result = subprocess.run(command, cwd=repo, env=environment, stdout=stream, stderr=subprocess.STDOUT)
    records.append({'phase': label, 'exit': result.returncode, 'command': command})
    with (root / 'qualification-outcome.json').open('w') as stream:
        json.dump({'records': records, 'timing_started': False, 'source_adopted': False}, stream, indent=2)
    print(json.dumps(records[-1]), flush=True)
    if result.returncode != 0:
        print((root / (label + '-guard.log')).read_text()[-1500:], flush=True)
        raise SystemExit(result.returncode)
print('Full source/build/admission qualification complete; timing and adoption still require frozen protocol', flush=True)
