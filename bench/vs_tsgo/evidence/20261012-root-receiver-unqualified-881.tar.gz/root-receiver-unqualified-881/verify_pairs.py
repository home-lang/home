"""Independent phase coverage, custody, diagnostics and paired statistics."""
import hashlib
import json
import math
from pathlib import Path
import random
import re
import statistics
import sys

root = Path(__file__).resolve().parent
kind, workload = sys.argv[1:]
assert kind in ['screen', 'confirm']
protocol = json.loads((root / 'performance-protocol.json').read_bytes())
folder = root / (kind + '-' + workload)
metadata = json.loads((folder / 'metadata.json').read_bytes())
build = json.loads((root / 'candidate-build.json').read_bytes())
assert metadata['status'] == 'complete' and metadata['before'] == metadata['after']
assert metadata['phase'] == kind and metadata['workload'] == workload
assert metadata['source_parent'] == protocol['source_parent'] and metadata['patch_sha256'] == protocol['candidate_patch_sha256']
assert metadata['protocol_sha256'] == hashlib.sha256((root / 'performance-protocol.json').read_bytes()).hexdigest()
assert metadata['runner_sha256'] == hashlib.sha256((root / 'paired.py').read_bytes()).hexdigest()
assert metadata['parent_sha256'] == protocol['parent_native_sha256'] and metadata['candidate_sha256'] == build['native_sha256']
allowed = protocol['official_workloads'] + ['jsdoc_' + str(value) for value in protocol['scales']]
assert workload in allowed
pairs = 10 if kind == 'screen' else 30
assert metadata['pairs'] == pairs and metadata['warmups'] == 3
assert {path.name for path in folder.glob('pair-*.json')} == {f'pair-{index:03d}.json' for index in range(pairs)}
negative = {'destructuring', 'type_predicates', 'type_predicates_large', 'import_graph', 'reexport_graph',
            'variadic_tuples', 'commonjs_graph', 'recursive_generics', 'checkjs_jsdoc', 'null_safe_access', 'jsdoc_512', 'jsdoc_8192'}
expected_keys = {(name, workload, 'positive') for name in ['parent', 'candidate']}
if workload in negative:
    expected_keys |= {(name, workload, 'negative') for name in ['parent', 'candidate']}
trace = metadata['admissions']
assert len(trace) == len(expected_keys)
assert {(row['compiler'], row['workload'], row['kind']) for row in trace} == expected_keys
for row in trace:
    assert row['passed']
    codes = sorted(re.findall(r'\berror TS(\d+):', row['stdout'] + row['stderr']))
    assert codes == row['codes']
    image = 'home' if row['compiler'] == 'candidate' else 'parent'
    prefix = metadata['before']['compilers'][image]['command']
    assert row['command'][:len(prefix)] == prefix and row['command'][len(prefix):len(prefix)+2] == ['--noEmit', '-p']
    if row['kind'] == 'positive':
        assert row['exit_code'] == 0 and not row['stdout'] and not row['stderr']
    else:
        assert row['exit_code'] == 1 and codes == sorted(row['expected_codes'])
        if workload in ['checkjs_jsdoc', 'jsdoc_512', 'jsdoc_8192']:
            assert codes == ['2322'] * 9 + ['2339'] * 3 + ['2345'] * 3
        if workload == 'null_safe_access':
            assert codes == sorted(['2322'] * 18 + ['2339', '2345', '2493'] * 3)
expected_warmups = {f'warmup-{index:03d}-{name}.json' for index in range(3) for name in ['parent', 'candidate']}
assert {path.name for path in folder.glob('warmup-*.json')} == expected_warmups
for filename in expected_warmups:
    row = json.loads((folder / filename).read_bytes())
    name = filename.removesuffix('.json').rsplit('-', 1)[1]
    prefix = metadata['before']['compilers']['home' if name == 'candidate' else 'parent']['command']
    assert row['command'][:len(prefix)] == prefix and row['exit'] == 0 and not row['stdout'] and not row['stderr']
parent, candidate, differences = [], [], []
hashes = {}
for index in range(pairs):
    path = folder / f'pair-{index:03d}.json'
    hashes[path.name] = hashlib.sha256(path.read_bytes()).hexdigest()
    rows = json.loads(path.read_bytes())['results']
    order = ['parent', 'candidate'] if index % 2 == 0 else ['candidate', 'parent']
    assert [row['command'] for row in rows] == [name + ' ' + workload for name in order]
    values = {}
    for row in rows:
        assert row['exit_codes'] == [0] and len(row['times']) == 1
        value = row['times'][0]
        assert type(value) in [int, float] and math.isfinite(value) and value > 0
        values[row['command'].split(' ', 1)[0]] = value
    parent.append(values['parent'])
    candidate.append(values['candidate'])
    differences.append(values['parent'] - values['candidate'])
generator = random.Random(881)
estimates = sorted(sum(differences[generator.randrange(pairs)] for _ in differences) / pairs for _ in range(20000))
def percentile(fraction):
    position = (len(estimates) - 1) * fraction
    low, high = math.floor(position), math.ceil(position)
    return estimates[low] + (estimates[high] - estimates[low]) * (position - low)
interval = [percentile(0.025), percentile(0.975)]
result = {'phase': kind, 'workload': workload, 'pairs': pairs, 'admissions': len(trace), 'verified': True,
          'parent_median': statistics.median(parent), 'candidate_median': statistics.median(candidate),
          'paired_mean_saving': statistics.mean(differences), 'paired_mean_saving_95_interval': interval,
          'candidate_faster_pairs': sum(value > 0 for value in differences), 'raw_sha256': hashes,
          'seed': 881, 'resamples': 20000, 'discarded_samples': 0, 'repeated_measurements': 0,
          'conclusion': 'saving' if interval[0] > 0 else 'loss' if interval[1] < 0 else 'inconclusive'}
with (root / (kind + '-' + workload + '-statistics.json')).open('x') as stream:
    json.dump(result, stream, indent=2)
print(json.dumps({key: value for key, value in result.items() if key != 'raw_sha256'}), flush=True)
