import hashlib
import json
from pathlib import Path
import shutil
import subprocess

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts863-qualification-docs/lang')
protocol = json.loads((root / 'performance-protocol.json').read_bytes())
gates = json.loads((root / 'complete-gates.json').read_bytes())
assert [row['target'] for row in gates['records']] == ['checker', 'program', 'driver', 'cli', 'entrypoint']
assert all(row['exit'] == 0 for row in gates['records'])
def patch_hash():
    return hashlib.sha256(subprocess.check_output(['git', 'diff', '--', 'packages/ts_checker/src/check.zig'], cwd=repo)).hexdigest()
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
assert patch_hash() == protocol['candidate_patch_sha256'] == gates['patch_sha256']
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip() == protocol['source_parent']
installed = repo / 'zig-out/bin/home-tsc'
retained = Path('/Users/chris/.cache/home-ts-owned-alias-inflight-interfaces.jHEAoG/candidate-home-tsc')
before = {str(path): digest(path) for path in [installed, retained]}
prefix = root / 'candidate'
assert not prefix.exists()
command = ['/Users/chris/Code/Home/lang-bun-port/zig-out/toolchains/zig-aarch64-macos-0.17.0-dev.2163+89ff10d56/zig',
           'build', 'home-tsc', '-Doptimize=ReleaseFast', '-Dhome-tsc-strip=true', '-Denable_jsc=false',
           '-j1', '--summary', 'all', '--prefix', str(prefix)]
with (root / 'candidate-build.log').open('x') as stream:
    result = subprocess.run(command, cwd=repo, stdout=stream, stderr=subprocess.STDOUT)
record = {'command': command, 'exit': result.returncode, 'source_parent': protocol['source_parent'],
          'source_patch_sha256': patch_hash(), 'source_adopted': False, 'timing_samples': 0,
          'previous_images_before': before, 'previous_images_after': {str(path): digest(path) for path in [installed, retained]}}
if result.returncode == 0:
    frozen = root / 'candidate-home-tsc'
    assert not frozen.exists()
    shutil.copy2(prefix / 'bin/home-tsc', frozen)
    record['native_sha256'] = digest(frozen)
with (root / 'candidate-build.json').open('x') as stream:
    json.dump(record, stream, indent=2)
assert record['previous_images_before'] == record['previous_images_after']
assert patch_hash() == protocol['candidate_patch_sha256']
print(json.dumps(record), flush=True)
raise SystemExit(result.returncode)
