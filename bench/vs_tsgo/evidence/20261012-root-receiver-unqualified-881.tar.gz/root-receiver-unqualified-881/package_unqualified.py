import hashlib
import json
from pathlib import Path
import sys
import tarfile

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts863-qualification-docs/lang')
sys.path.insert(0, str(repo / 'bench/vs_tsgo'))
import run
protocol = json.loads((root / 'performance-protocol.json').read_bytes())
workloads = protocol['official_workloads'] + ['jsdoc_' + str(value) for value in protocol['scales']]
stats = {}
for kind in ['screen', 'confirm']:
    for name in workloads:
        path = root / (kind + '-' + name + '-statistics.json')
        if path.exists():
            row = json.loads(path.read_bytes())
            assert row['verified']
            for filename, expected in row['raw_sha256'].items():
                assert hashlib.sha256((root / (kind + '-' + name) / filename).read_bytes()).hexdigest() == expected
            stats[kind + '-' + name] = row
assert len(stats) == 43
assert stats['confirm-checkjs_jsdoc']['paired_mean_saving_95_interval'][0] <= 0
assert json.loads((root / 'performance-terminal.json').read_bytes())['exit'] == 124
report = {'qualified': False, 'source_adopted': False, 'source_restored': True,
          'reason': 'Official primary gain inconclusive; final scale phase incomplete at unchanged guard124',
          'complete_verified_phase_pairs': sum(row['pairs'] for row in stats.values()),
          'complete_pairs_in_interrupted_phase': 27, 'empty_interrupted_raw_files': 1,
          'total_complete_pairs_retained': 877, 'planned_pairs': 880,
          'timing_repeats': 0, 'discarded_observations': 0, 'rows': stats}
with (root / 'rejection-summary.json').open('x') as stream:
    json.dump(report, stream, indent=2)
prefix = 'root-receiver-unqualified-881'
members = {}
for path in sorted(root.rglob('*')):
    if path.is_symlink(): raise ValueError('No symlinks in retained evidence')
    if path.is_file() and '__pycache__' not in path.parts:
        members[prefix + '/' + path.relative_to(root).as_posix()] = path.read_bytes()
members[prefix + '/README.txt'] = (
    'Unqualified candidate, never adopted. Exact source patch and both frozen images retained.\n'
    'All full source and complete CLI/protocol/scaled gates passed; unchanged Zod235 identities remain unadmitted.\n'
    'All22 screens and21 independent phases complete,850 independently verified pairs.\n'
    'Final8192 phase guard124 retains27 complete pairs plus one empty raw file; not a completed confirmation.\n'
    'Official128-family independent confidence interval spanszero, so primary gain is not established.\n'
    'Every original observation, warmup, failure, interrupted file and source revision is retained.\n'
    'No repeats, filtering, layout tuning, cap changes, body skips or relaxed diagnostic expectations.\n'
    'Metadata paths and all raw bytes are verbatim; no credential environment is captured.\n'
).encode()
members[prefix + '/SHA256SUMS'] = ''.join(f'{hashlib.sha256(raw).hexdigest()}  {name.removeprefix(prefix + "/")}\n' for name, raw in sorted(members.items())).encode()
output = repo / 'bench/vs_tsgo/evidence/20261012-root-receiver-unqualified-881.tar.gz'
assert not output.exists(), 'Never overwrite original evidence'
run.write_evidence_archive(output, members)
with tarfile.open(output) as archive:
    for name, raw in members.items(): assert archive.extractfile(name).read() == raw, name
print(json.dumps({'archive': str(output), 'sha256': hashlib.sha256(output.read_bytes()).hexdigest(),
                  'verified_payloads': len(members) - 1, 'bytes': output.stat().st_size,
                  'complete_pairs_retained': 877, 'source_adopted': False}))
