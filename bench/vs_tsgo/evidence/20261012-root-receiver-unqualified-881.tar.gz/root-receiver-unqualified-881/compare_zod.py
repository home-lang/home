from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

root = Path(__file__).resolve().parent
runner = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
sys.path.insert(0, str(runner / 'bench/vs_tsgo'))
import competitors
package = Path('/Users/chris/.cache/home-ts-zod-admission.RzJCwi/source/package')
before = competitors.inventory_hash(competitors.payload_inventory(package))
assert before == '7aecd95defd7eff6294e398adefb2ef89821b099199990083ebba310d17d3ca5'
outputs = {}
for name, image in [('parent', root / 'baseline/bin/home-tsc'), ('candidate', root / 'candidate-home-tsc')]:
    command = [str(image), '--noEmit', '-p', str(package / 'tsconfig.benchmark.json'), '--home-list-unmodeled-any']
    result = subprocess.run(command, capture_output=True, text=True)
    record = {'command': command, 'exit': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr,
              'native_sha256': hashlib.sha256(image.read_bytes()).hexdigest(), 'before': before,
              'after': competitors.inventory_hash(competitors.payload_inventory(package)), 'admitted': False, 'timing_samples': 0}
    assert record['after'] == before
    with (root / ('zod-' + name + '.json')).open('x') as stream:
        json.dump(record, stream, indent=2)
    pattern = r'([^\n]+)\((\d+),(\d+)\):\s+(?:error|warning)\s+((?:TS|HM)\d+):\s*([^\n]+)'
    identities = Counter((path.removeprefix(str(package) + '/'), line, column, code, message)
                         for path, line, column, code, message in re.findall(pattern, result.stdout + result.stderr))
    all_codes = Counter(re.findall(r'\b((?:TS|HM)\d+):', result.stdout + result.stderr))
    classified_codes = Counter()
    for identity, count in identities.items():
        classified_codes[identity[3]] += count
    assert classified_codes == all_codes, 'Unclassified diagnostic; no partial library comparison'
    assert result.returncode == 1 and identities, 'Invalid library execution; retain raw output'
    outputs[name] = identities
added = outputs['candidate'] - outputs['parent']
removed = outputs['parent'] - outputs['candidate']
record = {'before': before, 'after': competitors.inventory_hash(competitors.payload_inventory(package)),
          'parent_identities': sum(outputs['parent'].values()), 'candidate_identities': sum(outputs['candidate'].values()),
          'added': [{'identity': list(key), 'count': value} for key, value in added.items()],
          'removed': [{'identity': list(key), 'count': value} for key, value in removed.items()],
          'all_original_outputs_retained': True, 'admitted': False, 'timing_samples': 0}
with (root / 'zod-delta.json').open('x') as stream:
    json.dump(record, stream, indent=2)
print(json.dumps(record), flush=True)
assert not added, 'Added unchanged-library diagnostic identities; no timing or adoption'
