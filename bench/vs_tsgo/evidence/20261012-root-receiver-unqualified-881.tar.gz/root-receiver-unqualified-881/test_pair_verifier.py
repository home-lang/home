"""Explicitly simulated fixtures; never mixed with qualification measurements."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

root = Path(__file__).resolve().parent
protocol_raw = (root / 'performance-protocol.json').read_bytes()
protocol = json.loads(protocol_raw)
def fixture(path):
    shutil.copy2(root / 'verify_pairs.py', path / 'verify_pairs.py')
    shutil.copy2(root / 'paired.py', path / 'paired.py')
    (path / 'performance-protocol.json').write_bytes(protocol_raw)
    (path / 'candidate-build.json').write_text(json.dumps({'native_sha256': 'b' * 64}))
    folder = path / 'confirm-startup'
    folder.mkdir()
    snapshot = {'compilers': {'home': {'command': ['/simulated/candidate']}, 'parent': {'command': ['/simulated/parent']}}}
    trace = [{'compiler': name, 'workload': 'startup', 'kind': 'positive', 'passed': True,
              'command': ['/simulated/' + name, '--noEmit', '-p', '/simulated/tsconfig.json'],
              'exit_code': 0, 'stdout': '', 'stderr': '', 'codes': []} for name in ['parent', 'candidate']]
    metadata = {'phase': 'confirm', 'workload': 'startup', 'pairs': 30, 'warmups': 3, 'status': 'complete',
                'source_parent': protocol['source_parent'], 'patch_sha256': protocol['candidate_patch_sha256'],
                'protocol_sha256': hashlib.sha256(protocol_raw).hexdigest(),
                'runner_sha256': hashlib.sha256((path / 'paired.py').read_bytes()).hexdigest(),
                'parent_sha256': protocol['parent_native_sha256'], 'candidate_sha256': 'b' * 64,
                'before': snapshot, 'after': snapshot, 'admissions': trace, 'SIMULATED_NOT_BENCHMARK': True}
    (folder / 'metadata.json').write_text(json.dumps(metadata))
    for index in range(3):
        for name in ['parent', 'candidate']:
            (folder / f'warmup-{index:03d}-{name}.json').write_text(json.dumps({'command': ['/simulated/' + name, '--noEmit', '-p', '/simulated/tsconfig.json'], 'exit': 0, 'stdout': '', 'stderr': ''}))
    for index in range(30):
        order = ['parent', 'candidate'] if index % 2 == 0 else ['candidate', 'parent']
        rows = [{'command': name + ' startup', 'times': [0.2 if name == 'parent' else 0.1], 'exit_codes': [0]} for name in order]
        (folder / f'pair-{index:03d}.json').write_text(json.dumps({'results': rows}))
    return folder
cases = ['valid', 'missing_pair', 'duplicate_order', 'failed_exit', 'invalid_time', 'missing_warmup', 'changed_provenance']
for case in cases:
    with tempfile.TemporaryDirectory(prefix='home-pair-verifier-simulated-') as temporary:
        path = Path(temporary)
        folder = fixture(path)
        if case == 'missing_pair':
            (folder / 'pair-029.json').unlink()
        elif case in ['duplicate_order', 'failed_exit', 'invalid_time']:
            raw = json.loads((folder / 'pair-000.json').read_bytes())
            if case == 'duplicate_order': raw['results'][1]['command'] = 'parent startup'
            if case == 'failed_exit': raw['results'][1]['exit_codes'] = [1]
            if case == 'invalid_time': raw['results'][1]['times'] = [float('nan')]
            (folder / 'pair-000.json').write_text(json.dumps(raw))
        elif case == 'missing_warmup':
            (folder / 'warmup-002-candidate.json').unlink()
        elif case == 'changed_provenance':
            data = json.loads((folder / 'metadata.json').read_bytes())
            data['after'] = {'changed': True}
            (folder / 'metadata.json').write_text(json.dumps(data))
        result = subprocess.run([sys.executable, str(path / 'verify_pairs.py'), 'confirm', 'startup'], capture_output=True, text=True)
        assert (result.returncode == 0) == (case == 'valid'), (case, result.stdout, result.stderr)
        if case == 'valid':
            statistics = json.loads((path / 'confirm-startup-statistics.json').read_bytes())
            assert statistics['conclusion'] == 'saving' and statistics['candidate_faster_pairs'] == 30
            assert all(abs(value - 0.1) < 1e-12 for value in statistics['paired_mean_saving_95_interval'])
        print(case, 'verified', flush=True)
with (root / 'pair-verifier-tests.json').open('x') as stream:
    json.dump({'passed': True, 'cases': cases, 'SIMULATED_NOT_BENCHMARK': True, 'timing_samples': 0}, stream, indent=2)
