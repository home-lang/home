import hashlib
import json
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts863-qualification-docs/lang')
target = sys.argv[1]
assert target in ['program', 'driver', 'cli', 'entrypoint']
expected = json.loads((root / 'performance-protocol.json').read_bytes())['candidate_patch_sha256']
def patch_hash():
    return hashlib.sha256(subprocess.check_output(['git', 'diff', '--', 'packages/ts_checker/src/check.zig'], cwd=repo)).hexdigest()
assert patch_hash() == expected
with (root / (target + '-complete.log')).open('x') as stream:
    result = subprocess.run([sys.executable, '/Users/chris/.cache/home-ts-843.3BeUMH/module_tests.py', target],
                            cwd=repo, stdout=stream, stderr=subprocess.STDOUT)
assert patch_hash() == expected
with (root / (target + '-complete.json')).open('x') as stream:
    json.dump({'target': target, 'exit': result.returncode, 'patch_sha256': expected, 'filtered': False}, stream, indent=2)
print((root / (target + '-complete.log')).read_text()[-750:], flush=True)
raise SystemExit(result.returncode)
