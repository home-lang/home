import hashlib
import json
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
parent = 'f60a1fa637778db68b6f452d417314dddfe8e150'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip() == parent
for label, count in [('checker',4553), ('program',250), ('driver',200), ('cli',74), ('entrypoint',36)]:
    assert json.loads((root / (label + '-command.json')).read_text())['exit'] == 0
    assert f'All {count} tests passed.' in (root / (label + '.log')).read_text()
assert json.loads((root / 'build-command.json').read_text())['exit'] == 0
for label in ('harness', 'zod-parent', 'zod-candidate'):
    assert json.loads((root / (label + '-command.json')).read_text())['exit'] == 0
assert 'Ran 136 tests' in (root / 'harness.log').read_text()
zod = json.loads((root / 'zod-comparison.json').read_text())
assert zod['complete_primary_messages_equal'] and zod['added'] == zod['removed'] == 0
assert not zod['production_admitted']
assert (root / 'home-tsc-candidate').read_bytes() == (repo / 'zig-out/bin/home-tsc').read_bytes()
patch = subprocess.check_output(['git', 'diff', '--', 'packages/ts_checker/src/check.zig'], cwd=repo)
assert not (root / 'candidate.patch').exists()
(root / 'candidate.patch').write_bytes(patch)
(root / 'candidate-provenance.json').write_text(json.dumps({
    'parent_source': parent,
    'binaries': {name: hashlib.sha256((root / ('home-tsc-' + name)).read_bytes()).hexdigest() for name in ('parent','candidate')},
    'candidate_patch_sha256': hashlib.sha256(patch).hexdigest(),
    'all_full_module_gates_passed': True,
    'complete_zod_and_harness_gates_required_before_timing': True}, indent=2) + '\n')
print((root / 'candidate-provenance.json').read_text())
