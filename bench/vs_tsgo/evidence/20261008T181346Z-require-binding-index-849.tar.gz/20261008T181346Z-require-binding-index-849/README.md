# Home issue #849 retained evidence

Exact parent: `5976d10d3697fb95eff4b633b8f047a4182d351e`.

The archive retains all unfiltered paired rounds, 68 semantic admission records,
the deterministic 1,024- and 4,096-family inputs, exact runner revisions,
fresh-cache test logs, the supported stripped ReleaseFast build log, binary and
Mach-O section hashes, the source patch, and byte-identical normalized Zod output.

The 1,024-family follow-up is retained as inconclusive. The independent
4,096-family confirmation is accepted because its paired mean-saving 95% interval
is wholly positive. Every independently rechecked screen regression interval spans
zero. See `metadata.json` for machine-readable results.
