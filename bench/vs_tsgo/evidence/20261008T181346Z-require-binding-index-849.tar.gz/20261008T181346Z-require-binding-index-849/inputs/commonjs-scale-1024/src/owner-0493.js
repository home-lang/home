class Service493 {
  id = 493;
  label = "service-493";
  meta = { active: false, score: 493 };
}
class Alternate493 {
  id = 493;
  label = 493;
  meta = { active: false, score: 493 };
}
module.exports = new Service493();
module.exports = new Alternate493();
