import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

root=Path(__file__).resolve().parent
matrix=Path('/Users/chris/.cache/home-ts-matrix-852.VNuoKE')
repo=Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
for filename,count in [('admission.json',30),('combined-admission.json',5)]:
    data=json.loads((root/filename).read_text())
    assert len(data['records'])==count and all(row['passed'] for row in data['records'])
    assert data['before']==data['after']
provenance=json.loads((root/'provenance.json').read_text())
assert len(provenance['admissions'])==58 and all(row['passed'] for row in provenance['admissions'])
assert (root/'original-text.bin').read_bytes()==(root/'renamed-text.bin').read_bytes()
profile=json.loads((root/'checkjs8192-profile.json').read_text())
assert profile['compiler_exit']==0 and profile['sample_exit']==0
assert profile['input_hash_before']==profile['input_hash_after']
command=['env','HOME_RUN_MAX_MB=3840','HOME_RUN_LABEL=ts852-final-harness','perl','scripts/run-bounded.pl','600',
         'python3','-m','unittest','discover','-s','bench/vs_tsgo','-p','test_*.py']
result=subprocess.run(command,cwd=repo,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
(root/'harness.log').write_text(result.stdout)
assert result.returncode==0 and 'Ran 136 tests' in result.stdout
entries={}
def add(path,target):
    assert target not in entries
    entries[target]=path.read_bytes()
def tree(path,target):
    for child in sorted(path.rglob('*')):
        if child.is_file():add(child,target+'/'+child.relative_to(path).as_posix())
for filename in ('admit.py','probe_gate.py','profile.py','logged_profile.py','package.py','admission.json','combined-admission.json',
                 'provenance.json','checkjs8192-profile.json','checkjs8192-sample.txt','profile-command.json','profile.log',
                 'original-text.bin','renamed-text.bin','symbol-map.txt','harness.log'):
    add(root/filename,filename)
for directory in ('admission-inputs','combined-negative-input','checkjs-scale-8192'):tree(root/directory,'inputs/'+directory)
for filename in ('matrix.py','verify.py','verified.json','command.json','matrix.log'):add(matrix/filename,'matrix/'+filename)
for filename in ('run.py','compare.py','test_run.py','test_compare.py','corpus.toml'):add(repo/'bench/vs_tsgo'/filename,'harness/'+filename)
name='20261008-jsdoc-admission-profile-852-853'
checksums=''.join(hashlib.sha256(data).hexdigest()+'  '+path+'\n' for path,data in sorted(entries.items()))
count=len(entries);entries['SHA256SUMS']=checksums.encode()
archive=repo/'bench/vs_tsgo/evidence'/(name+'.tar.gz');assert not archive.exists()
with archive.open('wb') as output:
    with gzip.GzipFile(filename='',mode='wb',fileobj=output,mtime=0) as compressed:
        with tarfile.open(fileobj=compressed,mode='w') as tar:
            for path,data in sorted(entries.items()):
                info=tarfile.TarInfo(name+'/'+path);info.size,info.mode,info.mtime=len(data),0o644,0
                tar.addfile(info,io.BytesIO(data))
with tarfile.open(archive) as tar:
    for line in checksums.splitlines():
        digest,path=line.split('  ',1)
        assert hashlib.sha256(tar.extractfile(name+'/'+path).read()).hexdigest()==digest
print(json.dumps({'archive':str(archive),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'payload_checksums':count}),flush=True)
