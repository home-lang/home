import json
from pathlib import Path
import shutil
import subprocess
import sys

repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
root = Path(__file__).resolve().parent
sys.path.insert(0, str(repo / 'bench/vs_tsgo'))
import run
import competitors

profiles = competitors.load_profiles(repo / 'bench/vs_tsgo/profiles/darwin-arm64.json')
commands = run.compiler_commands(profiles)
versions = run.verified_compiler_versions(commands, profiles)
before = run.benchmark_provenance(commands, profiles)
records = []
families = run.manifest()['generated']['checkjs_jsdoc_families']
indices = sorted({0, families // 2, families - 1})
base = run.CORPUS / 'checkjs_jsdoc'
controls = {
    'model-type': (''.join(f'/** @type {{boolean}} */ const wrongId{i} = preserved{i}.id;\n' for i in indices), ['2322'] * 3),
    'model-member': (''.join(f'preserved{i}.missing;\n' for i in indices), ['2339'] * 3),
    'callback-return': (''.join(f'/** @type {{number}} */ const wrongCallback{i} = project{i}(model{i});\n' for i in indices), ['2322'] * 3),
    'instance-argument': (''.join(f'store{i}.read(123);\n' for i in indices), ['2345'] * 3),
    'generic-value': (''.join(f'/** @type {{Box{i}<Model{i}>}} */ const wrongBox{i} = {{ value: {{ id: "wrong", name: "x", meta: {{ active: true, label: "x" }} }}, label: "x" }};\n' for i in indices), ['2322'] * 3),
}
for case, (invalid, expected) in {'positive': ('', None), **controls}.items():
    project = root / 'admission-inputs' / case
    shutil.copytree(base, project)
    path = project / 'src/checkjs-jsdoc.js'
    assert path.is_file(), list((project / 'src').iterdir())
    if invalid:
        path.write_text(path.read_text() + invalid)
    for name, command in commands.items():
        result, passed = run.admission_process(name, command + ['--noEmit', '-p', str(project / 'tsconfig.json')],
            'checkjs_jsdoc/' + case, expected_codes=expected,
            positive_output=profiles[name].positive_output if name in profiles else 'silent', trace=records)
        print(case, name, result.returncode, records[-1]['codes'], passed, flush=True)
    (root / 'admission.json').write_text(json.dumps({'versions': versions, 'records': records, 'before': before}, indent=2) + '\n')
after = run.benchmark_provenance(commands, profiles)
assert before == after
(root / 'admission.json').write_text(json.dumps({'versions': versions, 'records': records,
    'before': before, 'after': after, 'input_inventory': competitors.payload_inventory(root / 'admission-inputs')}, indent=2) + '\n')
print('Every observation retained; no timings collected.', flush=True)
