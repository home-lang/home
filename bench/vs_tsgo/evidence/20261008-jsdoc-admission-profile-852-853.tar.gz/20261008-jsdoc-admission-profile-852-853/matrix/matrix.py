import hashlib
import json
import os
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
native = Path('/Users/chris/.cache/home-ts-resolver-key.B8M6wf/home-tsc-restored')
expected = 'c16c8caaf52d35180a7fcd53b87cac0dd71ff7b86526ef285e09bb4e088335f4'
assert hashlib.sha256(native.read_bytes()).hexdigest() == expected
assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=repo, text=True) == ''
assert subprocess.run(['git', 'diff', '--quiet', 'db28b2e10', 'HEAD', '--', 'packages', 'build.zig', 'build.zig.zon'], cwd=repo).returncode == 0
source = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
command = ['perl', 'scripts/run-bounded.pl', '600', 'python3', 'bench/vs_tsgo/run.py',
           'cold', '--runs', '30', '--warmup', '3', '--competitor-manifest', 'bench/vs_tsgo/profiles/darwin-arm64.json']
env = os.environ.copy()
env['HOME_RUN_MAX_MB'] = '3840'
env['HOME_RUN_LABEL'] = 'ts852-jsdoc-gated-matrix'
env['HOME_TSC'] = str(native)
record = {'command': command, 'source': source, 'compiler_source': 'db28b2e10200b20c7de1412ccf44901a21b05e1e',
          'native_sha256': expected, 'runs': 30, 'warmup': 3, 'guard_mb': 3840,
          'runner_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(root / 'command.json').write_text(json.dumps(record, indent=2) + '\n')
result = subprocess.run(command, cwd=repo, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
(root / 'matrix.log').write_text(result.stdout)
record['exit'] = result.returncode
(root / 'command.json').write_text(json.dumps(record, indent=2) + '\n')
print(result.stdout[-5000:], flush=True)
if result.returncode != 0:
    raise SystemExit(result.returncode)
assert hashlib.sha256(native.read_bytes()).hexdigest() == expected
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip() == source
