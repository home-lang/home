import json
from pathlib import Path
import shutil
import sys

repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
root = Path(__file__).resolve().parent
sys.path.insert(0, str(repo / 'bench/vs_tsgo'))
import run
import competitors

profiles = competitors.load_profiles(repo / 'bench/vs_tsgo/profiles/darwin-arm64.json')
commands = run.compiler_commands(profiles)
before = run.benchmark_provenance(commands, profiles)
original = run.admission_process
def retain(name, command, workload, **kwargs):
    project = Path(command[command.index('-p') + 1]).parent
    target = root / 'combined-negative-input'
    if not target.exists():
        shutil.copytree(project, target)
    return original(name, command, workload, **kwargs)
run.admission_process = retain
records = []
run.validate_checkjs_jsdoc_negatives(commands, trace=records)
after = run.benchmark_provenance(commands, profiles)
assert before == after and len(records) == 5 and all(row['passed'] for row in records)
(root / 'combined-admission.json').write_text(json.dumps({'records': records, 'before': before, 'after': after,
    'input_inventory': competitors.payload_inventory(root / 'combined-negative-input')}, indent=2) + '\n')
print('All five pinned compilers reject the combined 15-error JSDoc control; complete inputs/output/provenance retained.')
