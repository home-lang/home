interface O {value:string;optional?:number}
declare const maybe:number|undefined;
declare function identity<T>(value:T):T;
function make():O{return {value:"ok",optional:identity(maybe)};}
