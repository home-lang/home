interface O {value:string;optional?:number}
declare const maybe:number|undefined;
declare function identity<T>(value:T):T;
const item:O={value:123,optional:maybe};
