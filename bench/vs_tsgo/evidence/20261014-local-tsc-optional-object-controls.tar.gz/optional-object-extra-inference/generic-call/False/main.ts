interface O {value:string;optional?:number}
declare const maybe:number|undefined;
declare function identity<T>(value:T):T;
declare function accept(item:O):void;
accept({value:"ok",optional:identity(maybe)});
