import type {Result} from "./types";
declare const optional:number|undefined;
const item = {value:"ok",optional} satisfies Result<string>;
