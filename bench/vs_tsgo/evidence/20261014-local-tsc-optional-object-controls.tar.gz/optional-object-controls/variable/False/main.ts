import type {Result} from "./types";
declare const optional:number|undefined;
const item:Result<string> = {value:"ok",optional};
