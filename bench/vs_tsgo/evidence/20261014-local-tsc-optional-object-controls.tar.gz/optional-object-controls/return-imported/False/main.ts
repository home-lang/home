import type {Result} from "./types";
function make<T>(value:T, optional:number|undefined):Result<T> { return {value,optional}; }
