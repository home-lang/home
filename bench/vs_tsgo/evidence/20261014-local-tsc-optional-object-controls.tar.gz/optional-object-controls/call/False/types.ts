export interface Result<T> { value: T; optional?: number; }
