import type {Result} from "./types";
declare const optional:number|undefined;
declare function accept(item:Result<string>):void;
accept({value:"ok",optional});
