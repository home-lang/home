interface Result<T> {value:T;optional?:number;}
function make<T>(value:T, optional:number|undefined):Result<T> { return {value,optional}; }
