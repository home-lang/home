interface O {value:string;optional?:number}
declare const maybe:number|undefined;
declare function accept(item:O):void;
accept({value:123,optional:maybe});
