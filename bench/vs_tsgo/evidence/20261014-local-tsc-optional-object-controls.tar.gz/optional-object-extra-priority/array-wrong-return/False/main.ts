interface O {optional?:number}
function make():O[]{return [{optional:"bad"}];}
