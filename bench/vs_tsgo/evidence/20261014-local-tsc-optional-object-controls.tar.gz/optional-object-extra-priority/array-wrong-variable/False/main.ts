interface O {optional?:number}
const items:O[]=[{optional:"bad"}];
