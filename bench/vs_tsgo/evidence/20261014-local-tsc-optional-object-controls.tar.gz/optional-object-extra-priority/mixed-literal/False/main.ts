interface O {value:string;optional?:number}
const item:O={value:123,optional:undefined};
