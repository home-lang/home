interface O {optional?:number}
declare function accept(items:O[]):void;
accept([{optional:"bad"}]);
