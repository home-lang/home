interface O { optional?: number }
const item = { optional: "bad" } satisfies O;
