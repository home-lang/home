interface O {optional?:number}
declare const value:number|undefined;
function make():O[]{return [{optional:value}];}
