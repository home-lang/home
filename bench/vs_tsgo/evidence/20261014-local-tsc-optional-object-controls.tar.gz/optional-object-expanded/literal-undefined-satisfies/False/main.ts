interface O { optional?: number }
const item = { optional: undefined } satisfies O;
