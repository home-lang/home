interface O {optional?:number}
const item:O={};
function make():O{return {};}
declare function accept(item:O):void;
accept({});
const checked={} satisfies O;
