interface O { required: number }
function make(value: number | undefined): O { return {required:value}; }
