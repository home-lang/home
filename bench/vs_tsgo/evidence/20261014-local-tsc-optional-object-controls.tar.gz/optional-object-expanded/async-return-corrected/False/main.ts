interface O {optional?:number}
declare const value:number|undefined;
async function make():Promise<O>{return {optional:value};}
