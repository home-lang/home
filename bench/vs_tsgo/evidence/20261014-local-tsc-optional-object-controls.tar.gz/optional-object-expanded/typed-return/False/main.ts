interface O { optional?: number }
declare const value: number | undefined;
declare const source: {optional:number|undefined};
function make():O {return source;}
