interface O { optional?: number }
declare const value: number | undefined;
const item: {nested:O} = {nested:{optional:value}};
