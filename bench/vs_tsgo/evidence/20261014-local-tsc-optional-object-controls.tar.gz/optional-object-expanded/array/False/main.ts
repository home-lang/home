interface O { optional?: number }
declare const value: number | undefined;
const items:O[] = [{optional:value}];
