interface O {optional?:number}
declare const value:number|undefined;
declare function accept(items:O[]):void;
accept([{optional:value}]);
