interface O { optional?: number | undefined }
const item: O = { optional: undefined };
function make():O {return {optional:undefined};}
