interface O { optional?: number }
const item: O = { optional: undefined };
