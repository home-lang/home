interface O {optional?:number}
const item:O={optional:1};
function make():O{return {optional:1};}
declare function accept(item:O):void;
accept({optional:1});
const checked={optional:1} satisfies O;
