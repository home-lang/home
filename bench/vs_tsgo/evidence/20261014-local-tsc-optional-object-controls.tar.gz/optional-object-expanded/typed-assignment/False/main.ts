interface O { optional?: number }
declare const value: number | undefined;
declare const source: {optional:number|undefined};
const item: O = source;
