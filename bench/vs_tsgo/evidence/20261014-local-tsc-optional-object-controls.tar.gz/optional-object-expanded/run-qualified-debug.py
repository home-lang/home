from pathlib import Path
import subprocess,json,hashlib
r=Path.cwd();base=r/'.home-cache/owner-transfer/optional-object-expanded';rows=[]
for config in sorted(base.rglob('tsconfig.json')):
 hashes={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in config.parent.iterdir() if p.is_file()}
 for engine,image in [('native',r/'.home-cache/owner-transfer/reference-typescript-7.0.2/lib/tsc'),('home',r/'.home-cache/owner-transfer/optional-object-final-debug/bin/home-tsc')]:
  result=subprocess.run([str(image),'--project','tsconfig.json','--pretty','false'],cwd=config.parent,capture_output=True,text=True,timeout=45);assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in hashes.items());rows.append(dict(case=str(config.parent.relative_to(base)),engine=engine,exit=result.returncode,stdout=result.stdout,stderr=result.stderr));print(rows[-1],flush=True)
(base/'qualified-debug.json').write_text(json.dumps(rows,indent=2))
