class Service179 {
  id = 179;
  label = "service-179";
  meta = { active: false, score: 179 };
}
class Alternate179 {
  id = 179;
  label = 179;
  meta = { active: false, score: 179 };
}
module.exports = new Service179();
module.exports = new Alternate179();
