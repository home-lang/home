class Service367 {
  id = 367;
  label = "service-367";
  meta = { active: false, score: 367 };
}
class Alternate367 {
  id = 367;
  label = 367;
  meta = { active: false, score: 367 };
}
module.exports = new Service367();
module.exports = new Alternate367();
