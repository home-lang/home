class Service150 {
  id = 150;
  label = "service-150";
  meta = { active: true, score: 150 };
}
class Alternate150 {
  id = 150;
  label = 150;
  meta = { active: true, score: 150 };
}
module.exports = new Service150();
module.exports = new Alternate150();
