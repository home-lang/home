class Service429 {
  id = 429;
  label = "service-429";
  meta = { active: false, score: 429 };
}
class Alternate429 {
  id = 429;
  label = 429;
  meta = { active: false, score: 429 };
}
module.exports = new Service429();
module.exports = new Alternate429();
