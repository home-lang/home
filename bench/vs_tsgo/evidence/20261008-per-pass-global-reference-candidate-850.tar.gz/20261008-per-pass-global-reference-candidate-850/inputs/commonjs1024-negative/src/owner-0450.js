class Service450 {
  id = 450;
  label = "service-450";
  meta = { active: true, score: 450 };
}
class Alternate450 {
  id = 450;
  label = 450;
  meta = { active: true, score: 450 };
}
module.exports = new Service450();
module.exports = new Alternate450();
