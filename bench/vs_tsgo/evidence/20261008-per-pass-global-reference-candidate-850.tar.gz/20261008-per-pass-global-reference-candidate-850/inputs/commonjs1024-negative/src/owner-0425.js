class Service425 {
  id = 425;
  label = "service-425";
  meta = { active: false, score: 425 };
}
class Alternate425 {
  id = 425;
  label = 425;
  meta = { active: false, score: 425 };
}
module.exports = new Service425();
module.exports = new Alternate425();
