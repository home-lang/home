class Service280 {
  id = 280;
  label = "service-280";
  meta = { active: true, score: 280 };
}
class Alternate280 {
  id = 280;
  label = 280;
  meta = { active: true, score: 280 };
}
module.exports = new Service280();
module.exports = new Alternate280();
