class Service313 {
  id = 313;
  label = "service-313";
  meta = { active: false, score: 313 };
}
class Alternate313 {
  id = 313;
  label = 313;
  meta = { active: false, score: 313 };
}
module.exports = new Service313();
module.exports = new Alternate313();
