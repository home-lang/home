class Service393 {
  id = 393;
  label = "service-393";
  meta = { active: false, score: 393 };
}
class Alternate393 {
  id = 393;
  label = 393;
  meta = { active: false, score: 393 };
}
module.exports = new Service393();
module.exports = new Alternate393();
