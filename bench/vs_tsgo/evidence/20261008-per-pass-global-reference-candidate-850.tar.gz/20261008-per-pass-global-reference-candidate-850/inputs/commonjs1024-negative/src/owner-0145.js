class Service145 {
  id = 145;
  label = "service-145";
  meta = { active: false, score: 145 };
}
class Alternate145 {
  id = 145;
  label = 145;
  meta = { active: false, score: 145 };
}
module.exports = new Service145();
module.exports = new Alternate145();
