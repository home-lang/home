class Service128 {
  id = 128;
  label = "service-128";
  meta = { active: true, score: 128 };
}
class Alternate128 {
  id = 128;
  label = 128;
  meta = { active: true, score: 128 };
}
module.exports = new Service128();
module.exports = new Alternate128();
