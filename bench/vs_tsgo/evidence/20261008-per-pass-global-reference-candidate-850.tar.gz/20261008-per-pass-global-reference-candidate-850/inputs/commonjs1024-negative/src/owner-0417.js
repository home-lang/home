class Service417 {
  id = 417;
  label = "service-417";
  meta = { active: false, score: 417 };
}
class Alternate417 {
  id = 417;
  label = 417;
  meta = { active: false, score: 417 };
}
module.exports = new Service417();
module.exports = new Alternate417();
