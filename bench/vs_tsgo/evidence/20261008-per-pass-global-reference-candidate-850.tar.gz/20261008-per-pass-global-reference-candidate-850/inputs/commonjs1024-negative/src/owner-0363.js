class Service363 {
  id = 363;
  label = "service-363";
  meta = { active: false, score: 363 };
}
class Alternate363 {
  id = 363;
  label = 363;
  meta = { active: false, score: 363 };
}
module.exports = new Service363();
module.exports = new Alternate363();
