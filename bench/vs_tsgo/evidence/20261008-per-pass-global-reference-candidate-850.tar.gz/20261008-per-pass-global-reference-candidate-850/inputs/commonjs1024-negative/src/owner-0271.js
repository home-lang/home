class Service271 {
  id = 271;
  label = "service-271";
  meta = { active: false, score: 271 };
}
class Alternate271 {
  id = 271;
  label = 271;
  meta = { active: false, score: 271 };
}
module.exports = new Service271();
module.exports = new Alternate271();
