class Service471 {
  id = 471;
  label = "service-471";
  meta = { active: false, score: 471 };
}
class Alternate471 {
  id = 471;
  label = 471;
  meta = { active: false, score: 471 };
}
module.exports = new Service471();
module.exports = new Alternate471();
