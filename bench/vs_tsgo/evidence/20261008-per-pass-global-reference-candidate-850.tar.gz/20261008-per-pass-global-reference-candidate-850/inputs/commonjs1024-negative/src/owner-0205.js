class Service205 {
  id = 205;
  label = "service-205";
  meta = { active: false, score: 205 };
}
class Alternate205 {
  id = 205;
  label = 205;
  meta = { active: false, score: 205 };
}
module.exports = new Service205();
module.exports = new Alternate205();
