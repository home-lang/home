class Service227 {
  id = 227;
  label = "service-227";
  meta = { active: false, score: 227 };
}
class Alternate227 {
  id = 227;
  label = 227;
  meta = { active: false, score: 227 };
}
module.exports = new Service227();
module.exports = new Alternate227();
