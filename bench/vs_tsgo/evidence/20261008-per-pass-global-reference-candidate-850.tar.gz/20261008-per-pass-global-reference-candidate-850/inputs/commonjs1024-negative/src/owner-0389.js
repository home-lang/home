class Service389 {
  id = 389;
  label = "service-389";
  meta = { active: false, score: 389 };
}
class Alternate389 {
  id = 389;
  label = 389;
  meta = { active: false, score: 389 };
}
module.exports = new Service389();
module.exports = new Alternate389();
