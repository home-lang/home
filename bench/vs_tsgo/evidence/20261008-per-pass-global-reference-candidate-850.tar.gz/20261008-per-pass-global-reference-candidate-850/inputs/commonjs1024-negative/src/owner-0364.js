class Service364 {
  id = 364;
  label = "service-364";
  meta = { active: true, score: 364 };
}
class Alternate364 {
  id = 364;
  label = 364;
  meta = { active: true, score: 364 };
}
module.exports = new Service364();
module.exports = new Alternate364();
