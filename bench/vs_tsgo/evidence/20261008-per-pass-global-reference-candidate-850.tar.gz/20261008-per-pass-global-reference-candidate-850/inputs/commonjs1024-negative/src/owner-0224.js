class Service224 {
  id = 224;
  label = "service-224";
  meta = { active: true, score: 224 };
}
class Alternate224 {
  id = 224;
  label = 224;
  meta = { active: true, score: 224 };
}
module.exports = new Service224();
module.exports = new Alternate224();
