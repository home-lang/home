class Service151 {
  id = 151;
  label = "service-151";
  meta = { active: false, score: 151 };
}
class Alternate151 {
  id = 151;
  label = 151;
  meta = { active: false, score: 151 };
}
module.exports = new Service151();
module.exports = new Alternate151();
