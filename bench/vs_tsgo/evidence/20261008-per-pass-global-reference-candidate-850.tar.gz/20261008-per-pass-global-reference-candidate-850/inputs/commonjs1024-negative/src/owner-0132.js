class Service132 {
  id = 132;
  label = "service-132";
  meta = { active: true, score: 132 };
}
class Alternate132 {
  id = 132;
  label = 132;
  meta = { active: true, score: 132 };
}
module.exports = new Service132();
module.exports = new Alternate132();
