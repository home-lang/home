class Service395 {
  id = 395;
  label = "service-395";
  meta = { active: false, score: 395 };
}
class Alternate395 {
  id = 395;
  label = 395;
  meta = { active: false, score: 395 };
}
module.exports = new Service395();
module.exports = new Alternate395();
