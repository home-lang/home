class Service223 {
  id = 223;
  label = "service-223";
  meta = { active: false, score: 223 };
}
class Alternate223 {
  id = 223;
  label = 223;
  meta = { active: false, score: 223 };
}
module.exports = new Service223();
module.exports = new Alternate223();
