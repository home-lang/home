class Service230 {
  id = 230;
  label = "service-230";
  meta = { active: true, score: 230 };
}
class Alternate230 {
  id = 230;
  label = 230;
  meta = { active: true, score: 230 };
}
module.exports = new Service230();
module.exports = new Alternate230();
