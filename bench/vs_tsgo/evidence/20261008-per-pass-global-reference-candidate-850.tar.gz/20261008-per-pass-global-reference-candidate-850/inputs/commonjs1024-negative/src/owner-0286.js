class Service286 {
  id = 286;
  label = "service-286";
  meta = { active: true, score: 286 };
}
class Alternate286 {
  id = 286;
  label = 286;
  meta = { active: true, score: 286 };
}
module.exports = new Service286();
module.exports = new Alternate286();
