class Service401 {
  id = 401;
  label = "service-401";
  meta = { active: false, score: 401 };
}
class Alternate401 {
  id = 401;
  label = 401;
  meta = { active: false, score: 401 };
}
module.exports = new Service401();
module.exports = new Alternate401();
