class Service477 {
  id = 477;
  label = "service-477";
  meta = { active: false, score: 477 };
}
class Alternate477 {
  id = 477;
  label = 477;
  meta = { active: false, score: 477 };
}
module.exports = new Service477();
module.exports = new Alternate477();
