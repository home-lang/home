class Service236 {
  id = 236;
  label = "service-236";
  meta = { active: true, score: 236 };
}
class Alternate236 {
  id = 236;
  label = 236;
  meta = { active: true, score: 236 };
}
module.exports = new Service236();
module.exports = new Alternate236();
