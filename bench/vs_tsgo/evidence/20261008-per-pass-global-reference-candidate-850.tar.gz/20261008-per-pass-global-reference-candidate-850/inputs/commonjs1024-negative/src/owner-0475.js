class Service475 {
  id = 475;
  label = "service-475";
  meta = { active: false, score: 475 };
}
class Alternate475 {
  id = 475;
  label = 475;
  meta = { active: false, score: 475 };
}
module.exports = new Service475();
module.exports = new Alternate475();
