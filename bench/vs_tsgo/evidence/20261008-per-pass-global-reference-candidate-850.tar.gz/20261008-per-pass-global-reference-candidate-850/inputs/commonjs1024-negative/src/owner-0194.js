class Service194 {
  id = 194;
  label = "service-194";
  meta = { active: true, score: 194 };
}
class Alternate194 {
  id = 194;
  label = 194;
  meta = { active: true, score: 194 };
}
module.exports = new Service194();
module.exports = new Alternate194();
