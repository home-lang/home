class Service410 {
  id = 410;
  label = "service-410";
  meta = { active: true, score: 410 };
}
class Alternate410 {
  id = 410;
  label = 410;
  meta = { active: true, score: 410 };
}
module.exports = new Service410();
module.exports = new Alternate410();
