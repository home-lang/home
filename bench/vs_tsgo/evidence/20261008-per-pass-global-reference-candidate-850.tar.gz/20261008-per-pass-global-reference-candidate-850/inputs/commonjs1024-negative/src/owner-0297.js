class Service297 {
  id = 297;
  label = "service-297";
  meta = { active: false, score: 297 };
}
class Alternate297 {
  id = 297;
  label = 297;
  meta = { active: false, score: 297 };
}
module.exports = new Service297();
module.exports = new Alternate297();
