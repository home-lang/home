class Service172 {
  id = 172;
  label = "service-172";
  meta = { active: true, score: 172 };
}
class Alternate172 {
  id = 172;
  label = 172;
  meta = { active: true, score: 172 };
}
module.exports = new Service172();
module.exports = new Alternate172();
