class Service397 {
  id = 397;
  label = "service-397";
  meta = { active: false, score: 397 };
}
class Alternate397 {
  id = 397;
  label = 397;
  meta = { active: false, score: 397 };
}
module.exports = new Service397();
module.exports = new Alternate397();
