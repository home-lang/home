class Service298 {
  id = 298;
  label = "service-298";
  meta = { active: true, score: 298 };
}
class Alternate298 {
  id = 298;
  label = 298;
  meta = { active: true, score: 298 };
}
module.exports = new Service298();
module.exports = new Alternate298();
