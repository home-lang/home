class Service307 {
  id = 307;
  label = "service-307";
  meta = { active: false, score: 307 };
}
class Alternate307 {
  id = 307;
  label = 307;
  meta = { active: false, score: 307 };
}
module.exports = new Service307();
module.exports = new Alternate307();
