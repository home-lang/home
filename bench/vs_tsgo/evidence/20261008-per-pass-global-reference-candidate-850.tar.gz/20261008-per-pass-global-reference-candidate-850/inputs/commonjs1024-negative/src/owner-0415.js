class Service415 {
  id = 415;
  label = "service-415";
  meta = { active: false, score: 415 };
}
class Alternate415 {
  id = 415;
  label = 415;
  meta = { active: false, score: 415 };
}
module.exports = new Service415();
module.exports = new Alternate415();
