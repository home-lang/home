class Service129 {
  id = 129;
  label = "service-129";
  meta = { active: false, score: 129 };
}
class Alternate129 {
  id = 129;
  label = 129;
  meta = { active: false, score: 129 };
}
module.exports = new Service129();
module.exports = new Alternate129();
