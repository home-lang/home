class Service463 {
  id = 463;
  label = "service-463";
  meta = { active: false, score: 463 };
}
class Alternate463 {
  id = 463;
  label = 463;
  meta = { active: false, score: 463 };
}
module.exports = new Service463();
module.exports = new Alternate463();
