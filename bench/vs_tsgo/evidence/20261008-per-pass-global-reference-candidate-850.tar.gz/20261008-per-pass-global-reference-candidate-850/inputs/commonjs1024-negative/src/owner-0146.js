class Service146 {
  id = 146;
  label = "service-146";
  meta = { active: true, score: 146 };
}
class Alternate146 {
  id = 146;
  label = 146;
  meta = { active: true, score: 146 };
}
module.exports = new Service146();
module.exports = new Alternate146();
