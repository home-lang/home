class Service385 {
  id = 385;
  label = "service-385";
  meta = { active: false, score: 385 };
}
class Alternate385 {
  id = 385;
  label = 385;
  meta = { active: false, score: 385 };
}
module.exports = new Service385();
module.exports = new Alternate385();
