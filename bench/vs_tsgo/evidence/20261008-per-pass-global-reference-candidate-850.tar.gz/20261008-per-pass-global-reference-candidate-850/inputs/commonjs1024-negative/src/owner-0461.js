class Service461 {
  id = 461;
  label = "service-461";
  meta = { active: false, score: 461 };
}
class Alternate461 {
  id = 461;
  label = 461;
  meta = { active: false, score: 461 };
}
module.exports = new Service461();
module.exports = new Alternate461();
