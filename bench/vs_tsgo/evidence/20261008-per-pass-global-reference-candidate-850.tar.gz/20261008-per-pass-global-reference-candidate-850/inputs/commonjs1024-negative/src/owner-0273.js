class Service273 {
  id = 273;
  label = "service-273";
  meta = { active: false, score: 273 };
}
class Alternate273 {
  id = 273;
  label = 273;
  meta = { active: false, score: 273 };
}
module.exports = new Service273();
module.exports = new Alternate273();
