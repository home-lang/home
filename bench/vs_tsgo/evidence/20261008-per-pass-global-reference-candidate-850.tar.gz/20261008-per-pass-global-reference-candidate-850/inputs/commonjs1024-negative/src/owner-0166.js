class Service166 {
  id = 166;
  label = "service-166";
  meta = { active: true, score: 166 };
}
class Alternate166 {
  id = 166;
  label = 166;
  meta = { active: true, score: 166 };
}
module.exports = new Service166();
module.exports = new Alternate166();
