class Service376 {
  id = 376;
  label = "service-376";
  meta = { active: true, score: 376 };
}
class Alternate376 {
  id = 376;
  label = 376;
  meta = { active: true, score: 376 };
}
module.exports = new Service376();
module.exports = new Alternate376();
