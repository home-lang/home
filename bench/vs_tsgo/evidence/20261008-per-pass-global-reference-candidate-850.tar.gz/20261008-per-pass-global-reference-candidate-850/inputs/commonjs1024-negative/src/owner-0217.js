class Service217 {
  id = 217;
  label = "service-217";
  meta = { active: false, score: 217 };
}
class Alternate217 {
  id = 217;
  label = 217;
  meta = { active: false, score: 217 };
}
module.exports = new Service217();
module.exports = new Alternate217();
