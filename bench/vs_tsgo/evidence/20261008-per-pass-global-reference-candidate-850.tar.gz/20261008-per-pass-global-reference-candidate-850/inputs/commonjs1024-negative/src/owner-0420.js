class Service420 {
  id = 420;
  label = "service-420";
  meta = { active: true, score: 420 };
}
class Alternate420 {
  id = 420;
  label = 420;
  meta = { active: true, score: 420 };
}
module.exports = new Service420();
module.exports = new Alternate420();
