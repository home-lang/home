class Service200 {
  id = 200;
  label = "service-200";
  meta = { active: true, score: 200 };
}
class Alternate200 {
  id = 200;
  label = 200;
  meta = { active: true, score: 200 };
}
module.exports = new Service200();
module.exports = new Alternate200();
