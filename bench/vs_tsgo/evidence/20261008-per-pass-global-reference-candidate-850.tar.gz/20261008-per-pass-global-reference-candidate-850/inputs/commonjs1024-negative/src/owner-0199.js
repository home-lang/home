class Service199 {
  id = 199;
  label = "service-199";
  meta = { active: false, score: 199 };
}
class Alternate199 {
  id = 199;
  label = 199;
  meta = { active: false, score: 199 };
}
module.exports = new Service199();
module.exports = new Alternate199();
