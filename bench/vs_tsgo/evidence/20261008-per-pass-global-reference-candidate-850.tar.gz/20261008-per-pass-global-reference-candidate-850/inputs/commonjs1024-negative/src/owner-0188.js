class Service188 {
  id = 188;
  label = "service-188";
  meta = { active: true, score: 188 };
}
class Alternate188 {
  id = 188;
  label = 188;
  meta = { active: true, score: 188 };
}
module.exports = new Service188();
module.exports = new Alternate188();
