class Service438 {
  id = 438;
  label = "service-438";
  meta = { active: true, score: 438 };
}
class Alternate438 {
  id = 438;
  label = 438;
  meta = { active: true, score: 438 };
}
module.exports = new Service438();
module.exports = new Alternate438();
