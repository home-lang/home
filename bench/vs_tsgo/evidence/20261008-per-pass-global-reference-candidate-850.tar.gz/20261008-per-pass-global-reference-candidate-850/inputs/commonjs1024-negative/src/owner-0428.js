class Service428 {
  id = 428;
  label = "service-428";
  meta = { active: true, score: 428 };
}
class Alternate428 {
  id = 428;
  label = 428;
  meta = { active: true, score: 428 };
}
module.exports = new Service428();
module.exports = new Alternate428();
