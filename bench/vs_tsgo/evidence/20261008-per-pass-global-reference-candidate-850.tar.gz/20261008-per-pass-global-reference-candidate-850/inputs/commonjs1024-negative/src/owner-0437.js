class Service437 {
  id = 437;
  label = "service-437";
  meta = { active: false, score: 437 };
}
class Alternate437 {
  id = 437;
  label = 437;
  meta = { active: false, score: 437 };
}
module.exports = new Service437();
module.exports = new Alternate437();
