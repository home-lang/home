class Service440 {
  id = 440;
  label = "service-440";
  meta = { active: true, score: 440 };
}
class Alternate440 {
  id = 440;
  label = 440;
  meta = { active: true, score: 440 };
}
module.exports = new Service440();
module.exports = new Alternate440();
