class Service262 {
  id = 262;
  label = "service-262";
  meta = { active: true, score: 262 };
}
class Alternate262 {
  id = 262;
  label = 262;
  meta = { active: true, score: 262 };
}
module.exports = new Service262();
module.exports = new Alternate262();
