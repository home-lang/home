class Service388 {
  id = 388;
  label = "service-388";
  meta = { active: true, score: 388 };
}
class Alternate388 {
  id = 388;
  label = 388;
  meta = { active: true, score: 388 };
}
module.exports = new Service388();
module.exports = new Alternate388();
