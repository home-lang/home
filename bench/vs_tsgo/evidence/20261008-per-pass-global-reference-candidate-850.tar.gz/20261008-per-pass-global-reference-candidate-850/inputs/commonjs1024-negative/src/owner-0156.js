class Service156 {
  id = 156;
  label = "service-156";
  meta = { active: true, score: 156 };
}
class Alternate156 {
  id = 156;
  label = 156;
  meta = { active: true, score: 156 };
}
module.exports = new Service156();
module.exports = new Alternate156();
