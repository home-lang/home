class Service274 {
  id = 274;
  label = "service-274";
  meta = { active: true, score: 274 };
}
class Alternate274 {
  id = 274;
  label = 274;
  meta = { active: true, score: 274 };
}
module.exports = new Service274();
module.exports = new Alternate274();
