class Service225 {
  id = 225;
  label = "service-225";
  meta = { active: false, score: 225 };
}
class Alternate225 {
  id = 225;
  label = 225;
  meta = { active: false, score: 225 };
}
module.exports = new Service225();
module.exports = new Alternate225();
