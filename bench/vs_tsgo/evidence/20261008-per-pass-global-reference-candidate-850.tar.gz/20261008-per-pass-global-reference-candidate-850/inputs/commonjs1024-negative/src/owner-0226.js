class Service226 {
  id = 226;
  label = "service-226";
  meta = { active: true, score: 226 };
}
class Alternate226 {
  id = 226;
  label = 226;
  meta = { active: true, score: 226 };
}
module.exports = new Service226();
module.exports = new Alternate226();
