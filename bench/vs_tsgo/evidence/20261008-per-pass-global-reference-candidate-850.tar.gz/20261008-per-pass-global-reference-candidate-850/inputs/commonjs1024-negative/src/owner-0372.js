class Service372 {
  id = 372;
  label = "service-372";
  meta = { active: true, score: 372 };
}
class Alternate372 {
  id = 372;
  label = 372;
  meta = { active: true, score: 372 };
}
module.exports = new Service372();
module.exports = new Alternate372();
