class Service327 {
  id = 327;
  label = "service-327";
  meta = { active: false, score: 327 };
}
class Alternate327 {
  id = 327;
  label = 327;
  meta = { active: false, score: 327 };
}
module.exports = new Service327();
module.exports = new Alternate327();
