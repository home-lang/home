class Service419 {
  id = 419;
  label = "service-419";
  meta = { active: false, score: 419 };
}
class Alternate419 {
  id = 419;
  label = 419;
  meta = { active: false, score: 419 };
}
module.exports = new Service419();
module.exports = new Alternate419();
