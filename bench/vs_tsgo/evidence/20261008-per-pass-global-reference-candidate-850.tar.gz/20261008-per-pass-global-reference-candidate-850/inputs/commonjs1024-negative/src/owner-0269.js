class Service269 {
  id = 269;
  label = "service-269";
  meta = { active: false, score: 269 };
}
class Alternate269 {
  id = 269;
  label = 269;
  meta = { active: false, score: 269 };
}
module.exports = new Service269();
module.exports = new Alternate269();
