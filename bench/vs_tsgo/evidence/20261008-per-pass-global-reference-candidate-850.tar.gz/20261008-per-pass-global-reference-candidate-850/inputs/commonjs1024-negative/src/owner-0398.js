class Service398 {
  id = 398;
  label = "service-398";
  meta = { active: true, score: 398 };
}
class Alternate398 {
  id = 398;
  label = 398;
  meta = { active: true, score: 398 };
}
module.exports = new Service398();
module.exports = new Alternate398();
