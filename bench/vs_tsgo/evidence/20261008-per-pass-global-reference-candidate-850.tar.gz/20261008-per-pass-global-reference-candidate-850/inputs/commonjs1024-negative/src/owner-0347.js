class Service347 {
  id = 347;
  label = "service-347";
  meta = { active: false, score: 347 };
}
class Alternate347 {
  id = 347;
  label = 347;
  meta = { active: false, score: 347 };
}
module.exports = new Service347();
module.exports = new Alternate347();
