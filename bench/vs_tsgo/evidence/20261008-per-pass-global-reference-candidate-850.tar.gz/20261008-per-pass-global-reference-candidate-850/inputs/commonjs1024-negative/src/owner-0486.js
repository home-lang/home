class Service486 {
  id = 486;
  label = "service-486";
  meta = { active: true, score: 486 };
}
class Alternate486 {
  id = 486;
  label = 486;
  meta = { active: true, score: 486 };
}
module.exports = new Service486();
module.exports = new Alternate486();
