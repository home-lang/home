class Service340 {
  id = 340;
  label = "service-340";
  meta = { active: true, score: 340 };
}
class Alternate340 {
  id = 340;
  label = 340;
  meta = { active: true, score: 340 };
}
module.exports = new Service340();
module.exports = new Alternate340();
