class Service177 {
  id = 177;
  label = "service-177";
  meta = { active: false, score: 177 };
}
class Alternate177 {
  id = 177;
  label = 177;
  meta = { active: false, score: 177 };
}
module.exports = new Service177();
module.exports = new Alternate177();
