class Service238 {
  id = 238;
  label = "service-238";
  meta = { active: true, score: 238 };
}
class Alternate238 {
  id = 238;
  label = 238;
  meta = { active: true, score: 238 };
}
module.exports = new Service238();
module.exports = new Alternate238();
