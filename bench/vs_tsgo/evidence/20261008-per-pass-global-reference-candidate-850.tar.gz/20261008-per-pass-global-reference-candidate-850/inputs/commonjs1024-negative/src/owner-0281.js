class Service281 {
  id = 281;
  label = "service-281";
  meta = { active: false, score: 281 };
}
class Alternate281 {
  id = 281;
  label = 281;
  meta = { active: false, score: 281 };
}
module.exports = new Service281();
module.exports = new Alternate281();
