class Service203 {
  id = 203;
  label = "service-203";
  meta = { active: false, score: 203 };
}
class Alternate203 {
  id = 203;
  label = 203;
  meta = { active: false, score: 203 };
}
module.exports = new Service203();
module.exports = new Alternate203();
