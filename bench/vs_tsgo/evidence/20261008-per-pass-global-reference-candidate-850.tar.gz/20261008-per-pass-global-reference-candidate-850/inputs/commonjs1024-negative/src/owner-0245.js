class Service245 {
  id = 245;
  label = "service-245";
  meta = { active: false, score: 245 };
}
class Alternate245 {
  id = 245;
  label = 245;
  meta = { active: false, score: 245 };
}
module.exports = new Service245();
module.exports = new Alternate245();
