class Service344 {
  id = 344;
  label = "service-344";
  meta = { active: true, score: 344 };
}
class Alternate344 {
  id = 344;
  label = 344;
  meta = { active: true, score: 344 };
}
module.exports = new Service344();
module.exports = new Alternate344();
