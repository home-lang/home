class Service381 {
  id = 381;
  label = "service-381";
  meta = { active: false, score: 381 };
}
class Alternate381 {
  id = 381;
  label = 381;
  meta = { active: false, score: 381 };
}
module.exports = new Service381();
module.exports = new Alternate381();
