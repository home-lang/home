class Service175 {
  id = 175;
  label = "service-175";
  meta = { active: false, score: 175 };
}
class Alternate175 {
  id = 175;
  label = 175;
  meta = { active: false, score: 175 };
}
module.exports = new Service175();
module.exports = new Alternate175();
