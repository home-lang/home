class Service483 {
  id = 483;
  label = "service-483";
  meta = { active: false, score: 483 };
}
class Alternate483 {
  id = 483;
  label = 483;
  meta = { active: false, score: 483 };
}
module.exports = new Service483();
module.exports = new Alternate483();
