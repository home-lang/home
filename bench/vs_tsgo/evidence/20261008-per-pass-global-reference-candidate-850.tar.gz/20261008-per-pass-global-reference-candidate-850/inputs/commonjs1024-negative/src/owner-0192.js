class Service192 {
  id = 192;
  label = "service-192";
  meta = { active: true, score: 192 };
}
class Alternate192 {
  id = 192;
  label = 192;
  meta = { active: true, score: 192 };
}
module.exports = new Service192();
module.exports = new Alternate192();
