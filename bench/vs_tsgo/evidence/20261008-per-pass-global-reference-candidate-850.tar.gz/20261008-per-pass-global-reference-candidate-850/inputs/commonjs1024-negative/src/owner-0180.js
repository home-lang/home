class Service180 {
  id = 180;
  label = "service-180";
  meta = { active: true, score: 180 };
}
class Alternate180 {
  id = 180;
  label = 180;
  meta = { active: true, score: 180 };
}
module.exports = new Service180();
module.exports = new Alternate180();
