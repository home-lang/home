class Service174 {
  id = 174;
  label = "service-174";
  meta = { active: true, score: 174 };
}
class Alternate174 {
  id = 174;
  label = 174;
  meta = { active: true, score: 174 };
}
module.exports = new Service174();
module.exports = new Alternate174();
