class Service270 {
  id = 270;
  label = "service-270";
  meta = { active: true, score: 270 };
}
class Alternate270 {
  id = 270;
  label = 270;
  meta = { active: true, score: 270 };
}
module.exports = new Service270();
module.exports = new Alternate270();
