class Service208 {
  id = 208;
  label = "service-208";
  meta = { active: true, score: 208 };
}
class Alternate208 {
  id = 208;
  label = 208;
  meta = { active: true, score: 208 };
}
module.exports = new Service208();
module.exports = new Alternate208();
