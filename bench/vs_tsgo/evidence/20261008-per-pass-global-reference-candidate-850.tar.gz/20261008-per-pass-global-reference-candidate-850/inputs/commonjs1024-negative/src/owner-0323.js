class Service323 {
  id = 323;
  label = "service-323";
  meta = { active: false, score: 323 };
}
class Alternate323 {
  id = 323;
  label = 323;
  meta = { active: false, score: 323 };
}
module.exports = new Service323();
module.exports = new Alternate323();
