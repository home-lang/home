class Service375 {
  id = 375;
  label = "service-375";
  meta = { active: false, score: 375 };
}
class Alternate375 {
  id = 375;
  label = 375;
  meta = { active: false, score: 375 };
}
module.exports = new Service375();
module.exports = new Alternate375();
