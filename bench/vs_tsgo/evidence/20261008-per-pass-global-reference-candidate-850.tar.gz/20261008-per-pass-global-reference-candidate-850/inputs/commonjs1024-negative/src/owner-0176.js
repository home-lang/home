class Service176 {
  id = 176;
  label = "service-176";
  meta = { active: true, score: 176 };
}
class Alternate176 {
  id = 176;
  label = 176;
  meta = { active: true, score: 176 };
}
module.exports = new Service176();
module.exports = new Alternate176();
