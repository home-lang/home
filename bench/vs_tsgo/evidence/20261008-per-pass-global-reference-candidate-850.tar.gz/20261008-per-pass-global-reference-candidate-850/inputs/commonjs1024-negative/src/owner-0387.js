class Service387 {
  id = 387;
  label = "service-387";
  meta = { active: false, score: 387 };
}
class Alternate387 {
  id = 387;
  label = 387;
  meta = { active: false, score: 387 };
}
module.exports = new Service387();
module.exports = new Alternate387();
