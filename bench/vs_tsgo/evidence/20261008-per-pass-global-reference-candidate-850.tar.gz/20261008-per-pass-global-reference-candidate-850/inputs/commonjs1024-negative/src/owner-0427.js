class Service427 {
  id = 427;
  label = "service-427";
  meta = { active: false, score: 427 };
}
class Alternate427 {
  id = 427;
  label = 427;
  meta = { active: false, score: 427 };
}
module.exports = new Service427();
module.exports = new Alternate427();
