class Service181 {
  id = 181;
  label = "service-181";
  meta = { active: false, score: 181 };
}
class Alternate181 {
  id = 181;
  label = 181;
  meta = { active: false, score: 181 };
}
module.exports = new Service181();
module.exports = new Alternate181();
