class Service275 {
  id = 275;
  label = "service-275";
  meta = { active: false, score: 275 };
}
class Alternate275 {
  id = 275;
  label = 275;
  meta = { active: false, score: 275 };
}
module.exports = new Service275();
module.exports = new Alternate275();
