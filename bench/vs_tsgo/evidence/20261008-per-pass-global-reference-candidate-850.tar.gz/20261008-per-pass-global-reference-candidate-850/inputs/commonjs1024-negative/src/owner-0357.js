class Service357 {
  id = 357;
  label = "service-357";
  meta = { active: false, score: 357 };
}
class Alternate357 {
  id = 357;
  label = 357;
  meta = { active: false, score: 357 };
}
module.exports = new Service357();
module.exports = new Alternate357();
