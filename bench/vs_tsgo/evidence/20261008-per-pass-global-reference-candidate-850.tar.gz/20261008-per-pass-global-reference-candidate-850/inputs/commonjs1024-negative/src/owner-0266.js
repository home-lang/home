class Service266 {
  id = 266;
  label = "service-266";
  meta = { active: true, score: 266 };
}
class Alternate266 {
  id = 266;
  label = 266;
  meta = { active: true, score: 266 };
}
module.exports = new Service266();
module.exports = new Alternate266();
