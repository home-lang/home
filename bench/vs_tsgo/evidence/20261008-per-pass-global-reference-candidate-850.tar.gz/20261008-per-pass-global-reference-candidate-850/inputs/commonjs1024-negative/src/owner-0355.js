class Service355 {
  id = 355;
  label = "service-355";
  meta = { active: false, score: 355 };
}
class Alternate355 {
  id = 355;
  label = 355;
  meta = { active: false, score: 355 };
}
module.exports = new Service355();
module.exports = new Alternate355();
