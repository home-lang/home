class Service261 {
  id = 261;
  label = "service-261";
  meta = { active: false, score: 261 };
}
class Alternate261 {
  id = 261;
  label = 261;
  meta = { active: false, score: 261 };
}
module.exports = new Service261();
module.exports = new Alternate261();
