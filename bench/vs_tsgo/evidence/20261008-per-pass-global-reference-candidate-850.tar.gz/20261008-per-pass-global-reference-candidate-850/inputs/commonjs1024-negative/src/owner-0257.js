class Service257 {
  id = 257;
  label = "service-257";
  meta = { active: false, score: 257 };
}
class Alternate257 {
  id = 257;
  label = 257;
  meta = { active: false, score: 257 };
}
module.exports = new Service257();
module.exports = new Alternate257();
