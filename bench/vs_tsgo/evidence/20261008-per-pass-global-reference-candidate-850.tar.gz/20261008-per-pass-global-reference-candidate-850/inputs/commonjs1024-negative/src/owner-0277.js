class Service277 {
  id = 277;
  label = "service-277";
  meta = { active: false, score: 277 };
}
class Alternate277 {
  id = 277;
  label = 277;
  meta = { active: false, score: 277 };
}
module.exports = new Service277();
module.exports = new Alternate277();
