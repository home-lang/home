class Service456 {
  id = 456;
  label = "service-456";
  meta = { active: true, score: 456 };
}
class Alternate456 {
  id = 456;
  label = 456;
  meta = { active: true, score: 456 };
}
module.exports = new Service456();
module.exports = new Alternate456();
