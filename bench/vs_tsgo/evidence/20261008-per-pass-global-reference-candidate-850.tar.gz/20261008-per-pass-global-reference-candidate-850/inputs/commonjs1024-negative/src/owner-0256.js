class Service256 {
  id = 256;
  label = "service-256";
  meta = { active: true, score: 256 };
}
class Alternate256 {
  id = 256;
  label = 256;
  meta = { active: true, score: 256 };
}
module.exports = new Service256();
module.exports = new Alternate256();
