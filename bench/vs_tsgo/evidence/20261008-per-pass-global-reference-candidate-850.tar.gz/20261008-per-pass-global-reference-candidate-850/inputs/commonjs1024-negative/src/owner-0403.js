class Service403 {
  id = 403;
  label = "service-403";
  meta = { active: false, score: 403 };
}
class Alternate403 {
  id = 403;
  label = 403;
  meta = { active: false, score: 403 };
}
module.exports = new Service403();
module.exports = new Alternate403();
