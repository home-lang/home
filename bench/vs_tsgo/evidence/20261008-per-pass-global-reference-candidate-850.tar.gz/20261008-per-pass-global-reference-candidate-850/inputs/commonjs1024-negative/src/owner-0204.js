class Service204 {
  id = 204;
  label = "service-204";
  meta = { active: true, score: 204 };
}
class Alternate204 {
  id = 204;
  label = 204;
  meta = { active: true, score: 204 };
}
module.exports = new Service204();
module.exports = new Alternate204();
