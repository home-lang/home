class Service370 {
  id = 370;
  label = "service-370";
  meta = { active: true, score: 370 };
}
class Alternate370 {
  id = 370;
  label = 370;
  meta = { active: true, score: 370 };
}
module.exports = new Service370();
module.exports = new Alternate370();
