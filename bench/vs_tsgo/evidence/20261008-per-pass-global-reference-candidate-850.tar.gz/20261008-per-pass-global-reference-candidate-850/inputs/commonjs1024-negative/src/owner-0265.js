class Service265 {
  id = 265;
  label = "service-265";
  meta = { active: false, score: 265 };
}
class Alternate265 {
  id = 265;
  label = 265;
  meta = { active: false, score: 265 };
}
module.exports = new Service265();
module.exports = new Alternate265();
