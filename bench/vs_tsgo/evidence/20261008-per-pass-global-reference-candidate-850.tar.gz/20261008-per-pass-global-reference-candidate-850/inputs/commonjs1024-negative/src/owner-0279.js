class Service279 {
  id = 279;
  label = "service-279";
  meta = { active: false, score: 279 };
}
class Alternate279 {
  id = 279;
  label = 279;
  meta = { active: false, score: 279 };
}
module.exports = new Service279();
module.exports = new Alternate279();
