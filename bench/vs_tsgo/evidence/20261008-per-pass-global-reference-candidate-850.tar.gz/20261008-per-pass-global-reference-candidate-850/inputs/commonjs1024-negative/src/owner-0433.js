class Service433 {
  id = 433;
  label = "service-433";
  meta = { active: false, score: 433 };
}
class Alternate433 {
  id = 433;
  label = 433;
  meta = { active: false, score: 433 };
}
module.exports = new Service433();
module.exports = new Alternate433();
