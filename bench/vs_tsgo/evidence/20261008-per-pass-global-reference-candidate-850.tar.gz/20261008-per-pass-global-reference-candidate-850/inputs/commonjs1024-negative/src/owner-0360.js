class Service360 {
  id = 360;
  label = "service-360";
  meta = { active: true, score: 360 };
}
class Alternate360 {
  id = 360;
  label = 360;
  meta = { active: true, score: 360 };
}
module.exports = new Service360();
module.exports = new Alternate360();
