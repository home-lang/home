class Service350 {
  id = 350;
  label = "service-350";
  meta = { active: true, score: 350 };
}
class Alternate350 {
  id = 350;
  label = 350;
  meta = { active: true, score: 350 };
}
module.exports = new Service350();
module.exports = new Alternate350();
