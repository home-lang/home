class Service259 {
  id = 259;
  label = "service-259";
  meta = { active: false, score: 259 };
}
class Alternate259 {
  id = 259;
  label = 259;
  meta = { active: false, score: 259 };
}
module.exports = new Service259();
module.exports = new Alternate259();
