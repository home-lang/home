class Service283 {
  id = 283;
  label = "service-283";
  meta = { active: false, score: 283 };
}
class Alternate283 {
  id = 283;
  label = 283;
  meta = { active: false, score: 283 };
}
module.exports = new Service283();
module.exports = new Alternate283();
