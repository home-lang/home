class Service299 {
  id = 299;
  label = "service-299";
  meta = { active: false, score: 299 };
}
class Alternate299 {
  id = 299;
  label = 299;
  meta = { active: false, score: 299 };
}
module.exports = new Service299();
module.exports = new Alternate299();
