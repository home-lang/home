class Service202 {
  id = 202;
  label = "service-202";
  meta = { active: true, score: 202 };
}
class Alternate202 {
  id = 202;
  label = 202;
  meta = { active: true, score: 202 };
}
module.exports = new Service202();
module.exports = new Alternate202();
