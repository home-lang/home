class Service189 {
  id = 189;
  label = "service-189";
  meta = { active: false, score: 189 };
}
class Alternate189 {
  id = 189;
  label = 189;
  meta = { active: false, score: 189 };
}
module.exports = new Service189();
module.exports = new Alternate189();
