class Service406 {
  id = 406;
  label = "service-406";
  meta = { active: true, score: 406 };
}
class Alternate406 {
  id = 406;
  label = 406;
  meta = { active: true, score: 406 };
}
module.exports = new Service406();
module.exports = new Alternate406();
