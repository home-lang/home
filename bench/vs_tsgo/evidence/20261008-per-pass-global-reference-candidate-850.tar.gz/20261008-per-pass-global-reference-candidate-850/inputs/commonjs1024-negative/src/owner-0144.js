class Service144 {
  id = 144;
  label = "service-144";
  meta = { active: true, score: 144 };
}
class Alternate144 {
  id = 144;
  label = 144;
  meta = { active: true, score: 144 };
}
module.exports = new Service144();
module.exports = new Alternate144();
