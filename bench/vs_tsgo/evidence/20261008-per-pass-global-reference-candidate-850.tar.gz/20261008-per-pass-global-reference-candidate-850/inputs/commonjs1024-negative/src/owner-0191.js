class Service191 {
  id = 191;
  label = "service-191";
  meta = { active: false, score: 191 };
}
class Alternate191 {
  id = 191;
  label = 191;
  meta = { active: false, score: 191 };
}
module.exports = new Service191();
module.exports = new Alternate191();
