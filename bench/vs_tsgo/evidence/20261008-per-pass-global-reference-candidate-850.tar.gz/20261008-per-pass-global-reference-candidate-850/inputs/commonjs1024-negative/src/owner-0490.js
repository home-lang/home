class Service490 {
  id = 490;
  label = "service-490";
  meta = { active: true, score: 490 };
}
class Alternate490 {
  id = 490;
  label = 490;
  meta = { active: true, score: 490 };
}
module.exports = new Service490();
module.exports = new Alternate490();
