class Service263 {
  id = 263;
  label = "service-263";
  meta = { active: false, score: 263 };
}
class Alternate263 {
  id = 263;
  label = 263;
  meta = { active: false, score: 263 };
}
module.exports = new Service263();
module.exports = new Alternate263();
