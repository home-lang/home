class Service185 {
  id = 185;
  label = "service-185";
  meta = { active: false, score: 185 };
}
class Alternate185 {
  id = 185;
  label = 185;
  meta = { active: false, score: 185 };
}
module.exports = new Service185();
module.exports = new Alternate185();
