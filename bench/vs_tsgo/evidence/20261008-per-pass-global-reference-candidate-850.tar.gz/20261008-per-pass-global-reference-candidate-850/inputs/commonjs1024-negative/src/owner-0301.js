class Service301 {
  id = 301;
  label = "service-301";
  meta = { active: false, score: 301 };
}
class Alternate301 {
  id = 301;
  label = 301;
  meta = { active: false, score: 301 };
}
module.exports = new Service301();
module.exports = new Alternate301();
