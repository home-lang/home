class Service197 {
  id = 197;
  label = "service-197";
  meta = { active: false, score: 197 };
}
class Alternate197 {
  id = 197;
  label = 197;
  meta = { active: false, score: 197 };
}
module.exports = new Service197();
module.exports = new Alternate197();
