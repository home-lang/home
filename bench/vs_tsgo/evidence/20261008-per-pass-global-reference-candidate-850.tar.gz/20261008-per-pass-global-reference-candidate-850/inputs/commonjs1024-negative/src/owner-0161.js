class Service161 {
  id = 161;
  label = "service-161";
  meta = { active: false, score: 161 };
}
class Alternate161 {
  id = 161;
  label = 161;
  meta = { active: false, score: 161 };
}
module.exports = new Service161();
module.exports = new Alternate161();
