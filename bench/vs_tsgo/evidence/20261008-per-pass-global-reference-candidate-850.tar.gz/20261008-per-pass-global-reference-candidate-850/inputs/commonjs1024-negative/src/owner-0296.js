class Service296 {
  id = 296;
  label = "service-296";
  meta = { active: true, score: 296 };
}
class Alternate296 {
  id = 296;
  label = 296;
  meta = { active: true, score: 296 };
}
module.exports = new Service296();
module.exports = new Alternate296();
