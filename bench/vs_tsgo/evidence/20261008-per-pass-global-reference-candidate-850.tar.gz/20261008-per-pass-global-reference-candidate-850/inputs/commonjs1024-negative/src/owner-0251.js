class Service251 {
  id = 251;
  label = "service-251";
  meta = { active: false, score: 251 };
}
class Alternate251 {
  id = 251;
  label = 251;
  meta = { active: false, score: 251 };
}
module.exports = new Service251();
module.exports = new Alternate251();
