class Service330 {
  id = 330;
  label = "service-330";
  meta = { active: true, score: 330 };
}
class Alternate330 {
  id = 330;
  label = 330;
  meta = { active: true, score: 330 };
}
module.exports = new Service330();
module.exports = new Alternate330();
