class Service147 {
  id = 147;
  label = "service-147";
  meta = { active: false, score: 147 };
}
class Alternate147 {
  id = 147;
  label = 147;
  meta = { active: false, score: 147 };
}
module.exports = new Service147();
module.exports = new Alternate147();
