class Service220 {
  id = 220;
  label = "service-220";
  meta = { active: true, score: 220 };
}
class Alternate220 {
  id = 220;
  label = 220;
  meta = { active: true, score: 220 };
}
module.exports = new Service220();
module.exports = new Alternate220();
