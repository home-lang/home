class Service304 {
  id = 304;
  label = "service-304";
  meta = { active: true, score: 304 };
}
class Alternate304 {
  id = 304;
  label = 304;
  meta = { active: true, score: 304 };
}
module.exports = new Service304();
module.exports = new Alternate304();
