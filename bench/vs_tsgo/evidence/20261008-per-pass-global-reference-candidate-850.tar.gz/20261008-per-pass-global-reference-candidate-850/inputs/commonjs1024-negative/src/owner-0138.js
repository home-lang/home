class Service138 {
  id = 138;
  label = "service-138";
  meta = { active: true, score: 138 };
}
class Alternate138 {
  id = 138;
  label = 138;
  meta = { active: true, score: 138 };
}
module.exports = new Service138();
module.exports = new Alternate138();
