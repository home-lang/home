class Service137 {
  id = 137;
  label = "service-137";
  meta = { active: false, score: 137 };
}
class Alternate137 {
  id = 137;
  label = 137;
  meta = { active: false, score: 137 };
}
module.exports = new Service137();
module.exports = new Alternate137();
