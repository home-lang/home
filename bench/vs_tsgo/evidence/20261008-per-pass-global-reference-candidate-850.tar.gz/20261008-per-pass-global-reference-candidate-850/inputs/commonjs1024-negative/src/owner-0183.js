class Service183 {
  id = 183;
  label = "service-183";
  meta = { active: false, score: 183 };
}
class Alternate183 {
  id = 183;
  label = 183;
  meta = { active: false, score: 183 };
}
module.exports = new Service183();
module.exports = new Alternate183();
