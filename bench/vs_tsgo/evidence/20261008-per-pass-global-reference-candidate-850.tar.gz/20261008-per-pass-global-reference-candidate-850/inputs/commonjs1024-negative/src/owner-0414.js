class Service414 {
  id = 414;
  label = "service-414";
  meta = { active: true, score: 414 };
}
class Alternate414 {
  id = 414;
  label = 414;
  meta = { active: true, score: 414 };
}
module.exports = new Service414();
module.exports = new Alternate414();
