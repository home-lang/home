class Service402 {
  id = 402;
  label = "service-402";
  meta = { active: true, score: 402 };
}
class Alternate402 {
  id = 402;
  label = 402;
  meta = { active: true, score: 402 };
}
module.exports = new Service402();
module.exports = new Alternate402();
