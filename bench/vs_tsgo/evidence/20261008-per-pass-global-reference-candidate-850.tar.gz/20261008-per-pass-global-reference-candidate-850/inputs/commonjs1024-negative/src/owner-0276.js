class Service276 {
  id = 276;
  label = "service-276";
  meta = { active: true, score: 276 };
}
class Alternate276 {
  id = 276;
  label = 276;
  meta = { active: true, score: 276 };
}
module.exports = new Service276();
module.exports = new Alternate276();
