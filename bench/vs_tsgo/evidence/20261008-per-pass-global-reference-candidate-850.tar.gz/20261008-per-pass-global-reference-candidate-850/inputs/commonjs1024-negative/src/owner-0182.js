class Service182 {
  id = 182;
  label = "service-182";
  meta = { active: true, score: 182 };
}
class Alternate182 {
  id = 182;
  label = 182;
  meta = { active: true, score: 182 };
}
module.exports = new Service182();
module.exports = new Alternate182();
