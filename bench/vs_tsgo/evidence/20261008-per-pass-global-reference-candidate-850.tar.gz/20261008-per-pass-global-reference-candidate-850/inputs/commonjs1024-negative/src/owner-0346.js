class Service346 {
  id = 346;
  label = "service-346";
  meta = { active: true, score: 346 };
}
class Alternate346 {
  id = 346;
  label = 346;
  meta = { active: true, score: 346 };
}
module.exports = new Service346();
module.exports = new Alternate346();
