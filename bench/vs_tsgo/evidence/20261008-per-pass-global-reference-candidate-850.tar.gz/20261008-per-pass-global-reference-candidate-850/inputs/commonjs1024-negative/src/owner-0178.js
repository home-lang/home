class Service178 {
  id = 178;
  label = "service-178";
  meta = { active: true, score: 178 };
}
class Alternate178 {
  id = 178;
  label = 178;
  meta = { active: true, score: 178 };
}
module.exports = new Service178();
module.exports = new Alternate178();
