class Service169 {
  id = 169;
  label = "service-169";
  meta = { active: false, score: 169 };
}
class Alternate169 {
  id = 169;
  label = 169;
  meta = { active: false, score: 169 };
}
module.exports = new Service169();
module.exports = new Alternate169();
