class Service289 {
  id = 289;
  label = "service-289";
  meta = { active: false, score: 289 };
}
class Alternate289 {
  id = 289;
  label = 289;
  meta = { active: false, score: 289 };
}
module.exports = new Service289();
module.exports = new Alternate289();
