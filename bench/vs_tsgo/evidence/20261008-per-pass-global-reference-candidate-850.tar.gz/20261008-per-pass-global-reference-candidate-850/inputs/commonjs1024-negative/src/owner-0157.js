class Service157 {
  id = 157;
  label = "service-157";
  meta = { active: false, score: 157 };
}
class Alternate157 {
  id = 157;
  label = 157;
  meta = { active: false, score: 157 };
}
module.exports = new Service157();
module.exports = new Alternate157();
