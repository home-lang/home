class Service310 {
  id = 310;
  label = "service-310";
  meta = { active: true, score: 310 };
}
class Alternate310 {
  id = 310;
  label = 310;
  meta = { active: true, score: 310 };
}
module.exports = new Service310();
module.exports = new Alternate310();
