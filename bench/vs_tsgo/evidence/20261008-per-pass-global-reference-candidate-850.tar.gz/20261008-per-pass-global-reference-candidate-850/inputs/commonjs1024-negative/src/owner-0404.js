class Service404 {
  id = 404;
  label = "service-404";
  meta = { active: true, score: 404 };
}
class Alternate404 {
  id = 404;
  label = 404;
  meta = { active: true, score: 404 };
}
module.exports = new Service404();
module.exports = new Alternate404();
