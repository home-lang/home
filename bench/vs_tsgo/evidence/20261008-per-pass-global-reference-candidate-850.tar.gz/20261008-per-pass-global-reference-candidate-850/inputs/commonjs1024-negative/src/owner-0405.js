class Service405 {
  id = 405;
  label = "service-405";
  meta = { active: false, score: 405 };
}
class Alternate405 {
  id = 405;
  label = 405;
  meta = { active: false, score: 405 };
}
module.exports = new Service405();
module.exports = new Alternate405();
