class Service218 {
  id = 218;
  label = "service-218";
  meta = { active: true, score: 218 };
}
class Alternate218 {
  id = 218;
  label = 218;
  meta = { active: true, score: 218 };
}
module.exports = new Service218();
module.exports = new Alternate218();
