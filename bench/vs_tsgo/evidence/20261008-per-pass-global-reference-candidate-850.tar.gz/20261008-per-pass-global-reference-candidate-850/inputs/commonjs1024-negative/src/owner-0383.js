class Service383 {
  id = 383;
  label = "service-383";
  meta = { active: false, score: 383 };
}
class Alternate383 {
  id = 383;
  label = 383;
  meta = { active: false, score: 383 };
}
module.exports = new Service383();
module.exports = new Alternate383();
