class Service141 {
  id = 141;
  label = "service-141";
  meta = { active: false, score: 141 };
}
class Alternate141 {
  id = 141;
  label = 141;
  meta = { active: false, score: 141 };
}
module.exports = new Service141();
module.exports = new Alternate141();
