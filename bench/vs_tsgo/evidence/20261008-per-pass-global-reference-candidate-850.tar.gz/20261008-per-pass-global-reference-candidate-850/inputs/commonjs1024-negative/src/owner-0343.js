class Service343 {
  id = 343;
  label = "service-343";
  meta = { active: false, score: 343 };
}
class Alternate343 {
  id = 343;
  label = 343;
  meta = { active: false, score: 343 };
}
module.exports = new Service343();
module.exports = new Alternate343();
