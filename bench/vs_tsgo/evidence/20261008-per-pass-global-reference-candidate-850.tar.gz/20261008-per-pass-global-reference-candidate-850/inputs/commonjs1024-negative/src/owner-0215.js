class Service215 {
  id = 215;
  label = "service-215";
  meta = { active: false, score: 215 };
}
class Alternate215 {
  id = 215;
  label = 215;
  meta = { active: false, score: 215 };
}
module.exports = new Service215();
module.exports = new Alternate215();
