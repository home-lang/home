class Service487 {
  id = 487;
  label = "service-487";
  meta = { active: false, score: 487 };
}
class Alternate487 {
  id = 487;
  label = 487;
  meta = { active: false, score: 487 };
}
module.exports = new Service487();
module.exports = new Alternate487();
