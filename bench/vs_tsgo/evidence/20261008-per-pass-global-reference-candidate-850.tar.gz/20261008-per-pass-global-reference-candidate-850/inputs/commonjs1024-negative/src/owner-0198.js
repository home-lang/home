class Service198 {
  id = 198;
  label = "service-198";
  meta = { active: true, score: 198 };
}
class Alternate198 {
  id = 198;
  label = 198;
  meta = { active: true, score: 198 };
}
module.exports = new Service198();
module.exports = new Alternate198();
