class Service240 {
  id = 240;
  label = "service-240";
  meta = { active: true, score: 240 };
}
class Alternate240 {
  id = 240;
  label = 240;
  meta = { active: true, score: 240 };
}
module.exports = new Service240();
module.exports = new Alternate240();
