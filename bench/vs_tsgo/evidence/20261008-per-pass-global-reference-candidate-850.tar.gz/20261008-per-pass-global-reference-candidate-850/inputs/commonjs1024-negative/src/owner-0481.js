class Service481 {
  id = 481;
  label = "service-481";
  meta = { active: false, score: 481 };
}
class Alternate481 {
  id = 481;
  label = 481;
  meta = { active: false, score: 481 };
}
module.exports = new Service481();
module.exports = new Alternate481();
