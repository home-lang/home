class Service336 {
  id = 336;
  label = "service-336";
  meta = { active: true, score: 336 };
}
class Alternate336 {
  id = 336;
  label = 336;
  meta = { active: true, score: 336 };
}
module.exports = new Service336();
module.exports = new Alternate336();
