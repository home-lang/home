class Service386 {
  id = 386;
  label = "service-386";
  meta = { active: true, score: 386 };
}
class Alternate386 {
  id = 386;
  label = 386;
  meta = { active: true, score: 386 };
}
module.exports = new Service386();
module.exports = new Alternate386();
