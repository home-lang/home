class Service302 {
  id = 302;
  label = "service-302";
  meta = { active: true, score: 302 };
}
class Alternate302 {
  id = 302;
  label = 302;
  meta = { active: true, score: 302 };
}
module.exports = new Service302();
module.exports = new Alternate302();
