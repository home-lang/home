class Service368 {
  id = 368;
  label = "service-368";
  meta = { active: true, score: 368 };
}
class Alternate368 {
  id = 368;
  label = 368;
  meta = { active: true, score: 368 };
}
module.exports = new Service368();
module.exports = new Alternate368();
