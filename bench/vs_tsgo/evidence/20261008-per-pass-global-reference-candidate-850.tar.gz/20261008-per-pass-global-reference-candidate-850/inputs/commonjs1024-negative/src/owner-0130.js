class Service130 {
  id = 130;
  label = "service-130";
  meta = { active: true, score: 130 };
}
class Alternate130 {
  id = 130;
  label = 130;
  meta = { active: true, score: 130 };
}
module.exports = new Service130();
module.exports = new Alternate130();
