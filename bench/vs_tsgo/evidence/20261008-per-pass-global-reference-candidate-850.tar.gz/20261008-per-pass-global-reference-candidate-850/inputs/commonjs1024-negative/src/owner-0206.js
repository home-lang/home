class Service206 {
  id = 206;
  label = "service-206";
  meta = { active: true, score: 206 };
}
class Alternate206 {
  id = 206;
  label = 206;
  meta = { active: true, score: 206 };
}
module.exports = new Service206();
module.exports = new Alternate206();
