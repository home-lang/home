class Service214 {
  id = 214;
  label = "service-214";
  meta = { active: true, score: 214 };
}
class Alternate214 {
  id = 214;
  label = 214;
  meta = { active: true, score: 214 };
}
module.exports = new Service214();
module.exports = new Alternate214();
