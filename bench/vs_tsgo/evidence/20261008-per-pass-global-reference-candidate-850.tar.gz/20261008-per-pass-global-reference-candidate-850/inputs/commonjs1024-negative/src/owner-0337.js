class Service337 {
  id = 337;
  label = "service-337";
  meta = { active: false, score: 337 };
}
class Alternate337 {
  id = 337;
  label = 337;
  meta = { active: false, score: 337 };
}
module.exports = new Service337();
module.exports = new Alternate337();
