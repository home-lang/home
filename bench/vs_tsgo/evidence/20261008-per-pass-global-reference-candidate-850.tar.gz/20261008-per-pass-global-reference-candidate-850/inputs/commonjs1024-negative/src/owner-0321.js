class Service321 {
  id = 321;
  label = "service-321";
  meta = { active: false, score: 321 };
}
class Alternate321 {
  id = 321;
  label = 321;
  meta = { active: false, score: 321 };
}
module.exports = new Service321();
module.exports = new Alternate321();
