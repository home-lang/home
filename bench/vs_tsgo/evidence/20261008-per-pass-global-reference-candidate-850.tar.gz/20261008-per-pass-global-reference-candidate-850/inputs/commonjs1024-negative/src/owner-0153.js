class Service153 {
  id = 153;
  label = "service-153";
  meta = { active: false, score: 153 };
}
class Alternate153 {
  id = 153;
  label = 153;
  meta = { active: false, score: 153 };
}
module.exports = new Service153();
module.exports = new Alternate153();
