class Service133 {
  id = 133;
  label = "service-133";
  meta = { active: false, score: 133 };
}
class Alternate133 {
  id = 133;
  label = 133;
  meta = { active: false, score: 133 };
}
module.exports = new Service133();
module.exports = new Alternate133();
