class Service207 {
  id = 207;
  label = "service-207";
  meta = { active: false, score: 207 };
}
class Alternate207 {
  id = 207;
  label = 207;
  meta = { active: false, score: 207 };
}
module.exports = new Service207();
module.exports = new Alternate207();
