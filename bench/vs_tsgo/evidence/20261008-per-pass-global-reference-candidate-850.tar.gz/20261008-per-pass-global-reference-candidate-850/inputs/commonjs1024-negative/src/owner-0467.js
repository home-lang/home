class Service467 {
  id = 467;
  label = "service-467";
  meta = { active: false, score: 467 };
}
class Alternate467 {
  id = 467;
  label = 467;
  meta = { active: false, score: 467 };
}
module.exports = new Service467();
module.exports = new Alternate467();
