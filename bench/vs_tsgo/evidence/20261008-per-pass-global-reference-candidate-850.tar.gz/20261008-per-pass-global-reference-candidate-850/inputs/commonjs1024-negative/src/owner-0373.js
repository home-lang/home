class Service373 {
  id = 373;
  label = "service-373";
  meta = { active: false, score: 373 };
}
class Alternate373 {
  id = 373;
  label = 373;
  meta = { active: false, score: 373 };
}
module.exports = new Service373();
module.exports = new Alternate373();
