class Service408 {
  id = 408;
  label = "service-408";
  meta = { active: true, score: 408 };
}
class Alternate408 {
  id = 408;
  label = 408;
  meta = { active: true, score: 408 };
}
module.exports = new Service408();
module.exports = new Alternate408();
