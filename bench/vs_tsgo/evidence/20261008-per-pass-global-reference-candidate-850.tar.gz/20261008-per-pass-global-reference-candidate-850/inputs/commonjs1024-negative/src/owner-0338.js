class Service338 {
  id = 338;
  label = "service-338";
  meta = { active: true, score: 338 };
}
class Alternate338 {
  id = 338;
  label = 338;
  meta = { active: true, score: 338 };
}
module.exports = new Service338();
module.exports = new Alternate338();
