class Service195 {
  id = 195;
  label = "service-195";
  meta = { active: false, score: 195 };
}
class Alternate195 {
  id = 195;
  label = 195;
  meta = { active: false, score: 195 };
}
module.exports = new Service195();
module.exports = new Alternate195();
