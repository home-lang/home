class Service315 {
  id = 315;
  label = "service-315";
  meta = { active: false, score: 315 };
}
class Alternate315 {
  id = 315;
  label = 315;
  meta = { active: false, score: 315 };
}
module.exports = new Service315();
module.exports = new Alternate315();
