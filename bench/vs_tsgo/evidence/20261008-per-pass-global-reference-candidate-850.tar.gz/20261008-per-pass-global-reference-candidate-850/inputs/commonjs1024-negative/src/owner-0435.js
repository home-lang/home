class Service435 {
  id = 435;
  label = "service-435";
  meta = { active: false, score: 435 };
}
class Alternate435 {
  id = 435;
  label = 435;
  meta = { active: false, score: 435 };
}
module.exports = new Service435();
module.exports = new Alternate435();
