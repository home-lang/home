class Service485 {
  id = 485;
  label = "service-485";
  meta = { active: false, score: 485 };
}
class Alternate485 {
  id = 485;
  label = 485;
  meta = { active: false, score: 485 };
}
module.exports = new Service485();
module.exports = new Alternate485();
