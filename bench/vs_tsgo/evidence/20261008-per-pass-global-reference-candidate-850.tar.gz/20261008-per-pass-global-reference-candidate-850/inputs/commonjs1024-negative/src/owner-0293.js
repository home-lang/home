class Service293 {
  id = 293;
  label = "service-293";
  meta = { active: false, score: 293 };
}
class Alternate293 {
  id = 293;
  label = 293;
  meta = { active: false, score: 293 };
}
module.exports = new Service293();
module.exports = new Alternate293();
