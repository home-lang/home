class Service345 {
  id = 345;
  label = "service-345";
  meta = { active: false, score: 345 };
}
class Alternate345 {
  id = 345;
  label = 345;
  meta = { active: false, score: 345 };
}
module.exports = new Service345();
module.exports = new Alternate345();
