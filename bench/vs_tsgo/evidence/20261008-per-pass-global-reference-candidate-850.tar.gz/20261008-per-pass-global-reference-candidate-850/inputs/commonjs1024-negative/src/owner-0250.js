class Service250 {
  id = 250;
  label = "service-250";
  meta = { active: true, score: 250 };
}
class Alternate250 {
  id = 250;
  label = 250;
  meta = { active: true, score: 250 };
}
module.exports = new Service250();
module.exports = new Alternate250();
