class Service267 {
  id = 267;
  label = "service-267";
  meta = { active: false, score: 267 };
}
class Alternate267 {
  id = 267;
  label = 267;
  meta = { active: false, score: 267 };
}
module.exports = new Service267();
module.exports = new Alternate267();
