class Service170 {
  id = 170;
  label = "service-170";
  meta = { active: true, score: 170 };
}
class Alternate170 {
  id = 170;
  label = 170;
  meta = { active: true, score: 170 };
}
module.exports = new Service170();
module.exports = new Alternate170();
