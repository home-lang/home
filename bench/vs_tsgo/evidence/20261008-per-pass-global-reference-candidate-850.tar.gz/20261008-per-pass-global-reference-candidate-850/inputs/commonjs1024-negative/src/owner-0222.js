class Service222 {
  id = 222;
  label = "service-222";
  meta = { active: true, score: 222 };
}
class Alternate222 {
  id = 222;
  label = 222;
  meta = { active: true, score: 222 };
}
module.exports = new Service222();
module.exports = new Alternate222();
