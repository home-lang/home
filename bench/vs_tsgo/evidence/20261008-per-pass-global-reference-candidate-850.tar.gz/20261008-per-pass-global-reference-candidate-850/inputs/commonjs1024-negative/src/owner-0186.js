class Service186 {
  id = 186;
  label = "service-186";
  meta = { active: true, score: 186 };
}
class Alternate186 {
  id = 186;
  label = 186;
  meta = { active: true, score: 186 };
}
module.exports = new Service186();
module.exports = new Alternate186();
