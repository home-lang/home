class Service173 {
  id = 173;
  label = "service-173";
  meta = { active: false, score: 173 };
}
class Alternate173 {
  id = 173;
  label = 173;
  meta = { active: false, score: 173 };
}
module.exports = new Service173();
module.exports = new Alternate173();
