class Service148 {
  id = 148;
  label = "service-148";
  meta = { active: true, score: 148 };
}
class Alternate148 {
  id = 148;
  label = 148;
  meta = { active: true, score: 148 };
}
module.exports = new Service148();
module.exports = new Alternate148();
