class Service318 {
  id = 318;
  label = "service-318";
  meta = { active: true, score: 318 };
}
class Alternate318 {
  id = 318;
  label = 318;
  meta = { active: true, score: 318 };
}
module.exports = new Service318();
module.exports = new Alternate318();
