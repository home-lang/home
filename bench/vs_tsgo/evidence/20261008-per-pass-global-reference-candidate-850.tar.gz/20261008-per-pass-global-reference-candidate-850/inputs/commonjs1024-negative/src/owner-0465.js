class Service465 {
  id = 465;
  label = "service-465";
  meta = { active: false, score: 465 };
}
class Alternate465 {
  id = 465;
  label = 465;
  meta = { active: false, score: 465 };
}
module.exports = new Service465();
module.exports = new Alternate465();
