class Service155 {
  id = 155;
  label = "service-155";
  meta = { active: false, score: 155 };
}
class Alternate155 {
  id = 155;
  label = 155;
  meta = { active: false, score: 155 };
}
module.exports = new Service155();
module.exports = new Alternate155();
