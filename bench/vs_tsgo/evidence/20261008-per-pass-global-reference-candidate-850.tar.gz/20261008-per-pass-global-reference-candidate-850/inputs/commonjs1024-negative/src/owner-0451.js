class Service451 {
  id = 451;
  label = "service-451";
  meta = { active: false, score: 451 };
}
class Alternate451 {
  id = 451;
  label = 451;
  meta = { active: false, score: 451 };
}
module.exports = new Service451();
module.exports = new Alternate451();
