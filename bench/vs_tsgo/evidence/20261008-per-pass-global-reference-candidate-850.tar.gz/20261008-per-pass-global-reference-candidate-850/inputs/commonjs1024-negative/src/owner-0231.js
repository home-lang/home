class Service231 {
  id = 231;
  label = "service-231";
  meta = { active: false, score: 231 };
}
class Alternate231 {
  id = 231;
  label = 231;
  meta = { active: false, score: 231 };
}
module.exports = new Service231();
module.exports = new Alternate231();
