class Service472 {
  id = 472;
  label = "service-472";
  meta = { active: true, score: 472 };
}
class Alternate472 {
  id = 472;
  label = 472;
  meta = { active: true, score: 472 };
}
module.exports = new Service472();
module.exports = new Alternate472();
