class Service288 {
  id = 288;
  label = "service-288";
  meta = { active: true, score: 288 };
}
class Alternate288 {
  id = 288;
  label = 288;
  meta = { active: true, score: 288 };
}
module.exports = new Service288();
module.exports = new Alternate288();
