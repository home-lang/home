class Service184 {
  id = 184;
  label = "service-184";
  meta = { active: true, score: 184 };
}
class Alternate184 {
  id = 184;
  label = 184;
  meta = { active: true, score: 184 };
}
module.exports = new Service184();
module.exports = new Alternate184();
