class Service460 {
  id = 460;
  label = "service-460";
  meta = { active: true, score: 460 };
}
class Alternate460 {
  id = 460;
  label = 460;
  meta = { active: true, score: 460 };
}
module.exports = new Service460();
module.exports = new Alternate460();
