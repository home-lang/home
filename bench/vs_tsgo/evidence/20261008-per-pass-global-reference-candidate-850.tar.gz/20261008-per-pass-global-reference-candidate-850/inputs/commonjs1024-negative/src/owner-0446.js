class Service446 {
  id = 446;
  label = "service-446";
  meta = { active: true, score: 446 };
}
class Alternate446 {
  id = 446;
  label = 446;
  meta = { active: true, score: 446 };
}
module.exports = new Service446();
module.exports = new Alternate446();
