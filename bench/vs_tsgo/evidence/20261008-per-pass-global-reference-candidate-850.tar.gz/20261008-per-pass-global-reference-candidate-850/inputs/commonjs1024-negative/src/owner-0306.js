class Service306 {
  id = 306;
  label = "service-306";
  meta = { active: true, score: 306 };
}
class Alternate306 {
  id = 306;
  label = 306;
  meta = { active: true, score: 306 };
}
module.exports = new Service306();
module.exports = new Alternate306();
