class Service300 {
  id = 300;
  label = "service-300";
  meta = { active: true, score: 300 };
}
class Alternate300 {
  id = 300;
  label = 300;
  meta = { active: true, score: 300 };
}
module.exports = new Service300();
module.exports = new Alternate300();
