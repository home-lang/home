class Service308 {
  id = 308;
  label = "service-308";
  meta = { active: true, score: 308 };
}
class Alternate308 {
  id = 308;
  label = 308;
  meta = { active: true, score: 308 };
}
module.exports = new Service308();
module.exports = new Alternate308();
