class Service268 {
  id = 268;
  label = "service-268";
  meta = { active: true, score: 268 };
}
class Alternate268 {
  id = 268;
  label = 268;
  meta = { active: true, score: 268 };
}
module.exports = new Service268();
module.exports = new Alternate268();
