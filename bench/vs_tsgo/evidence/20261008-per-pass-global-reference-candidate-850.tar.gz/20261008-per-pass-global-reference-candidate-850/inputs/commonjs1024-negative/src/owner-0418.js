class Service418 {
  id = 418;
  label = "service-418";
  meta = { active: true, score: 418 };
}
class Alternate418 {
  id = 418;
  label = 418;
  meta = { active: true, score: 418 };
}
module.exports = new Service418();
module.exports = new Alternate418();
