class Service362 {
  id = 362;
  label = "service-362";
  meta = { active: true, score: 362 };
}
class Alternate362 {
  id = 362;
  label = 362;
  meta = { active: true, score: 362 };
}
module.exports = new Service362();
module.exports = new Alternate362();
