class Service378 {
  id = 378;
  label = "service-378";
  meta = { active: true, score: 378 };
}
class Alternate378 {
  id = 378;
  label = 378;
  meta = { active: true, score: 378 };
}
module.exports = new Service378();
module.exports = new Alternate378();
