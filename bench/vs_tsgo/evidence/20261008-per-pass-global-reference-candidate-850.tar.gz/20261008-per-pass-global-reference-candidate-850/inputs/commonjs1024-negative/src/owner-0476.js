class Service476 {
  id = 476;
  label = "service-476";
  meta = { active: true, score: 476 };
}
class Alternate476 {
  id = 476;
  label = 476;
  meta = { active: true, score: 476 };
}
module.exports = new Service476();
module.exports = new Alternate476();
