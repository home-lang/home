class Service139 {
  id = 139;
  label = "service-139";
  meta = { active: false, score: 139 };
}
class Alternate139 {
  id = 139;
  label = 139;
  meta = { active: false, score: 139 };
}
module.exports = new Service139();
module.exports = new Alternate139();
