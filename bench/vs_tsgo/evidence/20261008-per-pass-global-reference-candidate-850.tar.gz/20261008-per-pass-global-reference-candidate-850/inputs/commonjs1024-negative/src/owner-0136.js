class Service136 {
  id = 136;
  label = "service-136";
  meta = { active: true, score: 136 };
}
class Alternate136 {
  id = 136;
  label = 136;
  meta = { active: true, score: 136 };
}
module.exports = new Service136();
module.exports = new Alternate136();
