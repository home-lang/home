class Service380 {
  id = 380;
  label = "service-380";
  meta = { active: true, score: 380 };
}
class Alternate380 {
  id = 380;
  label = 380;
  meta = { active: true, score: 380 };
}
module.exports = new Service380();
module.exports = new Alternate380();
