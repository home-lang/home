class Service196 {
  id = 196;
  label = "service-196";
  meta = { active: true, score: 196 };
}
class Alternate196 {
  id = 196;
  label = 196;
  meta = { active: true, score: 196 };
}
module.exports = new Service196();
module.exports = new Alternate196();
