class Service470 {
  id = 470;
  label = "service-470";
  meta = { active: true, score: 470 };
}
class Alternate470 {
  id = 470;
  label = 470;
  meta = { active: true, score: 470 };
}
module.exports = new Service470();
module.exports = new Alternate470();
