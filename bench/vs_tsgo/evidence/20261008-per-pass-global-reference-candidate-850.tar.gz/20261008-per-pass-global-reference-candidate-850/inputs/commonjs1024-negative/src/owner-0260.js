class Service260 {
  id = 260;
  label = "service-260";
  meta = { active: true, score: 260 };
}
class Alternate260 {
  id = 260;
  label = 260;
  meta = { active: true, score: 260 };
}
module.exports = new Service260();
module.exports = new Alternate260();
