class Service333 {
  id = 333;
  label = "service-333";
  meta = { active: false, score: 333 };
}
class Alternate333 {
  id = 333;
  label = 333;
  meta = { active: false, score: 333 };
}
module.exports = new Service333();
module.exports = new Alternate333();
