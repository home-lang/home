class Service247 {
  id = 247;
  label = "service-247";
  meta = { active: false, score: 247 };
}
class Alternate247 {
  id = 247;
  label = 247;
  meta = { active: false, score: 247 };
}
module.exports = new Service247();
module.exports = new Alternate247();
