class Service160 {
  id = 160;
  label = "service-160";
  meta = { active: true, score: 160 };
}
class Alternate160 {
  id = 160;
  label = 160;
  meta = { active: true, score: 160 };
}
module.exports = new Service160();
module.exports = new Alternate160();
