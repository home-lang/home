class Service140 {
  id = 140;
  label = "service-140";
  meta = { active: true, score: 140 };
}
class Alternate140 {
  id = 140;
  label = 140;
  meta = { active: true, score: 140 };
}
module.exports = new Service140();
module.exports = new Alternate140();
