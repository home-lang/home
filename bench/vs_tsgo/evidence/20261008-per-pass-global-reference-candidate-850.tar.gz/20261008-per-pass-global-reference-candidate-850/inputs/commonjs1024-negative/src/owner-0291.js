class Service291 {
  id = 291;
  label = "service-291";
  meta = { active: false, score: 291 };
}
class Alternate291 {
  id = 291;
  label = 291;
  meta = { active: false, score: 291 };
}
module.exports = new Service291();
module.exports = new Alternate291();
