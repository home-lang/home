class Service154 {
  id = 154;
  label = "service-154";
  meta = { active: true, score: 154 };
}
class Alternate154 {
  id = 154;
  label = 154;
  meta = { active: true, score: 154 };
}
module.exports = new Service154();
module.exports = new Alternate154();
