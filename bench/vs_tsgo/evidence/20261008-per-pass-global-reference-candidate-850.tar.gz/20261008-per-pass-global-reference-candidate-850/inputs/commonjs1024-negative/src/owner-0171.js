class Service171 {
  id = 171;
  label = "service-171";
  meta = { active: false, score: 171 };
}
class Alternate171 {
  id = 171;
  label = 171;
  meta = { active: false, score: 171 };
}
module.exports = new Service171();
module.exports = new Alternate171();
