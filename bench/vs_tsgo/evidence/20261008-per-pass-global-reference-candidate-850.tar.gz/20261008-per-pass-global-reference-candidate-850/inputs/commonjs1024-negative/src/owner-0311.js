class Service311 {
  id = 311;
  label = "service-311";
  meta = { active: false, score: 311 };
}
class Alternate311 {
  id = 311;
  label = 311;
  meta = { active: false, score: 311 };
}
module.exports = new Service311();
module.exports = new Alternate311();
