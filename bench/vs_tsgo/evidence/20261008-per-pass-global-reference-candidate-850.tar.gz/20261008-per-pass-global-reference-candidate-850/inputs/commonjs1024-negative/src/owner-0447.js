class Service447 {
  id = 447;
  label = "service-447";
  meta = { active: false, score: 447 };
}
class Alternate447 {
  id = 447;
  label = 447;
  meta = { active: false, score: 447 };
}
module.exports = new Service447();
module.exports = new Alternate447();
