class Service374 {
  id = 374;
  label = "service-374";
  meta = { active: true, score: 374 };
}
class Alternate374 {
  id = 374;
  label = 374;
  meta = { active: true, score: 374 };
}
module.exports = new Service374();
module.exports = new Alternate374();
