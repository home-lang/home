class Service187 {
  id = 187;
  label = "service-187";
  meta = { active: false, score: 187 };
}
class Alternate187 {
  id = 187;
  label = 187;
  meta = { active: false, score: 187 };
}
module.exports = new Service187();
module.exports = new Alternate187();
