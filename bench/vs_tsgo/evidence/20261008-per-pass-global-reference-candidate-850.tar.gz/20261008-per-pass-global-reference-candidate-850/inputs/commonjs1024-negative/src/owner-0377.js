class Service377 {
  id = 377;
  label = "service-377";
  meta = { active: false, score: 377 };
}
class Alternate377 {
  id = 377;
  label = 377;
  meta = { active: false, score: 377 };
}
module.exports = new Service377();
module.exports = new Alternate377();
