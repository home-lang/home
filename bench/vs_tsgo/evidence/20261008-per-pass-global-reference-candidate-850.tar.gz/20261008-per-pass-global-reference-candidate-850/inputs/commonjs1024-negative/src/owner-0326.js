class Service326 {
  id = 326;
  label = "service-326";
  meta = { active: true, score: 326 };
}
class Alternate326 {
  id = 326;
  label = 326;
  meta = { active: true, score: 326 };
}
module.exports = new Service326();
module.exports = new Alternate326();
