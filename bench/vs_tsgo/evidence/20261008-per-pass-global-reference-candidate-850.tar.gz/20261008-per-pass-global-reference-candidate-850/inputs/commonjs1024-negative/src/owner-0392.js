class Service392 {
  id = 392;
  label = "service-392";
  meta = { active: true, score: 392 };
}
class Alternate392 {
  id = 392;
  label = 392;
  meta = { active: true, score: 392 };
}
module.exports = new Service392();
module.exports = new Alternate392();
