class Service400 {
  id = 400;
  label = "service-400";
  meta = { active: true, score: 400 };
}
class Alternate400 {
  id = 400;
  label = 400;
  meta = { active: true, score: 400 };
}
module.exports = new Service400();
module.exports = new Alternate400();
