class Service285 {
  id = 285;
  label = "service-285";
  meta = { active: false, score: 285 };
}
class Alternate285 {
  id = 285;
  label = 285;
  meta = { active: false, score: 285 };
}
module.exports = new Service285();
module.exports = new Alternate285();
