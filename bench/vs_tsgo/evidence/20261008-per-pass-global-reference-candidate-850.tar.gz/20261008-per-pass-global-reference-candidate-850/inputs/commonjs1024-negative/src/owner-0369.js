class Service369 {
  id = 369;
  label = "service-369";
  meta = { active: false, score: 369 };
}
class Alternate369 {
  id = 369;
  label = 369;
  meta = { active: false, score: 369 };
}
module.exports = new Service369();
module.exports = new Alternate369();
