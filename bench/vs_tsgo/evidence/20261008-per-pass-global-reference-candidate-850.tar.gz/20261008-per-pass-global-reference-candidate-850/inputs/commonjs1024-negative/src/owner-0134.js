class Service134 {
  id = 134;
  label = "service-134";
  meta = { active: true, score: 134 };
}
class Alternate134 {
  id = 134;
  label = 134;
  meta = { active: true, score: 134 };
}
module.exports = new Service134();
module.exports = new Alternate134();
