class Service294 {
  id = 294;
  label = "service-294";
  meta = { active: true, score: 294 };
}
class Alternate294 {
  id = 294;
  label = 294;
  meta = { active: true, score: 294 };
}
module.exports = new Service294();
module.exports = new Alternate294();
