class Service366 {
  id = 366;
  label = "service-366";
  meta = { active: true, score: 366 };
}
class Alternate366 {
  id = 366;
  label = 366;
  meta = { active: true, score: 366 };
}
module.exports = new Service366();
module.exports = new Alternate366();
