class Service272 {
  id = 272;
  label = "service-272";
  meta = { active: true, score: 272 };
}
class Alternate272 {
  id = 272;
  label = 272;
  meta = { active: true, score: 272 };
}
module.exports = new Service272();
module.exports = new Alternate272();
