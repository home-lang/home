class Service407 {
  id = 407;
  label = "service-407";
  meta = { active: false, score: 407 };
}
class Alternate407 {
  id = 407;
  label = 407;
  meta = { active: false, score: 407 };
}
module.exports = new Service407();
module.exports = new Alternate407();
