class Service391 {
  id = 391;
  label = "service-391";
  meta = { active: false, score: 391 };
}
class Alternate391 {
  id = 391;
  label = 391;
  meta = { active: false, score: 391 };
}
module.exports = new Service391();
module.exports = new Alternate391();
