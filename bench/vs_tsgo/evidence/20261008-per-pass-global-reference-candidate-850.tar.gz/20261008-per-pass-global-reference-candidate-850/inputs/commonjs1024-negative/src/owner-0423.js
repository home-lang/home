class Service423 {
  id = 423;
  label = "service-423";
  meta = { active: false, score: 423 };
}
class Alternate423 {
  id = 423;
  label = 423;
  meta = { active: false, score: 423 };
}
module.exports = new Service423();
module.exports = new Alternate423();
