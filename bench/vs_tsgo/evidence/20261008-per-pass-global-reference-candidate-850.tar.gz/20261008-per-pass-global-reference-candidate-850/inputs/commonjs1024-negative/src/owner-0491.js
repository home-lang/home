class Service491 {
  id = 491;
  label = "service-491";
  meta = { active: false, score: 491 };
}
class Alternate491 {
  id = 491;
  label = 491;
  meta = { active: false, score: 491 };
}
module.exports = new Service491();
module.exports = new Alternate491();
