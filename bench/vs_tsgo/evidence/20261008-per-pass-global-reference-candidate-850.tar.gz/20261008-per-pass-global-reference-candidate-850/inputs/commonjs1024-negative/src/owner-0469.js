class Service469 {
  id = 469;
  label = "service-469";
  meta = { active: false, score: 469 };
}
class Alternate469 {
  id = 469;
  label = 469;
  meta = { active: false, score: 469 };
}
module.exports = new Service469();
module.exports = new Alternate469();
