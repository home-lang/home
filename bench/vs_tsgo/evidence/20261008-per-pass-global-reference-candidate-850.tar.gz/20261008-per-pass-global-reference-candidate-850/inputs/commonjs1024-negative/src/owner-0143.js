class Service143 {
  id = 143;
  label = "service-143";
  meta = { active: false, score: 143 };
}
class Alternate143 {
  id = 143;
  label = 143;
  meta = { active: false, score: 143 };
}
module.exports = new Service143();
module.exports = new Alternate143();
