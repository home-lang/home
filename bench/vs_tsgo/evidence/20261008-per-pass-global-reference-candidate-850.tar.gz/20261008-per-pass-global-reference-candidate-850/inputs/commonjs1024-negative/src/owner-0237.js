class Service237 {
  id = 237;
  label = "service-237";
  meta = { active: false, score: 237 };
}
class Alternate237 {
  id = 237;
  label = 237;
  meta = { active: false, score: 237 };
}
module.exports = new Service237();
module.exports = new Alternate237();
