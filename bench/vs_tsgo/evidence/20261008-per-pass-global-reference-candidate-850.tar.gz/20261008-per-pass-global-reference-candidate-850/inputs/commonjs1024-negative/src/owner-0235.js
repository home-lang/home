class Service235 {
  id = 235;
  label = "service-235";
  meta = { active: false, score: 235 };
}
class Alternate235 {
  id = 235;
  label = 235;
  meta = { active: false, score: 235 };
}
module.exports = new Service235();
module.exports = new Alternate235();
