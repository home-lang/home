class Service384 {
  id = 384;
  label = "service-384";
  meta = { active: true, score: 384 };
}
class Alternate384 {
  id = 384;
  label = 384;
  meta = { active: true, score: 384 };
}
module.exports = new Service384();
module.exports = new Alternate384();
