class Service201 {
  id = 201;
  label = "service-201";
  meta = { active: false, score: 201 };
}
class Alternate201 {
  id = 201;
  label = 201;
  meta = { active: false, score: 201 };
}
module.exports = new Service201();
module.exports = new Alternate201();
