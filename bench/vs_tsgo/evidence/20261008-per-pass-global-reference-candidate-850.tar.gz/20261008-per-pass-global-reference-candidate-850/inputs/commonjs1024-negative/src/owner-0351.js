class Service351 {
  id = 351;
  label = "service-351";
  meta = { active: false, score: 351 };
}
class Alternate351 {
  id = 351;
  label = 351;
  meta = { active: false, score: 351 };
}
module.exports = new Service351();
module.exports = new Alternate351();
