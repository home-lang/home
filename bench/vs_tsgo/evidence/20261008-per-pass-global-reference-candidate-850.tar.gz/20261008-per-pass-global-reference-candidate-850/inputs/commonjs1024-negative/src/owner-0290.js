class Service290 {
  id = 290;
  label = "service-290";
  meta = { active: true, score: 290 };
}
class Alternate290 {
  id = 290;
  label = 290;
  meta = { active: true, score: 290 };
}
module.exports = new Service290();
module.exports = new Alternate290();
