class Service232 {
  id = 232;
  label = "service-232";
  meta = { active: true, score: 232 };
}
class Alternate232 {
  id = 232;
  label = 232;
  meta = { active: true, score: 232 };
}
module.exports = new Service232();
module.exports = new Alternate232();
