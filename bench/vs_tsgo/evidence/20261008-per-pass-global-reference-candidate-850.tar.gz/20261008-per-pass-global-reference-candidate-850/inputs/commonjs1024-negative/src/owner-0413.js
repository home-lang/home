class Service413 {
  id = 413;
  label = "service-413";
  meta = { active: false, score: 413 };
}
class Alternate413 {
  id = 413;
  label = 413;
  meta = { active: false, score: 413 };
}
module.exports = new Service413();
module.exports = new Alternate413();
