class Service303 {
  id = 303;
  label = "service-303";
  meta = { active: false, score: 303 };
}
class Alternate303 {
  id = 303;
  label = 303;
  meta = { active: false, score: 303 };
}
module.exports = new Service303();
module.exports = new Alternate303();
