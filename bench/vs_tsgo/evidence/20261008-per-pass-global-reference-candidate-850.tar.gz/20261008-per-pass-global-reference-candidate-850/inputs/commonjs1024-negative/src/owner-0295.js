class Service295 {
  id = 295;
  label = "service-295";
  meta = { active: false, score: 295 };
}
class Alternate295 {
  id = 295;
  label = 295;
  meta = { active: false, score: 295 };
}
module.exports = new Service295();
module.exports = new Alternate295();
