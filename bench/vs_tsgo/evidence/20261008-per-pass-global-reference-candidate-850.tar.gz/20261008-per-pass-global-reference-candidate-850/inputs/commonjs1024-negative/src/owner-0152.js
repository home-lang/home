class Service152 {
  id = 152;
  label = "service-152";
  meta = { active: true, score: 152 };
}
class Alternate152 {
  id = 152;
  label = 152;
  meta = { active: true, score: 152 };
}
module.exports = new Service152();
module.exports = new Alternate152();
