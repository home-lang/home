class Service233 {
  id = 233;
  label = "service-233";
  meta = { active: false, score: 233 };
}
class Alternate233 {
  id = 233;
  label = 233;
  meta = { active: false, score: 233 };
}
module.exports = new Service233();
module.exports = new Alternate233();
