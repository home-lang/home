class Service421 {
  id = 421;
  label = "service-421";
  meta = { active: false, score: 421 };
}
class Alternate421 {
  id = 421;
  label = 421;
  meta = { active: false, score: 421 };
}
module.exports = new Service421();
module.exports = new Alternate421();
