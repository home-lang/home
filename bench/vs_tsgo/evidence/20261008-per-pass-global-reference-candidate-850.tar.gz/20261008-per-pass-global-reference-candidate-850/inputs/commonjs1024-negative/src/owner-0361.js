class Service361 {
  id = 361;
  label = "service-361";
  meta = { active: false, score: 361 };
}
class Alternate361 {
  id = 361;
  label = 361;
  meta = { active: false, score: 361 };
}
module.exports = new Service361();
module.exports = new Alternate361();
