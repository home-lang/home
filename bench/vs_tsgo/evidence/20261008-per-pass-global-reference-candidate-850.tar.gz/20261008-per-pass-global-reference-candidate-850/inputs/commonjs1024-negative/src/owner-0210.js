class Service210 {
  id = 210;
  label = "service-210";
  meta = { active: true, score: 210 };
}
class Alternate210 {
  id = 210;
  label = 210;
  meta = { active: true, score: 210 };
}
module.exports = new Service210();
module.exports = new Alternate210();
