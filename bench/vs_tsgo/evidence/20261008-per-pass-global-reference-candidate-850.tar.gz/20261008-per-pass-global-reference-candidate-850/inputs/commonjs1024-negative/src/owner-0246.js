class Service246 {
  id = 246;
  label = "service-246";
  meta = { active: true, score: 246 };
}
class Alternate246 {
  id = 246;
  label = 246;
  meta = { active: true, score: 246 };
}
module.exports = new Service246();
module.exports = new Alternate246();
