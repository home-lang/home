class Service443 {
  id = 443;
  label = "service-443";
  meta = { active: false, score: 443 };
}
class Alternate443 {
  id = 443;
  label = 443;
  meta = { active: false, score: 443 };
}
module.exports = new Service443();
module.exports = new Alternate443();
