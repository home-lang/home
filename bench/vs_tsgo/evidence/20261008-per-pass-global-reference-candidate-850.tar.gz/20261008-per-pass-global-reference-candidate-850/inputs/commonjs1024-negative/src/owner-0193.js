class Service193 {
  id = 193;
  label = "service-193";
  meta = { active: false, score: 193 };
}
class Alternate193 {
  id = 193;
  label = 193;
  meta = { active: false, score: 193 };
}
module.exports = new Service193();
module.exports = new Alternate193();
