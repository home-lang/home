class Service430 {
  id = 430;
  label = "service-430";
  meta = { active: true, score: 430 };
}
class Alternate430 {
  id = 430;
  label = 430;
  meta = { active: true, score: 430 };
}
module.exports = new Service430();
module.exports = new Alternate430();
