class Service255 {
  id = 255;
  label = "service-255";
  meta = { active: false, score: 255 };
}
class Alternate255 {
  id = 255;
  label = 255;
  meta = { active: false, score: 255 };
}
module.exports = new Service255();
module.exports = new Alternate255();
