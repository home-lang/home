class Service426 {
  id = 426;
  label = "service-426";
  meta = { active: true, score: 426 };
}
class Alternate426 {
  id = 426;
  label = 426;
  meta = { active: true, score: 426 };
}
module.exports = new Service426();
module.exports = new Alternate426();
