class Service325 {
  id = 325;
  label = "service-325";
  meta = { active: false, score: 325 };
}
class Alternate325 {
  id = 325;
  label = 325;
  meta = { active: false, score: 325 };
}
module.exports = new Service325();
module.exports = new Alternate325();
