class Service356 {
  id = 356;
  label = "service-356";
  meta = { active: true, score: 356 };
}
class Alternate356 {
  id = 356;
  label = 356;
  meta = { active: true, score: 356 };
}
module.exports = new Service356();
module.exports = new Alternate356();
