class Service167 {
  id = 167;
  label = "service-167";
  meta = { active: false, score: 167 };
}
class Alternate167 {
  id = 167;
  label = 167;
  meta = { active: false, score: 167 };
}
module.exports = new Service167();
module.exports = new Alternate167();
