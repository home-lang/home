class Service163 {
  id = 163;
  label = "service-163";
  meta = { active: false, score: 163 };
}
class Alternate163 {
  id = 163;
  label = 163;
  meta = { active: false, score: 163 };
}
module.exports = new Service163();
module.exports = new Alternate163();
