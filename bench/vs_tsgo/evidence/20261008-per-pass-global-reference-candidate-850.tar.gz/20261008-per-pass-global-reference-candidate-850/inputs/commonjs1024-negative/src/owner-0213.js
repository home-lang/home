class Service213 {
  id = 213;
  label = "service-213";
  meta = { active: false, score: 213 };
}
class Alternate213 {
  id = 213;
  label = 213;
  meta = { active: false, score: 213 };
}
module.exports = new Service213();
module.exports = new Alternate213();
