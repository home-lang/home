class Service371 {
  id = 371;
  label = "service-371";
  meta = { active: false, score: 371 };
}
class Alternate371 {
  id = 371;
  label = 371;
  meta = { active: false, score: 371 };
}
module.exports = new Service371();
module.exports = new Alternate371();
