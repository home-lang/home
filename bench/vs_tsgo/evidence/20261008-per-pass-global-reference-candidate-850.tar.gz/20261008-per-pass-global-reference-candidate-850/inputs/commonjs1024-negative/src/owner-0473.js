class Service473 {
  id = 473;
  label = "service-473";
  meta = { active: false, score: 473 };
}
class Alternate473 {
  id = 473;
  label = 473;
  meta = { active: false, score: 473 };
}
module.exports = new Service473();
module.exports = new Alternate473();
