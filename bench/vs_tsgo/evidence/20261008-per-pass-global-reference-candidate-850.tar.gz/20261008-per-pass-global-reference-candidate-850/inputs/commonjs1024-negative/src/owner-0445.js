class Service445 {
  id = 445;
  label = "service-445";
  meta = { active: false, score: 445 };
}
class Alternate445 {
  id = 445;
  label = 445;
  meta = { active: false, score: 445 };
}
module.exports = new Service445();
module.exports = new Alternate445();
