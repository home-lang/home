class Service287 {
  id = 287;
  label = "service-287";
  meta = { active: false, score: 287 };
}
class Alternate287 {
  id = 287;
  label = 287;
  meta = { active: false, score: 287 };
}
module.exports = new Service287();
module.exports = new Alternate287();
