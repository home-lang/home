class Service480 {
  id = 480;
  label = "service-480";
  meta = { active: true, score: 480 };
}
class Alternate480 {
  id = 480;
  label = 480;
  meta = { active: true, score: 480 };
}
module.exports = new Service480();
module.exports = new Alternate480();
