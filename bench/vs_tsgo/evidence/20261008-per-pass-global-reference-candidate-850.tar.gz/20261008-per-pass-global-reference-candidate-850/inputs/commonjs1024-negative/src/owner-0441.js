class Service441 {
  id = 441;
  label = "service-441";
  meta = { active: false, score: 441 };
}
class Alternate441 {
  id = 441;
  label = 441;
  meta = { active: false, score: 441 };
}
module.exports = new Service441();
module.exports = new Alternate441();
