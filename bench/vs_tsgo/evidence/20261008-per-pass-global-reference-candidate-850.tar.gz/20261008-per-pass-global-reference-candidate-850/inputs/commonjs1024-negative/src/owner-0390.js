class Service390 {
  id = 390;
  label = "service-390";
  meta = { active: true, score: 390 };
}
class Alternate390 {
  id = 390;
  label = 390;
  meta = { active: true, score: 390 };
}
module.exports = new Service390();
module.exports = new Alternate390();
