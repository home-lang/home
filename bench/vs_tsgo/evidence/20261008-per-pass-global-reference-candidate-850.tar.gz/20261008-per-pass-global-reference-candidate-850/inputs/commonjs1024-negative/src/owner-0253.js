class Service253 {
  id = 253;
  label = "service-253";
  meta = { active: false, score: 253 };
}
class Alternate253 {
  id = 253;
  label = 253;
  meta = { active: false, score: 253 };
}
module.exports = new Service253();
module.exports = new Alternate253();
