class Service320 {
  id = 320;
  label = "service-320";
  meta = { active: true, score: 320 };
}
class Alternate320 {
  id = 320;
  label = 320;
  meta = { active: true, score: 320 };
}
module.exports = new Service320();
module.exports = new Alternate320();
