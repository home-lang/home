class Service165 {
  id = 165;
  label = "service-165";
  meta = { active: false, score: 165 };
}
class Alternate165 {
  id = 165;
  label = 165;
  meta = { active: false, score: 165 };
}
module.exports = new Service165();
module.exports = new Alternate165();
