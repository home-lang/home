class Service317 {
  id = 317;
  label = "service-317";
  meta = { active: false, score: 317 };
}
class Alternate317 {
  id = 317;
  label = 317;
  meta = { active: false, score: 317 };
}
module.exports = new Service317();
module.exports = new Alternate317();
