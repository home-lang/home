class Service422 {
  id = 422;
  label = "service-422";
  meta = { active: true, score: 422 };
}
class Alternate422 {
  id = 422;
  label = 422;
  meta = { active: true, score: 422 };
}
module.exports = new Service422();
module.exports = new Alternate422();
