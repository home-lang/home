class Service190 {
  id = 190;
  label = "service-190";
  meta = { active: true, score: 190 };
}
class Alternate190 {
  id = 190;
  label = 190;
  meta = { active: true, score: 190 };
}
module.exports = new Service190();
module.exports = new Alternate190();
