class Service416 {
  id = 416;
  label = "service-416";
  meta = { active: true, score: 416 };
}
class Alternate416 {
  id = 416;
  label = 416;
  meta = { active: true, score: 416 };
}
module.exports = new Service416();
module.exports = new Alternate416();
