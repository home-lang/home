class Service365 {
  id = 365;
  label = "service-365";
  meta = { active: false, score: 365 };
}
class Alternate365 {
  id = 365;
  label = 365;
  meta = { active: false, score: 365 };
}
module.exports = new Service365();
module.exports = new Alternate365();
