class Service264 {
  id = 264;
  label = "service-264";
  meta = { active: true, score: 264 };
}
class Alternate264 {
  id = 264;
  label = 264;
  meta = { active: true, score: 264 };
}
module.exports = new Service264();
module.exports = new Alternate264();
