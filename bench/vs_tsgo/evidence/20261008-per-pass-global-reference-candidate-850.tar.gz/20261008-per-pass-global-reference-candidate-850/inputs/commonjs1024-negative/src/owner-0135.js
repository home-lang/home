class Service135 {
  id = 135;
  label = "service-135";
  meta = { active: false, score: 135 };
}
class Alternate135 {
  id = 135;
  label = 135;
  meta = { active: false, score: 135 };
}
module.exports = new Service135();
module.exports = new Alternate135();
