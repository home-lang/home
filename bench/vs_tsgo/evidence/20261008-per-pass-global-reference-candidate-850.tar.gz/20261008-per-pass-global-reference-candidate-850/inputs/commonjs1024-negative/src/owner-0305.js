class Service305 {
  id = 305;
  label = "service-305";
  meta = { active: false, score: 305 };
}
class Alternate305 {
  id = 305;
  label = 305;
  meta = { active: false, score: 305 };
}
module.exports = new Service305();
module.exports = new Alternate305();
