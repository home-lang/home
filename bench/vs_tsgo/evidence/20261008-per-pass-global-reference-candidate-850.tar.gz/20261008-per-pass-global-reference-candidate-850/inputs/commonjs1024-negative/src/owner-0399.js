class Service399 {
  id = 399;
  label = "service-399";
  meta = { active: false, score: 399 };
}
class Alternate399 {
  id = 399;
  label = 399;
  meta = { active: false, score: 399 };
}
module.exports = new Service399();
module.exports = new Alternate399();
