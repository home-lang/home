class Service278 {
  id = 278;
  label = "service-278";
  meta = { active: true, score: 278 };
}
class Alternate278 {
  id = 278;
  label = 278;
  meta = { active: true, score: 278 };
}
module.exports = new Service278();
module.exports = new Alternate278();
