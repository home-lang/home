class Service168 {
  id = 168;
  label = "service-168";
  meta = { active: true, score: 168 };
}
class Alternate168 {
  id = 168;
  label = 168;
  meta = { active: true, score: 168 };
}
module.exports = new Service168();
module.exports = new Alternate168();
