class Service396 {
  id = 396;
  label = "service-396";
  meta = { active: true, score: 396 };
}
class Alternate396 {
  id = 396;
  label = 396;
  meta = { active: true, score: 396 };
}
module.exports = new Service396();
module.exports = new Alternate396();
