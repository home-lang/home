class Service436 {
  id = 436;
  label = "service-436";
  meta = { active: true, score: 436 };
}
class Alternate436 {
  id = 436;
  label = 436;
  meta = { active: true, score: 436 };
}
module.exports = new Service436();
module.exports = new Alternate436();
