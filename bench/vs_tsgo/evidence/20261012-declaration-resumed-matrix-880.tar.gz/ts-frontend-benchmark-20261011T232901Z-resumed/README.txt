This is a paused, resumed matrix, not an uninterrupted measurement.
Top-level rounds may assemble immutable original and supplementary samples.
Original checkpoint, raw Hyperfine segments, phase records and warmups are retained under lineage/.
Every evidence file is byte-for-byte; metadata retains local paths to preserve lineage hashes.
Both complete protocol and immutable no-repeat lineage were verified before packaging.
