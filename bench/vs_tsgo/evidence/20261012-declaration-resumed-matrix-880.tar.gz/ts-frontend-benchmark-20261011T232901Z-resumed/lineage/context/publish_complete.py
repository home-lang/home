"""Publish only a complete independently verified continuation; never overwrite."""
import contextlib
import hashlib
import io
import json
from pathlib import Path
import statistics
import shutil
import sys
import tarfile

implementation = Path('/Users/chris/.codex/worktrees/ts863-qualification-docs/lang')
sys.path.insert(0, str(implementation / 'bench/vs_tsgo'))
import run
import compare
import checkpoint

output = implementation / 'bench/vs_tsgo/results/20261011T232901Z-resumed'
metadata = json.loads((output / 'metadata.json').read_bytes())
checkpoint.validate_lineage(output, metadata)
compare.validate_interleaved_rounds(output, metadata)
publisher_copy = output / 'lineage/context/publish_complete.py'
if publisher_copy.exists():
    raise ValueError('Do not overwrite publisher context')
shutil.copy2(Path(__file__), publisher_copy)
phases = list(dict.fromkeys(row['workload'] for row in json.loads((output / 'lineage/plan.json').read_bytes())['unrecorded_slots']))
for name in phases:
    terminal = json.loads((output / 'lineage/guards' / (name + '.json')).read_bytes())
    if terminal.get('exit') != 0:
        raise ValueError('Nonzero guard terminal: ' + name)
names = list(metadata['compilers'])
rows = {}
for workload in metadata['workloads']:
    samples = {name: [] for name in names}
    for index in range(metadata['runs']):
        for row in json.loads((output / f'{workload}-round-{index:03d}.json').read_bytes())['results']:
            samples[row['command'].split(' ', 1)[0]] += row['times']
    rows[workload] = {name: statistics.median(samples[name]) for name in names}
summary = {'rounds': len(rows) * metadata['runs'], 'samples': len(rows) * metadata['runs'] * len(names),
           'admissions': metadata['admission']['records'], 'compiler_versions': metadata['compilers'],
           'host': metadata['host'], 'measurement_pause': True, 'recorded_samples_repeated': 0,
           'home_lowest_medians': sum(row['home'] < min(v for n, v in row.items() if n != 'home') for row in rows.values()),
           'home_faster_native_ts7': sum(row['home'] < row['tsgo'] for row in rows.values()),
           'medians_seconds': rows, 'ranking_scope': 'descriptive paused same-host matrix, not causal or portable'}
publication = output / 'lineage/publication'
publication.mkdir()
with (publication / 'summary.json').open('x') as stream:
    json.dump(summary, stream, indent=2)
text = io.StringIO()
old_argv = sys.argv
try:
    sys.argv = ['compare.py', str(output)]
    with contextlib.redirect_stdout(text):
        if compare.main() != 0:
            raise ValueError('Report verification failed')
finally:
    sys.argv = old_argv
with (publication / 'report.md').open('x') as stream:
    stream.write(text.getvalue())
archive = implementation / 'bench/vs_tsgo/evidence/20261012-declaration-resumed-matrix-880.tar.gz'
if archive.exists():
    raise ValueError('Do not overwrite published evidence')
run.cmd_evidence(output, archive)
with tarfile.open(archive) as packed:
    prefix = 'ts-frontend-benchmark-' + output.name + '/'
    checksums = packed.extractfile(prefix + 'SHA256SUMS').read().decode().splitlines()
    for line in checksums:
        expected, relative = line.split('  ', 1)
        if hashlib.sha256(packed.extractfile(prefix + relative).read()).hexdigest() != expected:
            raise ValueError('Archive payload changed: ' + relative)
    for path in output.rglob('*'):
        if path.is_file() and packed.extractfile(prefix + path.relative_to(output).as_posix()).read() != path.read_bytes():
            raise ValueError('Archive changed retained evidence bytes: ' + str(path))
print(json.dumps({'archive': str(archive), 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
                  'verified_payloads': len(checksums), 'summary': summary}, indent=2))
