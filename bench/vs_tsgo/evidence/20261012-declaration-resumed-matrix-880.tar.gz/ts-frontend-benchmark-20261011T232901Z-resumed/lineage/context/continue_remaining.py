"""Execute each untouched continuation phase once, under the unchanged guard."""
import json
import os
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
measured = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
output = Path('/Users/chris/.codex/worktrees/ts863-qualification-docs/lang/bench/vs_tsgo/results/20261011T232901Z-resumed')
plan = json.loads((output / 'lineage/plan.json').read_bytes())
phases = list(dict.fromkeys(row['workload'] for row in plan['unrecorded_slots']))
first = json.loads((output / 'lineage/phases/reexport_graph.json').read_bytes())
if first.get('status') != 'complete':
    raise ValueError('Original reexports guard must finish successfully before continuation')
guards = output / 'lineage/guards'
guards.mkdir(exist_ok=True)
environment = dict(os.environ, HOME_RUN_MAX_MB='3840', HOME_TSC='/Users/chris/.cache/home-ts-owned-alias-inflight-interfaces.jHEAoG/candidate-home-tsc')
for workload in phases[1:]:
    phase = output / 'lineage/phases' / (workload + '.json')
    if phase.exists():
        raise ValueError('Remaining workload already attempted: ' + workload)
    environment['HOME_RUN_LABEL'] = 'ts880-matrix-' + workload
    log = guards / (workload + '.log')
    terminal = guards / (workload + '.json')
    if log.exists() or terminal.exists():
        raise ValueError('Guard already attempted: ' + workload)
    command = ['perl', 'scripts/run-bounded.pl', '600', sys.executable, str(root / 'controller.py'), 'workload', workload]
    print(json.dumps({'workload': workload, 'state': 'guard-starting', 'log': str(log)}), flush=True)
    with log.open('x') as stream:
        result = subprocess.run(command, cwd=measured, env=environment, stdout=stream, stderr=subprocess.STDOUT)
    with terminal.open('x') as stream:
        json.dump({'workload': workload, 'command': command, 'exit': result.returncode,
                   'limits': {'seconds': 600, 'memory_mb': 3840, 'disk_admission_mb': 1024, 'disk_critical_mb': 512}}, stream, indent=2)
    print(json.dumps({'workload': workload, 'guard_exit': result.returncode}), flush=True)
    if result.returncode != 0:
        raise SystemExit(result.returncode)
    if json.loads(phase.read_bytes()).get('status') != 'complete':
        raise ValueError('Guard succeeded without a complete phase')
print(json.dumps({'remaining_phases': len(phases) - 1, 'state': 'complete', 'finalization_required': True}), flush=True)
