Historical measurement modules are loaded first by controller.py to retain original tools/corpus/commands/cwd provenance.
Publication modules verify complete protocol and immutable continuation lineage; no timer samples are repeated.
Native Home identity is bb4c00dd2fdfba719098150082b696b4f9ba8ab65a7a47640b197540420cf771 from landed4b4060e05, qualified separately under#879.
Original source/adoption qualification: bench/vs_tsgo/evidence/20261011-owned-alias-qualified-landed-879.tar.gz SHA2561852d6d51008a90bce47b0abf5142469a60d2968654bc3cea7131544107531d3.
Linux dispatch refused422 despite active/enabled API fields; no Linux timing or repository settings change.
