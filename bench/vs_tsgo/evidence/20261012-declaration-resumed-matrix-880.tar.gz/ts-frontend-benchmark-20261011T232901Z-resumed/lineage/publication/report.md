# TypeScript frontend benchmark — 20261011T232901Z-resumed

Apple M3 Pro / Mac15,6; 11 logical cores; Darwin 27.0.0 (arm64); 30 runs after 3 warmups; tsc `Version 6.0.3`, tsgo `Version 7.0.2`, Home `Version 0.1.0`, tsc_rs `Version 7.1.0-dev`, bun_canary `1.4.3-canary.1+bd599f5af`.
Measurement tools: node `v26.10.0`, hyperfine `hyperfine 1.20.0`, python `3.9.6`.
Provenance: verified unchanged before admission and after measurement.
Continuation: interrupted checkpoint plus only unrecorded slots; retained raw lineage verified.
The measurement pause and split round prevent treating this as an uninterrupted or cross-host performance result.

| Workload | tsc median | tsgo median | Home median | tsc_rs median | bun_canary median | Home vs fastest competitor |
|---|---:|---:|---:|---:|---:|---:|
| `checkjs_jsdoc` | 261.3 ms | 29.1 ms | 32.6 ms | 29.0 ms | 17.4 ms | 1.88× slower |
| `class_hierarchy` | 235.6 ms | 26.2 ms | 27.5 ms | 22.4 ms | 17.3 ms | 1.59× slower |
| `commonjs_graph` | 188.4 ms | 22.7 ms | 23.2 ms | 18.7 ms | 15.0 ms | 1.55× slower |
| `control_flow` | 1502.8 ms | 137.5 ms | 144.3 ms | 100.8 ms | 55.3 ms | 2.61× slower |
| `deep_types` | 1898.3 ms | 127.5 ms | 138.2 ms | 72.5 ms | 70.7 ms | 1.95× slower |
| `destructuring` | 184.7 ms | 20.9 ms | 18.1 ms | 19.0 ms | 14.7 ms | 1.23× slower |
| `generic_calls` | 808.0 ms | 72.5 ms | 79.6 ms | 65.8 ms | 45.4 ms | 1.75× slower |
| `import_graph` | 974.7 ms | 74.0 ms | 91.2 ms | 63.3 ms | 117.9 ms | 1.44× slower |
| `interface_composition` | 264.1 ms | 40.0 ms | 41.7 ms | 30.7 ms | 23.0 ms | 1.81× slower |
| `many_files` | 1067.2 ms | 93.8 ms | 99.8 ms | 55.1 ms | 51.1 ms | 1.95× slower |
| `null_safe_access` | 286.9 ms | 35.9 ms | 29.2 ms | 31.9 ms | 22.9 ms | 1.28× slower |
| `overload_resolution` | 268.8 ms | 40.3 ms | 28.7 ms | 32.1 ms | 24.4 ms | 1.18× slower |
| `recursive_generics` | 194.4 ms | 47.2 ms | 17.9 ms | 39.1 ms | 12.7 ms | 1.41× slower |
| `reexport_graph` | 550.7 ms | 37.6 ms | 72.4 ms | 31.5 ms | 30.3 ms | 2.39× slower |
| `startup` | 255.6 ms | 28.7 ms | 10.5 ms | 23.7 ms | 22.8 ms | **2.18× faster** |
| `structural_objects` | 258.4 ms | 36.1 ms | 27.1 ms | 28.9 ms | 22.1 ms | 1.23× slower |
| `tsx_components` | 600.8 ms | 45.3 ms | 50.4 ms | 39.7 ms | 29.2 ms | 1.73× slower |
| `type_predicates` | 1903.9 ms | 186.1 ms | 163.6 ms | 151.9 ms | 101.0 ms | 1.62× slower |
| `type_predicates_large` | 3215.9 ms | 789.8 ms | 596.0 ms | 680.4 ms | 436.2 ms | 1.37× slower |
| `variadic_tuples` | 323.2 ms | 56.0 ms | 39.3 ms | 41.6 ms | 23.6 ms | 1.66× slower |

Times are medians of all retained fresh-process samples. Comparisons use the fastest median of every measured competitor.
Ratios rounding to 1.00× are labeled near ties; this is not a statistical significance test.
Legacy graph rows without schema-2 rejection controls are retained as timings, not fair speed claims (#487).
Legacy tuple rows without schema-3 rejection controls are provisional; schema 3 also retains the graph gates.
Legacy JSDoc rows without validation-schema-4 rejection controls are provisional, not fair speed claims (#852).
Legacy null-safe rows without validation-schema-5 inferred-local controls are provisional, not fair speed claims (#864).
