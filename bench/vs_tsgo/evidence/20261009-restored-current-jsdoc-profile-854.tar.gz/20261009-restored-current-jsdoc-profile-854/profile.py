"""Current-source diagnostic sampling; never used as a timing binary."""
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time

repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
root = Path(__file__).resolve().parent
sys.path.insert(0, str(repo / 'bench/vs_tsgo'))
import run
import competitors

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

source = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=repo, text=True)
candidate = Path('/Users/chris/.cache/home-ts-require-facts.GAagto')
restored = json.loads((candidate / 'restored-current-main.json').read_text())
assert restored['source_clean_before_and_after'] and not restored['rejected_candidate_in_production']
assert subprocess.run(['git', 'diff', '--quiet', restored['restored_source'], 'HEAD', '--', 'packages', 'build.zig', 'build.zig.zon'], cwd=repo).returncode == 0
installed = repo / 'zig-out/bin/home-tsc'
assert digest(installed) == '34118002e25d69a8351a60ee493c504ca734b477ed31efc79fb03ee63a9ad331'
frozen = root / 'home-tsc-current'
shutil.copy2(installed, frozen)
matches = [p for p in (repo / '.zig-cache/o').glob('*/home-tsc')
           if p.is_file() and p.stat().st_size == frozen.stat().st_size and digest(p) == digest(frozen)]
assert matches, 'No exact cached link image found'
original = matches[0].parent / 'home-tsc_zcu.o'
assert original.is_file(), original
objcopy = '/Users/chris/.local/share/pantry/global/bin/llvm-objcopy'
nm = subprocess.check_output(['nm', str(original)], text=True)
renames = []
for line in nm.splitlines():
    match = re.match(r'^[0-9a-f]+ [a-zA-Z] (l_.+)$', line)
    if match:
        old = match.group(1)
        renames.append(old + ' diag_' + old)
assert renames
(root / 'symbol-map.txt').write_text('\n'.join(renames) + '\n')
renamed = root / 'profile-symbols.o'
subprocess.run([objcopy, '--redefine-syms=' + str(root / 'symbol-map.txt'), str(original), str(renamed)], check=True)
for name, path in [('original', original), ('renamed', renamed)]:
    subprocess.run([objcopy, '--dump-section=__TEXT,__text=' + str(root / (name + '-text.bin')), str(path)], check=True)
assert (root / 'original-text.bin').read_bytes() == (root / 'renamed-text.bin').read_bytes()
diagnostic = root / 'home-tsc-profile'
subprocess.run(['clang', '-Wl,-no_dead_strip_inits_and_terms', '-o', str(diagnostic), str(renamed)], check=True)
commands = {'frozen': [str(frozen)], 'diagnostic': [str(diagnostic)]}
trace = []
for workload in run.manifest()['workloads']:
    run.validate(commands, workload, trace=trace)
assert len(trace) == 58 and all(row['passed'] for row in trace)
run.generate_checkjs_jsdoc(root / 'checkjs-scale-8192', 8192)
for name, command in commands.items():
    for kind in ('positive', 'negative'):
        project = root / 'checkjs-scale-8192/tsconfig.json' if kind == 'positive' else candidate / 'checkjs8192-negative/tsconfig.json'
        expected = None if kind == 'positive' else ['2322'] * 9 + ['2339'] * 3 + ['2345'] * 3
        _, passed = run.admission_process(name, command + ['--noEmit', '-p', str(project)], 'checkjs8192', expected_codes=expected, trace=trace)
        assert passed
assert len(trace) == 62 and all(row['passed'] for row in trace)
provenance = {'source': source, 'binary_sha256': digest(frozen), 'object_path': str(original),
              'original_object_sha256': digest(original), 'diagnostic_sha256': digest(diagnostic),
              'text_sha256': digest(root / 'original-text.bin'), 'renamed_symbols': len(renames),
              'runner_sha256': digest(Path(__file__)), 'admissions': trace,
              'diagnostic_image_used_for_timing': False}
(root / 'provenance.json').write_text(json.dumps(provenance, indent=2) + '\n')
projects = {
    'checkjs8192': root / 'checkjs-scale-8192/tsconfig.json',
}
for name, project in projects.items():
    before = competitors.inventory_hash(competitors.payload_inventory(project.parent))
    command = [str(diagnostic), '--noEmit', '-p', str(project)]
    child = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    started = time.monotonic()
    time.sleep(0.1)
    samples = []
    for label, offset in [('early', 0.1), ('middle', 3.0)]:
        remaining = started + offset - time.monotonic()
        if remaining > 0:
            time.sleep(remaining)
        assert child.poll() is None, 'Compiler finished before the declared exploratory sample; preserve this outcome'
        path = root / (name + '-' + label + '-sample.txt')
        sample = subprocess.run(['/usr/bin/sample', str(child.pid), '1', '1', '-mayDie', '-file', str(path)], capture_output=True, text=True)
        samples.append({'label': label, 'target_start_offset_seconds': offset, 'sample_exit': sample.returncode,
            'sample_stdout': sample.stdout, 'sample_stderr': sample.stderr, 'path': str(path)})
    stdout, stderr = child.communicate(timeout=120)
    record = {'project': str(project), 'command': command, 'compiler_exit': child.returncode,
              'stdout': stdout, 'stderr': stderr, 'samples': samples,
              'interpretation': 'Two separate one-second exploratory stack samples, not whole-run CPU percentages or timing measurements',
              'input_hash_before': before, 'input_hash_after': competitors.inventory_hash(competitors.payload_inventory(project.parent))}
    (root / (name + '-profile.json')).write_text(json.dumps(record, indent=2) + '\n')
    print(name, json.dumps(record), flush=True)
    assert child.returncode == 0 and not stdout and not stderr
    assert record['input_hash_before'] == record['input_hash_after'] and all(row['sample_exit'] == 0 for row in samples)
assert digest(installed) == digest(frozen)
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip() == source
print('All 62 admissions passed; instruction bytes and source/input provenance unchanged. Diagnostic image never timed.', flush=True)
