    fn resolveValueDeclInStmt(
        self: *Checker,
        s: NodeId,
        node: NodeId,
        id: hir_mod.IdentifierPayload,
    ) CheckError!?TypeId {
        const decl = self.unwrapExportDecl(s);
        if (!self.valueDeclVisibleFromNode(decl, node)) return null;
        const sk = self.hir.kindOf(decl);
        if (sk == .var_decl or sk == .let_decl or sk == .const_decl) {
            const v = hir_mod.varDeclOf(self.hir, decl);
            if (v.name != hir_mod.none_node_id and self.hir.kindOf(v.name) == .identifier) {
                const vid = hir_mod.identifierOf(self.hir, v.name);
                if (vid.name == id.name) {
                    self.reportDeprecatedDeclarationUse(node, decl, id.name) catch {};
                    if (sk == .var_decl and
                        self.strict_flags.strict_null_checks and
                        !v.is_ambient and
                        v.type_annotation == hir_mod.none_node_id and
                        v.init == hir_mod.none_node_id)
                    {
                        return types.Primitive.undefined_t;
                    }
                    if (self.nodeIsCallCallee(node) and v.init != hir_mod.none_node_id) {
                        const init_kind = self.hir.kindOf(v.init);
                        if ((init_kind == .fn_decl or init_kind == .fn_expr or init_kind == .arrow_fn) and
                            self.fnHasJsDocClassOrConstructorTag(v.init))
                        {
                            if (try self.jsConstructorStaticTypeForHeritage(node, id.name)) |constructor_t| return constructor_t;
                        }
                    }
                    const t = self.hir.typeOf(decl);
                    if (!self.declared_identifier_lookup and
                        v.type_annotation != hir_mod.none_node_id and
                        t != types.Primitive.none and
                        self.hir.typeOf(v.name) == t)
                    {
                        return t;
                    }
                    if (v.type_annotation != hir_mod.none_node_id and
                        (self.declared_identifier_lookup or t == types.Primitive.none))
                    {
                        const declared_t = self.lowerVarDeclTypeAnnotationForIdentifierLookup(id.name, v) catch types.Primitive.any;
                        self.hir.setType(decl, declared_t);
                        self.hir.setType(v.name, declared_t);
                        return declared_t;
                    }
                    if (v.type_annotation != hir_mod.none_node_id and t != types.Primitive.none) {
                        const declared_t = self.lowerVarDeclTypeAnnotationForIdentifierLookup(id.name, v) catch types.Primitive.any;
                        if (self.annotatedArrayLookupShouldUseDeclared(t, declared_t)) {
                            self.hir.setType(decl, declared_t);
                            self.hir.setType(v.name, declared_t);
                            return declared_t;
                        }
                    }
                    if (t != types.Primitive.none) return t;
                    // A binding declared in an outer scope is visible from a
                    // nested function even when its declaration appears later.
                    // Its initializer will be checked in declaration order;
                    // use `any` provisionally instead of misreporting TS2304.
                    if (self.enclosingFunctionLike(node) != self.enclosingFunctionLike(decl)) {
                        return types.Primitive.any;
                    }
                }
            } else if (v.name != hir_mod.none_node_id) {
                const vk = self.hir.kindOf(v.name);
                if (vk == .object_pattern or vk == .array_pattern or vk == .object_literal or vk == .array_literal) {
                    if (self.bindingTargetIdentifierNode(v.name, id.name)) |target| {
                        const cached_binding_t = self.hir.typeOf(target);
                        if (cached_binding_t != types.Primitive.none) return cached_binding_t;
                    }
                    const container_t = if (self.hir.typeOf(decl) != types.Primitive.none)
                        self.hir.typeOf(decl)
                    else
                        types.Primitive.any;
                    if (v.type_annotation != hir_mod.none_node_id) {
                        const declared_t = self.lowerVarDeclTypeAnnotationForIdentifierLookup(id.name, v) catch types.Primitive.any;
                        if (self.typeOfPatternBinding(v.name, declared_t, id.name)) |bt| {
                            return bt;
                        }
                    }
                    if (v.init != hir_mod.none_node_id) {
                        if (self.typeOfPatternBindingFromSource(v.name, v.init, container_t, id.name) catch null) |bt| {
                            return bt;
                        }
                    }
                    if (self.typeOfPatternBinding(v.name, container_t, id.name)) |bt| {
                        return bt;
                    }
                }
            }
        } else if (sk == .fn_decl or sk == .fn_expr) {
            const fp = hir_mod.fnDeclOf(self.hir, decl);
            if (fp.name != hir_mod.none_node_id and self.hir.kindOf(fp.name) == .identifier) {
                const fid = hir_mod.identifierOf(self.hir, fp.name);
                if (fid.name == id.name) {
                    self.reportDeprecatedDeclarationUse(node, decl, id.name) catch {};
                    if (self.nodeIsCallCallee(node) and self.fnHasJsDocClassOrConstructorTag(decl)) {
                        if (try self.jsConstructorStaticTypeForHeritage(node, id.name)) |constructor_t| return constructor_t;
                    }
                    if (self.overloadedFunctionValueType(id.name) catch null) |overload_t| {
                        return try self.expandoAugmentedFunctionValueType(id.name, node, overload_t);
                    }
                    const t = self.hir.typeOf(decl);
                    if (t != types.Primitive.none) return try self.expandoAugmentedFunctionValueType(id.name, node, t);
                    if (try self.ensurePlainFunctionSignature(decl)) |sig| {
                        return try self.expandoAugmentedFunctionValueType(id.name, node, sig);
                    }
                    // The name IS declared by a sibling function in this
                    // block scope, but its signature type hasn't been
                    // assigned yet (this happens when the reference is
                    // resolved before the nested declaration is checked ÃÂ¢ÃÂÃÂ
                    // e.g. `return bar;` for a nested `function bar` inside
                    // a class method body, cf. wrappedAndRecursiveConstraints3).
                    // tsc never emits TS2304 for a declared binding, so fall
                    // back to `any` rather than letting the unresolved-name
                    // chain fire.
                    _ = self.reportReturnTypeAnnotationCircularIfActive(decl);
                    return types.Primitive.any;
                }
            }
        } else if (sk == .class_decl or sk == .class_expr) {
            const cp = hir_mod.classOf(self.hir, decl);
            if (cp.name != hir_mod.none_node_id and self.hir.kindOf(cp.name) == .identifier) {
                const cid = hir_mod.identifierOf(self.hir, cp.name);
                if (cid.name == id.name) {
                    self.reportDeprecatedDeclarationUse(node, decl, id.name) catch {};
                    if (self.class_static_type_by_node.get(decl)) |static_t| return static_t;
                    if (self.class_static_types.get(id.name)) |static_t| return static_t;
                    const t = self.hir.typeOf(decl);
                    if (t != types.Primitive.none) return t;
                    // Declared by a sibling class in this block scope but
                    // not yet typed ÃÂ¢ÃÂÃÂ same rationale as the function case
                    // above: a declared binding must not surface TS2304.
                    return types.Primitive.any;
                }
            }
        } else if (sk == .import_decl) {
            if (self.importDeclBindsLocal(decl, id.name)) {
                // The lexical walk missed a nearer binding (a `var` in a nested
                // block, a use before its declaration); the import is not the
                // symbol this name resolves to.
                if (self.valueNameShadowsImport(id.name, node)) return types.Primitive.any;
                if (self.moduleNamespaceTypeForLocalImport(id.name, node) catch null) |ns_t| return ns_t;
                if (self.virtualImportTypeForLocal(id.name, node) catch null) |import_t| return import_t;
                if (try self.programExportedClassTypeForImportBinding(decl, id.name, node)) |class_t| return class_t;
                if (try self.programExportedValueTypeForImportBinding(decl, id.name)) |value_t| return value_t;
                return types.Primitive.any;
            }
        } else if (sk == .for_in_stmt or sk == .for_of_stmt) {
            const fr = hir_mod.forInOf(self.hir, decl);
            if (fr.target != hir_mod.none_node_id and self.hir.kindOf(fr.target) == .var_decl) {
                const v = hir_mod.varDeclOf(self.hir, fr.target);
                if (v.name != hir_mod.none_node_id and self.hir.kindOf(v.name) == .identifier and
                    hir_mod.identifierOf(self.hir, v.name).name == id.name)
                {
                    const t = self.hir.typeOf(fr.target);
                    return if (t == types.Primitive.none) types.Primitive.any else t;
                }
            }
        }
        return null;
    }

