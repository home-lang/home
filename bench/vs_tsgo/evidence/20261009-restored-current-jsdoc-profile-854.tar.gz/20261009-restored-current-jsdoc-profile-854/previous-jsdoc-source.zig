    fn jsDocTypeForPreviousIdentifierDecl(self: *Checker, node: NodeId) CheckError!?TypeId {
        if (!self.sourceHasCheckJsDirective()) return null;
        if (node == hir_mod.none_node_id or self.hir.kindOf(node) != .identifier) return null;
        if (self.source_has_virtual_sections and
            !self.virtualSectionIsJsLike(node))
        {
            return null;
        }
        const id = hir_mod.identifierOf(self.hir, node);
        if (self.nearestPriorValueDeclInSameFunction(node, id.name)) |decl| {
            if (try self.jsDocTypeForLeadingNode(decl)) |declared_t| return declared_t;
        }
        const use_start = self.hir.spanOf(node).start;
        var cur = self.hir.parentOf(node);
        while (cur != hir_mod.none_node_id) : (cur = self.hir.parentOf(cur)) {
            const stmts: ?[]const NodeId = switch (self.hir.kindOf(cur)) {
                .block_stmt => hir_mod.blockStmts(self.hir, cur),
                .namespace_decl => hir_mod.namespaceBody(self.hir, cur),
                else => null,
            };
            if (stmts) |items| {
                for (items) |stmt| {
                    if (self.hir.spanOf(stmt).start >= use_start) break;
                    const decl = if (self.hir.kindOf(stmt) == .export_decl) hir_mod.exportOf(self.hir, stmt).decl else stmt;
                    if (decl == hir_mod.none_node_id) continue;
                    const dk = self.hir.kindOf(decl);
                    if (dk != .var_decl and dk != .let_decl and dk != .const_decl) continue;
                    const v = hir_mod.varDeclOf(self.hir, decl);
                    if (v.name == hir_mod.none_node_id or self.hir.kindOf(v.name) != .identifier) continue;
                    if (hir_mod.identifierOf(self.hir, v.name).name != id.name) continue;
                    return try self.jsDocTypeForLeadingNode(decl);
                }
            }
        }
        return null;
    }

