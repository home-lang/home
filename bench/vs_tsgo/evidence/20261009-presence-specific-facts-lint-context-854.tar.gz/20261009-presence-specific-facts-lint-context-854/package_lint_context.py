import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
assert json.loads((root / 'lint-command.json').read_text())['exit'] == 1
assert '22074 problems (11461 errors, 10613 warnings)' in (root / 'lint.log').read_text()
metadata = {
    'source_at_lint': '37b5225c2cf795e16bf3d20a436a606c0ae594e9',
    'primary_evidence_sha256': '5dc948934a065562ddcf9c8528f418657e4f6f946e4127fee0ed63faf5b5da01',
    'lint_session': {'session': 69882, 'status': 'terminal', 'exit': 1},
    'primary_archive_session': {'session': 28689, 'status': 'terminal', 'exit': 0},
    'lint_scope': 'repository-wide read-only Pickier, no automatic fixes',
    'existing_errors': 11461, 'existing_warnings': 10613,
    'changed_files': ['README.md', 'docs/docs/TS_PERFORMANCE.md'],
    'semantic_and_benchmark_gates': 'all pass; existing repository lint findings are not a semantic gate failure'
}
(root / 'lint-context.json').write_text(json.dumps(metadata, indent=2) + '\n')
entries = {name: (root / name).read_bytes() for name in ('lint.py', 'lint.log', 'lint-command.json', 'lint-context.json', 'package_lint_context.py')}
checksums = ''.join(hashlib.sha256(data).hexdigest() + '  ' + name + '\n' for name, data in sorted(entries.items()))
entries['SHA256SUMS'] = checksums.encode()
name = '20261009-presence-specific-facts-lint-context-854'
path = repo / 'bench/vs_tsgo/evidence' / (name + '.tar.gz')
assert not path.exists()
with path.open('wb') as output:
    with gzip.GzipFile(filename='', mode='wb', fileobj=output, mtime=0) as gz:
        with tarfile.open(fileobj=gz, mode='w') as tar:
            for filename, data in sorted(entries.items()):
                item = tarfile.TarInfo(name + '/' + filename)
                item.size, item.mode, item.mtime = len(data), 0o644, 0
                tar.addfile(item, io.BytesIO(data))
with tarfile.open(path) as tar:
    for row in checksums.splitlines():
        expected, filename = row.split('  ', 1)
        assert hashlib.sha256(tar.extractfile(name + '/' + filename).read()).hexdigest() == expected
report = {'archive': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'payload_checksums': 5}
(root / 'lint-archive.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report))
