export declare const value: number;
//# sourceMappingURL=helper.d.ts.map