export declare const answer: string;
