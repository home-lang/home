export declare const answer;
