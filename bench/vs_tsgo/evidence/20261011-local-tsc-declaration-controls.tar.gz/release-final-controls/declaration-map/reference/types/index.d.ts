export declare const answer: number;
//# sourceMappingURL=index.d.ts.map