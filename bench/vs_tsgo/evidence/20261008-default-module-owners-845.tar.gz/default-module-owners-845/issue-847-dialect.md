## Updated evidence: TS 6/7 dialect difference

The #845 95-case same-input matrix includes CommonJS with moduleResolution node10 and ignoreDeprecations 6.0. TS 6.0.3 accepts that configuration and proceeds to semantic default-import checks. Direct native TS 7.0.2 rejects it with TS5108 at tsconfig.json(12,25). Home source 929d46a67 also rejects it with TS5108, but currently emits a global message without that config-file position.

The initial finding was relative to TS 6 alone. The new direct-native oracle changes the next action: do not make a permissive option change that contradicts TS 7, and do not claim these 19 config-rejected cases are shared semantic admissions. Preserve the entire 95-case matrix and document the version-dependent outcomes. Full raw native command/output: /Users/chris/.cache/home-ts-845.xzutkH/native-config.log; TS6/Home records, fixture bytes and hashes in parent.json and owner.json beside it.

## Remaining work

- Establish/document the frontend's intended TS option dialect and compatibility contract using authoritative source/tests. If both dialects are supported, use explicit logical version selection rather than inferring it from benchmark names or suppressing removed-option errors.
- Match config diagnostic source positions/messages under the chosen dialect; native TS7 currently anchors TS5108 to the removed option value, while Home drops the location.
- Retain positive current-option controls, deprecated/removed option negatives and ignoreDeprecations cases. Keep TS6-only accepted configurations separate from fair multi-compiler timing admissions.
- Publish issue-linked conventional commits, complete config/CLI gates and documentation when implemented. This issue remains open, not a blocker for meaningful work on shared admissible module/default semantics under #845/#846.

Related #416, #845. No config source fix or benchmark claim yet.
