import type value from './target.js';
export const result = 1;
