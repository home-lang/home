declare const value: { named: number }; export = value;
