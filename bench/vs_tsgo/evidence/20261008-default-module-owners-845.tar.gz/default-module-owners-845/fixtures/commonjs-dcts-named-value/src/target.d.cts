export declare const named: number;
