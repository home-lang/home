import value from './target.mjs';
export const result = 1;
