export const named = 1;
