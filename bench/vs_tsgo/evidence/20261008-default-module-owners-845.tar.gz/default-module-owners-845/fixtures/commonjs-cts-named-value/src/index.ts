import value from './target.cjs';
export const result = 1;
