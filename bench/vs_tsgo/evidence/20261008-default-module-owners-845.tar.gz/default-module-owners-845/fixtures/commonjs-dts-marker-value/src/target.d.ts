export declare const named: number; export declare const __esModule: true;
