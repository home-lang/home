| Workload | tsc 6.0.3 median | native TS 7.0.2 median | Home median | Rust tsc-rs 0.1.0 median | Bun canary median | Home vs fastest competitor |
|---|---:|---:|---:|---:|---:|---:|
| `checkjs_jsdoc` | 218.4 ms | 24.8 ms | 29.0 ms | 24.3 ms | 14.2 ms | 2.04× slower |
| `class_hierarchy` | 241.6 ms | 26.4 ms | 27.8 ms | 22.3 ms | 16.9 ms | 1.65× slower |
| `commonjs_graph` | 178.8 ms | 20.9 ms | 28.7 ms | 17.1 ms | 14.1 ms | 2.03× slower |
| `control_flow` | 225.2 ms | 31.1 ms | 28.8 ms | 27.7 ms | 18.0 ms | 1.60× slower |
| `deep_types` | 149.9 ms | 23.3 ms | 22.8 ms | 15.7 ms | 14.7 ms | 1.55× slower |
| `destructuring` | 218.9 ms | 25.0 ms | 21.6 ms | 21.7 ms | 15.9 ms | 1.36× slower |
| `generic_calls` | 233.1 ms | 27.3 ms | 27.3 ms | 23.8 ms | 17.7 ms | 1.54× slower |
| `import_graph` | 148.4 ms | 16.2 ms | 23.2 ms | 12.7 ms | 16.9 ms | 1.82× slower |
| `interface_composition` | 241.1 ms | 36.2 ms | 38.1 ms | 27.2 ms | 20.4 ms | 1.87× slower |
| `many_files` | 212.4 ms | 23.0 ms | 22.5 ms | 17.2 ms | 13.7 ms | 1.64× slower |
| `null_safe_access` | 215.8 ms | 29.5 ms | 35.8 ms | 25.3 ms | 18.2 ms | 1.97× slower |
| `overload_resolution` | 249.2 ms | 38.4 ms | 28.5 ms | 30.9 ms | 23.9 ms | 1.19× slower |
| `recursive_generics` | 162.0 ms | 42.1 ms | 15.7 ms | 34.3 ms | 9.9 ms | 1.58× slower |
| `reexport_graph` | 117.5 ms | 12.3 ms | 14.5 ms | 10.7 ms | 9.8 ms | 1.48× slower |
| `startup` | 68.1 ms | 7.8 ms | 3.2 ms | 6.3 ms | 6.7 ms | **2.00× faster** |
| `structural_objects` | 230.9 ms | 32.0 ms | 26.9 ms | 26.6 ms | 19.5 ms | 1.38× slower |
| `tsx_components` | 193.9 ms | 18.0 ms | 21.1 ms | 16.1 ms | 12.1 ms | 1.75× slower |
| `type_predicates` | 275.5 ms | 46.2 ms | 37.1 ms | 38.6 ms | 26.5 ms | 1.40× slower |
| `type_predicates_large` | 1,099.7 ms | 349.6 ms | 268.7 ms | 287.5 ms | 174.3 ms | 1.54× slower |
| `variadic_tuples` | 266.1 ms | 47.6 ms | 33.8 ms | 35.8 ms | 19.9 ms | 1.70× slower |
