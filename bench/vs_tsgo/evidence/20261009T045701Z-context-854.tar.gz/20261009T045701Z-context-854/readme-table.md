| Workload | tsc 6.0.3 median | native TS 7.0.2 median | Home median | Rust tsc-rs 0.1.0 median | Bun canary median | Home vs fastest competitor |
|---|---:|---:|---:|---:|---:|---:|
| Startup (one small file) | 68.1 ms | 7.8 ms | 3.2 ms | 6.3 ms | 6.7 ms | **2.00× faster** |
| 256 independent files | 212.4 ms | 23.0 ms | 22.5 ms | 17.2 ms | 13.7 ms | 1.64× slower |
| 128-module import chain | 148.4 ms | 16.2 ms | 23.2 ms | 12.7 ms | 16.9 ms | 1.82× slower |
| 64 modules through 8 barrel re-exports | 117.5 ms | 12.3 ms | 14.5 ms | 10.7 ms | 9.8 ms | 1.48× slower |
| Deep conditional / mapped / template types | 149.9 ms | 23.3 ms | 22.8 ms | 15.7 ms | 14.7 ms | 1.55× slower |
| Recursive generics | 162.0 ms | 42.1 ms | 15.7 ms | 34.3 ms | 9.9 ms | 1.58× slower |
| Checked JavaScript with JSDoc | 218.4 ms | 24.8 ms | 29.0 ms | 24.3 ms | 14.2 ms | 2.04× slower |
| Control-flow narrowing (256 unions) | 225.2 ms | 31.1 ms | 28.8 ms | 27.7 ms | 18.0 ms | 1.60× slower |
| 256 type-predicate families | 275.5 ms | 46.2 ms | 37.1 ms | 38.6 ms | 26.5 ms | 1.40× slower |
| 2,048 type-predicate families | 1,099.7 ms | 349.6 ms | 268.7 ms | 287.5 ms | 174.3 ms | 1.54× slower |
