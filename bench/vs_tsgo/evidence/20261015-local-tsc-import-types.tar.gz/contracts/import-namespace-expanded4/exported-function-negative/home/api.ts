export function get():import("./owner").Token{return {value:"ok"};}
