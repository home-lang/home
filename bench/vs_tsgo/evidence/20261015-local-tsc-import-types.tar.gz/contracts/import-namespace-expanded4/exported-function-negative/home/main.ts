import {get} from "./api";const bad:number=get().value;
