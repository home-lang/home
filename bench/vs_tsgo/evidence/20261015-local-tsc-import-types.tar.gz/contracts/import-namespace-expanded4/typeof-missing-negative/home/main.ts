export {};declare const bad:typeof import("./owner").missing;
