export function use<Token>():void{const bad:import("./owner").Token={value:1};}
