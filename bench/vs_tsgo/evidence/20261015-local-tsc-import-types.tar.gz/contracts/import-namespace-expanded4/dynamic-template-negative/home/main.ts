export async function use():Promise<void>{const {take}=await import(`./owner`);take(1);}
