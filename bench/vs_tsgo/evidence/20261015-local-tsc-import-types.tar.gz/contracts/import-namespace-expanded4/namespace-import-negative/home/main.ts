export {};const bad:import("./owner").Inner.Token={value:1};
