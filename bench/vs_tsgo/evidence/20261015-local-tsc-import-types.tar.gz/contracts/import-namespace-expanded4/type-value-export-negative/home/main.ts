export {};declare const bad:import("./owner").value;
