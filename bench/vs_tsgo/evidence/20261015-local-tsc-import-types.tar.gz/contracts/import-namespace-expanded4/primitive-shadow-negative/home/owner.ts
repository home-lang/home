interface X{value:string}export {X as string};
