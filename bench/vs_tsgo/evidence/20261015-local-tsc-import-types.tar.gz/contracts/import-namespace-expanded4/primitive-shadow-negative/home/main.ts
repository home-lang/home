export {};const bad:import("./owner").string=1;
