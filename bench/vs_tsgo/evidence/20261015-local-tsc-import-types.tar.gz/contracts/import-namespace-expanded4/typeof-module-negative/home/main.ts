export {};declare const module:typeof import("./owner");module.take(1);
