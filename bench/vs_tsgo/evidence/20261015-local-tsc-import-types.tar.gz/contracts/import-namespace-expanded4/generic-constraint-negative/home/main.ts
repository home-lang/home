export {};declare const bad:import("./owner").Bound<number>;
