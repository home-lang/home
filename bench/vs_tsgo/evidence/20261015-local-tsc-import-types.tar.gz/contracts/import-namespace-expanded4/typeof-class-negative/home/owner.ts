export interface Token{value:string}export class Guard{take(value:string):void{}}
