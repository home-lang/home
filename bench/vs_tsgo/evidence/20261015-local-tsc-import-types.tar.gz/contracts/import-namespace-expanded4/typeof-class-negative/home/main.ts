export {};const bad:import("./owner").Token={value:1};declare const klass:typeof import("./owner").Guard;new klass().take(1);
