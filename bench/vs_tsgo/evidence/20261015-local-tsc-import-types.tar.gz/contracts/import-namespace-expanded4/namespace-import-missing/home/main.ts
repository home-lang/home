export {};declare const bad:import("./owner").Inner.Missing;
