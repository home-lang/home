export {};const bad:import("./owner").Box={value:1};
