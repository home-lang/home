export {};declare const bad:import("./owner").Token<number>;
