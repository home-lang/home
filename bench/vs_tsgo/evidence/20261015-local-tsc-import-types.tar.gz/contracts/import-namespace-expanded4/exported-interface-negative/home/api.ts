export interface API{token:import("./owner").Token}
