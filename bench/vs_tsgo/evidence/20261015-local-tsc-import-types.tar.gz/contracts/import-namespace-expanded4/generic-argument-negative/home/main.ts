export {};const bad:import("./owner").Box<number>={value:"bad"};
