export {};declare const take:typeof import("./owner").take;take(1);
