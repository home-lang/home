interface Token{value:string}
