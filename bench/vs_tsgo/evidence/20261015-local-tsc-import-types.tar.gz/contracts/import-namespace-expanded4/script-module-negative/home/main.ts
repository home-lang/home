export {};declare const bad:import("./owner").Token;
