import type {API} from "./api";declare const api:API;const bad:number=api.token.value;
