export interface API{token:import("./owner").Box<string>}
