export {};interface Token{value:number}const bad:import("./owner").Token={value:1};
