export async function use():Promise<void>{await import("./missing");}
