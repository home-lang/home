export async function use():Promise<void>{const {take}=await import("./owner",{with:{type:"json"}});take(1);}
