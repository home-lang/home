import {unlink} from "node:fs/promises";export async function use(path:string):Promise<void>{await unlink(path);}
