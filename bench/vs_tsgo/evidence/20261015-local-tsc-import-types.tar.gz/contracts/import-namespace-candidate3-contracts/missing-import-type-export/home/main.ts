export {};declare const token:import("./owner").Missing;
