export {};declare const token:import("./missing").Token;
