export class Guard{async get():Promise<import("./owner").Token>{return {value:1};}}
