export {};declare const token:import("./owner").Token;const good:string=token.value;
