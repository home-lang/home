export async function use(path:string):Promise<void>{const {unlink}=await import("node:fs/promises");await unlink(path);}
