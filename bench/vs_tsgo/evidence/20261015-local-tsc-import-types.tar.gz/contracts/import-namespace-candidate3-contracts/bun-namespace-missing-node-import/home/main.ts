export async function use():Promise<void>{await import("node:missing-home-control");}
