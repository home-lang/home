export async function use():Promise<void>{const {remove}=await import("./owner");await remove(1);}
