export async function use(path:string):Promise<void>{const {remove}=await import("./owner");await remove(path);}
