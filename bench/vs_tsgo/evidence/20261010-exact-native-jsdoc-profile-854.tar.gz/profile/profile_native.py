"""One unmodified native process; fixed exploratory windows, never repeat-to-sample."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
sys.path.insert(0, str(repo / 'bench/vs_tsgo'))
import run
import competitors

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
expected = 'ff78eeff3f36f622db610d23881be7165dce31b424481318e82360f1da5935f8'
native = root / 'home-tsc-current'
mapping = json.loads((root / 'native-address-map.json').read_text())
scale = json.loads((root / 'scale-project.json').read_text())
admitted = json.loads((root / 'scale-admission.json').read_text())
source = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip()
assert mapping['source'] == scale['source'] == source
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=repo).decode()
assert mapping['all_non_relocated_bytes_equal'] and mapping['undeclared_changed_bytes'] == 0
assert mapping['native_sha256'] == digest(native) == digest(repo / 'zig-out/bin/home-tsc') == expected
assert digest(Path(mapping['object_path'])) == mapping['object_sha256']
assert digest(Path(mapping['exact_cached_link_image'])) == expected
assert admitted['passed'] and len(admitted['records']) == 6 and all(row['passed'] for row in admitted['records'])
projects = [('positive', Path(scale['project'])), ('negative', Path(scale['negative']))]
before = {name: competitors.inventory_hash(competitors.payload_inventory(path)) for name, path in projects}
assert before == scale['input_hashes']
trace = []
for workload in run.selected_workloads(None):
    run.validate({'native': [str(native)]}, workload, trace=trace)
assert len(trace) == 30 and all(row['passed'] for row in trace)
provenance = {'source': source, 'compiler_source': mapping['compiler_source'], 'native_sha256': expected,
              'map_sha256': digest(root / 'native-address-map.json'), 'input_hashes_before': before,
              'protocol_five_native_admissions': trace, 'scaled_reference_native_admissions': admitted,
              'diagnostic_image_created_or_sampled': False, 'timing_samples': 0,
              'fixed_windows': [{'label': 'early', 'offset_seconds': 0.1, 'duration_seconds': 1},
                                {'label': 'middle', 'offset_seconds': 3.0, 'duration_seconds': 1}]}
(root / 'native-profile-provenance.json').write_text(json.dumps(provenance, indent=2) + '\n')
command = [str(native), '--noEmit', '-p', str(Path(scale['project']) / 'tsconfig.json')]
child = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
started = time.monotonic()
samples = []
for label, offset in [('early', 0.1), ('middle', 3.0)]:
    remaining = started + offset - time.monotonic()
    if remaining > 0:
        time.sleep(remaining)
    if child.poll() is not None:
        samples.append({'label': label, 'target_start_offset_seconds': offset, 'skipped': True,
                        'reason': 'original native process completed before fixed window; not repeated'})
        continue
    path = root / ('jsdoc8192-native-' + label + '-sample.txt')
    sample_started = time.monotonic() - started
    result = subprocess.run(['/usr/bin/sample', str(child.pid), '1', '1', '-mayDie', '-file', str(path)],
                            capture_output=True, text=True)
    samples.append({'label': label, 'target_start_offset_seconds': offset, 'skipped': False,
                    'actual_start_offset_seconds': sample_started,
                    'actual_finish_offset_seconds': time.monotonic() - started,
                    'sample_exit': result.returncode, 'sample_stdout': result.stdout,
                    'sample_stderr': result.stderr, 'path': str(path)})
stdout, stderr = child.communicate()
after = {name: competitors.inventory_hash(competitors.payload_inventory(path)) for name, path in projects}
record = {'command': command, 'pid': child.pid, 'compiler_exit': child.returncode,
          'stdout': stdout, 'stderr': stderr, 'samples': samples,
          'input_hashes_before': before, 'input_hashes_after': after,
          'native_sha256': expected, 'native_process_runs': 1, 'timing_samples': 0,
          'interpretation': 'Separate exploratory stack windows, not whole-run CPU percentages or benchmark timing. Missing or failed windows retained; no repeat-to-sample.'}
(root / 'native-profile.json').write_text(json.dumps(record, indent=2) + '\n')
assert child.returncode == 0 and not stdout and not stderr
assert before == after and digest(native) == digest(repo / 'zig-out/bin/home-tsc') == expected
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip() == source
print(json.dumps({'compiler_exit': child.returncode, 'samples': samples, 'native_process_runs': 1}), flush=True)
