"""Map explicit sampled PCs only; never turn collapsed groups into function CPU counts."""
from bisect import bisect_right
import hashlib
import json
from pathlib import Path
import re

root = Path(__file__).resolve().parent
mapping = json.loads((root / 'native-address-map.json').read_text())
provenance = json.loads((root / 'native-profile-provenance.json').read_text())
profile = json.loads((root / 'native-profile.json').read_text())
assert profile['compiler_exit'] == 0 and not profile['stdout'] and not profile['stderr']
assert profile['input_hashes_before'] == profile['input_hashes_after']
assert profile['native_process_runs'] == 1 and profile['timing_samples'] == 0
assert hashlib.sha256((root / 'native-address-map.json').read_bytes()).hexdigest() == provenance['map_sha256']
assert not provenance['diagnostic_image_created_or_sampled']
headers = re.findall(r'^([0-9a-f]+) T __mh_execute_header$', (root / 'native-symbols.txt').read_text(), re.MULTILINE)
assert len(headers) == 1
header = int(headers[0], 16)
ranges = mapping['ranges']
starts = [entry['start'] for entry in ranges]
observed = {}
samples = {}
for sample in profile['samples']:
    if sample['skipped'] or sample['sample_exit'] != 0:
        samples[sample['label']] = {'unavailable': True, 'original_record': sample}
        continue
    raw = Path(sample['path']).read_text()
    loads = re.findall(r'^Load Address:\s+(0x[0-9a-f]+)$', raw, re.MULTILINE)
    assert len(loads) == 1
    load = int(loads[0], 16)
    graph = raw.split('Call graph:\n', 1)[1].split('\nTotal number in stack', 1)[0]
    main = re.search(r'^\s+(\d+) Thread_\d+\s+DispatchQueue_1:', graph, re.MULTILINE)
    assert main
    records = []
    for line in graph.splitlines():
        if '(in home-tsc-current)' not in line:
            continue
        bracket = re.search(r'\[([^]]+)\]', line)
        assert bracket
        pcs = re.findall(r'0x[0-9a-f]+', bracket.group(1))
        count = re.match(r'^[\s+!:|]*(\d+)\s', line)
        assert pcs and count
        frames = []
        for value in pcs:
            address = int(value, 16) - load + header
            index = bisect_right(starts, address) - 1
            entry = ranges[index] if index >= 0 and address < ranges[index]['end'] else None
            frame = {'runtime_pc': value, 'preferred_pc': hex(address),
                     'symbols': entry['symbols'] if entry else [],
                     'offset': address - entry['start'] if entry else None}
            frames.append(frame)
            if entry:
                key = '|'.join(entry['symbols'])
                item = observed.setdefault(key, {'symbols': entry['symbols'], 'start': entry['start'],
                    'end': entry['end'], 'early_displayed_offsets': set(), 'middle_displayed_offsets': set()})
                item[sample['label'] + '_displayed_offsets'].add(frame['offset'])
        records.append({'raw_line': line, 'collapsed_group_count': int(count.group(1)),
                        'ellipsis_present': '...' in bracket.group(1), 'explicit_frames': frames,
                        'count_scope': 'Original inclusive/collapsed group count, not attributed to any mapped function'})
    samples[sample['label']] = {'main_thread_observations': int(main.group(1)), 'load_address': hex(load),
        'raw_sample_sha256': hashlib.sha256(Path(sample['path']).read_bytes()).hexdigest(),
        'native_callgraph_rows': records}
for item in observed.values():
    item['early_displayed_offsets'] = sorted(item['early_displayed_offsets'])
    item['middle_displayed_offsets'] = sorted(item['middle_displayed_offsets'])
report = {'source': provenance['source'], 'compiler_source': provenance['compiler_source'],
          'native_sha256': provenance['native_sha256'], 'observed_functions': observed,
          'sample_records': samples, 'native_process_runs': 1, 'timing_samples': 0,
          'diagnostic_images_sampled': 0,
          'scope': 'Only explicitly displayed PCs are resolved using current exact-image ASLR and original-object ranges. Ellipses and collapsed counts remain unassigned; no whole-run CPU share or causal speedup claim.'}
(root / 'resolved-native-profile.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'native_sha256': report['native_sha256'], 'observed_functions': len(observed),
    'sample_windows': {name: {key: value for key, value in item.items() if key != 'native_callgraph_rows'}
                       for name, item in samples.items()}, 'scope': report['scope']}), flush=True)
