    fn jsDocTypeForPreviousIdentifierDecl(self: *Checker, node: NodeId) CheckError!?TypeId {
        if (!self.sourceHasCheckJsDirective()) return null;
        if (node == hir_mod.none_node_id or self.hir.kindOf(node) != .identifier) return null;
        if (self.source_has_virtual_sections and
            !self.virtualSectionIsJsLike(node))
        {
            return null;
        }
        const id = hir_mod.identifierOf(self.hir, node);
        if (self.nearestPriorValueDeclInSameFunction(node, id.name)) |decl| {
            if (try self.jsDocTypeForLeadingNode(decl)) |declared_t| return declared_t;
        }
        const declaration = self.firstAncestorPriorJsDocDecl(node, id.name) orelse return null;
        return try self.jsDocTypeForLeadingNode(declaration);
    }

