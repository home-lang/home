"""Read-only mapping of the exact stripped image; never relink or sample another image."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
expected = 'ff78eeff3f36f622db610d23881be7165dce31b424481318e82360f1da5935f8'
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

native = root / 'home-tsc-current'
assert not native.exists()
shutil.copyfile(repo / 'zig-out/bin/home-tsc', native)
native.chmod(0o755)
assert digest(native) == digest(repo / 'zig-out/bin/home-tsc') == expected
matches = [path for path in sorted((repo / '.zig-cache/o').glob('*/home-tsc'))
           if path.is_file() and path.stat().st_size == native.stat().st_size and digest(path) == expected
           and (path.parent / 'home-tsc_zcu.o').is_file()]
assert matches, 'No exact original cached link/object pair; stop before profiling'
original = matches[0].parent / 'home-tsc_zcu.o'
object_hash = digest(original)
tools_root = Path('/Users/chris/.local/share/pantry/global/bin')
def capture(command, filename):
    result = subprocess.run(command, capture_output=True, text=True, check=True)
    (root / filename).write_text(result.stdout)
    return result.stdout

for label, path in [('native', native), ('object', original)]:
    capture([str(tools_root / 'llvm-objdump'), '--section-headers', str(path)], label + '-sections.txt')
    capture(['nm', str(path)], label + '-symbols.txt')
    subprocess.run([str(tools_root / 'llvm-objcopy'), '--dump-section=__TEXT,__text=' + str(root / (label + '-text.bin')),
                    str(path), str(root / (label + '-dump-copy'))], check=True)
capture([str(tools_root / 'llvm-readobj'), '--relocations', '--expand-relocs', str(original)], 'object-relocations.txt')
def definitions(filename):
    result = {}
    for line in (root / filename).read_text().splitlines():
        match = re.match(r'^([0-9a-f]+) [tT] (.+)$', line)
        if match:
            result[match.group(2)] = int(match.group(1), 16)
    return result
native_definitions = definitions('native-symbols.txt')
object_definitions = definitions('object-symbols.txt')
anchors = {name: {'native': native_definitions[name], 'object': object_definitions[name],
                  'delta': native_definitions[name] - object_definitions[name]}
           for name in native_definitions.keys() & object_definitions.keys()}
assert '_main' in anchors
deltas = {value['delta'] for value in anchors.values()}
assert len(deltas) == 1
delta = next(iter(deltas))
def section(filename):
    matches = re.findall(r'^\s*\d+ __text\s+([0-9a-f]+)\s+([0-9a-f]+)\s+TEXT$', (root / filename).read_text(), re.MULTILINE)
    assert len(matches) == 1
    size, address = matches[0]
    return int(size, 16), int(address, 16)
object_size, object_start = section('object-sections.txt')
native_size, native_start = section('native-sections.txt')
object_bytes = (root / 'object-text.bin').read_bytes()
native_bytes = (root / 'native-text.bin').read_bytes()
assert object_size == len(object_bytes) and native_size == len(native_bytes)
offset = object_start + delta - native_start
assert offset >= 0 and offset + object_size <= native_size
linked = native_bytes[offset:offset + object_size]
relocation_text = (root / 'object-relocations.txt').read_text().split('  Section __text {', 1)[1].split('\n  }', 1)[0]
relocations = re.findall(r'Relocation \{\s+Offset: (0x[0-9A-F]+).*?Length: (\d+).*?Type: (ARM64_RELOC_\w+)', relocation_text, re.DOTALL)
assert relocations and len(relocations) == relocation_text.count('Relocation {')
allowed = {'ARM64_RELOC_BRANCH26', 'ARM64_RELOC_PAGE21', 'ARM64_RELOC_PAGEOFF12',
           'ARM64_RELOC_GOT_LOAD_PAGE21', 'ARM64_RELOC_GOT_LOAD_PAGEOFF12',
           'ARM64_RELOC_TLVP_LOAD_PAGE21', 'ARM64_RELOC_TLVP_LOAD_PAGEOFF12',
           'ARM64_RELOC_ADDEND', 'ARM64_RELOC_UNSIGNED'}
mask = bytearray(object_size)
kinds = Counter()
for address, length, kind in relocations:
    assert kind in allowed and int(length) in (2, 3)
    position, width = int(address, 16), 1 << int(length)
    assert 0 <= position and position + width <= object_size
    mask[position:position + width] = b'\x01' * width
    kinds[kind] += 1
differences = [index for index, (before, after) in enumerate(zip(object_bytes, linked)) if before != after and not mask[index]]
assert not differences, {'undeclared_changed_bytes': len(differences), 'first_offsets': differences[:20]}
symbols = {}
for name, address in object_definitions.items():
    if object_start <= address < object_start + object_size:
        symbols.setdefault(address + delta, []).append(name)
addresses = sorted(symbols)
ranges = [{'start': address, 'end': addresses[index + 1] if index + 1 < len(addresses) else object_start + delta + object_size,
           'symbols': sorted(symbols[address])} for index, address in enumerate(addresses)]
assert digest(original) == object_hash and digest(native) == digest(repo / 'zig-out/bin/home-tsc') == expected
record = {'source': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip(),
          'compiler_source': '0b8d1f049e4db8660c9bbc77eb498bb49d7d62eb', 'native_sha256': expected,
          'object_path': str(original), 'object_sha256': object_hash, 'exact_cached_link_image': str(matches[0]),
          'native_text_start': native_start, 'native_text_size': native_size, 'object_text_start': object_start,
          'object_text_size': object_size, 'object_native_start': object_start + delta,
          'object_native_end': object_start + delta + object_size, 'link_delta': delta,
          'native_text_sha256': digest(root / 'native-text.bin'), 'object_text_sha256': digest(root / 'object-text.bin'),
          'all_non_relocated_bytes_equal': True, 'undeclared_changed_bytes': 0,
          'declared_relocations': len(relocations), 'declared_relocation_bytes': sum(mask),
          'relocation_types': dict(kinds), 'mapped_text_ranges': len(ranges), 'ranges': ranges,
          'sampling_started': False, 'diagnostic_image_created': False,
          'scope': 'Exact original cached link/object layout. All bytes outside whole declared relocation-sized words match. This does NOT prove opcode/bit equivalence within masked words. Native tail outside mapped object text is not mapped; no relink or diagnostic executable is used.'}
(root / 'native-address-map.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({key: value for key, value in record.items() if key != 'ranges'}), flush=True)
