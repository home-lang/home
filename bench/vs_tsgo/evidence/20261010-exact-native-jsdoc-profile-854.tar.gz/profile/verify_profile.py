from bisect import bisect_right
import hashlib
import json
from pathlib import Path
import re
import subprocess

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
mapping = json.loads((root / 'native-address-map.json').read_text())
provenance = json.loads((root / 'native-profile-provenance.json').read_text())
profile = json.loads((root / 'native-profile.json').read_text())
resolved = json.loads((root / 'resolved-native-profile.json').read_text())
assert json.loads((root / 'verified-map.json').read_text())['passed']
assert digest(root / 'native-address-map.json') == provenance['map_sha256']
assert digest(root / 'home-tsc-current') == digest(repo / 'zig-out/bin/home-tsc') == provenance['native_sha256']
assert digest(Path(mapping['object_path'])) == mapping['object_sha256']
assert digest(Path(mapping['exact_cached_link_image'])) == provenance['native_sha256']
assert not provenance['diagnostic_image_created_or_sampled']
assert profile['native_process_runs'] == 1 and profile['timing_samples'] == 0
assert profile['compiler_exit'] == 0 and not profile['stdout'] and not profile['stderr']
assert profile['input_hashes_before'] == profile['input_hashes_after']
checks = provenance['protocol_five_native_admissions']
assert len(checks) == 30 and all(record['passed'] for record in checks)
checks += provenance['scaled_reference_native_admissions']['records']
assert len(checks) == 36
for record in checks:
    codes = sorted(re.findall(r'error TS(\d+):', record['stdout'] + record['stderr']))
    assert codes == record['codes']
    if record['kind'] == 'positive':
        assert record['exit_code'] == 0 and not record['stdout'] and not record['stderr']
    else:
        assert record['exit_code'] in (1, 2) and codes == sorted(record['expected_codes'])
        if record['workload'] == 'null_safe_access':
            assert codes == sorted(['2322'] * 18 + ['2339', '2345', '2493'] * 3)
        if record['workload'] in ('checkjs_jsdoc', 'jsdoc8192'):
            assert codes == ['2322'] * 9 + ['2339'] * 3 + ['2345'] * 3
header = int(re.findall(r'^([0-9a-f]+) T __mh_execute_header$', (root / 'native-symbols.txt').read_text(), re.MULTILINE)[0], 16)
starts = [entry['start'] for entry in mapping['ranges']]
assert [record['target_start_offset_seconds'] for record in profile['samples']] == [0.1, 3.0]
for sample in profile['samples']:
    if sample['skipped'] or sample['sample_exit'] != 0:
        assert resolved['sample_records'][sample['label']]['unavailable']
        continue
    raw = Path(sample['path']).read_text()
    assert digest(Path(sample['path'])) == resolved['sample_records'][sample['label']]['raw_sample_sha256']
    load = int(re.findall(r'^Load Address:\s+(0x[0-9a-f]+)$', raw, re.MULTILINE)[0], 16)
    graph = raw.split('Call graph:\n', 1)[1].split('\nTotal number in stack', 1)[0]
    lines = [line for line in graph.splitlines() if '(in home-tsc-current)' in line]
    saved = resolved['sample_records'][sample['label']]['native_callgraph_rows']
    assert len(lines) == len(saved)
    for line, record in zip(lines, saved):
        assert line == record['raw_line']
        bracket = re.search(r'\[([^]]+)\]', line).group(1)
        pcs = re.findall(r'0x[0-9a-f]+', bracket)
        assert record['ellipsis_present'] == ('...' in bracket)
        assert record['collapsed_group_count'] == int(re.match(r'^[\s+!:|]*(\d+)\s', line).group(1))
        assert [frame['runtime_pc'] for frame in record['explicit_frames']] == pcs
        for value, frame in zip(pcs, record['explicit_frames']):
            address = int(value, 16) - load + header
            index = bisect_right(starts, address) - 1
            entry = mapping['ranges'][index] if index >= 0 and address < mapping['ranges'][index]['end'] else None
            assert frame['preferred_pc'] == hex(address)
            assert frame['symbols'] == (entry['symbols'] if entry else [])
            assert frame['offset'] == (address - entry['start'] if entry else None)
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip() == provenance['source']
assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=repo).decode() == ''
result = {'passed': True, 'source': provenance['source'], 'native_sha256': provenance['native_sha256'],
          'native_process_runs': 1, 'sample_windows': 2, 'verified_admissions': 36,
          'explicitly_observed_symbols': len(resolved['observed_functions']), 'timing_samples': 0,
          'whole_run_CPU_percentage_claimed': False, 'collapsed_group_counts_attributed': False,
          'opcode_equivalence_inside_masks_claimed': False, 'diagnostic_images_used': 0}
(root / 'verified-profile.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result), flush=True)
