import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
sys.path.insert(0, str(repo / 'bench/vs_tsgo'))
import run
import competitors

families = 8192
project = root / 'jsdoc-scale-8192'
negative = root / 'jsdoc-scale-8192-negative'
assert not project.exists() and not negative.exists()
run.generate_checkjs_jsdoc(project, families)
shutil.copytree(project, negative)
indices = sorted({0, families // 2, families - 1})
invalid = ''.join(
    f'/** @type {{boolean}} */ const wrongId{i} = preserved{i}.id;\n'
    f'preserved{i}.missing;\n'
    f'/** @type {{number}} */ const wrongCallback{i} = project{i}(model{i});\n'
    f'store{i}.read(123);\n'
    f'/** @type {{Box{i}<Model{i}>}} */ const wrongBox{i} = {{ value: {{ id: "wrong", name: "x", meta: {{ active: true, label: "x" }} }}, label: "x" }};\n'
    for i in indices)
source = negative / 'src/checkjs-jsdoc.js'
run.write(source, source.read_text() + invalid)
inventory = {name: competitors.inventory_hash(competitors.payload_inventory(path))
             for name, path in [('positive', project), ('negative', negative)]}
record = {'families': families, 'indices': indices, 'project': str(project), 'negative': str(negative),
          'input_hashes': inventory, 'expected_negative_codes': sorted(['2322'] * 9 + ['2339'] * 3 + ['2345'] * 3),
          'source': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip(),
          'generator_sha256': hashlib.sha256((repo / 'bench/vs_tsgo/run.py').read_bytes()).hexdigest(),
          'timings_taken': False, 'sampling_started': False,
          'purpose': 'Diagnostic scaling of the exact existing checked-JS generator; no removed bodies/types or new timed row'}
(root / 'scale-project.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record), flush=True)
