import hashlib
import json
from pathlib import Path
import sys
import time

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
sys.path.insert(0, str(repo / 'bench/vs_tsgo'))
import run
import competitors

scale = json.loads((root / 'scale-project.json').read_text())
expected_native = 'ff78eeff3f36f622db610d23881be7165dce31b424481318e82360f1da5935f8'
assert hashlib.sha256((repo / 'zig-out/bin/home-tsc').read_bytes()).hexdigest() == expected_native
assert json.loads((root / 'verified-map.json').read_text())['passed']
commands = run.compiler_commands()
commands['home'] = [str(root / 'home-tsc-current')]
versions = run.verified_compiler_versions(commands)
trace = []
record = {'versions': versions, 'records': trace, 'timings_taken': False,
          'sampling_started': False, 'admission_wall_seconds': {}}
for kind, path in [('positive', Path(scale['project'])), ('negative', Path(scale['negative']))]:
    expected = None if kind == 'positive' else scale['expected_negative_codes']
    for name, command in commands.items():
        started = time.monotonic()
        result, passed = run.admission_process(name, command + ['--noEmit', '-p', str(path / 'tsconfig.json')],
                                             'jsdoc8192', expected_codes=expected, trace=trace)
        record['admission_wall_seconds'][kind + '-' + name] = time.monotonic() - started
        (root / 'scale-admission.json').write_text(json.dumps(record, indent=2) + '\n')
        print(kind, name, 'exit', result.returncode, 'passed', passed, flush=True)
        assert passed, 'Retain failed admission and do not sample'
after = {name: competitors.inventory_hash(competitors.payload_inventory(path))
         for name, path in [('positive', Path(scale['project'])), ('negative', Path(scale['negative']))]}
assert after == scale['input_hashes']
record.update(passed=True, input_hashes_unchanged=True)
(root / 'scale-admission.json').write_text(json.dumps(record, indent=2) + '\n')
print('All six complete scale admissions pass; no timing or sampling.', flush=True)
