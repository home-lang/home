import json
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
verified = json.loads((root / 'verified-profile.json').read_text())
assert verified['passed']
mapping = json.loads((root / 'native-address-map.json').read_text())
profile = json.loads((root / 'resolved-native-profile.json').read_text())
source = subprocess.check_output(['git', 'show', verified['source'] + ':packages/ts_checker/src/check.zig'], cwd=repo)
records = []
for name in ['memberAccessReceiverIsRequireAssignmentBinding', 'leadingJsDocBodyWithStart', 'jsDocTypeForPreviousIdentifierDecl']:
    entries = [item for item in profile['observed_functions'].values() if any(symbol.endswith('.' + name) for symbol in item['symbols'])]
    assert len(entries) == 1
    entry = entries[0]
    marker = ('    fn ' + name + '(').encode()
    start = source.index(marker)
    end = source.index(b'    fn ', start + len(marker))
    (root / (name + '-source.zig')).write_bytes(source[start:end])
    command = ['/Users/chris/.local/share/pantry/global/bin/llvm-objdump', '--disassemble',
               '--start-address=' + hex(entry['start']), '--stop-address=' + hex(entry['end']), str(root / 'home-tsc-current')]
    result = subprocess.run(command, capture_output=True, text=True, check=True)
    (root / (name + '-native-assembly.txt')).write_text(result.stdout)
    records.append({'name': name, 'command': command, 'start': hex(entry['start']), 'end': hex(entry['end']),
                    'early_displayed_offsets': entry['early_displayed_offsets'], 'middle_displayed_offsets': entry['middle_displayed_offsets'],
                    'CPU_share_inferred': False})
(root / 'observed-code.json').write_text(json.dumps(records, indent=2) + '\n')
print(json.dumps(records), flush=True)
