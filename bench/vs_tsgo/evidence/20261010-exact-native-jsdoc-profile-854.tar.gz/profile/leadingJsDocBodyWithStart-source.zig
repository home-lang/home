    fn leadingJsDocBodyWithStart(self: *Checker, src: []const u8, decl_start: u32) ?JsDocBody {
        if (self.source_facts.may_have_jsdoc) |cached| {
            if (!cached) return null;
        } else {
            const may_have_jsdoc = std.mem.indexOf(u8, src, "/**") != null;
            self.source_facts.may_have_jsdoc = may_have_jsdoc;
            if (!may_have_jsdoc) return null;
        }
        var limit = @min(@as(usize, decl_start), src.len);
        var trimmed_end = limit;
        while (trimmed_end > 0 and std.ascii.isWhitespace(src[trimmed_end - 1])) : (trimmed_end -= 1) {}
        if (trimmed_end >= "export".len and
            std.mem.eql(u8, src[trimmed_end - "export".len .. trimmed_end], "export") and
            (trimmed_end == "export".len or !isJsDocIdentChar(src[trimmed_end - "export".len - 1])))
        {
            limit = trimmed_end - "export".len;
        }
        // Walk backward through only the trivia adjacent to the declaration.
        // A whole-prefix `lastIndexOf` makes a large file with many functions
        // quadratic even though the relevant comment is always local.
        var cursor = limit;
        const end = while (true) {
            while (cursor > 0 and std.ascii.isWhitespace(src[cursor - 1])) cursor -= 1;
            if (cursor >= 2 and std.mem.eql(u8, src[cursor - 2 .. cursor], "*/")) {
                break cursor - 2;
            }
            var line_start = cursor;
            while (line_start > 0 and src[line_start - 1] != '\n' and src[line_start - 1] != '\r') {
                line_start -= 1;
            }
            const line_comment = std.mem.indexOf(u8, src[line_start..cursor], "//") orelse return null;
            cursor = line_start + line_comment;
        };
        var start_cursor = end;
        const start = while (start_cursor > 0) {
            start_cursor -= 1;
            if (start_cursor + 2 > end or
                src[start_cursor] != '/' or
                src[start_cursor + 1] != '*') continue;
            if (start_cursor + 2 < src.len and src[start_cursor + 2] == '*') break start_cursor;
            return null;
        } else return null;
        return .{
            .body = src[start + 3 .. end],
            .start = start + 3,
        };
    }

