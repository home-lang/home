import hashlib
import json
from pathlib import Path
import sys

root = Path(__file__).resolve().parent
prior = Path('/Users/chris/.cache/home-ts-callable-intersection-facts.34PC25')
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
sys.path.insert(0, str(repo / 'bench/vs_tsgo'))
import run
import competitors

assert not (root / 'results.json').exists()
home = prior / 'candidate-home-tsc'
assert hashlib.sha256(home.read_bytes()).hexdigest() == '04d9c9188e521a339f6a6798c1d88b3d73af72ad6daa679aa753c6dbce16475c'
trace = []
before = {}
for variant in ['void-method', 'no-this-interface', 'explicit-def', 'typed-callback', 'callback-fields', 'direct-model', 'direct-indexed-def']:
    for negative in [False, True]:
        name = variant + ('-negative' if negative else '-positive')
        original = prior / ('collection-factory-negative' if negative else 'collection-factory-positive')
        project = root / name
        for relative in ['tsconfig.json', 'src/util.d.ts', 'src/factory.ts']:
            run.write(project / relative, (original / relative).read_text())
        run.generate_minimal_lib(project)
        text = (original / 'src/main.ts').read_text()
        if variant in ['void-method', 'no-this-interface']:
            text = text.replace('add(value:T):this', 'add(value:T):void')
        if variant == 'no-this-interface':
            text = text.replace('declare class Collection<T>', 'interface Collection<T>')
        if variant == 'explicit-def':
            text = text.replace('factory.create("model",', 'factory.create<Model,ModelDef>("model",')
        if variant == 'typed-callback':
            text = text.replace('(instance,def)=>', '(instance:Model,def:ModelDef)=>')
        if variant == 'callback-fields':
            body = ('const kind:"model"=def.kind;const output:string=instance.state.output;void kind;void output;' if not negative else 'const kind:number=def.kind;const output:number=instance.state.output;def.missing;instance.state.missing;void kind;void output;')
            start = text.index(' for(const part')
            end = text.index(' void instance;', start)
            text = text[:start] + body + '\n' + text[end:]
        if variant in ['direct-model', 'direct-indexed-def']:
            start = text.index('const result:factory.Creator<Model>')
            body = text[text.index(' for(const part', start):text.index(' void instance;', start)]
            declaration = 'declare const instance:Model;const def=instance.state.def;' if variant == 'direct-model' else 'declare const def:Model["state"]["def"];'
            text = text[:start] + declaration + '\n' + body
        run.write(project / 'src/main.ts', text)
        before[name] = competitors.inventory_hash(competitors.payload_inventory(project))
        commands = run.compiler_commands()
        commands['home'] = [str(home)]
        for compiler, command in commands.items():
            codes = ['2322', '2322', '2339', '2339'] if variant == 'callback-fields' else ['2322', '2339']
            result, passed = run.admission_process(compiler, command + ['--noEmit', '-p', str(project / 'tsconfig.json')], name, expected_codes=codes if negative else None, trace=trace)
            (root / 'results.json').write_text(json.dumps({'records': trace, 'before': before, 'timings_taken': False}, indent=2) + '\n')
            print(name, compiler, result.returncode, passed, trace[-1]['codes'], flush=True)
after = {name: competitors.inventory_hash(competitors.payload_inventory(root / name)) for name in before}
assert before == after
(root / 'results.json').write_text(json.dumps({'records': trace, 'before': before, 'after': after, 'timings_taken': False}, indent=2) + '\n')
