import hashlib
import io
import json
from pathlib import Path
import tarfile

root = Path(__file__).resolve().parent
candidate = Path('/Users/chris/.cache/home-ts-callable-intersection-facts.34PC25')
context = Path('/Users/chris/.cache/home-ts-collection-context.HqtTR3')
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
archive = repo / 'bench/vs_tsgo/evidence/20261010-finite-record-qualification-held-863.tar.gz'
assert not archive.exists()
assert (context / 'results.json').exists()
payloads = {}
for directory in [candidate, root, context]:
    for path in sorted(directory.rglob('*')):
        if path.is_file() and path.suffix in ['.json', '.log', '.py', '.ts', '.md', '.txt', '.patch']:
            payloads[directory.name + '/' + str(path.relative_to(directory))] = path.read_bytes()
build = json.loads((candidate / 'candidate-build.json').read_text())
payloads['original-candidate.patch'] = build['source_patch'].encode()
inventory = json.loads((candidate / 'verified-retained-revisions.json').read_text())
for record in inventory['records']:
    path = Path(record['path'])
    data = path.read_bytes()
    assert len(data) == record['bytes'] and hashlib.sha256(data).hexdigest() == record['sha256']
    payloads['prior-revisions/' + path.parent.name + '/' + path.name] = data
checksums = ''.join(hashlib.sha256(data).hexdigest() + '  ' + name + '\n' for name, data in sorted(payloads.items()))
payloads['SHA256SUMS'] = checksums.encode()
with tarfile.open(archive, 'w:gz') as output:
    for name, data in sorted(payloads.items()):
        info = tarfile.TarInfo(name)
        info.size = len(data)
        output.addfile(info, io.BytesIO(data))
with tarfile.open(archive) as retained:
    for line in checksums.splitlines():
        expected, name = line.split('  ', 1)
        assert hashlib.sha256(retained.extractfile(name).read()).hexdigest() == expected
outcome = {'archive': str(archive), 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'payload_checksums_verified': len(payloads) - 1, 'candidate_adopted': False, 'timings_taken': False}
(root / 'archive-outcome.json').write_text(json.dumps(outcome, indent=2) + '\n')
print(json.dumps(outcome), flush=True)
