import hashlib
import json
from pathlib import Path
import sys

root = Path(__file__).resolve().parent
prior = Path('/Users/chris/.cache/home-ts-callable-intersection-facts.34PC25')
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
sys.path.insert(0, str(repo / 'bench/vs_tsgo'))
import run
import competitors

assert not (root / 'results.json').exists()
home = prior / 'candidate-home-tsc'
assert hashlib.sha256(home.read_bytes()).hexdigest() == '04d9c9188e521a339f6a6798c1d88b3d73af72ad6daa679aa753c6dbce16475c'
trace = []
inventories = {}
variants = ['original', 'collection-only', 'record-only', 'unused-collection', 'collection-object', 'explicit', 'direct']
for variant in variants:
    for negative in [False, True]:
        name = variant + ('-negative' if negative else '-positive')
        original = prior / ('collection-factory-negative' if negative else 'collection-factory-positive')
        project = root / name
        for relative in ['tsconfig.json', 'src/lib.d.ts', 'src/util.d.ts', 'src/factory.ts']:
            source = original / relative
            if source.exists():
                run.write(project / relative, source.read_text())
        run.generate_minimal_lib(project)
        text = (original / 'src/main.ts').read_text()
        if variant in ['collection-only', 'unused-collection', 'collection-object']:
            text = text.replace('bag:Record<string,unknown>;', '')
        if variant in ['record-only', 'unused-collection']:
            text = text.replace('traits:Collection<string>;', '')
        if variant == 'record-only':
            text = text.replace('declare class Collection<T>{add(value:T):this;has(value:T):boolean;}\n', '')
        if variant == 'collection-object':
            text = text.replace('declare class Collection<T>{add(value:T):this;has(value:T):boolean;}', 'interface Collection<T>{add(value:T):this;has(value:T):boolean;}')
        if variant == 'explicit':
            text = text.replace('factory.create("model",', 'factory.create<Model>("model",')
        if variant == 'direct':
            start = text.index('const result:factory.Creator<Model>')
            body = text[text.index(' for(const part', start):text.index(' void instance;', start)]
            text = text[:start] + 'declare const def:ModelDef;\n' + body
        run.write(project / 'src/main.ts', text)
        inventories[name] = competitors.inventory_hash(competitors.payload_inventory(project))
        commands = run.compiler_commands()
        commands['home'] = [str(home)]
        for compiler, command in commands.items():
            result, passed = run.admission_process(compiler, command + ['--noEmit', '-p', str(project / 'tsconfig.json')], name, expected_codes=['2322', '2339'] if negative else None, trace=trace)
            (root / 'results.json').write_text(json.dumps({'records': trace, 'before': inventories, 'timings_taken': False}, indent=2) + '\n')
            print(name, compiler, result.returncode, passed, trace[-1]['codes'], flush=True)
after = {name: competitors.inventory_hash(competitors.payload_inventory(root / name)) for name in inventories}
assert inventories == after
(root / 'results.json').write_text(json.dumps({'records': trace, 'before': inventories, 'after': after, 'timings_taken': False}, indent=2) + '\n')
