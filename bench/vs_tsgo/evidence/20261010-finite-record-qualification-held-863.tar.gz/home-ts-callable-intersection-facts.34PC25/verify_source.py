import hashlib
import json
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
patch = subprocess.check_output(['git','diff'],cwd=repo)
added = [line[1:] for line in patch.decode().splitlines() if line.startswith('+') and not line.startswith('+++')]
assert not any('return types.Primitive.any' in line or 'depth >' in line or '__context_debug_marker' in line for line in added)
source = (repo/'packages/ts_checker/src/check.zig').read_text()
start=source.index('    fn applyLogicalAssignmentFlow(')
end=source.index('\n    fn ',start+5)
body=source[start:end]
assert body.count('const checked = self.hir.typeOf(a.value);')==2
assert 'lhs_non_null' not in body
assert 'target.key.obj_name != lhs.key.obj_name' in body
assert 'lhs_id.name != target_id.name' in body
assert 'std.mem.indexOf(u8, self.source.?, "__context_debug_marker")' not in source
result={'passed':True,'source_parent':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo).decode().strip(),
 'patch_sha256':hashlib.sha256(patch).hexdigest(),'logical_poststatement_reconstruction_removed':True,
 'same_target_guards_retained':True,'new_any_fallback_or_semantic_cap':False,'debug_instrumentation_absent':True}
(root/'verified-source.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result),flush=True)
