import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
sys.path.insert(0, str(repo / 'bench/vs_tsgo'))
import run
import compare
import competitors

build = json.loads((root / 'candidate-build.json').read_text())
assert build['exit'] == 0
assert subprocess.check_output(['git', 'diff'], cwd=repo).decode() == build['source_patch']
parent = root / 'parent-home-tsc'
candidate = root / 'candidate-home-tsc'
assert not candidate.exists()
shutil.copyfile(repo / 'zig-out/bin/home-tsc', candidate)
candidate.chmod(0o755)
assert hashlib.sha256(candidate.read_bytes()).hexdigest() == build['native_sha256']
assert hashlib.sha256(parent.read_bytes()).hexdigest() == 'ff78eeff3f36f622db610d23881be7165dce31b424481318e82360f1da5935f8'
profiles = competitors.load_profiles(repo / 'bench/vs_tsgo/profiles/darwin-arm64.json')
commands = run.compiler_commands(profiles)
commands['home'] = [str(candidate)]
versions = run.verified_compiler_versions(commands, profiles)
commands['parent'] = [str(parent)]
def provenance():
    record = run.benchmark_provenance(commands, profiles)
    record['compilers']['parent'] = {'command': commands['parent'], 'executable': run.artifact_provenance(parent)}
    return record
before = provenance()
workloads = run.selected_workloads(None)
trace = []
record = {'schema': 1, 'passed': False, 'before': before, 'after': None, 'records': trace}
for workload in workloads:
    try:
        run.validate(commands, workload, profiles=profiles, trace=trace)
    finally:
        (root / 'image-admission.jsonl').write_text(json.dumps(record, indent=2) + '\n')
    print(workload, 'admitted', flush=True)
after = provenance()
assert after == before
assert len(trace) == 180 and all(row['passed'] for row in trace)
record.update(passed=True, after=after)
(root / 'image-admission.jsonl').write_text(json.dumps(record, indent=2) + '\n')
metadata = {'validation_schema': 5, 'admission': {'path': 'admission.jsonl', 'records': 180},
            'provenance': {'status': 'verified', 'before': before, 'after': after}}
verification = root / 'admission-verification'
verification.mkdir(exist_ok=False)
raw = (root / 'image-admission.jsonl').read_bytes()
(verification / 'admission.jsonl').write_bytes(raw)
metadata['admission']['sha256'] = hashlib.sha256(raw).hexdigest()
compare.validate_admission(verification, metadata, list(commands), workloads)
zod = Path('/Users/chris/.cache/home-ts-zod-admission.RzJCwi/source/package/tsconfig.benchmark.json')
zod_records = []
for name, binary in [('parent', parent), ('candidate', candidate)]:
    command = [str(binary), '--noEmit', '-p', str(zod), '--home-list-unmodeled-any']
    result = subprocess.run(command, capture_output=True, text=True)
    output = result.stdout + result.stderr
    counts = {code: len(re.findall(r'\b' + code + r':', output))
              for code in sorted(set(re.findall(r'\b((?:TS|HM)\d+):', output)))}
    zod_records.append({'image': name, 'command': command, 'exit': result.returncode,
                         'stdout': result.stdout, 'stderr': result.stderr, 'diagnostic_counts': counts})
    (root / 'zod-image-audit.json').write_text(json.dumps(zod_records, indent=2) + '\n')
assert all(row['exit'] == 1 for row in zod_records)
# Retain exact diagnostic delta for this correctness feature; never erase it.
assert zod_records[0]['diagnostic_counts']['HM9002'] == 2
assert sum(count for code, count in zod_records[0]['diagnostic_counts'].items() if code.startswith('TS')) == 241
summary = {'passed': True, 'admissions': 180, 'versions': versions, 'validation_schema': 5,
           'parent_sha256': hashlib.sha256(parent.read_bytes()).hexdigest(),
           'candidate_sha256': hashlib.sha256(candidate.read_bytes()).hexdigest(),
           'provenance_unchanged': True, 'zod_parent_counts': zod_records[0]['diagnostic_counts'], 'zod_candidate_counts': zod_records[1]['diagnostic_counts'],
           'zod_admitted': False, 'timings_taken': False,
           'source_parent': build['source_parent'], 'patch_sha256': hashlib.sha256(build['source_patch'].encode()).hexdigest()}
(root / 'verified-image-admission.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary), flush=True)
