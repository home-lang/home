import hashlib
import json
from pathlib import Path
import sys

root = Path(__file__).resolve().parent
first = Path('/Users/chris/.cache/home-ts-finite-record.4tXOmc')
second = Path('/Users/chris/.cache/home-ts-finite-record-alias.hrHehA')
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
sys.path.insert(0, str(repo / 'bench/vs_tsgo'))
import run
import competitors

assert not (root / 'diagnostic-admission.json').exists()
build = json.loads((root / 'candidate-build.json').read_text())
assert build['exit'] == 0 and hashlib.sha256((repo / 'zig-out/bin/home-tsc').read_bytes()).hexdigest() == build['native_sha256']
cases = [(name, first / name, codes) for name, codes in [
 ('ambient-string-positive', None), ('ambient-string-negative', ['2322', '2540', '7053']),
 ('ambient-number-positive', None), ('ambient-number-negative', ['2322', '2540', '7053']),
 ('extended-positive', None), ('extended-negative', ['2322', '2339', '2339', '2353', '2540', '2741'])]]
cases += [(name, second / name, ['2322', '2339'] if 'negative' in name else None)
          for name in ['context-positive','context-negative','context-explicit-positive','context-explicit-negative']]
cases += [(name, Path('/Users/chris/.cache/home-ts-finite-context.wESqP5') / name, ['2322', '2322'] if 'negative' in name else None)
          for name in ['priority-positive', 'priority-negative']]
cases += [('regression-' + name, Path('/Users/chris/.cache/home-ts-finite-context.wESqP5') / ('regression-' + name), codes) for name, codes in [('optional-slots', ['18048', '18048']), ('returned-arrow', ['7006'])]]
cases += [(name, Path('/Users/chris/.cache/home-ts-resolved-result-context.PNzvph')/name, codes) for name,codes in [('flow-positive',None),('flow-negative',['2322','2339']),('flow-reduction-local',None),('flow-reduction-imported',None)]]
cases += [('typeof-callable-union', Path('/Users/chris/.cache/home-ts-logical-flow-scope.sz5cch/typeof-callable-union'), ['2322','2339'])]
cases += [(name, Path('/Users/chris/.cache/home-ts-logical-flow-scope.sz5cch')/name, ['2322','2339'] if 'negative' in name else None) for name in ['array-member-index-positive','array-member-index-negative','array-member-loop-positive','array-member-loop-negative']]
cases += [('boundary-callable-intersection', Path('/Users/chris/.cache/home-ts-owned-iterator.DyBXfA/boundary-callable-intersection'), ['2322','2339'])]
before = {name: competitors.inventory_hash(competitors.payload_inventory(path)) for name, path, _ in cases}
trace = []
record = {'records': trace, 'before': before, 'native_sha256': build['native_sha256'], 'timing_started': False}
for workload, project, expected in cases:
    for name, command in run.compiler_commands().items():
        result, passed = run.admission_process(name, command + ['--noEmit', '-p', str(project / 'tsconfig.json')],
            workload, expected_codes=expected, trace=trace)
        (root / 'diagnostic-admission.json').write_text(json.dumps(record, indent=2) + '\n')
        print(workload, name, result.returncode, passed, trace[-1]['codes'], flush=True)
after = {name: competitors.inventory_hash(competitors.payload_inventory(path)) for name, path, _ in cases}
assert before == after
record.update(after=after, passed=all(row['passed'] for row in trace))
(root / 'diagnostic-admission.json').write_text(json.dumps(record, indent=2) + '\n')
assert record['passed'], 'Retain all mismatches; no adoption'
