type Exclude<T,U>=T extends U?never:T;
type Record<K extends keyof any,T>={[P in K]:T};
