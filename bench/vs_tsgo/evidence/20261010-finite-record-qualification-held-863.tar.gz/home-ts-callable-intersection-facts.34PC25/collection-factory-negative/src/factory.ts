type Trait={state:{def:any;[key:string]:any}};
export interface Creator<T extends Trait,D=T["state"]["def"]>{new(def:D):T;init(instance:T,def:D):asserts instance is T;}
export declare function create<T extends Trait,D=T["state"]["def"]>(name:string,initializer:(instance:T,def:D)=>void):Creator<T,D>;
