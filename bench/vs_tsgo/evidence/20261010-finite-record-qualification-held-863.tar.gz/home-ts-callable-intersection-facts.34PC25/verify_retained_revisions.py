import hashlib
import json
from pathlib import Path

base=Path('/Users/chris/.cache')
root=Path(__file__).resolve().parent
expected={
 'home-ts-finite-record.4tXOmc':['parent-probes.json','parent-ambient-probes.json','extended-admission.json','checker.json','candidate-build.json'],
 'home-ts-finite-record-alias.hrHehA':['finite-admission.json','context-probes.json','context-explicit-probes.json','zod-image-audit.json','candidate-build.json'],
 'home-ts-finite-context.wESqP5':['checker.json','remaining-gates.json','diagnostic-admission.json','regression-reference-probes.json'],
 'home-ts-owned-result-inference.fb1ikL':['checker.json','diagnostic-admission.json','zod-image-audit.json'],
 'home-ts-context-representation.wKzDZ4':['diagnostic.json','diagnostic.log','outcome.json'],
 'home-ts-resolved-result-context.PNzvph':['diagnostic-admission.json','flow-probes.json','flow-reductions.json','zod-image-audit.json'],
 'home-ts-finite-flow.lSAdOR':['checker.json','queued-cancellation.json','key-flow-cause.json'],
 'home-ts-exact-logical-flow.Ua2bV6':['checker.json','candidate-build.json','checker-first-failure.json','program-queued-cancellation.json'],
 'home-ts-logical-flow-scope.sz5cch':['diagnostic-admission.json','nested-probes.json','array-member-probes.json','typeof-probes.json','entrypoint-cancellation.json'],
 'home-ts-owned-iterator.DyBXfA':['diagnostic-admission.json','boundary-probes.json','alias-boundary-probes.json','zod-image-audit.json','cli-queued-cancellation.json'],
 'home-ts-runtime-object-facts.wxGN82':['checker.json','factory-shape-probes.json','interrupted-qualification.json'],
 'home-ts-typeof-diagnostic.ecn6Fy':['diagnostic.json','diagnostic.log','outcome.json']}
records=[]
for directory,names in expected.items():
 for name in names:
  path=base/directory/name
  assert path.is_file() and not path.is_symlink(), str(path)
  records.append({'path':str(path),'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
assert json.loads((base/'home-ts-owned-result-inference.fb1ikL/zod-image-audit.json').read_text())[-1]['exit']==-11
assert json.loads((base/'home-ts-finite-context.wESqP5/checker.json').read_text())['exit']==1
assert json.loads((base/'home-ts-owned-iterator.DyBXfA/diagnostic-admission.json').read_text())['passed']
result={'passed':True,'revisions':len(expected),'retained_records':len(records),'all_required_failures_retained':True,'records':records}
(root/'verified-retained-revisions.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='records'}),flush=True)
