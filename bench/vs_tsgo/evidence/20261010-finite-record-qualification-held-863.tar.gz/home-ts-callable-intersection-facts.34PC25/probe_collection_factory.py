import json
from pathlib import Path
import sys

root=Path(__file__).resolve().parent
repo=Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
sys.path.insert(0,str(repo/'bench/vs_tsgo'))
import run

assert not (root/'collection-factory-probes.json').exists()
trace=[]
for negative in [False,True]:
 project=root/('collection-factory-negative' if negative else 'collection-factory-positive')
 run.write(project/'tsconfig.json',run.shared_config())
 run.generate_minimal_lib(project)
 run.write(project/'src/util.d.ts','type Exclude<T,U>=T extends U?never:T;\ntype Record<K extends keyof any,T>={[P in K]:T};\n')
 run.write(project/'src/factory.ts','''type Trait={state:{def:any;[key:string]:any}};
export interface Creator<T extends Trait,D=T["state"]["def"]>{new(def:D):T;init(instance:T,def:D):asserts instance is T;}
export declare function create<T extends Trait,D=T["state"]["def"]>(name:string,initializer:(instance:T,def:D)=>void):Creator<T,D>;
''')
 source='''import * as factory from "./factory";
declare class Collection<T>{add(value:T):this;has(value:T):boolean;}\ntype Literal=string|number|bigint|boolean|null|undefined;
type LiteralPart=Exclude<Literal,symbol>;
interface BaseDef{kind:string;}
interface BaseState<O=unknown,I=unknown>{def:BaseDef;output:O;input:I;traits:Collection<string>;bag:Record<string,unknown>;}
interface Base<O=unknown,I=unknown,S extends BaseState<O,I>=BaseState<O,I>>{state:S;}
interface NestedState extends BaseState<LiteralPart,LiteralPart>{label:string;}
interface Nested extends Base{state:NestedState;}
type Part=LiteralPart|Nested;
interface ModelDef extends BaseDef{kind:"model";parts:Part[];}
interface ModelState<T extends string=string>extends BaseState<T,T>{def:ModelDef;}
interface Model<T extends string=string>extends Base{state:ModelState<T>;}
const result:factory.Creator<Model>=factory.create("model",(instance,def)=>{
 for(const part of def.parts)if(typeof part==="object"&&part!==null){const text:string=part.state.label;void text;}
 void instance;
});void result;
'''
 if negative: source=source.replace('const text:string=part.state.label;','const text:number=part.state.label;part.missing;')
 run.write(project/'src/main.ts',source)
 commands=run.compiler_commands()
 commands['home']=['/Users/chris/.cache/home-ts-owned-iterator.DyBXfA/candidate-home-tsc']
 for name,command in commands.items():
  result,passed=run.admission_process(name,command+['--noEmit','-p',str(project/'tsconfig.json')],'collection-factory-negative' if negative else 'collection-factory-positive',expected_codes=['2322','2339'] if negative else None,trace=trace)
  (root/'collection-factory-probes.json').write_text(json.dumps({'records':trace,'prior_native_frozen':True},indent=2)+'\n')
  print(negative,name,result.returncode,passed,trace[-1]['codes'],flush=True)
