import json
import os
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
state = root / 'diagnostic-command.json'
assert not state.exists()
command = ['perl','scripts/run-bounded.pl','600',sys.executable,str(root/'admit_diagnostics.py')]
record = {'command':command,'status':'running','guard_max_mb':3840}
state.write_text(json.dumps(record,indent=2)+'\n')
environment = dict(os.environ,HOME_RUN_MAX_MB='3840',HOME_RUN_LABEL='ts863-callable-intersection-facts-diagnostics')
with (root/'diagnostic-run.log').open('w') as output:
    result = subprocess.run(command,cwd=repo,env=environment,stdout=output,stderr=subprocess.STDOUT)
record.update(exit=result.returncode,status='complete' if result.returncode==0 else 'incomplete')
state.write_text(json.dumps(record,indent=2)+'\n')
print((root/'diagnostic-run.log').read_text()[-2500:],flush=True)
raise SystemExit(result.returncode)
