declare const init: RequestInit;
const method: string | undefined = init.method;
const wrong: number = init.method;
