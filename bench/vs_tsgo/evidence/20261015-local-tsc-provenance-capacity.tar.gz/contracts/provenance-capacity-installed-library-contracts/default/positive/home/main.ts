declare const init: RequestInit;
const method: string | undefined = init.method;
