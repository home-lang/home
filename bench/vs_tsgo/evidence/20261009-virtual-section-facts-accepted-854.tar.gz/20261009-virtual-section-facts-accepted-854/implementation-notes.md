# Virtual-section prefix facts (#854)

Exact parent: `5ea87f0f81ce20d18782abcad2d0412797b9d3a0`.
Parent native SHA-256: `69836df6bd81695ed3f78c2b147a7ec8ac908e5e406da5523b9da7ed3c4a895a`.

The landed-source early/middle samples map repeated prefix scanning in
`virtualSectionStartForNode` (172/169 leaf observations, not whole-run CPU
percentages). This candidate uses a complete lazy source-owned list of marker
line starts. A single full physical-source pass includes raw `@filename:` or
`@Filename:` substrings anywhere on each line, appending a line once even if
both markers occur. It intentionally is not a directive/comment parser.

Binary search returns the last start at or before the clamped query. The
containing line is fully inspected, including markers after the queried byte;
an exact newline query still belongs to the preceding line. Empty sources,
trailing empty lines, positions beyond EOF, and default start zero preserve
the original scalar scan. Both node and raw-position queries share the facts;
the existing node cache, filename parsing and section-end lookup are unchanged.
Facts contain positions only, not types or mutable HIR data. Source replacement
deinitializes/resets them. All allocation failures release partial lists and
retain the complete original scalar scanner for that source revision.

Four controls cover every byte through/beyond EOF, raw markers in strings and
comments, marker case/duplicates, LF/CRLF, newline ownership, clamped HIR spans,
source replacement/absence/null, every forced-growth construction allocation
failure with balanced ownership and no repeated build attempt, and complete
mixed virtual-JS/TS diagnostic equality against forced scalar queries.

First full checker run: 4,545 passed / one test failed. The failing allocator
counts successful allocations rather than the rejected attempt; only that test
assertion was corrected. Complete original draft and failure log are retained.
Corrected full checker: all 4,546 pass. No semantic workaround was introduced.

The complete frozen protocol verifies502 paired rounds and660 admissions.
Accepted source is30330c16947900dd0d9ce441071649c7f822c2fc. Acceptance is
scoped to the statistically supported checked-JS scaling improvement; the
official interval spans zero and recursive-generics remains an adverse warning.
No equivalence, universal speedup or competitor-rank change is established.
