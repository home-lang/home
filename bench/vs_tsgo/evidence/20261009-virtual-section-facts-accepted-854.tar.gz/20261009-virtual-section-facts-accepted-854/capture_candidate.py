import hashlib
import json
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
parent = '5ea87f0f81ce20d18782abcad2d0412797b9d3a0'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip() == parent
for label, count in [('checker',4546), ('program',247), ('driver',200), ('cli',74), ('entrypoint',35)]:
    assert json.loads((root / (label + '-command.json')).read_text())['exit'] == 0
    assert f'All {count} tests passed.' in (root / (label + '.log')).read_text()
assert json.loads((root / 'build-command.json').read_text())['exit'] == 0
assert (root / 'home-tsc-candidate').read_bytes() == (repo / 'zig-out/bin/home-tsc').read_bytes()
patch = subprocess.check_output(['git', 'diff', '--', 'packages/ts_checker/src/check.zig'], cwd=repo)
assert not (root / 'candidate.patch').exists()
(root / 'candidate.patch').write_bytes(patch)
(root / 'candidate-provenance.json').write_text(json.dumps({
    'parent_source': parent,
    'binaries': {name: hashlib.sha256((root / ('home-tsc-' + name)).read_bytes()).hexdigest() for name in ('parent','candidate')},
    'candidate_patch_sha256': hashlib.sha256(patch).hexdigest(),
    'all_full_module_gates_passed': True}, indent=2) + '\n')
print((root / 'candidate-provenance.json').read_text())
