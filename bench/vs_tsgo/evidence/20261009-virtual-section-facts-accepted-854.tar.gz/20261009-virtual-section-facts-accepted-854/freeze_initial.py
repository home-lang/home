import hashlib
import json
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
parent = '5ea87f0f81ce20d18782abcad2d0412797b9d3a0'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip() == parent
patch = subprocess.check_output(['git', 'diff', '--', 'packages/ts_checker/src/check.zig'], cwd=repo)
assert not (root / 'first-draft.patch').exists()
(root / 'first-draft.patch').write_bytes(patch)
(root / 'initial-provenance.json').write_text(json.dumps({
    'source_parent': parent,
    'first_draft_patch_sha256': hashlib.sha256(patch).hexdigest(),
    'parent_binary_sha256': hashlib.sha256((root / 'home-tsc-parent').read_bytes()).hexdigest(),
    'mapped_profile_source': 'b9e6d25916804d238c17dc9caee4e1d05fdd3032',
    'timing_acceptance': 'pending; no timing samples yet'}, indent=2) + '\n')
print('Preserved complete initial source/test draft against the exact landed parent.')
