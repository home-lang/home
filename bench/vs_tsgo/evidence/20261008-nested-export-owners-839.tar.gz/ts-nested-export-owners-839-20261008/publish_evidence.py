import hashlib
import json
from pathlib import Path
import re
import statistics
import sys
import tarfile

repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
sys.path.insert(0, str(repo / 'bench/vs_tsgo'))
import run
import compare

root = Path(__file__).resolve().parent
result = repo / 'bench/vs_tsgo/results/20261008T042639Z'
matrix = repo / 'bench/vs_tsgo/evidence/20261008T042639Z.tar.gz'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def verify(path):
    with tarfile.open(path) as tar:
        data = {member.name: tar.extractfile(member).read() for member in tar.getmembers() if member.isfile()}
    checksum_path = next(name for name in data if name.endswith('/SHA256SUMS'))
    prefix = checksum_path.rsplit('/', 1)[0]
    lines = data[checksum_path].decode().splitlines()
    assert len(lines) == len(data) - 1
    for line in lines:
        digest, name = line.split('  ', 1)
        assert sha(data[prefix + '/' + name]) == digest, name
    return data, prefix, len(lines)

data, prefix, checksums = verify(matrix)
assert checksums == 603
raws = [name for name in data if '-round-' in name and name.endswith('.json')]
assert len(raws) == 600
metadata = json.loads(data[prefix + '/metadata.json'])
assert metadata['provenance']['status'] == 'verified'
assert metadata['provenance']['before'] == metadata['provenance']['after']
admission = json.loads(data[prefix + '/admission.jsonl'])
assert len(admission['records']) == 140 and all(row['passed'] for row in admission['records'])
assert admission['passed'] is True
assert admission['before'] == metadata['provenance']['before'] == admission['after']
assert sha(data[prefix + '/admission.jsonl']) == metadata['admission']['sha256']
compare.validate_interleaved_rounds(result, json.loads((result / 'metadata.json').read_text()))
samples = {}
for name in raws:
    filename = name.rsplit('/', 1)[1]
    assert (result / filename).read_bytes() == data[name]
    workload = filename.split('-round-')[0]
    for record in json.loads(data[name])['results']:
        compiler, command_workload = record['command'].split(' ', 1)
        assert command_workload == workload and record['exit_codes'] == [0] and len(record['times']) == 1
        samples.setdefault(workload, {}).setdefault(compiler, []).extend(record['times'])
assert sum(len(times) for group in samples.values() for times in group.values()) == 3000
medians = {workload: {name: statistics.median(times) for name, times in group.items()} for workload, group in samples.items()}
matrix_summary = {
    'home_wins': sum(values['home'] < min(time for name, time in values.items() if name != 'home') for values in medians.values()),
    'home_vs_native_go_wins': sum(values['home'] < values['tsgo'] for values in medians.values()),
    'sha256': sha(matrix.read_bytes()), 'medians': medians,
}

stage_summaries = {}
round_count = 0
for stage in ('screen', 'confirmation', 'families', 'regression_confirmation'):
    directory = root / ('facts-paired-' + stage)
    summary = json.loads((directory / 'summary.json').read_text())
    assert summary['before'] == summary['after']
    admissions = json.loads((directory / 'admission.json').read_text())
    assert len(admissions['records']) == 56 and all(row['passed'] for row in admissions['records'])
    assert admissions['fingerprints'] == summary['before']
    for workload, group in summary['summaries'].items():
        samples = {'parent': [], 'candidate': []}
        rounds = sorted(directory.glob(workload + '-round-*.json'))
        round_count += len(rounds)
        for index, path in enumerate(rounds):
            records = json.loads(path.read_text())['results']
            assert [row['command'] for row in records] == (['parent', 'candidate'] if index % 2 == 0 else ['candidate', 'parent'])
            for row in records:
                assert row['exit_codes'] == [0] and len(row['times']) == 1
                samples[row['command']].extend(row['times'])
        assert samples == group['samples']
        assert statistics.median(samples['parent']) == group['parent_median']
        assert statistics.median(samples['candidate']) == group['candidate_median']
        differences = [old - new for old, new in zip(samples['parent'], samples['candidate'])]
        n = len(differences)
        mean = statistics.mean(differences)
        half = {6: 2.571, 10: 2.262, 20: 2.093, 30: 2.045}[n] * statistics.stdev(differences) / n ** 0.5
        assert group['candidate_wins'] == sum(delta > 0 for delta in differences)
        assert group['paired_mean_saving_seconds'] == mean
        assert group['paired_mean_95pct_t_interval_seconds'] == [mean - half, mean + half]
    stage_summaries[stage] = summary
assert round_count == 566

def identities(side):
    pattern = re.compile(r'^(.+?)\((\d+),(\d+)\): (?:error|warning) (TS\d+|HM\d+):')
    result = []
    for line in (root / ('zod-' + side + '-diagnostics.log')).read_text().splitlines():
        match = pattern.match(line)
        if match:
            path, row, column, code = match.groups()
            assert '/package/' in path
            result.append((path.split('/package/', 1)[1], int(row), int(column), code))
    assert len(result) == 199 and sum(item[3] == 'HM9002' for item in result) == 3
    return sorted(result)

zod = identities('parent')
assert zod == identities('candidate')
assert sha(Path('/Users/chris/.cache/home-ts-839-evidence/home-tsc-export-facts-candidate-3318885fb').read_bytes()) == '4b4af24fdb57dcfdba69de49a460014a1800cacdda7164a4fc8614e727e9ec2d'
assert sha((root / 'home-tsc-candidate').read_bytes()) == '92338a9715ef01c3bf7e7238f980e9df72e856340f6684daabf98924ceea4960'

prefix = 'ts-nested-export-owners-839-20261008'
members = {}
files = ['candidate.patch', 'candidate-build.log', 'program.log', 'checker.log', 'cli.log', 'entrypoint.log', 'harness.log', 'screen.log', 'confirmation.log', 'families.log', 'regression-confirmation.log', 'paired.py', 'zod-parent.json', 'zod-candidate.json', 'zod-parent-diagnostics.log', 'zod-candidate-diagnostics.log', 'zod-parent.log', 'zod-candidate.log', 'pickier.log', 'five-compiler.log', 'depth-issue.md', 'publish_evidence.py']
for name in files:
    members[prefix + '/' + name] = (root / name).read_bytes()
for directory in ('facts-paired-screen', 'facts-paired-confirmation', 'facts-paired-families', 'facts-paired-regression_confirmation'):
    for path in sorted((root / directory).rglob('*')):
        if path.is_file():
            members[prefix + '/' + str(path.relative_to(root))] = path.read_bytes()
scale = Path('/Users/chris/.cache/home-ts-839-evidence/reexport-scale-4096')
for path in sorted(scale.rglob('*')):
    if path.is_file():
        members[prefix + '/reexport-scale-4096/' + str(path.relative_to(scale))] = path.read_bytes()
members[prefix + '/verified-summary.json'] = (json.dumps({'source_parent': 'eaaddf213ad096f443f936151b9416e73ead7db8', 'source_commit': '30d3824da0cb58c943377418f8a6454f2ca2122e', 'matrix': matrix_summary, 'paired_results': stage_summaries, 'zod_diagnostic_multiset': zod}, indent=2) + '\n').encode()
members[prefix + '/README.txt'] = b'''Nested export-owner reuse evidence (#839), source 30d3824da.
Exact parent eaaddf213 has compiler inputs identical to 69c3d28ee: only docs/evidence differ. Its frozen compiler SHA-256 is 4b4af24f...; the candidate is the retained 1137b455 patch with SHA-256 92338a97..., with unchanged Zig 2163 / stripped ReleaseFast flags.
All 566 byte-identical pair rounds are retained: screen 20/6, independent confirmation 30/10, all 20 families at 10 pairs each, and independent 30-pair rechecks for all ten families with >3% slower screen medians. This includes the initial wholly negative overload saving interval; that warning is not discarded. Every stage retains 56 successful admission records, all fingerprints and runner byte hashes before/after. Overlapping intervals are not equivalence. The verifier recomputes every sample, median, win count and two-sided 95% paired t interval.
The full five-compiler archive is separately published as 20261008T042639Z.tar.gz. Complete compiler/source test and Zod logs are retained. Checker tests execute their exact unchanged cached artifact; a 21 MiB footprint is a cached run, not a new checker compilation. No named test filter or source exclusion was applied.
The secondary 4096-leaf graph uses the same generator/eight leaves per barrel; official 64-leaf work is unchanged. Full scale inputs are included.
Zod's complete 106-file diagnostic multisets remain equal (196 TS + 3 HM9002). Observed parent/candidate footprints 1087/936 MiB are not a universal memory improvement claim.
Existing eight-level fact cutoff is separately tracked in issue #843; reuse does not remove or certify that correctness limit. No guard ceiling or disk floor is relaxed. Local reproduction paths remain in raw logs/records. Compiler binaries are not redistributed here.
'''
members[prefix + '/SHA256SUMS'] = ''.join(f'{sha(content)}  {name.removeprefix(prefix + "/")}\n' for name, content in sorted(members.items())).encode()
destination = repo / 'bench/vs_tsgo/evidence/20261008-nested-export-owners-839.tar.gz'
run.write_evidence_archive(destination, members)
_, _, paired_checksums = verify(destination)
print(json.dumps({'matrix': matrix_summary, 'matrix_checksums': checksums, 'paired_archive': str(destination), 'paired_sha256': sha(destination.read_bytes()), 'paired_checksums': paired_checksums, 'paired_rounds': round_count}))
