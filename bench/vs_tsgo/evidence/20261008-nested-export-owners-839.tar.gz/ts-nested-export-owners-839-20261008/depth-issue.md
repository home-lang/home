## Finding

`packages/ts_program/src/ts_program.zig` currently begins `moduleExportFactsFromResolvedModuleDepth` with `if (depth >= 8) return .{};` (source parent `eaaddf213`, compiler source `69c3d28ee`). This silently bounds fact propagation through otherwise valid named/star re-export chains. The companion `export_origins.Query` already uses visited worklist states without an arbitrary depth limit, so origin identity and legacy fact propagation have different reachability contracts.

General recursive-owner reuse under #839 is a separate storage optimization and must not be presented as removing this limit or proving long-chain fact correctness. No new cutoff is allowed. This existing limit remains an explicit outstanding requirement toward #416's fair TypeScript feature/performance goal.

## Required work

- Add exact TypeScript-oracle and Program/CLI controls beyond eight re-export layers for generic/call-only functions, value/type/namespace meanings, ambient const enums, readonly/default metadata and type-only restriction provenance.
- Include cyclic graphs, diamonds, aliases, duplicate paths to one declaration, ambiguity and missing targets. Preserve the appropriate root/local-vs-forwarded semantics; do not suppress diagnostics or replace unresolved facts with claimed completeness.
- Replace the depth cutoff with cycle-safe complete traversal/fact evaluation. Address stack safety and repeated graph work logically rather than raising the numeric limit.
- Retain full semantic tests, pinned full-Zod diagnostic identity comparisons, and exact-parent measurements on unchanged workloads. Add fair deep-chain rejection controls where CLI behavior depends on these facts; do not time a compiler that fails admission.
- Document result IDs, source/binary/input provenance, raw samples, regressions/tradeoffs and README summary. Keep conventional commits linked here and to #839 as appropriate.

## Scope/provenance

This finding is verified by current source inspection. No deep-chain compiler failure or timing improvement is claimed yet; those must be demonstrated by the new controls. Related: #416, #839, #548.
