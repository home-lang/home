import json
from pathlib import Path
import shlex
import statistics
import subprocess
import sys

REPO = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
sys.path.insert(0, str(REPO / 'bench/vs_tsgo'))
import run
import competitors

root = Path(__file__).resolve().parent
stage = sys.argv[1]
assert stage in ('screen', 'confirmation', 'families', 'regression_confirmation')
commands = {
    'parent': ['/Users/chris/.cache/home-ts-839-evidence/home-tsc-export-facts-candidate-3318885fb'],
    'candidate': [str(root / 'home-tsc-candidate')],
}
projects = {name: run.CORPUS / name / 'tsconfig.json' for name in run.manifest()['workloads']}
projects['scale4096'] = Path('/Users/chris/.cache/home-ts-839-evidence/reexport-scale-4096/tsconfig.json')
selected = list(run.manifest()['workloads']) if stage == 'families' else ['reexport_graph', 'scale4096']
if stage == 'regression_confirmation':
    screened = json.loads((root / 'facts-paired-families/summary.json').read_text())['summaries']
    selected = [name for name, values in screened.items() if values['candidate_median'] > values['parent_median'] * 1.03]
    assert selected, 'No >3% slower family median requires a targeted recheck'
output = root / ('facts-paired-' + stage)
output.mkdir(exist_ok=False)

def fingerprints():
    return {
        'binaries': {name: run.sha256_file(Path(command[0])) for name, command in commands.items()},
        'inputs': {name: competitors.inventory_hash(competitors.payload_inventory(path.parent)) for name, path in projects.items()},
        'harness': {name: run.sha256_file(run.HERE / name) for name in ('run.py', 'compare.py', 'competitors.py')},
        'hyperfine': run.artifact_provenance(run.resolved_tool('hyperfine')),
        'runner': run.artifact_provenance(Path(__file__)),
    }

before = fingerprints()
trace = []
for workload in run.manifest()['workloads']:
    run.validate(commands, workload, trace=trace)
assert len(trace) == 56 and all(record['passed'] for record in trace)
(output / 'admission.json').write_text(json.dumps({'records': trace, 'fingerprints': before}, indent=2) + '\n')
summaries = {}
for workload in selected:
    argv = {name: command + ['--noEmit', '-p', str(projects[workload])] for name, command in commands.items()}
    for _ in range(3):
        for command in argv.values():
            result = subprocess.run(command, check=True, capture_output=True)
            assert not result.stdout and not result.stderr
    count = 10 if stage == 'families' else (30 if stage in ('confirmation', 'regression_confirmation') else 20)
    if workload == 'scale4096':
        count = 10 if stage == 'confirmation' else 6
    samples = {name: [] for name in commands}
    for index in range(count):
        order = list(commands)
        if index % 2:
            order.reverse()
        path = output / f'{workload}-round-{index:03d}.json'
        command = ['hyperfine', '--shell=none', '--runs', '1', '--style', 'none', '--export-json', str(path)]
        for name in order:
            command += ['--command-name', name, shlex.join(argv[name])]
        subprocess.run(command, check=True)
        records = json.loads(path.read_text())['results']
        assert [record['command'] for record in records] == order
        for record in records:
            assert record['exit_codes'] == [0] and len(record['times']) == 1
            samples[record['command']].extend(record['times'])
    differences = [old - new for old, new in zip(samples['parent'], samples['candidate'])]
    mean = statistics.mean(differences)
    critical = {6: 2.571, 10: 2.262, 20: 2.093, 30: 2.045}[count]
    half = critical * statistics.stdev(differences) / count ** 0.5
    summaries[workload] = {
        'samples': samples,
        'parent_median': statistics.median(samples['parent']),
        'candidate_median': statistics.median(samples['candidate']),
        'candidate_wins': sum(value > 0 for value in differences),
        'paired_mean_saving_seconds': mean,
        'paired_mean_95pct_t_interval_seconds': [mean - half, mean + half],
    }
after = fingerprints()
assert before == after
summary = {'source_parent': 'eaaddf213ad096f443f936151b9416e73ead7db8', 'parent_compiler_source': '69c3d28ee6469bf89816a45bba9290d919805085', 'candidate_patch_sha256': run.sha256_file(root / 'candidate.patch'), 'before': before, 'after': after, 'warmups': 3, 'stage': stage, 'summaries': summaries}
(output / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary), flush=True)
