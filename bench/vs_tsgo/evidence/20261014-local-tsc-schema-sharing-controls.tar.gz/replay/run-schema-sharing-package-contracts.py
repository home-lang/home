from pathlib import Path
import subprocess,json,sys
r=Path.cwd();c=r/'.home-cache/owner-transfer';home=c/'schema-sharing-final-release/bin/home-tsc';reference=r/'.home-cache/table-replacement/owned-project/node_modules/typescript/bin/tsc';rows=[]
for name in ['library-array','optional-object','imported-generic','generic-indexed','optional-indexed','recursive-interface','automatic-variable','declaration']:
 command=['python3','scripts/tests/test-ts-'+name+'-cli.py','--home',str(home),'--reference',str(reference),'--output',str(c/('schema-sharing-retry-package-'+name))];print(name+' started',flush=True)
 with (c/('schema-sharing-retry-package-'+name+'.log')).open('w') as log:p=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
 rows.append(dict(name=name,command=command,exit=p.returncode));(c/'schema-sharing-retry-package-contracts-summary.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,p.returncode,flush=True)
 if p.returncode:sys.exit(p.returncode)

p=subprocess.run(["python3",str(c/"remaining-array-controls/run.py")]);sys.exit(p.returncode)
