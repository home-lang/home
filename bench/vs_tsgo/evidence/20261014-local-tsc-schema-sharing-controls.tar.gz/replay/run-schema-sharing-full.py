from pathlib import Path
import subprocess,json,hashlib,sys
r=Path.cwd();c=r/'.home-cache/owner-transfer';z=r/'.home-cache/toolchains/zig-aarch64-macos-0.17.0-dev.2163+89ff10d56/zig';frozen=json.loads((c/'schema-sharing-source-hashes.json').read_text());rows=[]
for name in ['ts_checker','ts_driver','tsc_main','tsc_streams']:
 assert all(hashlib.sha256((r/n).read_bytes()).hexdigest()==v for n,v in frozen.items())
 command=[str(z),'build','test','--cache-dir',str(r/'.home-cache/generic-return-zig-cache'),'-Dfilter='+name,'-Denable_jsc=false','-j1','--summary','all'];print(name+' started',flush=True)
 with (c/('schema-sharing-final-full-'+name+'.log')).open('w') as log:p=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
 rows.append(dict(name=name,command=command,exit=p.returncode));(c/'schema-sharing-final-full-summary.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,p.returncode,flush=True)
 assert all(hashlib.sha256((r/n).read_bytes()).hexdigest()==v for n,v in frozen.items())
 if p.returncode:sys.exit(p.returncode)
