declare const locales:readonly string[];
"a".localeCompare("b",locales);
