for(const [key,value] of Object.entries([1,2])){const wrong:boolean=value;}
