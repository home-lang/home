const entries=Object.entries({a:1,b:"text"});
const wrong:boolean=entries[0][1];
