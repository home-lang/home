"a".localeCompare("b", undefined, {numeric:true});
