export type Data={a:number}
