export interface Data {a:number}
