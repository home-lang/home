declare const data:Record<string,readonly number[]>;
for(const [key,value] of Object.entries(data)){
 const good:readonly number[]=value;
 const wrong:number[]=value;
}
