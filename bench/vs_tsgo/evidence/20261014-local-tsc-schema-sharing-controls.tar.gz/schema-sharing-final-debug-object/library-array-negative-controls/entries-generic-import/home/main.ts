import type {Box} from "./types";
declare const box:Box<number>;
for(const [key,value] of Object.entries(box)){const anything:boolean=value;}
