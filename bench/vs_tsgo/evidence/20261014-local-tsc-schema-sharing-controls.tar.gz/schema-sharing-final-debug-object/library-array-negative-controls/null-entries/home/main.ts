Object.entries(null);
Object.entries(undefined);
