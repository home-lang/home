interface Data {[key:string]:number; a:number}
declare const data:Data;
for(const [key,value] of Object.entries(data)){const wrong:boolean=value;}
