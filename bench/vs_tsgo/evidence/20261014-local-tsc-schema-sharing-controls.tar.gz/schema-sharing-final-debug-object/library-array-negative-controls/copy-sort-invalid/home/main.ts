declare const rows:{id:number}[];
rows.toSorted((a,b)=>"bad");
