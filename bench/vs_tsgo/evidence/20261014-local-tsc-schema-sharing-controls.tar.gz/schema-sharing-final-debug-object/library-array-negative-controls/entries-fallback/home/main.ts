interface Data {a:number}
declare const data:Data;
for(const [key,value] of Object.entries(data)){ const anything:boolean=value; }
