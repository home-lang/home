declare const data:Record<string,number>;
for(const [key,value] of Object.entries(data)){
 const k:string=key;
 const wrong:boolean=value;
}
