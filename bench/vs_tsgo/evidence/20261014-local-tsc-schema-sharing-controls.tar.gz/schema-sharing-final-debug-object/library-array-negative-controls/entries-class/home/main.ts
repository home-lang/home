class Data {a=1}
for(const [key,value] of Object.entries(new Data())){const anything:boolean=value;}
