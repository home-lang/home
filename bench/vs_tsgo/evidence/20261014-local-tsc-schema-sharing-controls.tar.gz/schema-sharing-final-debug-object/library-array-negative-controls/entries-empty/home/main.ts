for(const [key,value] of Object.entries({})){const wrong:boolean=value;}
