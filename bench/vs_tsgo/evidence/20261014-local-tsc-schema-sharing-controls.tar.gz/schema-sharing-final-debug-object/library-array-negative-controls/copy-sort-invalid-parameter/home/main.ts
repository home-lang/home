declare const rows:{id:number}[];
rows.toSorted((a:string,b:string)=>0);
