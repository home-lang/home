const compared:number = "item2".localeCompare("item10", undefined, {numeric:true});
