declare const rows: readonly {id:number}[];
const sorted = rows.toSorted((a,b)=>a.id-b.id);
sorted.push({id:1});
