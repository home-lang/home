declare const rows: {id:number}[];
const sorted = rows.toSorted((a,b)=>a.id-b.id);
const id:number=sorted[0].id;
