type Scalar=string|number|boolean|null;
type Value=Scalar|readonly Scalar[];
function test(value:Value){
 const candidates=Array.isArray(value)?value:[value];
 return candidates.map(candidate=>String(candidate));
}
