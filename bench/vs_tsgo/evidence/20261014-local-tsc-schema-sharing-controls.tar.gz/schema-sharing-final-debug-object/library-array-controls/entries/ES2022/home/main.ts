function rows<Row extends Record<string,unknown>>(indexes:Record<string,readonly Row[]>){
 for(const [name,values] of Object.entries(indexes)){
  const key:string=name;
  const rows:readonly Row[]=values;
 }
}
