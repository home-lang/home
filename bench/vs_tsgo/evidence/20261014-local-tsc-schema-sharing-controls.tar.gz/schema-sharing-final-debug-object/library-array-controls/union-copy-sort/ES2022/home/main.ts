declare const rows: {id:number}[]|{id:number;name:string}[];
const sorted=rows.toSorted((a,b)=>a.id-b.id);
