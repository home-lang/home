from pathlib import Path
import hashlib,json,os,subprocess,re,sys
root=Path.cwd();out=root/'.home-cache/table-replacement';project=out/'owned-project';sources=json.loads((out/'owned-project-source-hashes.json').read_text());guard=root/'scripts/run-bounded.pl';home=root/'.home-cache/owner-transfer/schema-sharing-final-release/bin/home-tsc';reference=project/'node_modules/@typescript/typescript-darwin-arm64/lib/tsc';report={'source_count':len(sources),'runs':[],'replacement_verified':False}
baseline_files={str(p.relative_to(project)) for p in project.rglob('*') if p.is_file()}

def save(): (out/'schema-sharing-final-release-summary.json').write_text(json.dumps(report,indent=2)+'\n')
def verify():
 changed=[p for p,h in sources.items() if not (project/p).is_file() or hashlib.sha256((project/p).read_bytes()).hexdigest()!=h]
 if changed:raise SystemExit('Source changed '+str(changed))
 expected=baseline_files.copy()
 control=project/'examples/home-tsc-negative-control.ts'
 if control.exists():expected.add(str(control.relative_to(project)))
 actual={str(p.relative_to(project)) for p in project.rglob('*') if p.is_file()}
 if actual!=expected:raise SystemExit('Unexpected project outputs/removals '+str(sorted(actual^expected)))
def run(name,exe,args):
 env=os.environ.copy();env.update(HOME_RUN_MAX_MB='3840',HOME_RUN_LABEL='schema-sharing-final-release-'+name)
 argv=[str(exe)]+args
 print(name+' started',flush=True);r=subprocess.run(argv,cwd=project,env=env,capture_output=True,text=True,timeout=300)
 (out/('schema-sharing-final-release-'+name+'.log')).write_text(r.stdout+r.stderr)
 report['runs'].append({'name':name,'command':argv,'cwd':str(project),'sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr});save();print(name+' exit '+str(r.returncode),flush=True);return r
verify();listing=run('reference-files',reference,['--project','tsconfig.json','--listFilesOnly','--pretty','false'])
if listing.returncode:raise SystemExit(listing.returncode)
files=[Path(l) for l in listing.stdout.splitlines() if Path(l).is_file()];report['input_hashes']={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in files};report['config_sha256']=hashlib.sha256((project/'tsconfig.json').read_bytes()).hexdigest()
for name,exe in [('reference',reference),('home',home)]:run(name,exe,['--project','tsconfig.json','--pretty','false']);verify()
report['input_changes_after']=[p for p,h in report['input_hashes'].items() if not Path(p).is_file() or hashlib.sha256(Path(p).read_bytes()).hexdigest()!=h]
report['positive_comparison_passed']=not report['input_changes_after'] and all(r['exit']==0 for r in report['runs']);save()
if not report['positive_comparison_passed']:raise SystemExit('Positive comparison incomplete or mismatched')
control=project/'examples/home-tsc-negative-control.ts';assert not control.exists()
text="import { createTable, MemoryTableDriver } from '../resources/functions/table'\nconst driver = new MemoryTableDriver({ products: [{ id: 1 }] })\ncreateTable({ driver, index: 'products', perPage: 'invalid' })\n"
control.write_text(text);report['negative_control']={'relative_path':str(control.relative_to(project)),'source':text,'sha256':hashlib.sha256(control.read_bytes()).hexdigest()};save()
try:
 observations=[]
 for name,exe in [('reference-negative',reference),('home-negative',home)]:
  r=run(name,exe,['--project','tsconfig.json','--pretty','false']);verify();assert control.read_text()==text
  diagnostics=re.findall(r'([^\r\n]+?)\((\d+),(\d+)\): error TS(\d+):',r.stdout+r.stderr)
  observations.append({'name':name,'exit':r.returncode,'diagnostics':diagnostics})
 report['negative_observations']=observations
 report['negative_comparison_passed']=observations[0]['exit']==observations[1]['exit']==1 and observations[0]['diagnostics']==observations[1]['diagnostics'] and len(observations[0]['diagnostics'])==1 and observations[0]['diagnostics'][0][3]=='2322'
finally:control.unlink();verify();save()
report['replacement_verified']=report['positive_comparison_passed'] and report.get('negative_comparison_passed',False);save();print('table check entrypoint verified',report['replacement_verified'],flush=True)
if not report['replacement_verified']:sys.exit(1)
