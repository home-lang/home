import hashlib
import json
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
name = sys.argv[1]
assert name in ('initial-two-controls', 'expanded-controls', 'six-controls')
parent = 'e7206761f810020aae39fc81d88e363becab0d46'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip() == parent
patch = subprocess.check_output(['git', 'diff', '--', 'packages/ts_checker/src/check.zig'], cwd=repo)
assert not (root / (name + '.patch')).exists()
(root / (name + '.patch')).write_bytes(patch)
record = {'parent_source': parent, 'patch_sha256': hashlib.sha256(patch).hexdigest(),
          'parent_native_sha256': hashlib.sha256((root / 'home-tsc-parent').read_bytes()).hexdigest(),
          'scope': 'Development draft only; remaining malformed/recovery/HIR-growth/OOM controls, complete module/native/diagnostic/Zod/harness gates and frozen protocol required before timing'}
(root / (name + '-provenance.json')).write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))
