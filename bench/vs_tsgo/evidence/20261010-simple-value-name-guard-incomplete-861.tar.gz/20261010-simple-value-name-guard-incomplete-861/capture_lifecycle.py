"""Capture terminal jobs only after the full statistical decision and disposition."""
import datetime
import hashlib
import json
from pathlib import Path
import re
import subprocess

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
labels = ['parent-build', 'checker', 'binder', 'program', 'driver', 'cli', 'entrypoint',
          'build', 'diagnostic-parity', 'zod-parent', 'zod-candidate', 'harness',
          'screen', 'confirmation', 'families', 'recheck', 'interface-risk']
labels += [f'confirmation_large-{n}' for n in range(5)]
decision = json.loads((root / 'decision.json').read_text())
assert decision['status'] in ('accepted', 'rejected') and decision['source_commit'] != 'pending'
if decision['status'] == 'rejected':
    labels.append('restored-build')
commands = {}
for name in labels:
    command = json.loads((root / (name + '-command.json')).read_text())
    assert command['exit'] == 0
    log = (root / (name + '.log')).read_text()
    peaks = [int(value) for value in re.findall(r'peak tree footprint (\d+) MB', log)]
    lows = [int(value) for value in re.findall(r'host low-water (\d+)%', log)]
    commands[name] = {'status': 'terminal', **command,
        'peak_tree_mb': max(peaks) if peaks else None,
        'host_low_water_percent': min(lows) if lows else None,
        'shared_lock_wait_logged': 'waiting up to 900s for the machine lock' in log}
verified = json.loads((root / 'verified-pairs.json').read_text())
assert verified['complete'] and verified['rounds'] == 382 + 30 * len(verified['independent_rechecks'])
assert verified['admissions'] == 660
native = hashlib.sha256((repo / 'zig-out/bin/home-tsc').read_bytes()).hexdigest()
if decision['status'] == 'accepted':
    assert subprocess.check_output(['git', 'show', '--format=', decision['source_commit'], '--', 'packages/ts_checker/src/check.zig'], cwd=repo) == (root / 'candidate.patch').read_bytes()
    assert native == decision['binaries']['candidate']
else:
    restored = json.loads((root / 'restored-current-main.json').read_text())
    assert restored['source_clean_before_and_after'] and not restored['rejected_candidate_in_production']
    assert native == restored['binary_sha256']
record = {'observed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'source_at_disposition': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip(),
    'native_sha256': native, 'commands': commands,
    'original_gate_session': {'session': 15996, 'status': 'terminal', 'exit': 0},
    'clean_current_main_parent_session': {'session': 40992, 'status': 'terminal', 'exit': 0},
    'current_main_candidate_build_session': {'session': 56554, 'status': 'terminal', 'exit': 0},
    'recoverable_closed_test_cleanup_session': {'session': 18634, 'status': 'terminal', 'exit': 0},
    'measurement_session': {'session': 33261, 'status': 'terminal', 'exit': 0},
    'candidate_committed_or_pushed': decision['status'] == 'accepted',
    'rounds': verified['rounds'], 'admissions': verified['admissions'],
    'exclusions': 0, 'repeat_until_pass': False, 'alignment_tuning': False,
    'guard': {'timeout_seconds': 600, 'tree_mb': 3840, 'disk_admission_mb': 1024, 'disk_continuation_mb': 512},
    'interpretation': 'All original development failures/gates, native/input reconciliation, completed phases, warnings and shared-lock waits retained. Scoped A/B only; no universal, equivalence, Zod, C++ or other-platform completion claim.'}
assert not (root / 'final-job-lifecycle.json').exists()
(root / 'final-job-lifecycle.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({key: record[key] for key in ('source_at_disposition', 'native_sha256', 'rounds', 'admissions', 'candidate_committed_or_pushed')}))
