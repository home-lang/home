| Retained measurement | Parent median | Candidate median | Candidate faster | Paired mean saving 95% interval |
|---|---:|---:|---:|---:|
| Official checked JS screen | 36.077 ms | 37.863 ms | 8/20 | -5.261 to +0.723 ms |
| 512 family screen | 154.728 ms | 158.185 ms | 2/6 | -15.598 to +10.656 ms |
| 8192 family screen | 11,151.313 ms | 10,735.609 ms | 4/6 | -723.334 to +1,851.352 ms |
| Official checked JS independent confirmation | 36.102 ms | 37.224 ms | 12/30 | -4.705 to +1.400 ms |
| 512 family independent confirmation | 147.629 ms | 149.565 ms | 10/30 | -3.734 to +2.916 ms |
| 8192 family batch 1 | 13,205.332 ms | 10,679.446 ms | 4/6 | -2,848.505 to +9,345.077 ms |
| 8192 family batch 2 | 10,721.569 ms | 9,743.467 ms | 4/6 | -1,174.681 to +2,832.900 ms |
| 8192 family batch 3 data recovered execution unconfirmed | 14,264.008 ms | 15,088.627 ms | 3/6 | -15,472.494 to +8,329.141 ms |
| 8192 family batch 4 | 11,085.269 ms | 9,518.928 ms | 6/6 | +253.933 to +4,314.435 ms |
| 8192 family batch 5 disk stopped | No completed pairs | No completed pairs | 0/6 planned | Not available |

| All family screens ten pairs each | Parent median | Candidate median | Candidate faster | Paired mean saving 95% interval |
|---|---:|---:|---:|---:|
| `checkjs_jsdoc` | 36.714 ms | 36.599 ms | 5/10 | -2.340 to +5.213 ms |
| `class_hierarchy` | 34.655 ms | 33.485 ms | 7/10 | -9.890 to +11.369 ms |
| `commonjs_graph` | 30.239 ms | 28.085 ms | 5/10 | -11.694 to +6.285 ms |
| `control_flow` | 37.888 ms | 43.454 ms | 2/10 | -18.363 to +1.386 ms |
| `deep_types` | 31.766 ms | 31.556 ms | 3/10 | -17.911 to +7.405 ms |
| `destructuring` | 20.248 ms | 19.747 ms | 6/10 | -2.125 to +8.853 ms |
| `generic_calls` | 43.953 ms | 46.195 ms | 3/10 | -7.080 to +3.232 ms |
| `import_graph` | 29.103 ms | 27.347 ms | 5/10 | -3.943 to +6.277 ms |
| `interface_composition` | 47.791 ms | 60.971 ms | 1/10 | -17.033 to -4.314 ms |
| `many_files` | 31.675 ms | 30.160 ms | 6/10 | -3.991 to +9.842 ms |
| `null_safe_access` | 55.926 ms | 53.872 ms | 6/10 | -8.191 to +9.169 ms |
| `overload_resolution` | 35.088 ms | 35.268 ms | 5/10 | -10.153 to +1.867 ms |
| `recursive_generics` | 21.829 ms | 21.562 ms | 6/10 | -3.288 to +4.780 ms |
| `reexport_graph` | 16.295 ms | 17.249 ms | 4/10 | -4.339 to +1.999 ms |
| `startup` | 3.919 ms | 3.923 ms | 2/10 | -0.437 to +0.120 ms |
| `structural_objects` | 33.735 ms | 33.024 ms | 4/10 | -4.218 to +4.359 ms |
| `tsx_components` | 27.006 ms | 26.138 ms | 5/10 | -2.199 to +6.269 ms |
| `type_predicates` | 49.344 ms | 49.236 ms | 5/10 | -16.832 to +13.905 ms |
| `type_predicates_large` | 363.625 ms | 361.548 ms | 4/10 | -42.973 to +53.632 ms |
| `variadic_tuples` | 46.162 ms | 48.706 ms | 6/10 | -3.597 to +3.486 ms |

| Independent risk checks thirty pairs each | Parent median | Candidate median | Candidate faster | Paired mean saving 95% interval |
|---|---:|---:|---:|---:|
| `checkjs_jsdoc` | 43.210 ms | 42.132 ms | 16/30 | -3.246 to +1.862 ms |
| `commonjs_graph` | 30.045 ms | 29.216 ms | 12/30 | -2.117 to +2.567 ms |
| `control_flow` | 43.360 ms | 46.292 ms | 14/30 | -7.450 to +18.563 ms |
| `deep_types` | 52.372 ms | 54.734 ms | 12/30 | -5.566 to +20.171 ms |
| `destructuring` | 25.443 ms | 24.698 ms | 16/30 | -3.190 to +3.141 ms |
| `generic_calls` | 44.622 ms | 42.863 ms | 17/30 | -4.775 to +6.454 ms |
| `interface_composition` | 52.294 ms | 50.145 ms | 13/30 | -13.029 to +7.541 ms |
| `recursive_generics` | 29.591 ms | 32.065 ms | 12/30 | -23.980 to +3.673 ms |
| `reexport_graph` | 21.523 ms | 19.147 ms | 15/30 | -3.632 to +4.041 ms |
| `type_predicates_large` | 565.326 ms | 624.102 ms | 13/30 | -242.097 to +295.340 ms |
| `variadic_tuples` | 107.637 ms | 98.618 ms | 19/30 | -21.083 to +44.561 ms |

| Independent declaration checks thirty pairs each | Parent median | Candidate median | Candidate faster | Paired mean saving 95% interval |
|---|---:|---:|---:|---:|
| `class_hierarchy` | 41.582 ms | 46.604 ms | 9/30 | -7.434 to +0.985 ms |
| `interface_composition` | 55.683 ms | 62.015 ms | 11/30 | -15.476 to +23.459 ms |
