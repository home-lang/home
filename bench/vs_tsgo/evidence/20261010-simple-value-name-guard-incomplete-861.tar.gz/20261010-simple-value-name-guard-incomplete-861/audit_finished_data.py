import json
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
for label, args in [('strict-frozen-verifier', ['verify_pairs.py']),
                    ('supplemental-interrupted-data', ['verify_interrupted_data.py', '--partial'])]:
    command = ['env', 'HOME_RUN_MAX_MB=3840', 'HOME_RUN_LABEL=ts861-' + label,
               'perl', 'scripts/run-bounded.pl', '600', 'python3', str(root / args[0]), *args[1:]]
    result = subprocess.run(command, cwd=repo, capture_output=True, text=True)
    output = result.stdout + result.stderr
    (root / (label + '.log')).write_text(output)
    (root / (label + '-command.json')).write_text(json.dumps({'command': command, 'exit': result.returncode}, indent=2) + '\n')
    print(label, 'exit', result.returncode, output[-3000:], flush=True)
    if label == 'strict-frozen-verifier':
        assert result.returncode != 0, 'Interrupted execution must never be reported fully qualified'
    else:
        assert result.returncode == 0
