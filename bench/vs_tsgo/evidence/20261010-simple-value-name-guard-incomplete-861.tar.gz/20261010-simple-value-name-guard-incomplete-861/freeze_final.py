import hashlib
import json
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
parent = 'e7206761f810020aae39fc81d88e363becab0d46'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip() == parent
assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=repo).decode().splitlines() == [' M packages/ts_checker/src/check.zig']
path = 'packages/ts_checker/src/check.zig'
old = subprocess.check_output(['git', 'show', parent + ':' + path], cwd=repo).decode()
current = (repo / path).read_text()
old_resolver = old.split('    fn resolveValueDeclInStmt(\n', 1)[1].split('    fn identifierReadsUninitializedVar(', 1)[0]
scalar = current.split('    fn resolveValueDeclInStmtSlow(\n', 1)[1].split('    fn identifierReadsUninitializedVar(', 1)[0]
assert old_resolver == scalar, 'The full original resolver must remain byte-identical'
patch = subprocess.check_output(['git', 'diff', '--', path], cwd=repo)
assert patch == (root / 'six-controls.patch').read_bytes()
assert not (root / 'final-draft.patch').exists()
(root / 'final-draft.patch').write_bytes(patch)
record = {'source_parent': parent,
          'parent_binary_sha256': hashlib.sha256((root / 'home-tsc-parent').read_bytes()).hexdigest(),
          'protocol_sha256': hashlib.sha256((root / 'protocol.json').read_bytes()).hexdigest(),
          'final_draft_patch_sha256': hashlib.sha256(patch).hexdigest(),
          'full_original_resolver_byte_identical': True,
          'timing_not_started': True,
          'required_gates': ['checker', 'binder', 'program', 'driver', 'cli', 'entrypoint', 'build', 'harness', 'diagnostic-parity', 'zod-parent', 'zod-candidate'],
          'runners': {name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in ['paired.py', 'paired-interface-risk.py', 'verify_pairs.py', 'decide.py']}}
(root / 'final-source-freeze.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))
