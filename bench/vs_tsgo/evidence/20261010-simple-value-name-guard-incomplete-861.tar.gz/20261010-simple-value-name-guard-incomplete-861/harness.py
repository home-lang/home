import json
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
command = ['env', 'HOME_RUN_MAX_MB=3840', 'HOME_RUN_LABEL=ts861-full-harness',
    'perl', 'scripts/run-bounded.pl', '600', 'python3', '-m', 'unittest',
    'discover', '-s', 'bench/vs_tsgo', '-p', 'test_*.py']
result = subprocess.run(command, cwd=repo, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
(root / 'harness.log').write_text(result.stdout)
(root / 'harness-command.json').write_text(json.dumps({'command': command, 'exit': result.returncode}, indent=2) + '\n')
print(result.stdout[-2200:], flush=True)
assert result.returncode == 0 and 'Ran 136 tests' in result.stdout
