import hashlib
import json
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
parent = '6863bd9c3ffd4426681d338504c2411f3b8dee5c'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip() == parent
initial = json.loads((root / 'current-source-freeze.json').read_text())
protocol = json.loads((root / 'protocol.json').read_text())
assert initial['source_parent'] == protocol['parent_source'] == parent
assert hashlib.sha256((root / 'protocol.json').read_bytes()).hexdigest() == initial['protocol_sha256']
assert hashlib.sha256((root / 'home-tsc-parent').read_bytes()).hexdigest() == initial['parent_binary_sha256'] == protocol['parent_binary_sha256']
assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=repo).decode().splitlines() == [' M packages/ts_checker/src/check.zig']
for label, count in [('checker',4559), ('program',251), ('driver',200), ('cli',76), ('entrypoint',38)]:
    assert json.loads((root / (label + '-command.json')).read_text())['exit'] == 0
    assert f'All {count} tests passed.' in (root / (label + '.log')).read_text()
    assert '"named_test_filters": []' in (root / (label + '.log')).read_text()
assert json.loads((root / 'binder-command.json').read_text())['exit'] == 0
assert 'All 21 tests passed.' in (root / 'binder.log').read_text()
assert '"named_test_filters": []' in (root / 'binder.log').read_text()
assert json.loads((root / 'diagnostic-parity-command.json').read_text())['exit'] == 0
diagnostic_controls = json.loads((root / 'diagnostic-parity.json').read_text())
assert len(diagnostic_controls) == 6 and all(row['complete_output_equal'] for row in diagnostic_controls)
for name, expected in initial['runners'].items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == expected
assert json.loads((root / 'build-command.json').read_text())['exit'] == 0
for label in ('harness', 'zod-parent', 'zod-candidate'):
    assert json.loads((root / (label + '-command.json')).read_text())['exit'] == 0
assert 'Ran 136 tests' in (root / 'harness.log').read_text()
zod = json.loads((root / 'zod-comparison.json').read_text())
assert zod['complete_primary_messages_equal'] and zod['added'] == zod['removed'] == 0
assert not zod['production_admitted']
assert (root / 'home-tsc-candidate').read_bytes() == (repo / 'zig-out/bin/home-tsc').read_bytes()
patch = subprocess.check_output(['git', 'diff', '--', 'packages/ts_checker/src/check.zig'], cwd=repo)
assert patch == (root / 'final-draft.patch').read_bytes()
assert hashlib.sha256(patch).hexdigest() == initial['final_draft_patch_sha256']
assert patch == (root / 'candidate.patch').read_bytes()
reconciliation = json.loads((root / 'reconciled-native-proof.json').read_text())
assert reconciliation['current_source'] == parent
assert reconciliation['tracked_ts_inputs_identical']
assert reconciliation['parent_native_identical'] and reconciliation['candidate_native_identical']
(root / 'candidate-provenance.json').write_text(json.dumps({
    'parent_source': parent,
    'binaries': {name: hashlib.sha256((root / ('home-tsc-' + name)).read_bytes()).hexdigest() for name in ('parent','candidate')},
    'candidate_patch_sha256': hashlib.sha256(patch).hexdigest(),
    'protocol_sha256': hashlib.sha256((root / 'protocol.json').read_bytes()).hexdigest(),
    'same_frozen_final_patch_required': True,
    'initial_and_intermediate_semantic_controls_retained': True,
    'all_full_module_gates_passed': True,
    'complete_zod_and_harness_gates_required_before_timing': True,
    'full_original_resolver_byte_identical': initial['full_original_resolver_byte_identical'],
    'full_semantic_gate_source': reconciliation['original_source'],
    'current_main_reconciliation': reconciliation,
    'timing_rules_unchanged_from_original_predeclared_protocol': True}, indent=2) + '\n')
print((root / 'candidate-provenance.json').read_text())
