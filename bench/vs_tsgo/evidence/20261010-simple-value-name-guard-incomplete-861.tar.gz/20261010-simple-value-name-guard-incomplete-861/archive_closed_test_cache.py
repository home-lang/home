"""Recoverably archive only old closed Zig test executables/objects we own."""
import gzip
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import tarfile

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
cache = repo / '.zig-cache/o'
cutoff = (root / 'original-experiment/parent-provenance.json').stat().st_mtime
plan_path = root / 'closed-test-cache-plan.json'
if sys.argv[1:] == ['--plan']:
    records = []
    for directory in sorted(cache.iterdir()):
        if not directory.is_dir() or not re.fullmatch('[0-9a-f]{32}', directory.name):
            continue
        executable = directory / 'root'
        if not executable.is_file() or executable.is_symlink() or executable.stat().st_mtime >= cutoff:
            continue
        if b'.test.' not in executable.read_bytes():
            continue
        for name in ('root', 'root_zcu.o'):
            path = directory / name
            if not path.is_file() or path.is_symlink() or path.stat().st_mtime >= cutoff:
                continue
            records.append({'path': str(path), 'relative': str(path.relative_to(repo)),
                            'bytes': path.stat().st_size, 'mtime': path.stat().st_mtime,
                            'sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
    assert records
    opened = subprocess.run(['lsof', '-n', '--', *[row['path'] for row in records]], capture_output=True, text=True)
    assert opened.returncode == 1 and not opened.stdout and not opened.stderr, opened
    assert not plan_path.exists()
    record = {'scope': 'Old Zig test root/root_zcu.o files only, before clean861parent build; no native home-tsc/object/profile/source/raw samples',
              'cutoff_mtime': cutoff, 'all_paths_verified_regular_and_closed': True,
              'records': records, 'bytes': sum(row['bytes'] for row in records)}
    plan_path.write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps({'files': len(records), 'bytes': record['bytes'], 'plan': str(plan_path)}))
else:
    assert sys.argv[1:] == ['--archive-remove']
    record = json.loads(plan_path.read_text())
    records = record['records']
    for row in records:
        path = Path(row['path'])
        assert path.parent.parent == cache and path.name in ('root', 'root_zcu.o')
        assert path.is_file() and not path.is_symlink() and path.stat().st_mtime == row['mtime']
        assert hashlib.sha256(path.read_bytes()).hexdigest() == row['sha256']
    opened = subprocess.run(['lsof', '-n', '--', *[row['path'] for row in records]], capture_output=True, text=True)
    assert opened.returncode == 1 and not opened.stdout and not opened.stderr, opened
    destination = root / 'closed-owned-test-cache-recovery.tar.gz'
    assert not destination.exists()
    with destination.open('wb') as output:
        with gzip.GzipFile(filename='', mode='wb', fileobj=output, mtime=0, compresslevel=1) as compressed:
            with tarfile.open(fileobj=compressed, mode='w') as archive:
                archive.add(plan_path, arcname='closed-test-cache-plan.json')
                for row in records:
                    archive.add(row['path'], arcname=row['relative'])
    with tarfile.open(destination) as archive:
        for row in records:
            assert hashlib.sha256(archive.extractfile(row['relative']).read()).hexdigest() == row['sha256']
    for row in records:
        path = Path(row['path'])
        assert hashlib.sha256(path.read_bytes()).hexdigest() == row['sha256']
        path.unlink()
    result = {'files_removed': len(records), 'bytes': record['bytes'], 'recoverable_archive': str(destination),
              'archive_sha256': hashlib.sha256(destination.read_bytes()).hexdigest(), 'each_payload_verified': True,
              'native_source_raw_evidence_and_current_artifacts_preserved': True}
    (root / 'closed-test-cache-cleanup.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result))
