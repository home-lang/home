import hashlib
import json
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
original = root / 'original-experiment'
parent = '6863bd9c3ffd4426681d338504c2411f3b8dee5c'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip() == parent
assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=repo).decode().splitlines() == [' M packages/ts_checker/src/check.zig']
patch = subprocess.check_output(['git', 'diff', '--', 'packages/ts_checker/src/check.zig'], cwd=repo)
assert patch == (original / 'candidate.patch').read_bytes() == (root / 'candidate.patch').read_bytes()
old_protocol = json.loads((original / 'protocol.json').read_text())
current_protocol = json.loads((root / 'protocol.json').read_text())
assert old_protocol.pop('parent_source') == 'e7206761f810020aae39fc81d88e363becab0d46'
assert current_protocol.pop('parent_source') == parent
assert old_protocol == current_protocol, 'Reconciliation may not change any timing or acceptance rule'
old_source = subprocess.check_output(['git', 'show', 'e7206761f810020aae39fc81d88e363becab0d46:packages/ts_checker/src/check.zig'], cwd=repo).decode()
current_source = (repo / 'packages/ts_checker/src/check.zig').read_text()
old_body = old_source.split('    fn resolveValueDeclInStmt(\n', 1)[1].split('    fn identifierReadsUninitializedVar(', 1)[0]
scalar = current_source.split('    fn resolveValueDeclInStmtSlow(\n', 1)[1].split('    fn identifierReadsUninitializedVar(', 1)[0]
assert old_body == scalar
record = {'source_parent': parent,
          'parent_binary_sha256': hashlib.sha256((root / 'home-tsc-parent').read_bytes()).hexdigest(),
          'protocol_sha256': hashlib.sha256((root / 'protocol.json').read_bytes()).hexdigest(),
          'final_draft_patch_sha256': hashlib.sha256(patch).hexdigest(),
          'full_original_resolver_byte_identical': True, 'timing_not_started': True,
          'only_parent_source_changed_in_protocol': True,
          'runners': {name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in ['paired.py', 'paired-interface-risk.py', 'verify_pairs.py', 'decide.py']}}
assert not (root / 'current-source-freeze.json').exists()
(root / 'current-source-freeze.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))
