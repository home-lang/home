// @ts-check

/**
 * @typedef {object} Model0
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box0
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project0
 * @param {Model0} input
 * @returns {string}
 */

/**
 * @template {Model0} T
 * @param {T} value
 * @returns {T}
 */
function preserve0(value) {
  return value;
}

class Store0 {
  /**
   * @param {Box0<Model0>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project0} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model0} */
const model0 = {
  id: 0, name: "model-0", meta: { active: true, label: "meta-0" },
};
const preserved0 = preserve0(model0);
/** @type {Box0<Model0>} */
const box0 = { value: preserved0, label: "box-0" };
/** @type {Project0} */
const project0 = (input) => `${input.meta.label}:${input.name}`;
const store0 = new Store0(box0);
const rendered0 = store0.read(project0);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult0 = {
  id: preserved0.id,
  name: preserved0.name,
  active: preserved0.meta.active,
  rendered: rendered0,
};

/**
 * @typedef {object} Model1
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box1
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project1
 * @param {Model1} input
 * @returns {string}
 */

/**
 * @template {Model1} T
 * @param {T} value
 * @returns {T}
 */
function preserve1(value) {
  return value;
}

class Store1 {
  /**
   * @param {Box1<Model1>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project1} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model1} */
const model1 = {
  id: 1, name: "model-1", meta: { active: false, label: "meta-1" },
};
const preserved1 = preserve1(model1);
/** @type {Box1<Model1>} */
const box1 = { value: preserved1, label: "box-1" };
/** @type {Project1} */
const project1 = (input) => `${input.meta.label}:${input.name}`;
const store1 = new Store1(box1);
const rendered1 = store1.read(project1);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult1 = {
  id: preserved1.id,
  name: preserved1.name,
  active: preserved1.meta.active,
  rendered: rendered1,
};

/**
 * @typedef {object} Model2
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box2
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project2
 * @param {Model2} input
 * @returns {string}
 */

/**
 * @template {Model2} T
 * @param {T} value
 * @returns {T}
 */
function preserve2(value) {
  return value;
}

class Store2 {
  /**
   * @param {Box2<Model2>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project2} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model2} */
const model2 = {
  id: 2, name: "model-2", meta: { active: true, label: "meta-2" },
};
const preserved2 = preserve2(model2);
/** @type {Box2<Model2>} */
const box2 = { value: preserved2, label: "box-2" };
/** @type {Project2} */
const project2 = (input) => `${input.meta.label}:${input.name}`;
const store2 = new Store2(box2);
const rendered2 = store2.read(project2);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult2 = {
  id: preserved2.id,
  name: preserved2.name,
  active: preserved2.meta.active,
  rendered: rendered2,
};

/**
 * @typedef {object} Model3
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box3
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project3
 * @param {Model3} input
 * @returns {string}
 */

/**
 * @template {Model3} T
 * @param {T} value
 * @returns {T}
 */
function preserve3(value) {
  return value;
}

class Store3 {
  /**
   * @param {Box3<Model3>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project3} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model3} */
const model3 = {
  id: 3, name: "model-3", meta: { active: false, label: "meta-3" },
};
const preserved3 = preserve3(model3);
/** @type {Box3<Model3>} */
const box3 = { value: preserved3, label: "box-3" };
/** @type {Project3} */
const project3 = (input) => `${input.meta.label}:${input.name}`;
const store3 = new Store3(box3);
const rendered3 = store3.read(project3);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult3 = {
  id: preserved3.id,
  name: preserved3.name,
  active: preserved3.meta.active,
  rendered: rendered3,
};

/**
 * @typedef {object} Model4
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box4
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project4
 * @param {Model4} input
 * @returns {string}
 */

/**
 * @template {Model4} T
 * @param {T} value
 * @returns {T}
 */
function preserve4(value) {
  return value;
}

class Store4 {
  /**
   * @param {Box4<Model4>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project4} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model4} */
const model4 = {
  id: 4, name: "model-4", meta: { active: true, label: "meta-4" },
};
const preserved4 = preserve4(model4);
/** @type {Box4<Model4>} */
const box4 = { value: preserved4, label: "box-4" };
/** @type {Project4} */
const project4 = (input) => `${input.meta.label}:${input.name}`;
const store4 = new Store4(box4);
const rendered4 = store4.read(project4);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult4 = {
  id: preserved4.id,
  name: preserved4.name,
  active: preserved4.meta.active,
  rendered: rendered4,
};

/**
 * @typedef {object} Model5
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box5
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project5
 * @param {Model5} input
 * @returns {string}
 */

/**
 * @template {Model5} T
 * @param {T} value
 * @returns {T}
 */
function preserve5(value) {
  return value;
}

class Store5 {
  /**
   * @param {Box5<Model5>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project5} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model5} */
const model5 = {
  id: 5, name: "model-5", meta: { active: false, label: "meta-5" },
};
const preserved5 = preserve5(model5);
/** @type {Box5<Model5>} */
const box5 = { value: preserved5, label: "box-5" };
/** @type {Project5} */
const project5 = (input) => `${input.meta.label}:${input.name}`;
const store5 = new Store5(box5);
const rendered5 = store5.read(project5);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult5 = {
  id: preserved5.id,
  name: preserved5.name,
  active: preserved5.meta.active,
  rendered: rendered5,
};

/**
 * @typedef {object} Model6
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box6
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project6
 * @param {Model6} input
 * @returns {string}
 */

/**
 * @template {Model6} T
 * @param {T} value
 * @returns {T}
 */
function preserve6(value) {
  return value;
}

class Store6 {
  /**
   * @param {Box6<Model6>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project6} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model6} */
const model6 = {
  id: 6, name: "model-6", meta: { active: true, label: "meta-6" },
};
const preserved6 = preserve6(model6);
/** @type {Box6<Model6>} */
const box6 = { value: preserved6, label: "box-6" };
/** @type {Project6} */
const project6 = (input) => `${input.meta.label}:${input.name}`;
const store6 = new Store6(box6);
const rendered6 = store6.read(project6);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult6 = {
  id: preserved6.id,
  name: preserved6.name,
  active: preserved6.meta.active,
  rendered: rendered6,
};

/**
 * @typedef {object} Model7
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box7
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project7
 * @param {Model7} input
 * @returns {string}
 */

/**
 * @template {Model7} T
 * @param {T} value
 * @returns {T}
 */
function preserve7(value) {
  return value;
}

class Store7 {
  /**
   * @param {Box7<Model7>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project7} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model7} */
const model7 = {
  id: 7, name: "model-7", meta: { active: false, label: "meta-7" },
};
const preserved7 = preserve7(model7);
/** @type {Box7<Model7>} */
const box7 = { value: preserved7, label: "box-7" };
/** @type {Project7} */
const project7 = (input) => `${input.meta.label}:${input.name}`;
const store7 = new Store7(box7);
const rendered7 = store7.read(project7);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult7 = {
  id: preserved7.id,
  name: preserved7.name,
  active: preserved7.meta.active,
  rendered: rendered7,
};

/**
 * @typedef {object} Model8
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box8
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project8
 * @param {Model8} input
 * @returns {string}
 */

/**
 * @template {Model8} T
 * @param {T} value
 * @returns {T}
 */
function preserve8(value) {
  return value;
}

class Store8 {
  /**
   * @param {Box8<Model8>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project8} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model8} */
const model8 = {
  id: 8, name: "model-8", meta: { active: true, label: "meta-8" },
};
const preserved8 = preserve8(model8);
/** @type {Box8<Model8>} */
const box8 = { value: preserved8, label: "box-8" };
/** @type {Project8} */
const project8 = (input) => `${input.meta.label}:${input.name}`;
const store8 = new Store8(box8);
const rendered8 = store8.read(project8);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult8 = {
  id: preserved8.id,
  name: preserved8.name,
  active: preserved8.meta.active,
  rendered: rendered8,
};

/**
 * @typedef {object} Model9
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box9
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project9
 * @param {Model9} input
 * @returns {string}
 */

/**
 * @template {Model9} T
 * @param {T} value
 * @returns {T}
 */
function preserve9(value) {
  return value;
}

class Store9 {
  /**
   * @param {Box9<Model9>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project9} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model9} */
const model9 = {
  id: 9, name: "model-9", meta: { active: false, label: "meta-9" },
};
const preserved9 = preserve9(model9);
/** @type {Box9<Model9>} */
const box9 = { value: preserved9, label: "box-9" };
/** @type {Project9} */
const project9 = (input) => `${input.meta.label}:${input.name}`;
const store9 = new Store9(box9);
const rendered9 = store9.read(project9);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult9 = {
  id: preserved9.id,
  name: preserved9.name,
  active: preserved9.meta.active,
  rendered: rendered9,
};

/**
 * @typedef {object} Model10
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box10
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project10
 * @param {Model10} input
 * @returns {string}
 */

/**
 * @template {Model10} T
 * @param {T} value
 * @returns {T}
 */
function preserve10(value) {
  return value;
}

class Store10 {
  /**
   * @param {Box10<Model10>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project10} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model10} */
const model10 = {
  id: 10, name: "model-10", meta: { active: true, label: "meta-10" },
};
const preserved10 = preserve10(model10);
/** @type {Box10<Model10>} */
const box10 = { value: preserved10, label: "box-10" };
/** @type {Project10} */
const project10 = (input) => `${input.meta.label}:${input.name}`;
const store10 = new Store10(box10);
const rendered10 = store10.read(project10);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult10 = {
  id: preserved10.id,
  name: preserved10.name,
  active: preserved10.meta.active,
  rendered: rendered10,
};

/**
 * @typedef {object} Model11
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box11
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project11
 * @param {Model11} input
 * @returns {string}
 */

/**
 * @template {Model11} T
 * @param {T} value
 * @returns {T}
 */
function preserve11(value) {
  return value;
}

class Store11 {
  /**
   * @param {Box11<Model11>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project11} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model11} */
const model11 = {
  id: 11, name: "model-11", meta: { active: false, label: "meta-11" },
};
const preserved11 = preserve11(model11);
/** @type {Box11<Model11>} */
const box11 = { value: preserved11, label: "box-11" };
/** @type {Project11} */
const project11 = (input) => `${input.meta.label}:${input.name}`;
const store11 = new Store11(box11);
const rendered11 = store11.read(project11);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult11 = {
  id: preserved11.id,
  name: preserved11.name,
  active: preserved11.meta.active,
  rendered: rendered11,
};

/**
 * @typedef {object} Model12
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box12
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project12
 * @param {Model12} input
 * @returns {string}
 */

/**
 * @template {Model12} T
 * @param {T} value
 * @returns {T}
 */
function preserve12(value) {
  return value;
}

class Store12 {
  /**
   * @param {Box12<Model12>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project12} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model12} */
const model12 = {
  id: 12, name: "model-12", meta: { active: true, label: "meta-12" },
};
const preserved12 = preserve12(model12);
/** @type {Box12<Model12>} */
const box12 = { value: preserved12, label: "box-12" };
/** @type {Project12} */
const project12 = (input) => `${input.meta.label}:${input.name}`;
const store12 = new Store12(box12);
const rendered12 = store12.read(project12);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult12 = {
  id: preserved12.id,
  name: preserved12.name,
  active: preserved12.meta.active,
  rendered: rendered12,
};

/**
 * @typedef {object} Model13
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box13
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project13
 * @param {Model13} input
 * @returns {string}
 */

/**
 * @template {Model13} T
 * @param {T} value
 * @returns {T}
 */
function preserve13(value) {
  return value;
}

class Store13 {
  /**
   * @param {Box13<Model13>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project13} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model13} */
const model13 = {
  id: 13, name: "model-13", meta: { active: false, label: "meta-13" },
};
const preserved13 = preserve13(model13);
/** @type {Box13<Model13>} */
const box13 = { value: preserved13, label: "box-13" };
/** @type {Project13} */
const project13 = (input) => `${input.meta.label}:${input.name}`;
const store13 = new Store13(box13);
const rendered13 = store13.read(project13);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult13 = {
  id: preserved13.id,
  name: preserved13.name,
  active: preserved13.meta.active,
  rendered: rendered13,
};

/**
 * @typedef {object} Model14
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box14
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project14
 * @param {Model14} input
 * @returns {string}
 */

/**
 * @template {Model14} T
 * @param {T} value
 * @returns {T}
 */
function preserve14(value) {
  return value;
}

class Store14 {
  /**
   * @param {Box14<Model14>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project14} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model14} */
const model14 = {
  id: 14, name: "model-14", meta: { active: true, label: "meta-14" },
};
const preserved14 = preserve14(model14);
/** @type {Box14<Model14>} */
const box14 = { value: preserved14, label: "box-14" };
/** @type {Project14} */
const project14 = (input) => `${input.meta.label}:${input.name}`;
const store14 = new Store14(box14);
const rendered14 = store14.read(project14);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult14 = {
  id: preserved14.id,
  name: preserved14.name,
  active: preserved14.meta.active,
  rendered: rendered14,
};

/**
 * @typedef {object} Model15
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box15
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project15
 * @param {Model15} input
 * @returns {string}
 */

/**
 * @template {Model15} T
 * @param {T} value
 * @returns {T}
 */
function preserve15(value) {
  return value;
}

class Store15 {
  /**
   * @param {Box15<Model15>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project15} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model15} */
const model15 = {
  id: 15, name: "model-15", meta: { active: false, label: "meta-15" },
};
const preserved15 = preserve15(model15);
/** @type {Box15<Model15>} */
const box15 = { value: preserved15, label: "box-15" };
/** @type {Project15} */
const project15 = (input) => `${input.meta.label}:${input.name}`;
const store15 = new Store15(box15);
const rendered15 = store15.read(project15);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult15 = {
  id: preserved15.id,
  name: preserved15.name,
  active: preserved15.meta.active,
  rendered: rendered15,
};

/**
 * @typedef {object} Model16
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box16
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project16
 * @param {Model16} input
 * @returns {string}
 */

/**
 * @template {Model16} T
 * @param {T} value
 * @returns {T}
 */
function preserve16(value) {
  return value;
}

class Store16 {
  /**
   * @param {Box16<Model16>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project16} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model16} */
const model16 = {
  id: 16, name: "model-16", meta: { active: true, label: "meta-16" },
};
const preserved16 = preserve16(model16);
/** @type {Box16<Model16>} */
const box16 = { value: preserved16, label: "box-16" };
/** @type {Project16} */
const project16 = (input) => `${input.meta.label}:${input.name}`;
const store16 = new Store16(box16);
const rendered16 = store16.read(project16);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult16 = {
  id: preserved16.id,
  name: preserved16.name,
  active: preserved16.meta.active,
  rendered: rendered16,
};

/**
 * @typedef {object} Model17
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box17
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project17
 * @param {Model17} input
 * @returns {string}
 */

/**
 * @template {Model17} T
 * @param {T} value
 * @returns {T}
 */
function preserve17(value) {
  return value;
}

class Store17 {
  /**
   * @param {Box17<Model17>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project17} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model17} */
const model17 = {
  id: 17, name: "model-17", meta: { active: false, label: "meta-17" },
};
const preserved17 = preserve17(model17);
/** @type {Box17<Model17>} */
const box17 = { value: preserved17, label: "box-17" };
/** @type {Project17} */
const project17 = (input) => `${input.meta.label}:${input.name}`;
const store17 = new Store17(box17);
const rendered17 = store17.read(project17);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult17 = {
  id: preserved17.id,
  name: preserved17.name,
  active: preserved17.meta.active,
  rendered: rendered17,
};

/**
 * @typedef {object} Model18
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box18
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project18
 * @param {Model18} input
 * @returns {string}
 */

/**
 * @template {Model18} T
 * @param {T} value
 * @returns {T}
 */
function preserve18(value) {
  return value;
}

class Store18 {
  /**
   * @param {Box18<Model18>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project18} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model18} */
const model18 = {
  id: 18, name: "model-18", meta: { active: true, label: "meta-18" },
};
const preserved18 = preserve18(model18);
/** @type {Box18<Model18>} */
const box18 = { value: preserved18, label: "box-18" };
/** @type {Project18} */
const project18 = (input) => `${input.meta.label}:${input.name}`;
const store18 = new Store18(box18);
const rendered18 = store18.read(project18);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult18 = {
  id: preserved18.id,
  name: preserved18.name,
  active: preserved18.meta.active,
  rendered: rendered18,
};

/**
 * @typedef {object} Model19
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box19
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project19
 * @param {Model19} input
 * @returns {string}
 */

/**
 * @template {Model19} T
 * @param {T} value
 * @returns {T}
 */
function preserve19(value) {
  return value;
}

class Store19 {
  /**
   * @param {Box19<Model19>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project19} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model19} */
const model19 = {
  id: 19, name: "model-19", meta: { active: false, label: "meta-19" },
};
const preserved19 = preserve19(model19);
/** @type {Box19<Model19>} */
const box19 = { value: preserved19, label: "box-19" };
/** @type {Project19} */
const project19 = (input) => `${input.meta.label}:${input.name}`;
const store19 = new Store19(box19);
const rendered19 = store19.read(project19);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult19 = {
  id: preserved19.id,
  name: preserved19.name,
  active: preserved19.meta.active,
  rendered: rendered19,
};

/**
 * @typedef {object} Model20
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box20
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project20
 * @param {Model20} input
 * @returns {string}
 */

/**
 * @template {Model20} T
 * @param {T} value
 * @returns {T}
 */
function preserve20(value) {
  return value;
}

class Store20 {
  /**
   * @param {Box20<Model20>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project20} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model20} */
const model20 = {
  id: 20, name: "model-20", meta: { active: true, label: "meta-20" },
};
const preserved20 = preserve20(model20);
/** @type {Box20<Model20>} */
const box20 = { value: preserved20, label: "box-20" };
/** @type {Project20} */
const project20 = (input) => `${input.meta.label}:${input.name}`;
const store20 = new Store20(box20);
const rendered20 = store20.read(project20);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult20 = {
  id: preserved20.id,
  name: preserved20.name,
  active: preserved20.meta.active,
  rendered: rendered20,
};

/**
 * @typedef {object} Model21
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box21
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project21
 * @param {Model21} input
 * @returns {string}
 */

/**
 * @template {Model21} T
 * @param {T} value
 * @returns {T}
 */
function preserve21(value) {
  return value;
}

class Store21 {
  /**
   * @param {Box21<Model21>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project21} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model21} */
const model21 = {
  id: 21, name: "model-21", meta: { active: false, label: "meta-21" },
};
const preserved21 = preserve21(model21);
/** @type {Box21<Model21>} */
const box21 = { value: preserved21, label: "box-21" };
/** @type {Project21} */
const project21 = (input) => `${input.meta.label}:${input.name}`;
const store21 = new Store21(box21);
const rendered21 = store21.read(project21);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult21 = {
  id: preserved21.id,
  name: preserved21.name,
  active: preserved21.meta.active,
  rendered: rendered21,
};

/**
 * @typedef {object} Model22
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box22
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project22
 * @param {Model22} input
 * @returns {string}
 */

/**
 * @template {Model22} T
 * @param {T} value
 * @returns {T}
 */
function preserve22(value) {
  return value;
}

class Store22 {
  /**
   * @param {Box22<Model22>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project22} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model22} */
const model22 = {
  id: 22, name: "model-22", meta: { active: true, label: "meta-22" },
};
const preserved22 = preserve22(model22);
/** @type {Box22<Model22>} */
const box22 = { value: preserved22, label: "box-22" };
/** @type {Project22} */
const project22 = (input) => `${input.meta.label}:${input.name}`;
const store22 = new Store22(box22);
const rendered22 = store22.read(project22);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult22 = {
  id: preserved22.id,
  name: preserved22.name,
  active: preserved22.meta.active,
  rendered: rendered22,
};

/**
 * @typedef {object} Model23
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box23
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project23
 * @param {Model23} input
 * @returns {string}
 */

/**
 * @template {Model23} T
 * @param {T} value
 * @returns {T}
 */
function preserve23(value) {
  return value;
}

class Store23 {
  /**
   * @param {Box23<Model23>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project23} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model23} */
const model23 = {
  id: 23, name: "model-23", meta: { active: false, label: "meta-23" },
};
const preserved23 = preserve23(model23);
/** @type {Box23<Model23>} */
const box23 = { value: preserved23, label: "box-23" };
/** @type {Project23} */
const project23 = (input) => `${input.meta.label}:${input.name}`;
const store23 = new Store23(box23);
const rendered23 = store23.read(project23);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult23 = {
  id: preserved23.id,
  name: preserved23.name,
  active: preserved23.meta.active,
  rendered: rendered23,
};

/**
 * @typedef {object} Model24
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box24
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project24
 * @param {Model24} input
 * @returns {string}
 */

/**
 * @template {Model24} T
 * @param {T} value
 * @returns {T}
 */
function preserve24(value) {
  return value;
}

class Store24 {
  /**
   * @param {Box24<Model24>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project24} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model24} */
const model24 = {
  id: 24, name: "model-24", meta: { active: true, label: "meta-24" },
};
const preserved24 = preserve24(model24);
/** @type {Box24<Model24>} */
const box24 = { value: preserved24, label: "box-24" };
/** @type {Project24} */
const project24 = (input) => `${input.meta.label}:${input.name}`;
const store24 = new Store24(box24);
const rendered24 = store24.read(project24);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult24 = {
  id: preserved24.id,
  name: preserved24.name,
  active: preserved24.meta.active,
  rendered: rendered24,
};

/**
 * @typedef {object} Model25
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box25
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project25
 * @param {Model25} input
 * @returns {string}
 */

/**
 * @template {Model25} T
 * @param {T} value
 * @returns {T}
 */
function preserve25(value) {
  return value;
}

class Store25 {
  /**
   * @param {Box25<Model25>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project25} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model25} */
const model25 = {
  id: 25, name: "model-25", meta: { active: false, label: "meta-25" },
};
const preserved25 = preserve25(model25);
/** @type {Box25<Model25>} */
const box25 = { value: preserved25, label: "box-25" };
/** @type {Project25} */
const project25 = (input) => `${input.meta.label}:${input.name}`;
const store25 = new Store25(box25);
const rendered25 = store25.read(project25);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult25 = {
  id: preserved25.id,
  name: preserved25.name,
  active: preserved25.meta.active,
  rendered: rendered25,
};

/**
 * @typedef {object} Model26
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box26
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project26
 * @param {Model26} input
 * @returns {string}
 */

/**
 * @template {Model26} T
 * @param {T} value
 * @returns {T}
 */
function preserve26(value) {
  return value;
}

class Store26 {
  /**
   * @param {Box26<Model26>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project26} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model26} */
const model26 = {
  id: 26, name: "model-26", meta: { active: true, label: "meta-26" },
};
const preserved26 = preserve26(model26);
/** @type {Box26<Model26>} */
const box26 = { value: preserved26, label: "box-26" };
/** @type {Project26} */
const project26 = (input) => `${input.meta.label}:${input.name}`;
const store26 = new Store26(box26);
const rendered26 = store26.read(project26);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult26 = {
  id: preserved26.id,
  name: preserved26.name,
  active: preserved26.meta.active,
  rendered: rendered26,
};

/**
 * @typedef {object} Model27
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box27
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project27
 * @param {Model27} input
 * @returns {string}
 */

/**
 * @template {Model27} T
 * @param {T} value
 * @returns {T}
 */
function preserve27(value) {
  return value;
}

class Store27 {
  /**
   * @param {Box27<Model27>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project27} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model27} */
const model27 = {
  id: 27, name: "model-27", meta: { active: false, label: "meta-27" },
};
const preserved27 = preserve27(model27);
/** @type {Box27<Model27>} */
const box27 = { value: preserved27, label: "box-27" };
/** @type {Project27} */
const project27 = (input) => `${input.meta.label}:${input.name}`;
const store27 = new Store27(box27);
const rendered27 = store27.read(project27);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult27 = {
  id: preserved27.id,
  name: preserved27.name,
  active: preserved27.meta.active,
  rendered: rendered27,
};

/**
 * @typedef {object} Model28
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box28
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project28
 * @param {Model28} input
 * @returns {string}
 */

/**
 * @template {Model28} T
 * @param {T} value
 * @returns {T}
 */
function preserve28(value) {
  return value;
}

class Store28 {
  /**
   * @param {Box28<Model28>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project28} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model28} */
const model28 = {
  id: 28, name: "model-28", meta: { active: true, label: "meta-28" },
};
const preserved28 = preserve28(model28);
/** @type {Box28<Model28>} */
const box28 = { value: preserved28, label: "box-28" };
/** @type {Project28} */
const project28 = (input) => `${input.meta.label}:${input.name}`;
const store28 = new Store28(box28);
const rendered28 = store28.read(project28);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult28 = {
  id: preserved28.id,
  name: preserved28.name,
  active: preserved28.meta.active,
  rendered: rendered28,
};

/**
 * @typedef {object} Model29
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box29
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project29
 * @param {Model29} input
 * @returns {string}
 */

/**
 * @template {Model29} T
 * @param {T} value
 * @returns {T}
 */
function preserve29(value) {
  return value;
}

class Store29 {
  /**
   * @param {Box29<Model29>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project29} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model29} */
const model29 = {
  id: 29, name: "model-29", meta: { active: false, label: "meta-29" },
};
const preserved29 = preserve29(model29);
/** @type {Box29<Model29>} */
const box29 = { value: preserved29, label: "box-29" };
/** @type {Project29} */
const project29 = (input) => `${input.meta.label}:${input.name}`;
const store29 = new Store29(box29);
const rendered29 = store29.read(project29);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult29 = {
  id: preserved29.id,
  name: preserved29.name,
  active: preserved29.meta.active,
  rendered: rendered29,
};

/**
 * @typedef {object} Model30
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box30
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project30
 * @param {Model30} input
 * @returns {string}
 */

/**
 * @template {Model30} T
 * @param {T} value
 * @returns {T}
 */
function preserve30(value) {
  return value;
}

class Store30 {
  /**
   * @param {Box30<Model30>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project30} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model30} */
const model30 = {
  id: 30, name: "model-30", meta: { active: true, label: "meta-30" },
};
const preserved30 = preserve30(model30);
/** @type {Box30<Model30>} */
const box30 = { value: preserved30, label: "box-30" };
/** @type {Project30} */
const project30 = (input) => `${input.meta.label}:${input.name}`;
const store30 = new Store30(box30);
const rendered30 = store30.read(project30);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult30 = {
  id: preserved30.id,
  name: preserved30.name,
  active: preserved30.meta.active,
  rendered: rendered30,
};

/**
 * @typedef {object} Model31
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box31
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project31
 * @param {Model31} input
 * @returns {string}
 */

/**
 * @template {Model31} T
 * @param {T} value
 * @returns {T}
 */
function preserve31(value) {
  return value;
}

class Store31 {
  /**
   * @param {Box31<Model31>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project31} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model31} */
const model31 = {
  id: 31, name: "model-31", meta: { active: false, label: "meta-31" },
};
const preserved31 = preserve31(model31);
/** @type {Box31<Model31>} */
const box31 = { value: preserved31, label: "box-31" };
/** @type {Project31} */
const project31 = (input) => `${input.meta.label}:${input.name}`;
const store31 = new Store31(box31);
const rendered31 = store31.read(project31);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult31 = {
  id: preserved31.id,
  name: preserved31.name,
  active: preserved31.meta.active,
  rendered: rendered31,
};

/**
 * @typedef {object} Model32
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box32
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project32
 * @param {Model32} input
 * @returns {string}
 */

/**
 * @template {Model32} T
 * @param {T} value
 * @returns {T}
 */
function preserve32(value) {
  return value;
}

class Store32 {
  /**
   * @param {Box32<Model32>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project32} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model32} */
const model32 = {
  id: 32, name: "model-32", meta: { active: true, label: "meta-32" },
};
const preserved32 = preserve32(model32);
/** @type {Box32<Model32>} */
const box32 = { value: preserved32, label: "box-32" };
/** @type {Project32} */
const project32 = (input) => `${input.meta.label}:${input.name}`;
const store32 = new Store32(box32);
const rendered32 = store32.read(project32);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult32 = {
  id: preserved32.id,
  name: preserved32.name,
  active: preserved32.meta.active,
  rendered: rendered32,
};

/**
 * @typedef {object} Model33
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box33
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project33
 * @param {Model33} input
 * @returns {string}
 */

/**
 * @template {Model33} T
 * @param {T} value
 * @returns {T}
 */
function preserve33(value) {
  return value;
}

class Store33 {
  /**
   * @param {Box33<Model33>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project33} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model33} */
const model33 = {
  id: 33, name: "model-33", meta: { active: false, label: "meta-33" },
};
const preserved33 = preserve33(model33);
/** @type {Box33<Model33>} */
const box33 = { value: preserved33, label: "box-33" };
/** @type {Project33} */
const project33 = (input) => `${input.meta.label}:${input.name}`;
const store33 = new Store33(box33);
const rendered33 = store33.read(project33);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult33 = {
  id: preserved33.id,
  name: preserved33.name,
  active: preserved33.meta.active,
  rendered: rendered33,
};

/**
 * @typedef {object} Model34
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box34
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project34
 * @param {Model34} input
 * @returns {string}
 */

/**
 * @template {Model34} T
 * @param {T} value
 * @returns {T}
 */
function preserve34(value) {
  return value;
}

class Store34 {
  /**
   * @param {Box34<Model34>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project34} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model34} */
const model34 = {
  id: 34, name: "model-34", meta: { active: true, label: "meta-34" },
};
const preserved34 = preserve34(model34);
/** @type {Box34<Model34>} */
const box34 = { value: preserved34, label: "box-34" };
/** @type {Project34} */
const project34 = (input) => `${input.meta.label}:${input.name}`;
const store34 = new Store34(box34);
const rendered34 = store34.read(project34);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult34 = {
  id: preserved34.id,
  name: preserved34.name,
  active: preserved34.meta.active,
  rendered: rendered34,
};

/**
 * @typedef {object} Model35
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box35
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project35
 * @param {Model35} input
 * @returns {string}
 */

/**
 * @template {Model35} T
 * @param {T} value
 * @returns {T}
 */
function preserve35(value) {
  return value;
}

class Store35 {
  /**
   * @param {Box35<Model35>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project35} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model35} */
const model35 = {
  id: 35, name: "model-35", meta: { active: false, label: "meta-35" },
};
const preserved35 = preserve35(model35);
/** @type {Box35<Model35>} */
const box35 = { value: preserved35, label: "box-35" };
/** @type {Project35} */
const project35 = (input) => `${input.meta.label}:${input.name}`;
const store35 = new Store35(box35);
const rendered35 = store35.read(project35);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult35 = {
  id: preserved35.id,
  name: preserved35.name,
  active: preserved35.meta.active,
  rendered: rendered35,
};

/**
 * @typedef {object} Model36
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box36
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project36
 * @param {Model36} input
 * @returns {string}
 */

/**
 * @template {Model36} T
 * @param {T} value
 * @returns {T}
 */
function preserve36(value) {
  return value;
}

class Store36 {
  /**
   * @param {Box36<Model36>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project36} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model36} */
const model36 = {
  id: 36, name: "model-36", meta: { active: true, label: "meta-36" },
};
const preserved36 = preserve36(model36);
/** @type {Box36<Model36>} */
const box36 = { value: preserved36, label: "box-36" };
/** @type {Project36} */
const project36 = (input) => `${input.meta.label}:${input.name}`;
const store36 = new Store36(box36);
const rendered36 = store36.read(project36);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult36 = {
  id: preserved36.id,
  name: preserved36.name,
  active: preserved36.meta.active,
  rendered: rendered36,
};

/**
 * @typedef {object} Model37
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box37
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project37
 * @param {Model37} input
 * @returns {string}
 */

/**
 * @template {Model37} T
 * @param {T} value
 * @returns {T}
 */
function preserve37(value) {
  return value;
}

class Store37 {
  /**
   * @param {Box37<Model37>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project37} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model37} */
const model37 = {
  id: 37, name: "model-37", meta: { active: false, label: "meta-37" },
};
const preserved37 = preserve37(model37);
/** @type {Box37<Model37>} */
const box37 = { value: preserved37, label: "box-37" };
/** @type {Project37} */
const project37 = (input) => `${input.meta.label}:${input.name}`;
const store37 = new Store37(box37);
const rendered37 = store37.read(project37);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult37 = {
  id: preserved37.id,
  name: preserved37.name,
  active: preserved37.meta.active,
  rendered: rendered37,
};

/**
 * @typedef {object} Model38
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box38
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project38
 * @param {Model38} input
 * @returns {string}
 */

/**
 * @template {Model38} T
 * @param {T} value
 * @returns {T}
 */
function preserve38(value) {
  return value;
}

class Store38 {
  /**
   * @param {Box38<Model38>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project38} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model38} */
const model38 = {
  id: 38, name: "model-38", meta: { active: true, label: "meta-38" },
};
const preserved38 = preserve38(model38);
/** @type {Box38<Model38>} */
const box38 = { value: preserved38, label: "box-38" };
/** @type {Project38} */
const project38 = (input) => `${input.meta.label}:${input.name}`;
const store38 = new Store38(box38);
const rendered38 = store38.read(project38);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult38 = {
  id: preserved38.id,
  name: preserved38.name,
  active: preserved38.meta.active,
  rendered: rendered38,
};

/**
 * @typedef {object} Model39
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box39
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project39
 * @param {Model39} input
 * @returns {string}
 */

/**
 * @template {Model39} T
 * @param {T} value
 * @returns {T}
 */
function preserve39(value) {
  return value;
}

class Store39 {
  /**
   * @param {Box39<Model39>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project39} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model39} */
const model39 = {
  id: 39, name: "model-39", meta: { active: false, label: "meta-39" },
};
const preserved39 = preserve39(model39);
/** @type {Box39<Model39>} */
const box39 = { value: preserved39, label: "box-39" };
/** @type {Project39} */
const project39 = (input) => `${input.meta.label}:${input.name}`;
const store39 = new Store39(box39);
const rendered39 = store39.read(project39);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult39 = {
  id: preserved39.id,
  name: preserved39.name,
  active: preserved39.meta.active,
  rendered: rendered39,
};

/**
 * @typedef {object} Model40
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box40
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project40
 * @param {Model40} input
 * @returns {string}
 */

/**
 * @template {Model40} T
 * @param {T} value
 * @returns {T}
 */
function preserve40(value) {
  return value;
}

class Store40 {
  /**
   * @param {Box40<Model40>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project40} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model40} */
const model40 = {
  id: 40, name: "model-40", meta: { active: true, label: "meta-40" },
};
const preserved40 = preserve40(model40);
/** @type {Box40<Model40>} */
const box40 = { value: preserved40, label: "box-40" };
/** @type {Project40} */
const project40 = (input) => `${input.meta.label}:${input.name}`;
const store40 = new Store40(box40);
const rendered40 = store40.read(project40);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult40 = {
  id: preserved40.id,
  name: preserved40.name,
  active: preserved40.meta.active,
  rendered: rendered40,
};

/**
 * @typedef {object} Model41
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box41
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project41
 * @param {Model41} input
 * @returns {string}
 */

/**
 * @template {Model41} T
 * @param {T} value
 * @returns {T}
 */
function preserve41(value) {
  return value;
}

class Store41 {
  /**
   * @param {Box41<Model41>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project41} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model41} */
const model41 = {
  id: 41, name: "model-41", meta: { active: false, label: "meta-41" },
};
const preserved41 = preserve41(model41);
/** @type {Box41<Model41>} */
const box41 = { value: preserved41, label: "box-41" };
/** @type {Project41} */
const project41 = (input) => `${input.meta.label}:${input.name}`;
const store41 = new Store41(box41);
const rendered41 = store41.read(project41);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult41 = {
  id: preserved41.id,
  name: preserved41.name,
  active: preserved41.meta.active,
  rendered: rendered41,
};

/**
 * @typedef {object} Model42
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box42
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project42
 * @param {Model42} input
 * @returns {string}
 */

/**
 * @template {Model42} T
 * @param {T} value
 * @returns {T}
 */
function preserve42(value) {
  return value;
}

class Store42 {
  /**
   * @param {Box42<Model42>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project42} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model42} */
const model42 = {
  id: 42, name: "model-42", meta: { active: true, label: "meta-42" },
};
const preserved42 = preserve42(model42);
/** @type {Box42<Model42>} */
const box42 = { value: preserved42, label: "box-42" };
/** @type {Project42} */
const project42 = (input) => `${input.meta.label}:${input.name}`;
const store42 = new Store42(box42);
const rendered42 = store42.read(project42);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult42 = {
  id: preserved42.id,
  name: preserved42.name,
  active: preserved42.meta.active,
  rendered: rendered42,
};

/**
 * @typedef {object} Model43
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box43
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project43
 * @param {Model43} input
 * @returns {string}
 */

/**
 * @template {Model43} T
 * @param {T} value
 * @returns {T}
 */
function preserve43(value) {
  return value;
}

class Store43 {
  /**
   * @param {Box43<Model43>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project43} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model43} */
const model43 = {
  id: 43, name: "model-43", meta: { active: false, label: "meta-43" },
};
const preserved43 = preserve43(model43);
/** @type {Box43<Model43>} */
const box43 = { value: preserved43, label: "box-43" };
/** @type {Project43} */
const project43 = (input) => `${input.meta.label}:${input.name}`;
const store43 = new Store43(box43);
const rendered43 = store43.read(project43);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult43 = {
  id: preserved43.id,
  name: preserved43.name,
  active: preserved43.meta.active,
  rendered: rendered43,
};

/**
 * @typedef {object} Model44
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box44
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project44
 * @param {Model44} input
 * @returns {string}
 */

/**
 * @template {Model44} T
 * @param {T} value
 * @returns {T}
 */
function preserve44(value) {
  return value;
}

class Store44 {
  /**
   * @param {Box44<Model44>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project44} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model44} */
const model44 = {
  id: 44, name: "model-44", meta: { active: true, label: "meta-44" },
};
const preserved44 = preserve44(model44);
/** @type {Box44<Model44>} */
const box44 = { value: preserved44, label: "box-44" };
/** @type {Project44} */
const project44 = (input) => `${input.meta.label}:${input.name}`;
const store44 = new Store44(box44);
const rendered44 = store44.read(project44);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult44 = {
  id: preserved44.id,
  name: preserved44.name,
  active: preserved44.meta.active,
  rendered: rendered44,
};

/**
 * @typedef {object} Model45
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box45
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project45
 * @param {Model45} input
 * @returns {string}
 */

/**
 * @template {Model45} T
 * @param {T} value
 * @returns {T}
 */
function preserve45(value) {
  return value;
}

class Store45 {
  /**
   * @param {Box45<Model45>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project45} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model45} */
const model45 = {
  id: 45, name: "model-45", meta: { active: false, label: "meta-45" },
};
const preserved45 = preserve45(model45);
/** @type {Box45<Model45>} */
const box45 = { value: preserved45, label: "box-45" };
/** @type {Project45} */
const project45 = (input) => `${input.meta.label}:${input.name}`;
const store45 = new Store45(box45);
const rendered45 = store45.read(project45);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult45 = {
  id: preserved45.id,
  name: preserved45.name,
  active: preserved45.meta.active,
  rendered: rendered45,
};

/**
 * @typedef {object} Model46
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box46
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project46
 * @param {Model46} input
 * @returns {string}
 */

/**
 * @template {Model46} T
 * @param {T} value
 * @returns {T}
 */
function preserve46(value) {
  return value;
}

class Store46 {
  /**
   * @param {Box46<Model46>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project46} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model46} */
const model46 = {
  id: 46, name: "model-46", meta: { active: true, label: "meta-46" },
};
const preserved46 = preserve46(model46);
/** @type {Box46<Model46>} */
const box46 = { value: preserved46, label: "box-46" };
/** @type {Project46} */
const project46 = (input) => `${input.meta.label}:${input.name}`;
const store46 = new Store46(box46);
const rendered46 = store46.read(project46);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult46 = {
  id: preserved46.id,
  name: preserved46.name,
  active: preserved46.meta.active,
  rendered: rendered46,
};

/**
 * @typedef {object} Model47
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box47
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project47
 * @param {Model47} input
 * @returns {string}
 */

/**
 * @template {Model47} T
 * @param {T} value
 * @returns {T}
 */
function preserve47(value) {
  return value;
}

class Store47 {
  /**
   * @param {Box47<Model47>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project47} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model47} */
const model47 = {
  id: 47, name: "model-47", meta: { active: false, label: "meta-47" },
};
const preserved47 = preserve47(model47);
/** @type {Box47<Model47>} */
const box47 = { value: preserved47, label: "box-47" };
/** @type {Project47} */
const project47 = (input) => `${input.meta.label}:${input.name}`;
const store47 = new Store47(box47);
const rendered47 = store47.read(project47);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult47 = {
  id: preserved47.id,
  name: preserved47.name,
  active: preserved47.meta.active,
  rendered: rendered47,
};

/**
 * @typedef {object} Model48
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box48
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project48
 * @param {Model48} input
 * @returns {string}
 */

/**
 * @template {Model48} T
 * @param {T} value
 * @returns {T}
 */
function preserve48(value) {
  return value;
}

class Store48 {
  /**
   * @param {Box48<Model48>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project48} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model48} */
const model48 = {
  id: 48, name: "model-48", meta: { active: true, label: "meta-48" },
};
const preserved48 = preserve48(model48);
/** @type {Box48<Model48>} */
const box48 = { value: preserved48, label: "box-48" };
/** @type {Project48} */
const project48 = (input) => `${input.meta.label}:${input.name}`;
const store48 = new Store48(box48);
const rendered48 = store48.read(project48);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult48 = {
  id: preserved48.id,
  name: preserved48.name,
  active: preserved48.meta.active,
  rendered: rendered48,
};

/**
 * @typedef {object} Model49
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box49
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project49
 * @param {Model49} input
 * @returns {string}
 */

/**
 * @template {Model49} T
 * @param {T} value
 * @returns {T}
 */
function preserve49(value) {
  return value;
}

class Store49 {
  /**
   * @param {Box49<Model49>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project49} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model49} */
const model49 = {
  id: 49, name: "model-49", meta: { active: false, label: "meta-49" },
};
const preserved49 = preserve49(model49);
/** @type {Box49<Model49>} */
const box49 = { value: preserved49, label: "box-49" };
/** @type {Project49} */
const project49 = (input) => `${input.meta.label}:${input.name}`;
const store49 = new Store49(box49);
const rendered49 = store49.read(project49);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult49 = {
  id: preserved49.id,
  name: preserved49.name,
  active: preserved49.meta.active,
  rendered: rendered49,
};

/**
 * @typedef {object} Model50
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box50
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project50
 * @param {Model50} input
 * @returns {string}
 */

/**
 * @template {Model50} T
 * @param {T} value
 * @returns {T}
 */
function preserve50(value) {
  return value;
}

class Store50 {
  /**
   * @param {Box50<Model50>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project50} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model50} */
const model50 = {
  id: 50, name: "model-50", meta: { active: true, label: "meta-50" },
};
const preserved50 = preserve50(model50);
/** @type {Box50<Model50>} */
const box50 = { value: preserved50, label: "box-50" };
/** @type {Project50} */
const project50 = (input) => `${input.meta.label}:${input.name}`;
const store50 = new Store50(box50);
const rendered50 = store50.read(project50);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult50 = {
  id: preserved50.id,
  name: preserved50.name,
  active: preserved50.meta.active,
  rendered: rendered50,
};

/**
 * @typedef {object} Model51
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box51
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project51
 * @param {Model51} input
 * @returns {string}
 */

/**
 * @template {Model51} T
 * @param {T} value
 * @returns {T}
 */
function preserve51(value) {
  return value;
}

class Store51 {
  /**
   * @param {Box51<Model51>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project51} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model51} */
const model51 = {
  id: 51, name: "model-51", meta: { active: false, label: "meta-51" },
};
const preserved51 = preserve51(model51);
/** @type {Box51<Model51>} */
const box51 = { value: preserved51, label: "box-51" };
/** @type {Project51} */
const project51 = (input) => `${input.meta.label}:${input.name}`;
const store51 = new Store51(box51);
const rendered51 = store51.read(project51);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult51 = {
  id: preserved51.id,
  name: preserved51.name,
  active: preserved51.meta.active,
  rendered: rendered51,
};

/**
 * @typedef {object} Model52
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box52
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project52
 * @param {Model52} input
 * @returns {string}
 */

/**
 * @template {Model52} T
 * @param {T} value
 * @returns {T}
 */
function preserve52(value) {
  return value;
}

class Store52 {
  /**
   * @param {Box52<Model52>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project52} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model52} */
const model52 = {
  id: 52, name: "model-52", meta: { active: true, label: "meta-52" },
};
const preserved52 = preserve52(model52);
/** @type {Box52<Model52>} */
const box52 = { value: preserved52, label: "box-52" };
/** @type {Project52} */
const project52 = (input) => `${input.meta.label}:${input.name}`;
const store52 = new Store52(box52);
const rendered52 = store52.read(project52);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult52 = {
  id: preserved52.id,
  name: preserved52.name,
  active: preserved52.meta.active,
  rendered: rendered52,
};

/**
 * @typedef {object} Model53
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box53
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project53
 * @param {Model53} input
 * @returns {string}
 */

/**
 * @template {Model53} T
 * @param {T} value
 * @returns {T}
 */
function preserve53(value) {
  return value;
}

class Store53 {
  /**
   * @param {Box53<Model53>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project53} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model53} */
const model53 = {
  id: 53, name: "model-53", meta: { active: false, label: "meta-53" },
};
const preserved53 = preserve53(model53);
/** @type {Box53<Model53>} */
const box53 = { value: preserved53, label: "box-53" };
/** @type {Project53} */
const project53 = (input) => `${input.meta.label}:${input.name}`;
const store53 = new Store53(box53);
const rendered53 = store53.read(project53);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult53 = {
  id: preserved53.id,
  name: preserved53.name,
  active: preserved53.meta.active,
  rendered: rendered53,
};

/**
 * @typedef {object} Model54
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box54
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project54
 * @param {Model54} input
 * @returns {string}
 */

/**
 * @template {Model54} T
 * @param {T} value
 * @returns {T}
 */
function preserve54(value) {
  return value;
}

class Store54 {
  /**
   * @param {Box54<Model54>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project54} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model54} */
const model54 = {
  id: 54, name: "model-54", meta: { active: true, label: "meta-54" },
};
const preserved54 = preserve54(model54);
/** @type {Box54<Model54>} */
const box54 = { value: preserved54, label: "box-54" };
/** @type {Project54} */
const project54 = (input) => `${input.meta.label}:${input.name}`;
const store54 = new Store54(box54);
const rendered54 = store54.read(project54);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult54 = {
  id: preserved54.id,
  name: preserved54.name,
  active: preserved54.meta.active,
  rendered: rendered54,
};

/**
 * @typedef {object} Model55
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box55
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project55
 * @param {Model55} input
 * @returns {string}
 */

/**
 * @template {Model55} T
 * @param {T} value
 * @returns {T}
 */
function preserve55(value) {
  return value;
}

class Store55 {
  /**
   * @param {Box55<Model55>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project55} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model55} */
const model55 = {
  id: 55, name: "model-55", meta: { active: false, label: "meta-55" },
};
const preserved55 = preserve55(model55);
/** @type {Box55<Model55>} */
const box55 = { value: preserved55, label: "box-55" };
/** @type {Project55} */
const project55 = (input) => `${input.meta.label}:${input.name}`;
const store55 = new Store55(box55);
const rendered55 = store55.read(project55);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult55 = {
  id: preserved55.id,
  name: preserved55.name,
  active: preserved55.meta.active,
  rendered: rendered55,
};

/**
 * @typedef {object} Model56
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box56
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project56
 * @param {Model56} input
 * @returns {string}
 */

/**
 * @template {Model56} T
 * @param {T} value
 * @returns {T}
 */
function preserve56(value) {
  return value;
}

class Store56 {
  /**
   * @param {Box56<Model56>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project56} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model56} */
const model56 = {
  id: 56, name: "model-56", meta: { active: true, label: "meta-56" },
};
const preserved56 = preserve56(model56);
/** @type {Box56<Model56>} */
const box56 = { value: preserved56, label: "box-56" };
/** @type {Project56} */
const project56 = (input) => `${input.meta.label}:${input.name}`;
const store56 = new Store56(box56);
const rendered56 = store56.read(project56);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult56 = {
  id: preserved56.id,
  name: preserved56.name,
  active: preserved56.meta.active,
  rendered: rendered56,
};

/**
 * @typedef {object} Model57
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box57
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project57
 * @param {Model57} input
 * @returns {string}
 */

/**
 * @template {Model57} T
 * @param {T} value
 * @returns {T}
 */
function preserve57(value) {
  return value;
}

class Store57 {
  /**
   * @param {Box57<Model57>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project57} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model57} */
const model57 = {
  id: 57, name: "model-57", meta: { active: false, label: "meta-57" },
};
const preserved57 = preserve57(model57);
/** @type {Box57<Model57>} */
const box57 = { value: preserved57, label: "box-57" };
/** @type {Project57} */
const project57 = (input) => `${input.meta.label}:${input.name}`;
const store57 = new Store57(box57);
const rendered57 = store57.read(project57);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult57 = {
  id: preserved57.id,
  name: preserved57.name,
  active: preserved57.meta.active,
  rendered: rendered57,
};

/**
 * @typedef {object} Model58
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box58
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project58
 * @param {Model58} input
 * @returns {string}
 */

/**
 * @template {Model58} T
 * @param {T} value
 * @returns {T}
 */
function preserve58(value) {
  return value;
}

class Store58 {
  /**
   * @param {Box58<Model58>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project58} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model58} */
const model58 = {
  id: 58, name: "model-58", meta: { active: true, label: "meta-58" },
};
const preserved58 = preserve58(model58);
/** @type {Box58<Model58>} */
const box58 = { value: preserved58, label: "box-58" };
/** @type {Project58} */
const project58 = (input) => `${input.meta.label}:${input.name}`;
const store58 = new Store58(box58);
const rendered58 = store58.read(project58);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult58 = {
  id: preserved58.id,
  name: preserved58.name,
  active: preserved58.meta.active,
  rendered: rendered58,
};

/**
 * @typedef {object} Model59
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box59
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project59
 * @param {Model59} input
 * @returns {string}
 */

/**
 * @template {Model59} T
 * @param {T} value
 * @returns {T}
 */
function preserve59(value) {
  return value;
}

class Store59 {
  /**
   * @param {Box59<Model59>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project59} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model59} */
const model59 = {
  id: 59, name: "model-59", meta: { active: false, label: "meta-59" },
};
const preserved59 = preserve59(model59);
/** @type {Box59<Model59>} */
const box59 = { value: preserved59, label: "box-59" };
/** @type {Project59} */
const project59 = (input) => `${input.meta.label}:${input.name}`;
const store59 = new Store59(box59);
const rendered59 = store59.read(project59);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult59 = {
  id: preserved59.id,
  name: preserved59.name,
  active: preserved59.meta.active,
  rendered: rendered59,
};

/**
 * @typedef {object} Model60
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box60
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project60
 * @param {Model60} input
 * @returns {string}
 */

/**
 * @template {Model60} T
 * @param {T} value
 * @returns {T}
 */
function preserve60(value) {
  return value;
}

class Store60 {
  /**
   * @param {Box60<Model60>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project60} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model60} */
const model60 = {
  id: 60, name: "model-60", meta: { active: true, label: "meta-60" },
};
const preserved60 = preserve60(model60);
/** @type {Box60<Model60>} */
const box60 = { value: preserved60, label: "box-60" };
/** @type {Project60} */
const project60 = (input) => `${input.meta.label}:${input.name}`;
const store60 = new Store60(box60);
const rendered60 = store60.read(project60);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult60 = {
  id: preserved60.id,
  name: preserved60.name,
  active: preserved60.meta.active,
  rendered: rendered60,
};

/**
 * @typedef {object} Model61
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box61
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project61
 * @param {Model61} input
 * @returns {string}
 */

/**
 * @template {Model61} T
 * @param {T} value
 * @returns {T}
 */
function preserve61(value) {
  return value;
}

class Store61 {
  /**
   * @param {Box61<Model61>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project61} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model61} */
const model61 = {
  id: 61, name: "model-61", meta: { active: false, label: "meta-61" },
};
const preserved61 = preserve61(model61);
/** @type {Box61<Model61>} */
const box61 = { value: preserved61, label: "box-61" };
/** @type {Project61} */
const project61 = (input) => `${input.meta.label}:${input.name}`;
const store61 = new Store61(box61);
const rendered61 = store61.read(project61);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult61 = {
  id: preserved61.id,
  name: preserved61.name,
  active: preserved61.meta.active,
  rendered: rendered61,
};

/**
 * @typedef {object} Model62
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box62
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project62
 * @param {Model62} input
 * @returns {string}
 */

/**
 * @template {Model62} T
 * @param {T} value
 * @returns {T}
 */
function preserve62(value) {
  return value;
}

class Store62 {
  /**
   * @param {Box62<Model62>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project62} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model62} */
const model62 = {
  id: 62, name: "model-62", meta: { active: true, label: "meta-62" },
};
const preserved62 = preserve62(model62);
/** @type {Box62<Model62>} */
const box62 = { value: preserved62, label: "box-62" };
/** @type {Project62} */
const project62 = (input) => `${input.meta.label}:${input.name}`;
const store62 = new Store62(box62);
const rendered62 = store62.read(project62);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult62 = {
  id: preserved62.id,
  name: preserved62.name,
  active: preserved62.meta.active,
  rendered: rendered62,
};

/**
 * @typedef {object} Model63
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box63
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project63
 * @param {Model63} input
 * @returns {string}
 */

/**
 * @template {Model63} T
 * @param {T} value
 * @returns {T}
 */
function preserve63(value) {
  return value;
}

class Store63 {
  /**
   * @param {Box63<Model63>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project63} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model63} */
const model63 = {
  id: 63, name: "model-63", meta: { active: false, label: "meta-63" },
};
const preserved63 = preserve63(model63);
/** @type {Box63<Model63>} */
const box63 = { value: preserved63, label: "box-63" };
/** @type {Project63} */
const project63 = (input) => `${input.meta.label}:${input.name}`;
const store63 = new Store63(box63);
const rendered63 = store63.read(project63);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult63 = {
  id: preserved63.id,
  name: preserved63.name,
  active: preserved63.meta.active,
  rendered: rendered63,
};

/**
 * @typedef {object} Model64
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box64
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project64
 * @param {Model64} input
 * @returns {string}
 */

/**
 * @template {Model64} T
 * @param {T} value
 * @returns {T}
 */
function preserve64(value) {
  return value;
}

class Store64 {
  /**
   * @param {Box64<Model64>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project64} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model64} */
const model64 = {
  id: 64, name: "model-64", meta: { active: true, label: "meta-64" },
};
const preserved64 = preserve64(model64);
/** @type {Box64<Model64>} */
const box64 = { value: preserved64, label: "box-64" };
/** @type {Project64} */
const project64 = (input) => `${input.meta.label}:${input.name}`;
const store64 = new Store64(box64);
const rendered64 = store64.read(project64);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult64 = {
  id: preserved64.id,
  name: preserved64.name,
  active: preserved64.meta.active,
  rendered: rendered64,
};

/**
 * @typedef {object} Model65
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box65
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project65
 * @param {Model65} input
 * @returns {string}
 */

/**
 * @template {Model65} T
 * @param {T} value
 * @returns {T}
 */
function preserve65(value) {
  return value;
}

class Store65 {
  /**
   * @param {Box65<Model65>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project65} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model65} */
const model65 = {
  id: 65, name: "model-65", meta: { active: false, label: "meta-65" },
};
const preserved65 = preserve65(model65);
/** @type {Box65<Model65>} */
const box65 = { value: preserved65, label: "box-65" };
/** @type {Project65} */
const project65 = (input) => `${input.meta.label}:${input.name}`;
const store65 = new Store65(box65);
const rendered65 = store65.read(project65);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult65 = {
  id: preserved65.id,
  name: preserved65.name,
  active: preserved65.meta.active,
  rendered: rendered65,
};

/**
 * @typedef {object} Model66
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box66
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project66
 * @param {Model66} input
 * @returns {string}
 */

/**
 * @template {Model66} T
 * @param {T} value
 * @returns {T}
 */
function preserve66(value) {
  return value;
}

class Store66 {
  /**
   * @param {Box66<Model66>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project66} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model66} */
const model66 = {
  id: 66, name: "model-66", meta: { active: true, label: "meta-66" },
};
const preserved66 = preserve66(model66);
/** @type {Box66<Model66>} */
const box66 = { value: preserved66, label: "box-66" };
/** @type {Project66} */
const project66 = (input) => `${input.meta.label}:${input.name}`;
const store66 = new Store66(box66);
const rendered66 = store66.read(project66);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult66 = {
  id: preserved66.id,
  name: preserved66.name,
  active: preserved66.meta.active,
  rendered: rendered66,
};

/**
 * @typedef {object} Model67
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box67
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project67
 * @param {Model67} input
 * @returns {string}
 */

/**
 * @template {Model67} T
 * @param {T} value
 * @returns {T}
 */
function preserve67(value) {
  return value;
}

class Store67 {
  /**
   * @param {Box67<Model67>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project67} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model67} */
const model67 = {
  id: 67, name: "model-67", meta: { active: false, label: "meta-67" },
};
const preserved67 = preserve67(model67);
/** @type {Box67<Model67>} */
const box67 = { value: preserved67, label: "box-67" };
/** @type {Project67} */
const project67 = (input) => `${input.meta.label}:${input.name}`;
const store67 = new Store67(box67);
const rendered67 = store67.read(project67);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult67 = {
  id: preserved67.id,
  name: preserved67.name,
  active: preserved67.meta.active,
  rendered: rendered67,
};

/**
 * @typedef {object} Model68
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box68
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project68
 * @param {Model68} input
 * @returns {string}
 */

/**
 * @template {Model68} T
 * @param {T} value
 * @returns {T}
 */
function preserve68(value) {
  return value;
}

class Store68 {
  /**
   * @param {Box68<Model68>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project68} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model68} */
const model68 = {
  id: 68, name: "model-68", meta: { active: true, label: "meta-68" },
};
const preserved68 = preserve68(model68);
/** @type {Box68<Model68>} */
const box68 = { value: preserved68, label: "box-68" };
/** @type {Project68} */
const project68 = (input) => `${input.meta.label}:${input.name}`;
const store68 = new Store68(box68);
const rendered68 = store68.read(project68);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult68 = {
  id: preserved68.id,
  name: preserved68.name,
  active: preserved68.meta.active,
  rendered: rendered68,
};

/**
 * @typedef {object} Model69
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box69
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project69
 * @param {Model69} input
 * @returns {string}
 */

/**
 * @template {Model69} T
 * @param {T} value
 * @returns {T}
 */
function preserve69(value) {
  return value;
}

class Store69 {
  /**
   * @param {Box69<Model69>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project69} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model69} */
const model69 = {
  id: 69, name: "model-69", meta: { active: false, label: "meta-69" },
};
const preserved69 = preserve69(model69);
/** @type {Box69<Model69>} */
const box69 = { value: preserved69, label: "box-69" };
/** @type {Project69} */
const project69 = (input) => `${input.meta.label}:${input.name}`;
const store69 = new Store69(box69);
const rendered69 = store69.read(project69);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult69 = {
  id: preserved69.id,
  name: preserved69.name,
  active: preserved69.meta.active,
  rendered: rendered69,
};

/**
 * @typedef {object} Model70
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box70
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project70
 * @param {Model70} input
 * @returns {string}
 */

/**
 * @template {Model70} T
 * @param {T} value
 * @returns {T}
 */
function preserve70(value) {
  return value;
}

class Store70 {
  /**
   * @param {Box70<Model70>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project70} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model70} */
const model70 = {
  id: 70, name: "model-70", meta: { active: true, label: "meta-70" },
};
const preserved70 = preserve70(model70);
/** @type {Box70<Model70>} */
const box70 = { value: preserved70, label: "box-70" };
/** @type {Project70} */
const project70 = (input) => `${input.meta.label}:${input.name}`;
const store70 = new Store70(box70);
const rendered70 = store70.read(project70);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult70 = {
  id: preserved70.id,
  name: preserved70.name,
  active: preserved70.meta.active,
  rendered: rendered70,
};

/**
 * @typedef {object} Model71
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box71
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project71
 * @param {Model71} input
 * @returns {string}
 */

/**
 * @template {Model71} T
 * @param {T} value
 * @returns {T}
 */
function preserve71(value) {
  return value;
}

class Store71 {
  /**
   * @param {Box71<Model71>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project71} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model71} */
const model71 = {
  id: 71, name: "model-71", meta: { active: false, label: "meta-71" },
};
const preserved71 = preserve71(model71);
/** @type {Box71<Model71>} */
const box71 = { value: preserved71, label: "box-71" };
/** @type {Project71} */
const project71 = (input) => `${input.meta.label}:${input.name}`;
const store71 = new Store71(box71);
const rendered71 = store71.read(project71);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult71 = {
  id: preserved71.id,
  name: preserved71.name,
  active: preserved71.meta.active,
  rendered: rendered71,
};

/**
 * @typedef {object} Model72
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box72
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project72
 * @param {Model72} input
 * @returns {string}
 */

/**
 * @template {Model72} T
 * @param {T} value
 * @returns {T}
 */
function preserve72(value) {
  return value;
}

class Store72 {
  /**
   * @param {Box72<Model72>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project72} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model72} */
const model72 = {
  id: 72, name: "model-72", meta: { active: true, label: "meta-72" },
};
const preserved72 = preserve72(model72);
/** @type {Box72<Model72>} */
const box72 = { value: preserved72, label: "box-72" };
/** @type {Project72} */
const project72 = (input) => `${input.meta.label}:${input.name}`;
const store72 = new Store72(box72);
const rendered72 = store72.read(project72);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult72 = {
  id: preserved72.id,
  name: preserved72.name,
  active: preserved72.meta.active,
  rendered: rendered72,
};

/**
 * @typedef {object} Model73
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box73
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project73
 * @param {Model73} input
 * @returns {string}
 */

/**
 * @template {Model73} T
 * @param {T} value
 * @returns {T}
 */
function preserve73(value) {
  return value;
}

class Store73 {
  /**
   * @param {Box73<Model73>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project73} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model73} */
const model73 = {
  id: 73, name: "model-73", meta: { active: false, label: "meta-73" },
};
const preserved73 = preserve73(model73);
/** @type {Box73<Model73>} */
const box73 = { value: preserved73, label: "box-73" };
/** @type {Project73} */
const project73 = (input) => `${input.meta.label}:${input.name}`;
const store73 = new Store73(box73);
const rendered73 = store73.read(project73);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult73 = {
  id: preserved73.id,
  name: preserved73.name,
  active: preserved73.meta.active,
  rendered: rendered73,
};

/**
 * @typedef {object} Model74
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box74
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project74
 * @param {Model74} input
 * @returns {string}
 */

/**
 * @template {Model74} T
 * @param {T} value
 * @returns {T}
 */
function preserve74(value) {
  return value;
}

class Store74 {
  /**
   * @param {Box74<Model74>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project74} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model74} */
const model74 = {
  id: 74, name: "model-74", meta: { active: true, label: "meta-74" },
};
const preserved74 = preserve74(model74);
/** @type {Box74<Model74>} */
const box74 = { value: preserved74, label: "box-74" };
/** @type {Project74} */
const project74 = (input) => `${input.meta.label}:${input.name}`;
const store74 = new Store74(box74);
const rendered74 = store74.read(project74);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult74 = {
  id: preserved74.id,
  name: preserved74.name,
  active: preserved74.meta.active,
  rendered: rendered74,
};

/**
 * @typedef {object} Model75
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box75
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project75
 * @param {Model75} input
 * @returns {string}
 */

/**
 * @template {Model75} T
 * @param {T} value
 * @returns {T}
 */
function preserve75(value) {
  return value;
}

class Store75 {
  /**
   * @param {Box75<Model75>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project75} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model75} */
const model75 = {
  id: 75, name: "model-75", meta: { active: false, label: "meta-75" },
};
const preserved75 = preserve75(model75);
/** @type {Box75<Model75>} */
const box75 = { value: preserved75, label: "box-75" };
/** @type {Project75} */
const project75 = (input) => `${input.meta.label}:${input.name}`;
const store75 = new Store75(box75);
const rendered75 = store75.read(project75);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult75 = {
  id: preserved75.id,
  name: preserved75.name,
  active: preserved75.meta.active,
  rendered: rendered75,
};

/**
 * @typedef {object} Model76
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box76
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project76
 * @param {Model76} input
 * @returns {string}
 */

/**
 * @template {Model76} T
 * @param {T} value
 * @returns {T}
 */
function preserve76(value) {
  return value;
}

class Store76 {
  /**
   * @param {Box76<Model76>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project76} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model76} */
const model76 = {
  id: 76, name: "model-76", meta: { active: true, label: "meta-76" },
};
const preserved76 = preserve76(model76);
/** @type {Box76<Model76>} */
const box76 = { value: preserved76, label: "box-76" };
/** @type {Project76} */
const project76 = (input) => `${input.meta.label}:${input.name}`;
const store76 = new Store76(box76);
const rendered76 = store76.read(project76);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult76 = {
  id: preserved76.id,
  name: preserved76.name,
  active: preserved76.meta.active,
  rendered: rendered76,
};

/**
 * @typedef {object} Model77
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box77
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project77
 * @param {Model77} input
 * @returns {string}
 */

/**
 * @template {Model77} T
 * @param {T} value
 * @returns {T}
 */
function preserve77(value) {
  return value;
}

class Store77 {
  /**
   * @param {Box77<Model77>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project77} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model77} */
const model77 = {
  id: 77, name: "model-77", meta: { active: false, label: "meta-77" },
};
const preserved77 = preserve77(model77);
/** @type {Box77<Model77>} */
const box77 = { value: preserved77, label: "box-77" };
/** @type {Project77} */
const project77 = (input) => `${input.meta.label}:${input.name}`;
const store77 = new Store77(box77);
const rendered77 = store77.read(project77);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult77 = {
  id: preserved77.id,
  name: preserved77.name,
  active: preserved77.meta.active,
  rendered: rendered77,
};

/**
 * @typedef {object} Model78
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box78
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project78
 * @param {Model78} input
 * @returns {string}
 */

/**
 * @template {Model78} T
 * @param {T} value
 * @returns {T}
 */
function preserve78(value) {
  return value;
}

class Store78 {
  /**
   * @param {Box78<Model78>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project78} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model78} */
const model78 = {
  id: 78, name: "model-78", meta: { active: true, label: "meta-78" },
};
const preserved78 = preserve78(model78);
/** @type {Box78<Model78>} */
const box78 = { value: preserved78, label: "box-78" };
/** @type {Project78} */
const project78 = (input) => `${input.meta.label}:${input.name}`;
const store78 = new Store78(box78);
const rendered78 = store78.read(project78);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult78 = {
  id: preserved78.id,
  name: preserved78.name,
  active: preserved78.meta.active,
  rendered: rendered78,
};

/**
 * @typedef {object} Model79
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box79
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project79
 * @param {Model79} input
 * @returns {string}
 */

/**
 * @template {Model79} T
 * @param {T} value
 * @returns {T}
 */
function preserve79(value) {
  return value;
}

class Store79 {
  /**
   * @param {Box79<Model79>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project79} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model79} */
const model79 = {
  id: 79, name: "model-79", meta: { active: false, label: "meta-79" },
};
const preserved79 = preserve79(model79);
/** @type {Box79<Model79>} */
const box79 = { value: preserved79, label: "box-79" };
/** @type {Project79} */
const project79 = (input) => `${input.meta.label}:${input.name}`;
const store79 = new Store79(box79);
const rendered79 = store79.read(project79);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult79 = {
  id: preserved79.id,
  name: preserved79.name,
  active: preserved79.meta.active,
  rendered: rendered79,
};

/**
 * @typedef {object} Model80
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box80
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project80
 * @param {Model80} input
 * @returns {string}
 */

/**
 * @template {Model80} T
 * @param {T} value
 * @returns {T}
 */
function preserve80(value) {
  return value;
}

class Store80 {
  /**
   * @param {Box80<Model80>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project80} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model80} */
const model80 = {
  id: 80, name: "model-80", meta: { active: true, label: "meta-80" },
};
const preserved80 = preserve80(model80);
/** @type {Box80<Model80>} */
const box80 = { value: preserved80, label: "box-80" };
/** @type {Project80} */
const project80 = (input) => `${input.meta.label}:${input.name}`;
const store80 = new Store80(box80);
const rendered80 = store80.read(project80);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult80 = {
  id: preserved80.id,
  name: preserved80.name,
  active: preserved80.meta.active,
  rendered: rendered80,
};

/**
 * @typedef {object} Model81
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box81
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project81
 * @param {Model81} input
 * @returns {string}
 */

/**
 * @template {Model81} T
 * @param {T} value
 * @returns {T}
 */
function preserve81(value) {
  return value;
}

class Store81 {
  /**
   * @param {Box81<Model81>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project81} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model81} */
const model81 = {
  id: 81, name: "model-81", meta: { active: false, label: "meta-81" },
};
const preserved81 = preserve81(model81);
/** @type {Box81<Model81>} */
const box81 = { value: preserved81, label: "box-81" };
/** @type {Project81} */
const project81 = (input) => `${input.meta.label}:${input.name}`;
const store81 = new Store81(box81);
const rendered81 = store81.read(project81);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult81 = {
  id: preserved81.id,
  name: preserved81.name,
  active: preserved81.meta.active,
  rendered: rendered81,
};

/**
 * @typedef {object} Model82
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box82
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project82
 * @param {Model82} input
 * @returns {string}
 */

/**
 * @template {Model82} T
 * @param {T} value
 * @returns {T}
 */
function preserve82(value) {
  return value;
}

class Store82 {
  /**
   * @param {Box82<Model82>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project82} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model82} */
const model82 = {
  id: 82, name: "model-82", meta: { active: true, label: "meta-82" },
};
const preserved82 = preserve82(model82);
/** @type {Box82<Model82>} */
const box82 = { value: preserved82, label: "box-82" };
/** @type {Project82} */
const project82 = (input) => `${input.meta.label}:${input.name}`;
const store82 = new Store82(box82);
const rendered82 = store82.read(project82);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult82 = {
  id: preserved82.id,
  name: preserved82.name,
  active: preserved82.meta.active,
  rendered: rendered82,
};

/**
 * @typedef {object} Model83
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box83
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project83
 * @param {Model83} input
 * @returns {string}
 */

/**
 * @template {Model83} T
 * @param {T} value
 * @returns {T}
 */
function preserve83(value) {
  return value;
}

class Store83 {
  /**
   * @param {Box83<Model83>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project83} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model83} */
const model83 = {
  id: 83, name: "model-83", meta: { active: false, label: "meta-83" },
};
const preserved83 = preserve83(model83);
/** @type {Box83<Model83>} */
const box83 = { value: preserved83, label: "box-83" };
/** @type {Project83} */
const project83 = (input) => `${input.meta.label}:${input.name}`;
const store83 = new Store83(box83);
const rendered83 = store83.read(project83);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult83 = {
  id: preserved83.id,
  name: preserved83.name,
  active: preserved83.meta.active,
  rendered: rendered83,
};

/**
 * @typedef {object} Model84
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box84
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project84
 * @param {Model84} input
 * @returns {string}
 */

/**
 * @template {Model84} T
 * @param {T} value
 * @returns {T}
 */
function preserve84(value) {
  return value;
}

class Store84 {
  /**
   * @param {Box84<Model84>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project84} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model84} */
const model84 = {
  id: 84, name: "model-84", meta: { active: true, label: "meta-84" },
};
const preserved84 = preserve84(model84);
/** @type {Box84<Model84>} */
const box84 = { value: preserved84, label: "box-84" };
/** @type {Project84} */
const project84 = (input) => `${input.meta.label}:${input.name}`;
const store84 = new Store84(box84);
const rendered84 = store84.read(project84);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult84 = {
  id: preserved84.id,
  name: preserved84.name,
  active: preserved84.meta.active,
  rendered: rendered84,
};

/**
 * @typedef {object} Model85
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box85
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project85
 * @param {Model85} input
 * @returns {string}
 */

/**
 * @template {Model85} T
 * @param {T} value
 * @returns {T}
 */
function preserve85(value) {
  return value;
}

class Store85 {
  /**
   * @param {Box85<Model85>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project85} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model85} */
const model85 = {
  id: 85, name: "model-85", meta: { active: false, label: "meta-85" },
};
const preserved85 = preserve85(model85);
/** @type {Box85<Model85>} */
const box85 = { value: preserved85, label: "box-85" };
/** @type {Project85} */
const project85 = (input) => `${input.meta.label}:${input.name}`;
const store85 = new Store85(box85);
const rendered85 = store85.read(project85);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult85 = {
  id: preserved85.id,
  name: preserved85.name,
  active: preserved85.meta.active,
  rendered: rendered85,
};

/**
 * @typedef {object} Model86
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box86
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project86
 * @param {Model86} input
 * @returns {string}
 */

/**
 * @template {Model86} T
 * @param {T} value
 * @returns {T}
 */
function preserve86(value) {
  return value;
}

class Store86 {
  /**
   * @param {Box86<Model86>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project86} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model86} */
const model86 = {
  id: 86, name: "model-86", meta: { active: true, label: "meta-86" },
};
const preserved86 = preserve86(model86);
/** @type {Box86<Model86>} */
const box86 = { value: preserved86, label: "box-86" };
/** @type {Project86} */
const project86 = (input) => `${input.meta.label}:${input.name}`;
const store86 = new Store86(box86);
const rendered86 = store86.read(project86);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult86 = {
  id: preserved86.id,
  name: preserved86.name,
  active: preserved86.meta.active,
  rendered: rendered86,
};

/**
 * @typedef {object} Model87
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box87
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project87
 * @param {Model87} input
 * @returns {string}
 */

/**
 * @template {Model87} T
 * @param {T} value
 * @returns {T}
 */
function preserve87(value) {
  return value;
}

class Store87 {
  /**
   * @param {Box87<Model87>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project87} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model87} */
const model87 = {
  id: 87, name: "model-87", meta: { active: false, label: "meta-87" },
};
const preserved87 = preserve87(model87);
/** @type {Box87<Model87>} */
const box87 = { value: preserved87, label: "box-87" };
/** @type {Project87} */
const project87 = (input) => `${input.meta.label}:${input.name}`;
const store87 = new Store87(box87);
const rendered87 = store87.read(project87);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult87 = {
  id: preserved87.id,
  name: preserved87.name,
  active: preserved87.meta.active,
  rendered: rendered87,
};

/**
 * @typedef {object} Model88
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box88
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project88
 * @param {Model88} input
 * @returns {string}
 */

/**
 * @template {Model88} T
 * @param {T} value
 * @returns {T}
 */
function preserve88(value) {
  return value;
}

class Store88 {
  /**
   * @param {Box88<Model88>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project88} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model88} */
const model88 = {
  id: 88, name: "model-88", meta: { active: true, label: "meta-88" },
};
const preserved88 = preserve88(model88);
/** @type {Box88<Model88>} */
const box88 = { value: preserved88, label: "box-88" };
/** @type {Project88} */
const project88 = (input) => `${input.meta.label}:${input.name}`;
const store88 = new Store88(box88);
const rendered88 = store88.read(project88);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult88 = {
  id: preserved88.id,
  name: preserved88.name,
  active: preserved88.meta.active,
  rendered: rendered88,
};

/**
 * @typedef {object} Model89
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box89
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project89
 * @param {Model89} input
 * @returns {string}
 */

/**
 * @template {Model89} T
 * @param {T} value
 * @returns {T}
 */
function preserve89(value) {
  return value;
}

class Store89 {
  /**
   * @param {Box89<Model89>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project89} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model89} */
const model89 = {
  id: 89, name: "model-89", meta: { active: false, label: "meta-89" },
};
const preserved89 = preserve89(model89);
/** @type {Box89<Model89>} */
const box89 = { value: preserved89, label: "box-89" };
/** @type {Project89} */
const project89 = (input) => `${input.meta.label}:${input.name}`;
const store89 = new Store89(box89);
const rendered89 = store89.read(project89);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult89 = {
  id: preserved89.id,
  name: preserved89.name,
  active: preserved89.meta.active,
  rendered: rendered89,
};

/**
 * @typedef {object} Model90
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box90
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project90
 * @param {Model90} input
 * @returns {string}
 */

/**
 * @template {Model90} T
 * @param {T} value
 * @returns {T}
 */
function preserve90(value) {
  return value;
}

class Store90 {
  /**
   * @param {Box90<Model90>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project90} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model90} */
const model90 = {
  id: 90, name: "model-90", meta: { active: true, label: "meta-90" },
};
const preserved90 = preserve90(model90);
/** @type {Box90<Model90>} */
const box90 = { value: preserved90, label: "box-90" };
/** @type {Project90} */
const project90 = (input) => `${input.meta.label}:${input.name}`;
const store90 = new Store90(box90);
const rendered90 = store90.read(project90);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult90 = {
  id: preserved90.id,
  name: preserved90.name,
  active: preserved90.meta.active,
  rendered: rendered90,
};

/**
 * @typedef {object} Model91
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box91
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project91
 * @param {Model91} input
 * @returns {string}
 */

/**
 * @template {Model91} T
 * @param {T} value
 * @returns {T}
 */
function preserve91(value) {
  return value;
}

class Store91 {
  /**
   * @param {Box91<Model91>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project91} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model91} */
const model91 = {
  id: 91, name: "model-91", meta: { active: false, label: "meta-91" },
};
const preserved91 = preserve91(model91);
/** @type {Box91<Model91>} */
const box91 = { value: preserved91, label: "box-91" };
/** @type {Project91} */
const project91 = (input) => `${input.meta.label}:${input.name}`;
const store91 = new Store91(box91);
const rendered91 = store91.read(project91);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult91 = {
  id: preserved91.id,
  name: preserved91.name,
  active: preserved91.meta.active,
  rendered: rendered91,
};

/**
 * @typedef {object} Model92
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box92
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project92
 * @param {Model92} input
 * @returns {string}
 */

/**
 * @template {Model92} T
 * @param {T} value
 * @returns {T}
 */
function preserve92(value) {
  return value;
}

class Store92 {
  /**
   * @param {Box92<Model92>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project92} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model92} */
const model92 = {
  id: 92, name: "model-92", meta: { active: true, label: "meta-92" },
};
const preserved92 = preserve92(model92);
/** @type {Box92<Model92>} */
const box92 = { value: preserved92, label: "box-92" };
/** @type {Project92} */
const project92 = (input) => `${input.meta.label}:${input.name}`;
const store92 = new Store92(box92);
const rendered92 = store92.read(project92);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult92 = {
  id: preserved92.id,
  name: preserved92.name,
  active: preserved92.meta.active,
  rendered: rendered92,
};

/**
 * @typedef {object} Model93
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box93
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project93
 * @param {Model93} input
 * @returns {string}
 */

/**
 * @template {Model93} T
 * @param {T} value
 * @returns {T}
 */
function preserve93(value) {
  return value;
}

class Store93 {
  /**
   * @param {Box93<Model93>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project93} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model93} */
const model93 = {
  id: 93, name: "model-93", meta: { active: false, label: "meta-93" },
};
const preserved93 = preserve93(model93);
/** @type {Box93<Model93>} */
const box93 = { value: preserved93, label: "box-93" };
/** @type {Project93} */
const project93 = (input) => `${input.meta.label}:${input.name}`;
const store93 = new Store93(box93);
const rendered93 = store93.read(project93);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult93 = {
  id: preserved93.id,
  name: preserved93.name,
  active: preserved93.meta.active,
  rendered: rendered93,
};

/**
 * @typedef {object} Model94
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box94
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project94
 * @param {Model94} input
 * @returns {string}
 */

/**
 * @template {Model94} T
 * @param {T} value
 * @returns {T}
 */
function preserve94(value) {
  return value;
}

class Store94 {
  /**
   * @param {Box94<Model94>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project94} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model94} */
const model94 = {
  id: 94, name: "model-94", meta: { active: true, label: "meta-94" },
};
const preserved94 = preserve94(model94);
/** @type {Box94<Model94>} */
const box94 = { value: preserved94, label: "box-94" };
/** @type {Project94} */
const project94 = (input) => `${input.meta.label}:${input.name}`;
const store94 = new Store94(box94);
const rendered94 = store94.read(project94);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult94 = {
  id: preserved94.id,
  name: preserved94.name,
  active: preserved94.meta.active,
  rendered: rendered94,
};

/**
 * @typedef {object} Model95
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box95
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project95
 * @param {Model95} input
 * @returns {string}
 */

/**
 * @template {Model95} T
 * @param {T} value
 * @returns {T}
 */
function preserve95(value) {
  return value;
}

class Store95 {
  /**
   * @param {Box95<Model95>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project95} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model95} */
const model95 = {
  id: 95, name: "model-95", meta: { active: false, label: "meta-95" },
};
const preserved95 = preserve95(model95);
/** @type {Box95<Model95>} */
const box95 = { value: preserved95, label: "box-95" };
/** @type {Project95} */
const project95 = (input) => `${input.meta.label}:${input.name}`;
const store95 = new Store95(box95);
const rendered95 = store95.read(project95);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult95 = {
  id: preserved95.id,
  name: preserved95.name,
  active: preserved95.meta.active,
  rendered: rendered95,
};

/**
 * @typedef {object} Model96
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box96
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project96
 * @param {Model96} input
 * @returns {string}
 */

/**
 * @template {Model96} T
 * @param {T} value
 * @returns {T}
 */
function preserve96(value) {
  return value;
}

class Store96 {
  /**
   * @param {Box96<Model96>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project96} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model96} */
const model96 = {
  id: 96, name: "model-96", meta: { active: true, label: "meta-96" },
};
const preserved96 = preserve96(model96);
/** @type {Box96<Model96>} */
const box96 = { value: preserved96, label: "box-96" };
/** @type {Project96} */
const project96 = (input) => `${input.meta.label}:${input.name}`;
const store96 = new Store96(box96);
const rendered96 = store96.read(project96);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult96 = {
  id: preserved96.id,
  name: preserved96.name,
  active: preserved96.meta.active,
  rendered: rendered96,
};

/**
 * @typedef {object} Model97
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box97
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project97
 * @param {Model97} input
 * @returns {string}
 */

/**
 * @template {Model97} T
 * @param {T} value
 * @returns {T}
 */
function preserve97(value) {
  return value;
}

class Store97 {
  /**
   * @param {Box97<Model97>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project97} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model97} */
const model97 = {
  id: 97, name: "model-97", meta: { active: false, label: "meta-97" },
};
const preserved97 = preserve97(model97);
/** @type {Box97<Model97>} */
const box97 = { value: preserved97, label: "box-97" };
/** @type {Project97} */
const project97 = (input) => `${input.meta.label}:${input.name}`;
const store97 = new Store97(box97);
const rendered97 = store97.read(project97);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult97 = {
  id: preserved97.id,
  name: preserved97.name,
  active: preserved97.meta.active,
  rendered: rendered97,
};

/**
 * @typedef {object} Model98
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box98
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project98
 * @param {Model98} input
 * @returns {string}
 */

/**
 * @template {Model98} T
 * @param {T} value
 * @returns {T}
 */
function preserve98(value) {
  return value;
}

class Store98 {
  /**
   * @param {Box98<Model98>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project98} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model98} */
const model98 = {
  id: 98, name: "model-98", meta: { active: true, label: "meta-98" },
};
const preserved98 = preserve98(model98);
/** @type {Box98<Model98>} */
const box98 = { value: preserved98, label: "box-98" };
/** @type {Project98} */
const project98 = (input) => `${input.meta.label}:${input.name}`;
const store98 = new Store98(box98);
const rendered98 = store98.read(project98);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult98 = {
  id: preserved98.id,
  name: preserved98.name,
  active: preserved98.meta.active,
  rendered: rendered98,
};

/**
 * @typedef {object} Model99
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box99
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project99
 * @param {Model99} input
 * @returns {string}
 */

/**
 * @template {Model99} T
 * @param {T} value
 * @returns {T}
 */
function preserve99(value) {
  return value;
}

class Store99 {
  /**
   * @param {Box99<Model99>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project99} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model99} */
const model99 = {
  id: 99, name: "model-99", meta: { active: false, label: "meta-99" },
};
const preserved99 = preserve99(model99);
/** @type {Box99<Model99>} */
const box99 = { value: preserved99, label: "box-99" };
/** @type {Project99} */
const project99 = (input) => `${input.meta.label}:${input.name}`;
const store99 = new Store99(box99);
const rendered99 = store99.read(project99);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult99 = {
  id: preserved99.id,
  name: preserved99.name,
  active: preserved99.meta.active,
  rendered: rendered99,
};

/**
 * @typedef {object} Model100
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box100
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project100
 * @param {Model100} input
 * @returns {string}
 */

/**
 * @template {Model100} T
 * @param {T} value
 * @returns {T}
 */
function preserve100(value) {
  return value;
}

class Store100 {
  /**
   * @param {Box100<Model100>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project100} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model100} */
const model100 = {
  id: 100, name: "model-100", meta: { active: true, label: "meta-100" },
};
const preserved100 = preserve100(model100);
/** @type {Box100<Model100>} */
const box100 = { value: preserved100, label: "box-100" };
/** @type {Project100} */
const project100 = (input) => `${input.meta.label}:${input.name}`;
const store100 = new Store100(box100);
const rendered100 = store100.read(project100);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult100 = {
  id: preserved100.id,
  name: preserved100.name,
  active: preserved100.meta.active,
  rendered: rendered100,
};

/**
 * @typedef {object} Model101
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box101
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project101
 * @param {Model101} input
 * @returns {string}
 */

/**
 * @template {Model101} T
 * @param {T} value
 * @returns {T}
 */
function preserve101(value) {
  return value;
}

class Store101 {
  /**
   * @param {Box101<Model101>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project101} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model101} */
const model101 = {
  id: 101, name: "model-101", meta: { active: false, label: "meta-101" },
};
const preserved101 = preserve101(model101);
/** @type {Box101<Model101>} */
const box101 = { value: preserved101, label: "box-101" };
/** @type {Project101} */
const project101 = (input) => `${input.meta.label}:${input.name}`;
const store101 = new Store101(box101);
const rendered101 = store101.read(project101);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult101 = {
  id: preserved101.id,
  name: preserved101.name,
  active: preserved101.meta.active,
  rendered: rendered101,
};

/**
 * @typedef {object} Model102
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box102
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project102
 * @param {Model102} input
 * @returns {string}
 */

/**
 * @template {Model102} T
 * @param {T} value
 * @returns {T}
 */
function preserve102(value) {
  return value;
}

class Store102 {
  /**
   * @param {Box102<Model102>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project102} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model102} */
const model102 = {
  id: 102, name: "model-102", meta: { active: true, label: "meta-102" },
};
const preserved102 = preserve102(model102);
/** @type {Box102<Model102>} */
const box102 = { value: preserved102, label: "box-102" };
/** @type {Project102} */
const project102 = (input) => `${input.meta.label}:${input.name}`;
const store102 = new Store102(box102);
const rendered102 = store102.read(project102);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult102 = {
  id: preserved102.id,
  name: preserved102.name,
  active: preserved102.meta.active,
  rendered: rendered102,
};

/**
 * @typedef {object} Model103
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box103
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project103
 * @param {Model103} input
 * @returns {string}
 */

/**
 * @template {Model103} T
 * @param {T} value
 * @returns {T}
 */
function preserve103(value) {
  return value;
}

class Store103 {
  /**
   * @param {Box103<Model103>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project103} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model103} */
const model103 = {
  id: 103, name: "model-103", meta: { active: false, label: "meta-103" },
};
const preserved103 = preserve103(model103);
/** @type {Box103<Model103>} */
const box103 = { value: preserved103, label: "box-103" };
/** @type {Project103} */
const project103 = (input) => `${input.meta.label}:${input.name}`;
const store103 = new Store103(box103);
const rendered103 = store103.read(project103);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult103 = {
  id: preserved103.id,
  name: preserved103.name,
  active: preserved103.meta.active,
  rendered: rendered103,
};

/**
 * @typedef {object} Model104
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box104
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project104
 * @param {Model104} input
 * @returns {string}
 */

/**
 * @template {Model104} T
 * @param {T} value
 * @returns {T}
 */
function preserve104(value) {
  return value;
}

class Store104 {
  /**
   * @param {Box104<Model104>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project104} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model104} */
const model104 = {
  id: 104, name: "model-104", meta: { active: true, label: "meta-104" },
};
const preserved104 = preserve104(model104);
/** @type {Box104<Model104>} */
const box104 = { value: preserved104, label: "box-104" };
/** @type {Project104} */
const project104 = (input) => `${input.meta.label}:${input.name}`;
const store104 = new Store104(box104);
const rendered104 = store104.read(project104);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult104 = {
  id: preserved104.id,
  name: preserved104.name,
  active: preserved104.meta.active,
  rendered: rendered104,
};

/**
 * @typedef {object} Model105
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box105
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project105
 * @param {Model105} input
 * @returns {string}
 */

/**
 * @template {Model105} T
 * @param {T} value
 * @returns {T}
 */
function preserve105(value) {
  return value;
}

class Store105 {
  /**
   * @param {Box105<Model105>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project105} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model105} */
const model105 = {
  id: 105, name: "model-105", meta: { active: false, label: "meta-105" },
};
const preserved105 = preserve105(model105);
/** @type {Box105<Model105>} */
const box105 = { value: preserved105, label: "box-105" };
/** @type {Project105} */
const project105 = (input) => `${input.meta.label}:${input.name}`;
const store105 = new Store105(box105);
const rendered105 = store105.read(project105);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult105 = {
  id: preserved105.id,
  name: preserved105.name,
  active: preserved105.meta.active,
  rendered: rendered105,
};

/**
 * @typedef {object} Model106
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box106
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project106
 * @param {Model106} input
 * @returns {string}
 */

/**
 * @template {Model106} T
 * @param {T} value
 * @returns {T}
 */
function preserve106(value) {
  return value;
}

class Store106 {
  /**
   * @param {Box106<Model106>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project106} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model106} */
const model106 = {
  id: 106, name: "model-106", meta: { active: true, label: "meta-106" },
};
const preserved106 = preserve106(model106);
/** @type {Box106<Model106>} */
const box106 = { value: preserved106, label: "box-106" };
/** @type {Project106} */
const project106 = (input) => `${input.meta.label}:${input.name}`;
const store106 = new Store106(box106);
const rendered106 = store106.read(project106);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult106 = {
  id: preserved106.id,
  name: preserved106.name,
  active: preserved106.meta.active,
  rendered: rendered106,
};

/**
 * @typedef {object} Model107
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box107
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project107
 * @param {Model107} input
 * @returns {string}
 */

/**
 * @template {Model107} T
 * @param {T} value
 * @returns {T}
 */
function preserve107(value) {
  return value;
}

class Store107 {
  /**
   * @param {Box107<Model107>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project107} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model107} */
const model107 = {
  id: 107, name: "model-107", meta: { active: false, label: "meta-107" },
};
const preserved107 = preserve107(model107);
/** @type {Box107<Model107>} */
const box107 = { value: preserved107, label: "box-107" };
/** @type {Project107} */
const project107 = (input) => `${input.meta.label}:${input.name}`;
const store107 = new Store107(box107);
const rendered107 = store107.read(project107);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult107 = {
  id: preserved107.id,
  name: preserved107.name,
  active: preserved107.meta.active,
  rendered: rendered107,
};

/**
 * @typedef {object} Model108
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box108
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project108
 * @param {Model108} input
 * @returns {string}
 */

/**
 * @template {Model108} T
 * @param {T} value
 * @returns {T}
 */
function preserve108(value) {
  return value;
}

class Store108 {
  /**
   * @param {Box108<Model108>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project108} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model108} */
const model108 = {
  id: 108, name: "model-108", meta: { active: true, label: "meta-108" },
};
const preserved108 = preserve108(model108);
/** @type {Box108<Model108>} */
const box108 = { value: preserved108, label: "box-108" };
/** @type {Project108} */
const project108 = (input) => `${input.meta.label}:${input.name}`;
const store108 = new Store108(box108);
const rendered108 = store108.read(project108);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult108 = {
  id: preserved108.id,
  name: preserved108.name,
  active: preserved108.meta.active,
  rendered: rendered108,
};

/**
 * @typedef {object} Model109
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box109
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project109
 * @param {Model109} input
 * @returns {string}
 */

/**
 * @template {Model109} T
 * @param {T} value
 * @returns {T}
 */
function preserve109(value) {
  return value;
}

class Store109 {
  /**
   * @param {Box109<Model109>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project109} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model109} */
const model109 = {
  id: 109, name: "model-109", meta: { active: false, label: "meta-109" },
};
const preserved109 = preserve109(model109);
/** @type {Box109<Model109>} */
const box109 = { value: preserved109, label: "box-109" };
/** @type {Project109} */
const project109 = (input) => `${input.meta.label}:${input.name}`;
const store109 = new Store109(box109);
const rendered109 = store109.read(project109);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult109 = {
  id: preserved109.id,
  name: preserved109.name,
  active: preserved109.meta.active,
  rendered: rendered109,
};

/**
 * @typedef {object} Model110
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box110
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project110
 * @param {Model110} input
 * @returns {string}
 */

/**
 * @template {Model110} T
 * @param {T} value
 * @returns {T}
 */
function preserve110(value) {
  return value;
}

class Store110 {
  /**
   * @param {Box110<Model110>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project110} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model110} */
const model110 = {
  id: 110, name: "model-110", meta: { active: true, label: "meta-110" },
};
const preserved110 = preserve110(model110);
/** @type {Box110<Model110>} */
const box110 = { value: preserved110, label: "box-110" };
/** @type {Project110} */
const project110 = (input) => `${input.meta.label}:${input.name}`;
const store110 = new Store110(box110);
const rendered110 = store110.read(project110);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult110 = {
  id: preserved110.id,
  name: preserved110.name,
  active: preserved110.meta.active,
  rendered: rendered110,
};

/**
 * @typedef {object} Model111
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box111
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project111
 * @param {Model111} input
 * @returns {string}
 */

/**
 * @template {Model111} T
 * @param {T} value
 * @returns {T}
 */
function preserve111(value) {
  return value;
}

class Store111 {
  /**
   * @param {Box111<Model111>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project111} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model111} */
const model111 = {
  id: 111, name: "model-111", meta: { active: false, label: "meta-111" },
};
const preserved111 = preserve111(model111);
/** @type {Box111<Model111>} */
const box111 = { value: preserved111, label: "box-111" };
/** @type {Project111} */
const project111 = (input) => `${input.meta.label}:${input.name}`;
const store111 = new Store111(box111);
const rendered111 = store111.read(project111);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult111 = {
  id: preserved111.id,
  name: preserved111.name,
  active: preserved111.meta.active,
  rendered: rendered111,
};

/**
 * @typedef {object} Model112
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box112
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project112
 * @param {Model112} input
 * @returns {string}
 */

/**
 * @template {Model112} T
 * @param {T} value
 * @returns {T}
 */
function preserve112(value) {
  return value;
}

class Store112 {
  /**
   * @param {Box112<Model112>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project112} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model112} */
const model112 = {
  id: 112, name: "model-112", meta: { active: true, label: "meta-112" },
};
const preserved112 = preserve112(model112);
/** @type {Box112<Model112>} */
const box112 = { value: preserved112, label: "box-112" };
/** @type {Project112} */
const project112 = (input) => `${input.meta.label}:${input.name}`;
const store112 = new Store112(box112);
const rendered112 = store112.read(project112);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult112 = {
  id: preserved112.id,
  name: preserved112.name,
  active: preserved112.meta.active,
  rendered: rendered112,
};

/**
 * @typedef {object} Model113
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box113
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project113
 * @param {Model113} input
 * @returns {string}
 */

/**
 * @template {Model113} T
 * @param {T} value
 * @returns {T}
 */
function preserve113(value) {
  return value;
}

class Store113 {
  /**
   * @param {Box113<Model113>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project113} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model113} */
const model113 = {
  id: 113, name: "model-113", meta: { active: false, label: "meta-113" },
};
const preserved113 = preserve113(model113);
/** @type {Box113<Model113>} */
const box113 = { value: preserved113, label: "box-113" };
/** @type {Project113} */
const project113 = (input) => `${input.meta.label}:${input.name}`;
const store113 = new Store113(box113);
const rendered113 = store113.read(project113);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult113 = {
  id: preserved113.id,
  name: preserved113.name,
  active: preserved113.meta.active,
  rendered: rendered113,
};

/**
 * @typedef {object} Model114
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box114
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project114
 * @param {Model114} input
 * @returns {string}
 */

/**
 * @template {Model114} T
 * @param {T} value
 * @returns {T}
 */
function preserve114(value) {
  return value;
}

class Store114 {
  /**
   * @param {Box114<Model114>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project114} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model114} */
const model114 = {
  id: 114, name: "model-114", meta: { active: true, label: "meta-114" },
};
const preserved114 = preserve114(model114);
/** @type {Box114<Model114>} */
const box114 = { value: preserved114, label: "box-114" };
/** @type {Project114} */
const project114 = (input) => `${input.meta.label}:${input.name}`;
const store114 = new Store114(box114);
const rendered114 = store114.read(project114);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult114 = {
  id: preserved114.id,
  name: preserved114.name,
  active: preserved114.meta.active,
  rendered: rendered114,
};

/**
 * @typedef {object} Model115
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box115
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project115
 * @param {Model115} input
 * @returns {string}
 */

/**
 * @template {Model115} T
 * @param {T} value
 * @returns {T}
 */
function preserve115(value) {
  return value;
}

class Store115 {
  /**
   * @param {Box115<Model115>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project115} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model115} */
const model115 = {
  id: 115, name: "model-115", meta: { active: false, label: "meta-115" },
};
const preserved115 = preserve115(model115);
/** @type {Box115<Model115>} */
const box115 = { value: preserved115, label: "box-115" };
/** @type {Project115} */
const project115 = (input) => `${input.meta.label}:${input.name}`;
const store115 = new Store115(box115);
const rendered115 = store115.read(project115);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult115 = {
  id: preserved115.id,
  name: preserved115.name,
  active: preserved115.meta.active,
  rendered: rendered115,
};

/**
 * @typedef {object} Model116
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box116
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project116
 * @param {Model116} input
 * @returns {string}
 */

/**
 * @template {Model116} T
 * @param {T} value
 * @returns {T}
 */
function preserve116(value) {
  return value;
}

class Store116 {
  /**
   * @param {Box116<Model116>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project116} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model116} */
const model116 = {
  id: 116, name: "model-116", meta: { active: true, label: "meta-116" },
};
const preserved116 = preserve116(model116);
/** @type {Box116<Model116>} */
const box116 = { value: preserved116, label: "box-116" };
/** @type {Project116} */
const project116 = (input) => `${input.meta.label}:${input.name}`;
const store116 = new Store116(box116);
const rendered116 = store116.read(project116);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult116 = {
  id: preserved116.id,
  name: preserved116.name,
  active: preserved116.meta.active,
  rendered: rendered116,
};

/**
 * @typedef {object} Model117
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box117
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project117
 * @param {Model117} input
 * @returns {string}
 */

/**
 * @template {Model117} T
 * @param {T} value
 * @returns {T}
 */
function preserve117(value) {
  return value;
}

class Store117 {
  /**
   * @param {Box117<Model117>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project117} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model117} */
const model117 = {
  id: 117, name: "model-117", meta: { active: false, label: "meta-117" },
};
const preserved117 = preserve117(model117);
/** @type {Box117<Model117>} */
const box117 = { value: preserved117, label: "box-117" };
/** @type {Project117} */
const project117 = (input) => `${input.meta.label}:${input.name}`;
const store117 = new Store117(box117);
const rendered117 = store117.read(project117);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult117 = {
  id: preserved117.id,
  name: preserved117.name,
  active: preserved117.meta.active,
  rendered: rendered117,
};

/**
 * @typedef {object} Model118
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box118
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project118
 * @param {Model118} input
 * @returns {string}
 */

/**
 * @template {Model118} T
 * @param {T} value
 * @returns {T}
 */
function preserve118(value) {
  return value;
}

class Store118 {
  /**
   * @param {Box118<Model118>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project118} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model118} */
const model118 = {
  id: 118, name: "model-118", meta: { active: true, label: "meta-118" },
};
const preserved118 = preserve118(model118);
/** @type {Box118<Model118>} */
const box118 = { value: preserved118, label: "box-118" };
/** @type {Project118} */
const project118 = (input) => `${input.meta.label}:${input.name}`;
const store118 = new Store118(box118);
const rendered118 = store118.read(project118);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult118 = {
  id: preserved118.id,
  name: preserved118.name,
  active: preserved118.meta.active,
  rendered: rendered118,
};

/**
 * @typedef {object} Model119
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box119
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project119
 * @param {Model119} input
 * @returns {string}
 */

/**
 * @template {Model119} T
 * @param {T} value
 * @returns {T}
 */
function preserve119(value) {
  return value;
}

class Store119 {
  /**
   * @param {Box119<Model119>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project119} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model119} */
const model119 = {
  id: 119, name: "model-119", meta: { active: false, label: "meta-119" },
};
const preserved119 = preserve119(model119);
/** @type {Box119<Model119>} */
const box119 = { value: preserved119, label: "box-119" };
/** @type {Project119} */
const project119 = (input) => `${input.meta.label}:${input.name}`;
const store119 = new Store119(box119);
const rendered119 = store119.read(project119);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult119 = {
  id: preserved119.id,
  name: preserved119.name,
  active: preserved119.meta.active,
  rendered: rendered119,
};

/**
 * @typedef {object} Model120
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box120
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project120
 * @param {Model120} input
 * @returns {string}
 */

/**
 * @template {Model120} T
 * @param {T} value
 * @returns {T}
 */
function preserve120(value) {
  return value;
}

class Store120 {
  /**
   * @param {Box120<Model120>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project120} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model120} */
const model120 = {
  id: 120, name: "model-120", meta: { active: true, label: "meta-120" },
};
const preserved120 = preserve120(model120);
/** @type {Box120<Model120>} */
const box120 = { value: preserved120, label: "box-120" };
/** @type {Project120} */
const project120 = (input) => `${input.meta.label}:${input.name}`;
const store120 = new Store120(box120);
const rendered120 = store120.read(project120);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult120 = {
  id: preserved120.id,
  name: preserved120.name,
  active: preserved120.meta.active,
  rendered: rendered120,
};

/**
 * @typedef {object} Model121
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box121
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project121
 * @param {Model121} input
 * @returns {string}
 */

/**
 * @template {Model121} T
 * @param {T} value
 * @returns {T}
 */
function preserve121(value) {
  return value;
}

class Store121 {
  /**
   * @param {Box121<Model121>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project121} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model121} */
const model121 = {
  id: 121, name: "model-121", meta: { active: false, label: "meta-121" },
};
const preserved121 = preserve121(model121);
/** @type {Box121<Model121>} */
const box121 = { value: preserved121, label: "box-121" };
/** @type {Project121} */
const project121 = (input) => `${input.meta.label}:${input.name}`;
const store121 = new Store121(box121);
const rendered121 = store121.read(project121);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult121 = {
  id: preserved121.id,
  name: preserved121.name,
  active: preserved121.meta.active,
  rendered: rendered121,
};

/**
 * @typedef {object} Model122
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box122
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project122
 * @param {Model122} input
 * @returns {string}
 */

/**
 * @template {Model122} T
 * @param {T} value
 * @returns {T}
 */
function preserve122(value) {
  return value;
}

class Store122 {
  /**
   * @param {Box122<Model122>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project122} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model122} */
const model122 = {
  id: 122, name: "model-122", meta: { active: true, label: "meta-122" },
};
const preserved122 = preserve122(model122);
/** @type {Box122<Model122>} */
const box122 = { value: preserved122, label: "box-122" };
/** @type {Project122} */
const project122 = (input) => `${input.meta.label}:${input.name}`;
const store122 = new Store122(box122);
const rendered122 = store122.read(project122);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult122 = {
  id: preserved122.id,
  name: preserved122.name,
  active: preserved122.meta.active,
  rendered: rendered122,
};

/**
 * @typedef {object} Model123
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box123
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project123
 * @param {Model123} input
 * @returns {string}
 */

/**
 * @template {Model123} T
 * @param {T} value
 * @returns {T}
 */
function preserve123(value) {
  return value;
}

class Store123 {
  /**
   * @param {Box123<Model123>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project123} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model123} */
const model123 = {
  id: 123, name: "model-123", meta: { active: false, label: "meta-123" },
};
const preserved123 = preserve123(model123);
/** @type {Box123<Model123>} */
const box123 = { value: preserved123, label: "box-123" };
/** @type {Project123} */
const project123 = (input) => `${input.meta.label}:${input.name}`;
const store123 = new Store123(box123);
const rendered123 = store123.read(project123);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult123 = {
  id: preserved123.id,
  name: preserved123.name,
  active: preserved123.meta.active,
  rendered: rendered123,
};

/**
 * @typedef {object} Model124
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box124
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project124
 * @param {Model124} input
 * @returns {string}
 */

/**
 * @template {Model124} T
 * @param {T} value
 * @returns {T}
 */
function preserve124(value) {
  return value;
}

class Store124 {
  /**
   * @param {Box124<Model124>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project124} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model124} */
const model124 = {
  id: 124, name: "model-124", meta: { active: true, label: "meta-124" },
};
const preserved124 = preserve124(model124);
/** @type {Box124<Model124>} */
const box124 = { value: preserved124, label: "box-124" };
/** @type {Project124} */
const project124 = (input) => `${input.meta.label}:${input.name}`;
const store124 = new Store124(box124);
const rendered124 = store124.read(project124);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult124 = {
  id: preserved124.id,
  name: preserved124.name,
  active: preserved124.meta.active,
  rendered: rendered124,
};

/**
 * @typedef {object} Model125
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box125
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project125
 * @param {Model125} input
 * @returns {string}
 */

/**
 * @template {Model125} T
 * @param {T} value
 * @returns {T}
 */
function preserve125(value) {
  return value;
}

class Store125 {
  /**
   * @param {Box125<Model125>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project125} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model125} */
const model125 = {
  id: 125, name: "model-125", meta: { active: false, label: "meta-125" },
};
const preserved125 = preserve125(model125);
/** @type {Box125<Model125>} */
const box125 = { value: preserved125, label: "box-125" };
/** @type {Project125} */
const project125 = (input) => `${input.meta.label}:${input.name}`;
const store125 = new Store125(box125);
const rendered125 = store125.read(project125);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult125 = {
  id: preserved125.id,
  name: preserved125.name,
  active: preserved125.meta.active,
  rendered: rendered125,
};

/**
 * @typedef {object} Model126
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box126
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project126
 * @param {Model126} input
 * @returns {string}
 */

/**
 * @template {Model126} T
 * @param {T} value
 * @returns {T}
 */
function preserve126(value) {
  return value;
}

class Store126 {
  /**
   * @param {Box126<Model126>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project126} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model126} */
const model126 = {
  id: 126, name: "model-126", meta: { active: true, label: "meta-126" },
};
const preserved126 = preserve126(model126);
/** @type {Box126<Model126>} */
const box126 = { value: preserved126, label: "box-126" };
/** @type {Project126} */
const project126 = (input) => `${input.meta.label}:${input.name}`;
const store126 = new Store126(box126);
const rendered126 = store126.read(project126);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult126 = {
  id: preserved126.id,
  name: preserved126.name,
  active: preserved126.meta.active,
  rendered: rendered126,
};

/**
 * @typedef {object} Model127
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box127
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project127
 * @param {Model127} input
 * @returns {string}
 */

/**
 * @template {Model127} T
 * @param {T} value
 * @returns {T}
 */
function preserve127(value) {
  return value;
}

class Store127 {
  /**
   * @param {Box127<Model127>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project127} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model127} */
const model127 = {
  id: 127, name: "model-127", meta: { active: false, label: "meta-127" },
};
const preserved127 = preserve127(model127);
/** @type {Box127<Model127>} */
const box127 = { value: preserved127, label: "box-127" };
/** @type {Project127} */
const project127 = (input) => `${input.meta.label}:${input.name}`;
const store127 = new Store127(box127);
const rendered127 = store127.read(project127);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult127 = {
  id: preserved127.id,
  name: preserved127.name,
  active: preserved127.meta.active,
  rendered: rendered127,
};

/**
 * @typedef {object} Model128
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box128
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project128
 * @param {Model128} input
 * @returns {string}
 */

/**
 * @template {Model128} T
 * @param {T} value
 * @returns {T}
 */
function preserve128(value) {
  return value;
}

class Store128 {
  /**
   * @param {Box128<Model128>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project128} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model128} */
const model128 = {
  id: 128, name: "model-128", meta: { active: true, label: "meta-128" },
};
const preserved128 = preserve128(model128);
/** @type {Box128<Model128>} */
const box128 = { value: preserved128, label: "box-128" };
/** @type {Project128} */
const project128 = (input) => `${input.meta.label}:${input.name}`;
const store128 = new Store128(box128);
const rendered128 = store128.read(project128);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult128 = {
  id: preserved128.id,
  name: preserved128.name,
  active: preserved128.meta.active,
  rendered: rendered128,
};

/**
 * @typedef {object} Model129
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box129
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project129
 * @param {Model129} input
 * @returns {string}
 */

/**
 * @template {Model129} T
 * @param {T} value
 * @returns {T}
 */
function preserve129(value) {
  return value;
}

class Store129 {
  /**
   * @param {Box129<Model129>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project129} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model129} */
const model129 = {
  id: 129, name: "model-129", meta: { active: false, label: "meta-129" },
};
const preserved129 = preserve129(model129);
/** @type {Box129<Model129>} */
const box129 = { value: preserved129, label: "box-129" };
/** @type {Project129} */
const project129 = (input) => `${input.meta.label}:${input.name}`;
const store129 = new Store129(box129);
const rendered129 = store129.read(project129);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult129 = {
  id: preserved129.id,
  name: preserved129.name,
  active: preserved129.meta.active,
  rendered: rendered129,
};

/**
 * @typedef {object} Model130
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box130
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project130
 * @param {Model130} input
 * @returns {string}
 */

/**
 * @template {Model130} T
 * @param {T} value
 * @returns {T}
 */
function preserve130(value) {
  return value;
}

class Store130 {
  /**
   * @param {Box130<Model130>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project130} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model130} */
const model130 = {
  id: 130, name: "model-130", meta: { active: true, label: "meta-130" },
};
const preserved130 = preserve130(model130);
/** @type {Box130<Model130>} */
const box130 = { value: preserved130, label: "box-130" };
/** @type {Project130} */
const project130 = (input) => `${input.meta.label}:${input.name}`;
const store130 = new Store130(box130);
const rendered130 = store130.read(project130);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult130 = {
  id: preserved130.id,
  name: preserved130.name,
  active: preserved130.meta.active,
  rendered: rendered130,
};

/**
 * @typedef {object} Model131
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box131
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project131
 * @param {Model131} input
 * @returns {string}
 */

/**
 * @template {Model131} T
 * @param {T} value
 * @returns {T}
 */
function preserve131(value) {
  return value;
}

class Store131 {
  /**
   * @param {Box131<Model131>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project131} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model131} */
const model131 = {
  id: 131, name: "model-131", meta: { active: false, label: "meta-131" },
};
const preserved131 = preserve131(model131);
/** @type {Box131<Model131>} */
const box131 = { value: preserved131, label: "box-131" };
/** @type {Project131} */
const project131 = (input) => `${input.meta.label}:${input.name}`;
const store131 = new Store131(box131);
const rendered131 = store131.read(project131);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult131 = {
  id: preserved131.id,
  name: preserved131.name,
  active: preserved131.meta.active,
  rendered: rendered131,
};

/**
 * @typedef {object} Model132
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box132
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project132
 * @param {Model132} input
 * @returns {string}
 */

/**
 * @template {Model132} T
 * @param {T} value
 * @returns {T}
 */
function preserve132(value) {
  return value;
}

class Store132 {
  /**
   * @param {Box132<Model132>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project132} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model132} */
const model132 = {
  id: 132, name: "model-132", meta: { active: true, label: "meta-132" },
};
const preserved132 = preserve132(model132);
/** @type {Box132<Model132>} */
const box132 = { value: preserved132, label: "box-132" };
/** @type {Project132} */
const project132 = (input) => `${input.meta.label}:${input.name}`;
const store132 = new Store132(box132);
const rendered132 = store132.read(project132);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult132 = {
  id: preserved132.id,
  name: preserved132.name,
  active: preserved132.meta.active,
  rendered: rendered132,
};

/**
 * @typedef {object} Model133
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box133
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project133
 * @param {Model133} input
 * @returns {string}
 */

/**
 * @template {Model133} T
 * @param {T} value
 * @returns {T}
 */
function preserve133(value) {
  return value;
}

class Store133 {
  /**
   * @param {Box133<Model133>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project133} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model133} */
const model133 = {
  id: 133, name: "model-133", meta: { active: false, label: "meta-133" },
};
const preserved133 = preserve133(model133);
/** @type {Box133<Model133>} */
const box133 = { value: preserved133, label: "box-133" };
/** @type {Project133} */
const project133 = (input) => `${input.meta.label}:${input.name}`;
const store133 = new Store133(box133);
const rendered133 = store133.read(project133);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult133 = {
  id: preserved133.id,
  name: preserved133.name,
  active: preserved133.meta.active,
  rendered: rendered133,
};

/**
 * @typedef {object} Model134
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box134
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project134
 * @param {Model134} input
 * @returns {string}
 */

/**
 * @template {Model134} T
 * @param {T} value
 * @returns {T}
 */
function preserve134(value) {
  return value;
}

class Store134 {
  /**
   * @param {Box134<Model134>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project134} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model134} */
const model134 = {
  id: 134, name: "model-134", meta: { active: true, label: "meta-134" },
};
const preserved134 = preserve134(model134);
/** @type {Box134<Model134>} */
const box134 = { value: preserved134, label: "box-134" };
/** @type {Project134} */
const project134 = (input) => `${input.meta.label}:${input.name}`;
const store134 = new Store134(box134);
const rendered134 = store134.read(project134);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult134 = {
  id: preserved134.id,
  name: preserved134.name,
  active: preserved134.meta.active,
  rendered: rendered134,
};

/**
 * @typedef {object} Model135
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box135
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project135
 * @param {Model135} input
 * @returns {string}
 */

/**
 * @template {Model135} T
 * @param {T} value
 * @returns {T}
 */
function preserve135(value) {
  return value;
}

class Store135 {
  /**
   * @param {Box135<Model135>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project135} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model135} */
const model135 = {
  id: 135, name: "model-135", meta: { active: false, label: "meta-135" },
};
const preserved135 = preserve135(model135);
/** @type {Box135<Model135>} */
const box135 = { value: preserved135, label: "box-135" };
/** @type {Project135} */
const project135 = (input) => `${input.meta.label}:${input.name}`;
const store135 = new Store135(box135);
const rendered135 = store135.read(project135);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult135 = {
  id: preserved135.id,
  name: preserved135.name,
  active: preserved135.meta.active,
  rendered: rendered135,
};

/**
 * @typedef {object} Model136
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box136
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project136
 * @param {Model136} input
 * @returns {string}
 */

/**
 * @template {Model136} T
 * @param {T} value
 * @returns {T}
 */
function preserve136(value) {
  return value;
}

class Store136 {
  /**
   * @param {Box136<Model136>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project136} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model136} */
const model136 = {
  id: 136, name: "model-136", meta: { active: true, label: "meta-136" },
};
const preserved136 = preserve136(model136);
/** @type {Box136<Model136>} */
const box136 = { value: preserved136, label: "box-136" };
/** @type {Project136} */
const project136 = (input) => `${input.meta.label}:${input.name}`;
const store136 = new Store136(box136);
const rendered136 = store136.read(project136);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult136 = {
  id: preserved136.id,
  name: preserved136.name,
  active: preserved136.meta.active,
  rendered: rendered136,
};

/**
 * @typedef {object} Model137
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box137
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project137
 * @param {Model137} input
 * @returns {string}
 */

/**
 * @template {Model137} T
 * @param {T} value
 * @returns {T}
 */
function preserve137(value) {
  return value;
}

class Store137 {
  /**
   * @param {Box137<Model137>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project137} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model137} */
const model137 = {
  id: 137, name: "model-137", meta: { active: false, label: "meta-137" },
};
const preserved137 = preserve137(model137);
/** @type {Box137<Model137>} */
const box137 = { value: preserved137, label: "box-137" };
/** @type {Project137} */
const project137 = (input) => `${input.meta.label}:${input.name}`;
const store137 = new Store137(box137);
const rendered137 = store137.read(project137);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult137 = {
  id: preserved137.id,
  name: preserved137.name,
  active: preserved137.meta.active,
  rendered: rendered137,
};

/**
 * @typedef {object} Model138
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box138
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project138
 * @param {Model138} input
 * @returns {string}
 */

/**
 * @template {Model138} T
 * @param {T} value
 * @returns {T}
 */
function preserve138(value) {
  return value;
}

class Store138 {
  /**
   * @param {Box138<Model138>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project138} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model138} */
const model138 = {
  id: 138, name: "model-138", meta: { active: true, label: "meta-138" },
};
const preserved138 = preserve138(model138);
/** @type {Box138<Model138>} */
const box138 = { value: preserved138, label: "box-138" };
/** @type {Project138} */
const project138 = (input) => `${input.meta.label}:${input.name}`;
const store138 = new Store138(box138);
const rendered138 = store138.read(project138);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult138 = {
  id: preserved138.id,
  name: preserved138.name,
  active: preserved138.meta.active,
  rendered: rendered138,
};

/**
 * @typedef {object} Model139
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box139
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project139
 * @param {Model139} input
 * @returns {string}
 */

/**
 * @template {Model139} T
 * @param {T} value
 * @returns {T}
 */
function preserve139(value) {
  return value;
}

class Store139 {
  /**
   * @param {Box139<Model139>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project139} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model139} */
const model139 = {
  id: 139, name: "model-139", meta: { active: false, label: "meta-139" },
};
const preserved139 = preserve139(model139);
/** @type {Box139<Model139>} */
const box139 = { value: preserved139, label: "box-139" };
/** @type {Project139} */
const project139 = (input) => `${input.meta.label}:${input.name}`;
const store139 = new Store139(box139);
const rendered139 = store139.read(project139);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult139 = {
  id: preserved139.id,
  name: preserved139.name,
  active: preserved139.meta.active,
  rendered: rendered139,
};

/**
 * @typedef {object} Model140
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box140
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project140
 * @param {Model140} input
 * @returns {string}
 */

/**
 * @template {Model140} T
 * @param {T} value
 * @returns {T}
 */
function preserve140(value) {
  return value;
}

class Store140 {
  /**
   * @param {Box140<Model140>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project140} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model140} */
const model140 = {
  id: 140, name: "model-140", meta: { active: true, label: "meta-140" },
};
const preserved140 = preserve140(model140);
/** @type {Box140<Model140>} */
const box140 = { value: preserved140, label: "box-140" };
/** @type {Project140} */
const project140 = (input) => `${input.meta.label}:${input.name}`;
const store140 = new Store140(box140);
const rendered140 = store140.read(project140);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult140 = {
  id: preserved140.id,
  name: preserved140.name,
  active: preserved140.meta.active,
  rendered: rendered140,
};

/**
 * @typedef {object} Model141
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box141
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project141
 * @param {Model141} input
 * @returns {string}
 */

/**
 * @template {Model141} T
 * @param {T} value
 * @returns {T}
 */
function preserve141(value) {
  return value;
}

class Store141 {
  /**
   * @param {Box141<Model141>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project141} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model141} */
const model141 = {
  id: 141, name: "model-141", meta: { active: false, label: "meta-141" },
};
const preserved141 = preserve141(model141);
/** @type {Box141<Model141>} */
const box141 = { value: preserved141, label: "box-141" };
/** @type {Project141} */
const project141 = (input) => `${input.meta.label}:${input.name}`;
const store141 = new Store141(box141);
const rendered141 = store141.read(project141);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult141 = {
  id: preserved141.id,
  name: preserved141.name,
  active: preserved141.meta.active,
  rendered: rendered141,
};

/**
 * @typedef {object} Model142
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box142
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project142
 * @param {Model142} input
 * @returns {string}
 */

/**
 * @template {Model142} T
 * @param {T} value
 * @returns {T}
 */
function preserve142(value) {
  return value;
}

class Store142 {
  /**
   * @param {Box142<Model142>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project142} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model142} */
const model142 = {
  id: 142, name: "model-142", meta: { active: true, label: "meta-142" },
};
const preserved142 = preserve142(model142);
/** @type {Box142<Model142>} */
const box142 = { value: preserved142, label: "box-142" };
/** @type {Project142} */
const project142 = (input) => `${input.meta.label}:${input.name}`;
const store142 = new Store142(box142);
const rendered142 = store142.read(project142);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult142 = {
  id: preserved142.id,
  name: preserved142.name,
  active: preserved142.meta.active,
  rendered: rendered142,
};

/**
 * @typedef {object} Model143
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box143
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project143
 * @param {Model143} input
 * @returns {string}
 */

/**
 * @template {Model143} T
 * @param {T} value
 * @returns {T}
 */
function preserve143(value) {
  return value;
}

class Store143 {
  /**
   * @param {Box143<Model143>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project143} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model143} */
const model143 = {
  id: 143, name: "model-143", meta: { active: false, label: "meta-143" },
};
const preserved143 = preserve143(model143);
/** @type {Box143<Model143>} */
const box143 = { value: preserved143, label: "box-143" };
/** @type {Project143} */
const project143 = (input) => `${input.meta.label}:${input.name}`;
const store143 = new Store143(box143);
const rendered143 = store143.read(project143);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult143 = {
  id: preserved143.id,
  name: preserved143.name,
  active: preserved143.meta.active,
  rendered: rendered143,
};

/**
 * @typedef {object} Model144
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box144
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project144
 * @param {Model144} input
 * @returns {string}
 */

/**
 * @template {Model144} T
 * @param {T} value
 * @returns {T}
 */
function preserve144(value) {
  return value;
}

class Store144 {
  /**
   * @param {Box144<Model144>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project144} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model144} */
const model144 = {
  id: 144, name: "model-144", meta: { active: true, label: "meta-144" },
};
const preserved144 = preserve144(model144);
/** @type {Box144<Model144>} */
const box144 = { value: preserved144, label: "box-144" };
/** @type {Project144} */
const project144 = (input) => `${input.meta.label}:${input.name}`;
const store144 = new Store144(box144);
const rendered144 = store144.read(project144);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult144 = {
  id: preserved144.id,
  name: preserved144.name,
  active: preserved144.meta.active,
  rendered: rendered144,
};

/**
 * @typedef {object} Model145
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box145
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project145
 * @param {Model145} input
 * @returns {string}
 */

/**
 * @template {Model145} T
 * @param {T} value
 * @returns {T}
 */
function preserve145(value) {
  return value;
}

class Store145 {
  /**
   * @param {Box145<Model145>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project145} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model145} */
const model145 = {
  id: 145, name: "model-145", meta: { active: false, label: "meta-145" },
};
const preserved145 = preserve145(model145);
/** @type {Box145<Model145>} */
const box145 = { value: preserved145, label: "box-145" };
/** @type {Project145} */
const project145 = (input) => `${input.meta.label}:${input.name}`;
const store145 = new Store145(box145);
const rendered145 = store145.read(project145);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult145 = {
  id: preserved145.id,
  name: preserved145.name,
  active: preserved145.meta.active,
  rendered: rendered145,
};

/**
 * @typedef {object} Model146
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box146
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project146
 * @param {Model146} input
 * @returns {string}
 */

/**
 * @template {Model146} T
 * @param {T} value
 * @returns {T}
 */
function preserve146(value) {
  return value;
}

class Store146 {
  /**
   * @param {Box146<Model146>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project146} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model146} */
const model146 = {
  id: 146, name: "model-146", meta: { active: true, label: "meta-146" },
};
const preserved146 = preserve146(model146);
/** @type {Box146<Model146>} */
const box146 = { value: preserved146, label: "box-146" };
/** @type {Project146} */
const project146 = (input) => `${input.meta.label}:${input.name}`;
const store146 = new Store146(box146);
const rendered146 = store146.read(project146);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult146 = {
  id: preserved146.id,
  name: preserved146.name,
  active: preserved146.meta.active,
  rendered: rendered146,
};

/**
 * @typedef {object} Model147
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box147
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project147
 * @param {Model147} input
 * @returns {string}
 */

/**
 * @template {Model147} T
 * @param {T} value
 * @returns {T}
 */
function preserve147(value) {
  return value;
}

class Store147 {
  /**
   * @param {Box147<Model147>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project147} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model147} */
const model147 = {
  id: 147, name: "model-147", meta: { active: false, label: "meta-147" },
};
const preserved147 = preserve147(model147);
/** @type {Box147<Model147>} */
const box147 = { value: preserved147, label: "box-147" };
/** @type {Project147} */
const project147 = (input) => `${input.meta.label}:${input.name}`;
const store147 = new Store147(box147);
const rendered147 = store147.read(project147);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult147 = {
  id: preserved147.id,
  name: preserved147.name,
  active: preserved147.meta.active,
  rendered: rendered147,
};

/**
 * @typedef {object} Model148
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box148
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project148
 * @param {Model148} input
 * @returns {string}
 */

/**
 * @template {Model148} T
 * @param {T} value
 * @returns {T}
 */
function preserve148(value) {
  return value;
}

class Store148 {
  /**
   * @param {Box148<Model148>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project148} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model148} */
const model148 = {
  id: 148, name: "model-148", meta: { active: true, label: "meta-148" },
};
const preserved148 = preserve148(model148);
/** @type {Box148<Model148>} */
const box148 = { value: preserved148, label: "box-148" };
/** @type {Project148} */
const project148 = (input) => `${input.meta.label}:${input.name}`;
const store148 = new Store148(box148);
const rendered148 = store148.read(project148);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult148 = {
  id: preserved148.id,
  name: preserved148.name,
  active: preserved148.meta.active,
  rendered: rendered148,
};

/**
 * @typedef {object} Model149
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box149
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project149
 * @param {Model149} input
 * @returns {string}
 */

/**
 * @template {Model149} T
 * @param {T} value
 * @returns {T}
 */
function preserve149(value) {
  return value;
}

class Store149 {
  /**
   * @param {Box149<Model149>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project149} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model149} */
const model149 = {
  id: 149, name: "model-149", meta: { active: false, label: "meta-149" },
};
const preserved149 = preserve149(model149);
/** @type {Box149<Model149>} */
const box149 = { value: preserved149, label: "box-149" };
/** @type {Project149} */
const project149 = (input) => `${input.meta.label}:${input.name}`;
const store149 = new Store149(box149);
const rendered149 = store149.read(project149);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult149 = {
  id: preserved149.id,
  name: preserved149.name,
  active: preserved149.meta.active,
  rendered: rendered149,
};

/**
 * @typedef {object} Model150
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box150
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project150
 * @param {Model150} input
 * @returns {string}
 */

/**
 * @template {Model150} T
 * @param {T} value
 * @returns {T}
 */
function preserve150(value) {
  return value;
}

class Store150 {
  /**
   * @param {Box150<Model150>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project150} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model150} */
const model150 = {
  id: 150, name: "model-150", meta: { active: true, label: "meta-150" },
};
const preserved150 = preserve150(model150);
/** @type {Box150<Model150>} */
const box150 = { value: preserved150, label: "box-150" };
/** @type {Project150} */
const project150 = (input) => `${input.meta.label}:${input.name}`;
const store150 = new Store150(box150);
const rendered150 = store150.read(project150);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult150 = {
  id: preserved150.id,
  name: preserved150.name,
  active: preserved150.meta.active,
  rendered: rendered150,
};

/**
 * @typedef {object} Model151
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box151
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project151
 * @param {Model151} input
 * @returns {string}
 */

/**
 * @template {Model151} T
 * @param {T} value
 * @returns {T}
 */
function preserve151(value) {
  return value;
}

class Store151 {
  /**
   * @param {Box151<Model151>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project151} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model151} */
const model151 = {
  id: 151, name: "model-151", meta: { active: false, label: "meta-151" },
};
const preserved151 = preserve151(model151);
/** @type {Box151<Model151>} */
const box151 = { value: preserved151, label: "box-151" };
/** @type {Project151} */
const project151 = (input) => `${input.meta.label}:${input.name}`;
const store151 = new Store151(box151);
const rendered151 = store151.read(project151);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult151 = {
  id: preserved151.id,
  name: preserved151.name,
  active: preserved151.meta.active,
  rendered: rendered151,
};

/**
 * @typedef {object} Model152
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box152
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project152
 * @param {Model152} input
 * @returns {string}
 */

/**
 * @template {Model152} T
 * @param {T} value
 * @returns {T}
 */
function preserve152(value) {
  return value;
}

class Store152 {
  /**
   * @param {Box152<Model152>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project152} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model152} */
const model152 = {
  id: 152, name: "model-152", meta: { active: true, label: "meta-152" },
};
const preserved152 = preserve152(model152);
/** @type {Box152<Model152>} */
const box152 = { value: preserved152, label: "box-152" };
/** @type {Project152} */
const project152 = (input) => `${input.meta.label}:${input.name}`;
const store152 = new Store152(box152);
const rendered152 = store152.read(project152);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult152 = {
  id: preserved152.id,
  name: preserved152.name,
  active: preserved152.meta.active,
  rendered: rendered152,
};

/**
 * @typedef {object} Model153
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box153
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project153
 * @param {Model153} input
 * @returns {string}
 */

/**
 * @template {Model153} T
 * @param {T} value
 * @returns {T}
 */
function preserve153(value) {
  return value;
}

class Store153 {
  /**
   * @param {Box153<Model153>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project153} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model153} */
const model153 = {
  id: 153, name: "model-153", meta: { active: false, label: "meta-153" },
};
const preserved153 = preserve153(model153);
/** @type {Box153<Model153>} */
const box153 = { value: preserved153, label: "box-153" };
/** @type {Project153} */
const project153 = (input) => `${input.meta.label}:${input.name}`;
const store153 = new Store153(box153);
const rendered153 = store153.read(project153);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult153 = {
  id: preserved153.id,
  name: preserved153.name,
  active: preserved153.meta.active,
  rendered: rendered153,
};

/**
 * @typedef {object} Model154
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box154
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project154
 * @param {Model154} input
 * @returns {string}
 */

/**
 * @template {Model154} T
 * @param {T} value
 * @returns {T}
 */
function preserve154(value) {
  return value;
}

class Store154 {
  /**
   * @param {Box154<Model154>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project154} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model154} */
const model154 = {
  id: 154, name: "model-154", meta: { active: true, label: "meta-154" },
};
const preserved154 = preserve154(model154);
/** @type {Box154<Model154>} */
const box154 = { value: preserved154, label: "box-154" };
/** @type {Project154} */
const project154 = (input) => `${input.meta.label}:${input.name}`;
const store154 = new Store154(box154);
const rendered154 = store154.read(project154);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult154 = {
  id: preserved154.id,
  name: preserved154.name,
  active: preserved154.meta.active,
  rendered: rendered154,
};

/**
 * @typedef {object} Model155
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box155
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project155
 * @param {Model155} input
 * @returns {string}
 */

/**
 * @template {Model155} T
 * @param {T} value
 * @returns {T}
 */
function preserve155(value) {
  return value;
}

class Store155 {
  /**
   * @param {Box155<Model155>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project155} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model155} */
const model155 = {
  id: 155, name: "model-155", meta: { active: false, label: "meta-155" },
};
const preserved155 = preserve155(model155);
/** @type {Box155<Model155>} */
const box155 = { value: preserved155, label: "box-155" };
/** @type {Project155} */
const project155 = (input) => `${input.meta.label}:${input.name}`;
const store155 = new Store155(box155);
const rendered155 = store155.read(project155);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult155 = {
  id: preserved155.id,
  name: preserved155.name,
  active: preserved155.meta.active,
  rendered: rendered155,
};

/**
 * @typedef {object} Model156
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box156
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project156
 * @param {Model156} input
 * @returns {string}
 */

/**
 * @template {Model156} T
 * @param {T} value
 * @returns {T}
 */
function preserve156(value) {
  return value;
}

class Store156 {
  /**
   * @param {Box156<Model156>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project156} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model156} */
const model156 = {
  id: 156, name: "model-156", meta: { active: true, label: "meta-156" },
};
const preserved156 = preserve156(model156);
/** @type {Box156<Model156>} */
const box156 = { value: preserved156, label: "box-156" };
/** @type {Project156} */
const project156 = (input) => `${input.meta.label}:${input.name}`;
const store156 = new Store156(box156);
const rendered156 = store156.read(project156);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult156 = {
  id: preserved156.id,
  name: preserved156.name,
  active: preserved156.meta.active,
  rendered: rendered156,
};

/**
 * @typedef {object} Model157
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box157
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project157
 * @param {Model157} input
 * @returns {string}
 */

/**
 * @template {Model157} T
 * @param {T} value
 * @returns {T}
 */
function preserve157(value) {
  return value;
}

class Store157 {
  /**
   * @param {Box157<Model157>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project157} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model157} */
const model157 = {
  id: 157, name: "model-157", meta: { active: false, label: "meta-157" },
};
const preserved157 = preserve157(model157);
/** @type {Box157<Model157>} */
const box157 = { value: preserved157, label: "box-157" };
/** @type {Project157} */
const project157 = (input) => `${input.meta.label}:${input.name}`;
const store157 = new Store157(box157);
const rendered157 = store157.read(project157);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult157 = {
  id: preserved157.id,
  name: preserved157.name,
  active: preserved157.meta.active,
  rendered: rendered157,
};

/**
 * @typedef {object} Model158
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box158
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project158
 * @param {Model158} input
 * @returns {string}
 */

/**
 * @template {Model158} T
 * @param {T} value
 * @returns {T}
 */
function preserve158(value) {
  return value;
}

class Store158 {
  /**
   * @param {Box158<Model158>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project158} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model158} */
const model158 = {
  id: 158, name: "model-158", meta: { active: true, label: "meta-158" },
};
const preserved158 = preserve158(model158);
/** @type {Box158<Model158>} */
const box158 = { value: preserved158, label: "box-158" };
/** @type {Project158} */
const project158 = (input) => `${input.meta.label}:${input.name}`;
const store158 = new Store158(box158);
const rendered158 = store158.read(project158);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult158 = {
  id: preserved158.id,
  name: preserved158.name,
  active: preserved158.meta.active,
  rendered: rendered158,
};

/**
 * @typedef {object} Model159
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box159
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project159
 * @param {Model159} input
 * @returns {string}
 */

/**
 * @template {Model159} T
 * @param {T} value
 * @returns {T}
 */
function preserve159(value) {
  return value;
}

class Store159 {
  /**
   * @param {Box159<Model159>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project159} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model159} */
const model159 = {
  id: 159, name: "model-159", meta: { active: false, label: "meta-159" },
};
const preserved159 = preserve159(model159);
/** @type {Box159<Model159>} */
const box159 = { value: preserved159, label: "box-159" };
/** @type {Project159} */
const project159 = (input) => `${input.meta.label}:${input.name}`;
const store159 = new Store159(box159);
const rendered159 = store159.read(project159);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult159 = {
  id: preserved159.id,
  name: preserved159.name,
  active: preserved159.meta.active,
  rendered: rendered159,
};

/**
 * @typedef {object} Model160
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box160
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project160
 * @param {Model160} input
 * @returns {string}
 */

/**
 * @template {Model160} T
 * @param {T} value
 * @returns {T}
 */
function preserve160(value) {
  return value;
}

class Store160 {
  /**
   * @param {Box160<Model160>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project160} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model160} */
const model160 = {
  id: 160, name: "model-160", meta: { active: true, label: "meta-160" },
};
const preserved160 = preserve160(model160);
/** @type {Box160<Model160>} */
const box160 = { value: preserved160, label: "box-160" };
/** @type {Project160} */
const project160 = (input) => `${input.meta.label}:${input.name}`;
const store160 = new Store160(box160);
const rendered160 = store160.read(project160);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult160 = {
  id: preserved160.id,
  name: preserved160.name,
  active: preserved160.meta.active,
  rendered: rendered160,
};

/**
 * @typedef {object} Model161
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box161
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project161
 * @param {Model161} input
 * @returns {string}
 */

/**
 * @template {Model161} T
 * @param {T} value
 * @returns {T}
 */
function preserve161(value) {
  return value;
}

class Store161 {
  /**
   * @param {Box161<Model161>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project161} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model161} */
const model161 = {
  id: 161, name: "model-161", meta: { active: false, label: "meta-161" },
};
const preserved161 = preserve161(model161);
/** @type {Box161<Model161>} */
const box161 = { value: preserved161, label: "box-161" };
/** @type {Project161} */
const project161 = (input) => `${input.meta.label}:${input.name}`;
const store161 = new Store161(box161);
const rendered161 = store161.read(project161);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult161 = {
  id: preserved161.id,
  name: preserved161.name,
  active: preserved161.meta.active,
  rendered: rendered161,
};

/**
 * @typedef {object} Model162
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box162
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project162
 * @param {Model162} input
 * @returns {string}
 */

/**
 * @template {Model162} T
 * @param {T} value
 * @returns {T}
 */
function preserve162(value) {
  return value;
}

class Store162 {
  /**
   * @param {Box162<Model162>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project162} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model162} */
const model162 = {
  id: 162, name: "model-162", meta: { active: true, label: "meta-162" },
};
const preserved162 = preserve162(model162);
/** @type {Box162<Model162>} */
const box162 = { value: preserved162, label: "box-162" };
/** @type {Project162} */
const project162 = (input) => `${input.meta.label}:${input.name}`;
const store162 = new Store162(box162);
const rendered162 = store162.read(project162);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult162 = {
  id: preserved162.id,
  name: preserved162.name,
  active: preserved162.meta.active,
  rendered: rendered162,
};

/**
 * @typedef {object} Model163
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box163
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project163
 * @param {Model163} input
 * @returns {string}
 */

/**
 * @template {Model163} T
 * @param {T} value
 * @returns {T}
 */
function preserve163(value) {
  return value;
}

class Store163 {
  /**
   * @param {Box163<Model163>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project163} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model163} */
const model163 = {
  id: 163, name: "model-163", meta: { active: false, label: "meta-163" },
};
const preserved163 = preserve163(model163);
/** @type {Box163<Model163>} */
const box163 = { value: preserved163, label: "box-163" };
/** @type {Project163} */
const project163 = (input) => `${input.meta.label}:${input.name}`;
const store163 = new Store163(box163);
const rendered163 = store163.read(project163);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult163 = {
  id: preserved163.id,
  name: preserved163.name,
  active: preserved163.meta.active,
  rendered: rendered163,
};

/**
 * @typedef {object} Model164
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box164
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project164
 * @param {Model164} input
 * @returns {string}
 */

/**
 * @template {Model164} T
 * @param {T} value
 * @returns {T}
 */
function preserve164(value) {
  return value;
}

class Store164 {
  /**
   * @param {Box164<Model164>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project164} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model164} */
const model164 = {
  id: 164, name: "model-164", meta: { active: true, label: "meta-164" },
};
const preserved164 = preserve164(model164);
/** @type {Box164<Model164>} */
const box164 = { value: preserved164, label: "box-164" };
/** @type {Project164} */
const project164 = (input) => `${input.meta.label}:${input.name}`;
const store164 = new Store164(box164);
const rendered164 = store164.read(project164);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult164 = {
  id: preserved164.id,
  name: preserved164.name,
  active: preserved164.meta.active,
  rendered: rendered164,
};

/**
 * @typedef {object} Model165
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box165
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project165
 * @param {Model165} input
 * @returns {string}
 */

/**
 * @template {Model165} T
 * @param {T} value
 * @returns {T}
 */
function preserve165(value) {
  return value;
}

class Store165 {
  /**
   * @param {Box165<Model165>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project165} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model165} */
const model165 = {
  id: 165, name: "model-165", meta: { active: false, label: "meta-165" },
};
const preserved165 = preserve165(model165);
/** @type {Box165<Model165>} */
const box165 = { value: preserved165, label: "box-165" };
/** @type {Project165} */
const project165 = (input) => `${input.meta.label}:${input.name}`;
const store165 = new Store165(box165);
const rendered165 = store165.read(project165);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult165 = {
  id: preserved165.id,
  name: preserved165.name,
  active: preserved165.meta.active,
  rendered: rendered165,
};

/**
 * @typedef {object} Model166
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box166
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project166
 * @param {Model166} input
 * @returns {string}
 */

/**
 * @template {Model166} T
 * @param {T} value
 * @returns {T}
 */
function preserve166(value) {
  return value;
}

class Store166 {
  /**
   * @param {Box166<Model166>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project166} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model166} */
const model166 = {
  id: 166, name: "model-166", meta: { active: true, label: "meta-166" },
};
const preserved166 = preserve166(model166);
/** @type {Box166<Model166>} */
const box166 = { value: preserved166, label: "box-166" };
/** @type {Project166} */
const project166 = (input) => `${input.meta.label}:${input.name}`;
const store166 = new Store166(box166);
const rendered166 = store166.read(project166);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult166 = {
  id: preserved166.id,
  name: preserved166.name,
  active: preserved166.meta.active,
  rendered: rendered166,
};

/**
 * @typedef {object} Model167
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box167
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project167
 * @param {Model167} input
 * @returns {string}
 */

/**
 * @template {Model167} T
 * @param {T} value
 * @returns {T}
 */
function preserve167(value) {
  return value;
}

class Store167 {
  /**
   * @param {Box167<Model167>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project167} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model167} */
const model167 = {
  id: 167, name: "model-167", meta: { active: false, label: "meta-167" },
};
const preserved167 = preserve167(model167);
/** @type {Box167<Model167>} */
const box167 = { value: preserved167, label: "box-167" };
/** @type {Project167} */
const project167 = (input) => `${input.meta.label}:${input.name}`;
const store167 = new Store167(box167);
const rendered167 = store167.read(project167);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult167 = {
  id: preserved167.id,
  name: preserved167.name,
  active: preserved167.meta.active,
  rendered: rendered167,
};

/**
 * @typedef {object} Model168
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box168
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project168
 * @param {Model168} input
 * @returns {string}
 */

/**
 * @template {Model168} T
 * @param {T} value
 * @returns {T}
 */
function preserve168(value) {
  return value;
}

class Store168 {
  /**
   * @param {Box168<Model168>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project168} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model168} */
const model168 = {
  id: 168, name: "model-168", meta: { active: true, label: "meta-168" },
};
const preserved168 = preserve168(model168);
/** @type {Box168<Model168>} */
const box168 = { value: preserved168, label: "box-168" };
/** @type {Project168} */
const project168 = (input) => `${input.meta.label}:${input.name}`;
const store168 = new Store168(box168);
const rendered168 = store168.read(project168);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult168 = {
  id: preserved168.id,
  name: preserved168.name,
  active: preserved168.meta.active,
  rendered: rendered168,
};

/**
 * @typedef {object} Model169
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box169
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project169
 * @param {Model169} input
 * @returns {string}
 */

/**
 * @template {Model169} T
 * @param {T} value
 * @returns {T}
 */
function preserve169(value) {
  return value;
}

class Store169 {
  /**
   * @param {Box169<Model169>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project169} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model169} */
const model169 = {
  id: 169, name: "model-169", meta: { active: false, label: "meta-169" },
};
const preserved169 = preserve169(model169);
/** @type {Box169<Model169>} */
const box169 = { value: preserved169, label: "box-169" };
/** @type {Project169} */
const project169 = (input) => `${input.meta.label}:${input.name}`;
const store169 = new Store169(box169);
const rendered169 = store169.read(project169);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult169 = {
  id: preserved169.id,
  name: preserved169.name,
  active: preserved169.meta.active,
  rendered: rendered169,
};

/**
 * @typedef {object} Model170
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box170
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project170
 * @param {Model170} input
 * @returns {string}
 */

/**
 * @template {Model170} T
 * @param {T} value
 * @returns {T}
 */
function preserve170(value) {
  return value;
}

class Store170 {
  /**
   * @param {Box170<Model170>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project170} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model170} */
const model170 = {
  id: 170, name: "model-170", meta: { active: true, label: "meta-170" },
};
const preserved170 = preserve170(model170);
/** @type {Box170<Model170>} */
const box170 = { value: preserved170, label: "box-170" };
/** @type {Project170} */
const project170 = (input) => `${input.meta.label}:${input.name}`;
const store170 = new Store170(box170);
const rendered170 = store170.read(project170);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult170 = {
  id: preserved170.id,
  name: preserved170.name,
  active: preserved170.meta.active,
  rendered: rendered170,
};

/**
 * @typedef {object} Model171
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box171
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project171
 * @param {Model171} input
 * @returns {string}
 */

/**
 * @template {Model171} T
 * @param {T} value
 * @returns {T}
 */
function preserve171(value) {
  return value;
}

class Store171 {
  /**
   * @param {Box171<Model171>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project171} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model171} */
const model171 = {
  id: 171, name: "model-171", meta: { active: false, label: "meta-171" },
};
const preserved171 = preserve171(model171);
/** @type {Box171<Model171>} */
const box171 = { value: preserved171, label: "box-171" };
/** @type {Project171} */
const project171 = (input) => `${input.meta.label}:${input.name}`;
const store171 = new Store171(box171);
const rendered171 = store171.read(project171);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult171 = {
  id: preserved171.id,
  name: preserved171.name,
  active: preserved171.meta.active,
  rendered: rendered171,
};

/**
 * @typedef {object} Model172
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box172
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project172
 * @param {Model172} input
 * @returns {string}
 */

/**
 * @template {Model172} T
 * @param {T} value
 * @returns {T}
 */
function preserve172(value) {
  return value;
}

class Store172 {
  /**
   * @param {Box172<Model172>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project172} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model172} */
const model172 = {
  id: 172, name: "model-172", meta: { active: true, label: "meta-172" },
};
const preserved172 = preserve172(model172);
/** @type {Box172<Model172>} */
const box172 = { value: preserved172, label: "box-172" };
/** @type {Project172} */
const project172 = (input) => `${input.meta.label}:${input.name}`;
const store172 = new Store172(box172);
const rendered172 = store172.read(project172);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult172 = {
  id: preserved172.id,
  name: preserved172.name,
  active: preserved172.meta.active,
  rendered: rendered172,
};

/**
 * @typedef {object} Model173
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box173
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project173
 * @param {Model173} input
 * @returns {string}
 */

/**
 * @template {Model173} T
 * @param {T} value
 * @returns {T}
 */
function preserve173(value) {
  return value;
}

class Store173 {
  /**
   * @param {Box173<Model173>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project173} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model173} */
const model173 = {
  id: 173, name: "model-173", meta: { active: false, label: "meta-173" },
};
const preserved173 = preserve173(model173);
/** @type {Box173<Model173>} */
const box173 = { value: preserved173, label: "box-173" };
/** @type {Project173} */
const project173 = (input) => `${input.meta.label}:${input.name}`;
const store173 = new Store173(box173);
const rendered173 = store173.read(project173);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult173 = {
  id: preserved173.id,
  name: preserved173.name,
  active: preserved173.meta.active,
  rendered: rendered173,
};

/**
 * @typedef {object} Model174
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box174
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project174
 * @param {Model174} input
 * @returns {string}
 */

/**
 * @template {Model174} T
 * @param {T} value
 * @returns {T}
 */
function preserve174(value) {
  return value;
}

class Store174 {
  /**
   * @param {Box174<Model174>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project174} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model174} */
const model174 = {
  id: 174, name: "model-174", meta: { active: true, label: "meta-174" },
};
const preserved174 = preserve174(model174);
/** @type {Box174<Model174>} */
const box174 = { value: preserved174, label: "box-174" };
/** @type {Project174} */
const project174 = (input) => `${input.meta.label}:${input.name}`;
const store174 = new Store174(box174);
const rendered174 = store174.read(project174);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult174 = {
  id: preserved174.id,
  name: preserved174.name,
  active: preserved174.meta.active,
  rendered: rendered174,
};

/**
 * @typedef {object} Model175
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box175
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project175
 * @param {Model175} input
 * @returns {string}
 */

/**
 * @template {Model175} T
 * @param {T} value
 * @returns {T}
 */
function preserve175(value) {
  return value;
}

class Store175 {
  /**
   * @param {Box175<Model175>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project175} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model175} */
const model175 = {
  id: 175, name: "model-175", meta: { active: false, label: "meta-175" },
};
const preserved175 = preserve175(model175);
/** @type {Box175<Model175>} */
const box175 = { value: preserved175, label: "box-175" };
/** @type {Project175} */
const project175 = (input) => `${input.meta.label}:${input.name}`;
const store175 = new Store175(box175);
const rendered175 = store175.read(project175);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult175 = {
  id: preserved175.id,
  name: preserved175.name,
  active: preserved175.meta.active,
  rendered: rendered175,
};

/**
 * @typedef {object} Model176
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box176
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project176
 * @param {Model176} input
 * @returns {string}
 */

/**
 * @template {Model176} T
 * @param {T} value
 * @returns {T}
 */
function preserve176(value) {
  return value;
}

class Store176 {
  /**
   * @param {Box176<Model176>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project176} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model176} */
const model176 = {
  id: 176, name: "model-176", meta: { active: true, label: "meta-176" },
};
const preserved176 = preserve176(model176);
/** @type {Box176<Model176>} */
const box176 = { value: preserved176, label: "box-176" };
/** @type {Project176} */
const project176 = (input) => `${input.meta.label}:${input.name}`;
const store176 = new Store176(box176);
const rendered176 = store176.read(project176);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult176 = {
  id: preserved176.id,
  name: preserved176.name,
  active: preserved176.meta.active,
  rendered: rendered176,
};

/**
 * @typedef {object} Model177
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box177
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project177
 * @param {Model177} input
 * @returns {string}
 */

/**
 * @template {Model177} T
 * @param {T} value
 * @returns {T}
 */
function preserve177(value) {
  return value;
}

class Store177 {
  /**
   * @param {Box177<Model177>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project177} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model177} */
const model177 = {
  id: 177, name: "model-177", meta: { active: false, label: "meta-177" },
};
const preserved177 = preserve177(model177);
/** @type {Box177<Model177>} */
const box177 = { value: preserved177, label: "box-177" };
/** @type {Project177} */
const project177 = (input) => `${input.meta.label}:${input.name}`;
const store177 = new Store177(box177);
const rendered177 = store177.read(project177);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult177 = {
  id: preserved177.id,
  name: preserved177.name,
  active: preserved177.meta.active,
  rendered: rendered177,
};

/**
 * @typedef {object} Model178
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box178
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project178
 * @param {Model178} input
 * @returns {string}
 */

/**
 * @template {Model178} T
 * @param {T} value
 * @returns {T}
 */
function preserve178(value) {
  return value;
}

class Store178 {
  /**
   * @param {Box178<Model178>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project178} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model178} */
const model178 = {
  id: 178, name: "model-178", meta: { active: true, label: "meta-178" },
};
const preserved178 = preserve178(model178);
/** @type {Box178<Model178>} */
const box178 = { value: preserved178, label: "box-178" };
/** @type {Project178} */
const project178 = (input) => `${input.meta.label}:${input.name}`;
const store178 = new Store178(box178);
const rendered178 = store178.read(project178);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult178 = {
  id: preserved178.id,
  name: preserved178.name,
  active: preserved178.meta.active,
  rendered: rendered178,
};

/**
 * @typedef {object} Model179
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box179
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project179
 * @param {Model179} input
 * @returns {string}
 */

/**
 * @template {Model179} T
 * @param {T} value
 * @returns {T}
 */
function preserve179(value) {
  return value;
}

class Store179 {
  /**
   * @param {Box179<Model179>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project179} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model179} */
const model179 = {
  id: 179, name: "model-179", meta: { active: false, label: "meta-179" },
};
const preserved179 = preserve179(model179);
/** @type {Box179<Model179>} */
const box179 = { value: preserved179, label: "box-179" };
/** @type {Project179} */
const project179 = (input) => `${input.meta.label}:${input.name}`;
const store179 = new Store179(box179);
const rendered179 = store179.read(project179);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult179 = {
  id: preserved179.id,
  name: preserved179.name,
  active: preserved179.meta.active,
  rendered: rendered179,
};

/**
 * @typedef {object} Model180
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box180
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project180
 * @param {Model180} input
 * @returns {string}
 */

/**
 * @template {Model180} T
 * @param {T} value
 * @returns {T}
 */
function preserve180(value) {
  return value;
}

class Store180 {
  /**
   * @param {Box180<Model180>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project180} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model180} */
const model180 = {
  id: 180, name: "model-180", meta: { active: true, label: "meta-180" },
};
const preserved180 = preserve180(model180);
/** @type {Box180<Model180>} */
const box180 = { value: preserved180, label: "box-180" };
/** @type {Project180} */
const project180 = (input) => `${input.meta.label}:${input.name}`;
const store180 = new Store180(box180);
const rendered180 = store180.read(project180);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult180 = {
  id: preserved180.id,
  name: preserved180.name,
  active: preserved180.meta.active,
  rendered: rendered180,
};

/**
 * @typedef {object} Model181
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box181
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project181
 * @param {Model181} input
 * @returns {string}
 */

/**
 * @template {Model181} T
 * @param {T} value
 * @returns {T}
 */
function preserve181(value) {
  return value;
}

class Store181 {
  /**
   * @param {Box181<Model181>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project181} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model181} */
const model181 = {
  id: 181, name: "model-181", meta: { active: false, label: "meta-181" },
};
const preserved181 = preserve181(model181);
/** @type {Box181<Model181>} */
const box181 = { value: preserved181, label: "box-181" };
/** @type {Project181} */
const project181 = (input) => `${input.meta.label}:${input.name}`;
const store181 = new Store181(box181);
const rendered181 = store181.read(project181);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult181 = {
  id: preserved181.id,
  name: preserved181.name,
  active: preserved181.meta.active,
  rendered: rendered181,
};

/**
 * @typedef {object} Model182
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box182
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project182
 * @param {Model182} input
 * @returns {string}
 */

/**
 * @template {Model182} T
 * @param {T} value
 * @returns {T}
 */
function preserve182(value) {
  return value;
}

class Store182 {
  /**
   * @param {Box182<Model182>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project182} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model182} */
const model182 = {
  id: 182, name: "model-182", meta: { active: true, label: "meta-182" },
};
const preserved182 = preserve182(model182);
/** @type {Box182<Model182>} */
const box182 = { value: preserved182, label: "box-182" };
/** @type {Project182} */
const project182 = (input) => `${input.meta.label}:${input.name}`;
const store182 = new Store182(box182);
const rendered182 = store182.read(project182);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult182 = {
  id: preserved182.id,
  name: preserved182.name,
  active: preserved182.meta.active,
  rendered: rendered182,
};

/**
 * @typedef {object} Model183
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box183
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project183
 * @param {Model183} input
 * @returns {string}
 */

/**
 * @template {Model183} T
 * @param {T} value
 * @returns {T}
 */
function preserve183(value) {
  return value;
}

class Store183 {
  /**
   * @param {Box183<Model183>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project183} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model183} */
const model183 = {
  id: 183, name: "model-183", meta: { active: false, label: "meta-183" },
};
const preserved183 = preserve183(model183);
/** @type {Box183<Model183>} */
const box183 = { value: preserved183, label: "box-183" };
/** @type {Project183} */
const project183 = (input) => `${input.meta.label}:${input.name}`;
const store183 = new Store183(box183);
const rendered183 = store183.read(project183);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult183 = {
  id: preserved183.id,
  name: preserved183.name,
  active: preserved183.meta.active,
  rendered: rendered183,
};

/**
 * @typedef {object} Model184
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box184
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project184
 * @param {Model184} input
 * @returns {string}
 */

/**
 * @template {Model184} T
 * @param {T} value
 * @returns {T}
 */
function preserve184(value) {
  return value;
}

class Store184 {
  /**
   * @param {Box184<Model184>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project184} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model184} */
const model184 = {
  id: 184, name: "model-184", meta: { active: true, label: "meta-184" },
};
const preserved184 = preserve184(model184);
/** @type {Box184<Model184>} */
const box184 = { value: preserved184, label: "box-184" };
/** @type {Project184} */
const project184 = (input) => `${input.meta.label}:${input.name}`;
const store184 = new Store184(box184);
const rendered184 = store184.read(project184);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult184 = {
  id: preserved184.id,
  name: preserved184.name,
  active: preserved184.meta.active,
  rendered: rendered184,
};

/**
 * @typedef {object} Model185
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box185
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project185
 * @param {Model185} input
 * @returns {string}
 */

/**
 * @template {Model185} T
 * @param {T} value
 * @returns {T}
 */
function preserve185(value) {
  return value;
}

class Store185 {
  /**
   * @param {Box185<Model185>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project185} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model185} */
const model185 = {
  id: 185, name: "model-185", meta: { active: false, label: "meta-185" },
};
const preserved185 = preserve185(model185);
/** @type {Box185<Model185>} */
const box185 = { value: preserved185, label: "box-185" };
/** @type {Project185} */
const project185 = (input) => `${input.meta.label}:${input.name}`;
const store185 = new Store185(box185);
const rendered185 = store185.read(project185);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult185 = {
  id: preserved185.id,
  name: preserved185.name,
  active: preserved185.meta.active,
  rendered: rendered185,
};

/**
 * @typedef {object} Model186
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box186
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project186
 * @param {Model186} input
 * @returns {string}
 */

/**
 * @template {Model186} T
 * @param {T} value
 * @returns {T}
 */
function preserve186(value) {
  return value;
}

class Store186 {
  /**
   * @param {Box186<Model186>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project186} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model186} */
const model186 = {
  id: 186, name: "model-186", meta: { active: true, label: "meta-186" },
};
const preserved186 = preserve186(model186);
/** @type {Box186<Model186>} */
const box186 = { value: preserved186, label: "box-186" };
/** @type {Project186} */
const project186 = (input) => `${input.meta.label}:${input.name}`;
const store186 = new Store186(box186);
const rendered186 = store186.read(project186);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult186 = {
  id: preserved186.id,
  name: preserved186.name,
  active: preserved186.meta.active,
  rendered: rendered186,
};

/**
 * @typedef {object} Model187
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box187
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project187
 * @param {Model187} input
 * @returns {string}
 */

/**
 * @template {Model187} T
 * @param {T} value
 * @returns {T}
 */
function preserve187(value) {
  return value;
}

class Store187 {
  /**
   * @param {Box187<Model187>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project187} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model187} */
const model187 = {
  id: 187, name: "model-187", meta: { active: false, label: "meta-187" },
};
const preserved187 = preserve187(model187);
/** @type {Box187<Model187>} */
const box187 = { value: preserved187, label: "box-187" };
/** @type {Project187} */
const project187 = (input) => `${input.meta.label}:${input.name}`;
const store187 = new Store187(box187);
const rendered187 = store187.read(project187);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult187 = {
  id: preserved187.id,
  name: preserved187.name,
  active: preserved187.meta.active,
  rendered: rendered187,
};

/**
 * @typedef {object} Model188
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box188
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project188
 * @param {Model188} input
 * @returns {string}
 */

/**
 * @template {Model188} T
 * @param {T} value
 * @returns {T}
 */
function preserve188(value) {
  return value;
}

class Store188 {
  /**
   * @param {Box188<Model188>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project188} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model188} */
const model188 = {
  id: 188, name: "model-188", meta: { active: true, label: "meta-188" },
};
const preserved188 = preserve188(model188);
/** @type {Box188<Model188>} */
const box188 = { value: preserved188, label: "box-188" };
/** @type {Project188} */
const project188 = (input) => `${input.meta.label}:${input.name}`;
const store188 = new Store188(box188);
const rendered188 = store188.read(project188);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult188 = {
  id: preserved188.id,
  name: preserved188.name,
  active: preserved188.meta.active,
  rendered: rendered188,
};

/**
 * @typedef {object} Model189
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box189
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project189
 * @param {Model189} input
 * @returns {string}
 */

/**
 * @template {Model189} T
 * @param {T} value
 * @returns {T}
 */
function preserve189(value) {
  return value;
}

class Store189 {
  /**
   * @param {Box189<Model189>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project189} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model189} */
const model189 = {
  id: 189, name: "model-189", meta: { active: false, label: "meta-189" },
};
const preserved189 = preserve189(model189);
/** @type {Box189<Model189>} */
const box189 = { value: preserved189, label: "box-189" };
/** @type {Project189} */
const project189 = (input) => `${input.meta.label}:${input.name}`;
const store189 = new Store189(box189);
const rendered189 = store189.read(project189);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult189 = {
  id: preserved189.id,
  name: preserved189.name,
  active: preserved189.meta.active,
  rendered: rendered189,
};

/**
 * @typedef {object} Model190
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box190
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project190
 * @param {Model190} input
 * @returns {string}
 */

/**
 * @template {Model190} T
 * @param {T} value
 * @returns {T}
 */
function preserve190(value) {
  return value;
}

class Store190 {
  /**
   * @param {Box190<Model190>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project190} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model190} */
const model190 = {
  id: 190, name: "model-190", meta: { active: true, label: "meta-190" },
};
const preserved190 = preserve190(model190);
/** @type {Box190<Model190>} */
const box190 = { value: preserved190, label: "box-190" };
/** @type {Project190} */
const project190 = (input) => `${input.meta.label}:${input.name}`;
const store190 = new Store190(box190);
const rendered190 = store190.read(project190);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult190 = {
  id: preserved190.id,
  name: preserved190.name,
  active: preserved190.meta.active,
  rendered: rendered190,
};

/**
 * @typedef {object} Model191
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box191
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project191
 * @param {Model191} input
 * @returns {string}
 */

/**
 * @template {Model191} T
 * @param {T} value
 * @returns {T}
 */
function preserve191(value) {
  return value;
}

class Store191 {
  /**
   * @param {Box191<Model191>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project191} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model191} */
const model191 = {
  id: 191, name: "model-191", meta: { active: false, label: "meta-191" },
};
const preserved191 = preserve191(model191);
/** @type {Box191<Model191>} */
const box191 = { value: preserved191, label: "box-191" };
/** @type {Project191} */
const project191 = (input) => `${input.meta.label}:${input.name}`;
const store191 = new Store191(box191);
const rendered191 = store191.read(project191);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult191 = {
  id: preserved191.id,
  name: preserved191.name,
  active: preserved191.meta.active,
  rendered: rendered191,
};

/**
 * @typedef {object} Model192
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box192
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project192
 * @param {Model192} input
 * @returns {string}
 */

/**
 * @template {Model192} T
 * @param {T} value
 * @returns {T}
 */
function preserve192(value) {
  return value;
}

class Store192 {
  /**
   * @param {Box192<Model192>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project192} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model192} */
const model192 = {
  id: 192, name: "model-192", meta: { active: true, label: "meta-192" },
};
const preserved192 = preserve192(model192);
/** @type {Box192<Model192>} */
const box192 = { value: preserved192, label: "box-192" };
/** @type {Project192} */
const project192 = (input) => `${input.meta.label}:${input.name}`;
const store192 = new Store192(box192);
const rendered192 = store192.read(project192);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult192 = {
  id: preserved192.id,
  name: preserved192.name,
  active: preserved192.meta.active,
  rendered: rendered192,
};

/**
 * @typedef {object} Model193
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box193
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project193
 * @param {Model193} input
 * @returns {string}
 */

/**
 * @template {Model193} T
 * @param {T} value
 * @returns {T}
 */
function preserve193(value) {
  return value;
}

class Store193 {
  /**
   * @param {Box193<Model193>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project193} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model193} */
const model193 = {
  id: 193, name: "model-193", meta: { active: false, label: "meta-193" },
};
const preserved193 = preserve193(model193);
/** @type {Box193<Model193>} */
const box193 = { value: preserved193, label: "box-193" };
/** @type {Project193} */
const project193 = (input) => `${input.meta.label}:${input.name}`;
const store193 = new Store193(box193);
const rendered193 = store193.read(project193);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult193 = {
  id: preserved193.id,
  name: preserved193.name,
  active: preserved193.meta.active,
  rendered: rendered193,
};

/**
 * @typedef {object} Model194
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box194
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project194
 * @param {Model194} input
 * @returns {string}
 */

/**
 * @template {Model194} T
 * @param {T} value
 * @returns {T}
 */
function preserve194(value) {
  return value;
}

class Store194 {
  /**
   * @param {Box194<Model194>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project194} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model194} */
const model194 = {
  id: 194, name: "model-194", meta: { active: true, label: "meta-194" },
};
const preserved194 = preserve194(model194);
/** @type {Box194<Model194>} */
const box194 = { value: preserved194, label: "box-194" };
/** @type {Project194} */
const project194 = (input) => `${input.meta.label}:${input.name}`;
const store194 = new Store194(box194);
const rendered194 = store194.read(project194);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult194 = {
  id: preserved194.id,
  name: preserved194.name,
  active: preserved194.meta.active,
  rendered: rendered194,
};

/**
 * @typedef {object} Model195
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box195
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project195
 * @param {Model195} input
 * @returns {string}
 */

/**
 * @template {Model195} T
 * @param {T} value
 * @returns {T}
 */
function preserve195(value) {
  return value;
}

class Store195 {
  /**
   * @param {Box195<Model195>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project195} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model195} */
const model195 = {
  id: 195, name: "model-195", meta: { active: false, label: "meta-195" },
};
const preserved195 = preserve195(model195);
/** @type {Box195<Model195>} */
const box195 = { value: preserved195, label: "box-195" };
/** @type {Project195} */
const project195 = (input) => `${input.meta.label}:${input.name}`;
const store195 = new Store195(box195);
const rendered195 = store195.read(project195);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult195 = {
  id: preserved195.id,
  name: preserved195.name,
  active: preserved195.meta.active,
  rendered: rendered195,
};

/**
 * @typedef {object} Model196
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box196
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project196
 * @param {Model196} input
 * @returns {string}
 */

/**
 * @template {Model196} T
 * @param {T} value
 * @returns {T}
 */
function preserve196(value) {
  return value;
}

class Store196 {
  /**
   * @param {Box196<Model196>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project196} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model196} */
const model196 = {
  id: 196, name: "model-196", meta: { active: true, label: "meta-196" },
};
const preserved196 = preserve196(model196);
/** @type {Box196<Model196>} */
const box196 = { value: preserved196, label: "box-196" };
/** @type {Project196} */
const project196 = (input) => `${input.meta.label}:${input.name}`;
const store196 = new Store196(box196);
const rendered196 = store196.read(project196);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult196 = {
  id: preserved196.id,
  name: preserved196.name,
  active: preserved196.meta.active,
  rendered: rendered196,
};

/**
 * @typedef {object} Model197
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box197
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project197
 * @param {Model197} input
 * @returns {string}
 */

/**
 * @template {Model197} T
 * @param {T} value
 * @returns {T}
 */
function preserve197(value) {
  return value;
}

class Store197 {
  /**
   * @param {Box197<Model197>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project197} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model197} */
const model197 = {
  id: 197, name: "model-197", meta: { active: false, label: "meta-197" },
};
const preserved197 = preserve197(model197);
/** @type {Box197<Model197>} */
const box197 = { value: preserved197, label: "box-197" };
/** @type {Project197} */
const project197 = (input) => `${input.meta.label}:${input.name}`;
const store197 = new Store197(box197);
const rendered197 = store197.read(project197);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult197 = {
  id: preserved197.id,
  name: preserved197.name,
  active: preserved197.meta.active,
  rendered: rendered197,
};

/**
 * @typedef {object} Model198
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box198
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project198
 * @param {Model198} input
 * @returns {string}
 */

/**
 * @template {Model198} T
 * @param {T} value
 * @returns {T}
 */
function preserve198(value) {
  return value;
}

class Store198 {
  /**
   * @param {Box198<Model198>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project198} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model198} */
const model198 = {
  id: 198, name: "model-198", meta: { active: true, label: "meta-198" },
};
const preserved198 = preserve198(model198);
/** @type {Box198<Model198>} */
const box198 = { value: preserved198, label: "box-198" };
/** @type {Project198} */
const project198 = (input) => `${input.meta.label}:${input.name}`;
const store198 = new Store198(box198);
const rendered198 = store198.read(project198);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult198 = {
  id: preserved198.id,
  name: preserved198.name,
  active: preserved198.meta.active,
  rendered: rendered198,
};

/**
 * @typedef {object} Model199
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box199
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project199
 * @param {Model199} input
 * @returns {string}
 */

/**
 * @template {Model199} T
 * @param {T} value
 * @returns {T}
 */
function preserve199(value) {
  return value;
}

class Store199 {
  /**
   * @param {Box199<Model199>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project199} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model199} */
const model199 = {
  id: 199, name: "model-199", meta: { active: false, label: "meta-199" },
};
const preserved199 = preserve199(model199);
/** @type {Box199<Model199>} */
const box199 = { value: preserved199, label: "box-199" };
/** @type {Project199} */
const project199 = (input) => `${input.meta.label}:${input.name}`;
const store199 = new Store199(box199);
const rendered199 = store199.read(project199);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult199 = {
  id: preserved199.id,
  name: preserved199.name,
  active: preserved199.meta.active,
  rendered: rendered199,
};

/**
 * @typedef {object} Model200
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box200
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project200
 * @param {Model200} input
 * @returns {string}
 */

/**
 * @template {Model200} T
 * @param {T} value
 * @returns {T}
 */
function preserve200(value) {
  return value;
}

class Store200 {
  /**
   * @param {Box200<Model200>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project200} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model200} */
const model200 = {
  id: 200, name: "model-200", meta: { active: true, label: "meta-200" },
};
const preserved200 = preserve200(model200);
/** @type {Box200<Model200>} */
const box200 = { value: preserved200, label: "box-200" };
/** @type {Project200} */
const project200 = (input) => `${input.meta.label}:${input.name}`;
const store200 = new Store200(box200);
const rendered200 = store200.read(project200);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult200 = {
  id: preserved200.id,
  name: preserved200.name,
  active: preserved200.meta.active,
  rendered: rendered200,
};

/**
 * @typedef {object} Model201
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box201
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project201
 * @param {Model201} input
 * @returns {string}
 */

/**
 * @template {Model201} T
 * @param {T} value
 * @returns {T}
 */
function preserve201(value) {
  return value;
}

class Store201 {
  /**
   * @param {Box201<Model201>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project201} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model201} */
const model201 = {
  id: 201, name: "model-201", meta: { active: false, label: "meta-201" },
};
const preserved201 = preserve201(model201);
/** @type {Box201<Model201>} */
const box201 = { value: preserved201, label: "box-201" };
/** @type {Project201} */
const project201 = (input) => `${input.meta.label}:${input.name}`;
const store201 = new Store201(box201);
const rendered201 = store201.read(project201);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult201 = {
  id: preserved201.id,
  name: preserved201.name,
  active: preserved201.meta.active,
  rendered: rendered201,
};

/**
 * @typedef {object} Model202
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box202
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project202
 * @param {Model202} input
 * @returns {string}
 */

/**
 * @template {Model202} T
 * @param {T} value
 * @returns {T}
 */
function preserve202(value) {
  return value;
}

class Store202 {
  /**
   * @param {Box202<Model202>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project202} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model202} */
const model202 = {
  id: 202, name: "model-202", meta: { active: true, label: "meta-202" },
};
const preserved202 = preserve202(model202);
/** @type {Box202<Model202>} */
const box202 = { value: preserved202, label: "box-202" };
/** @type {Project202} */
const project202 = (input) => `${input.meta.label}:${input.name}`;
const store202 = new Store202(box202);
const rendered202 = store202.read(project202);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult202 = {
  id: preserved202.id,
  name: preserved202.name,
  active: preserved202.meta.active,
  rendered: rendered202,
};

/**
 * @typedef {object} Model203
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box203
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project203
 * @param {Model203} input
 * @returns {string}
 */

/**
 * @template {Model203} T
 * @param {T} value
 * @returns {T}
 */
function preserve203(value) {
  return value;
}

class Store203 {
  /**
   * @param {Box203<Model203>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project203} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model203} */
const model203 = {
  id: 203, name: "model-203", meta: { active: false, label: "meta-203" },
};
const preserved203 = preserve203(model203);
/** @type {Box203<Model203>} */
const box203 = { value: preserved203, label: "box-203" };
/** @type {Project203} */
const project203 = (input) => `${input.meta.label}:${input.name}`;
const store203 = new Store203(box203);
const rendered203 = store203.read(project203);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult203 = {
  id: preserved203.id,
  name: preserved203.name,
  active: preserved203.meta.active,
  rendered: rendered203,
};

/**
 * @typedef {object} Model204
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box204
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project204
 * @param {Model204} input
 * @returns {string}
 */

/**
 * @template {Model204} T
 * @param {T} value
 * @returns {T}
 */
function preserve204(value) {
  return value;
}

class Store204 {
  /**
   * @param {Box204<Model204>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project204} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model204} */
const model204 = {
  id: 204, name: "model-204", meta: { active: true, label: "meta-204" },
};
const preserved204 = preserve204(model204);
/** @type {Box204<Model204>} */
const box204 = { value: preserved204, label: "box-204" };
/** @type {Project204} */
const project204 = (input) => `${input.meta.label}:${input.name}`;
const store204 = new Store204(box204);
const rendered204 = store204.read(project204);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult204 = {
  id: preserved204.id,
  name: preserved204.name,
  active: preserved204.meta.active,
  rendered: rendered204,
};

/**
 * @typedef {object} Model205
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box205
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project205
 * @param {Model205} input
 * @returns {string}
 */

/**
 * @template {Model205} T
 * @param {T} value
 * @returns {T}
 */
function preserve205(value) {
  return value;
}

class Store205 {
  /**
   * @param {Box205<Model205>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project205} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model205} */
const model205 = {
  id: 205, name: "model-205", meta: { active: false, label: "meta-205" },
};
const preserved205 = preserve205(model205);
/** @type {Box205<Model205>} */
const box205 = { value: preserved205, label: "box-205" };
/** @type {Project205} */
const project205 = (input) => `${input.meta.label}:${input.name}`;
const store205 = new Store205(box205);
const rendered205 = store205.read(project205);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult205 = {
  id: preserved205.id,
  name: preserved205.name,
  active: preserved205.meta.active,
  rendered: rendered205,
};

/**
 * @typedef {object} Model206
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box206
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project206
 * @param {Model206} input
 * @returns {string}
 */

/**
 * @template {Model206} T
 * @param {T} value
 * @returns {T}
 */
function preserve206(value) {
  return value;
}

class Store206 {
  /**
   * @param {Box206<Model206>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project206} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model206} */
const model206 = {
  id: 206, name: "model-206", meta: { active: true, label: "meta-206" },
};
const preserved206 = preserve206(model206);
/** @type {Box206<Model206>} */
const box206 = { value: preserved206, label: "box-206" };
/** @type {Project206} */
const project206 = (input) => `${input.meta.label}:${input.name}`;
const store206 = new Store206(box206);
const rendered206 = store206.read(project206);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult206 = {
  id: preserved206.id,
  name: preserved206.name,
  active: preserved206.meta.active,
  rendered: rendered206,
};

/**
 * @typedef {object} Model207
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box207
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project207
 * @param {Model207} input
 * @returns {string}
 */

/**
 * @template {Model207} T
 * @param {T} value
 * @returns {T}
 */
function preserve207(value) {
  return value;
}

class Store207 {
  /**
   * @param {Box207<Model207>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project207} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model207} */
const model207 = {
  id: 207, name: "model-207", meta: { active: false, label: "meta-207" },
};
const preserved207 = preserve207(model207);
/** @type {Box207<Model207>} */
const box207 = { value: preserved207, label: "box-207" };
/** @type {Project207} */
const project207 = (input) => `${input.meta.label}:${input.name}`;
const store207 = new Store207(box207);
const rendered207 = store207.read(project207);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult207 = {
  id: preserved207.id,
  name: preserved207.name,
  active: preserved207.meta.active,
  rendered: rendered207,
};

/**
 * @typedef {object} Model208
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box208
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project208
 * @param {Model208} input
 * @returns {string}
 */

/**
 * @template {Model208} T
 * @param {T} value
 * @returns {T}
 */
function preserve208(value) {
  return value;
}

class Store208 {
  /**
   * @param {Box208<Model208>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project208} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model208} */
const model208 = {
  id: 208, name: "model-208", meta: { active: true, label: "meta-208" },
};
const preserved208 = preserve208(model208);
/** @type {Box208<Model208>} */
const box208 = { value: preserved208, label: "box-208" };
/** @type {Project208} */
const project208 = (input) => `${input.meta.label}:${input.name}`;
const store208 = new Store208(box208);
const rendered208 = store208.read(project208);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult208 = {
  id: preserved208.id,
  name: preserved208.name,
  active: preserved208.meta.active,
  rendered: rendered208,
};

/**
 * @typedef {object} Model209
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box209
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project209
 * @param {Model209} input
 * @returns {string}
 */

/**
 * @template {Model209} T
 * @param {T} value
 * @returns {T}
 */
function preserve209(value) {
  return value;
}

class Store209 {
  /**
   * @param {Box209<Model209>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project209} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model209} */
const model209 = {
  id: 209, name: "model-209", meta: { active: false, label: "meta-209" },
};
const preserved209 = preserve209(model209);
/** @type {Box209<Model209>} */
const box209 = { value: preserved209, label: "box-209" };
/** @type {Project209} */
const project209 = (input) => `${input.meta.label}:${input.name}`;
const store209 = new Store209(box209);
const rendered209 = store209.read(project209);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult209 = {
  id: preserved209.id,
  name: preserved209.name,
  active: preserved209.meta.active,
  rendered: rendered209,
};

/**
 * @typedef {object} Model210
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box210
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project210
 * @param {Model210} input
 * @returns {string}
 */

/**
 * @template {Model210} T
 * @param {T} value
 * @returns {T}
 */
function preserve210(value) {
  return value;
}

class Store210 {
  /**
   * @param {Box210<Model210>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project210} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model210} */
const model210 = {
  id: 210, name: "model-210", meta: { active: true, label: "meta-210" },
};
const preserved210 = preserve210(model210);
/** @type {Box210<Model210>} */
const box210 = { value: preserved210, label: "box-210" };
/** @type {Project210} */
const project210 = (input) => `${input.meta.label}:${input.name}`;
const store210 = new Store210(box210);
const rendered210 = store210.read(project210);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult210 = {
  id: preserved210.id,
  name: preserved210.name,
  active: preserved210.meta.active,
  rendered: rendered210,
};

/**
 * @typedef {object} Model211
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box211
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project211
 * @param {Model211} input
 * @returns {string}
 */

/**
 * @template {Model211} T
 * @param {T} value
 * @returns {T}
 */
function preserve211(value) {
  return value;
}

class Store211 {
  /**
   * @param {Box211<Model211>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project211} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model211} */
const model211 = {
  id: 211, name: "model-211", meta: { active: false, label: "meta-211" },
};
const preserved211 = preserve211(model211);
/** @type {Box211<Model211>} */
const box211 = { value: preserved211, label: "box-211" };
/** @type {Project211} */
const project211 = (input) => `${input.meta.label}:${input.name}`;
const store211 = new Store211(box211);
const rendered211 = store211.read(project211);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult211 = {
  id: preserved211.id,
  name: preserved211.name,
  active: preserved211.meta.active,
  rendered: rendered211,
};

/**
 * @typedef {object} Model212
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box212
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project212
 * @param {Model212} input
 * @returns {string}
 */

/**
 * @template {Model212} T
 * @param {T} value
 * @returns {T}
 */
function preserve212(value) {
  return value;
}

class Store212 {
  /**
   * @param {Box212<Model212>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project212} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model212} */
const model212 = {
  id: 212, name: "model-212", meta: { active: true, label: "meta-212" },
};
const preserved212 = preserve212(model212);
/** @type {Box212<Model212>} */
const box212 = { value: preserved212, label: "box-212" };
/** @type {Project212} */
const project212 = (input) => `${input.meta.label}:${input.name}`;
const store212 = new Store212(box212);
const rendered212 = store212.read(project212);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult212 = {
  id: preserved212.id,
  name: preserved212.name,
  active: preserved212.meta.active,
  rendered: rendered212,
};

/**
 * @typedef {object} Model213
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box213
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project213
 * @param {Model213} input
 * @returns {string}
 */

/**
 * @template {Model213} T
 * @param {T} value
 * @returns {T}
 */
function preserve213(value) {
  return value;
}

class Store213 {
  /**
   * @param {Box213<Model213>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project213} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model213} */
const model213 = {
  id: 213, name: "model-213", meta: { active: false, label: "meta-213" },
};
const preserved213 = preserve213(model213);
/** @type {Box213<Model213>} */
const box213 = { value: preserved213, label: "box-213" };
/** @type {Project213} */
const project213 = (input) => `${input.meta.label}:${input.name}`;
const store213 = new Store213(box213);
const rendered213 = store213.read(project213);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult213 = {
  id: preserved213.id,
  name: preserved213.name,
  active: preserved213.meta.active,
  rendered: rendered213,
};

/**
 * @typedef {object} Model214
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box214
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project214
 * @param {Model214} input
 * @returns {string}
 */

/**
 * @template {Model214} T
 * @param {T} value
 * @returns {T}
 */
function preserve214(value) {
  return value;
}

class Store214 {
  /**
   * @param {Box214<Model214>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project214} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model214} */
const model214 = {
  id: 214, name: "model-214", meta: { active: true, label: "meta-214" },
};
const preserved214 = preserve214(model214);
/** @type {Box214<Model214>} */
const box214 = { value: preserved214, label: "box-214" };
/** @type {Project214} */
const project214 = (input) => `${input.meta.label}:${input.name}`;
const store214 = new Store214(box214);
const rendered214 = store214.read(project214);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult214 = {
  id: preserved214.id,
  name: preserved214.name,
  active: preserved214.meta.active,
  rendered: rendered214,
};

/**
 * @typedef {object} Model215
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box215
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project215
 * @param {Model215} input
 * @returns {string}
 */

/**
 * @template {Model215} T
 * @param {T} value
 * @returns {T}
 */
function preserve215(value) {
  return value;
}

class Store215 {
  /**
   * @param {Box215<Model215>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project215} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model215} */
const model215 = {
  id: 215, name: "model-215", meta: { active: false, label: "meta-215" },
};
const preserved215 = preserve215(model215);
/** @type {Box215<Model215>} */
const box215 = { value: preserved215, label: "box-215" };
/** @type {Project215} */
const project215 = (input) => `${input.meta.label}:${input.name}`;
const store215 = new Store215(box215);
const rendered215 = store215.read(project215);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult215 = {
  id: preserved215.id,
  name: preserved215.name,
  active: preserved215.meta.active,
  rendered: rendered215,
};

/**
 * @typedef {object} Model216
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box216
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project216
 * @param {Model216} input
 * @returns {string}
 */

/**
 * @template {Model216} T
 * @param {T} value
 * @returns {T}
 */
function preserve216(value) {
  return value;
}

class Store216 {
  /**
   * @param {Box216<Model216>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project216} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model216} */
const model216 = {
  id: 216, name: "model-216", meta: { active: true, label: "meta-216" },
};
const preserved216 = preserve216(model216);
/** @type {Box216<Model216>} */
const box216 = { value: preserved216, label: "box-216" };
/** @type {Project216} */
const project216 = (input) => `${input.meta.label}:${input.name}`;
const store216 = new Store216(box216);
const rendered216 = store216.read(project216);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult216 = {
  id: preserved216.id,
  name: preserved216.name,
  active: preserved216.meta.active,
  rendered: rendered216,
};

/**
 * @typedef {object} Model217
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box217
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project217
 * @param {Model217} input
 * @returns {string}
 */

/**
 * @template {Model217} T
 * @param {T} value
 * @returns {T}
 */
function preserve217(value) {
  return value;
}

class Store217 {
  /**
   * @param {Box217<Model217>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project217} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model217} */
const model217 = {
  id: 217, name: "model-217", meta: { active: false, label: "meta-217" },
};
const preserved217 = preserve217(model217);
/** @type {Box217<Model217>} */
const box217 = { value: preserved217, label: "box-217" };
/** @type {Project217} */
const project217 = (input) => `${input.meta.label}:${input.name}`;
const store217 = new Store217(box217);
const rendered217 = store217.read(project217);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult217 = {
  id: preserved217.id,
  name: preserved217.name,
  active: preserved217.meta.active,
  rendered: rendered217,
};

/**
 * @typedef {object} Model218
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box218
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project218
 * @param {Model218} input
 * @returns {string}
 */

/**
 * @template {Model218} T
 * @param {T} value
 * @returns {T}
 */
function preserve218(value) {
  return value;
}

class Store218 {
  /**
   * @param {Box218<Model218>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project218} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model218} */
const model218 = {
  id: 218, name: "model-218", meta: { active: true, label: "meta-218" },
};
const preserved218 = preserve218(model218);
/** @type {Box218<Model218>} */
const box218 = { value: preserved218, label: "box-218" };
/** @type {Project218} */
const project218 = (input) => `${input.meta.label}:${input.name}`;
const store218 = new Store218(box218);
const rendered218 = store218.read(project218);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult218 = {
  id: preserved218.id,
  name: preserved218.name,
  active: preserved218.meta.active,
  rendered: rendered218,
};

/**
 * @typedef {object} Model219
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box219
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project219
 * @param {Model219} input
 * @returns {string}
 */

/**
 * @template {Model219} T
 * @param {T} value
 * @returns {T}
 */
function preserve219(value) {
  return value;
}

class Store219 {
  /**
   * @param {Box219<Model219>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project219} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model219} */
const model219 = {
  id: 219, name: "model-219", meta: { active: false, label: "meta-219" },
};
const preserved219 = preserve219(model219);
/** @type {Box219<Model219>} */
const box219 = { value: preserved219, label: "box-219" };
/** @type {Project219} */
const project219 = (input) => `${input.meta.label}:${input.name}`;
const store219 = new Store219(box219);
const rendered219 = store219.read(project219);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult219 = {
  id: preserved219.id,
  name: preserved219.name,
  active: preserved219.meta.active,
  rendered: rendered219,
};

/**
 * @typedef {object} Model220
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box220
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project220
 * @param {Model220} input
 * @returns {string}
 */

/**
 * @template {Model220} T
 * @param {T} value
 * @returns {T}
 */
function preserve220(value) {
  return value;
}

class Store220 {
  /**
   * @param {Box220<Model220>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project220} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model220} */
const model220 = {
  id: 220, name: "model-220", meta: { active: true, label: "meta-220" },
};
const preserved220 = preserve220(model220);
/** @type {Box220<Model220>} */
const box220 = { value: preserved220, label: "box-220" };
/** @type {Project220} */
const project220 = (input) => `${input.meta.label}:${input.name}`;
const store220 = new Store220(box220);
const rendered220 = store220.read(project220);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult220 = {
  id: preserved220.id,
  name: preserved220.name,
  active: preserved220.meta.active,
  rendered: rendered220,
};

/**
 * @typedef {object} Model221
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box221
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project221
 * @param {Model221} input
 * @returns {string}
 */

/**
 * @template {Model221} T
 * @param {T} value
 * @returns {T}
 */
function preserve221(value) {
  return value;
}

class Store221 {
  /**
   * @param {Box221<Model221>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project221} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model221} */
const model221 = {
  id: 221, name: "model-221", meta: { active: false, label: "meta-221" },
};
const preserved221 = preserve221(model221);
/** @type {Box221<Model221>} */
const box221 = { value: preserved221, label: "box-221" };
/** @type {Project221} */
const project221 = (input) => `${input.meta.label}:${input.name}`;
const store221 = new Store221(box221);
const rendered221 = store221.read(project221);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult221 = {
  id: preserved221.id,
  name: preserved221.name,
  active: preserved221.meta.active,
  rendered: rendered221,
};

/**
 * @typedef {object} Model222
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box222
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project222
 * @param {Model222} input
 * @returns {string}
 */

/**
 * @template {Model222} T
 * @param {T} value
 * @returns {T}
 */
function preserve222(value) {
  return value;
}

class Store222 {
  /**
   * @param {Box222<Model222>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project222} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model222} */
const model222 = {
  id: 222, name: "model-222", meta: { active: true, label: "meta-222" },
};
const preserved222 = preserve222(model222);
/** @type {Box222<Model222>} */
const box222 = { value: preserved222, label: "box-222" };
/** @type {Project222} */
const project222 = (input) => `${input.meta.label}:${input.name}`;
const store222 = new Store222(box222);
const rendered222 = store222.read(project222);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult222 = {
  id: preserved222.id,
  name: preserved222.name,
  active: preserved222.meta.active,
  rendered: rendered222,
};

/**
 * @typedef {object} Model223
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box223
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project223
 * @param {Model223} input
 * @returns {string}
 */

/**
 * @template {Model223} T
 * @param {T} value
 * @returns {T}
 */
function preserve223(value) {
  return value;
}

class Store223 {
  /**
   * @param {Box223<Model223>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project223} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model223} */
const model223 = {
  id: 223, name: "model-223", meta: { active: false, label: "meta-223" },
};
const preserved223 = preserve223(model223);
/** @type {Box223<Model223>} */
const box223 = { value: preserved223, label: "box-223" };
/** @type {Project223} */
const project223 = (input) => `${input.meta.label}:${input.name}`;
const store223 = new Store223(box223);
const rendered223 = store223.read(project223);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult223 = {
  id: preserved223.id,
  name: preserved223.name,
  active: preserved223.meta.active,
  rendered: rendered223,
};

/**
 * @typedef {object} Model224
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box224
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project224
 * @param {Model224} input
 * @returns {string}
 */

/**
 * @template {Model224} T
 * @param {T} value
 * @returns {T}
 */
function preserve224(value) {
  return value;
}

class Store224 {
  /**
   * @param {Box224<Model224>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project224} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model224} */
const model224 = {
  id: 224, name: "model-224", meta: { active: true, label: "meta-224" },
};
const preserved224 = preserve224(model224);
/** @type {Box224<Model224>} */
const box224 = { value: preserved224, label: "box-224" };
/** @type {Project224} */
const project224 = (input) => `${input.meta.label}:${input.name}`;
const store224 = new Store224(box224);
const rendered224 = store224.read(project224);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult224 = {
  id: preserved224.id,
  name: preserved224.name,
  active: preserved224.meta.active,
  rendered: rendered224,
};

/**
 * @typedef {object} Model225
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box225
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project225
 * @param {Model225} input
 * @returns {string}
 */

/**
 * @template {Model225} T
 * @param {T} value
 * @returns {T}
 */
function preserve225(value) {
  return value;
}

class Store225 {
  /**
   * @param {Box225<Model225>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project225} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model225} */
const model225 = {
  id: 225, name: "model-225", meta: { active: false, label: "meta-225" },
};
const preserved225 = preserve225(model225);
/** @type {Box225<Model225>} */
const box225 = { value: preserved225, label: "box-225" };
/** @type {Project225} */
const project225 = (input) => `${input.meta.label}:${input.name}`;
const store225 = new Store225(box225);
const rendered225 = store225.read(project225);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult225 = {
  id: preserved225.id,
  name: preserved225.name,
  active: preserved225.meta.active,
  rendered: rendered225,
};

/**
 * @typedef {object} Model226
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box226
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project226
 * @param {Model226} input
 * @returns {string}
 */

/**
 * @template {Model226} T
 * @param {T} value
 * @returns {T}
 */
function preserve226(value) {
  return value;
}

class Store226 {
  /**
   * @param {Box226<Model226>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project226} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model226} */
const model226 = {
  id: 226, name: "model-226", meta: { active: true, label: "meta-226" },
};
const preserved226 = preserve226(model226);
/** @type {Box226<Model226>} */
const box226 = { value: preserved226, label: "box-226" };
/** @type {Project226} */
const project226 = (input) => `${input.meta.label}:${input.name}`;
const store226 = new Store226(box226);
const rendered226 = store226.read(project226);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult226 = {
  id: preserved226.id,
  name: preserved226.name,
  active: preserved226.meta.active,
  rendered: rendered226,
};

/**
 * @typedef {object} Model227
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box227
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project227
 * @param {Model227} input
 * @returns {string}
 */

/**
 * @template {Model227} T
 * @param {T} value
 * @returns {T}
 */
function preserve227(value) {
  return value;
}

class Store227 {
  /**
   * @param {Box227<Model227>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project227} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model227} */
const model227 = {
  id: 227, name: "model-227", meta: { active: false, label: "meta-227" },
};
const preserved227 = preserve227(model227);
/** @type {Box227<Model227>} */
const box227 = { value: preserved227, label: "box-227" };
/** @type {Project227} */
const project227 = (input) => `${input.meta.label}:${input.name}`;
const store227 = new Store227(box227);
const rendered227 = store227.read(project227);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult227 = {
  id: preserved227.id,
  name: preserved227.name,
  active: preserved227.meta.active,
  rendered: rendered227,
};

/**
 * @typedef {object} Model228
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box228
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project228
 * @param {Model228} input
 * @returns {string}
 */

/**
 * @template {Model228} T
 * @param {T} value
 * @returns {T}
 */
function preserve228(value) {
  return value;
}

class Store228 {
  /**
   * @param {Box228<Model228>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project228} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model228} */
const model228 = {
  id: 228, name: "model-228", meta: { active: true, label: "meta-228" },
};
const preserved228 = preserve228(model228);
/** @type {Box228<Model228>} */
const box228 = { value: preserved228, label: "box-228" };
/** @type {Project228} */
const project228 = (input) => `${input.meta.label}:${input.name}`;
const store228 = new Store228(box228);
const rendered228 = store228.read(project228);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult228 = {
  id: preserved228.id,
  name: preserved228.name,
  active: preserved228.meta.active,
  rendered: rendered228,
};

/**
 * @typedef {object} Model229
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box229
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project229
 * @param {Model229} input
 * @returns {string}
 */

/**
 * @template {Model229} T
 * @param {T} value
 * @returns {T}
 */
function preserve229(value) {
  return value;
}

class Store229 {
  /**
   * @param {Box229<Model229>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project229} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model229} */
const model229 = {
  id: 229, name: "model-229", meta: { active: false, label: "meta-229" },
};
const preserved229 = preserve229(model229);
/** @type {Box229<Model229>} */
const box229 = { value: preserved229, label: "box-229" };
/** @type {Project229} */
const project229 = (input) => `${input.meta.label}:${input.name}`;
const store229 = new Store229(box229);
const rendered229 = store229.read(project229);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult229 = {
  id: preserved229.id,
  name: preserved229.name,
  active: preserved229.meta.active,
  rendered: rendered229,
};

/**
 * @typedef {object} Model230
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box230
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project230
 * @param {Model230} input
 * @returns {string}
 */

/**
 * @template {Model230} T
 * @param {T} value
 * @returns {T}
 */
function preserve230(value) {
  return value;
}

class Store230 {
  /**
   * @param {Box230<Model230>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project230} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model230} */
const model230 = {
  id: 230, name: "model-230", meta: { active: true, label: "meta-230" },
};
const preserved230 = preserve230(model230);
/** @type {Box230<Model230>} */
const box230 = { value: preserved230, label: "box-230" };
/** @type {Project230} */
const project230 = (input) => `${input.meta.label}:${input.name}`;
const store230 = new Store230(box230);
const rendered230 = store230.read(project230);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult230 = {
  id: preserved230.id,
  name: preserved230.name,
  active: preserved230.meta.active,
  rendered: rendered230,
};

/**
 * @typedef {object} Model231
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box231
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project231
 * @param {Model231} input
 * @returns {string}
 */

/**
 * @template {Model231} T
 * @param {T} value
 * @returns {T}
 */
function preserve231(value) {
  return value;
}

class Store231 {
  /**
   * @param {Box231<Model231>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project231} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model231} */
const model231 = {
  id: 231, name: "model-231", meta: { active: false, label: "meta-231" },
};
const preserved231 = preserve231(model231);
/** @type {Box231<Model231>} */
const box231 = { value: preserved231, label: "box-231" };
/** @type {Project231} */
const project231 = (input) => `${input.meta.label}:${input.name}`;
const store231 = new Store231(box231);
const rendered231 = store231.read(project231);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult231 = {
  id: preserved231.id,
  name: preserved231.name,
  active: preserved231.meta.active,
  rendered: rendered231,
};

/**
 * @typedef {object} Model232
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box232
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project232
 * @param {Model232} input
 * @returns {string}
 */

/**
 * @template {Model232} T
 * @param {T} value
 * @returns {T}
 */
function preserve232(value) {
  return value;
}

class Store232 {
  /**
   * @param {Box232<Model232>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project232} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model232} */
const model232 = {
  id: 232, name: "model-232", meta: { active: true, label: "meta-232" },
};
const preserved232 = preserve232(model232);
/** @type {Box232<Model232>} */
const box232 = { value: preserved232, label: "box-232" };
/** @type {Project232} */
const project232 = (input) => `${input.meta.label}:${input.name}`;
const store232 = new Store232(box232);
const rendered232 = store232.read(project232);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult232 = {
  id: preserved232.id,
  name: preserved232.name,
  active: preserved232.meta.active,
  rendered: rendered232,
};

/**
 * @typedef {object} Model233
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box233
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project233
 * @param {Model233} input
 * @returns {string}
 */

/**
 * @template {Model233} T
 * @param {T} value
 * @returns {T}
 */
function preserve233(value) {
  return value;
}

class Store233 {
  /**
   * @param {Box233<Model233>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project233} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model233} */
const model233 = {
  id: 233, name: "model-233", meta: { active: false, label: "meta-233" },
};
const preserved233 = preserve233(model233);
/** @type {Box233<Model233>} */
const box233 = { value: preserved233, label: "box-233" };
/** @type {Project233} */
const project233 = (input) => `${input.meta.label}:${input.name}`;
const store233 = new Store233(box233);
const rendered233 = store233.read(project233);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult233 = {
  id: preserved233.id,
  name: preserved233.name,
  active: preserved233.meta.active,
  rendered: rendered233,
};

/**
 * @typedef {object} Model234
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box234
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project234
 * @param {Model234} input
 * @returns {string}
 */

/**
 * @template {Model234} T
 * @param {T} value
 * @returns {T}
 */
function preserve234(value) {
  return value;
}

class Store234 {
  /**
   * @param {Box234<Model234>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project234} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model234} */
const model234 = {
  id: 234, name: "model-234", meta: { active: true, label: "meta-234" },
};
const preserved234 = preserve234(model234);
/** @type {Box234<Model234>} */
const box234 = { value: preserved234, label: "box-234" };
/** @type {Project234} */
const project234 = (input) => `${input.meta.label}:${input.name}`;
const store234 = new Store234(box234);
const rendered234 = store234.read(project234);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult234 = {
  id: preserved234.id,
  name: preserved234.name,
  active: preserved234.meta.active,
  rendered: rendered234,
};

/**
 * @typedef {object} Model235
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box235
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project235
 * @param {Model235} input
 * @returns {string}
 */

/**
 * @template {Model235} T
 * @param {T} value
 * @returns {T}
 */
function preserve235(value) {
  return value;
}

class Store235 {
  /**
   * @param {Box235<Model235>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project235} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model235} */
const model235 = {
  id: 235, name: "model-235", meta: { active: false, label: "meta-235" },
};
const preserved235 = preserve235(model235);
/** @type {Box235<Model235>} */
const box235 = { value: preserved235, label: "box-235" };
/** @type {Project235} */
const project235 = (input) => `${input.meta.label}:${input.name}`;
const store235 = new Store235(box235);
const rendered235 = store235.read(project235);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult235 = {
  id: preserved235.id,
  name: preserved235.name,
  active: preserved235.meta.active,
  rendered: rendered235,
};

/**
 * @typedef {object} Model236
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box236
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project236
 * @param {Model236} input
 * @returns {string}
 */

/**
 * @template {Model236} T
 * @param {T} value
 * @returns {T}
 */
function preserve236(value) {
  return value;
}

class Store236 {
  /**
   * @param {Box236<Model236>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project236} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model236} */
const model236 = {
  id: 236, name: "model-236", meta: { active: true, label: "meta-236" },
};
const preserved236 = preserve236(model236);
/** @type {Box236<Model236>} */
const box236 = { value: preserved236, label: "box-236" };
/** @type {Project236} */
const project236 = (input) => `${input.meta.label}:${input.name}`;
const store236 = new Store236(box236);
const rendered236 = store236.read(project236);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult236 = {
  id: preserved236.id,
  name: preserved236.name,
  active: preserved236.meta.active,
  rendered: rendered236,
};

/**
 * @typedef {object} Model237
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box237
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project237
 * @param {Model237} input
 * @returns {string}
 */

/**
 * @template {Model237} T
 * @param {T} value
 * @returns {T}
 */
function preserve237(value) {
  return value;
}

class Store237 {
  /**
   * @param {Box237<Model237>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project237} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model237} */
const model237 = {
  id: 237, name: "model-237", meta: { active: false, label: "meta-237" },
};
const preserved237 = preserve237(model237);
/** @type {Box237<Model237>} */
const box237 = { value: preserved237, label: "box-237" };
/** @type {Project237} */
const project237 = (input) => `${input.meta.label}:${input.name}`;
const store237 = new Store237(box237);
const rendered237 = store237.read(project237);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult237 = {
  id: preserved237.id,
  name: preserved237.name,
  active: preserved237.meta.active,
  rendered: rendered237,
};

/**
 * @typedef {object} Model238
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box238
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project238
 * @param {Model238} input
 * @returns {string}
 */

/**
 * @template {Model238} T
 * @param {T} value
 * @returns {T}
 */
function preserve238(value) {
  return value;
}

class Store238 {
  /**
   * @param {Box238<Model238>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project238} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model238} */
const model238 = {
  id: 238, name: "model-238", meta: { active: true, label: "meta-238" },
};
const preserved238 = preserve238(model238);
/** @type {Box238<Model238>} */
const box238 = { value: preserved238, label: "box-238" };
/** @type {Project238} */
const project238 = (input) => `${input.meta.label}:${input.name}`;
const store238 = new Store238(box238);
const rendered238 = store238.read(project238);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult238 = {
  id: preserved238.id,
  name: preserved238.name,
  active: preserved238.meta.active,
  rendered: rendered238,
};

/**
 * @typedef {object} Model239
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box239
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project239
 * @param {Model239} input
 * @returns {string}
 */

/**
 * @template {Model239} T
 * @param {T} value
 * @returns {T}
 */
function preserve239(value) {
  return value;
}

class Store239 {
  /**
   * @param {Box239<Model239>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project239} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model239} */
const model239 = {
  id: 239, name: "model-239", meta: { active: false, label: "meta-239" },
};
const preserved239 = preserve239(model239);
/** @type {Box239<Model239>} */
const box239 = { value: preserved239, label: "box-239" };
/** @type {Project239} */
const project239 = (input) => `${input.meta.label}:${input.name}`;
const store239 = new Store239(box239);
const rendered239 = store239.read(project239);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult239 = {
  id: preserved239.id,
  name: preserved239.name,
  active: preserved239.meta.active,
  rendered: rendered239,
};

/**
 * @typedef {object} Model240
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box240
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project240
 * @param {Model240} input
 * @returns {string}
 */

/**
 * @template {Model240} T
 * @param {T} value
 * @returns {T}
 */
function preserve240(value) {
  return value;
}

class Store240 {
  /**
   * @param {Box240<Model240>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project240} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model240} */
const model240 = {
  id: 240, name: "model-240", meta: { active: true, label: "meta-240" },
};
const preserved240 = preserve240(model240);
/** @type {Box240<Model240>} */
const box240 = { value: preserved240, label: "box-240" };
/** @type {Project240} */
const project240 = (input) => `${input.meta.label}:${input.name}`;
const store240 = new Store240(box240);
const rendered240 = store240.read(project240);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult240 = {
  id: preserved240.id,
  name: preserved240.name,
  active: preserved240.meta.active,
  rendered: rendered240,
};

/**
 * @typedef {object} Model241
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box241
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project241
 * @param {Model241} input
 * @returns {string}
 */

/**
 * @template {Model241} T
 * @param {T} value
 * @returns {T}
 */
function preserve241(value) {
  return value;
}

class Store241 {
  /**
   * @param {Box241<Model241>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project241} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model241} */
const model241 = {
  id: 241, name: "model-241", meta: { active: false, label: "meta-241" },
};
const preserved241 = preserve241(model241);
/** @type {Box241<Model241>} */
const box241 = { value: preserved241, label: "box-241" };
/** @type {Project241} */
const project241 = (input) => `${input.meta.label}:${input.name}`;
const store241 = new Store241(box241);
const rendered241 = store241.read(project241);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult241 = {
  id: preserved241.id,
  name: preserved241.name,
  active: preserved241.meta.active,
  rendered: rendered241,
};

/**
 * @typedef {object} Model242
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box242
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project242
 * @param {Model242} input
 * @returns {string}
 */

/**
 * @template {Model242} T
 * @param {T} value
 * @returns {T}
 */
function preserve242(value) {
  return value;
}

class Store242 {
  /**
   * @param {Box242<Model242>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project242} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model242} */
const model242 = {
  id: 242, name: "model-242", meta: { active: true, label: "meta-242" },
};
const preserved242 = preserve242(model242);
/** @type {Box242<Model242>} */
const box242 = { value: preserved242, label: "box-242" };
/** @type {Project242} */
const project242 = (input) => `${input.meta.label}:${input.name}`;
const store242 = new Store242(box242);
const rendered242 = store242.read(project242);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult242 = {
  id: preserved242.id,
  name: preserved242.name,
  active: preserved242.meta.active,
  rendered: rendered242,
};

/**
 * @typedef {object} Model243
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box243
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project243
 * @param {Model243} input
 * @returns {string}
 */

/**
 * @template {Model243} T
 * @param {T} value
 * @returns {T}
 */
function preserve243(value) {
  return value;
}

class Store243 {
  /**
   * @param {Box243<Model243>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project243} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model243} */
const model243 = {
  id: 243, name: "model-243", meta: { active: false, label: "meta-243" },
};
const preserved243 = preserve243(model243);
/** @type {Box243<Model243>} */
const box243 = { value: preserved243, label: "box-243" };
/** @type {Project243} */
const project243 = (input) => `${input.meta.label}:${input.name}`;
const store243 = new Store243(box243);
const rendered243 = store243.read(project243);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult243 = {
  id: preserved243.id,
  name: preserved243.name,
  active: preserved243.meta.active,
  rendered: rendered243,
};

/**
 * @typedef {object} Model244
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box244
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project244
 * @param {Model244} input
 * @returns {string}
 */

/**
 * @template {Model244} T
 * @param {T} value
 * @returns {T}
 */
function preserve244(value) {
  return value;
}

class Store244 {
  /**
   * @param {Box244<Model244>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project244} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model244} */
const model244 = {
  id: 244, name: "model-244", meta: { active: true, label: "meta-244" },
};
const preserved244 = preserve244(model244);
/** @type {Box244<Model244>} */
const box244 = { value: preserved244, label: "box-244" };
/** @type {Project244} */
const project244 = (input) => `${input.meta.label}:${input.name}`;
const store244 = new Store244(box244);
const rendered244 = store244.read(project244);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult244 = {
  id: preserved244.id,
  name: preserved244.name,
  active: preserved244.meta.active,
  rendered: rendered244,
};

/**
 * @typedef {object} Model245
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box245
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project245
 * @param {Model245} input
 * @returns {string}
 */

/**
 * @template {Model245} T
 * @param {T} value
 * @returns {T}
 */
function preserve245(value) {
  return value;
}

class Store245 {
  /**
   * @param {Box245<Model245>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project245} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model245} */
const model245 = {
  id: 245, name: "model-245", meta: { active: false, label: "meta-245" },
};
const preserved245 = preserve245(model245);
/** @type {Box245<Model245>} */
const box245 = { value: preserved245, label: "box-245" };
/** @type {Project245} */
const project245 = (input) => `${input.meta.label}:${input.name}`;
const store245 = new Store245(box245);
const rendered245 = store245.read(project245);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult245 = {
  id: preserved245.id,
  name: preserved245.name,
  active: preserved245.meta.active,
  rendered: rendered245,
};

/**
 * @typedef {object} Model246
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box246
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project246
 * @param {Model246} input
 * @returns {string}
 */

/**
 * @template {Model246} T
 * @param {T} value
 * @returns {T}
 */
function preserve246(value) {
  return value;
}

class Store246 {
  /**
   * @param {Box246<Model246>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project246} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model246} */
const model246 = {
  id: 246, name: "model-246", meta: { active: true, label: "meta-246" },
};
const preserved246 = preserve246(model246);
/** @type {Box246<Model246>} */
const box246 = { value: preserved246, label: "box-246" };
/** @type {Project246} */
const project246 = (input) => `${input.meta.label}:${input.name}`;
const store246 = new Store246(box246);
const rendered246 = store246.read(project246);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult246 = {
  id: preserved246.id,
  name: preserved246.name,
  active: preserved246.meta.active,
  rendered: rendered246,
};

/**
 * @typedef {object} Model247
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box247
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project247
 * @param {Model247} input
 * @returns {string}
 */

/**
 * @template {Model247} T
 * @param {T} value
 * @returns {T}
 */
function preserve247(value) {
  return value;
}

class Store247 {
  /**
   * @param {Box247<Model247>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project247} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model247} */
const model247 = {
  id: 247, name: "model-247", meta: { active: false, label: "meta-247" },
};
const preserved247 = preserve247(model247);
/** @type {Box247<Model247>} */
const box247 = { value: preserved247, label: "box-247" };
/** @type {Project247} */
const project247 = (input) => `${input.meta.label}:${input.name}`;
const store247 = new Store247(box247);
const rendered247 = store247.read(project247);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult247 = {
  id: preserved247.id,
  name: preserved247.name,
  active: preserved247.meta.active,
  rendered: rendered247,
};

/**
 * @typedef {object} Model248
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box248
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project248
 * @param {Model248} input
 * @returns {string}
 */

/**
 * @template {Model248} T
 * @param {T} value
 * @returns {T}
 */
function preserve248(value) {
  return value;
}

class Store248 {
  /**
   * @param {Box248<Model248>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project248} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model248} */
const model248 = {
  id: 248, name: "model-248", meta: { active: true, label: "meta-248" },
};
const preserved248 = preserve248(model248);
/** @type {Box248<Model248>} */
const box248 = { value: preserved248, label: "box-248" };
/** @type {Project248} */
const project248 = (input) => `${input.meta.label}:${input.name}`;
const store248 = new Store248(box248);
const rendered248 = store248.read(project248);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult248 = {
  id: preserved248.id,
  name: preserved248.name,
  active: preserved248.meta.active,
  rendered: rendered248,
};

/**
 * @typedef {object} Model249
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box249
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project249
 * @param {Model249} input
 * @returns {string}
 */

/**
 * @template {Model249} T
 * @param {T} value
 * @returns {T}
 */
function preserve249(value) {
  return value;
}

class Store249 {
  /**
   * @param {Box249<Model249>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project249} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model249} */
const model249 = {
  id: 249, name: "model-249", meta: { active: false, label: "meta-249" },
};
const preserved249 = preserve249(model249);
/** @type {Box249<Model249>} */
const box249 = { value: preserved249, label: "box-249" };
/** @type {Project249} */
const project249 = (input) => `${input.meta.label}:${input.name}`;
const store249 = new Store249(box249);
const rendered249 = store249.read(project249);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult249 = {
  id: preserved249.id,
  name: preserved249.name,
  active: preserved249.meta.active,
  rendered: rendered249,
};

/**
 * @typedef {object} Model250
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box250
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project250
 * @param {Model250} input
 * @returns {string}
 */

/**
 * @template {Model250} T
 * @param {T} value
 * @returns {T}
 */
function preserve250(value) {
  return value;
}

class Store250 {
  /**
   * @param {Box250<Model250>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project250} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model250} */
const model250 = {
  id: 250, name: "model-250", meta: { active: true, label: "meta-250" },
};
const preserved250 = preserve250(model250);
/** @type {Box250<Model250>} */
const box250 = { value: preserved250, label: "box-250" };
/** @type {Project250} */
const project250 = (input) => `${input.meta.label}:${input.name}`;
const store250 = new Store250(box250);
const rendered250 = store250.read(project250);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult250 = {
  id: preserved250.id,
  name: preserved250.name,
  active: preserved250.meta.active,
  rendered: rendered250,
};

/**
 * @typedef {object} Model251
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box251
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project251
 * @param {Model251} input
 * @returns {string}
 */

/**
 * @template {Model251} T
 * @param {T} value
 * @returns {T}
 */
function preserve251(value) {
  return value;
}

class Store251 {
  /**
   * @param {Box251<Model251>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project251} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model251} */
const model251 = {
  id: 251, name: "model-251", meta: { active: false, label: "meta-251" },
};
const preserved251 = preserve251(model251);
/** @type {Box251<Model251>} */
const box251 = { value: preserved251, label: "box-251" };
/** @type {Project251} */
const project251 = (input) => `${input.meta.label}:${input.name}`;
const store251 = new Store251(box251);
const rendered251 = store251.read(project251);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult251 = {
  id: preserved251.id,
  name: preserved251.name,
  active: preserved251.meta.active,
  rendered: rendered251,
};

/**
 * @typedef {object} Model252
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box252
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project252
 * @param {Model252} input
 * @returns {string}
 */

/**
 * @template {Model252} T
 * @param {T} value
 * @returns {T}
 */
function preserve252(value) {
  return value;
}

class Store252 {
  /**
   * @param {Box252<Model252>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project252} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model252} */
const model252 = {
  id: 252, name: "model-252", meta: { active: true, label: "meta-252" },
};
const preserved252 = preserve252(model252);
/** @type {Box252<Model252>} */
const box252 = { value: preserved252, label: "box-252" };
/** @type {Project252} */
const project252 = (input) => `${input.meta.label}:${input.name}`;
const store252 = new Store252(box252);
const rendered252 = store252.read(project252);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult252 = {
  id: preserved252.id,
  name: preserved252.name,
  active: preserved252.meta.active,
  rendered: rendered252,
};

/**
 * @typedef {object} Model253
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box253
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project253
 * @param {Model253} input
 * @returns {string}
 */

/**
 * @template {Model253} T
 * @param {T} value
 * @returns {T}
 */
function preserve253(value) {
  return value;
}

class Store253 {
  /**
   * @param {Box253<Model253>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project253} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model253} */
const model253 = {
  id: 253, name: "model-253", meta: { active: false, label: "meta-253" },
};
const preserved253 = preserve253(model253);
/** @type {Box253<Model253>} */
const box253 = { value: preserved253, label: "box-253" };
/** @type {Project253} */
const project253 = (input) => `${input.meta.label}:${input.name}`;
const store253 = new Store253(box253);
const rendered253 = store253.read(project253);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult253 = {
  id: preserved253.id,
  name: preserved253.name,
  active: preserved253.meta.active,
  rendered: rendered253,
};

/**
 * @typedef {object} Model254
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box254
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project254
 * @param {Model254} input
 * @returns {string}
 */

/**
 * @template {Model254} T
 * @param {T} value
 * @returns {T}
 */
function preserve254(value) {
  return value;
}

class Store254 {
  /**
   * @param {Box254<Model254>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project254} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model254} */
const model254 = {
  id: 254, name: "model-254", meta: { active: true, label: "meta-254" },
};
const preserved254 = preserve254(model254);
/** @type {Box254<Model254>} */
const box254 = { value: preserved254, label: "box-254" };
/** @type {Project254} */
const project254 = (input) => `${input.meta.label}:${input.name}`;
const store254 = new Store254(box254);
const rendered254 = store254.read(project254);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult254 = {
  id: preserved254.id,
  name: preserved254.name,
  active: preserved254.meta.active,
  rendered: rendered254,
};

/**
 * @typedef {object} Model255
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box255
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project255
 * @param {Model255} input
 * @returns {string}
 */

/**
 * @template {Model255} T
 * @param {T} value
 * @returns {T}
 */
function preserve255(value) {
  return value;
}

class Store255 {
  /**
   * @param {Box255<Model255>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project255} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model255} */
const model255 = {
  id: 255, name: "model-255", meta: { active: false, label: "meta-255" },
};
const preserved255 = preserve255(model255);
/** @type {Box255<Model255>} */
const box255 = { value: preserved255, label: "box-255" };
/** @type {Project255} */
const project255 = (input) => `${input.meta.label}:${input.name}`;
const store255 = new Store255(box255);
const rendered255 = store255.read(project255);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult255 = {
  id: preserved255.id,
  name: preserved255.name,
  active: preserved255.meta.active,
  rendered: rendered255,
};

/**
 * @typedef {object} Model256
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box256
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project256
 * @param {Model256} input
 * @returns {string}
 */

/**
 * @template {Model256} T
 * @param {T} value
 * @returns {T}
 */
function preserve256(value) {
  return value;
}

class Store256 {
  /**
   * @param {Box256<Model256>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project256} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model256} */
const model256 = {
  id: 256, name: "model-256", meta: { active: true, label: "meta-256" },
};
const preserved256 = preserve256(model256);
/** @type {Box256<Model256>} */
const box256 = { value: preserved256, label: "box-256" };
/** @type {Project256} */
const project256 = (input) => `${input.meta.label}:${input.name}`;
const store256 = new Store256(box256);
const rendered256 = store256.read(project256);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult256 = {
  id: preserved256.id,
  name: preserved256.name,
  active: preserved256.meta.active,
  rendered: rendered256,
};

/**
 * @typedef {object} Model257
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box257
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project257
 * @param {Model257} input
 * @returns {string}
 */

/**
 * @template {Model257} T
 * @param {T} value
 * @returns {T}
 */
function preserve257(value) {
  return value;
}

class Store257 {
  /**
   * @param {Box257<Model257>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project257} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model257} */
const model257 = {
  id: 257, name: "model-257", meta: { active: false, label: "meta-257" },
};
const preserved257 = preserve257(model257);
/** @type {Box257<Model257>} */
const box257 = { value: preserved257, label: "box-257" };
/** @type {Project257} */
const project257 = (input) => `${input.meta.label}:${input.name}`;
const store257 = new Store257(box257);
const rendered257 = store257.read(project257);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult257 = {
  id: preserved257.id,
  name: preserved257.name,
  active: preserved257.meta.active,
  rendered: rendered257,
};

/**
 * @typedef {object} Model258
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box258
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project258
 * @param {Model258} input
 * @returns {string}
 */

/**
 * @template {Model258} T
 * @param {T} value
 * @returns {T}
 */
function preserve258(value) {
  return value;
}

class Store258 {
  /**
   * @param {Box258<Model258>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project258} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model258} */
const model258 = {
  id: 258, name: "model-258", meta: { active: true, label: "meta-258" },
};
const preserved258 = preserve258(model258);
/** @type {Box258<Model258>} */
const box258 = { value: preserved258, label: "box-258" };
/** @type {Project258} */
const project258 = (input) => `${input.meta.label}:${input.name}`;
const store258 = new Store258(box258);
const rendered258 = store258.read(project258);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult258 = {
  id: preserved258.id,
  name: preserved258.name,
  active: preserved258.meta.active,
  rendered: rendered258,
};

/**
 * @typedef {object} Model259
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box259
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project259
 * @param {Model259} input
 * @returns {string}
 */

/**
 * @template {Model259} T
 * @param {T} value
 * @returns {T}
 */
function preserve259(value) {
  return value;
}

class Store259 {
  /**
   * @param {Box259<Model259>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project259} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model259} */
const model259 = {
  id: 259, name: "model-259", meta: { active: false, label: "meta-259" },
};
const preserved259 = preserve259(model259);
/** @type {Box259<Model259>} */
const box259 = { value: preserved259, label: "box-259" };
/** @type {Project259} */
const project259 = (input) => `${input.meta.label}:${input.name}`;
const store259 = new Store259(box259);
const rendered259 = store259.read(project259);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult259 = {
  id: preserved259.id,
  name: preserved259.name,
  active: preserved259.meta.active,
  rendered: rendered259,
};

/**
 * @typedef {object} Model260
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box260
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project260
 * @param {Model260} input
 * @returns {string}
 */

/**
 * @template {Model260} T
 * @param {T} value
 * @returns {T}
 */
function preserve260(value) {
  return value;
}

class Store260 {
  /**
   * @param {Box260<Model260>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project260} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model260} */
const model260 = {
  id: 260, name: "model-260", meta: { active: true, label: "meta-260" },
};
const preserved260 = preserve260(model260);
/** @type {Box260<Model260>} */
const box260 = { value: preserved260, label: "box-260" };
/** @type {Project260} */
const project260 = (input) => `${input.meta.label}:${input.name}`;
const store260 = new Store260(box260);
const rendered260 = store260.read(project260);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult260 = {
  id: preserved260.id,
  name: preserved260.name,
  active: preserved260.meta.active,
  rendered: rendered260,
};

/**
 * @typedef {object} Model261
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box261
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project261
 * @param {Model261} input
 * @returns {string}
 */

/**
 * @template {Model261} T
 * @param {T} value
 * @returns {T}
 */
function preserve261(value) {
  return value;
}

class Store261 {
  /**
   * @param {Box261<Model261>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project261} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model261} */
const model261 = {
  id: 261, name: "model-261", meta: { active: false, label: "meta-261" },
};
const preserved261 = preserve261(model261);
/** @type {Box261<Model261>} */
const box261 = { value: preserved261, label: "box-261" };
/** @type {Project261} */
const project261 = (input) => `${input.meta.label}:${input.name}`;
const store261 = new Store261(box261);
const rendered261 = store261.read(project261);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult261 = {
  id: preserved261.id,
  name: preserved261.name,
  active: preserved261.meta.active,
  rendered: rendered261,
};

/**
 * @typedef {object} Model262
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box262
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project262
 * @param {Model262} input
 * @returns {string}
 */

/**
 * @template {Model262} T
 * @param {T} value
 * @returns {T}
 */
function preserve262(value) {
  return value;
}

class Store262 {
  /**
   * @param {Box262<Model262>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project262} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model262} */
const model262 = {
  id: 262, name: "model-262", meta: { active: true, label: "meta-262" },
};
const preserved262 = preserve262(model262);
/** @type {Box262<Model262>} */
const box262 = { value: preserved262, label: "box-262" };
/** @type {Project262} */
const project262 = (input) => `${input.meta.label}:${input.name}`;
const store262 = new Store262(box262);
const rendered262 = store262.read(project262);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult262 = {
  id: preserved262.id,
  name: preserved262.name,
  active: preserved262.meta.active,
  rendered: rendered262,
};

/**
 * @typedef {object} Model263
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box263
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project263
 * @param {Model263} input
 * @returns {string}
 */

/**
 * @template {Model263} T
 * @param {T} value
 * @returns {T}
 */
function preserve263(value) {
  return value;
}

class Store263 {
  /**
   * @param {Box263<Model263>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project263} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model263} */
const model263 = {
  id: 263, name: "model-263", meta: { active: false, label: "meta-263" },
};
const preserved263 = preserve263(model263);
/** @type {Box263<Model263>} */
const box263 = { value: preserved263, label: "box-263" };
/** @type {Project263} */
const project263 = (input) => `${input.meta.label}:${input.name}`;
const store263 = new Store263(box263);
const rendered263 = store263.read(project263);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult263 = {
  id: preserved263.id,
  name: preserved263.name,
  active: preserved263.meta.active,
  rendered: rendered263,
};

/**
 * @typedef {object} Model264
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box264
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project264
 * @param {Model264} input
 * @returns {string}
 */

/**
 * @template {Model264} T
 * @param {T} value
 * @returns {T}
 */
function preserve264(value) {
  return value;
}

class Store264 {
  /**
   * @param {Box264<Model264>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project264} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model264} */
const model264 = {
  id: 264, name: "model-264", meta: { active: true, label: "meta-264" },
};
const preserved264 = preserve264(model264);
/** @type {Box264<Model264>} */
const box264 = { value: preserved264, label: "box-264" };
/** @type {Project264} */
const project264 = (input) => `${input.meta.label}:${input.name}`;
const store264 = new Store264(box264);
const rendered264 = store264.read(project264);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult264 = {
  id: preserved264.id,
  name: preserved264.name,
  active: preserved264.meta.active,
  rendered: rendered264,
};

/**
 * @typedef {object} Model265
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box265
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project265
 * @param {Model265} input
 * @returns {string}
 */

/**
 * @template {Model265} T
 * @param {T} value
 * @returns {T}
 */
function preserve265(value) {
  return value;
}

class Store265 {
  /**
   * @param {Box265<Model265>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project265} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model265} */
const model265 = {
  id: 265, name: "model-265", meta: { active: false, label: "meta-265" },
};
const preserved265 = preserve265(model265);
/** @type {Box265<Model265>} */
const box265 = { value: preserved265, label: "box-265" };
/** @type {Project265} */
const project265 = (input) => `${input.meta.label}:${input.name}`;
const store265 = new Store265(box265);
const rendered265 = store265.read(project265);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult265 = {
  id: preserved265.id,
  name: preserved265.name,
  active: preserved265.meta.active,
  rendered: rendered265,
};

/**
 * @typedef {object} Model266
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box266
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project266
 * @param {Model266} input
 * @returns {string}
 */

/**
 * @template {Model266} T
 * @param {T} value
 * @returns {T}
 */
function preserve266(value) {
  return value;
}

class Store266 {
  /**
   * @param {Box266<Model266>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project266} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model266} */
const model266 = {
  id: 266, name: "model-266", meta: { active: true, label: "meta-266" },
};
const preserved266 = preserve266(model266);
/** @type {Box266<Model266>} */
const box266 = { value: preserved266, label: "box-266" };
/** @type {Project266} */
const project266 = (input) => `${input.meta.label}:${input.name}`;
const store266 = new Store266(box266);
const rendered266 = store266.read(project266);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult266 = {
  id: preserved266.id,
  name: preserved266.name,
  active: preserved266.meta.active,
  rendered: rendered266,
};

/**
 * @typedef {object} Model267
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box267
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project267
 * @param {Model267} input
 * @returns {string}
 */

/**
 * @template {Model267} T
 * @param {T} value
 * @returns {T}
 */
function preserve267(value) {
  return value;
}

class Store267 {
  /**
   * @param {Box267<Model267>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project267} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model267} */
const model267 = {
  id: 267, name: "model-267", meta: { active: false, label: "meta-267" },
};
const preserved267 = preserve267(model267);
/** @type {Box267<Model267>} */
const box267 = { value: preserved267, label: "box-267" };
/** @type {Project267} */
const project267 = (input) => `${input.meta.label}:${input.name}`;
const store267 = new Store267(box267);
const rendered267 = store267.read(project267);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult267 = {
  id: preserved267.id,
  name: preserved267.name,
  active: preserved267.meta.active,
  rendered: rendered267,
};

/**
 * @typedef {object} Model268
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box268
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project268
 * @param {Model268} input
 * @returns {string}
 */

/**
 * @template {Model268} T
 * @param {T} value
 * @returns {T}
 */
function preserve268(value) {
  return value;
}

class Store268 {
  /**
   * @param {Box268<Model268>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project268} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model268} */
const model268 = {
  id: 268, name: "model-268", meta: { active: true, label: "meta-268" },
};
const preserved268 = preserve268(model268);
/** @type {Box268<Model268>} */
const box268 = { value: preserved268, label: "box-268" };
/** @type {Project268} */
const project268 = (input) => `${input.meta.label}:${input.name}`;
const store268 = new Store268(box268);
const rendered268 = store268.read(project268);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult268 = {
  id: preserved268.id,
  name: preserved268.name,
  active: preserved268.meta.active,
  rendered: rendered268,
};

/**
 * @typedef {object} Model269
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box269
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project269
 * @param {Model269} input
 * @returns {string}
 */

/**
 * @template {Model269} T
 * @param {T} value
 * @returns {T}
 */
function preserve269(value) {
  return value;
}

class Store269 {
  /**
   * @param {Box269<Model269>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project269} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model269} */
const model269 = {
  id: 269, name: "model-269", meta: { active: false, label: "meta-269" },
};
const preserved269 = preserve269(model269);
/** @type {Box269<Model269>} */
const box269 = { value: preserved269, label: "box-269" };
/** @type {Project269} */
const project269 = (input) => `${input.meta.label}:${input.name}`;
const store269 = new Store269(box269);
const rendered269 = store269.read(project269);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult269 = {
  id: preserved269.id,
  name: preserved269.name,
  active: preserved269.meta.active,
  rendered: rendered269,
};

/**
 * @typedef {object} Model270
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box270
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project270
 * @param {Model270} input
 * @returns {string}
 */

/**
 * @template {Model270} T
 * @param {T} value
 * @returns {T}
 */
function preserve270(value) {
  return value;
}

class Store270 {
  /**
   * @param {Box270<Model270>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project270} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model270} */
const model270 = {
  id: 270, name: "model-270", meta: { active: true, label: "meta-270" },
};
const preserved270 = preserve270(model270);
/** @type {Box270<Model270>} */
const box270 = { value: preserved270, label: "box-270" };
/** @type {Project270} */
const project270 = (input) => `${input.meta.label}:${input.name}`;
const store270 = new Store270(box270);
const rendered270 = store270.read(project270);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult270 = {
  id: preserved270.id,
  name: preserved270.name,
  active: preserved270.meta.active,
  rendered: rendered270,
};

/**
 * @typedef {object} Model271
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box271
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project271
 * @param {Model271} input
 * @returns {string}
 */

/**
 * @template {Model271} T
 * @param {T} value
 * @returns {T}
 */
function preserve271(value) {
  return value;
}

class Store271 {
  /**
   * @param {Box271<Model271>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project271} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model271} */
const model271 = {
  id: 271, name: "model-271", meta: { active: false, label: "meta-271" },
};
const preserved271 = preserve271(model271);
/** @type {Box271<Model271>} */
const box271 = { value: preserved271, label: "box-271" };
/** @type {Project271} */
const project271 = (input) => `${input.meta.label}:${input.name}`;
const store271 = new Store271(box271);
const rendered271 = store271.read(project271);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult271 = {
  id: preserved271.id,
  name: preserved271.name,
  active: preserved271.meta.active,
  rendered: rendered271,
};

/**
 * @typedef {object} Model272
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box272
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project272
 * @param {Model272} input
 * @returns {string}
 */

/**
 * @template {Model272} T
 * @param {T} value
 * @returns {T}
 */
function preserve272(value) {
  return value;
}

class Store272 {
  /**
   * @param {Box272<Model272>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project272} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model272} */
const model272 = {
  id: 272, name: "model-272", meta: { active: true, label: "meta-272" },
};
const preserved272 = preserve272(model272);
/** @type {Box272<Model272>} */
const box272 = { value: preserved272, label: "box-272" };
/** @type {Project272} */
const project272 = (input) => `${input.meta.label}:${input.name}`;
const store272 = new Store272(box272);
const rendered272 = store272.read(project272);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult272 = {
  id: preserved272.id,
  name: preserved272.name,
  active: preserved272.meta.active,
  rendered: rendered272,
};

/**
 * @typedef {object} Model273
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box273
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project273
 * @param {Model273} input
 * @returns {string}
 */

/**
 * @template {Model273} T
 * @param {T} value
 * @returns {T}
 */
function preserve273(value) {
  return value;
}

class Store273 {
  /**
   * @param {Box273<Model273>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project273} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model273} */
const model273 = {
  id: 273, name: "model-273", meta: { active: false, label: "meta-273" },
};
const preserved273 = preserve273(model273);
/** @type {Box273<Model273>} */
const box273 = { value: preserved273, label: "box-273" };
/** @type {Project273} */
const project273 = (input) => `${input.meta.label}:${input.name}`;
const store273 = new Store273(box273);
const rendered273 = store273.read(project273);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult273 = {
  id: preserved273.id,
  name: preserved273.name,
  active: preserved273.meta.active,
  rendered: rendered273,
};

/**
 * @typedef {object} Model274
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box274
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project274
 * @param {Model274} input
 * @returns {string}
 */

/**
 * @template {Model274} T
 * @param {T} value
 * @returns {T}
 */
function preserve274(value) {
  return value;
}

class Store274 {
  /**
   * @param {Box274<Model274>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project274} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model274} */
const model274 = {
  id: 274, name: "model-274", meta: { active: true, label: "meta-274" },
};
const preserved274 = preserve274(model274);
/** @type {Box274<Model274>} */
const box274 = { value: preserved274, label: "box-274" };
/** @type {Project274} */
const project274 = (input) => `${input.meta.label}:${input.name}`;
const store274 = new Store274(box274);
const rendered274 = store274.read(project274);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult274 = {
  id: preserved274.id,
  name: preserved274.name,
  active: preserved274.meta.active,
  rendered: rendered274,
};

/**
 * @typedef {object} Model275
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box275
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project275
 * @param {Model275} input
 * @returns {string}
 */

/**
 * @template {Model275} T
 * @param {T} value
 * @returns {T}
 */
function preserve275(value) {
  return value;
}

class Store275 {
  /**
   * @param {Box275<Model275>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project275} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model275} */
const model275 = {
  id: 275, name: "model-275", meta: { active: false, label: "meta-275" },
};
const preserved275 = preserve275(model275);
/** @type {Box275<Model275>} */
const box275 = { value: preserved275, label: "box-275" };
/** @type {Project275} */
const project275 = (input) => `${input.meta.label}:${input.name}`;
const store275 = new Store275(box275);
const rendered275 = store275.read(project275);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult275 = {
  id: preserved275.id,
  name: preserved275.name,
  active: preserved275.meta.active,
  rendered: rendered275,
};

/**
 * @typedef {object} Model276
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box276
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project276
 * @param {Model276} input
 * @returns {string}
 */

/**
 * @template {Model276} T
 * @param {T} value
 * @returns {T}
 */
function preserve276(value) {
  return value;
}

class Store276 {
  /**
   * @param {Box276<Model276>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project276} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model276} */
const model276 = {
  id: 276, name: "model-276", meta: { active: true, label: "meta-276" },
};
const preserved276 = preserve276(model276);
/** @type {Box276<Model276>} */
const box276 = { value: preserved276, label: "box-276" };
/** @type {Project276} */
const project276 = (input) => `${input.meta.label}:${input.name}`;
const store276 = new Store276(box276);
const rendered276 = store276.read(project276);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult276 = {
  id: preserved276.id,
  name: preserved276.name,
  active: preserved276.meta.active,
  rendered: rendered276,
};

/**
 * @typedef {object} Model277
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box277
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project277
 * @param {Model277} input
 * @returns {string}
 */

/**
 * @template {Model277} T
 * @param {T} value
 * @returns {T}
 */
function preserve277(value) {
  return value;
}

class Store277 {
  /**
   * @param {Box277<Model277>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project277} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model277} */
const model277 = {
  id: 277, name: "model-277", meta: { active: false, label: "meta-277" },
};
const preserved277 = preserve277(model277);
/** @type {Box277<Model277>} */
const box277 = { value: preserved277, label: "box-277" };
/** @type {Project277} */
const project277 = (input) => `${input.meta.label}:${input.name}`;
const store277 = new Store277(box277);
const rendered277 = store277.read(project277);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult277 = {
  id: preserved277.id,
  name: preserved277.name,
  active: preserved277.meta.active,
  rendered: rendered277,
};

/**
 * @typedef {object} Model278
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box278
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project278
 * @param {Model278} input
 * @returns {string}
 */

/**
 * @template {Model278} T
 * @param {T} value
 * @returns {T}
 */
function preserve278(value) {
  return value;
}

class Store278 {
  /**
   * @param {Box278<Model278>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project278} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model278} */
const model278 = {
  id: 278, name: "model-278", meta: { active: true, label: "meta-278" },
};
const preserved278 = preserve278(model278);
/** @type {Box278<Model278>} */
const box278 = { value: preserved278, label: "box-278" };
/** @type {Project278} */
const project278 = (input) => `${input.meta.label}:${input.name}`;
const store278 = new Store278(box278);
const rendered278 = store278.read(project278);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult278 = {
  id: preserved278.id,
  name: preserved278.name,
  active: preserved278.meta.active,
  rendered: rendered278,
};

/**
 * @typedef {object} Model279
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box279
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project279
 * @param {Model279} input
 * @returns {string}
 */

/**
 * @template {Model279} T
 * @param {T} value
 * @returns {T}
 */
function preserve279(value) {
  return value;
}

class Store279 {
  /**
   * @param {Box279<Model279>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project279} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model279} */
const model279 = {
  id: 279, name: "model-279", meta: { active: false, label: "meta-279" },
};
const preserved279 = preserve279(model279);
/** @type {Box279<Model279>} */
const box279 = { value: preserved279, label: "box-279" };
/** @type {Project279} */
const project279 = (input) => `${input.meta.label}:${input.name}`;
const store279 = new Store279(box279);
const rendered279 = store279.read(project279);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult279 = {
  id: preserved279.id,
  name: preserved279.name,
  active: preserved279.meta.active,
  rendered: rendered279,
};

/**
 * @typedef {object} Model280
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box280
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project280
 * @param {Model280} input
 * @returns {string}
 */

/**
 * @template {Model280} T
 * @param {T} value
 * @returns {T}
 */
function preserve280(value) {
  return value;
}

class Store280 {
  /**
   * @param {Box280<Model280>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project280} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model280} */
const model280 = {
  id: 280, name: "model-280", meta: { active: true, label: "meta-280" },
};
const preserved280 = preserve280(model280);
/** @type {Box280<Model280>} */
const box280 = { value: preserved280, label: "box-280" };
/** @type {Project280} */
const project280 = (input) => `${input.meta.label}:${input.name}`;
const store280 = new Store280(box280);
const rendered280 = store280.read(project280);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult280 = {
  id: preserved280.id,
  name: preserved280.name,
  active: preserved280.meta.active,
  rendered: rendered280,
};

/**
 * @typedef {object} Model281
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box281
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project281
 * @param {Model281} input
 * @returns {string}
 */

/**
 * @template {Model281} T
 * @param {T} value
 * @returns {T}
 */
function preserve281(value) {
  return value;
}

class Store281 {
  /**
   * @param {Box281<Model281>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project281} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model281} */
const model281 = {
  id: 281, name: "model-281", meta: { active: false, label: "meta-281" },
};
const preserved281 = preserve281(model281);
/** @type {Box281<Model281>} */
const box281 = { value: preserved281, label: "box-281" };
/** @type {Project281} */
const project281 = (input) => `${input.meta.label}:${input.name}`;
const store281 = new Store281(box281);
const rendered281 = store281.read(project281);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult281 = {
  id: preserved281.id,
  name: preserved281.name,
  active: preserved281.meta.active,
  rendered: rendered281,
};

/**
 * @typedef {object} Model282
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box282
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project282
 * @param {Model282} input
 * @returns {string}
 */

/**
 * @template {Model282} T
 * @param {T} value
 * @returns {T}
 */
function preserve282(value) {
  return value;
}

class Store282 {
  /**
   * @param {Box282<Model282>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project282} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model282} */
const model282 = {
  id: 282, name: "model-282", meta: { active: true, label: "meta-282" },
};
const preserved282 = preserve282(model282);
/** @type {Box282<Model282>} */
const box282 = { value: preserved282, label: "box-282" };
/** @type {Project282} */
const project282 = (input) => `${input.meta.label}:${input.name}`;
const store282 = new Store282(box282);
const rendered282 = store282.read(project282);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult282 = {
  id: preserved282.id,
  name: preserved282.name,
  active: preserved282.meta.active,
  rendered: rendered282,
};

/**
 * @typedef {object} Model283
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box283
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project283
 * @param {Model283} input
 * @returns {string}
 */

/**
 * @template {Model283} T
 * @param {T} value
 * @returns {T}
 */
function preserve283(value) {
  return value;
}

class Store283 {
  /**
   * @param {Box283<Model283>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project283} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model283} */
const model283 = {
  id: 283, name: "model-283", meta: { active: false, label: "meta-283" },
};
const preserved283 = preserve283(model283);
/** @type {Box283<Model283>} */
const box283 = { value: preserved283, label: "box-283" };
/** @type {Project283} */
const project283 = (input) => `${input.meta.label}:${input.name}`;
const store283 = new Store283(box283);
const rendered283 = store283.read(project283);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult283 = {
  id: preserved283.id,
  name: preserved283.name,
  active: preserved283.meta.active,
  rendered: rendered283,
};

/**
 * @typedef {object} Model284
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box284
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project284
 * @param {Model284} input
 * @returns {string}
 */

/**
 * @template {Model284} T
 * @param {T} value
 * @returns {T}
 */
function preserve284(value) {
  return value;
}

class Store284 {
  /**
   * @param {Box284<Model284>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project284} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model284} */
const model284 = {
  id: 284, name: "model-284", meta: { active: true, label: "meta-284" },
};
const preserved284 = preserve284(model284);
/** @type {Box284<Model284>} */
const box284 = { value: preserved284, label: "box-284" };
/** @type {Project284} */
const project284 = (input) => `${input.meta.label}:${input.name}`;
const store284 = new Store284(box284);
const rendered284 = store284.read(project284);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult284 = {
  id: preserved284.id,
  name: preserved284.name,
  active: preserved284.meta.active,
  rendered: rendered284,
};

/**
 * @typedef {object} Model285
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box285
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project285
 * @param {Model285} input
 * @returns {string}
 */

/**
 * @template {Model285} T
 * @param {T} value
 * @returns {T}
 */
function preserve285(value) {
  return value;
}

class Store285 {
  /**
   * @param {Box285<Model285>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project285} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model285} */
const model285 = {
  id: 285, name: "model-285", meta: { active: false, label: "meta-285" },
};
const preserved285 = preserve285(model285);
/** @type {Box285<Model285>} */
const box285 = { value: preserved285, label: "box-285" };
/** @type {Project285} */
const project285 = (input) => `${input.meta.label}:${input.name}`;
const store285 = new Store285(box285);
const rendered285 = store285.read(project285);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult285 = {
  id: preserved285.id,
  name: preserved285.name,
  active: preserved285.meta.active,
  rendered: rendered285,
};

/**
 * @typedef {object} Model286
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box286
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project286
 * @param {Model286} input
 * @returns {string}
 */

/**
 * @template {Model286} T
 * @param {T} value
 * @returns {T}
 */
function preserve286(value) {
  return value;
}

class Store286 {
  /**
   * @param {Box286<Model286>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project286} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model286} */
const model286 = {
  id: 286, name: "model-286", meta: { active: true, label: "meta-286" },
};
const preserved286 = preserve286(model286);
/** @type {Box286<Model286>} */
const box286 = { value: preserved286, label: "box-286" };
/** @type {Project286} */
const project286 = (input) => `${input.meta.label}:${input.name}`;
const store286 = new Store286(box286);
const rendered286 = store286.read(project286);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult286 = {
  id: preserved286.id,
  name: preserved286.name,
  active: preserved286.meta.active,
  rendered: rendered286,
};

/**
 * @typedef {object} Model287
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box287
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project287
 * @param {Model287} input
 * @returns {string}
 */

/**
 * @template {Model287} T
 * @param {T} value
 * @returns {T}
 */
function preserve287(value) {
  return value;
}

class Store287 {
  /**
   * @param {Box287<Model287>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project287} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model287} */
const model287 = {
  id: 287, name: "model-287", meta: { active: false, label: "meta-287" },
};
const preserved287 = preserve287(model287);
/** @type {Box287<Model287>} */
const box287 = { value: preserved287, label: "box-287" };
/** @type {Project287} */
const project287 = (input) => `${input.meta.label}:${input.name}`;
const store287 = new Store287(box287);
const rendered287 = store287.read(project287);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult287 = {
  id: preserved287.id,
  name: preserved287.name,
  active: preserved287.meta.active,
  rendered: rendered287,
};

/**
 * @typedef {object} Model288
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box288
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project288
 * @param {Model288} input
 * @returns {string}
 */

/**
 * @template {Model288} T
 * @param {T} value
 * @returns {T}
 */
function preserve288(value) {
  return value;
}

class Store288 {
  /**
   * @param {Box288<Model288>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project288} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model288} */
const model288 = {
  id: 288, name: "model-288", meta: { active: true, label: "meta-288" },
};
const preserved288 = preserve288(model288);
/** @type {Box288<Model288>} */
const box288 = { value: preserved288, label: "box-288" };
/** @type {Project288} */
const project288 = (input) => `${input.meta.label}:${input.name}`;
const store288 = new Store288(box288);
const rendered288 = store288.read(project288);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult288 = {
  id: preserved288.id,
  name: preserved288.name,
  active: preserved288.meta.active,
  rendered: rendered288,
};

/**
 * @typedef {object} Model289
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box289
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project289
 * @param {Model289} input
 * @returns {string}
 */

/**
 * @template {Model289} T
 * @param {T} value
 * @returns {T}
 */
function preserve289(value) {
  return value;
}

class Store289 {
  /**
   * @param {Box289<Model289>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project289} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model289} */
const model289 = {
  id: 289, name: "model-289", meta: { active: false, label: "meta-289" },
};
const preserved289 = preserve289(model289);
/** @type {Box289<Model289>} */
const box289 = { value: preserved289, label: "box-289" };
/** @type {Project289} */
const project289 = (input) => `${input.meta.label}:${input.name}`;
const store289 = new Store289(box289);
const rendered289 = store289.read(project289);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult289 = {
  id: preserved289.id,
  name: preserved289.name,
  active: preserved289.meta.active,
  rendered: rendered289,
};

/**
 * @typedef {object} Model290
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box290
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project290
 * @param {Model290} input
 * @returns {string}
 */

/**
 * @template {Model290} T
 * @param {T} value
 * @returns {T}
 */
function preserve290(value) {
  return value;
}

class Store290 {
  /**
   * @param {Box290<Model290>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project290} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model290} */
const model290 = {
  id: 290, name: "model-290", meta: { active: true, label: "meta-290" },
};
const preserved290 = preserve290(model290);
/** @type {Box290<Model290>} */
const box290 = { value: preserved290, label: "box-290" };
/** @type {Project290} */
const project290 = (input) => `${input.meta.label}:${input.name}`;
const store290 = new Store290(box290);
const rendered290 = store290.read(project290);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult290 = {
  id: preserved290.id,
  name: preserved290.name,
  active: preserved290.meta.active,
  rendered: rendered290,
};

/**
 * @typedef {object} Model291
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box291
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project291
 * @param {Model291} input
 * @returns {string}
 */

/**
 * @template {Model291} T
 * @param {T} value
 * @returns {T}
 */
function preserve291(value) {
  return value;
}

class Store291 {
  /**
   * @param {Box291<Model291>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project291} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model291} */
const model291 = {
  id: 291, name: "model-291", meta: { active: false, label: "meta-291" },
};
const preserved291 = preserve291(model291);
/** @type {Box291<Model291>} */
const box291 = { value: preserved291, label: "box-291" };
/** @type {Project291} */
const project291 = (input) => `${input.meta.label}:${input.name}`;
const store291 = new Store291(box291);
const rendered291 = store291.read(project291);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult291 = {
  id: preserved291.id,
  name: preserved291.name,
  active: preserved291.meta.active,
  rendered: rendered291,
};

/**
 * @typedef {object} Model292
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box292
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project292
 * @param {Model292} input
 * @returns {string}
 */

/**
 * @template {Model292} T
 * @param {T} value
 * @returns {T}
 */
function preserve292(value) {
  return value;
}

class Store292 {
  /**
   * @param {Box292<Model292>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project292} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model292} */
const model292 = {
  id: 292, name: "model-292", meta: { active: true, label: "meta-292" },
};
const preserved292 = preserve292(model292);
/** @type {Box292<Model292>} */
const box292 = { value: preserved292, label: "box-292" };
/** @type {Project292} */
const project292 = (input) => `${input.meta.label}:${input.name}`;
const store292 = new Store292(box292);
const rendered292 = store292.read(project292);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult292 = {
  id: preserved292.id,
  name: preserved292.name,
  active: preserved292.meta.active,
  rendered: rendered292,
};

/**
 * @typedef {object} Model293
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box293
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project293
 * @param {Model293} input
 * @returns {string}
 */

/**
 * @template {Model293} T
 * @param {T} value
 * @returns {T}
 */
function preserve293(value) {
  return value;
}

class Store293 {
  /**
   * @param {Box293<Model293>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project293} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model293} */
const model293 = {
  id: 293, name: "model-293", meta: { active: false, label: "meta-293" },
};
const preserved293 = preserve293(model293);
/** @type {Box293<Model293>} */
const box293 = { value: preserved293, label: "box-293" };
/** @type {Project293} */
const project293 = (input) => `${input.meta.label}:${input.name}`;
const store293 = new Store293(box293);
const rendered293 = store293.read(project293);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult293 = {
  id: preserved293.id,
  name: preserved293.name,
  active: preserved293.meta.active,
  rendered: rendered293,
};

/**
 * @typedef {object} Model294
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box294
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project294
 * @param {Model294} input
 * @returns {string}
 */

/**
 * @template {Model294} T
 * @param {T} value
 * @returns {T}
 */
function preserve294(value) {
  return value;
}

class Store294 {
  /**
   * @param {Box294<Model294>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project294} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model294} */
const model294 = {
  id: 294, name: "model-294", meta: { active: true, label: "meta-294" },
};
const preserved294 = preserve294(model294);
/** @type {Box294<Model294>} */
const box294 = { value: preserved294, label: "box-294" };
/** @type {Project294} */
const project294 = (input) => `${input.meta.label}:${input.name}`;
const store294 = new Store294(box294);
const rendered294 = store294.read(project294);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult294 = {
  id: preserved294.id,
  name: preserved294.name,
  active: preserved294.meta.active,
  rendered: rendered294,
};

/**
 * @typedef {object} Model295
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box295
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project295
 * @param {Model295} input
 * @returns {string}
 */

/**
 * @template {Model295} T
 * @param {T} value
 * @returns {T}
 */
function preserve295(value) {
  return value;
}

class Store295 {
  /**
   * @param {Box295<Model295>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project295} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model295} */
const model295 = {
  id: 295, name: "model-295", meta: { active: false, label: "meta-295" },
};
const preserved295 = preserve295(model295);
/** @type {Box295<Model295>} */
const box295 = { value: preserved295, label: "box-295" };
/** @type {Project295} */
const project295 = (input) => `${input.meta.label}:${input.name}`;
const store295 = new Store295(box295);
const rendered295 = store295.read(project295);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult295 = {
  id: preserved295.id,
  name: preserved295.name,
  active: preserved295.meta.active,
  rendered: rendered295,
};

/**
 * @typedef {object} Model296
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box296
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project296
 * @param {Model296} input
 * @returns {string}
 */

/**
 * @template {Model296} T
 * @param {T} value
 * @returns {T}
 */
function preserve296(value) {
  return value;
}

class Store296 {
  /**
   * @param {Box296<Model296>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project296} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model296} */
const model296 = {
  id: 296, name: "model-296", meta: { active: true, label: "meta-296" },
};
const preserved296 = preserve296(model296);
/** @type {Box296<Model296>} */
const box296 = { value: preserved296, label: "box-296" };
/** @type {Project296} */
const project296 = (input) => `${input.meta.label}:${input.name}`;
const store296 = new Store296(box296);
const rendered296 = store296.read(project296);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult296 = {
  id: preserved296.id,
  name: preserved296.name,
  active: preserved296.meta.active,
  rendered: rendered296,
};

/**
 * @typedef {object} Model297
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box297
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project297
 * @param {Model297} input
 * @returns {string}
 */

/**
 * @template {Model297} T
 * @param {T} value
 * @returns {T}
 */
function preserve297(value) {
  return value;
}

class Store297 {
  /**
   * @param {Box297<Model297>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project297} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model297} */
const model297 = {
  id: 297, name: "model-297", meta: { active: false, label: "meta-297" },
};
const preserved297 = preserve297(model297);
/** @type {Box297<Model297>} */
const box297 = { value: preserved297, label: "box-297" };
/** @type {Project297} */
const project297 = (input) => `${input.meta.label}:${input.name}`;
const store297 = new Store297(box297);
const rendered297 = store297.read(project297);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult297 = {
  id: preserved297.id,
  name: preserved297.name,
  active: preserved297.meta.active,
  rendered: rendered297,
};

/**
 * @typedef {object} Model298
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box298
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project298
 * @param {Model298} input
 * @returns {string}
 */

/**
 * @template {Model298} T
 * @param {T} value
 * @returns {T}
 */
function preserve298(value) {
  return value;
}

class Store298 {
  /**
   * @param {Box298<Model298>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project298} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model298} */
const model298 = {
  id: 298, name: "model-298", meta: { active: true, label: "meta-298" },
};
const preserved298 = preserve298(model298);
/** @type {Box298<Model298>} */
const box298 = { value: preserved298, label: "box-298" };
/** @type {Project298} */
const project298 = (input) => `${input.meta.label}:${input.name}`;
const store298 = new Store298(box298);
const rendered298 = store298.read(project298);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult298 = {
  id: preserved298.id,
  name: preserved298.name,
  active: preserved298.meta.active,
  rendered: rendered298,
};

/**
 * @typedef {object} Model299
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box299
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project299
 * @param {Model299} input
 * @returns {string}
 */

/**
 * @template {Model299} T
 * @param {T} value
 * @returns {T}
 */
function preserve299(value) {
  return value;
}

class Store299 {
  /**
   * @param {Box299<Model299>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project299} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model299} */
const model299 = {
  id: 299, name: "model-299", meta: { active: false, label: "meta-299" },
};
const preserved299 = preserve299(model299);
/** @type {Box299<Model299>} */
const box299 = { value: preserved299, label: "box-299" };
/** @type {Project299} */
const project299 = (input) => `${input.meta.label}:${input.name}`;
const store299 = new Store299(box299);
const rendered299 = store299.read(project299);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult299 = {
  id: preserved299.id,
  name: preserved299.name,
  active: preserved299.meta.active,
  rendered: rendered299,
};

/**
 * @typedef {object} Model300
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box300
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project300
 * @param {Model300} input
 * @returns {string}
 */

/**
 * @template {Model300} T
 * @param {T} value
 * @returns {T}
 */
function preserve300(value) {
  return value;
}

class Store300 {
  /**
   * @param {Box300<Model300>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project300} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model300} */
const model300 = {
  id: 300, name: "model-300", meta: { active: true, label: "meta-300" },
};
const preserved300 = preserve300(model300);
/** @type {Box300<Model300>} */
const box300 = { value: preserved300, label: "box-300" };
/** @type {Project300} */
const project300 = (input) => `${input.meta.label}:${input.name}`;
const store300 = new Store300(box300);
const rendered300 = store300.read(project300);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult300 = {
  id: preserved300.id,
  name: preserved300.name,
  active: preserved300.meta.active,
  rendered: rendered300,
};

/**
 * @typedef {object} Model301
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box301
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project301
 * @param {Model301} input
 * @returns {string}
 */

/**
 * @template {Model301} T
 * @param {T} value
 * @returns {T}
 */
function preserve301(value) {
  return value;
}

class Store301 {
  /**
   * @param {Box301<Model301>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project301} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model301} */
const model301 = {
  id: 301, name: "model-301", meta: { active: false, label: "meta-301" },
};
const preserved301 = preserve301(model301);
/** @type {Box301<Model301>} */
const box301 = { value: preserved301, label: "box-301" };
/** @type {Project301} */
const project301 = (input) => `${input.meta.label}:${input.name}`;
const store301 = new Store301(box301);
const rendered301 = store301.read(project301);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult301 = {
  id: preserved301.id,
  name: preserved301.name,
  active: preserved301.meta.active,
  rendered: rendered301,
};

/**
 * @typedef {object} Model302
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box302
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project302
 * @param {Model302} input
 * @returns {string}
 */

/**
 * @template {Model302} T
 * @param {T} value
 * @returns {T}
 */
function preserve302(value) {
  return value;
}

class Store302 {
  /**
   * @param {Box302<Model302>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project302} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model302} */
const model302 = {
  id: 302, name: "model-302", meta: { active: true, label: "meta-302" },
};
const preserved302 = preserve302(model302);
/** @type {Box302<Model302>} */
const box302 = { value: preserved302, label: "box-302" };
/** @type {Project302} */
const project302 = (input) => `${input.meta.label}:${input.name}`;
const store302 = new Store302(box302);
const rendered302 = store302.read(project302);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult302 = {
  id: preserved302.id,
  name: preserved302.name,
  active: preserved302.meta.active,
  rendered: rendered302,
};

/**
 * @typedef {object} Model303
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box303
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project303
 * @param {Model303} input
 * @returns {string}
 */

/**
 * @template {Model303} T
 * @param {T} value
 * @returns {T}
 */
function preserve303(value) {
  return value;
}

class Store303 {
  /**
   * @param {Box303<Model303>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project303} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model303} */
const model303 = {
  id: 303, name: "model-303", meta: { active: false, label: "meta-303" },
};
const preserved303 = preserve303(model303);
/** @type {Box303<Model303>} */
const box303 = { value: preserved303, label: "box-303" };
/** @type {Project303} */
const project303 = (input) => `${input.meta.label}:${input.name}`;
const store303 = new Store303(box303);
const rendered303 = store303.read(project303);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult303 = {
  id: preserved303.id,
  name: preserved303.name,
  active: preserved303.meta.active,
  rendered: rendered303,
};

/**
 * @typedef {object} Model304
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box304
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project304
 * @param {Model304} input
 * @returns {string}
 */

/**
 * @template {Model304} T
 * @param {T} value
 * @returns {T}
 */
function preserve304(value) {
  return value;
}

class Store304 {
  /**
   * @param {Box304<Model304>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project304} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model304} */
const model304 = {
  id: 304, name: "model-304", meta: { active: true, label: "meta-304" },
};
const preserved304 = preserve304(model304);
/** @type {Box304<Model304>} */
const box304 = { value: preserved304, label: "box-304" };
/** @type {Project304} */
const project304 = (input) => `${input.meta.label}:${input.name}`;
const store304 = new Store304(box304);
const rendered304 = store304.read(project304);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult304 = {
  id: preserved304.id,
  name: preserved304.name,
  active: preserved304.meta.active,
  rendered: rendered304,
};

/**
 * @typedef {object} Model305
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box305
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project305
 * @param {Model305} input
 * @returns {string}
 */

/**
 * @template {Model305} T
 * @param {T} value
 * @returns {T}
 */
function preserve305(value) {
  return value;
}

class Store305 {
  /**
   * @param {Box305<Model305>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project305} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model305} */
const model305 = {
  id: 305, name: "model-305", meta: { active: false, label: "meta-305" },
};
const preserved305 = preserve305(model305);
/** @type {Box305<Model305>} */
const box305 = { value: preserved305, label: "box-305" };
/** @type {Project305} */
const project305 = (input) => `${input.meta.label}:${input.name}`;
const store305 = new Store305(box305);
const rendered305 = store305.read(project305);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult305 = {
  id: preserved305.id,
  name: preserved305.name,
  active: preserved305.meta.active,
  rendered: rendered305,
};

/**
 * @typedef {object} Model306
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box306
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project306
 * @param {Model306} input
 * @returns {string}
 */

/**
 * @template {Model306} T
 * @param {T} value
 * @returns {T}
 */
function preserve306(value) {
  return value;
}

class Store306 {
  /**
   * @param {Box306<Model306>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project306} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model306} */
const model306 = {
  id: 306, name: "model-306", meta: { active: true, label: "meta-306" },
};
const preserved306 = preserve306(model306);
/** @type {Box306<Model306>} */
const box306 = { value: preserved306, label: "box-306" };
/** @type {Project306} */
const project306 = (input) => `${input.meta.label}:${input.name}`;
const store306 = new Store306(box306);
const rendered306 = store306.read(project306);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult306 = {
  id: preserved306.id,
  name: preserved306.name,
  active: preserved306.meta.active,
  rendered: rendered306,
};

/**
 * @typedef {object} Model307
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box307
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project307
 * @param {Model307} input
 * @returns {string}
 */

/**
 * @template {Model307} T
 * @param {T} value
 * @returns {T}
 */
function preserve307(value) {
  return value;
}

class Store307 {
  /**
   * @param {Box307<Model307>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project307} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model307} */
const model307 = {
  id: 307, name: "model-307", meta: { active: false, label: "meta-307" },
};
const preserved307 = preserve307(model307);
/** @type {Box307<Model307>} */
const box307 = { value: preserved307, label: "box-307" };
/** @type {Project307} */
const project307 = (input) => `${input.meta.label}:${input.name}`;
const store307 = new Store307(box307);
const rendered307 = store307.read(project307);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult307 = {
  id: preserved307.id,
  name: preserved307.name,
  active: preserved307.meta.active,
  rendered: rendered307,
};

/**
 * @typedef {object} Model308
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box308
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project308
 * @param {Model308} input
 * @returns {string}
 */

/**
 * @template {Model308} T
 * @param {T} value
 * @returns {T}
 */
function preserve308(value) {
  return value;
}

class Store308 {
  /**
   * @param {Box308<Model308>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project308} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model308} */
const model308 = {
  id: 308, name: "model-308", meta: { active: true, label: "meta-308" },
};
const preserved308 = preserve308(model308);
/** @type {Box308<Model308>} */
const box308 = { value: preserved308, label: "box-308" };
/** @type {Project308} */
const project308 = (input) => `${input.meta.label}:${input.name}`;
const store308 = new Store308(box308);
const rendered308 = store308.read(project308);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult308 = {
  id: preserved308.id,
  name: preserved308.name,
  active: preserved308.meta.active,
  rendered: rendered308,
};

/**
 * @typedef {object} Model309
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box309
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project309
 * @param {Model309} input
 * @returns {string}
 */

/**
 * @template {Model309} T
 * @param {T} value
 * @returns {T}
 */
function preserve309(value) {
  return value;
}

class Store309 {
  /**
   * @param {Box309<Model309>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project309} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model309} */
const model309 = {
  id: 309, name: "model-309", meta: { active: false, label: "meta-309" },
};
const preserved309 = preserve309(model309);
/** @type {Box309<Model309>} */
const box309 = { value: preserved309, label: "box-309" };
/** @type {Project309} */
const project309 = (input) => `${input.meta.label}:${input.name}`;
const store309 = new Store309(box309);
const rendered309 = store309.read(project309);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult309 = {
  id: preserved309.id,
  name: preserved309.name,
  active: preserved309.meta.active,
  rendered: rendered309,
};

/**
 * @typedef {object} Model310
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box310
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project310
 * @param {Model310} input
 * @returns {string}
 */

/**
 * @template {Model310} T
 * @param {T} value
 * @returns {T}
 */
function preserve310(value) {
  return value;
}

class Store310 {
  /**
   * @param {Box310<Model310>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project310} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model310} */
const model310 = {
  id: 310, name: "model-310", meta: { active: true, label: "meta-310" },
};
const preserved310 = preserve310(model310);
/** @type {Box310<Model310>} */
const box310 = { value: preserved310, label: "box-310" };
/** @type {Project310} */
const project310 = (input) => `${input.meta.label}:${input.name}`;
const store310 = new Store310(box310);
const rendered310 = store310.read(project310);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult310 = {
  id: preserved310.id,
  name: preserved310.name,
  active: preserved310.meta.active,
  rendered: rendered310,
};

/**
 * @typedef {object} Model311
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box311
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project311
 * @param {Model311} input
 * @returns {string}
 */

/**
 * @template {Model311} T
 * @param {T} value
 * @returns {T}
 */
function preserve311(value) {
  return value;
}

class Store311 {
  /**
   * @param {Box311<Model311>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project311} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model311} */
const model311 = {
  id: 311, name: "model-311", meta: { active: false, label: "meta-311" },
};
const preserved311 = preserve311(model311);
/** @type {Box311<Model311>} */
const box311 = { value: preserved311, label: "box-311" };
/** @type {Project311} */
const project311 = (input) => `${input.meta.label}:${input.name}`;
const store311 = new Store311(box311);
const rendered311 = store311.read(project311);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult311 = {
  id: preserved311.id,
  name: preserved311.name,
  active: preserved311.meta.active,
  rendered: rendered311,
};

/**
 * @typedef {object} Model312
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box312
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project312
 * @param {Model312} input
 * @returns {string}
 */

/**
 * @template {Model312} T
 * @param {T} value
 * @returns {T}
 */
function preserve312(value) {
  return value;
}

class Store312 {
  /**
   * @param {Box312<Model312>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project312} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model312} */
const model312 = {
  id: 312, name: "model-312", meta: { active: true, label: "meta-312" },
};
const preserved312 = preserve312(model312);
/** @type {Box312<Model312>} */
const box312 = { value: preserved312, label: "box-312" };
/** @type {Project312} */
const project312 = (input) => `${input.meta.label}:${input.name}`;
const store312 = new Store312(box312);
const rendered312 = store312.read(project312);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult312 = {
  id: preserved312.id,
  name: preserved312.name,
  active: preserved312.meta.active,
  rendered: rendered312,
};

/**
 * @typedef {object} Model313
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box313
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project313
 * @param {Model313} input
 * @returns {string}
 */

/**
 * @template {Model313} T
 * @param {T} value
 * @returns {T}
 */
function preserve313(value) {
  return value;
}

class Store313 {
  /**
   * @param {Box313<Model313>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project313} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model313} */
const model313 = {
  id: 313, name: "model-313", meta: { active: false, label: "meta-313" },
};
const preserved313 = preserve313(model313);
/** @type {Box313<Model313>} */
const box313 = { value: preserved313, label: "box-313" };
/** @type {Project313} */
const project313 = (input) => `${input.meta.label}:${input.name}`;
const store313 = new Store313(box313);
const rendered313 = store313.read(project313);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult313 = {
  id: preserved313.id,
  name: preserved313.name,
  active: preserved313.meta.active,
  rendered: rendered313,
};

/**
 * @typedef {object} Model314
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box314
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project314
 * @param {Model314} input
 * @returns {string}
 */

/**
 * @template {Model314} T
 * @param {T} value
 * @returns {T}
 */
function preserve314(value) {
  return value;
}

class Store314 {
  /**
   * @param {Box314<Model314>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project314} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model314} */
const model314 = {
  id: 314, name: "model-314", meta: { active: true, label: "meta-314" },
};
const preserved314 = preserve314(model314);
/** @type {Box314<Model314>} */
const box314 = { value: preserved314, label: "box-314" };
/** @type {Project314} */
const project314 = (input) => `${input.meta.label}:${input.name}`;
const store314 = new Store314(box314);
const rendered314 = store314.read(project314);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult314 = {
  id: preserved314.id,
  name: preserved314.name,
  active: preserved314.meta.active,
  rendered: rendered314,
};

/**
 * @typedef {object} Model315
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box315
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project315
 * @param {Model315} input
 * @returns {string}
 */

/**
 * @template {Model315} T
 * @param {T} value
 * @returns {T}
 */
function preserve315(value) {
  return value;
}

class Store315 {
  /**
   * @param {Box315<Model315>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project315} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model315} */
const model315 = {
  id: 315, name: "model-315", meta: { active: false, label: "meta-315" },
};
const preserved315 = preserve315(model315);
/** @type {Box315<Model315>} */
const box315 = { value: preserved315, label: "box-315" };
/** @type {Project315} */
const project315 = (input) => `${input.meta.label}:${input.name}`;
const store315 = new Store315(box315);
const rendered315 = store315.read(project315);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult315 = {
  id: preserved315.id,
  name: preserved315.name,
  active: preserved315.meta.active,
  rendered: rendered315,
};

/**
 * @typedef {object} Model316
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box316
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project316
 * @param {Model316} input
 * @returns {string}
 */

/**
 * @template {Model316} T
 * @param {T} value
 * @returns {T}
 */
function preserve316(value) {
  return value;
}

class Store316 {
  /**
   * @param {Box316<Model316>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project316} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model316} */
const model316 = {
  id: 316, name: "model-316", meta: { active: true, label: "meta-316" },
};
const preserved316 = preserve316(model316);
/** @type {Box316<Model316>} */
const box316 = { value: preserved316, label: "box-316" };
/** @type {Project316} */
const project316 = (input) => `${input.meta.label}:${input.name}`;
const store316 = new Store316(box316);
const rendered316 = store316.read(project316);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult316 = {
  id: preserved316.id,
  name: preserved316.name,
  active: preserved316.meta.active,
  rendered: rendered316,
};

/**
 * @typedef {object} Model317
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box317
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project317
 * @param {Model317} input
 * @returns {string}
 */

/**
 * @template {Model317} T
 * @param {T} value
 * @returns {T}
 */
function preserve317(value) {
  return value;
}

class Store317 {
  /**
   * @param {Box317<Model317>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project317} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model317} */
const model317 = {
  id: 317, name: "model-317", meta: { active: false, label: "meta-317" },
};
const preserved317 = preserve317(model317);
/** @type {Box317<Model317>} */
const box317 = { value: preserved317, label: "box-317" };
/** @type {Project317} */
const project317 = (input) => `${input.meta.label}:${input.name}`;
const store317 = new Store317(box317);
const rendered317 = store317.read(project317);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult317 = {
  id: preserved317.id,
  name: preserved317.name,
  active: preserved317.meta.active,
  rendered: rendered317,
};

/**
 * @typedef {object} Model318
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box318
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project318
 * @param {Model318} input
 * @returns {string}
 */

/**
 * @template {Model318} T
 * @param {T} value
 * @returns {T}
 */
function preserve318(value) {
  return value;
}

class Store318 {
  /**
   * @param {Box318<Model318>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project318} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model318} */
const model318 = {
  id: 318, name: "model-318", meta: { active: true, label: "meta-318" },
};
const preserved318 = preserve318(model318);
/** @type {Box318<Model318>} */
const box318 = { value: preserved318, label: "box-318" };
/** @type {Project318} */
const project318 = (input) => `${input.meta.label}:${input.name}`;
const store318 = new Store318(box318);
const rendered318 = store318.read(project318);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult318 = {
  id: preserved318.id,
  name: preserved318.name,
  active: preserved318.meta.active,
  rendered: rendered318,
};

/**
 * @typedef {object} Model319
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box319
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project319
 * @param {Model319} input
 * @returns {string}
 */

/**
 * @template {Model319} T
 * @param {T} value
 * @returns {T}
 */
function preserve319(value) {
  return value;
}

class Store319 {
  /**
   * @param {Box319<Model319>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project319} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model319} */
const model319 = {
  id: 319, name: "model-319", meta: { active: false, label: "meta-319" },
};
const preserved319 = preserve319(model319);
/** @type {Box319<Model319>} */
const box319 = { value: preserved319, label: "box-319" };
/** @type {Project319} */
const project319 = (input) => `${input.meta.label}:${input.name}`;
const store319 = new Store319(box319);
const rendered319 = store319.read(project319);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult319 = {
  id: preserved319.id,
  name: preserved319.name,
  active: preserved319.meta.active,
  rendered: rendered319,
};

/**
 * @typedef {object} Model320
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box320
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project320
 * @param {Model320} input
 * @returns {string}
 */

/**
 * @template {Model320} T
 * @param {T} value
 * @returns {T}
 */
function preserve320(value) {
  return value;
}

class Store320 {
  /**
   * @param {Box320<Model320>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project320} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model320} */
const model320 = {
  id: 320, name: "model-320", meta: { active: true, label: "meta-320" },
};
const preserved320 = preserve320(model320);
/** @type {Box320<Model320>} */
const box320 = { value: preserved320, label: "box-320" };
/** @type {Project320} */
const project320 = (input) => `${input.meta.label}:${input.name}`;
const store320 = new Store320(box320);
const rendered320 = store320.read(project320);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult320 = {
  id: preserved320.id,
  name: preserved320.name,
  active: preserved320.meta.active,
  rendered: rendered320,
};

/**
 * @typedef {object} Model321
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box321
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project321
 * @param {Model321} input
 * @returns {string}
 */

/**
 * @template {Model321} T
 * @param {T} value
 * @returns {T}
 */
function preserve321(value) {
  return value;
}

class Store321 {
  /**
   * @param {Box321<Model321>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project321} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model321} */
const model321 = {
  id: 321, name: "model-321", meta: { active: false, label: "meta-321" },
};
const preserved321 = preserve321(model321);
/** @type {Box321<Model321>} */
const box321 = { value: preserved321, label: "box-321" };
/** @type {Project321} */
const project321 = (input) => `${input.meta.label}:${input.name}`;
const store321 = new Store321(box321);
const rendered321 = store321.read(project321);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult321 = {
  id: preserved321.id,
  name: preserved321.name,
  active: preserved321.meta.active,
  rendered: rendered321,
};

/**
 * @typedef {object} Model322
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box322
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project322
 * @param {Model322} input
 * @returns {string}
 */

/**
 * @template {Model322} T
 * @param {T} value
 * @returns {T}
 */
function preserve322(value) {
  return value;
}

class Store322 {
  /**
   * @param {Box322<Model322>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project322} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model322} */
const model322 = {
  id: 322, name: "model-322", meta: { active: true, label: "meta-322" },
};
const preserved322 = preserve322(model322);
/** @type {Box322<Model322>} */
const box322 = { value: preserved322, label: "box-322" };
/** @type {Project322} */
const project322 = (input) => `${input.meta.label}:${input.name}`;
const store322 = new Store322(box322);
const rendered322 = store322.read(project322);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult322 = {
  id: preserved322.id,
  name: preserved322.name,
  active: preserved322.meta.active,
  rendered: rendered322,
};

/**
 * @typedef {object} Model323
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box323
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project323
 * @param {Model323} input
 * @returns {string}
 */

/**
 * @template {Model323} T
 * @param {T} value
 * @returns {T}
 */
function preserve323(value) {
  return value;
}

class Store323 {
  /**
   * @param {Box323<Model323>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project323} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model323} */
const model323 = {
  id: 323, name: "model-323", meta: { active: false, label: "meta-323" },
};
const preserved323 = preserve323(model323);
/** @type {Box323<Model323>} */
const box323 = { value: preserved323, label: "box-323" };
/** @type {Project323} */
const project323 = (input) => `${input.meta.label}:${input.name}`;
const store323 = new Store323(box323);
const rendered323 = store323.read(project323);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult323 = {
  id: preserved323.id,
  name: preserved323.name,
  active: preserved323.meta.active,
  rendered: rendered323,
};

/**
 * @typedef {object} Model324
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box324
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project324
 * @param {Model324} input
 * @returns {string}
 */

/**
 * @template {Model324} T
 * @param {T} value
 * @returns {T}
 */
function preserve324(value) {
  return value;
}

class Store324 {
  /**
   * @param {Box324<Model324>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project324} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model324} */
const model324 = {
  id: 324, name: "model-324", meta: { active: true, label: "meta-324" },
};
const preserved324 = preserve324(model324);
/** @type {Box324<Model324>} */
const box324 = { value: preserved324, label: "box-324" };
/** @type {Project324} */
const project324 = (input) => `${input.meta.label}:${input.name}`;
const store324 = new Store324(box324);
const rendered324 = store324.read(project324);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult324 = {
  id: preserved324.id,
  name: preserved324.name,
  active: preserved324.meta.active,
  rendered: rendered324,
};

/**
 * @typedef {object} Model325
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box325
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project325
 * @param {Model325} input
 * @returns {string}
 */

/**
 * @template {Model325} T
 * @param {T} value
 * @returns {T}
 */
function preserve325(value) {
  return value;
}

class Store325 {
  /**
   * @param {Box325<Model325>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project325} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model325} */
const model325 = {
  id: 325, name: "model-325", meta: { active: false, label: "meta-325" },
};
const preserved325 = preserve325(model325);
/** @type {Box325<Model325>} */
const box325 = { value: preserved325, label: "box-325" };
/** @type {Project325} */
const project325 = (input) => `${input.meta.label}:${input.name}`;
const store325 = new Store325(box325);
const rendered325 = store325.read(project325);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult325 = {
  id: preserved325.id,
  name: preserved325.name,
  active: preserved325.meta.active,
  rendered: rendered325,
};

/**
 * @typedef {object} Model326
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box326
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project326
 * @param {Model326} input
 * @returns {string}
 */

/**
 * @template {Model326} T
 * @param {T} value
 * @returns {T}
 */
function preserve326(value) {
  return value;
}

class Store326 {
  /**
   * @param {Box326<Model326>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project326} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model326} */
const model326 = {
  id: 326, name: "model-326", meta: { active: true, label: "meta-326" },
};
const preserved326 = preserve326(model326);
/** @type {Box326<Model326>} */
const box326 = { value: preserved326, label: "box-326" };
/** @type {Project326} */
const project326 = (input) => `${input.meta.label}:${input.name}`;
const store326 = new Store326(box326);
const rendered326 = store326.read(project326);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult326 = {
  id: preserved326.id,
  name: preserved326.name,
  active: preserved326.meta.active,
  rendered: rendered326,
};

/**
 * @typedef {object} Model327
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box327
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project327
 * @param {Model327} input
 * @returns {string}
 */

/**
 * @template {Model327} T
 * @param {T} value
 * @returns {T}
 */
function preserve327(value) {
  return value;
}

class Store327 {
  /**
   * @param {Box327<Model327>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project327} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model327} */
const model327 = {
  id: 327, name: "model-327", meta: { active: false, label: "meta-327" },
};
const preserved327 = preserve327(model327);
/** @type {Box327<Model327>} */
const box327 = { value: preserved327, label: "box-327" };
/** @type {Project327} */
const project327 = (input) => `${input.meta.label}:${input.name}`;
const store327 = new Store327(box327);
const rendered327 = store327.read(project327);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult327 = {
  id: preserved327.id,
  name: preserved327.name,
  active: preserved327.meta.active,
  rendered: rendered327,
};

/**
 * @typedef {object} Model328
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box328
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project328
 * @param {Model328} input
 * @returns {string}
 */

/**
 * @template {Model328} T
 * @param {T} value
 * @returns {T}
 */
function preserve328(value) {
  return value;
}

class Store328 {
  /**
   * @param {Box328<Model328>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project328} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model328} */
const model328 = {
  id: 328, name: "model-328", meta: { active: true, label: "meta-328" },
};
const preserved328 = preserve328(model328);
/** @type {Box328<Model328>} */
const box328 = { value: preserved328, label: "box-328" };
/** @type {Project328} */
const project328 = (input) => `${input.meta.label}:${input.name}`;
const store328 = new Store328(box328);
const rendered328 = store328.read(project328);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult328 = {
  id: preserved328.id,
  name: preserved328.name,
  active: preserved328.meta.active,
  rendered: rendered328,
};

/**
 * @typedef {object} Model329
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box329
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project329
 * @param {Model329} input
 * @returns {string}
 */

/**
 * @template {Model329} T
 * @param {T} value
 * @returns {T}
 */
function preserve329(value) {
  return value;
}

class Store329 {
  /**
   * @param {Box329<Model329>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project329} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model329} */
const model329 = {
  id: 329, name: "model-329", meta: { active: false, label: "meta-329" },
};
const preserved329 = preserve329(model329);
/** @type {Box329<Model329>} */
const box329 = { value: preserved329, label: "box-329" };
/** @type {Project329} */
const project329 = (input) => `${input.meta.label}:${input.name}`;
const store329 = new Store329(box329);
const rendered329 = store329.read(project329);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult329 = {
  id: preserved329.id,
  name: preserved329.name,
  active: preserved329.meta.active,
  rendered: rendered329,
};

/**
 * @typedef {object} Model330
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box330
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project330
 * @param {Model330} input
 * @returns {string}
 */

/**
 * @template {Model330} T
 * @param {T} value
 * @returns {T}
 */
function preserve330(value) {
  return value;
}

class Store330 {
  /**
   * @param {Box330<Model330>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project330} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model330} */
const model330 = {
  id: 330, name: "model-330", meta: { active: true, label: "meta-330" },
};
const preserved330 = preserve330(model330);
/** @type {Box330<Model330>} */
const box330 = { value: preserved330, label: "box-330" };
/** @type {Project330} */
const project330 = (input) => `${input.meta.label}:${input.name}`;
const store330 = new Store330(box330);
const rendered330 = store330.read(project330);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult330 = {
  id: preserved330.id,
  name: preserved330.name,
  active: preserved330.meta.active,
  rendered: rendered330,
};

/**
 * @typedef {object} Model331
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box331
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project331
 * @param {Model331} input
 * @returns {string}
 */

/**
 * @template {Model331} T
 * @param {T} value
 * @returns {T}
 */
function preserve331(value) {
  return value;
}

class Store331 {
  /**
   * @param {Box331<Model331>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project331} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model331} */
const model331 = {
  id: 331, name: "model-331", meta: { active: false, label: "meta-331" },
};
const preserved331 = preserve331(model331);
/** @type {Box331<Model331>} */
const box331 = { value: preserved331, label: "box-331" };
/** @type {Project331} */
const project331 = (input) => `${input.meta.label}:${input.name}`;
const store331 = new Store331(box331);
const rendered331 = store331.read(project331);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult331 = {
  id: preserved331.id,
  name: preserved331.name,
  active: preserved331.meta.active,
  rendered: rendered331,
};

/**
 * @typedef {object} Model332
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box332
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project332
 * @param {Model332} input
 * @returns {string}
 */

/**
 * @template {Model332} T
 * @param {T} value
 * @returns {T}
 */
function preserve332(value) {
  return value;
}

class Store332 {
  /**
   * @param {Box332<Model332>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project332} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model332} */
const model332 = {
  id: 332, name: "model-332", meta: { active: true, label: "meta-332" },
};
const preserved332 = preserve332(model332);
/** @type {Box332<Model332>} */
const box332 = { value: preserved332, label: "box-332" };
/** @type {Project332} */
const project332 = (input) => `${input.meta.label}:${input.name}`;
const store332 = new Store332(box332);
const rendered332 = store332.read(project332);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult332 = {
  id: preserved332.id,
  name: preserved332.name,
  active: preserved332.meta.active,
  rendered: rendered332,
};

/**
 * @typedef {object} Model333
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box333
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project333
 * @param {Model333} input
 * @returns {string}
 */

/**
 * @template {Model333} T
 * @param {T} value
 * @returns {T}
 */
function preserve333(value) {
  return value;
}

class Store333 {
  /**
   * @param {Box333<Model333>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project333} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model333} */
const model333 = {
  id: 333, name: "model-333", meta: { active: false, label: "meta-333" },
};
const preserved333 = preserve333(model333);
/** @type {Box333<Model333>} */
const box333 = { value: preserved333, label: "box-333" };
/** @type {Project333} */
const project333 = (input) => `${input.meta.label}:${input.name}`;
const store333 = new Store333(box333);
const rendered333 = store333.read(project333);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult333 = {
  id: preserved333.id,
  name: preserved333.name,
  active: preserved333.meta.active,
  rendered: rendered333,
};

/**
 * @typedef {object} Model334
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box334
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project334
 * @param {Model334} input
 * @returns {string}
 */

/**
 * @template {Model334} T
 * @param {T} value
 * @returns {T}
 */
function preserve334(value) {
  return value;
}

class Store334 {
  /**
   * @param {Box334<Model334>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project334} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model334} */
const model334 = {
  id: 334, name: "model-334", meta: { active: true, label: "meta-334" },
};
const preserved334 = preserve334(model334);
/** @type {Box334<Model334>} */
const box334 = { value: preserved334, label: "box-334" };
/** @type {Project334} */
const project334 = (input) => `${input.meta.label}:${input.name}`;
const store334 = new Store334(box334);
const rendered334 = store334.read(project334);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult334 = {
  id: preserved334.id,
  name: preserved334.name,
  active: preserved334.meta.active,
  rendered: rendered334,
};

/**
 * @typedef {object} Model335
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box335
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project335
 * @param {Model335} input
 * @returns {string}
 */

/**
 * @template {Model335} T
 * @param {T} value
 * @returns {T}
 */
function preserve335(value) {
  return value;
}

class Store335 {
  /**
   * @param {Box335<Model335>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project335} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model335} */
const model335 = {
  id: 335, name: "model-335", meta: { active: false, label: "meta-335" },
};
const preserved335 = preserve335(model335);
/** @type {Box335<Model335>} */
const box335 = { value: preserved335, label: "box-335" };
/** @type {Project335} */
const project335 = (input) => `${input.meta.label}:${input.name}`;
const store335 = new Store335(box335);
const rendered335 = store335.read(project335);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult335 = {
  id: preserved335.id,
  name: preserved335.name,
  active: preserved335.meta.active,
  rendered: rendered335,
};

/**
 * @typedef {object} Model336
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box336
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project336
 * @param {Model336} input
 * @returns {string}
 */

/**
 * @template {Model336} T
 * @param {T} value
 * @returns {T}
 */
function preserve336(value) {
  return value;
}

class Store336 {
  /**
   * @param {Box336<Model336>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project336} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model336} */
const model336 = {
  id: 336, name: "model-336", meta: { active: true, label: "meta-336" },
};
const preserved336 = preserve336(model336);
/** @type {Box336<Model336>} */
const box336 = { value: preserved336, label: "box-336" };
/** @type {Project336} */
const project336 = (input) => `${input.meta.label}:${input.name}`;
const store336 = new Store336(box336);
const rendered336 = store336.read(project336);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult336 = {
  id: preserved336.id,
  name: preserved336.name,
  active: preserved336.meta.active,
  rendered: rendered336,
};

/**
 * @typedef {object} Model337
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box337
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project337
 * @param {Model337} input
 * @returns {string}
 */

/**
 * @template {Model337} T
 * @param {T} value
 * @returns {T}
 */
function preserve337(value) {
  return value;
}

class Store337 {
  /**
   * @param {Box337<Model337>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project337} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model337} */
const model337 = {
  id: 337, name: "model-337", meta: { active: false, label: "meta-337" },
};
const preserved337 = preserve337(model337);
/** @type {Box337<Model337>} */
const box337 = { value: preserved337, label: "box-337" };
/** @type {Project337} */
const project337 = (input) => `${input.meta.label}:${input.name}`;
const store337 = new Store337(box337);
const rendered337 = store337.read(project337);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult337 = {
  id: preserved337.id,
  name: preserved337.name,
  active: preserved337.meta.active,
  rendered: rendered337,
};

/**
 * @typedef {object} Model338
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box338
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project338
 * @param {Model338} input
 * @returns {string}
 */

/**
 * @template {Model338} T
 * @param {T} value
 * @returns {T}
 */
function preserve338(value) {
  return value;
}

class Store338 {
  /**
   * @param {Box338<Model338>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project338} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model338} */
const model338 = {
  id: 338, name: "model-338", meta: { active: true, label: "meta-338" },
};
const preserved338 = preserve338(model338);
/** @type {Box338<Model338>} */
const box338 = { value: preserved338, label: "box-338" };
/** @type {Project338} */
const project338 = (input) => `${input.meta.label}:${input.name}`;
const store338 = new Store338(box338);
const rendered338 = store338.read(project338);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult338 = {
  id: preserved338.id,
  name: preserved338.name,
  active: preserved338.meta.active,
  rendered: rendered338,
};

/**
 * @typedef {object} Model339
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box339
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project339
 * @param {Model339} input
 * @returns {string}
 */

/**
 * @template {Model339} T
 * @param {T} value
 * @returns {T}
 */
function preserve339(value) {
  return value;
}

class Store339 {
  /**
   * @param {Box339<Model339>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project339} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model339} */
const model339 = {
  id: 339, name: "model-339", meta: { active: false, label: "meta-339" },
};
const preserved339 = preserve339(model339);
/** @type {Box339<Model339>} */
const box339 = { value: preserved339, label: "box-339" };
/** @type {Project339} */
const project339 = (input) => `${input.meta.label}:${input.name}`;
const store339 = new Store339(box339);
const rendered339 = store339.read(project339);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult339 = {
  id: preserved339.id,
  name: preserved339.name,
  active: preserved339.meta.active,
  rendered: rendered339,
};

/**
 * @typedef {object} Model340
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box340
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project340
 * @param {Model340} input
 * @returns {string}
 */

/**
 * @template {Model340} T
 * @param {T} value
 * @returns {T}
 */
function preserve340(value) {
  return value;
}

class Store340 {
  /**
   * @param {Box340<Model340>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project340} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model340} */
const model340 = {
  id: 340, name: "model-340", meta: { active: true, label: "meta-340" },
};
const preserved340 = preserve340(model340);
/** @type {Box340<Model340>} */
const box340 = { value: preserved340, label: "box-340" };
/** @type {Project340} */
const project340 = (input) => `${input.meta.label}:${input.name}`;
const store340 = new Store340(box340);
const rendered340 = store340.read(project340);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult340 = {
  id: preserved340.id,
  name: preserved340.name,
  active: preserved340.meta.active,
  rendered: rendered340,
};

/**
 * @typedef {object} Model341
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box341
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project341
 * @param {Model341} input
 * @returns {string}
 */

/**
 * @template {Model341} T
 * @param {T} value
 * @returns {T}
 */
function preserve341(value) {
  return value;
}

class Store341 {
  /**
   * @param {Box341<Model341>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project341} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model341} */
const model341 = {
  id: 341, name: "model-341", meta: { active: false, label: "meta-341" },
};
const preserved341 = preserve341(model341);
/** @type {Box341<Model341>} */
const box341 = { value: preserved341, label: "box-341" };
/** @type {Project341} */
const project341 = (input) => `${input.meta.label}:${input.name}`;
const store341 = new Store341(box341);
const rendered341 = store341.read(project341);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult341 = {
  id: preserved341.id,
  name: preserved341.name,
  active: preserved341.meta.active,
  rendered: rendered341,
};

/**
 * @typedef {object} Model342
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box342
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project342
 * @param {Model342} input
 * @returns {string}
 */

/**
 * @template {Model342} T
 * @param {T} value
 * @returns {T}
 */
function preserve342(value) {
  return value;
}

class Store342 {
  /**
   * @param {Box342<Model342>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project342} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model342} */
const model342 = {
  id: 342, name: "model-342", meta: { active: true, label: "meta-342" },
};
const preserved342 = preserve342(model342);
/** @type {Box342<Model342>} */
const box342 = { value: preserved342, label: "box-342" };
/** @type {Project342} */
const project342 = (input) => `${input.meta.label}:${input.name}`;
const store342 = new Store342(box342);
const rendered342 = store342.read(project342);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult342 = {
  id: preserved342.id,
  name: preserved342.name,
  active: preserved342.meta.active,
  rendered: rendered342,
};

/**
 * @typedef {object} Model343
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box343
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project343
 * @param {Model343} input
 * @returns {string}
 */

/**
 * @template {Model343} T
 * @param {T} value
 * @returns {T}
 */
function preserve343(value) {
  return value;
}

class Store343 {
  /**
   * @param {Box343<Model343>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project343} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model343} */
const model343 = {
  id: 343, name: "model-343", meta: { active: false, label: "meta-343" },
};
const preserved343 = preserve343(model343);
/** @type {Box343<Model343>} */
const box343 = { value: preserved343, label: "box-343" };
/** @type {Project343} */
const project343 = (input) => `${input.meta.label}:${input.name}`;
const store343 = new Store343(box343);
const rendered343 = store343.read(project343);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult343 = {
  id: preserved343.id,
  name: preserved343.name,
  active: preserved343.meta.active,
  rendered: rendered343,
};

/**
 * @typedef {object} Model344
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box344
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project344
 * @param {Model344} input
 * @returns {string}
 */

/**
 * @template {Model344} T
 * @param {T} value
 * @returns {T}
 */
function preserve344(value) {
  return value;
}

class Store344 {
  /**
   * @param {Box344<Model344>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project344} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model344} */
const model344 = {
  id: 344, name: "model-344", meta: { active: true, label: "meta-344" },
};
const preserved344 = preserve344(model344);
/** @type {Box344<Model344>} */
const box344 = { value: preserved344, label: "box-344" };
/** @type {Project344} */
const project344 = (input) => `${input.meta.label}:${input.name}`;
const store344 = new Store344(box344);
const rendered344 = store344.read(project344);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult344 = {
  id: preserved344.id,
  name: preserved344.name,
  active: preserved344.meta.active,
  rendered: rendered344,
};

/**
 * @typedef {object} Model345
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box345
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project345
 * @param {Model345} input
 * @returns {string}
 */

/**
 * @template {Model345} T
 * @param {T} value
 * @returns {T}
 */
function preserve345(value) {
  return value;
}

class Store345 {
  /**
   * @param {Box345<Model345>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project345} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model345} */
const model345 = {
  id: 345, name: "model-345", meta: { active: false, label: "meta-345" },
};
const preserved345 = preserve345(model345);
/** @type {Box345<Model345>} */
const box345 = { value: preserved345, label: "box-345" };
/** @type {Project345} */
const project345 = (input) => `${input.meta.label}:${input.name}`;
const store345 = new Store345(box345);
const rendered345 = store345.read(project345);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult345 = {
  id: preserved345.id,
  name: preserved345.name,
  active: preserved345.meta.active,
  rendered: rendered345,
};

/**
 * @typedef {object} Model346
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box346
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project346
 * @param {Model346} input
 * @returns {string}
 */

/**
 * @template {Model346} T
 * @param {T} value
 * @returns {T}
 */
function preserve346(value) {
  return value;
}

class Store346 {
  /**
   * @param {Box346<Model346>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project346} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model346} */
const model346 = {
  id: 346, name: "model-346", meta: { active: true, label: "meta-346" },
};
const preserved346 = preserve346(model346);
/** @type {Box346<Model346>} */
const box346 = { value: preserved346, label: "box-346" };
/** @type {Project346} */
const project346 = (input) => `${input.meta.label}:${input.name}`;
const store346 = new Store346(box346);
const rendered346 = store346.read(project346);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult346 = {
  id: preserved346.id,
  name: preserved346.name,
  active: preserved346.meta.active,
  rendered: rendered346,
};

/**
 * @typedef {object} Model347
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box347
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project347
 * @param {Model347} input
 * @returns {string}
 */

/**
 * @template {Model347} T
 * @param {T} value
 * @returns {T}
 */
function preserve347(value) {
  return value;
}

class Store347 {
  /**
   * @param {Box347<Model347>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project347} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model347} */
const model347 = {
  id: 347, name: "model-347", meta: { active: false, label: "meta-347" },
};
const preserved347 = preserve347(model347);
/** @type {Box347<Model347>} */
const box347 = { value: preserved347, label: "box-347" };
/** @type {Project347} */
const project347 = (input) => `${input.meta.label}:${input.name}`;
const store347 = new Store347(box347);
const rendered347 = store347.read(project347);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult347 = {
  id: preserved347.id,
  name: preserved347.name,
  active: preserved347.meta.active,
  rendered: rendered347,
};

/**
 * @typedef {object} Model348
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box348
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project348
 * @param {Model348} input
 * @returns {string}
 */

/**
 * @template {Model348} T
 * @param {T} value
 * @returns {T}
 */
function preserve348(value) {
  return value;
}

class Store348 {
  /**
   * @param {Box348<Model348>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project348} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model348} */
const model348 = {
  id: 348, name: "model-348", meta: { active: true, label: "meta-348" },
};
const preserved348 = preserve348(model348);
/** @type {Box348<Model348>} */
const box348 = { value: preserved348, label: "box-348" };
/** @type {Project348} */
const project348 = (input) => `${input.meta.label}:${input.name}`;
const store348 = new Store348(box348);
const rendered348 = store348.read(project348);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult348 = {
  id: preserved348.id,
  name: preserved348.name,
  active: preserved348.meta.active,
  rendered: rendered348,
};

/**
 * @typedef {object} Model349
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box349
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project349
 * @param {Model349} input
 * @returns {string}
 */

/**
 * @template {Model349} T
 * @param {T} value
 * @returns {T}
 */
function preserve349(value) {
  return value;
}

class Store349 {
  /**
   * @param {Box349<Model349>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project349} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model349} */
const model349 = {
  id: 349, name: "model-349", meta: { active: false, label: "meta-349" },
};
const preserved349 = preserve349(model349);
/** @type {Box349<Model349>} */
const box349 = { value: preserved349, label: "box-349" };
/** @type {Project349} */
const project349 = (input) => `${input.meta.label}:${input.name}`;
const store349 = new Store349(box349);
const rendered349 = store349.read(project349);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult349 = {
  id: preserved349.id,
  name: preserved349.name,
  active: preserved349.meta.active,
  rendered: rendered349,
};

/**
 * @typedef {object} Model350
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box350
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project350
 * @param {Model350} input
 * @returns {string}
 */

/**
 * @template {Model350} T
 * @param {T} value
 * @returns {T}
 */
function preserve350(value) {
  return value;
}

class Store350 {
  /**
   * @param {Box350<Model350>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project350} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model350} */
const model350 = {
  id: 350, name: "model-350", meta: { active: true, label: "meta-350" },
};
const preserved350 = preserve350(model350);
/** @type {Box350<Model350>} */
const box350 = { value: preserved350, label: "box-350" };
/** @type {Project350} */
const project350 = (input) => `${input.meta.label}:${input.name}`;
const store350 = new Store350(box350);
const rendered350 = store350.read(project350);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult350 = {
  id: preserved350.id,
  name: preserved350.name,
  active: preserved350.meta.active,
  rendered: rendered350,
};

/**
 * @typedef {object} Model351
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box351
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project351
 * @param {Model351} input
 * @returns {string}
 */

/**
 * @template {Model351} T
 * @param {T} value
 * @returns {T}
 */
function preserve351(value) {
  return value;
}

class Store351 {
  /**
   * @param {Box351<Model351>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project351} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model351} */
const model351 = {
  id: 351, name: "model-351", meta: { active: false, label: "meta-351" },
};
const preserved351 = preserve351(model351);
/** @type {Box351<Model351>} */
const box351 = { value: preserved351, label: "box-351" };
/** @type {Project351} */
const project351 = (input) => `${input.meta.label}:${input.name}`;
const store351 = new Store351(box351);
const rendered351 = store351.read(project351);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult351 = {
  id: preserved351.id,
  name: preserved351.name,
  active: preserved351.meta.active,
  rendered: rendered351,
};

/**
 * @typedef {object} Model352
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box352
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project352
 * @param {Model352} input
 * @returns {string}
 */

/**
 * @template {Model352} T
 * @param {T} value
 * @returns {T}
 */
function preserve352(value) {
  return value;
}

class Store352 {
  /**
   * @param {Box352<Model352>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project352} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model352} */
const model352 = {
  id: 352, name: "model-352", meta: { active: true, label: "meta-352" },
};
const preserved352 = preserve352(model352);
/** @type {Box352<Model352>} */
const box352 = { value: preserved352, label: "box-352" };
/** @type {Project352} */
const project352 = (input) => `${input.meta.label}:${input.name}`;
const store352 = new Store352(box352);
const rendered352 = store352.read(project352);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult352 = {
  id: preserved352.id,
  name: preserved352.name,
  active: preserved352.meta.active,
  rendered: rendered352,
};

/**
 * @typedef {object} Model353
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box353
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project353
 * @param {Model353} input
 * @returns {string}
 */

/**
 * @template {Model353} T
 * @param {T} value
 * @returns {T}
 */
function preserve353(value) {
  return value;
}

class Store353 {
  /**
   * @param {Box353<Model353>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project353} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model353} */
const model353 = {
  id: 353, name: "model-353", meta: { active: false, label: "meta-353" },
};
const preserved353 = preserve353(model353);
/** @type {Box353<Model353>} */
const box353 = { value: preserved353, label: "box-353" };
/** @type {Project353} */
const project353 = (input) => `${input.meta.label}:${input.name}`;
const store353 = new Store353(box353);
const rendered353 = store353.read(project353);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult353 = {
  id: preserved353.id,
  name: preserved353.name,
  active: preserved353.meta.active,
  rendered: rendered353,
};

/**
 * @typedef {object} Model354
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box354
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project354
 * @param {Model354} input
 * @returns {string}
 */

/**
 * @template {Model354} T
 * @param {T} value
 * @returns {T}
 */
function preserve354(value) {
  return value;
}

class Store354 {
  /**
   * @param {Box354<Model354>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project354} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model354} */
const model354 = {
  id: 354, name: "model-354", meta: { active: true, label: "meta-354" },
};
const preserved354 = preserve354(model354);
/** @type {Box354<Model354>} */
const box354 = { value: preserved354, label: "box-354" };
/** @type {Project354} */
const project354 = (input) => `${input.meta.label}:${input.name}`;
const store354 = new Store354(box354);
const rendered354 = store354.read(project354);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult354 = {
  id: preserved354.id,
  name: preserved354.name,
  active: preserved354.meta.active,
  rendered: rendered354,
};

/**
 * @typedef {object} Model355
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box355
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project355
 * @param {Model355} input
 * @returns {string}
 */

/**
 * @template {Model355} T
 * @param {T} value
 * @returns {T}
 */
function preserve355(value) {
  return value;
}

class Store355 {
  /**
   * @param {Box355<Model355>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project355} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model355} */
const model355 = {
  id: 355, name: "model-355", meta: { active: false, label: "meta-355" },
};
const preserved355 = preserve355(model355);
/** @type {Box355<Model355>} */
const box355 = { value: preserved355, label: "box-355" };
/** @type {Project355} */
const project355 = (input) => `${input.meta.label}:${input.name}`;
const store355 = new Store355(box355);
const rendered355 = store355.read(project355);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult355 = {
  id: preserved355.id,
  name: preserved355.name,
  active: preserved355.meta.active,
  rendered: rendered355,
};

/**
 * @typedef {object} Model356
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box356
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project356
 * @param {Model356} input
 * @returns {string}
 */

/**
 * @template {Model356} T
 * @param {T} value
 * @returns {T}
 */
function preserve356(value) {
  return value;
}

class Store356 {
  /**
   * @param {Box356<Model356>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project356} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model356} */
const model356 = {
  id: 356, name: "model-356", meta: { active: true, label: "meta-356" },
};
const preserved356 = preserve356(model356);
/** @type {Box356<Model356>} */
const box356 = { value: preserved356, label: "box-356" };
/** @type {Project356} */
const project356 = (input) => `${input.meta.label}:${input.name}`;
const store356 = new Store356(box356);
const rendered356 = store356.read(project356);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult356 = {
  id: preserved356.id,
  name: preserved356.name,
  active: preserved356.meta.active,
  rendered: rendered356,
};

/**
 * @typedef {object} Model357
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box357
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project357
 * @param {Model357} input
 * @returns {string}
 */

/**
 * @template {Model357} T
 * @param {T} value
 * @returns {T}
 */
function preserve357(value) {
  return value;
}

class Store357 {
  /**
   * @param {Box357<Model357>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project357} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model357} */
const model357 = {
  id: 357, name: "model-357", meta: { active: false, label: "meta-357" },
};
const preserved357 = preserve357(model357);
/** @type {Box357<Model357>} */
const box357 = { value: preserved357, label: "box-357" };
/** @type {Project357} */
const project357 = (input) => `${input.meta.label}:${input.name}`;
const store357 = new Store357(box357);
const rendered357 = store357.read(project357);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult357 = {
  id: preserved357.id,
  name: preserved357.name,
  active: preserved357.meta.active,
  rendered: rendered357,
};

/**
 * @typedef {object} Model358
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box358
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project358
 * @param {Model358} input
 * @returns {string}
 */

/**
 * @template {Model358} T
 * @param {T} value
 * @returns {T}
 */
function preserve358(value) {
  return value;
}

class Store358 {
  /**
   * @param {Box358<Model358>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project358} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model358} */
const model358 = {
  id: 358, name: "model-358", meta: { active: true, label: "meta-358" },
};
const preserved358 = preserve358(model358);
/** @type {Box358<Model358>} */
const box358 = { value: preserved358, label: "box-358" };
/** @type {Project358} */
const project358 = (input) => `${input.meta.label}:${input.name}`;
const store358 = new Store358(box358);
const rendered358 = store358.read(project358);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult358 = {
  id: preserved358.id,
  name: preserved358.name,
  active: preserved358.meta.active,
  rendered: rendered358,
};

/**
 * @typedef {object} Model359
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box359
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project359
 * @param {Model359} input
 * @returns {string}
 */

/**
 * @template {Model359} T
 * @param {T} value
 * @returns {T}
 */
function preserve359(value) {
  return value;
}

class Store359 {
  /**
   * @param {Box359<Model359>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project359} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model359} */
const model359 = {
  id: 359, name: "model-359", meta: { active: false, label: "meta-359" },
};
const preserved359 = preserve359(model359);
/** @type {Box359<Model359>} */
const box359 = { value: preserved359, label: "box-359" };
/** @type {Project359} */
const project359 = (input) => `${input.meta.label}:${input.name}`;
const store359 = new Store359(box359);
const rendered359 = store359.read(project359);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult359 = {
  id: preserved359.id,
  name: preserved359.name,
  active: preserved359.meta.active,
  rendered: rendered359,
};

/**
 * @typedef {object} Model360
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box360
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project360
 * @param {Model360} input
 * @returns {string}
 */

/**
 * @template {Model360} T
 * @param {T} value
 * @returns {T}
 */
function preserve360(value) {
  return value;
}

class Store360 {
  /**
   * @param {Box360<Model360>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project360} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model360} */
const model360 = {
  id: 360, name: "model-360", meta: { active: true, label: "meta-360" },
};
const preserved360 = preserve360(model360);
/** @type {Box360<Model360>} */
const box360 = { value: preserved360, label: "box-360" };
/** @type {Project360} */
const project360 = (input) => `${input.meta.label}:${input.name}`;
const store360 = new Store360(box360);
const rendered360 = store360.read(project360);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult360 = {
  id: preserved360.id,
  name: preserved360.name,
  active: preserved360.meta.active,
  rendered: rendered360,
};

/**
 * @typedef {object} Model361
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box361
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project361
 * @param {Model361} input
 * @returns {string}
 */

/**
 * @template {Model361} T
 * @param {T} value
 * @returns {T}
 */
function preserve361(value) {
  return value;
}

class Store361 {
  /**
   * @param {Box361<Model361>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project361} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model361} */
const model361 = {
  id: 361, name: "model-361", meta: { active: false, label: "meta-361" },
};
const preserved361 = preserve361(model361);
/** @type {Box361<Model361>} */
const box361 = { value: preserved361, label: "box-361" };
/** @type {Project361} */
const project361 = (input) => `${input.meta.label}:${input.name}`;
const store361 = new Store361(box361);
const rendered361 = store361.read(project361);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult361 = {
  id: preserved361.id,
  name: preserved361.name,
  active: preserved361.meta.active,
  rendered: rendered361,
};

/**
 * @typedef {object} Model362
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box362
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project362
 * @param {Model362} input
 * @returns {string}
 */

/**
 * @template {Model362} T
 * @param {T} value
 * @returns {T}
 */
function preserve362(value) {
  return value;
}

class Store362 {
  /**
   * @param {Box362<Model362>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project362} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model362} */
const model362 = {
  id: 362, name: "model-362", meta: { active: true, label: "meta-362" },
};
const preserved362 = preserve362(model362);
/** @type {Box362<Model362>} */
const box362 = { value: preserved362, label: "box-362" };
/** @type {Project362} */
const project362 = (input) => `${input.meta.label}:${input.name}`;
const store362 = new Store362(box362);
const rendered362 = store362.read(project362);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult362 = {
  id: preserved362.id,
  name: preserved362.name,
  active: preserved362.meta.active,
  rendered: rendered362,
};

/**
 * @typedef {object} Model363
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box363
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project363
 * @param {Model363} input
 * @returns {string}
 */

/**
 * @template {Model363} T
 * @param {T} value
 * @returns {T}
 */
function preserve363(value) {
  return value;
}

class Store363 {
  /**
   * @param {Box363<Model363>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project363} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model363} */
const model363 = {
  id: 363, name: "model-363", meta: { active: false, label: "meta-363" },
};
const preserved363 = preserve363(model363);
/** @type {Box363<Model363>} */
const box363 = { value: preserved363, label: "box-363" };
/** @type {Project363} */
const project363 = (input) => `${input.meta.label}:${input.name}`;
const store363 = new Store363(box363);
const rendered363 = store363.read(project363);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult363 = {
  id: preserved363.id,
  name: preserved363.name,
  active: preserved363.meta.active,
  rendered: rendered363,
};

/**
 * @typedef {object} Model364
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box364
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project364
 * @param {Model364} input
 * @returns {string}
 */

/**
 * @template {Model364} T
 * @param {T} value
 * @returns {T}
 */
function preserve364(value) {
  return value;
}

class Store364 {
  /**
   * @param {Box364<Model364>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project364} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model364} */
const model364 = {
  id: 364, name: "model-364", meta: { active: true, label: "meta-364" },
};
const preserved364 = preserve364(model364);
/** @type {Box364<Model364>} */
const box364 = { value: preserved364, label: "box-364" };
/** @type {Project364} */
const project364 = (input) => `${input.meta.label}:${input.name}`;
const store364 = new Store364(box364);
const rendered364 = store364.read(project364);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult364 = {
  id: preserved364.id,
  name: preserved364.name,
  active: preserved364.meta.active,
  rendered: rendered364,
};

/**
 * @typedef {object} Model365
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box365
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project365
 * @param {Model365} input
 * @returns {string}
 */

/**
 * @template {Model365} T
 * @param {T} value
 * @returns {T}
 */
function preserve365(value) {
  return value;
}

class Store365 {
  /**
   * @param {Box365<Model365>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project365} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model365} */
const model365 = {
  id: 365, name: "model-365", meta: { active: false, label: "meta-365" },
};
const preserved365 = preserve365(model365);
/** @type {Box365<Model365>} */
const box365 = { value: preserved365, label: "box-365" };
/** @type {Project365} */
const project365 = (input) => `${input.meta.label}:${input.name}`;
const store365 = new Store365(box365);
const rendered365 = store365.read(project365);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult365 = {
  id: preserved365.id,
  name: preserved365.name,
  active: preserved365.meta.active,
  rendered: rendered365,
};

/**
 * @typedef {object} Model366
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box366
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project366
 * @param {Model366} input
 * @returns {string}
 */

/**
 * @template {Model366} T
 * @param {T} value
 * @returns {T}
 */
function preserve366(value) {
  return value;
}

class Store366 {
  /**
   * @param {Box366<Model366>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project366} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model366} */
const model366 = {
  id: 366, name: "model-366", meta: { active: true, label: "meta-366" },
};
const preserved366 = preserve366(model366);
/** @type {Box366<Model366>} */
const box366 = { value: preserved366, label: "box-366" };
/** @type {Project366} */
const project366 = (input) => `${input.meta.label}:${input.name}`;
const store366 = new Store366(box366);
const rendered366 = store366.read(project366);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult366 = {
  id: preserved366.id,
  name: preserved366.name,
  active: preserved366.meta.active,
  rendered: rendered366,
};

/**
 * @typedef {object} Model367
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box367
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project367
 * @param {Model367} input
 * @returns {string}
 */

/**
 * @template {Model367} T
 * @param {T} value
 * @returns {T}
 */
function preserve367(value) {
  return value;
}

class Store367 {
  /**
   * @param {Box367<Model367>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project367} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model367} */
const model367 = {
  id: 367, name: "model-367", meta: { active: false, label: "meta-367" },
};
const preserved367 = preserve367(model367);
/** @type {Box367<Model367>} */
const box367 = { value: preserved367, label: "box-367" };
/** @type {Project367} */
const project367 = (input) => `${input.meta.label}:${input.name}`;
const store367 = new Store367(box367);
const rendered367 = store367.read(project367);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult367 = {
  id: preserved367.id,
  name: preserved367.name,
  active: preserved367.meta.active,
  rendered: rendered367,
};

/**
 * @typedef {object} Model368
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box368
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project368
 * @param {Model368} input
 * @returns {string}
 */

/**
 * @template {Model368} T
 * @param {T} value
 * @returns {T}
 */
function preserve368(value) {
  return value;
}

class Store368 {
  /**
   * @param {Box368<Model368>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project368} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model368} */
const model368 = {
  id: 368, name: "model-368", meta: { active: true, label: "meta-368" },
};
const preserved368 = preserve368(model368);
/** @type {Box368<Model368>} */
const box368 = { value: preserved368, label: "box-368" };
/** @type {Project368} */
const project368 = (input) => `${input.meta.label}:${input.name}`;
const store368 = new Store368(box368);
const rendered368 = store368.read(project368);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult368 = {
  id: preserved368.id,
  name: preserved368.name,
  active: preserved368.meta.active,
  rendered: rendered368,
};

/**
 * @typedef {object} Model369
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box369
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project369
 * @param {Model369} input
 * @returns {string}
 */

/**
 * @template {Model369} T
 * @param {T} value
 * @returns {T}
 */
function preserve369(value) {
  return value;
}

class Store369 {
  /**
   * @param {Box369<Model369>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project369} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model369} */
const model369 = {
  id: 369, name: "model-369", meta: { active: false, label: "meta-369" },
};
const preserved369 = preserve369(model369);
/** @type {Box369<Model369>} */
const box369 = { value: preserved369, label: "box-369" };
/** @type {Project369} */
const project369 = (input) => `${input.meta.label}:${input.name}`;
const store369 = new Store369(box369);
const rendered369 = store369.read(project369);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult369 = {
  id: preserved369.id,
  name: preserved369.name,
  active: preserved369.meta.active,
  rendered: rendered369,
};

/**
 * @typedef {object} Model370
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box370
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project370
 * @param {Model370} input
 * @returns {string}
 */

/**
 * @template {Model370} T
 * @param {T} value
 * @returns {T}
 */
function preserve370(value) {
  return value;
}

class Store370 {
  /**
   * @param {Box370<Model370>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project370} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model370} */
const model370 = {
  id: 370, name: "model-370", meta: { active: true, label: "meta-370" },
};
const preserved370 = preserve370(model370);
/** @type {Box370<Model370>} */
const box370 = { value: preserved370, label: "box-370" };
/** @type {Project370} */
const project370 = (input) => `${input.meta.label}:${input.name}`;
const store370 = new Store370(box370);
const rendered370 = store370.read(project370);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult370 = {
  id: preserved370.id,
  name: preserved370.name,
  active: preserved370.meta.active,
  rendered: rendered370,
};

/**
 * @typedef {object} Model371
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box371
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project371
 * @param {Model371} input
 * @returns {string}
 */

/**
 * @template {Model371} T
 * @param {T} value
 * @returns {T}
 */
function preserve371(value) {
  return value;
}

class Store371 {
  /**
   * @param {Box371<Model371>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project371} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model371} */
const model371 = {
  id: 371, name: "model-371", meta: { active: false, label: "meta-371" },
};
const preserved371 = preserve371(model371);
/** @type {Box371<Model371>} */
const box371 = { value: preserved371, label: "box-371" };
/** @type {Project371} */
const project371 = (input) => `${input.meta.label}:${input.name}`;
const store371 = new Store371(box371);
const rendered371 = store371.read(project371);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult371 = {
  id: preserved371.id,
  name: preserved371.name,
  active: preserved371.meta.active,
  rendered: rendered371,
};

/**
 * @typedef {object} Model372
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box372
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project372
 * @param {Model372} input
 * @returns {string}
 */

/**
 * @template {Model372} T
 * @param {T} value
 * @returns {T}
 */
function preserve372(value) {
  return value;
}

class Store372 {
  /**
   * @param {Box372<Model372>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project372} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model372} */
const model372 = {
  id: 372, name: "model-372", meta: { active: true, label: "meta-372" },
};
const preserved372 = preserve372(model372);
/** @type {Box372<Model372>} */
const box372 = { value: preserved372, label: "box-372" };
/** @type {Project372} */
const project372 = (input) => `${input.meta.label}:${input.name}`;
const store372 = new Store372(box372);
const rendered372 = store372.read(project372);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult372 = {
  id: preserved372.id,
  name: preserved372.name,
  active: preserved372.meta.active,
  rendered: rendered372,
};

/**
 * @typedef {object} Model373
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box373
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project373
 * @param {Model373} input
 * @returns {string}
 */

/**
 * @template {Model373} T
 * @param {T} value
 * @returns {T}
 */
function preserve373(value) {
  return value;
}

class Store373 {
  /**
   * @param {Box373<Model373>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project373} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model373} */
const model373 = {
  id: 373, name: "model-373", meta: { active: false, label: "meta-373" },
};
const preserved373 = preserve373(model373);
/** @type {Box373<Model373>} */
const box373 = { value: preserved373, label: "box-373" };
/** @type {Project373} */
const project373 = (input) => `${input.meta.label}:${input.name}`;
const store373 = new Store373(box373);
const rendered373 = store373.read(project373);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult373 = {
  id: preserved373.id,
  name: preserved373.name,
  active: preserved373.meta.active,
  rendered: rendered373,
};

/**
 * @typedef {object} Model374
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box374
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project374
 * @param {Model374} input
 * @returns {string}
 */

/**
 * @template {Model374} T
 * @param {T} value
 * @returns {T}
 */
function preserve374(value) {
  return value;
}

class Store374 {
  /**
   * @param {Box374<Model374>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project374} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model374} */
const model374 = {
  id: 374, name: "model-374", meta: { active: true, label: "meta-374" },
};
const preserved374 = preserve374(model374);
/** @type {Box374<Model374>} */
const box374 = { value: preserved374, label: "box-374" };
/** @type {Project374} */
const project374 = (input) => `${input.meta.label}:${input.name}`;
const store374 = new Store374(box374);
const rendered374 = store374.read(project374);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult374 = {
  id: preserved374.id,
  name: preserved374.name,
  active: preserved374.meta.active,
  rendered: rendered374,
};

/**
 * @typedef {object} Model375
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box375
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project375
 * @param {Model375} input
 * @returns {string}
 */

/**
 * @template {Model375} T
 * @param {T} value
 * @returns {T}
 */
function preserve375(value) {
  return value;
}

class Store375 {
  /**
   * @param {Box375<Model375>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project375} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model375} */
const model375 = {
  id: 375, name: "model-375", meta: { active: false, label: "meta-375" },
};
const preserved375 = preserve375(model375);
/** @type {Box375<Model375>} */
const box375 = { value: preserved375, label: "box-375" };
/** @type {Project375} */
const project375 = (input) => `${input.meta.label}:${input.name}`;
const store375 = new Store375(box375);
const rendered375 = store375.read(project375);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult375 = {
  id: preserved375.id,
  name: preserved375.name,
  active: preserved375.meta.active,
  rendered: rendered375,
};

/**
 * @typedef {object} Model376
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box376
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project376
 * @param {Model376} input
 * @returns {string}
 */

/**
 * @template {Model376} T
 * @param {T} value
 * @returns {T}
 */
function preserve376(value) {
  return value;
}

class Store376 {
  /**
   * @param {Box376<Model376>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project376} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model376} */
const model376 = {
  id: 376, name: "model-376", meta: { active: true, label: "meta-376" },
};
const preserved376 = preserve376(model376);
/** @type {Box376<Model376>} */
const box376 = { value: preserved376, label: "box-376" };
/** @type {Project376} */
const project376 = (input) => `${input.meta.label}:${input.name}`;
const store376 = new Store376(box376);
const rendered376 = store376.read(project376);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult376 = {
  id: preserved376.id,
  name: preserved376.name,
  active: preserved376.meta.active,
  rendered: rendered376,
};

/**
 * @typedef {object} Model377
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box377
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project377
 * @param {Model377} input
 * @returns {string}
 */

/**
 * @template {Model377} T
 * @param {T} value
 * @returns {T}
 */
function preserve377(value) {
  return value;
}

class Store377 {
  /**
   * @param {Box377<Model377>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project377} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model377} */
const model377 = {
  id: 377, name: "model-377", meta: { active: false, label: "meta-377" },
};
const preserved377 = preserve377(model377);
/** @type {Box377<Model377>} */
const box377 = { value: preserved377, label: "box-377" };
/** @type {Project377} */
const project377 = (input) => `${input.meta.label}:${input.name}`;
const store377 = new Store377(box377);
const rendered377 = store377.read(project377);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult377 = {
  id: preserved377.id,
  name: preserved377.name,
  active: preserved377.meta.active,
  rendered: rendered377,
};

/**
 * @typedef {object} Model378
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box378
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project378
 * @param {Model378} input
 * @returns {string}
 */

/**
 * @template {Model378} T
 * @param {T} value
 * @returns {T}
 */
function preserve378(value) {
  return value;
}

class Store378 {
  /**
   * @param {Box378<Model378>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project378} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model378} */
const model378 = {
  id: 378, name: "model-378", meta: { active: true, label: "meta-378" },
};
const preserved378 = preserve378(model378);
/** @type {Box378<Model378>} */
const box378 = { value: preserved378, label: "box-378" };
/** @type {Project378} */
const project378 = (input) => `${input.meta.label}:${input.name}`;
const store378 = new Store378(box378);
const rendered378 = store378.read(project378);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult378 = {
  id: preserved378.id,
  name: preserved378.name,
  active: preserved378.meta.active,
  rendered: rendered378,
};

/**
 * @typedef {object} Model379
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box379
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project379
 * @param {Model379} input
 * @returns {string}
 */

/**
 * @template {Model379} T
 * @param {T} value
 * @returns {T}
 */
function preserve379(value) {
  return value;
}

class Store379 {
  /**
   * @param {Box379<Model379>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project379} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model379} */
const model379 = {
  id: 379, name: "model-379", meta: { active: false, label: "meta-379" },
};
const preserved379 = preserve379(model379);
/** @type {Box379<Model379>} */
const box379 = { value: preserved379, label: "box-379" };
/** @type {Project379} */
const project379 = (input) => `${input.meta.label}:${input.name}`;
const store379 = new Store379(box379);
const rendered379 = store379.read(project379);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult379 = {
  id: preserved379.id,
  name: preserved379.name,
  active: preserved379.meta.active,
  rendered: rendered379,
};

/**
 * @typedef {object} Model380
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box380
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project380
 * @param {Model380} input
 * @returns {string}
 */

/**
 * @template {Model380} T
 * @param {T} value
 * @returns {T}
 */
function preserve380(value) {
  return value;
}

class Store380 {
  /**
   * @param {Box380<Model380>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project380} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model380} */
const model380 = {
  id: 380, name: "model-380", meta: { active: true, label: "meta-380" },
};
const preserved380 = preserve380(model380);
/** @type {Box380<Model380>} */
const box380 = { value: preserved380, label: "box-380" };
/** @type {Project380} */
const project380 = (input) => `${input.meta.label}:${input.name}`;
const store380 = new Store380(box380);
const rendered380 = store380.read(project380);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult380 = {
  id: preserved380.id,
  name: preserved380.name,
  active: preserved380.meta.active,
  rendered: rendered380,
};

/**
 * @typedef {object} Model381
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box381
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project381
 * @param {Model381} input
 * @returns {string}
 */

/**
 * @template {Model381} T
 * @param {T} value
 * @returns {T}
 */
function preserve381(value) {
  return value;
}

class Store381 {
  /**
   * @param {Box381<Model381>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project381} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model381} */
const model381 = {
  id: 381, name: "model-381", meta: { active: false, label: "meta-381" },
};
const preserved381 = preserve381(model381);
/** @type {Box381<Model381>} */
const box381 = { value: preserved381, label: "box-381" };
/** @type {Project381} */
const project381 = (input) => `${input.meta.label}:${input.name}`;
const store381 = new Store381(box381);
const rendered381 = store381.read(project381);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult381 = {
  id: preserved381.id,
  name: preserved381.name,
  active: preserved381.meta.active,
  rendered: rendered381,
};

/**
 * @typedef {object} Model382
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box382
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project382
 * @param {Model382} input
 * @returns {string}
 */

/**
 * @template {Model382} T
 * @param {T} value
 * @returns {T}
 */
function preserve382(value) {
  return value;
}

class Store382 {
  /**
   * @param {Box382<Model382>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project382} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model382} */
const model382 = {
  id: 382, name: "model-382", meta: { active: true, label: "meta-382" },
};
const preserved382 = preserve382(model382);
/** @type {Box382<Model382>} */
const box382 = { value: preserved382, label: "box-382" };
/** @type {Project382} */
const project382 = (input) => `${input.meta.label}:${input.name}`;
const store382 = new Store382(box382);
const rendered382 = store382.read(project382);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult382 = {
  id: preserved382.id,
  name: preserved382.name,
  active: preserved382.meta.active,
  rendered: rendered382,
};

/**
 * @typedef {object} Model383
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box383
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project383
 * @param {Model383} input
 * @returns {string}
 */

/**
 * @template {Model383} T
 * @param {T} value
 * @returns {T}
 */
function preserve383(value) {
  return value;
}

class Store383 {
  /**
   * @param {Box383<Model383>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project383} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model383} */
const model383 = {
  id: 383, name: "model-383", meta: { active: false, label: "meta-383" },
};
const preserved383 = preserve383(model383);
/** @type {Box383<Model383>} */
const box383 = { value: preserved383, label: "box-383" };
/** @type {Project383} */
const project383 = (input) => `${input.meta.label}:${input.name}`;
const store383 = new Store383(box383);
const rendered383 = store383.read(project383);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult383 = {
  id: preserved383.id,
  name: preserved383.name,
  active: preserved383.meta.active,
  rendered: rendered383,
};

/**
 * @typedef {object} Model384
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box384
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project384
 * @param {Model384} input
 * @returns {string}
 */

/**
 * @template {Model384} T
 * @param {T} value
 * @returns {T}
 */
function preserve384(value) {
  return value;
}

class Store384 {
  /**
   * @param {Box384<Model384>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project384} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model384} */
const model384 = {
  id: 384, name: "model-384", meta: { active: true, label: "meta-384" },
};
const preserved384 = preserve384(model384);
/** @type {Box384<Model384>} */
const box384 = { value: preserved384, label: "box-384" };
/** @type {Project384} */
const project384 = (input) => `${input.meta.label}:${input.name}`;
const store384 = new Store384(box384);
const rendered384 = store384.read(project384);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult384 = {
  id: preserved384.id,
  name: preserved384.name,
  active: preserved384.meta.active,
  rendered: rendered384,
};

/**
 * @typedef {object} Model385
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box385
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project385
 * @param {Model385} input
 * @returns {string}
 */

/**
 * @template {Model385} T
 * @param {T} value
 * @returns {T}
 */
function preserve385(value) {
  return value;
}

class Store385 {
  /**
   * @param {Box385<Model385>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project385} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model385} */
const model385 = {
  id: 385, name: "model-385", meta: { active: false, label: "meta-385" },
};
const preserved385 = preserve385(model385);
/** @type {Box385<Model385>} */
const box385 = { value: preserved385, label: "box-385" };
/** @type {Project385} */
const project385 = (input) => `${input.meta.label}:${input.name}`;
const store385 = new Store385(box385);
const rendered385 = store385.read(project385);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult385 = {
  id: preserved385.id,
  name: preserved385.name,
  active: preserved385.meta.active,
  rendered: rendered385,
};

/**
 * @typedef {object} Model386
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box386
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project386
 * @param {Model386} input
 * @returns {string}
 */

/**
 * @template {Model386} T
 * @param {T} value
 * @returns {T}
 */
function preserve386(value) {
  return value;
}

class Store386 {
  /**
   * @param {Box386<Model386>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project386} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model386} */
const model386 = {
  id: 386, name: "model-386", meta: { active: true, label: "meta-386" },
};
const preserved386 = preserve386(model386);
/** @type {Box386<Model386>} */
const box386 = { value: preserved386, label: "box-386" };
/** @type {Project386} */
const project386 = (input) => `${input.meta.label}:${input.name}`;
const store386 = new Store386(box386);
const rendered386 = store386.read(project386);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult386 = {
  id: preserved386.id,
  name: preserved386.name,
  active: preserved386.meta.active,
  rendered: rendered386,
};

/**
 * @typedef {object} Model387
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box387
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project387
 * @param {Model387} input
 * @returns {string}
 */

/**
 * @template {Model387} T
 * @param {T} value
 * @returns {T}
 */
function preserve387(value) {
  return value;
}

class Store387 {
  /**
   * @param {Box387<Model387>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project387} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model387} */
const model387 = {
  id: 387, name: "model-387", meta: { active: false, label: "meta-387" },
};
const preserved387 = preserve387(model387);
/** @type {Box387<Model387>} */
const box387 = { value: preserved387, label: "box-387" };
/** @type {Project387} */
const project387 = (input) => `${input.meta.label}:${input.name}`;
const store387 = new Store387(box387);
const rendered387 = store387.read(project387);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult387 = {
  id: preserved387.id,
  name: preserved387.name,
  active: preserved387.meta.active,
  rendered: rendered387,
};

/**
 * @typedef {object} Model388
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box388
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project388
 * @param {Model388} input
 * @returns {string}
 */

/**
 * @template {Model388} T
 * @param {T} value
 * @returns {T}
 */
function preserve388(value) {
  return value;
}

class Store388 {
  /**
   * @param {Box388<Model388>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project388} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model388} */
const model388 = {
  id: 388, name: "model-388", meta: { active: true, label: "meta-388" },
};
const preserved388 = preserve388(model388);
/** @type {Box388<Model388>} */
const box388 = { value: preserved388, label: "box-388" };
/** @type {Project388} */
const project388 = (input) => `${input.meta.label}:${input.name}`;
const store388 = new Store388(box388);
const rendered388 = store388.read(project388);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult388 = {
  id: preserved388.id,
  name: preserved388.name,
  active: preserved388.meta.active,
  rendered: rendered388,
};

/**
 * @typedef {object} Model389
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box389
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project389
 * @param {Model389} input
 * @returns {string}
 */

/**
 * @template {Model389} T
 * @param {T} value
 * @returns {T}
 */
function preserve389(value) {
  return value;
}

class Store389 {
  /**
   * @param {Box389<Model389>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project389} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model389} */
const model389 = {
  id: 389, name: "model-389", meta: { active: false, label: "meta-389" },
};
const preserved389 = preserve389(model389);
/** @type {Box389<Model389>} */
const box389 = { value: preserved389, label: "box-389" };
/** @type {Project389} */
const project389 = (input) => `${input.meta.label}:${input.name}`;
const store389 = new Store389(box389);
const rendered389 = store389.read(project389);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult389 = {
  id: preserved389.id,
  name: preserved389.name,
  active: preserved389.meta.active,
  rendered: rendered389,
};

/**
 * @typedef {object} Model390
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box390
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project390
 * @param {Model390} input
 * @returns {string}
 */

/**
 * @template {Model390} T
 * @param {T} value
 * @returns {T}
 */
function preserve390(value) {
  return value;
}

class Store390 {
  /**
   * @param {Box390<Model390>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project390} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model390} */
const model390 = {
  id: 390, name: "model-390", meta: { active: true, label: "meta-390" },
};
const preserved390 = preserve390(model390);
/** @type {Box390<Model390>} */
const box390 = { value: preserved390, label: "box-390" };
/** @type {Project390} */
const project390 = (input) => `${input.meta.label}:${input.name}`;
const store390 = new Store390(box390);
const rendered390 = store390.read(project390);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult390 = {
  id: preserved390.id,
  name: preserved390.name,
  active: preserved390.meta.active,
  rendered: rendered390,
};

/**
 * @typedef {object} Model391
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box391
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project391
 * @param {Model391} input
 * @returns {string}
 */

/**
 * @template {Model391} T
 * @param {T} value
 * @returns {T}
 */
function preserve391(value) {
  return value;
}

class Store391 {
  /**
   * @param {Box391<Model391>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project391} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model391} */
const model391 = {
  id: 391, name: "model-391", meta: { active: false, label: "meta-391" },
};
const preserved391 = preserve391(model391);
/** @type {Box391<Model391>} */
const box391 = { value: preserved391, label: "box-391" };
/** @type {Project391} */
const project391 = (input) => `${input.meta.label}:${input.name}`;
const store391 = new Store391(box391);
const rendered391 = store391.read(project391);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult391 = {
  id: preserved391.id,
  name: preserved391.name,
  active: preserved391.meta.active,
  rendered: rendered391,
};

/**
 * @typedef {object} Model392
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box392
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project392
 * @param {Model392} input
 * @returns {string}
 */

/**
 * @template {Model392} T
 * @param {T} value
 * @returns {T}
 */
function preserve392(value) {
  return value;
}

class Store392 {
  /**
   * @param {Box392<Model392>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project392} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model392} */
const model392 = {
  id: 392, name: "model-392", meta: { active: true, label: "meta-392" },
};
const preserved392 = preserve392(model392);
/** @type {Box392<Model392>} */
const box392 = { value: preserved392, label: "box-392" };
/** @type {Project392} */
const project392 = (input) => `${input.meta.label}:${input.name}`;
const store392 = new Store392(box392);
const rendered392 = store392.read(project392);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult392 = {
  id: preserved392.id,
  name: preserved392.name,
  active: preserved392.meta.active,
  rendered: rendered392,
};

/**
 * @typedef {object} Model393
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box393
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project393
 * @param {Model393} input
 * @returns {string}
 */

/**
 * @template {Model393} T
 * @param {T} value
 * @returns {T}
 */
function preserve393(value) {
  return value;
}

class Store393 {
  /**
   * @param {Box393<Model393>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project393} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model393} */
const model393 = {
  id: 393, name: "model-393", meta: { active: false, label: "meta-393" },
};
const preserved393 = preserve393(model393);
/** @type {Box393<Model393>} */
const box393 = { value: preserved393, label: "box-393" };
/** @type {Project393} */
const project393 = (input) => `${input.meta.label}:${input.name}`;
const store393 = new Store393(box393);
const rendered393 = store393.read(project393);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult393 = {
  id: preserved393.id,
  name: preserved393.name,
  active: preserved393.meta.active,
  rendered: rendered393,
};

/**
 * @typedef {object} Model394
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box394
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project394
 * @param {Model394} input
 * @returns {string}
 */

/**
 * @template {Model394} T
 * @param {T} value
 * @returns {T}
 */
function preserve394(value) {
  return value;
}

class Store394 {
  /**
   * @param {Box394<Model394>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project394} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model394} */
const model394 = {
  id: 394, name: "model-394", meta: { active: true, label: "meta-394" },
};
const preserved394 = preserve394(model394);
/** @type {Box394<Model394>} */
const box394 = { value: preserved394, label: "box-394" };
/** @type {Project394} */
const project394 = (input) => `${input.meta.label}:${input.name}`;
const store394 = new Store394(box394);
const rendered394 = store394.read(project394);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult394 = {
  id: preserved394.id,
  name: preserved394.name,
  active: preserved394.meta.active,
  rendered: rendered394,
};

/**
 * @typedef {object} Model395
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box395
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project395
 * @param {Model395} input
 * @returns {string}
 */

/**
 * @template {Model395} T
 * @param {T} value
 * @returns {T}
 */
function preserve395(value) {
  return value;
}

class Store395 {
  /**
   * @param {Box395<Model395>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project395} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model395} */
const model395 = {
  id: 395, name: "model-395", meta: { active: false, label: "meta-395" },
};
const preserved395 = preserve395(model395);
/** @type {Box395<Model395>} */
const box395 = { value: preserved395, label: "box-395" };
/** @type {Project395} */
const project395 = (input) => `${input.meta.label}:${input.name}`;
const store395 = new Store395(box395);
const rendered395 = store395.read(project395);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult395 = {
  id: preserved395.id,
  name: preserved395.name,
  active: preserved395.meta.active,
  rendered: rendered395,
};

/**
 * @typedef {object} Model396
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box396
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project396
 * @param {Model396} input
 * @returns {string}
 */

/**
 * @template {Model396} T
 * @param {T} value
 * @returns {T}
 */
function preserve396(value) {
  return value;
}

class Store396 {
  /**
   * @param {Box396<Model396>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project396} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model396} */
const model396 = {
  id: 396, name: "model-396", meta: { active: true, label: "meta-396" },
};
const preserved396 = preserve396(model396);
/** @type {Box396<Model396>} */
const box396 = { value: preserved396, label: "box-396" };
/** @type {Project396} */
const project396 = (input) => `${input.meta.label}:${input.name}`;
const store396 = new Store396(box396);
const rendered396 = store396.read(project396);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult396 = {
  id: preserved396.id,
  name: preserved396.name,
  active: preserved396.meta.active,
  rendered: rendered396,
};

/**
 * @typedef {object} Model397
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box397
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project397
 * @param {Model397} input
 * @returns {string}
 */

/**
 * @template {Model397} T
 * @param {T} value
 * @returns {T}
 */
function preserve397(value) {
  return value;
}

class Store397 {
  /**
   * @param {Box397<Model397>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project397} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model397} */
const model397 = {
  id: 397, name: "model-397", meta: { active: false, label: "meta-397" },
};
const preserved397 = preserve397(model397);
/** @type {Box397<Model397>} */
const box397 = { value: preserved397, label: "box-397" };
/** @type {Project397} */
const project397 = (input) => `${input.meta.label}:${input.name}`;
const store397 = new Store397(box397);
const rendered397 = store397.read(project397);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult397 = {
  id: preserved397.id,
  name: preserved397.name,
  active: preserved397.meta.active,
  rendered: rendered397,
};

/**
 * @typedef {object} Model398
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box398
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project398
 * @param {Model398} input
 * @returns {string}
 */

/**
 * @template {Model398} T
 * @param {T} value
 * @returns {T}
 */
function preserve398(value) {
  return value;
}

class Store398 {
  /**
   * @param {Box398<Model398>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project398} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model398} */
const model398 = {
  id: 398, name: "model-398", meta: { active: true, label: "meta-398" },
};
const preserved398 = preserve398(model398);
/** @type {Box398<Model398>} */
const box398 = { value: preserved398, label: "box-398" };
/** @type {Project398} */
const project398 = (input) => `${input.meta.label}:${input.name}`;
const store398 = new Store398(box398);
const rendered398 = store398.read(project398);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult398 = {
  id: preserved398.id,
  name: preserved398.name,
  active: preserved398.meta.active,
  rendered: rendered398,
};

/**
 * @typedef {object} Model399
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box399
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project399
 * @param {Model399} input
 * @returns {string}
 */

/**
 * @template {Model399} T
 * @param {T} value
 * @returns {T}
 */
function preserve399(value) {
  return value;
}

class Store399 {
  /**
   * @param {Box399<Model399>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project399} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model399} */
const model399 = {
  id: 399, name: "model-399", meta: { active: false, label: "meta-399" },
};
const preserved399 = preserve399(model399);
/** @type {Box399<Model399>} */
const box399 = { value: preserved399, label: "box-399" };
/** @type {Project399} */
const project399 = (input) => `${input.meta.label}:${input.name}`;
const store399 = new Store399(box399);
const rendered399 = store399.read(project399);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult399 = {
  id: preserved399.id,
  name: preserved399.name,
  active: preserved399.meta.active,
  rendered: rendered399,
};

/**
 * @typedef {object} Model400
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box400
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project400
 * @param {Model400} input
 * @returns {string}
 */

/**
 * @template {Model400} T
 * @param {T} value
 * @returns {T}
 */
function preserve400(value) {
  return value;
}

class Store400 {
  /**
   * @param {Box400<Model400>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project400} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model400} */
const model400 = {
  id: 400, name: "model-400", meta: { active: true, label: "meta-400" },
};
const preserved400 = preserve400(model400);
/** @type {Box400<Model400>} */
const box400 = { value: preserved400, label: "box-400" };
/** @type {Project400} */
const project400 = (input) => `${input.meta.label}:${input.name}`;
const store400 = new Store400(box400);
const rendered400 = store400.read(project400);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult400 = {
  id: preserved400.id,
  name: preserved400.name,
  active: preserved400.meta.active,
  rendered: rendered400,
};

/**
 * @typedef {object} Model401
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box401
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project401
 * @param {Model401} input
 * @returns {string}
 */

/**
 * @template {Model401} T
 * @param {T} value
 * @returns {T}
 */
function preserve401(value) {
  return value;
}

class Store401 {
  /**
   * @param {Box401<Model401>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project401} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model401} */
const model401 = {
  id: 401, name: "model-401", meta: { active: false, label: "meta-401" },
};
const preserved401 = preserve401(model401);
/** @type {Box401<Model401>} */
const box401 = { value: preserved401, label: "box-401" };
/** @type {Project401} */
const project401 = (input) => `${input.meta.label}:${input.name}`;
const store401 = new Store401(box401);
const rendered401 = store401.read(project401);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult401 = {
  id: preserved401.id,
  name: preserved401.name,
  active: preserved401.meta.active,
  rendered: rendered401,
};

/**
 * @typedef {object} Model402
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box402
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project402
 * @param {Model402} input
 * @returns {string}
 */

/**
 * @template {Model402} T
 * @param {T} value
 * @returns {T}
 */
function preserve402(value) {
  return value;
}

class Store402 {
  /**
   * @param {Box402<Model402>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project402} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model402} */
const model402 = {
  id: 402, name: "model-402", meta: { active: true, label: "meta-402" },
};
const preserved402 = preserve402(model402);
/** @type {Box402<Model402>} */
const box402 = { value: preserved402, label: "box-402" };
/** @type {Project402} */
const project402 = (input) => `${input.meta.label}:${input.name}`;
const store402 = new Store402(box402);
const rendered402 = store402.read(project402);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult402 = {
  id: preserved402.id,
  name: preserved402.name,
  active: preserved402.meta.active,
  rendered: rendered402,
};

/**
 * @typedef {object} Model403
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box403
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project403
 * @param {Model403} input
 * @returns {string}
 */

/**
 * @template {Model403} T
 * @param {T} value
 * @returns {T}
 */
function preserve403(value) {
  return value;
}

class Store403 {
  /**
   * @param {Box403<Model403>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project403} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model403} */
const model403 = {
  id: 403, name: "model-403", meta: { active: false, label: "meta-403" },
};
const preserved403 = preserve403(model403);
/** @type {Box403<Model403>} */
const box403 = { value: preserved403, label: "box-403" };
/** @type {Project403} */
const project403 = (input) => `${input.meta.label}:${input.name}`;
const store403 = new Store403(box403);
const rendered403 = store403.read(project403);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult403 = {
  id: preserved403.id,
  name: preserved403.name,
  active: preserved403.meta.active,
  rendered: rendered403,
};

/**
 * @typedef {object} Model404
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box404
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project404
 * @param {Model404} input
 * @returns {string}
 */

/**
 * @template {Model404} T
 * @param {T} value
 * @returns {T}
 */
function preserve404(value) {
  return value;
}

class Store404 {
  /**
   * @param {Box404<Model404>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project404} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model404} */
const model404 = {
  id: 404, name: "model-404", meta: { active: true, label: "meta-404" },
};
const preserved404 = preserve404(model404);
/** @type {Box404<Model404>} */
const box404 = { value: preserved404, label: "box-404" };
/** @type {Project404} */
const project404 = (input) => `${input.meta.label}:${input.name}`;
const store404 = new Store404(box404);
const rendered404 = store404.read(project404);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult404 = {
  id: preserved404.id,
  name: preserved404.name,
  active: preserved404.meta.active,
  rendered: rendered404,
};

/**
 * @typedef {object} Model405
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box405
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project405
 * @param {Model405} input
 * @returns {string}
 */

/**
 * @template {Model405} T
 * @param {T} value
 * @returns {T}
 */
function preserve405(value) {
  return value;
}

class Store405 {
  /**
   * @param {Box405<Model405>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project405} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model405} */
const model405 = {
  id: 405, name: "model-405", meta: { active: false, label: "meta-405" },
};
const preserved405 = preserve405(model405);
/** @type {Box405<Model405>} */
const box405 = { value: preserved405, label: "box-405" };
/** @type {Project405} */
const project405 = (input) => `${input.meta.label}:${input.name}`;
const store405 = new Store405(box405);
const rendered405 = store405.read(project405);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult405 = {
  id: preserved405.id,
  name: preserved405.name,
  active: preserved405.meta.active,
  rendered: rendered405,
};

/**
 * @typedef {object} Model406
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box406
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project406
 * @param {Model406} input
 * @returns {string}
 */

/**
 * @template {Model406} T
 * @param {T} value
 * @returns {T}
 */
function preserve406(value) {
  return value;
}

class Store406 {
  /**
   * @param {Box406<Model406>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project406} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model406} */
const model406 = {
  id: 406, name: "model-406", meta: { active: true, label: "meta-406" },
};
const preserved406 = preserve406(model406);
/** @type {Box406<Model406>} */
const box406 = { value: preserved406, label: "box-406" };
/** @type {Project406} */
const project406 = (input) => `${input.meta.label}:${input.name}`;
const store406 = new Store406(box406);
const rendered406 = store406.read(project406);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult406 = {
  id: preserved406.id,
  name: preserved406.name,
  active: preserved406.meta.active,
  rendered: rendered406,
};

/**
 * @typedef {object} Model407
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box407
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project407
 * @param {Model407} input
 * @returns {string}
 */

/**
 * @template {Model407} T
 * @param {T} value
 * @returns {T}
 */
function preserve407(value) {
  return value;
}

class Store407 {
  /**
   * @param {Box407<Model407>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project407} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model407} */
const model407 = {
  id: 407, name: "model-407", meta: { active: false, label: "meta-407" },
};
const preserved407 = preserve407(model407);
/** @type {Box407<Model407>} */
const box407 = { value: preserved407, label: "box-407" };
/** @type {Project407} */
const project407 = (input) => `${input.meta.label}:${input.name}`;
const store407 = new Store407(box407);
const rendered407 = store407.read(project407);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult407 = {
  id: preserved407.id,
  name: preserved407.name,
  active: preserved407.meta.active,
  rendered: rendered407,
};

/**
 * @typedef {object} Model408
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box408
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project408
 * @param {Model408} input
 * @returns {string}
 */

/**
 * @template {Model408} T
 * @param {T} value
 * @returns {T}
 */
function preserve408(value) {
  return value;
}

class Store408 {
  /**
   * @param {Box408<Model408>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project408} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model408} */
const model408 = {
  id: 408, name: "model-408", meta: { active: true, label: "meta-408" },
};
const preserved408 = preserve408(model408);
/** @type {Box408<Model408>} */
const box408 = { value: preserved408, label: "box-408" };
/** @type {Project408} */
const project408 = (input) => `${input.meta.label}:${input.name}`;
const store408 = new Store408(box408);
const rendered408 = store408.read(project408);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult408 = {
  id: preserved408.id,
  name: preserved408.name,
  active: preserved408.meta.active,
  rendered: rendered408,
};

/**
 * @typedef {object} Model409
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box409
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project409
 * @param {Model409} input
 * @returns {string}
 */

/**
 * @template {Model409} T
 * @param {T} value
 * @returns {T}
 */
function preserve409(value) {
  return value;
}

class Store409 {
  /**
   * @param {Box409<Model409>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project409} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model409} */
const model409 = {
  id: 409, name: "model-409", meta: { active: false, label: "meta-409" },
};
const preserved409 = preserve409(model409);
/** @type {Box409<Model409>} */
const box409 = { value: preserved409, label: "box-409" };
/** @type {Project409} */
const project409 = (input) => `${input.meta.label}:${input.name}`;
const store409 = new Store409(box409);
const rendered409 = store409.read(project409);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult409 = {
  id: preserved409.id,
  name: preserved409.name,
  active: preserved409.meta.active,
  rendered: rendered409,
};

/**
 * @typedef {object} Model410
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box410
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project410
 * @param {Model410} input
 * @returns {string}
 */

/**
 * @template {Model410} T
 * @param {T} value
 * @returns {T}
 */
function preserve410(value) {
  return value;
}

class Store410 {
  /**
   * @param {Box410<Model410>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project410} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model410} */
const model410 = {
  id: 410, name: "model-410", meta: { active: true, label: "meta-410" },
};
const preserved410 = preserve410(model410);
/** @type {Box410<Model410>} */
const box410 = { value: preserved410, label: "box-410" };
/** @type {Project410} */
const project410 = (input) => `${input.meta.label}:${input.name}`;
const store410 = new Store410(box410);
const rendered410 = store410.read(project410);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult410 = {
  id: preserved410.id,
  name: preserved410.name,
  active: preserved410.meta.active,
  rendered: rendered410,
};

/**
 * @typedef {object} Model411
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box411
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project411
 * @param {Model411} input
 * @returns {string}
 */

/**
 * @template {Model411} T
 * @param {T} value
 * @returns {T}
 */
function preserve411(value) {
  return value;
}

class Store411 {
  /**
   * @param {Box411<Model411>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project411} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model411} */
const model411 = {
  id: 411, name: "model-411", meta: { active: false, label: "meta-411" },
};
const preserved411 = preserve411(model411);
/** @type {Box411<Model411>} */
const box411 = { value: preserved411, label: "box-411" };
/** @type {Project411} */
const project411 = (input) => `${input.meta.label}:${input.name}`;
const store411 = new Store411(box411);
const rendered411 = store411.read(project411);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult411 = {
  id: preserved411.id,
  name: preserved411.name,
  active: preserved411.meta.active,
  rendered: rendered411,
};

/**
 * @typedef {object} Model412
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box412
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project412
 * @param {Model412} input
 * @returns {string}
 */

/**
 * @template {Model412} T
 * @param {T} value
 * @returns {T}
 */
function preserve412(value) {
  return value;
}

class Store412 {
  /**
   * @param {Box412<Model412>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project412} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model412} */
const model412 = {
  id: 412, name: "model-412", meta: { active: true, label: "meta-412" },
};
const preserved412 = preserve412(model412);
/** @type {Box412<Model412>} */
const box412 = { value: preserved412, label: "box-412" };
/** @type {Project412} */
const project412 = (input) => `${input.meta.label}:${input.name}`;
const store412 = new Store412(box412);
const rendered412 = store412.read(project412);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult412 = {
  id: preserved412.id,
  name: preserved412.name,
  active: preserved412.meta.active,
  rendered: rendered412,
};

/**
 * @typedef {object} Model413
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box413
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project413
 * @param {Model413} input
 * @returns {string}
 */

/**
 * @template {Model413} T
 * @param {T} value
 * @returns {T}
 */
function preserve413(value) {
  return value;
}

class Store413 {
  /**
   * @param {Box413<Model413>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project413} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model413} */
const model413 = {
  id: 413, name: "model-413", meta: { active: false, label: "meta-413" },
};
const preserved413 = preserve413(model413);
/** @type {Box413<Model413>} */
const box413 = { value: preserved413, label: "box-413" };
/** @type {Project413} */
const project413 = (input) => `${input.meta.label}:${input.name}`;
const store413 = new Store413(box413);
const rendered413 = store413.read(project413);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult413 = {
  id: preserved413.id,
  name: preserved413.name,
  active: preserved413.meta.active,
  rendered: rendered413,
};

/**
 * @typedef {object} Model414
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box414
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project414
 * @param {Model414} input
 * @returns {string}
 */

/**
 * @template {Model414} T
 * @param {T} value
 * @returns {T}
 */
function preserve414(value) {
  return value;
}

class Store414 {
  /**
   * @param {Box414<Model414>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project414} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model414} */
const model414 = {
  id: 414, name: "model-414", meta: { active: true, label: "meta-414" },
};
const preserved414 = preserve414(model414);
/** @type {Box414<Model414>} */
const box414 = { value: preserved414, label: "box-414" };
/** @type {Project414} */
const project414 = (input) => `${input.meta.label}:${input.name}`;
const store414 = new Store414(box414);
const rendered414 = store414.read(project414);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult414 = {
  id: preserved414.id,
  name: preserved414.name,
  active: preserved414.meta.active,
  rendered: rendered414,
};

/**
 * @typedef {object} Model415
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box415
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project415
 * @param {Model415} input
 * @returns {string}
 */

/**
 * @template {Model415} T
 * @param {T} value
 * @returns {T}
 */
function preserve415(value) {
  return value;
}

class Store415 {
  /**
   * @param {Box415<Model415>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project415} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model415} */
const model415 = {
  id: 415, name: "model-415", meta: { active: false, label: "meta-415" },
};
const preserved415 = preserve415(model415);
/** @type {Box415<Model415>} */
const box415 = { value: preserved415, label: "box-415" };
/** @type {Project415} */
const project415 = (input) => `${input.meta.label}:${input.name}`;
const store415 = new Store415(box415);
const rendered415 = store415.read(project415);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult415 = {
  id: preserved415.id,
  name: preserved415.name,
  active: preserved415.meta.active,
  rendered: rendered415,
};

/**
 * @typedef {object} Model416
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box416
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project416
 * @param {Model416} input
 * @returns {string}
 */

/**
 * @template {Model416} T
 * @param {T} value
 * @returns {T}
 */
function preserve416(value) {
  return value;
}

class Store416 {
  /**
   * @param {Box416<Model416>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project416} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model416} */
const model416 = {
  id: 416, name: "model-416", meta: { active: true, label: "meta-416" },
};
const preserved416 = preserve416(model416);
/** @type {Box416<Model416>} */
const box416 = { value: preserved416, label: "box-416" };
/** @type {Project416} */
const project416 = (input) => `${input.meta.label}:${input.name}`;
const store416 = new Store416(box416);
const rendered416 = store416.read(project416);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult416 = {
  id: preserved416.id,
  name: preserved416.name,
  active: preserved416.meta.active,
  rendered: rendered416,
};

/**
 * @typedef {object} Model417
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box417
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project417
 * @param {Model417} input
 * @returns {string}
 */

/**
 * @template {Model417} T
 * @param {T} value
 * @returns {T}
 */
function preserve417(value) {
  return value;
}

class Store417 {
  /**
   * @param {Box417<Model417>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project417} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model417} */
const model417 = {
  id: 417, name: "model-417", meta: { active: false, label: "meta-417" },
};
const preserved417 = preserve417(model417);
/** @type {Box417<Model417>} */
const box417 = { value: preserved417, label: "box-417" };
/** @type {Project417} */
const project417 = (input) => `${input.meta.label}:${input.name}`;
const store417 = new Store417(box417);
const rendered417 = store417.read(project417);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult417 = {
  id: preserved417.id,
  name: preserved417.name,
  active: preserved417.meta.active,
  rendered: rendered417,
};

/**
 * @typedef {object} Model418
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box418
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project418
 * @param {Model418} input
 * @returns {string}
 */

/**
 * @template {Model418} T
 * @param {T} value
 * @returns {T}
 */
function preserve418(value) {
  return value;
}

class Store418 {
  /**
   * @param {Box418<Model418>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project418} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model418} */
const model418 = {
  id: 418, name: "model-418", meta: { active: true, label: "meta-418" },
};
const preserved418 = preserve418(model418);
/** @type {Box418<Model418>} */
const box418 = { value: preserved418, label: "box-418" };
/** @type {Project418} */
const project418 = (input) => `${input.meta.label}:${input.name}`;
const store418 = new Store418(box418);
const rendered418 = store418.read(project418);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult418 = {
  id: preserved418.id,
  name: preserved418.name,
  active: preserved418.meta.active,
  rendered: rendered418,
};

/**
 * @typedef {object} Model419
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box419
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project419
 * @param {Model419} input
 * @returns {string}
 */

/**
 * @template {Model419} T
 * @param {T} value
 * @returns {T}
 */
function preserve419(value) {
  return value;
}

class Store419 {
  /**
   * @param {Box419<Model419>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project419} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model419} */
const model419 = {
  id: 419, name: "model-419", meta: { active: false, label: "meta-419" },
};
const preserved419 = preserve419(model419);
/** @type {Box419<Model419>} */
const box419 = { value: preserved419, label: "box-419" };
/** @type {Project419} */
const project419 = (input) => `${input.meta.label}:${input.name}`;
const store419 = new Store419(box419);
const rendered419 = store419.read(project419);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult419 = {
  id: preserved419.id,
  name: preserved419.name,
  active: preserved419.meta.active,
  rendered: rendered419,
};

/**
 * @typedef {object} Model420
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box420
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project420
 * @param {Model420} input
 * @returns {string}
 */

/**
 * @template {Model420} T
 * @param {T} value
 * @returns {T}
 */
function preserve420(value) {
  return value;
}

class Store420 {
  /**
   * @param {Box420<Model420>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project420} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model420} */
const model420 = {
  id: 420, name: "model-420", meta: { active: true, label: "meta-420" },
};
const preserved420 = preserve420(model420);
/** @type {Box420<Model420>} */
const box420 = { value: preserved420, label: "box-420" };
/** @type {Project420} */
const project420 = (input) => `${input.meta.label}:${input.name}`;
const store420 = new Store420(box420);
const rendered420 = store420.read(project420);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult420 = {
  id: preserved420.id,
  name: preserved420.name,
  active: preserved420.meta.active,
  rendered: rendered420,
};

/**
 * @typedef {object} Model421
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box421
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project421
 * @param {Model421} input
 * @returns {string}
 */

/**
 * @template {Model421} T
 * @param {T} value
 * @returns {T}
 */
function preserve421(value) {
  return value;
}

class Store421 {
  /**
   * @param {Box421<Model421>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project421} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model421} */
const model421 = {
  id: 421, name: "model-421", meta: { active: false, label: "meta-421" },
};
const preserved421 = preserve421(model421);
/** @type {Box421<Model421>} */
const box421 = { value: preserved421, label: "box-421" };
/** @type {Project421} */
const project421 = (input) => `${input.meta.label}:${input.name}`;
const store421 = new Store421(box421);
const rendered421 = store421.read(project421);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult421 = {
  id: preserved421.id,
  name: preserved421.name,
  active: preserved421.meta.active,
  rendered: rendered421,
};

/**
 * @typedef {object} Model422
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box422
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project422
 * @param {Model422} input
 * @returns {string}
 */

/**
 * @template {Model422} T
 * @param {T} value
 * @returns {T}
 */
function preserve422(value) {
  return value;
}

class Store422 {
  /**
   * @param {Box422<Model422>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project422} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model422} */
const model422 = {
  id: 422, name: "model-422", meta: { active: true, label: "meta-422" },
};
const preserved422 = preserve422(model422);
/** @type {Box422<Model422>} */
const box422 = { value: preserved422, label: "box-422" };
/** @type {Project422} */
const project422 = (input) => `${input.meta.label}:${input.name}`;
const store422 = new Store422(box422);
const rendered422 = store422.read(project422);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult422 = {
  id: preserved422.id,
  name: preserved422.name,
  active: preserved422.meta.active,
  rendered: rendered422,
};

/**
 * @typedef {object} Model423
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box423
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project423
 * @param {Model423} input
 * @returns {string}
 */

/**
 * @template {Model423} T
 * @param {T} value
 * @returns {T}
 */
function preserve423(value) {
  return value;
}

class Store423 {
  /**
   * @param {Box423<Model423>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project423} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model423} */
const model423 = {
  id: 423, name: "model-423", meta: { active: false, label: "meta-423" },
};
const preserved423 = preserve423(model423);
/** @type {Box423<Model423>} */
const box423 = { value: preserved423, label: "box-423" };
/** @type {Project423} */
const project423 = (input) => `${input.meta.label}:${input.name}`;
const store423 = new Store423(box423);
const rendered423 = store423.read(project423);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult423 = {
  id: preserved423.id,
  name: preserved423.name,
  active: preserved423.meta.active,
  rendered: rendered423,
};

/**
 * @typedef {object} Model424
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box424
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project424
 * @param {Model424} input
 * @returns {string}
 */

/**
 * @template {Model424} T
 * @param {T} value
 * @returns {T}
 */
function preserve424(value) {
  return value;
}

class Store424 {
  /**
   * @param {Box424<Model424>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project424} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model424} */
const model424 = {
  id: 424, name: "model-424", meta: { active: true, label: "meta-424" },
};
const preserved424 = preserve424(model424);
/** @type {Box424<Model424>} */
const box424 = { value: preserved424, label: "box-424" };
/** @type {Project424} */
const project424 = (input) => `${input.meta.label}:${input.name}`;
const store424 = new Store424(box424);
const rendered424 = store424.read(project424);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult424 = {
  id: preserved424.id,
  name: preserved424.name,
  active: preserved424.meta.active,
  rendered: rendered424,
};

/**
 * @typedef {object} Model425
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box425
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project425
 * @param {Model425} input
 * @returns {string}
 */

/**
 * @template {Model425} T
 * @param {T} value
 * @returns {T}
 */
function preserve425(value) {
  return value;
}

class Store425 {
  /**
   * @param {Box425<Model425>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project425} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model425} */
const model425 = {
  id: 425, name: "model-425", meta: { active: false, label: "meta-425" },
};
const preserved425 = preserve425(model425);
/** @type {Box425<Model425>} */
const box425 = { value: preserved425, label: "box-425" };
/** @type {Project425} */
const project425 = (input) => `${input.meta.label}:${input.name}`;
const store425 = new Store425(box425);
const rendered425 = store425.read(project425);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult425 = {
  id: preserved425.id,
  name: preserved425.name,
  active: preserved425.meta.active,
  rendered: rendered425,
};

/**
 * @typedef {object} Model426
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box426
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project426
 * @param {Model426} input
 * @returns {string}
 */

/**
 * @template {Model426} T
 * @param {T} value
 * @returns {T}
 */
function preserve426(value) {
  return value;
}

class Store426 {
  /**
   * @param {Box426<Model426>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project426} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model426} */
const model426 = {
  id: 426, name: "model-426", meta: { active: true, label: "meta-426" },
};
const preserved426 = preserve426(model426);
/** @type {Box426<Model426>} */
const box426 = { value: preserved426, label: "box-426" };
/** @type {Project426} */
const project426 = (input) => `${input.meta.label}:${input.name}`;
const store426 = new Store426(box426);
const rendered426 = store426.read(project426);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult426 = {
  id: preserved426.id,
  name: preserved426.name,
  active: preserved426.meta.active,
  rendered: rendered426,
};

/**
 * @typedef {object} Model427
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box427
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project427
 * @param {Model427} input
 * @returns {string}
 */

/**
 * @template {Model427} T
 * @param {T} value
 * @returns {T}
 */
function preserve427(value) {
  return value;
}

class Store427 {
  /**
   * @param {Box427<Model427>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project427} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model427} */
const model427 = {
  id: 427, name: "model-427", meta: { active: false, label: "meta-427" },
};
const preserved427 = preserve427(model427);
/** @type {Box427<Model427>} */
const box427 = { value: preserved427, label: "box-427" };
/** @type {Project427} */
const project427 = (input) => `${input.meta.label}:${input.name}`;
const store427 = new Store427(box427);
const rendered427 = store427.read(project427);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult427 = {
  id: preserved427.id,
  name: preserved427.name,
  active: preserved427.meta.active,
  rendered: rendered427,
};

/**
 * @typedef {object} Model428
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box428
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project428
 * @param {Model428} input
 * @returns {string}
 */

/**
 * @template {Model428} T
 * @param {T} value
 * @returns {T}
 */
function preserve428(value) {
  return value;
}

class Store428 {
  /**
   * @param {Box428<Model428>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project428} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model428} */
const model428 = {
  id: 428, name: "model-428", meta: { active: true, label: "meta-428" },
};
const preserved428 = preserve428(model428);
/** @type {Box428<Model428>} */
const box428 = { value: preserved428, label: "box-428" };
/** @type {Project428} */
const project428 = (input) => `${input.meta.label}:${input.name}`;
const store428 = new Store428(box428);
const rendered428 = store428.read(project428);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult428 = {
  id: preserved428.id,
  name: preserved428.name,
  active: preserved428.meta.active,
  rendered: rendered428,
};

/**
 * @typedef {object} Model429
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box429
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project429
 * @param {Model429} input
 * @returns {string}
 */

/**
 * @template {Model429} T
 * @param {T} value
 * @returns {T}
 */
function preserve429(value) {
  return value;
}

class Store429 {
  /**
   * @param {Box429<Model429>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project429} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model429} */
const model429 = {
  id: 429, name: "model-429", meta: { active: false, label: "meta-429" },
};
const preserved429 = preserve429(model429);
/** @type {Box429<Model429>} */
const box429 = { value: preserved429, label: "box-429" };
/** @type {Project429} */
const project429 = (input) => `${input.meta.label}:${input.name}`;
const store429 = new Store429(box429);
const rendered429 = store429.read(project429);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult429 = {
  id: preserved429.id,
  name: preserved429.name,
  active: preserved429.meta.active,
  rendered: rendered429,
};

/**
 * @typedef {object} Model430
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box430
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project430
 * @param {Model430} input
 * @returns {string}
 */

/**
 * @template {Model430} T
 * @param {T} value
 * @returns {T}
 */
function preserve430(value) {
  return value;
}

class Store430 {
  /**
   * @param {Box430<Model430>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project430} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model430} */
const model430 = {
  id: 430, name: "model-430", meta: { active: true, label: "meta-430" },
};
const preserved430 = preserve430(model430);
/** @type {Box430<Model430>} */
const box430 = { value: preserved430, label: "box-430" };
/** @type {Project430} */
const project430 = (input) => `${input.meta.label}:${input.name}`;
const store430 = new Store430(box430);
const rendered430 = store430.read(project430);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult430 = {
  id: preserved430.id,
  name: preserved430.name,
  active: preserved430.meta.active,
  rendered: rendered430,
};

/**
 * @typedef {object} Model431
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box431
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project431
 * @param {Model431} input
 * @returns {string}
 */

/**
 * @template {Model431} T
 * @param {T} value
 * @returns {T}
 */
function preserve431(value) {
  return value;
}

class Store431 {
  /**
   * @param {Box431<Model431>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project431} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model431} */
const model431 = {
  id: 431, name: "model-431", meta: { active: false, label: "meta-431" },
};
const preserved431 = preserve431(model431);
/** @type {Box431<Model431>} */
const box431 = { value: preserved431, label: "box-431" };
/** @type {Project431} */
const project431 = (input) => `${input.meta.label}:${input.name}`;
const store431 = new Store431(box431);
const rendered431 = store431.read(project431);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult431 = {
  id: preserved431.id,
  name: preserved431.name,
  active: preserved431.meta.active,
  rendered: rendered431,
};

/**
 * @typedef {object} Model432
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box432
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project432
 * @param {Model432} input
 * @returns {string}
 */

/**
 * @template {Model432} T
 * @param {T} value
 * @returns {T}
 */
function preserve432(value) {
  return value;
}

class Store432 {
  /**
   * @param {Box432<Model432>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project432} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model432} */
const model432 = {
  id: 432, name: "model-432", meta: { active: true, label: "meta-432" },
};
const preserved432 = preserve432(model432);
/** @type {Box432<Model432>} */
const box432 = { value: preserved432, label: "box-432" };
/** @type {Project432} */
const project432 = (input) => `${input.meta.label}:${input.name}`;
const store432 = new Store432(box432);
const rendered432 = store432.read(project432);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult432 = {
  id: preserved432.id,
  name: preserved432.name,
  active: preserved432.meta.active,
  rendered: rendered432,
};

/**
 * @typedef {object} Model433
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box433
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project433
 * @param {Model433} input
 * @returns {string}
 */

/**
 * @template {Model433} T
 * @param {T} value
 * @returns {T}
 */
function preserve433(value) {
  return value;
}

class Store433 {
  /**
   * @param {Box433<Model433>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project433} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model433} */
const model433 = {
  id: 433, name: "model-433", meta: { active: false, label: "meta-433" },
};
const preserved433 = preserve433(model433);
/** @type {Box433<Model433>} */
const box433 = { value: preserved433, label: "box-433" };
/** @type {Project433} */
const project433 = (input) => `${input.meta.label}:${input.name}`;
const store433 = new Store433(box433);
const rendered433 = store433.read(project433);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult433 = {
  id: preserved433.id,
  name: preserved433.name,
  active: preserved433.meta.active,
  rendered: rendered433,
};

/**
 * @typedef {object} Model434
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box434
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project434
 * @param {Model434} input
 * @returns {string}
 */

/**
 * @template {Model434} T
 * @param {T} value
 * @returns {T}
 */
function preserve434(value) {
  return value;
}

class Store434 {
  /**
   * @param {Box434<Model434>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project434} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model434} */
const model434 = {
  id: 434, name: "model-434", meta: { active: true, label: "meta-434" },
};
const preserved434 = preserve434(model434);
/** @type {Box434<Model434>} */
const box434 = { value: preserved434, label: "box-434" };
/** @type {Project434} */
const project434 = (input) => `${input.meta.label}:${input.name}`;
const store434 = new Store434(box434);
const rendered434 = store434.read(project434);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult434 = {
  id: preserved434.id,
  name: preserved434.name,
  active: preserved434.meta.active,
  rendered: rendered434,
};

/**
 * @typedef {object} Model435
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box435
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project435
 * @param {Model435} input
 * @returns {string}
 */

/**
 * @template {Model435} T
 * @param {T} value
 * @returns {T}
 */
function preserve435(value) {
  return value;
}

class Store435 {
  /**
   * @param {Box435<Model435>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project435} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model435} */
const model435 = {
  id: 435, name: "model-435", meta: { active: false, label: "meta-435" },
};
const preserved435 = preserve435(model435);
/** @type {Box435<Model435>} */
const box435 = { value: preserved435, label: "box-435" };
/** @type {Project435} */
const project435 = (input) => `${input.meta.label}:${input.name}`;
const store435 = new Store435(box435);
const rendered435 = store435.read(project435);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult435 = {
  id: preserved435.id,
  name: preserved435.name,
  active: preserved435.meta.active,
  rendered: rendered435,
};

/**
 * @typedef {object} Model436
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box436
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project436
 * @param {Model436} input
 * @returns {string}
 */

/**
 * @template {Model436} T
 * @param {T} value
 * @returns {T}
 */
function preserve436(value) {
  return value;
}

class Store436 {
  /**
   * @param {Box436<Model436>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project436} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model436} */
const model436 = {
  id: 436, name: "model-436", meta: { active: true, label: "meta-436" },
};
const preserved436 = preserve436(model436);
/** @type {Box436<Model436>} */
const box436 = { value: preserved436, label: "box-436" };
/** @type {Project436} */
const project436 = (input) => `${input.meta.label}:${input.name}`;
const store436 = new Store436(box436);
const rendered436 = store436.read(project436);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult436 = {
  id: preserved436.id,
  name: preserved436.name,
  active: preserved436.meta.active,
  rendered: rendered436,
};

/**
 * @typedef {object} Model437
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box437
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project437
 * @param {Model437} input
 * @returns {string}
 */

/**
 * @template {Model437} T
 * @param {T} value
 * @returns {T}
 */
function preserve437(value) {
  return value;
}

class Store437 {
  /**
   * @param {Box437<Model437>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project437} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model437} */
const model437 = {
  id: 437, name: "model-437", meta: { active: false, label: "meta-437" },
};
const preserved437 = preserve437(model437);
/** @type {Box437<Model437>} */
const box437 = { value: preserved437, label: "box-437" };
/** @type {Project437} */
const project437 = (input) => `${input.meta.label}:${input.name}`;
const store437 = new Store437(box437);
const rendered437 = store437.read(project437);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult437 = {
  id: preserved437.id,
  name: preserved437.name,
  active: preserved437.meta.active,
  rendered: rendered437,
};

/**
 * @typedef {object} Model438
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box438
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project438
 * @param {Model438} input
 * @returns {string}
 */

/**
 * @template {Model438} T
 * @param {T} value
 * @returns {T}
 */
function preserve438(value) {
  return value;
}

class Store438 {
  /**
   * @param {Box438<Model438>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project438} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model438} */
const model438 = {
  id: 438, name: "model-438", meta: { active: true, label: "meta-438" },
};
const preserved438 = preserve438(model438);
/** @type {Box438<Model438>} */
const box438 = { value: preserved438, label: "box-438" };
/** @type {Project438} */
const project438 = (input) => `${input.meta.label}:${input.name}`;
const store438 = new Store438(box438);
const rendered438 = store438.read(project438);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult438 = {
  id: preserved438.id,
  name: preserved438.name,
  active: preserved438.meta.active,
  rendered: rendered438,
};

/**
 * @typedef {object} Model439
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box439
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project439
 * @param {Model439} input
 * @returns {string}
 */

/**
 * @template {Model439} T
 * @param {T} value
 * @returns {T}
 */
function preserve439(value) {
  return value;
}

class Store439 {
  /**
   * @param {Box439<Model439>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project439} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model439} */
const model439 = {
  id: 439, name: "model-439", meta: { active: false, label: "meta-439" },
};
const preserved439 = preserve439(model439);
/** @type {Box439<Model439>} */
const box439 = { value: preserved439, label: "box-439" };
/** @type {Project439} */
const project439 = (input) => `${input.meta.label}:${input.name}`;
const store439 = new Store439(box439);
const rendered439 = store439.read(project439);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult439 = {
  id: preserved439.id,
  name: preserved439.name,
  active: preserved439.meta.active,
  rendered: rendered439,
};

/**
 * @typedef {object} Model440
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box440
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project440
 * @param {Model440} input
 * @returns {string}
 */

/**
 * @template {Model440} T
 * @param {T} value
 * @returns {T}
 */
function preserve440(value) {
  return value;
}

class Store440 {
  /**
   * @param {Box440<Model440>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project440} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model440} */
const model440 = {
  id: 440, name: "model-440", meta: { active: true, label: "meta-440" },
};
const preserved440 = preserve440(model440);
/** @type {Box440<Model440>} */
const box440 = { value: preserved440, label: "box-440" };
/** @type {Project440} */
const project440 = (input) => `${input.meta.label}:${input.name}`;
const store440 = new Store440(box440);
const rendered440 = store440.read(project440);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult440 = {
  id: preserved440.id,
  name: preserved440.name,
  active: preserved440.meta.active,
  rendered: rendered440,
};

/**
 * @typedef {object} Model441
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box441
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project441
 * @param {Model441} input
 * @returns {string}
 */

/**
 * @template {Model441} T
 * @param {T} value
 * @returns {T}
 */
function preserve441(value) {
  return value;
}

class Store441 {
  /**
   * @param {Box441<Model441>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project441} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model441} */
const model441 = {
  id: 441, name: "model-441", meta: { active: false, label: "meta-441" },
};
const preserved441 = preserve441(model441);
/** @type {Box441<Model441>} */
const box441 = { value: preserved441, label: "box-441" };
/** @type {Project441} */
const project441 = (input) => `${input.meta.label}:${input.name}`;
const store441 = new Store441(box441);
const rendered441 = store441.read(project441);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult441 = {
  id: preserved441.id,
  name: preserved441.name,
  active: preserved441.meta.active,
  rendered: rendered441,
};

/**
 * @typedef {object} Model442
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box442
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project442
 * @param {Model442} input
 * @returns {string}
 */

/**
 * @template {Model442} T
 * @param {T} value
 * @returns {T}
 */
function preserve442(value) {
  return value;
}

class Store442 {
  /**
   * @param {Box442<Model442>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project442} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model442} */
const model442 = {
  id: 442, name: "model-442", meta: { active: true, label: "meta-442" },
};
const preserved442 = preserve442(model442);
/** @type {Box442<Model442>} */
const box442 = { value: preserved442, label: "box-442" };
/** @type {Project442} */
const project442 = (input) => `${input.meta.label}:${input.name}`;
const store442 = new Store442(box442);
const rendered442 = store442.read(project442);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult442 = {
  id: preserved442.id,
  name: preserved442.name,
  active: preserved442.meta.active,
  rendered: rendered442,
};

/**
 * @typedef {object} Model443
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box443
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project443
 * @param {Model443} input
 * @returns {string}
 */

/**
 * @template {Model443} T
 * @param {T} value
 * @returns {T}
 */
function preserve443(value) {
  return value;
}

class Store443 {
  /**
   * @param {Box443<Model443>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project443} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model443} */
const model443 = {
  id: 443, name: "model-443", meta: { active: false, label: "meta-443" },
};
const preserved443 = preserve443(model443);
/** @type {Box443<Model443>} */
const box443 = { value: preserved443, label: "box-443" };
/** @type {Project443} */
const project443 = (input) => `${input.meta.label}:${input.name}`;
const store443 = new Store443(box443);
const rendered443 = store443.read(project443);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult443 = {
  id: preserved443.id,
  name: preserved443.name,
  active: preserved443.meta.active,
  rendered: rendered443,
};

/**
 * @typedef {object} Model444
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box444
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project444
 * @param {Model444} input
 * @returns {string}
 */

/**
 * @template {Model444} T
 * @param {T} value
 * @returns {T}
 */
function preserve444(value) {
  return value;
}

class Store444 {
  /**
   * @param {Box444<Model444>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project444} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model444} */
const model444 = {
  id: 444, name: "model-444", meta: { active: true, label: "meta-444" },
};
const preserved444 = preserve444(model444);
/** @type {Box444<Model444>} */
const box444 = { value: preserved444, label: "box-444" };
/** @type {Project444} */
const project444 = (input) => `${input.meta.label}:${input.name}`;
const store444 = new Store444(box444);
const rendered444 = store444.read(project444);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult444 = {
  id: preserved444.id,
  name: preserved444.name,
  active: preserved444.meta.active,
  rendered: rendered444,
};

/**
 * @typedef {object} Model445
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box445
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project445
 * @param {Model445} input
 * @returns {string}
 */

/**
 * @template {Model445} T
 * @param {T} value
 * @returns {T}
 */
function preserve445(value) {
  return value;
}

class Store445 {
  /**
   * @param {Box445<Model445>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project445} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model445} */
const model445 = {
  id: 445, name: "model-445", meta: { active: false, label: "meta-445" },
};
const preserved445 = preserve445(model445);
/** @type {Box445<Model445>} */
const box445 = { value: preserved445, label: "box-445" };
/** @type {Project445} */
const project445 = (input) => `${input.meta.label}:${input.name}`;
const store445 = new Store445(box445);
const rendered445 = store445.read(project445);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult445 = {
  id: preserved445.id,
  name: preserved445.name,
  active: preserved445.meta.active,
  rendered: rendered445,
};

/**
 * @typedef {object} Model446
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box446
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project446
 * @param {Model446} input
 * @returns {string}
 */

/**
 * @template {Model446} T
 * @param {T} value
 * @returns {T}
 */
function preserve446(value) {
  return value;
}

class Store446 {
  /**
   * @param {Box446<Model446>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project446} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model446} */
const model446 = {
  id: 446, name: "model-446", meta: { active: true, label: "meta-446" },
};
const preserved446 = preserve446(model446);
/** @type {Box446<Model446>} */
const box446 = { value: preserved446, label: "box-446" };
/** @type {Project446} */
const project446 = (input) => `${input.meta.label}:${input.name}`;
const store446 = new Store446(box446);
const rendered446 = store446.read(project446);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult446 = {
  id: preserved446.id,
  name: preserved446.name,
  active: preserved446.meta.active,
  rendered: rendered446,
};

/**
 * @typedef {object} Model447
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box447
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project447
 * @param {Model447} input
 * @returns {string}
 */

/**
 * @template {Model447} T
 * @param {T} value
 * @returns {T}
 */
function preserve447(value) {
  return value;
}

class Store447 {
  /**
   * @param {Box447<Model447>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project447} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model447} */
const model447 = {
  id: 447, name: "model-447", meta: { active: false, label: "meta-447" },
};
const preserved447 = preserve447(model447);
/** @type {Box447<Model447>} */
const box447 = { value: preserved447, label: "box-447" };
/** @type {Project447} */
const project447 = (input) => `${input.meta.label}:${input.name}`;
const store447 = new Store447(box447);
const rendered447 = store447.read(project447);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult447 = {
  id: preserved447.id,
  name: preserved447.name,
  active: preserved447.meta.active,
  rendered: rendered447,
};

/**
 * @typedef {object} Model448
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box448
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project448
 * @param {Model448} input
 * @returns {string}
 */

/**
 * @template {Model448} T
 * @param {T} value
 * @returns {T}
 */
function preserve448(value) {
  return value;
}

class Store448 {
  /**
   * @param {Box448<Model448>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project448} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model448} */
const model448 = {
  id: 448, name: "model-448", meta: { active: true, label: "meta-448" },
};
const preserved448 = preserve448(model448);
/** @type {Box448<Model448>} */
const box448 = { value: preserved448, label: "box-448" };
/** @type {Project448} */
const project448 = (input) => `${input.meta.label}:${input.name}`;
const store448 = new Store448(box448);
const rendered448 = store448.read(project448);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult448 = {
  id: preserved448.id,
  name: preserved448.name,
  active: preserved448.meta.active,
  rendered: rendered448,
};

/**
 * @typedef {object} Model449
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box449
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project449
 * @param {Model449} input
 * @returns {string}
 */

/**
 * @template {Model449} T
 * @param {T} value
 * @returns {T}
 */
function preserve449(value) {
  return value;
}

class Store449 {
  /**
   * @param {Box449<Model449>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project449} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model449} */
const model449 = {
  id: 449, name: "model-449", meta: { active: false, label: "meta-449" },
};
const preserved449 = preserve449(model449);
/** @type {Box449<Model449>} */
const box449 = { value: preserved449, label: "box-449" };
/** @type {Project449} */
const project449 = (input) => `${input.meta.label}:${input.name}`;
const store449 = new Store449(box449);
const rendered449 = store449.read(project449);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult449 = {
  id: preserved449.id,
  name: preserved449.name,
  active: preserved449.meta.active,
  rendered: rendered449,
};

/**
 * @typedef {object} Model450
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box450
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project450
 * @param {Model450} input
 * @returns {string}
 */

/**
 * @template {Model450} T
 * @param {T} value
 * @returns {T}
 */
function preserve450(value) {
  return value;
}

class Store450 {
  /**
   * @param {Box450<Model450>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project450} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model450} */
const model450 = {
  id: 450, name: "model-450", meta: { active: true, label: "meta-450" },
};
const preserved450 = preserve450(model450);
/** @type {Box450<Model450>} */
const box450 = { value: preserved450, label: "box-450" };
/** @type {Project450} */
const project450 = (input) => `${input.meta.label}:${input.name}`;
const store450 = new Store450(box450);
const rendered450 = store450.read(project450);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult450 = {
  id: preserved450.id,
  name: preserved450.name,
  active: preserved450.meta.active,
  rendered: rendered450,
};

/**
 * @typedef {object} Model451
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box451
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project451
 * @param {Model451} input
 * @returns {string}
 */

/**
 * @template {Model451} T
 * @param {T} value
 * @returns {T}
 */
function preserve451(value) {
  return value;
}

class Store451 {
  /**
   * @param {Box451<Model451>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project451} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model451} */
const model451 = {
  id: 451, name: "model-451", meta: { active: false, label: "meta-451" },
};
const preserved451 = preserve451(model451);
/** @type {Box451<Model451>} */
const box451 = { value: preserved451, label: "box-451" };
/** @type {Project451} */
const project451 = (input) => `${input.meta.label}:${input.name}`;
const store451 = new Store451(box451);
const rendered451 = store451.read(project451);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult451 = {
  id: preserved451.id,
  name: preserved451.name,
  active: preserved451.meta.active,
  rendered: rendered451,
};

/**
 * @typedef {object} Model452
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box452
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project452
 * @param {Model452} input
 * @returns {string}
 */

/**
 * @template {Model452} T
 * @param {T} value
 * @returns {T}
 */
function preserve452(value) {
  return value;
}

class Store452 {
  /**
   * @param {Box452<Model452>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project452} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model452} */
const model452 = {
  id: 452, name: "model-452", meta: { active: true, label: "meta-452" },
};
const preserved452 = preserve452(model452);
/** @type {Box452<Model452>} */
const box452 = { value: preserved452, label: "box-452" };
/** @type {Project452} */
const project452 = (input) => `${input.meta.label}:${input.name}`;
const store452 = new Store452(box452);
const rendered452 = store452.read(project452);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult452 = {
  id: preserved452.id,
  name: preserved452.name,
  active: preserved452.meta.active,
  rendered: rendered452,
};

/**
 * @typedef {object} Model453
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box453
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project453
 * @param {Model453} input
 * @returns {string}
 */

/**
 * @template {Model453} T
 * @param {T} value
 * @returns {T}
 */
function preserve453(value) {
  return value;
}

class Store453 {
  /**
   * @param {Box453<Model453>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project453} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model453} */
const model453 = {
  id: 453, name: "model-453", meta: { active: false, label: "meta-453" },
};
const preserved453 = preserve453(model453);
/** @type {Box453<Model453>} */
const box453 = { value: preserved453, label: "box-453" };
/** @type {Project453} */
const project453 = (input) => `${input.meta.label}:${input.name}`;
const store453 = new Store453(box453);
const rendered453 = store453.read(project453);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult453 = {
  id: preserved453.id,
  name: preserved453.name,
  active: preserved453.meta.active,
  rendered: rendered453,
};

/**
 * @typedef {object} Model454
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box454
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project454
 * @param {Model454} input
 * @returns {string}
 */

/**
 * @template {Model454} T
 * @param {T} value
 * @returns {T}
 */
function preserve454(value) {
  return value;
}

class Store454 {
  /**
   * @param {Box454<Model454>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project454} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model454} */
const model454 = {
  id: 454, name: "model-454", meta: { active: true, label: "meta-454" },
};
const preserved454 = preserve454(model454);
/** @type {Box454<Model454>} */
const box454 = { value: preserved454, label: "box-454" };
/** @type {Project454} */
const project454 = (input) => `${input.meta.label}:${input.name}`;
const store454 = new Store454(box454);
const rendered454 = store454.read(project454);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult454 = {
  id: preserved454.id,
  name: preserved454.name,
  active: preserved454.meta.active,
  rendered: rendered454,
};

/**
 * @typedef {object} Model455
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box455
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project455
 * @param {Model455} input
 * @returns {string}
 */

/**
 * @template {Model455} T
 * @param {T} value
 * @returns {T}
 */
function preserve455(value) {
  return value;
}

class Store455 {
  /**
   * @param {Box455<Model455>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project455} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model455} */
const model455 = {
  id: 455, name: "model-455", meta: { active: false, label: "meta-455" },
};
const preserved455 = preserve455(model455);
/** @type {Box455<Model455>} */
const box455 = { value: preserved455, label: "box-455" };
/** @type {Project455} */
const project455 = (input) => `${input.meta.label}:${input.name}`;
const store455 = new Store455(box455);
const rendered455 = store455.read(project455);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult455 = {
  id: preserved455.id,
  name: preserved455.name,
  active: preserved455.meta.active,
  rendered: rendered455,
};

/**
 * @typedef {object} Model456
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box456
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project456
 * @param {Model456} input
 * @returns {string}
 */

/**
 * @template {Model456} T
 * @param {T} value
 * @returns {T}
 */
function preserve456(value) {
  return value;
}

class Store456 {
  /**
   * @param {Box456<Model456>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project456} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model456} */
const model456 = {
  id: 456, name: "model-456", meta: { active: true, label: "meta-456" },
};
const preserved456 = preserve456(model456);
/** @type {Box456<Model456>} */
const box456 = { value: preserved456, label: "box-456" };
/** @type {Project456} */
const project456 = (input) => `${input.meta.label}:${input.name}`;
const store456 = new Store456(box456);
const rendered456 = store456.read(project456);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult456 = {
  id: preserved456.id,
  name: preserved456.name,
  active: preserved456.meta.active,
  rendered: rendered456,
};

/**
 * @typedef {object} Model457
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box457
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project457
 * @param {Model457} input
 * @returns {string}
 */

/**
 * @template {Model457} T
 * @param {T} value
 * @returns {T}
 */
function preserve457(value) {
  return value;
}

class Store457 {
  /**
   * @param {Box457<Model457>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project457} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model457} */
const model457 = {
  id: 457, name: "model-457", meta: { active: false, label: "meta-457" },
};
const preserved457 = preserve457(model457);
/** @type {Box457<Model457>} */
const box457 = { value: preserved457, label: "box-457" };
/** @type {Project457} */
const project457 = (input) => `${input.meta.label}:${input.name}`;
const store457 = new Store457(box457);
const rendered457 = store457.read(project457);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult457 = {
  id: preserved457.id,
  name: preserved457.name,
  active: preserved457.meta.active,
  rendered: rendered457,
};

/**
 * @typedef {object} Model458
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box458
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project458
 * @param {Model458} input
 * @returns {string}
 */

/**
 * @template {Model458} T
 * @param {T} value
 * @returns {T}
 */
function preserve458(value) {
  return value;
}

class Store458 {
  /**
   * @param {Box458<Model458>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project458} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model458} */
const model458 = {
  id: 458, name: "model-458", meta: { active: true, label: "meta-458" },
};
const preserved458 = preserve458(model458);
/** @type {Box458<Model458>} */
const box458 = { value: preserved458, label: "box-458" };
/** @type {Project458} */
const project458 = (input) => `${input.meta.label}:${input.name}`;
const store458 = new Store458(box458);
const rendered458 = store458.read(project458);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult458 = {
  id: preserved458.id,
  name: preserved458.name,
  active: preserved458.meta.active,
  rendered: rendered458,
};

/**
 * @typedef {object} Model459
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box459
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project459
 * @param {Model459} input
 * @returns {string}
 */

/**
 * @template {Model459} T
 * @param {T} value
 * @returns {T}
 */
function preserve459(value) {
  return value;
}

class Store459 {
  /**
   * @param {Box459<Model459>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project459} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model459} */
const model459 = {
  id: 459, name: "model-459", meta: { active: false, label: "meta-459" },
};
const preserved459 = preserve459(model459);
/** @type {Box459<Model459>} */
const box459 = { value: preserved459, label: "box-459" };
/** @type {Project459} */
const project459 = (input) => `${input.meta.label}:${input.name}`;
const store459 = new Store459(box459);
const rendered459 = store459.read(project459);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult459 = {
  id: preserved459.id,
  name: preserved459.name,
  active: preserved459.meta.active,
  rendered: rendered459,
};

/**
 * @typedef {object} Model460
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box460
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project460
 * @param {Model460} input
 * @returns {string}
 */

/**
 * @template {Model460} T
 * @param {T} value
 * @returns {T}
 */
function preserve460(value) {
  return value;
}

class Store460 {
  /**
   * @param {Box460<Model460>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project460} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model460} */
const model460 = {
  id: 460, name: "model-460", meta: { active: true, label: "meta-460" },
};
const preserved460 = preserve460(model460);
/** @type {Box460<Model460>} */
const box460 = { value: preserved460, label: "box-460" };
/** @type {Project460} */
const project460 = (input) => `${input.meta.label}:${input.name}`;
const store460 = new Store460(box460);
const rendered460 = store460.read(project460);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult460 = {
  id: preserved460.id,
  name: preserved460.name,
  active: preserved460.meta.active,
  rendered: rendered460,
};

/**
 * @typedef {object} Model461
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box461
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project461
 * @param {Model461} input
 * @returns {string}
 */

/**
 * @template {Model461} T
 * @param {T} value
 * @returns {T}
 */
function preserve461(value) {
  return value;
}

class Store461 {
  /**
   * @param {Box461<Model461>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project461} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model461} */
const model461 = {
  id: 461, name: "model-461", meta: { active: false, label: "meta-461" },
};
const preserved461 = preserve461(model461);
/** @type {Box461<Model461>} */
const box461 = { value: preserved461, label: "box-461" };
/** @type {Project461} */
const project461 = (input) => `${input.meta.label}:${input.name}`;
const store461 = new Store461(box461);
const rendered461 = store461.read(project461);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult461 = {
  id: preserved461.id,
  name: preserved461.name,
  active: preserved461.meta.active,
  rendered: rendered461,
};

/**
 * @typedef {object} Model462
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box462
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project462
 * @param {Model462} input
 * @returns {string}
 */

/**
 * @template {Model462} T
 * @param {T} value
 * @returns {T}
 */
function preserve462(value) {
  return value;
}

class Store462 {
  /**
   * @param {Box462<Model462>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project462} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model462} */
const model462 = {
  id: 462, name: "model-462", meta: { active: true, label: "meta-462" },
};
const preserved462 = preserve462(model462);
/** @type {Box462<Model462>} */
const box462 = { value: preserved462, label: "box-462" };
/** @type {Project462} */
const project462 = (input) => `${input.meta.label}:${input.name}`;
const store462 = new Store462(box462);
const rendered462 = store462.read(project462);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult462 = {
  id: preserved462.id,
  name: preserved462.name,
  active: preserved462.meta.active,
  rendered: rendered462,
};

/**
 * @typedef {object} Model463
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box463
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project463
 * @param {Model463} input
 * @returns {string}
 */

/**
 * @template {Model463} T
 * @param {T} value
 * @returns {T}
 */
function preserve463(value) {
  return value;
}

class Store463 {
  /**
   * @param {Box463<Model463>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project463} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model463} */
const model463 = {
  id: 463, name: "model-463", meta: { active: false, label: "meta-463" },
};
const preserved463 = preserve463(model463);
/** @type {Box463<Model463>} */
const box463 = { value: preserved463, label: "box-463" };
/** @type {Project463} */
const project463 = (input) => `${input.meta.label}:${input.name}`;
const store463 = new Store463(box463);
const rendered463 = store463.read(project463);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult463 = {
  id: preserved463.id,
  name: preserved463.name,
  active: preserved463.meta.active,
  rendered: rendered463,
};

/**
 * @typedef {object} Model464
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box464
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project464
 * @param {Model464} input
 * @returns {string}
 */

/**
 * @template {Model464} T
 * @param {T} value
 * @returns {T}
 */
function preserve464(value) {
  return value;
}

class Store464 {
  /**
   * @param {Box464<Model464>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project464} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model464} */
const model464 = {
  id: 464, name: "model-464", meta: { active: true, label: "meta-464" },
};
const preserved464 = preserve464(model464);
/** @type {Box464<Model464>} */
const box464 = { value: preserved464, label: "box-464" };
/** @type {Project464} */
const project464 = (input) => `${input.meta.label}:${input.name}`;
const store464 = new Store464(box464);
const rendered464 = store464.read(project464);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult464 = {
  id: preserved464.id,
  name: preserved464.name,
  active: preserved464.meta.active,
  rendered: rendered464,
};

/**
 * @typedef {object} Model465
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box465
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project465
 * @param {Model465} input
 * @returns {string}
 */

/**
 * @template {Model465} T
 * @param {T} value
 * @returns {T}
 */
function preserve465(value) {
  return value;
}

class Store465 {
  /**
   * @param {Box465<Model465>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project465} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model465} */
const model465 = {
  id: 465, name: "model-465", meta: { active: false, label: "meta-465" },
};
const preserved465 = preserve465(model465);
/** @type {Box465<Model465>} */
const box465 = { value: preserved465, label: "box-465" };
/** @type {Project465} */
const project465 = (input) => `${input.meta.label}:${input.name}`;
const store465 = new Store465(box465);
const rendered465 = store465.read(project465);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult465 = {
  id: preserved465.id,
  name: preserved465.name,
  active: preserved465.meta.active,
  rendered: rendered465,
};

/**
 * @typedef {object} Model466
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box466
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project466
 * @param {Model466} input
 * @returns {string}
 */

/**
 * @template {Model466} T
 * @param {T} value
 * @returns {T}
 */
function preserve466(value) {
  return value;
}

class Store466 {
  /**
   * @param {Box466<Model466>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project466} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model466} */
const model466 = {
  id: 466, name: "model-466", meta: { active: true, label: "meta-466" },
};
const preserved466 = preserve466(model466);
/** @type {Box466<Model466>} */
const box466 = { value: preserved466, label: "box-466" };
/** @type {Project466} */
const project466 = (input) => `${input.meta.label}:${input.name}`;
const store466 = new Store466(box466);
const rendered466 = store466.read(project466);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult466 = {
  id: preserved466.id,
  name: preserved466.name,
  active: preserved466.meta.active,
  rendered: rendered466,
};

/**
 * @typedef {object} Model467
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box467
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project467
 * @param {Model467} input
 * @returns {string}
 */

/**
 * @template {Model467} T
 * @param {T} value
 * @returns {T}
 */
function preserve467(value) {
  return value;
}

class Store467 {
  /**
   * @param {Box467<Model467>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project467} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model467} */
const model467 = {
  id: 467, name: "model-467", meta: { active: false, label: "meta-467" },
};
const preserved467 = preserve467(model467);
/** @type {Box467<Model467>} */
const box467 = { value: preserved467, label: "box-467" };
/** @type {Project467} */
const project467 = (input) => `${input.meta.label}:${input.name}`;
const store467 = new Store467(box467);
const rendered467 = store467.read(project467);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult467 = {
  id: preserved467.id,
  name: preserved467.name,
  active: preserved467.meta.active,
  rendered: rendered467,
};

/**
 * @typedef {object} Model468
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box468
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project468
 * @param {Model468} input
 * @returns {string}
 */

/**
 * @template {Model468} T
 * @param {T} value
 * @returns {T}
 */
function preserve468(value) {
  return value;
}

class Store468 {
  /**
   * @param {Box468<Model468>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project468} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model468} */
const model468 = {
  id: 468, name: "model-468", meta: { active: true, label: "meta-468" },
};
const preserved468 = preserve468(model468);
/** @type {Box468<Model468>} */
const box468 = { value: preserved468, label: "box-468" };
/** @type {Project468} */
const project468 = (input) => `${input.meta.label}:${input.name}`;
const store468 = new Store468(box468);
const rendered468 = store468.read(project468);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult468 = {
  id: preserved468.id,
  name: preserved468.name,
  active: preserved468.meta.active,
  rendered: rendered468,
};

/**
 * @typedef {object} Model469
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box469
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project469
 * @param {Model469} input
 * @returns {string}
 */

/**
 * @template {Model469} T
 * @param {T} value
 * @returns {T}
 */
function preserve469(value) {
  return value;
}

class Store469 {
  /**
   * @param {Box469<Model469>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project469} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model469} */
const model469 = {
  id: 469, name: "model-469", meta: { active: false, label: "meta-469" },
};
const preserved469 = preserve469(model469);
/** @type {Box469<Model469>} */
const box469 = { value: preserved469, label: "box-469" };
/** @type {Project469} */
const project469 = (input) => `${input.meta.label}:${input.name}`;
const store469 = new Store469(box469);
const rendered469 = store469.read(project469);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult469 = {
  id: preserved469.id,
  name: preserved469.name,
  active: preserved469.meta.active,
  rendered: rendered469,
};

/**
 * @typedef {object} Model470
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box470
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project470
 * @param {Model470} input
 * @returns {string}
 */

/**
 * @template {Model470} T
 * @param {T} value
 * @returns {T}
 */
function preserve470(value) {
  return value;
}

class Store470 {
  /**
   * @param {Box470<Model470>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project470} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model470} */
const model470 = {
  id: 470, name: "model-470", meta: { active: true, label: "meta-470" },
};
const preserved470 = preserve470(model470);
/** @type {Box470<Model470>} */
const box470 = { value: preserved470, label: "box-470" };
/** @type {Project470} */
const project470 = (input) => `${input.meta.label}:${input.name}`;
const store470 = new Store470(box470);
const rendered470 = store470.read(project470);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult470 = {
  id: preserved470.id,
  name: preserved470.name,
  active: preserved470.meta.active,
  rendered: rendered470,
};

/**
 * @typedef {object} Model471
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box471
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project471
 * @param {Model471} input
 * @returns {string}
 */

/**
 * @template {Model471} T
 * @param {T} value
 * @returns {T}
 */
function preserve471(value) {
  return value;
}

class Store471 {
  /**
   * @param {Box471<Model471>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project471} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model471} */
const model471 = {
  id: 471, name: "model-471", meta: { active: false, label: "meta-471" },
};
const preserved471 = preserve471(model471);
/** @type {Box471<Model471>} */
const box471 = { value: preserved471, label: "box-471" };
/** @type {Project471} */
const project471 = (input) => `${input.meta.label}:${input.name}`;
const store471 = new Store471(box471);
const rendered471 = store471.read(project471);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult471 = {
  id: preserved471.id,
  name: preserved471.name,
  active: preserved471.meta.active,
  rendered: rendered471,
};

/**
 * @typedef {object} Model472
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box472
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project472
 * @param {Model472} input
 * @returns {string}
 */

/**
 * @template {Model472} T
 * @param {T} value
 * @returns {T}
 */
function preserve472(value) {
  return value;
}

class Store472 {
  /**
   * @param {Box472<Model472>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project472} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model472} */
const model472 = {
  id: 472, name: "model-472", meta: { active: true, label: "meta-472" },
};
const preserved472 = preserve472(model472);
/** @type {Box472<Model472>} */
const box472 = { value: preserved472, label: "box-472" };
/** @type {Project472} */
const project472 = (input) => `${input.meta.label}:${input.name}`;
const store472 = new Store472(box472);
const rendered472 = store472.read(project472);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult472 = {
  id: preserved472.id,
  name: preserved472.name,
  active: preserved472.meta.active,
  rendered: rendered472,
};

/**
 * @typedef {object} Model473
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box473
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project473
 * @param {Model473} input
 * @returns {string}
 */

/**
 * @template {Model473} T
 * @param {T} value
 * @returns {T}
 */
function preserve473(value) {
  return value;
}

class Store473 {
  /**
   * @param {Box473<Model473>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project473} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model473} */
const model473 = {
  id: 473, name: "model-473", meta: { active: false, label: "meta-473" },
};
const preserved473 = preserve473(model473);
/** @type {Box473<Model473>} */
const box473 = { value: preserved473, label: "box-473" };
/** @type {Project473} */
const project473 = (input) => `${input.meta.label}:${input.name}`;
const store473 = new Store473(box473);
const rendered473 = store473.read(project473);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult473 = {
  id: preserved473.id,
  name: preserved473.name,
  active: preserved473.meta.active,
  rendered: rendered473,
};

/**
 * @typedef {object} Model474
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box474
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project474
 * @param {Model474} input
 * @returns {string}
 */

/**
 * @template {Model474} T
 * @param {T} value
 * @returns {T}
 */
function preserve474(value) {
  return value;
}

class Store474 {
  /**
   * @param {Box474<Model474>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project474} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model474} */
const model474 = {
  id: 474, name: "model-474", meta: { active: true, label: "meta-474" },
};
const preserved474 = preserve474(model474);
/** @type {Box474<Model474>} */
const box474 = { value: preserved474, label: "box-474" };
/** @type {Project474} */
const project474 = (input) => `${input.meta.label}:${input.name}`;
const store474 = new Store474(box474);
const rendered474 = store474.read(project474);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult474 = {
  id: preserved474.id,
  name: preserved474.name,
  active: preserved474.meta.active,
  rendered: rendered474,
};

/**
 * @typedef {object} Model475
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box475
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project475
 * @param {Model475} input
 * @returns {string}
 */

/**
 * @template {Model475} T
 * @param {T} value
 * @returns {T}
 */
function preserve475(value) {
  return value;
}

class Store475 {
  /**
   * @param {Box475<Model475>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project475} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model475} */
const model475 = {
  id: 475, name: "model-475", meta: { active: false, label: "meta-475" },
};
const preserved475 = preserve475(model475);
/** @type {Box475<Model475>} */
const box475 = { value: preserved475, label: "box-475" };
/** @type {Project475} */
const project475 = (input) => `${input.meta.label}:${input.name}`;
const store475 = new Store475(box475);
const rendered475 = store475.read(project475);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult475 = {
  id: preserved475.id,
  name: preserved475.name,
  active: preserved475.meta.active,
  rendered: rendered475,
};

/**
 * @typedef {object} Model476
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box476
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project476
 * @param {Model476} input
 * @returns {string}
 */

/**
 * @template {Model476} T
 * @param {T} value
 * @returns {T}
 */
function preserve476(value) {
  return value;
}

class Store476 {
  /**
   * @param {Box476<Model476>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project476} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model476} */
const model476 = {
  id: 476, name: "model-476", meta: { active: true, label: "meta-476" },
};
const preserved476 = preserve476(model476);
/** @type {Box476<Model476>} */
const box476 = { value: preserved476, label: "box-476" };
/** @type {Project476} */
const project476 = (input) => `${input.meta.label}:${input.name}`;
const store476 = new Store476(box476);
const rendered476 = store476.read(project476);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult476 = {
  id: preserved476.id,
  name: preserved476.name,
  active: preserved476.meta.active,
  rendered: rendered476,
};

/**
 * @typedef {object} Model477
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box477
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project477
 * @param {Model477} input
 * @returns {string}
 */

/**
 * @template {Model477} T
 * @param {T} value
 * @returns {T}
 */
function preserve477(value) {
  return value;
}

class Store477 {
  /**
   * @param {Box477<Model477>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project477} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model477} */
const model477 = {
  id: 477, name: "model-477", meta: { active: false, label: "meta-477" },
};
const preserved477 = preserve477(model477);
/** @type {Box477<Model477>} */
const box477 = { value: preserved477, label: "box-477" };
/** @type {Project477} */
const project477 = (input) => `${input.meta.label}:${input.name}`;
const store477 = new Store477(box477);
const rendered477 = store477.read(project477);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult477 = {
  id: preserved477.id,
  name: preserved477.name,
  active: preserved477.meta.active,
  rendered: rendered477,
};

/**
 * @typedef {object} Model478
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box478
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project478
 * @param {Model478} input
 * @returns {string}
 */

/**
 * @template {Model478} T
 * @param {T} value
 * @returns {T}
 */
function preserve478(value) {
  return value;
}

class Store478 {
  /**
   * @param {Box478<Model478>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project478} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model478} */
const model478 = {
  id: 478, name: "model-478", meta: { active: true, label: "meta-478" },
};
const preserved478 = preserve478(model478);
/** @type {Box478<Model478>} */
const box478 = { value: preserved478, label: "box-478" };
/** @type {Project478} */
const project478 = (input) => `${input.meta.label}:${input.name}`;
const store478 = new Store478(box478);
const rendered478 = store478.read(project478);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult478 = {
  id: preserved478.id,
  name: preserved478.name,
  active: preserved478.meta.active,
  rendered: rendered478,
};

/**
 * @typedef {object} Model479
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box479
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project479
 * @param {Model479} input
 * @returns {string}
 */

/**
 * @template {Model479} T
 * @param {T} value
 * @returns {T}
 */
function preserve479(value) {
  return value;
}

class Store479 {
  /**
   * @param {Box479<Model479>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project479} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model479} */
const model479 = {
  id: 479, name: "model-479", meta: { active: false, label: "meta-479" },
};
const preserved479 = preserve479(model479);
/** @type {Box479<Model479>} */
const box479 = { value: preserved479, label: "box-479" };
/** @type {Project479} */
const project479 = (input) => `${input.meta.label}:${input.name}`;
const store479 = new Store479(box479);
const rendered479 = store479.read(project479);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult479 = {
  id: preserved479.id,
  name: preserved479.name,
  active: preserved479.meta.active,
  rendered: rendered479,
};

/**
 * @typedef {object} Model480
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box480
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project480
 * @param {Model480} input
 * @returns {string}
 */

/**
 * @template {Model480} T
 * @param {T} value
 * @returns {T}
 */
function preserve480(value) {
  return value;
}

class Store480 {
  /**
   * @param {Box480<Model480>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project480} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model480} */
const model480 = {
  id: 480, name: "model-480", meta: { active: true, label: "meta-480" },
};
const preserved480 = preserve480(model480);
/** @type {Box480<Model480>} */
const box480 = { value: preserved480, label: "box-480" };
/** @type {Project480} */
const project480 = (input) => `${input.meta.label}:${input.name}`;
const store480 = new Store480(box480);
const rendered480 = store480.read(project480);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult480 = {
  id: preserved480.id,
  name: preserved480.name,
  active: preserved480.meta.active,
  rendered: rendered480,
};

/**
 * @typedef {object} Model481
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box481
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project481
 * @param {Model481} input
 * @returns {string}
 */

/**
 * @template {Model481} T
 * @param {T} value
 * @returns {T}
 */
function preserve481(value) {
  return value;
}

class Store481 {
  /**
   * @param {Box481<Model481>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project481} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model481} */
const model481 = {
  id: 481, name: "model-481", meta: { active: false, label: "meta-481" },
};
const preserved481 = preserve481(model481);
/** @type {Box481<Model481>} */
const box481 = { value: preserved481, label: "box-481" };
/** @type {Project481} */
const project481 = (input) => `${input.meta.label}:${input.name}`;
const store481 = new Store481(box481);
const rendered481 = store481.read(project481);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult481 = {
  id: preserved481.id,
  name: preserved481.name,
  active: preserved481.meta.active,
  rendered: rendered481,
};

/**
 * @typedef {object} Model482
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box482
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project482
 * @param {Model482} input
 * @returns {string}
 */

/**
 * @template {Model482} T
 * @param {T} value
 * @returns {T}
 */
function preserve482(value) {
  return value;
}

class Store482 {
  /**
   * @param {Box482<Model482>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project482} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model482} */
const model482 = {
  id: 482, name: "model-482", meta: { active: true, label: "meta-482" },
};
const preserved482 = preserve482(model482);
/** @type {Box482<Model482>} */
const box482 = { value: preserved482, label: "box-482" };
/** @type {Project482} */
const project482 = (input) => `${input.meta.label}:${input.name}`;
const store482 = new Store482(box482);
const rendered482 = store482.read(project482);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult482 = {
  id: preserved482.id,
  name: preserved482.name,
  active: preserved482.meta.active,
  rendered: rendered482,
};

/**
 * @typedef {object} Model483
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box483
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project483
 * @param {Model483} input
 * @returns {string}
 */

/**
 * @template {Model483} T
 * @param {T} value
 * @returns {T}
 */
function preserve483(value) {
  return value;
}

class Store483 {
  /**
   * @param {Box483<Model483>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project483} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model483} */
const model483 = {
  id: 483, name: "model-483", meta: { active: false, label: "meta-483" },
};
const preserved483 = preserve483(model483);
/** @type {Box483<Model483>} */
const box483 = { value: preserved483, label: "box-483" };
/** @type {Project483} */
const project483 = (input) => `${input.meta.label}:${input.name}`;
const store483 = new Store483(box483);
const rendered483 = store483.read(project483);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult483 = {
  id: preserved483.id,
  name: preserved483.name,
  active: preserved483.meta.active,
  rendered: rendered483,
};

/**
 * @typedef {object} Model484
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box484
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project484
 * @param {Model484} input
 * @returns {string}
 */

/**
 * @template {Model484} T
 * @param {T} value
 * @returns {T}
 */
function preserve484(value) {
  return value;
}

class Store484 {
  /**
   * @param {Box484<Model484>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project484} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model484} */
const model484 = {
  id: 484, name: "model-484", meta: { active: true, label: "meta-484" },
};
const preserved484 = preserve484(model484);
/** @type {Box484<Model484>} */
const box484 = { value: preserved484, label: "box-484" };
/** @type {Project484} */
const project484 = (input) => `${input.meta.label}:${input.name}`;
const store484 = new Store484(box484);
const rendered484 = store484.read(project484);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult484 = {
  id: preserved484.id,
  name: preserved484.name,
  active: preserved484.meta.active,
  rendered: rendered484,
};

/**
 * @typedef {object} Model485
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box485
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project485
 * @param {Model485} input
 * @returns {string}
 */

/**
 * @template {Model485} T
 * @param {T} value
 * @returns {T}
 */
function preserve485(value) {
  return value;
}

class Store485 {
  /**
   * @param {Box485<Model485>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project485} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model485} */
const model485 = {
  id: 485, name: "model-485", meta: { active: false, label: "meta-485" },
};
const preserved485 = preserve485(model485);
/** @type {Box485<Model485>} */
const box485 = { value: preserved485, label: "box-485" };
/** @type {Project485} */
const project485 = (input) => `${input.meta.label}:${input.name}`;
const store485 = new Store485(box485);
const rendered485 = store485.read(project485);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult485 = {
  id: preserved485.id,
  name: preserved485.name,
  active: preserved485.meta.active,
  rendered: rendered485,
};

/**
 * @typedef {object} Model486
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box486
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project486
 * @param {Model486} input
 * @returns {string}
 */

/**
 * @template {Model486} T
 * @param {T} value
 * @returns {T}
 */
function preserve486(value) {
  return value;
}

class Store486 {
  /**
   * @param {Box486<Model486>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project486} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model486} */
const model486 = {
  id: 486, name: "model-486", meta: { active: true, label: "meta-486" },
};
const preserved486 = preserve486(model486);
/** @type {Box486<Model486>} */
const box486 = { value: preserved486, label: "box-486" };
/** @type {Project486} */
const project486 = (input) => `${input.meta.label}:${input.name}`;
const store486 = new Store486(box486);
const rendered486 = store486.read(project486);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult486 = {
  id: preserved486.id,
  name: preserved486.name,
  active: preserved486.meta.active,
  rendered: rendered486,
};

/**
 * @typedef {object} Model487
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box487
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project487
 * @param {Model487} input
 * @returns {string}
 */

/**
 * @template {Model487} T
 * @param {T} value
 * @returns {T}
 */
function preserve487(value) {
  return value;
}

class Store487 {
  /**
   * @param {Box487<Model487>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project487} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model487} */
const model487 = {
  id: 487, name: "model-487", meta: { active: false, label: "meta-487" },
};
const preserved487 = preserve487(model487);
/** @type {Box487<Model487>} */
const box487 = { value: preserved487, label: "box-487" };
/** @type {Project487} */
const project487 = (input) => `${input.meta.label}:${input.name}`;
const store487 = new Store487(box487);
const rendered487 = store487.read(project487);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult487 = {
  id: preserved487.id,
  name: preserved487.name,
  active: preserved487.meta.active,
  rendered: rendered487,
};

/**
 * @typedef {object} Model488
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box488
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project488
 * @param {Model488} input
 * @returns {string}
 */

/**
 * @template {Model488} T
 * @param {T} value
 * @returns {T}
 */
function preserve488(value) {
  return value;
}

class Store488 {
  /**
   * @param {Box488<Model488>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project488} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model488} */
const model488 = {
  id: 488, name: "model-488", meta: { active: true, label: "meta-488" },
};
const preserved488 = preserve488(model488);
/** @type {Box488<Model488>} */
const box488 = { value: preserved488, label: "box-488" };
/** @type {Project488} */
const project488 = (input) => `${input.meta.label}:${input.name}`;
const store488 = new Store488(box488);
const rendered488 = store488.read(project488);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult488 = {
  id: preserved488.id,
  name: preserved488.name,
  active: preserved488.meta.active,
  rendered: rendered488,
};

/**
 * @typedef {object} Model489
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box489
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project489
 * @param {Model489} input
 * @returns {string}
 */

/**
 * @template {Model489} T
 * @param {T} value
 * @returns {T}
 */
function preserve489(value) {
  return value;
}

class Store489 {
  /**
   * @param {Box489<Model489>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project489} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model489} */
const model489 = {
  id: 489, name: "model-489", meta: { active: false, label: "meta-489" },
};
const preserved489 = preserve489(model489);
/** @type {Box489<Model489>} */
const box489 = { value: preserved489, label: "box-489" };
/** @type {Project489} */
const project489 = (input) => `${input.meta.label}:${input.name}`;
const store489 = new Store489(box489);
const rendered489 = store489.read(project489);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult489 = {
  id: preserved489.id,
  name: preserved489.name,
  active: preserved489.meta.active,
  rendered: rendered489,
};

/**
 * @typedef {object} Model490
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box490
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project490
 * @param {Model490} input
 * @returns {string}
 */

/**
 * @template {Model490} T
 * @param {T} value
 * @returns {T}
 */
function preserve490(value) {
  return value;
}

class Store490 {
  /**
   * @param {Box490<Model490>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project490} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model490} */
const model490 = {
  id: 490, name: "model-490", meta: { active: true, label: "meta-490" },
};
const preserved490 = preserve490(model490);
/** @type {Box490<Model490>} */
const box490 = { value: preserved490, label: "box-490" };
/** @type {Project490} */
const project490 = (input) => `${input.meta.label}:${input.name}`;
const store490 = new Store490(box490);
const rendered490 = store490.read(project490);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult490 = {
  id: preserved490.id,
  name: preserved490.name,
  active: preserved490.meta.active,
  rendered: rendered490,
};

/**
 * @typedef {object} Model491
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box491
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project491
 * @param {Model491} input
 * @returns {string}
 */

/**
 * @template {Model491} T
 * @param {T} value
 * @returns {T}
 */
function preserve491(value) {
  return value;
}

class Store491 {
  /**
   * @param {Box491<Model491>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project491} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model491} */
const model491 = {
  id: 491, name: "model-491", meta: { active: false, label: "meta-491" },
};
const preserved491 = preserve491(model491);
/** @type {Box491<Model491>} */
const box491 = { value: preserved491, label: "box-491" };
/** @type {Project491} */
const project491 = (input) => `${input.meta.label}:${input.name}`;
const store491 = new Store491(box491);
const rendered491 = store491.read(project491);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult491 = {
  id: preserved491.id,
  name: preserved491.name,
  active: preserved491.meta.active,
  rendered: rendered491,
};

/**
 * @typedef {object} Model492
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box492
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project492
 * @param {Model492} input
 * @returns {string}
 */

/**
 * @template {Model492} T
 * @param {T} value
 * @returns {T}
 */
function preserve492(value) {
  return value;
}

class Store492 {
  /**
   * @param {Box492<Model492>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project492} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model492} */
const model492 = {
  id: 492, name: "model-492", meta: { active: true, label: "meta-492" },
};
const preserved492 = preserve492(model492);
/** @type {Box492<Model492>} */
const box492 = { value: preserved492, label: "box-492" };
/** @type {Project492} */
const project492 = (input) => `${input.meta.label}:${input.name}`;
const store492 = new Store492(box492);
const rendered492 = store492.read(project492);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult492 = {
  id: preserved492.id,
  name: preserved492.name,
  active: preserved492.meta.active,
  rendered: rendered492,
};

/**
 * @typedef {object} Model493
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box493
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project493
 * @param {Model493} input
 * @returns {string}
 */

/**
 * @template {Model493} T
 * @param {T} value
 * @returns {T}
 */
function preserve493(value) {
  return value;
}

class Store493 {
  /**
   * @param {Box493<Model493>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project493} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model493} */
const model493 = {
  id: 493, name: "model-493", meta: { active: false, label: "meta-493" },
};
const preserved493 = preserve493(model493);
/** @type {Box493<Model493>} */
const box493 = { value: preserved493, label: "box-493" };
/** @type {Project493} */
const project493 = (input) => `${input.meta.label}:${input.name}`;
const store493 = new Store493(box493);
const rendered493 = store493.read(project493);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult493 = {
  id: preserved493.id,
  name: preserved493.name,
  active: preserved493.meta.active,
  rendered: rendered493,
};

/**
 * @typedef {object} Model494
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box494
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project494
 * @param {Model494} input
 * @returns {string}
 */

/**
 * @template {Model494} T
 * @param {T} value
 * @returns {T}
 */
function preserve494(value) {
  return value;
}

class Store494 {
  /**
   * @param {Box494<Model494>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project494} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model494} */
const model494 = {
  id: 494, name: "model-494", meta: { active: true, label: "meta-494" },
};
const preserved494 = preserve494(model494);
/** @type {Box494<Model494>} */
const box494 = { value: preserved494, label: "box-494" };
/** @type {Project494} */
const project494 = (input) => `${input.meta.label}:${input.name}`;
const store494 = new Store494(box494);
const rendered494 = store494.read(project494);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult494 = {
  id: preserved494.id,
  name: preserved494.name,
  active: preserved494.meta.active,
  rendered: rendered494,
};

/**
 * @typedef {object} Model495
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box495
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project495
 * @param {Model495} input
 * @returns {string}
 */

/**
 * @template {Model495} T
 * @param {T} value
 * @returns {T}
 */
function preserve495(value) {
  return value;
}

class Store495 {
  /**
   * @param {Box495<Model495>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project495} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model495} */
const model495 = {
  id: 495, name: "model-495", meta: { active: false, label: "meta-495" },
};
const preserved495 = preserve495(model495);
/** @type {Box495<Model495>} */
const box495 = { value: preserved495, label: "box-495" };
/** @type {Project495} */
const project495 = (input) => `${input.meta.label}:${input.name}`;
const store495 = new Store495(box495);
const rendered495 = store495.read(project495);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult495 = {
  id: preserved495.id,
  name: preserved495.name,
  active: preserved495.meta.active,
  rendered: rendered495,
};

/**
 * @typedef {object} Model496
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box496
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project496
 * @param {Model496} input
 * @returns {string}
 */

/**
 * @template {Model496} T
 * @param {T} value
 * @returns {T}
 */
function preserve496(value) {
  return value;
}

class Store496 {
  /**
   * @param {Box496<Model496>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project496} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model496} */
const model496 = {
  id: 496, name: "model-496", meta: { active: true, label: "meta-496" },
};
const preserved496 = preserve496(model496);
/** @type {Box496<Model496>} */
const box496 = { value: preserved496, label: "box-496" };
/** @type {Project496} */
const project496 = (input) => `${input.meta.label}:${input.name}`;
const store496 = new Store496(box496);
const rendered496 = store496.read(project496);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult496 = {
  id: preserved496.id,
  name: preserved496.name,
  active: preserved496.meta.active,
  rendered: rendered496,
};

/**
 * @typedef {object} Model497
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box497
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project497
 * @param {Model497} input
 * @returns {string}
 */

/**
 * @template {Model497} T
 * @param {T} value
 * @returns {T}
 */
function preserve497(value) {
  return value;
}

class Store497 {
  /**
   * @param {Box497<Model497>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project497} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model497} */
const model497 = {
  id: 497, name: "model-497", meta: { active: false, label: "meta-497" },
};
const preserved497 = preserve497(model497);
/** @type {Box497<Model497>} */
const box497 = { value: preserved497, label: "box-497" };
/** @type {Project497} */
const project497 = (input) => `${input.meta.label}:${input.name}`;
const store497 = new Store497(box497);
const rendered497 = store497.read(project497);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult497 = {
  id: preserved497.id,
  name: preserved497.name,
  active: preserved497.meta.active,
  rendered: rendered497,
};

/**
 * @typedef {object} Model498
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box498
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project498
 * @param {Model498} input
 * @returns {string}
 */

/**
 * @template {Model498} T
 * @param {T} value
 * @returns {T}
 */
function preserve498(value) {
  return value;
}

class Store498 {
  /**
   * @param {Box498<Model498>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project498} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model498} */
const model498 = {
  id: 498, name: "model-498", meta: { active: true, label: "meta-498" },
};
const preserved498 = preserve498(model498);
/** @type {Box498<Model498>} */
const box498 = { value: preserved498, label: "box-498" };
/** @type {Project498} */
const project498 = (input) => `${input.meta.label}:${input.name}`;
const store498 = new Store498(box498);
const rendered498 = store498.read(project498);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult498 = {
  id: preserved498.id,
  name: preserved498.name,
  active: preserved498.meta.active,
  rendered: rendered498,
};

/**
 * @typedef {object} Model499
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box499
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project499
 * @param {Model499} input
 * @returns {string}
 */

/**
 * @template {Model499} T
 * @param {T} value
 * @returns {T}
 */
function preserve499(value) {
  return value;
}

class Store499 {
  /**
   * @param {Box499<Model499>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project499} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model499} */
const model499 = {
  id: 499, name: "model-499", meta: { active: false, label: "meta-499" },
};
const preserved499 = preserve499(model499);
/** @type {Box499<Model499>} */
const box499 = { value: preserved499, label: "box-499" };
/** @type {Project499} */
const project499 = (input) => `${input.meta.label}:${input.name}`;
const store499 = new Store499(box499);
const rendered499 = store499.read(project499);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult499 = {
  id: preserved499.id,
  name: preserved499.name,
  active: preserved499.meta.active,
  rendered: rendered499,
};

/**
 * @typedef {object} Model500
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box500
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project500
 * @param {Model500} input
 * @returns {string}
 */

/**
 * @template {Model500} T
 * @param {T} value
 * @returns {T}
 */
function preserve500(value) {
  return value;
}

class Store500 {
  /**
   * @param {Box500<Model500>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project500} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model500} */
const model500 = {
  id: 500, name: "model-500", meta: { active: true, label: "meta-500" },
};
const preserved500 = preserve500(model500);
/** @type {Box500<Model500>} */
const box500 = { value: preserved500, label: "box-500" };
/** @type {Project500} */
const project500 = (input) => `${input.meta.label}:${input.name}`;
const store500 = new Store500(box500);
const rendered500 = store500.read(project500);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult500 = {
  id: preserved500.id,
  name: preserved500.name,
  active: preserved500.meta.active,
  rendered: rendered500,
};

/**
 * @typedef {object} Model501
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box501
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project501
 * @param {Model501} input
 * @returns {string}
 */

/**
 * @template {Model501} T
 * @param {T} value
 * @returns {T}
 */
function preserve501(value) {
  return value;
}

class Store501 {
  /**
   * @param {Box501<Model501>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project501} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model501} */
const model501 = {
  id: 501, name: "model-501", meta: { active: false, label: "meta-501" },
};
const preserved501 = preserve501(model501);
/** @type {Box501<Model501>} */
const box501 = { value: preserved501, label: "box-501" };
/** @type {Project501} */
const project501 = (input) => `${input.meta.label}:${input.name}`;
const store501 = new Store501(box501);
const rendered501 = store501.read(project501);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult501 = {
  id: preserved501.id,
  name: preserved501.name,
  active: preserved501.meta.active,
  rendered: rendered501,
};

/**
 * @typedef {object} Model502
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box502
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project502
 * @param {Model502} input
 * @returns {string}
 */

/**
 * @template {Model502} T
 * @param {T} value
 * @returns {T}
 */
function preserve502(value) {
  return value;
}

class Store502 {
  /**
   * @param {Box502<Model502>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project502} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model502} */
const model502 = {
  id: 502, name: "model-502", meta: { active: true, label: "meta-502" },
};
const preserved502 = preserve502(model502);
/** @type {Box502<Model502>} */
const box502 = { value: preserved502, label: "box-502" };
/** @type {Project502} */
const project502 = (input) => `${input.meta.label}:${input.name}`;
const store502 = new Store502(box502);
const rendered502 = store502.read(project502);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult502 = {
  id: preserved502.id,
  name: preserved502.name,
  active: preserved502.meta.active,
  rendered: rendered502,
};

/**
 * @typedef {object} Model503
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box503
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project503
 * @param {Model503} input
 * @returns {string}
 */

/**
 * @template {Model503} T
 * @param {T} value
 * @returns {T}
 */
function preserve503(value) {
  return value;
}

class Store503 {
  /**
   * @param {Box503<Model503>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project503} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model503} */
const model503 = {
  id: 503, name: "model-503", meta: { active: false, label: "meta-503" },
};
const preserved503 = preserve503(model503);
/** @type {Box503<Model503>} */
const box503 = { value: preserved503, label: "box-503" };
/** @type {Project503} */
const project503 = (input) => `${input.meta.label}:${input.name}`;
const store503 = new Store503(box503);
const rendered503 = store503.read(project503);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult503 = {
  id: preserved503.id,
  name: preserved503.name,
  active: preserved503.meta.active,
  rendered: rendered503,
};

/**
 * @typedef {object} Model504
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box504
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project504
 * @param {Model504} input
 * @returns {string}
 */

/**
 * @template {Model504} T
 * @param {T} value
 * @returns {T}
 */
function preserve504(value) {
  return value;
}

class Store504 {
  /**
   * @param {Box504<Model504>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project504} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model504} */
const model504 = {
  id: 504, name: "model-504", meta: { active: true, label: "meta-504" },
};
const preserved504 = preserve504(model504);
/** @type {Box504<Model504>} */
const box504 = { value: preserved504, label: "box-504" };
/** @type {Project504} */
const project504 = (input) => `${input.meta.label}:${input.name}`;
const store504 = new Store504(box504);
const rendered504 = store504.read(project504);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult504 = {
  id: preserved504.id,
  name: preserved504.name,
  active: preserved504.meta.active,
  rendered: rendered504,
};

/**
 * @typedef {object} Model505
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box505
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project505
 * @param {Model505} input
 * @returns {string}
 */

/**
 * @template {Model505} T
 * @param {T} value
 * @returns {T}
 */
function preserve505(value) {
  return value;
}

class Store505 {
  /**
   * @param {Box505<Model505>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project505} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model505} */
const model505 = {
  id: 505, name: "model-505", meta: { active: false, label: "meta-505" },
};
const preserved505 = preserve505(model505);
/** @type {Box505<Model505>} */
const box505 = { value: preserved505, label: "box-505" };
/** @type {Project505} */
const project505 = (input) => `${input.meta.label}:${input.name}`;
const store505 = new Store505(box505);
const rendered505 = store505.read(project505);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult505 = {
  id: preserved505.id,
  name: preserved505.name,
  active: preserved505.meta.active,
  rendered: rendered505,
};

/**
 * @typedef {object} Model506
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box506
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project506
 * @param {Model506} input
 * @returns {string}
 */

/**
 * @template {Model506} T
 * @param {T} value
 * @returns {T}
 */
function preserve506(value) {
  return value;
}

class Store506 {
  /**
   * @param {Box506<Model506>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project506} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model506} */
const model506 = {
  id: 506, name: "model-506", meta: { active: true, label: "meta-506" },
};
const preserved506 = preserve506(model506);
/** @type {Box506<Model506>} */
const box506 = { value: preserved506, label: "box-506" };
/** @type {Project506} */
const project506 = (input) => `${input.meta.label}:${input.name}`;
const store506 = new Store506(box506);
const rendered506 = store506.read(project506);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult506 = {
  id: preserved506.id,
  name: preserved506.name,
  active: preserved506.meta.active,
  rendered: rendered506,
};

/**
 * @typedef {object} Model507
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box507
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project507
 * @param {Model507} input
 * @returns {string}
 */

/**
 * @template {Model507} T
 * @param {T} value
 * @returns {T}
 */
function preserve507(value) {
  return value;
}

class Store507 {
  /**
   * @param {Box507<Model507>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project507} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model507} */
const model507 = {
  id: 507, name: "model-507", meta: { active: false, label: "meta-507" },
};
const preserved507 = preserve507(model507);
/** @type {Box507<Model507>} */
const box507 = { value: preserved507, label: "box-507" };
/** @type {Project507} */
const project507 = (input) => `${input.meta.label}:${input.name}`;
const store507 = new Store507(box507);
const rendered507 = store507.read(project507);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult507 = {
  id: preserved507.id,
  name: preserved507.name,
  active: preserved507.meta.active,
  rendered: rendered507,
};

/**
 * @typedef {object} Model508
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box508
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project508
 * @param {Model508} input
 * @returns {string}
 */

/**
 * @template {Model508} T
 * @param {T} value
 * @returns {T}
 */
function preserve508(value) {
  return value;
}

class Store508 {
  /**
   * @param {Box508<Model508>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project508} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model508} */
const model508 = {
  id: 508, name: "model-508", meta: { active: true, label: "meta-508" },
};
const preserved508 = preserve508(model508);
/** @type {Box508<Model508>} */
const box508 = { value: preserved508, label: "box-508" };
/** @type {Project508} */
const project508 = (input) => `${input.meta.label}:${input.name}`;
const store508 = new Store508(box508);
const rendered508 = store508.read(project508);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult508 = {
  id: preserved508.id,
  name: preserved508.name,
  active: preserved508.meta.active,
  rendered: rendered508,
};

/**
 * @typedef {object} Model509
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box509
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project509
 * @param {Model509} input
 * @returns {string}
 */

/**
 * @template {Model509} T
 * @param {T} value
 * @returns {T}
 */
function preserve509(value) {
  return value;
}

class Store509 {
  /**
   * @param {Box509<Model509>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project509} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model509} */
const model509 = {
  id: 509, name: "model-509", meta: { active: false, label: "meta-509" },
};
const preserved509 = preserve509(model509);
/** @type {Box509<Model509>} */
const box509 = { value: preserved509, label: "box-509" };
/** @type {Project509} */
const project509 = (input) => `${input.meta.label}:${input.name}`;
const store509 = new Store509(box509);
const rendered509 = store509.read(project509);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult509 = {
  id: preserved509.id,
  name: preserved509.name,
  active: preserved509.meta.active,
  rendered: rendered509,
};

/**
 * @typedef {object} Model510
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box510
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project510
 * @param {Model510} input
 * @returns {string}
 */

/**
 * @template {Model510} T
 * @param {T} value
 * @returns {T}
 */
function preserve510(value) {
  return value;
}

class Store510 {
  /**
   * @param {Box510<Model510>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project510} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model510} */
const model510 = {
  id: 510, name: "model-510", meta: { active: true, label: "meta-510" },
};
const preserved510 = preserve510(model510);
/** @type {Box510<Model510>} */
const box510 = { value: preserved510, label: "box-510" };
/** @type {Project510} */
const project510 = (input) => `${input.meta.label}:${input.name}`;
const store510 = new Store510(box510);
const rendered510 = store510.read(project510);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult510 = {
  id: preserved510.id,
  name: preserved510.name,
  active: preserved510.meta.active,
  rendered: rendered510,
};

/**
 * @typedef {object} Model511
 * @property {number} id
 * @property {string} name
 * @property {{ active: boolean, label: string }} meta
 */

/**
 * @template T
 * @typedef {object} Box511
 * @property {T} value
 * @property {string} label
 */

/**
 * @callback Project511
 * @param {Model511} input
 * @returns {string}
 */

/**
 * @template {Model511} T
 * @param {T} value
 * @returns {T}
 */
function preserve511(value) {
  return value;
}

class Store511 {
  /**
   * @param {Box511<Model511>} box
   */
  constructor(box) {
    this.box = box;
  }

  /**
   * @param {Project511} project
   * @returns {string}
   */
  read(project) {
    return project(this.box.value);
  }
}

/** @type {Model511} */
const model511 = {
  id: 511, name: "model-511", meta: { active: false, label: "meta-511" },
};
const preserved511 = preserve511(model511);
/** @type {Box511<Model511>} */
const box511 = { value: preserved511, label: "box-511" };
/** @type {Project511} */
const project511 = (input) => `${input.meta.label}:${input.name}`;
const store511 = new Store511(box511);
const rendered511 = store511.read(project511);
/** @type {{ id: number, name: string, active: boolean, rendered: string }} */
export const jsdocResult511 = {
  id: preserved511.id,
  name: preserved511.name,
  active: preserved511.meta.active,
  rendered: rendered511,
};
/** @type {boolean} */ const wrongId0 = preserved0.id;
preserved0.missing;
/** @type {number} */ const wrongCallback0 = project0(model0);
store0.read(123);
/** @type {Box0<Model0>} */ const wrongBox0 = { value: { id: "wrong", name: "x", meta: { active: true, label: "x" } }, label: "x" };
/** @type {boolean} */ const wrongId256 = preserved256.id;
preserved256.missing;
/** @type {number} */ const wrongCallback256 = project256(model256);
store256.read(123);
/** @type {Box256<Model256>} */ const wrongBox256 = { value: { id: "wrong", name: "x", meta: { active: true, label: "x" } }, label: "x" };
/** @type {boolean} */ const wrongId511 = preserved511.id;
preserved511.missing;
/** @type {number} */ const wrongCallback511 = project511(model511);
store511.read(123);
/** @type {Box511<Model511>} */ const wrongBox511 = { value: { id: "wrong", name: "x", meta: { active: true, label: "x" } }, label: "x" };
