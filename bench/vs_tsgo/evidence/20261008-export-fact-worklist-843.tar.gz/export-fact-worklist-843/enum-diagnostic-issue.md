## Verified mismatch

Pinned TS 6.0.3 and frozen Home source `30d3824da` are run on the same strict/no-emit/no-lib ESNext project with `isolatedModules: true`:

- `leaf.d.ts`: `export declare const enum Code { A }`
- `chain0.ts`: named re-export of `Code` (plus a generic function and explicit `export type` interface in the retained fixture).
- `index.ts`: `import { Code } from './chain0'; export const result: number = Code.A;`

TS 6.0.3 emits one TS2748 at `index.ts(2,31)`, the actual `Code.A` access. Home emits TS2748 at `chain0.ts(1,16)` and `index.ts(1,10)` instead. This shallow case is independent of the eight-level cutoff tracked by #843. Corrected 8/32-layer fixtures also retain this mismatch, along with depth-related missing exports on the parent.

Source inspection identifies `checkAmbientConstEnumReExports` and import/runtime-status handling as candidates; this is not yet a verified cause or implementation.

## Required fix and verification

- Match oracle codes/counts and primary source positions for named/star re-exports, unused/value/type imports, actual member access, aliases and relevant module/isolated/verbatim options.
- Preserve genuine ambient const-enum errors; do not suppress all TS2748 or normalize away wrong positions/duplicates.
- Include shallow/deep/cyclic controls and retain full raw command/exit/stdout/stderr and input hashes.
- Keep #843's complete fact traversal separate from diagnostic-location semantics, but rerun these controls when either changes.
- Full checker/Program/CLI suites and pinned production diagnostic multiset gate; document conventional issue-linked commits and verified results.

Parent binary SHA-256: `92338a9715ef01c3bf7e7238f980e9df72e856340f6684daabf98924ceea4960`. Local raw evidence: `/Users/chris/.cache/home-ts-843.3BeUMH/oracle-parent.json` and `oracle-parent-corrected.log`; all fixture files and complete byte hashes retained. No speed claim or source fix yet. Related: #416, #843, #548.
