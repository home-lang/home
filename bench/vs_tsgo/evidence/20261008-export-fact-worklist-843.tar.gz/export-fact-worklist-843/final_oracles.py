import hashlib
import json
from pathlib import Path
import re
import subprocess

root = Path(__file__).resolve().parent
candidate = root / 'home-tsc-final'
for script, output in [('probe_enum_integrated.py', 'final-enum.json'), ('probe_oracle_integrated.py', 'final-oracle.json')]:
    subprocess.run(['python3', str(root / script), str(candidate), output], check=True)

def identities(record):
    results = []
    for line in (record['stdout'] + record['stderr']).splitlines():
        match = re.match(r'^(.+?)\((\d+),(\d+)\): error TS(\d+): (.*)$', line)
        if match:
            path, row, col, code, message = match.groups()
            results.append([path.split('/src/', 1)[-1], int(row), int(col), int(code), message])
        else:
            assert not line.strip(), line
    return sorted(results)

verified = []
for filename in ['final-enum.json', 'final-oracle.json']:
    cases = {}
    for record in json.loads((root / filename).read_text())['records']:
        key = record.get('case', str(record.get('depth')) + '-' + str(record.get('mode')))
        cases.setdefault(key, {})[record['compiler']] = record
    for key, records in cases.items():
        assert bool(records['tsc']['exit']) == bool(records['candidate']['exit']), key
        assert identities(records['tsc']) == identities(records['candidate']), key
        verified.append(key)
assert len(verified) == 30

fixture = root / 'default-star-oracle'
commands = {
    'tsc': ['/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang/bench/vs_tsgo/.tools/tsc/node_modules/.bin/tsc'],
    'parent': [str(root / 'home-tsc-integrated-parent')],
    'candidate': [str(candidate)],
}
records = []
for compiler, command in commands.items():
    argv = command + ['--noEmit', '-p', str(fixture / 'tsconfig.json')]
    result = subprocess.run(argv, capture_output=True, text=True)
    record = {'compiler': compiler, 'command': argv, 'exit': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr}
    record['identities'] = identities(record)
    records.append(record)
    print(compiler, result.returncode, record['identities'], flush=True)
default = {
    'records': records,
    'inputs': {str(path.relative_to(fixture)): hashlib.sha256(path.read_bytes()).hexdigest() for path in sorted(fixture.rglob('*')) if path.is_file()},
    'binaries': {key: hashlib.sha256(Path(command[0]).read_bytes()).hexdigest() for key, command in commands.items()},
}
(root / 'final-default-oracle.json').write_text(json.dumps(default, indent=2) + '\n')
assert records[0]['exit'] != 0 and records[2]['exit'] != 0
assert [identity[:4] for identity in records[0]['identities']] == [identity[:4] for identity in records[2]['identities']]
print('Verified 30 exact-message oracles plus default-star diagnostic identity', flush=True)
