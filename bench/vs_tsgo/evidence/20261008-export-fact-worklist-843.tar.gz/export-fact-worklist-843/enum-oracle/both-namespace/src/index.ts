import * as ns from './chain';
export const result = ns.Code.A;
