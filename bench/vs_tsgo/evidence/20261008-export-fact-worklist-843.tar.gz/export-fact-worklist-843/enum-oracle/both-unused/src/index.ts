import { Code } from './chain';
export const result = 1;
