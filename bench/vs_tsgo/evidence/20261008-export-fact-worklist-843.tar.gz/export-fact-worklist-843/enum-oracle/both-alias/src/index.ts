import { Code as E } from './chain';
export const result = E.A;
