export declare const enum Code { A }
