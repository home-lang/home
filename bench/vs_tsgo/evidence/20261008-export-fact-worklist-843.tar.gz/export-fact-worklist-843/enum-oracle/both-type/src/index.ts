import type { Code } from './chain';
export type Result = Code;
