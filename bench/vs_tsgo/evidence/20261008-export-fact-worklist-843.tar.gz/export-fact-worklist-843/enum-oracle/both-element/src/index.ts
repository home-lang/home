import { Code } from './chain';
export const result = Code['A'];
