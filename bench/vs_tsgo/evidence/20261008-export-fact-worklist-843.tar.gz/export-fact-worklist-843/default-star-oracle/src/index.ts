import make from './barrel';
export const result = make(1);
