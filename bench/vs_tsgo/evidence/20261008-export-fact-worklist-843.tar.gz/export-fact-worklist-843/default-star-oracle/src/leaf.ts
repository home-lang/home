export default function make<T>(value: T): T { return value; }
