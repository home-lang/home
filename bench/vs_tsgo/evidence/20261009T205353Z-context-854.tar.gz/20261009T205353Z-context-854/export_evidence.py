"""Package the original completed result through the canonical evidence command."""
import json
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
record = json.loads((root / 'command.json').read_text())
assert record['exit'] == 0 and record['result'] == '20261009T205353Z'
archive = repo / 'bench/vs_tsgo/evidence' / (record['result'] + '.tar.gz')
assert not archive.exists()
command = ['env', 'HOME_RUN_MAX_MB=3840', 'HOME_RUN_LABEL=ts854-landed-prefix-evidence',
    'perl', 'scripts/run-bounded.pl', '600', 'python3', 'bench/vs_tsgo/run.py', 'evidence',
    'bench/vs_tsgo/results/' + record['result']]
result = subprocess.run(command, cwd=repo, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
(root / 'export.log').write_text(result.stdout)
(root / 'export-command.json').write_text(json.dumps({'command': command, 'exit': result.returncode}, indent=2) + '\n')
print(result.stdout, flush=True)
assert result.returncode == 0 and archive.exists()
