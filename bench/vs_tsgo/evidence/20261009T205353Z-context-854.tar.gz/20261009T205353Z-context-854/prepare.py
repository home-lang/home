"""Verify a clean matching current-main native build before matrix timing."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
source = '0d2b0097abf6dbb37630505b69e8a261c7d53c9a'
compiler_source = '11055ba4746b224735c8ec2cba2f5e449bfff980'
expected = '68c6ed517f9125ae1b570ff2e585c5b368745389af828258f6621fe5e6e0311c'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip() == source
assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=repo).decode() == ''
assert subprocess.run(['git', 'diff', '--quiet', compiler_source, source, '--', 'packages', 'build.zig', 'build.zig.zon'], cwd=repo).returncode == 0
command = ['env', 'HOME_RUN_MAX_MB=3840', 'HOME_RUN_LABEL=ts854-landed-prefix-clean-build', 'perl', 'scripts/run-bounded.pl', '600',
    '/Users/chris/Code/Home/lang-bun-port/zig-out/toolchains/zig-aarch64-macos-0.17.0-dev.2163+89ff10d56/zig', 'build', 'home-tsc',
    '-Doptimize=ReleaseFast', '-Dhome-tsc-strip=true', '-Denable_jsc=false', '-j1', '--summary', 'all']
result = subprocess.run(command, cwd=repo, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
(root / 'clean-build.log').write_text(result.stdout)
(root / 'clean-build-command.json').write_text(json.dumps({'command': command, 'exit': result.returncode}, indent=2) + '\n')
assert result.returncode == 0
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip() == source
assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=repo).decode() == ''
native = repo / 'zig-out/bin/home-tsc'
assert hashlib.sha256(native.read_bytes()).hexdigest() == expected
shutil.copy2(native, root / 'home-tsc-current')
(root / 'clean-build-provenance.json').write_text(json.dumps({'source': source, 'compiler_source': compiler_source,
    'native_sha256': expected, 'source_clean_before_and_after': True, 'matches_accepted_candidate': True}, indent=2) + '\n')
print(result.stdout[-2000:], flush=True)
print('Clean current-main native matches accepted candidate SHA256 ' + expected, flush=True)
