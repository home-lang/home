| Workload | tsc 6.0.3 median | native TS 7.0.2 median | Home median | Rust tsc-rs 0.1.0 median | Bun canary median | Home vs fastest competitor |
|---|---:|---:|---:|---:|---:|---:|
| `checkjs_jsdoc` | 203.3 ms | 23.2 ms | 27.2 ms | 22.4 ms | 13.4 ms | 2.03× slower |
| `class_hierarchy` | 191.6 ms | 21.8 ms | 23.8 ms | 18.4 ms | 14.0 ms | 1.70× slower |
| `commonjs_graph` | 151.0 ms | 18.1 ms | 17.9 ms | 14.8 ms | 12.0 ms | 1.49× slower |
| `control_flow` | 193.8 ms | 27.8 ms | 25.9 ms | 24.8 ms | 16.6 ms | 1.56× slower |
| `deep_types` | 130.1 ms | 21.4 ms | 21.1 ms | 14.1 ms | 13.3 ms | 1.59× slower |
| `destructuring` | 147.4 ms | 17.2 ms | 15.5 ms | 15.8 ms | 11.6 ms | 1.34× slower |
| `generic_calls` | 189.0 ms | 23.5 ms | 23.7 ms | 19.5 ms | 15.1 ms | 1.56× slower |
| `import_graph` | 128.9 ms | 14.7 ms | 17.1 ms | 11.3 ms | 15.1 ms | 1.51× slower |
| `interface_composition` | 199.0 ms | 31.6 ms | 34.0 ms | 23.6 ms | 17.5 ms | 1.95× slower |
| `many_files` | 198.1 ms | 22.5 ms | 21.7 ms | 16.0 ms | 13.2 ms | 1.65× slower |
| `null_safe_access` | 189.6 ms | 26.4 ms | 32.4 ms | 22.6 ms | 16.5 ms | 1.97× slower |
| `overload_resolution` | 211.8 ms | 34.6 ms | 24.7 ms | 27.6 ms | 21.2 ms | 1.16× slower |
| `recursive_generics` | 152.8 ms | 40.0 ms | 14.5 ms | 32.5 ms | 9.4 ms | 1.54× slower |
| `reexport_graph` | 96.7 ms | 10.5 ms | 12.5 ms | 8.9 ms | 8.6 ms | 1.46× slower |
| `startup` | 63.9 ms | 7.5 ms | 2.9 ms | 5.9 ms | 6.3 ms | **2.04× faster** |
| `structural_objects` | 192.1 ms | 27.0 ms | 23.2 ms | 22.7 ms | 16.7 ms | 1.39× slower |
| `tsx_components` | 166.9 ms | 16.2 ms | 19.0 ms | 14.4 ms | 10.5 ms | 1.80× slower |
| `type_predicates` | 235.1 ms | 40.5 ms | 32.7 ms | 34.1 ms | 23.4 ms | 1.40× slower |
| `type_predicates_large` | 1,010.1 ms | 309.8 ms | 244.3 ms | 268.9 ms | 158.5 ms | 1.54× slower |
| `variadic_tuples` | 247.5 ms | 45.8 ms | 31.8 ms | 34.0 ms | 19.2 ms | 1.66× slower |
