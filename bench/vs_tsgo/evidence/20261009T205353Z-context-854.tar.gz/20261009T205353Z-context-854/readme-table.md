| Workload | tsc 6.0.3 median | native TS 7.0.2 median | Home median | Rust tsc-rs 0.1.0 median | Bun canary median | Home vs fastest competitor |
|---|---:|---:|---:|---:|---:|---:|
| Startup (one small file) | 63.9 ms | 7.5 ms | 2.9 ms | 5.9 ms | 6.3 ms | **2.04× faster** |
| 256 independent files | 198.1 ms | 22.5 ms | 21.7 ms | 16.0 ms | 13.2 ms | 1.65× slower |
| 128-module import chain | 128.9 ms | 14.7 ms | 17.1 ms | 11.3 ms | 15.1 ms | 1.51× slower |
| 64 modules through 8 barrel re-exports | 96.7 ms | 10.5 ms | 12.5 ms | 8.9 ms | 8.6 ms | 1.46× slower |
| Deep conditional / mapped / template types | 130.1 ms | 21.4 ms | 21.1 ms | 14.1 ms | 13.3 ms | 1.59× slower |
| Recursive generics | 152.8 ms | 40.0 ms | 14.5 ms | 32.5 ms | 9.4 ms | 1.54× slower |
| Checked JavaScript with JSDoc | 203.3 ms | 23.2 ms | 27.2 ms | 22.4 ms | 13.4 ms | 2.03× slower |
| Control-flow narrowing (256 unions) | 193.8 ms | 27.8 ms | 25.9 ms | 24.8 ms | 16.6 ms | 1.56× slower |
| 256 type-predicate families | 235.1 ms | 40.5 ms | 32.7 ms | 34.1 ms | 23.4 ms | 1.40× slower |
| 2,048 type-predicate families | 1,010.1 ms | 309.8 ms | 244.3 ms | 268.9 ms | 158.5 ms | 1.54× slower |
