import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
prepared = json.loads((root / 'clean-build-provenance.json').read_text())
assert prepared['source_clean_before_and_after'] and prepared['matches_accepted_candidate']
compiler_source = prepared['compiler_source']
native = root / 'home-tsc-current'
expected = '68c6ed517f9125ae1b570ff2e585c5b368745389af828258f6621fe5e6e0311c'
assert prepared['native_sha256'] == expected
assert hashlib.sha256(native.read_bytes()).hexdigest() == expected
assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=repo, text=True) == ''
assert subprocess.run(['git', 'diff', '--quiet', compiler_source, 'HEAD', '--', 'packages', 'build.zig', 'build.zig.zon'], cwd=repo).returncode == 0
source = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
assert source == prepared['source']
command = ['perl', 'scripts/run-bounded.pl', '600', 'python3', 'bench/vs_tsgo/run.py',
    'cold', '--runs', '30', '--warmup', '3', '--competitor-manifest', 'bench/vs_tsgo/profiles/darwin-arm64.json']
env = os.environ.copy()
env['HOME_RUN_MAX_MB'] = '3840'
env['HOME_RUN_LABEL'] = 'ts854-landed-jsdoc-prefix-matrix'
env['HOME_TSC'] = str(native)
record = {'command': command, 'source': source, 'compiler_source': compiler_source,
    'native_sha256': expected, 'runs': 30, 'warmup': 3, 'guard_mb': 3840,
    'runner_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(root / 'command.json').write_text(json.dumps(record, indent=2) + '\n')
result = subprocess.run(command, cwd=repo, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
(root / 'matrix.log').write_text(result.stdout)
record['exit'] = result.returncode
matches = re.findall(r'^Results: (.+)$', result.stdout, re.MULTILINE)
if result.returncode == 0:
    assert len(matches) == 1
    record['result'] = Path(matches[0]).name
(root / 'command.json').write_text(json.dumps(record, indent=2) + '\n')
print(result.stdout[-5500:], flush=True)
assert result.returncode == 0
assert hashlib.sha256(native.read_bytes()).hexdigest() == expected
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip() == source
