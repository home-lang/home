Diagnostic profile of latest-source native 2c6666ac, compiler source36a2d95e, context175c6cab.
One unchanged process, two predeclared windows, all36 complete admissions; zero benchmark timing samples.
Original profile/context bytes and separately retained native/link/object images are preserved.
Whole declared relocation words are masked; no opcode/bit equivalence is claimed inside masks.
Only explicit PCs map; ellipses and inclusive/collapsed counts are not attributed CPU shares.
Historical progress records remain unchanged; verified-profile/current-profile-terminal govern the outcome.
No compiler source change, measurement rerun or speedup claim.
