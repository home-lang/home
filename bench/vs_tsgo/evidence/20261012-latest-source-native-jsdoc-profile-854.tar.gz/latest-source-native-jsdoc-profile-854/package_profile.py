import hashlib
import json
from pathlib import Path
import sys
import tarfile

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts863-qualification-docs/lang')
sys.path.insert(0, str(repo / 'bench/vs_tsgo'))
import run
assert json.loads((root / 'verified-map.json').read_bytes())['passed']
assert json.loads((root / 'verified-profile.json').read_bytes())['passed']
outcome = json.loads((root / 'profile-outcome.json').read_bytes())
assert outcome['artifacts_unchanged'] and all(row['exit'] == 0 for row in outcome['records'])
assert all(row['guard_exit'] == 0 for row in json.loads((root / 'current-profile-terminal.json').read_bytes())['records'])
for row in json.loads((root / 'profile-script-hashes.json').read_bytes())['scripts']:
    assert hashlib.sha256((root / row['name']).read_bytes()).hexdigest() == row['adapted_sha256']
prefix = 'latest-source-native-jsdoc-profile-854'
members = {}
for path in sorted(root.rglob('*')):
    assert not path.is_symlink()
    if path.is_file() and '__pycache__' not in path.parts:
        members[prefix + '/' + path.relative_to(root).as_posix()] = path.read_bytes()
members[prefix + '/README.txt'] = (
    'Diagnostic profile of latest-source native 2c6666ac, compiler source36a2d95e, context175c6cab.\n'
    'One unchanged process, two predeclared windows, all36 complete admissions; zero benchmark timing samples.\n'
    'Original profile/context bytes and separately retained native/link/object images are preserved.\n'
    'Whole declared relocation words are masked; no opcode/bit equivalence is claimed inside masks.\n'
    'Only explicit PCs map; ellipses and inclusive/collapsed counts are not attributed CPU shares.\n'
    'Historical progress records remain unchanged; verified-profile/current-profile-terminal govern the outcome.\n'
    'No compiler source change, measurement rerun or speedup claim.\n'
).encode()
members[prefix + '/SHA256SUMS'] = ''.join('{}  {}\n'.format(hashlib.sha256(raw).hexdigest(), name.removeprefix(prefix + '/')) for name, raw in sorted(members.items())).encode()
output = repo / 'bench/vs_tsgo/evidence/20261012-latest-source-native-jsdoc-profile-854.tar.gz'
assert not output.exists()
run.write_evidence_archive(output, members)
with tarfile.open(output) as archive:
    for name, raw in members.items(): assert archive.extractfile(name).read() == raw
print(json.dumps({'archive': str(output), 'sha256': hashlib.sha256(output.read_bytes()).hexdigest(), 'verified_payloads': len(members)-1, 'bytes': output.stat().st_size, 'all_original_bytes_verified': True}), flush=True)
