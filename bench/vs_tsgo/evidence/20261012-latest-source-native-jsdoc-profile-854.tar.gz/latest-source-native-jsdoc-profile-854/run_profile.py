"""Require unchanged artifacts and complete admission before the single profile."""
import json
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts863-qualification-docs/lang')
measured = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
sys.path.insert(0, str(measured / 'bench/vs_tsgo'))
import run
matrix = json.loads((repo / 'bench/vs_tsgo/results/20261011T232901Z-resumed/metadata.json').read_bytes())
commands = {name: matrix['provenance']['before']['compilers'][name]['command'] for name in ['tsc', 'tsgo', 'home']}
commands['home'] = [str(root / 'home-tsc-current')]
before = run.benchmark_provenance(commands)
with (root / 'artifacts-before.json').open('x') as stream:
    json.dump(before, stream, indent=2)
records = []
for name in ['admit_scale.py', 'profile_native.py', 'resolve_samples.py', 'verify_profile.py', 'extract_observed_code.py']:
    assert run.benchmark_provenance(commands) == before, 'Artifacts changed before phase'
    print('Starting ' + name, flush=True)
    with (root / (name + '.log')).open('x') as stream:
        result = subprocess.run([sys.executable, str(root / name)], stdout=stream, stderr=subprocess.STDOUT)
    records.append({'script': name, 'exit': result.returncode})
    print(json.dumps(records[-1]), flush=True)
    if result.returncode != 0:
        print((root / (name + '.log')).read_text()[-3000:], flush=True)
        break
after = run.benchmark_provenance(commands)
with (root / 'profile-outcome.json').open('x') as stream:
    json.dump({'records': records, 'artifacts_before': before, 'artifacts_after': after,
               'artifacts_unchanged': before == after, 'benchmark_timing_samples': 0}, stream, indent=2)
assert before == after, 'Artifacts changed during diagnostic workflow'
raise SystemExit(records[-1]['exit'])
