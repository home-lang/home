"""Build the current source separately; retain exact provenance and old images."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

repo = Path('/Users/chris/.codex/worktrees/ts863-qualification-docs/lang')
root = Path(__file__).resolve().parent
head = '175c6cabcea439c0c60a32a8ee168ffa8123c230'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip() == head
assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=repo) == b''
files = subprocess.check_output(['git', 'ls-files', '-z', '--', 'packages', 'build.zig', 'build.zig.zon'], cwd=repo).decode().split('\0')
sources = {name: hashlib.sha256((repo / name).read_bytes()).hexdigest() for name in files if name and (repo / name).is_file()}
gitlinks = subprocess.check_output(['git', 'ls-files', '--stage', '--', 'packages'], cwd=repo, text=True)
gitlinks = [line for line in gitlinks.splitlines() if line.startswith('160000 ')]
images = [repo / 'zig-out/bin/home-tsc', Path('/Users/chris/.cache/home-ts-owned-alias-inflight-interfaces.jHEAoG/candidate-home-tsc')]
before = {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in images}
command = ['/Users/chris/Code/Home/lang-bun-port/zig-out/toolchains/zig-aarch64-macos-0.17.0-dev.2163+89ff10d56/zig', 'build', 'home-tsc', '-Doptimize=ReleaseFast', '-Dhome-tsc-strip=true', '-Denable_jsc=false', '-j1', '--summary', 'all', '--prefix', str(root / 'native')]
start = {'issue': 854, 'source_head': head, 'source_sha256': sources, 'gitlink_entries': gitlinks, 'command': command, 'previous_images': before, 'timing_samples': 0}
with (root / 'build-started.json').open('x') as stream: json.dump(start, stream, indent=2)
env = dict(os.environ, HOME_RUN_MAX_MB='3840', HOME_RUN_LABEL='ts854-current-source-profile-baseline')
with (root / 'build-guard.log').open('x') as stream:
    result = subprocess.run(['perl', 'scripts/run-bounded.pl', '600'] + command, cwd=repo, env=env, stdout=stream, stderr=subprocess.STDOUT)
record = dict(start, guard_exit=result.returncode)
record['source_unchanged'] = all(hashlib.sha256((repo / name).read_bytes()).hexdigest() == digest for name, digest in sources.items())
record['previous_images_unchanged'] = all(hashlib.sha256(path.read_bytes()).hexdigest() == before[str(path)] for path in images)
if result.returncode == 0:
    frozen = root / 'current-home-tsc'
    assert not frozen.exists()
    shutil.copy2(root / 'native/bin/home-tsc', frozen)
    record['native_sha256'] = hashlib.sha256(frozen.read_bytes()).hexdigest()
with (root / 'build-terminal.json').open('x') as stream: json.dump(record, stream, indent=2)
assert record['source_unchanged'] and record['previous_images_unchanged']
print(json.dumps({key: value for key, value in record.items() if key != 'source_sha256'}), flush=True)
raise SystemExit(result.returncode)
