"""Guard exact-image mapping and admitted single-process diagnostic sampling."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts863-qualification-docs/lang')
build = json.loads((root / 'build-terminal.json').read_bytes())
assert build['guard_exit'] == 0 and build['source_unchanged'] and build['previous_images_unchanged']
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip() == build['source_head']
assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=repo) == b''
assert subprocess.check_output(['git', 'diff', '36a2d95e88d5fb1117218301ed7fbbfacda919b2', 'HEAD', '--', 'packages', 'build.zig', 'build.zig.zon'], cwd=repo) == b''
for name, digest in build['source_sha256'].items(): assert hashlib.sha256((repo / name).read_bytes()).hexdigest() == digest
records = []
for script in ['build_native_map.py', 'verify_map.py', 'prepare_scale.py', 'run_profile.py']:
    env = dict(os.environ, HOME_RUN_MAX_MB='3840', HOME_RUN_LABEL='ts854-current-' + script)
    command = ['perl', 'scripts/run-bounded.pl', '600', sys.executable, str(root / script)]
    with (root / (script + '.guard.log')).open('x') as stream:
        result = subprocess.run(command, cwd=repo, env=env, stdout=stream, stderr=subprocess.STDOUT)
    records.append({'script': script, 'guard_exit': result.returncode, 'command': command})
    print(json.dumps(records[-1]), flush=True)
    with (root / 'current-profile-progress.json').open('w') as stream: json.dump({'records': records}, stream, indent=2)
    if result.returncode != 0: break
with (root / 'current-profile-terminal.json').open('x') as stream:
    json.dump({'records': records, 'benchmark_timing_samples': 0, 'source_adopted': False}, stream, indent=2)
raise SystemExit(records[-1]['guard_exit'])
