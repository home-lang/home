import hashlib
import json
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
parent = subprocess.check_output(['git', 'show', '35e3326510572dfc93d06293cad217ca167859ce:packages/ts_checker/src/check.zig'], cwd=repo).decode()
current = (repo / 'packages/ts_checker/src/check.zig').read_text()
stop = '    fn aliasedGuardReferencesAreStable('
original = parent.split('    fn guardReferencesAssignedIdentifier(', 1)[1].split(stop, 1)[0]
slow = current.split('    fn guardReferencesAssignedIdentifierSlow(', 1)[1].split(stop, 1)[0]
assert original == slow
marker = '    fn nodeAssignsIdentifier('
end = '    fn removeDefinitelyAssignedAfterFor('
assert parent.split(marker, 1)[1].split(end, 1)[0] == current.split(marker, 1)[1].split(end, 1)[0]
wrapper = current.split('    fn guardReferencesAssignedIdentifier(', 1)[1].split('    fn guardReferencesAssignedIdentifierSlow(', 1)[0]
code = '\n'.join(line for line in wrapper.splitlines() if not line.strip().startswith('//'))
for forbidden in ['source_may', 'sourceMarker', 'cache', '.put(', '.append(', 'allocPrint']:
    assert forbidden not in code
assert 'if (!self.nodeHasSupportedIdentifierAssignment(body)) return false;' in wrapper
assert 'return self.guardReferencesAssignedIdentifierSlow(guard);' in wrapper
assert subprocess.check_output(['git', 'diff', '--name-only'], cwd=repo).decode().splitlines() == ['packages/ts_checker/src/check.zig']
record = {'passed': True, 'source_parent': '35e3326510572dfc93d06293cad217ca167859ce',
          'original_global_span_scan_byte_identical': True, 'original_name_specific_assignment_query_byte_identical': True,
          'new_allocation_or_cache': False, 'assignment_results_cached': False, 'live_body_checked_every_query': True,
          'patch_sha256': hashlib.sha256(subprocess.check_output(['git', 'diff'], cwd=repo)).hexdigest()}
(root / 'verified-source.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record), flush=True)
