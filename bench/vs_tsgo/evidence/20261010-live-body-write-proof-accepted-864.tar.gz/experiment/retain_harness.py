from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
with (root / 'harness.log').open('w') as output:
    result = subprocess.run([sys.executable, '-m', 'unittest', 'discover', '-s', 'bench/vs_tsgo', '-p', 'test_*.py'],
                            stdout=output, stderr=subprocess.STDOUT)
print((root / 'harness.log').read_text()[-300:], flush=True)
raise SystemExit(result.returncode)
