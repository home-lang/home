import json
from pathlib import Path

root = Path(__file__).resolve().parent
protocol = json.loads((root / 'protocol.json').read_text())
screen = json.loads((root / 'screen-statistics.json').read_text())
target = json.loads((root / 'target-statistics.json').read_text())
assert screen['verified'] and screen['pairs'] == 200
assert target['verified'] and target['pairs'] == 30
risks = list(protocol['independent_regression_workloads'])
risks += [name for name in screen['additional_adverse_workloads'] if name not in risks]
records = []
for name in risks:
    record = json.loads((root / ('risk-' + name + '-statistics.json')).read_text())
    assert record['verified'] and record['pairs'] == 30 and list(record['rows']) == [name]
    records.append(record)
target_row = target['rows'][protocol['independent_target']]
losses = [name for record in records for name, row in record['rows'].items() if row['conclusion'] == 'loss']
qualified = target_row['conclusion'] == 'saving' and not losses
result = {'decision': 'eligible' if qualified else 'reject', 'source_changes_qualified_for_adoption': qualified,
          'target': target_row, 'independent_regression_losses': losses,
          'pairs': screen['pairs'] + target['pairs'] + sum(record['pairs'] for record in records),
          'phase_count': 2 + len(records), 'additional_adverse_workloads': screen['additional_adverse_workloads'],
          'all_raw_samples_retained': True, 'measurement_reruns': 0,
          'zero_spanning_risk_intervals_are_not_equivalence': True,
          'full_competitor_ranking_refreshed': False, 'universal_goal_complete': False}
(root / 'decision.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result), flush=True)
