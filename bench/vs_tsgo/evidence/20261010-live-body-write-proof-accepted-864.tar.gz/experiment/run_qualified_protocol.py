"""Single qualified continuation; no missing or incomplete phase is rerun."""
import json
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
state_path = root / 'qualified-protocol-command.json'
assert not state_path.exists(), 'Audit the original execution; do not duplicate it'
state = {'status': 'running', 'completed_steps': [], 'timing_repeats': 0}
state_path.write_text(json.dumps(state, indent=2) + '\n')
steps = [
    ['verify_gates.py'],
    ['run_phase.py', 'screen'],
    ['paired_statistics.py', 'screen'],
    ['run_phase.py', 'target'],
    ['paired_statistics.py', 'target'],
    ['run_confirmations.py'],
    ['decide.py'],
]
for arguments in steps:
    command = [sys.executable, str(root / arguments[0]), *arguments[1:]]
    result = subprocess.run(command, cwd=repo)
    state['completed_steps'].append({'command': command, 'exit': result.returncode})
    if result.returncode:
        state.update(status='incomplete', exit=result.returncode)
        state_path.write_text(json.dumps(state, indent=2) + '\n')
        raise SystemExit(result.returncode)
    state_path.write_text(json.dumps(state, indent=2) + '\n')
state.update(status='complete', exit=0)
state_path.write_text(json.dumps(state, indent=2) + '\n')
