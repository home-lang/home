import hashlib
import json
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
command = ['/Users/chris/Code/Home/lang-bun-port/zig-out/toolchains/zig-aarch64-macos-0.17.0-dev.2163+89ff10d56/zig',
           'build', 'home-tsc', '-Doptimize=ReleaseFast', '-Dhome-tsc-strip=true', '-Denable_jsc=false', '-j1', '--summary', 'all']
with (root / 'candidate-build.log').open('w') as output:
    result = subprocess.run(command, cwd=repo, stdout=output, stderr=subprocess.STDOUT)
record = {'command': command, 'exit': result.returncode,
          'source_parent': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip(),
          'source_patch': subprocess.check_output(['git', 'diff'], cwd=repo).decode()}
if result.returncode == 0:
    native = repo / 'zig-out/bin/home-tsc'
    record['native_sha256'] = hashlib.sha256(native.read_bytes()).hexdigest()
(root / 'candidate-build.json').write_text(json.dumps(record, indent=2) + '\n')
print((root / 'candidate-build.log').read_text(), flush=True)
raise SystemExit(result.returncode)
