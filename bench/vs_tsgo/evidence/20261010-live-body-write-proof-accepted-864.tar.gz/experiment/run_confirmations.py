import json
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
protocol = json.loads((root / 'protocol.json').read_text())
screen = json.loads((root / 'screen-statistics.json').read_text())
assert screen['verified'] and screen['pairs'] == 200
risks = list(protocol['independent_regression_workloads'])
risks += [name for name in screen['additional_adverse_workloads'] if name not in risks]
records = []
for name in risks:
    phase = 'risk-' + name
    existing = root / (phase + '-command.json')
    if existing.exists():
        saved = json.loads(existing.read_text())
        assert saved['status'] == 'complete' and saved['exit'] == 0, 'Audit incomplete phase; never blindly repeat it'
        result = 0
        reused = True
    else:
        result = subprocess.run([sys.executable, str(root / 'run_phase.py'), phase]).returncode
        reused = False
    records.append({'phase': phase, 'exit': result, 'completed_phase_reused_not_retimed': reused})
    (root / 'confirmations.json').write_text(json.dumps(records, indent=2) + '\n')
    if result:
        raise SystemExit(result)
for name in risks:
    result = subprocess.run([sys.executable, str(root / 'paired_statistics.py'), 'risk-' + name],
                            stdout=subprocess.DEVNULL).returncode
    assert result == 0
print('All prescribed independent risk confirmations and raw/statistical verification complete.', flush=True)
