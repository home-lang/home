import hashlib
import json
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
source = json.loads((root / 'verified-source.json').read_text())
build = json.loads((root / 'candidate-build.json').read_text())
admission = json.loads((root / 'verified-image-admission.json').read_text())
assert source['passed'] and build['exit'] == 0 and admission['passed'] and admission['admissions'] == 180
assert hashlib.sha256(subprocess.check_output(['git', 'diff'], cwd=repo)).hexdigest() == source['patch_sha256'] == admission['patch_sha256']
assert hashlib.sha256((root / 'parent-home-tsc').read_bytes()).hexdigest() == admission['parent_sha256']
assert hashlib.sha256((root / 'candidate-home-tsc').read_bytes()).hexdigest() == admission['candidate_sha256'] == build['native_sha256']
assert hashlib.sha256((repo / 'zig-out/bin/home-tsc').read_bytes()).hexdigest() == admission['candidate_sha256']
assert json.loads((root / 'checker.json').read_text())['exit'] == 0
assert 'All 4557 tests passed.' in (root / 'checker.log').read_text()
expected = {'program': 255, 'driver': 200, 'cli': 76, 'entrypoint': 38}
gates = json.loads((root / 'remaining-gates.json').read_text())
assert len(gates) == 4 and {record['target'] for record in gates} == set(expected)
for record in gates:
    assert record['exit'] == 0
    log = (root / (record['target'] + '-tests.log')).read_text()
    assert f"All {expected[record['target']]} tests passed." in log
    assert 'run-bounded: peak tree footprint' in log
assert 'Ran 147 tests' in (root / 'harness.log').read_text() and (root / 'harness.log').read_text().rstrip().endswith('OK')
assert admission['zod_TS'] == 241 and admission['zod_HM9002'] == 2 and admission['zod_admitted'] is False
result = {'passed': True, 'checker': 4557, **expected, 'harness': 147, 'admissions': 180,
          'parent_native_sha256': admission['parent_sha256'], 'candidate_native_sha256': admission['candidate_sha256'],
          'patch_sha256': source['patch_sha256'], 'zod_TS': 241, 'zod_HM9002': 2,
          'timing_started': (root / 'screen-command.json').exists(),
          'candidate_committed': False}
(root / 'verified-gates.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result), flush=True)
