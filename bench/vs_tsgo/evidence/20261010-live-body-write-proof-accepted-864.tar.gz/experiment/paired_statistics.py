"""Independent raw-pair/order/exit/provenance validation and frozen paired statistics."""
import hashlib
import json
import math
from pathlib import Path
import random
import re
import statistics as standard_statistics
import sys

root = Path(__file__).resolve().parent
protocol = json.loads((root / 'protocol.json').read_text())

def percentile(values, fraction):
    position = (len(values) - 1) * fraction
    low = math.floor(position)
    high = math.ceil(position)
    return values[low] + (values[high] - values[low]) * (position - low)

def bootstrap(differences):
    generator = random.Random(864)
    estimates = []
    for _ in range(20000):
        estimates.append(sum(differences[generator.randrange(len(differences))]
                             for _ in differences) / len(differences))
    estimates.sort()
    return [percentile(estimates, 0.025), percentile(estimates, 0.975)]

def validate_phase(phase):
    folder = root / phase
    metadata = json.loads((folder / 'metadata.json').read_text())
    assert metadata['phase'] == phase and metadata['status'] == 'complete'
    assert metadata['before'] == metadata['after']
    assert metadata['protocol_sha256'] == hashlib.sha256((root / 'protocol.json').read_bytes()).hexdigest()
    assert metadata['parent_sha256'] == protocol['parent_native_sha256']
    qualified = json.loads((root / 'verified-image-admission.json').read_text())
    assert metadata['candidate_sha256'] == qualified['candidate_sha256']
    assert metadata['source_parent'] == protocol['parent_source']
    assert metadata['warmups'] == 3
    assert metadata['runner_sha256'] == hashlib.sha256((root / 'paired.py').read_bytes()).hexdigest()
    required = 10 if phase == 'screen' else 30
    assert metadata['pairs'] == required
    expected_files = {f'{workload}-pair-{index:03d}.json' for workload in metadata['workloads'] for index in range(required)}
    assert {path.name for path in folder.glob('*-pair-*.json')} == expected_files
    trace = metadata['admissions']
    expected_keys = {(image, workload, 'positive') for image in ['parent', 'candidate'] for workload in metadata['workloads']}
    negative_workloads = {'destructuring', 'type_predicates', 'type_predicates_large', 'import_graph', 'reexport_graph',
                         'variadic_tuples', 'commonjs_graph', 'recursive_generics', 'checkjs_jsdoc', 'null_safe_access'}
    expected_keys |= {(image, workload, 'negative') for image in ['parent', 'candidate']
                     for workload in metadata['workloads'] if workload in negative_workloads}
    assert len(trace) == len(expected_keys)
    assert {(record['compiler'], record['workload'], record['kind']) for record in trace} == expected_keys
    for record in trace:
        assert record['passed']
        assert isinstance(record['stdout'], str) and isinstance(record['stderr'], str)
        codes = sorted(re.findall(r'\berror TS(\d+):', record['stdout'] + record['stderr']))
        assert codes == record['codes']
        image = 'home' if record['compiler'] == 'candidate' else 'parent'
        prefix = metadata['before']['compilers'][image]['command']
        assert record['command'][:len(prefix)] == prefix
        assert record['command'][len(prefix):len(prefix) + 2] == ['--noEmit', '-p']
        assert len(record['command']) == len(prefix) + 3
        if record['kind'] == 'positive':
            assert record['exit_code'] == 0 and not record['stdout'] and not record['stderr']
        else:
            assert record['exit_code'] == 1 and record['codes'] == sorted(record['expected_codes'])
            if record['workload'] == 'null_safe_access':
                assert codes == sorted(['2322'] * 18 + ['2339', '2345', '2493'] * 3)
            if record['workload'] == 'checkjs_jsdoc':
                assert codes == ['2322'] * 9 + ['2339'] * 3 + ['2345'] * 3
    rows = {}
    for workload in metadata['workloads']:
        parent, candidate, differences = [], [], []
        for index in range(required):
            data = json.loads((folder / f'{workload}-pair-{index:03d}.json').read_text())
            order = ['parent', 'candidate'] if index % 2 == 0 else ['candidate', 'parent']
            assert [record['command'] for record in data['results']] == [name + ' ' + workload for name in order]
            values = {}
            for record in data['results']:
                assert record['exit_codes'] == [0] and len(record['times']) == 1
                value = record['times'][0]
                assert type(value) in (int, float) and math.isfinite(value) and value > 0
                values[record['command'].split(' ', 1)[0]] = value
            parent.append(values['parent'])
            candidate.append(values['candidate'])
            differences.append(values['parent'] - values['candidate'])
        interval = bootstrap(differences)
        rows[workload] = {'pairs': required, 'parent_median': standard_statistics.median(parent),
            'candidate_median': standard_statistics.median(candidate),
            'paired_mean_saving': standard_statistics.mean(differences), 'paired_mean_saving_95_interval': interval,
            'candidate_faster_pairs': sum(value > 0 for value in differences),
            'parent_min': min(parent), 'parent_max': max(parent), 'candidate_min': min(candidate), 'candidate_max': max(candidate),
            'conclusion': 'saving' if interval[0] > 0 else 'loss' if interval[1] < 0 else 'inconclusive'}
    report = {'phase': phase, 'rows': rows, 'pairs': sum(row['pairs'] for row in rows.values()),
              'admissions': len(trace), 'seed': 864, 'resamples': 20000,
              'discarded_samples': 0, 'measurement_reruns': 0, 'verified': True}
    if phase == 'screen':
        report['additional_adverse_workloads'] = [name for name, row in rows.items()
            if row['conclusion'] == 'loss' and name not in protocol['independent_regression_workloads']
            and name != protocol['independent_target']]
    (root / (phase + '-statistics.json')).write_text(json.dumps(report, indent=2) + '\n')
    return report

if __name__ == '__main__':
    phase = sys.argv[1]
    report = validate_phase(phase)
    print(json.dumps(report), flush=True)
