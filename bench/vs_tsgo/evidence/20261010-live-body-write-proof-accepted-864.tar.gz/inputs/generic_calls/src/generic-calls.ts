interface Entity<N extends number> {
  readonly id: N;
  readonly label: `entity-${N}`;
  readonly active: boolean;
}

type PickFields<T, K extends keyof T> = { readonly [P in K]: T[P] };

declare function project<T, K extends readonly (keyof T)[]>(
  value: T,
  keys: K,
): PickFields<T, K[number]>;

declare function field<T, K extends keyof T>(value: T, key: K): T[K];

declare function transform<T, U>(value: T, mapper: (input: T) => U): U;

const entity0: Entity<0> = { id: 0, label: "entity-0", active: true };
const selected0 = project(entity0, ["id", "label"] as const);
const label0: `entity-0` = field(selected0, "label");
export const result0: PickFields<Entity<0>, "id" | "label"> = transform(
  selected0,
  value => ({ id: value.id, label: value.label }),
);

const entity1: Entity<1> = { id: 1, label: "entity-1", active: false };
const selected1 = project(entity1, ["id", "label"] as const);
const label1: `entity-1` = field(selected1, "label");
export const result1: PickFields<Entity<1>, "id" | "label"> = transform(
  selected1,
  value => ({ id: value.id, label: value.label }),
);

const entity2: Entity<2> = { id: 2, label: "entity-2", active: true };
const selected2 = project(entity2, ["id", "label"] as const);
const label2: `entity-2` = field(selected2, "label");
export const result2: PickFields<Entity<2>, "id" | "label"> = transform(
  selected2,
  value => ({ id: value.id, label: value.label }),
);

const entity3: Entity<3> = { id: 3, label: "entity-3", active: false };
const selected3 = project(entity3, ["id", "label"] as const);
const label3: `entity-3` = field(selected3, "label");
export const result3: PickFields<Entity<3>, "id" | "label"> = transform(
  selected3,
  value => ({ id: value.id, label: value.label }),
);

const entity4: Entity<4> = { id: 4, label: "entity-4", active: true };
const selected4 = project(entity4, ["id", "label"] as const);
const label4: `entity-4` = field(selected4, "label");
export const result4: PickFields<Entity<4>, "id" | "label"> = transform(
  selected4,
  value => ({ id: value.id, label: value.label }),
);

const entity5: Entity<5> = { id: 5, label: "entity-5", active: false };
const selected5 = project(entity5, ["id", "label"] as const);
const label5: `entity-5` = field(selected5, "label");
export const result5: PickFields<Entity<5>, "id" | "label"> = transform(
  selected5,
  value => ({ id: value.id, label: value.label }),
);

const entity6: Entity<6> = { id: 6, label: "entity-6", active: true };
const selected6 = project(entity6, ["id", "label"] as const);
const label6: `entity-6` = field(selected6, "label");
export const result6: PickFields<Entity<6>, "id" | "label"> = transform(
  selected6,
  value => ({ id: value.id, label: value.label }),
);

const entity7: Entity<7> = { id: 7, label: "entity-7", active: false };
const selected7 = project(entity7, ["id", "label"] as const);
const label7: `entity-7` = field(selected7, "label");
export const result7: PickFields<Entity<7>, "id" | "label"> = transform(
  selected7,
  value => ({ id: value.id, label: value.label }),
);

const entity8: Entity<8> = { id: 8, label: "entity-8", active: true };
const selected8 = project(entity8, ["id", "label"] as const);
const label8: `entity-8` = field(selected8, "label");
export const result8: PickFields<Entity<8>, "id" | "label"> = transform(
  selected8,
  value => ({ id: value.id, label: value.label }),
);

const entity9: Entity<9> = { id: 9, label: "entity-9", active: false };
const selected9 = project(entity9, ["id", "label"] as const);
const label9: `entity-9` = field(selected9, "label");
export const result9: PickFields<Entity<9>, "id" | "label"> = transform(
  selected9,
  value => ({ id: value.id, label: value.label }),
);

const entity10: Entity<10> = { id: 10, label: "entity-10", active: true };
const selected10 = project(entity10, ["id", "label"] as const);
const label10: `entity-10` = field(selected10, "label");
export const result10: PickFields<Entity<10>, "id" | "label"> = transform(
  selected10,
  value => ({ id: value.id, label: value.label }),
);

const entity11: Entity<11> = { id: 11, label: "entity-11", active: false };
const selected11 = project(entity11, ["id", "label"] as const);
const label11: `entity-11` = field(selected11, "label");
export const result11: PickFields<Entity<11>, "id" | "label"> = transform(
  selected11,
  value => ({ id: value.id, label: value.label }),
);

const entity12: Entity<12> = { id: 12, label: "entity-12", active: true };
const selected12 = project(entity12, ["id", "label"] as const);
const label12: `entity-12` = field(selected12, "label");
export const result12: PickFields<Entity<12>, "id" | "label"> = transform(
  selected12,
  value => ({ id: value.id, label: value.label }),
);

const entity13: Entity<13> = { id: 13, label: "entity-13", active: false };
const selected13 = project(entity13, ["id", "label"] as const);
const label13: `entity-13` = field(selected13, "label");
export const result13: PickFields<Entity<13>, "id" | "label"> = transform(
  selected13,
  value => ({ id: value.id, label: value.label }),
);

const entity14: Entity<14> = { id: 14, label: "entity-14", active: true };
const selected14 = project(entity14, ["id", "label"] as const);
const label14: `entity-14` = field(selected14, "label");
export const result14: PickFields<Entity<14>, "id" | "label"> = transform(
  selected14,
  value => ({ id: value.id, label: value.label }),
);

const entity15: Entity<15> = { id: 15, label: "entity-15", active: false };
const selected15 = project(entity15, ["id", "label"] as const);
const label15: `entity-15` = field(selected15, "label");
export const result15: PickFields<Entity<15>, "id" | "label"> = transform(
  selected15,
  value => ({ id: value.id, label: value.label }),
);

const entity16: Entity<16> = { id: 16, label: "entity-16", active: true };
const selected16 = project(entity16, ["id", "label"] as const);
const label16: `entity-16` = field(selected16, "label");
export const result16: PickFields<Entity<16>, "id" | "label"> = transform(
  selected16,
  value => ({ id: value.id, label: value.label }),
);

const entity17: Entity<17> = { id: 17, label: "entity-17", active: false };
const selected17 = project(entity17, ["id", "label"] as const);
const label17: `entity-17` = field(selected17, "label");
export const result17: PickFields<Entity<17>, "id" | "label"> = transform(
  selected17,
  value => ({ id: value.id, label: value.label }),
);

const entity18: Entity<18> = { id: 18, label: "entity-18", active: true };
const selected18 = project(entity18, ["id", "label"] as const);
const label18: `entity-18` = field(selected18, "label");
export const result18: PickFields<Entity<18>, "id" | "label"> = transform(
  selected18,
  value => ({ id: value.id, label: value.label }),
);

const entity19: Entity<19> = { id: 19, label: "entity-19", active: false };
const selected19 = project(entity19, ["id", "label"] as const);
const label19: `entity-19` = field(selected19, "label");
export const result19: PickFields<Entity<19>, "id" | "label"> = transform(
  selected19,
  value => ({ id: value.id, label: value.label }),
);

const entity20: Entity<20> = { id: 20, label: "entity-20", active: true };
const selected20 = project(entity20, ["id", "label"] as const);
const label20: `entity-20` = field(selected20, "label");
export const result20: PickFields<Entity<20>, "id" | "label"> = transform(
  selected20,
  value => ({ id: value.id, label: value.label }),
);

const entity21: Entity<21> = { id: 21, label: "entity-21", active: false };
const selected21 = project(entity21, ["id", "label"] as const);
const label21: `entity-21` = field(selected21, "label");
export const result21: PickFields<Entity<21>, "id" | "label"> = transform(
  selected21,
  value => ({ id: value.id, label: value.label }),
);

const entity22: Entity<22> = { id: 22, label: "entity-22", active: true };
const selected22 = project(entity22, ["id", "label"] as const);
const label22: `entity-22` = field(selected22, "label");
export const result22: PickFields<Entity<22>, "id" | "label"> = transform(
  selected22,
  value => ({ id: value.id, label: value.label }),
);

const entity23: Entity<23> = { id: 23, label: "entity-23", active: false };
const selected23 = project(entity23, ["id", "label"] as const);
const label23: `entity-23` = field(selected23, "label");
export const result23: PickFields<Entity<23>, "id" | "label"> = transform(
  selected23,
  value => ({ id: value.id, label: value.label }),
);

const entity24: Entity<24> = { id: 24, label: "entity-24", active: true };
const selected24 = project(entity24, ["id", "label"] as const);
const label24: `entity-24` = field(selected24, "label");
export const result24: PickFields<Entity<24>, "id" | "label"> = transform(
  selected24,
  value => ({ id: value.id, label: value.label }),
);

const entity25: Entity<25> = { id: 25, label: "entity-25", active: false };
const selected25 = project(entity25, ["id", "label"] as const);
const label25: `entity-25` = field(selected25, "label");
export const result25: PickFields<Entity<25>, "id" | "label"> = transform(
  selected25,
  value => ({ id: value.id, label: value.label }),
);

const entity26: Entity<26> = { id: 26, label: "entity-26", active: true };
const selected26 = project(entity26, ["id", "label"] as const);
const label26: `entity-26` = field(selected26, "label");
export const result26: PickFields<Entity<26>, "id" | "label"> = transform(
  selected26,
  value => ({ id: value.id, label: value.label }),
);

const entity27: Entity<27> = { id: 27, label: "entity-27", active: false };
const selected27 = project(entity27, ["id", "label"] as const);
const label27: `entity-27` = field(selected27, "label");
export const result27: PickFields<Entity<27>, "id" | "label"> = transform(
  selected27,
  value => ({ id: value.id, label: value.label }),
);

const entity28: Entity<28> = { id: 28, label: "entity-28", active: true };
const selected28 = project(entity28, ["id", "label"] as const);
const label28: `entity-28` = field(selected28, "label");
export const result28: PickFields<Entity<28>, "id" | "label"> = transform(
  selected28,
  value => ({ id: value.id, label: value.label }),
);

const entity29: Entity<29> = { id: 29, label: "entity-29", active: false };
const selected29 = project(entity29, ["id", "label"] as const);
const label29: `entity-29` = field(selected29, "label");
export const result29: PickFields<Entity<29>, "id" | "label"> = transform(
  selected29,
  value => ({ id: value.id, label: value.label }),
);

const entity30: Entity<30> = { id: 30, label: "entity-30", active: true };
const selected30 = project(entity30, ["id", "label"] as const);
const label30: `entity-30` = field(selected30, "label");
export const result30: PickFields<Entity<30>, "id" | "label"> = transform(
  selected30,
  value => ({ id: value.id, label: value.label }),
);

const entity31: Entity<31> = { id: 31, label: "entity-31", active: false };
const selected31 = project(entity31, ["id", "label"] as const);
const label31: `entity-31` = field(selected31, "label");
export const result31: PickFields<Entity<31>, "id" | "label"> = transform(
  selected31,
  value => ({ id: value.id, label: value.label }),
);

const entity32: Entity<32> = { id: 32, label: "entity-32", active: true };
const selected32 = project(entity32, ["id", "label"] as const);
const label32: `entity-32` = field(selected32, "label");
export const result32: PickFields<Entity<32>, "id" | "label"> = transform(
  selected32,
  value => ({ id: value.id, label: value.label }),
);

const entity33: Entity<33> = { id: 33, label: "entity-33", active: false };
const selected33 = project(entity33, ["id", "label"] as const);
const label33: `entity-33` = field(selected33, "label");
export const result33: PickFields<Entity<33>, "id" | "label"> = transform(
  selected33,
  value => ({ id: value.id, label: value.label }),
);

const entity34: Entity<34> = { id: 34, label: "entity-34", active: true };
const selected34 = project(entity34, ["id", "label"] as const);
const label34: `entity-34` = field(selected34, "label");
export const result34: PickFields<Entity<34>, "id" | "label"> = transform(
  selected34,
  value => ({ id: value.id, label: value.label }),
);

const entity35: Entity<35> = { id: 35, label: "entity-35", active: false };
const selected35 = project(entity35, ["id", "label"] as const);
const label35: `entity-35` = field(selected35, "label");
export const result35: PickFields<Entity<35>, "id" | "label"> = transform(
  selected35,
  value => ({ id: value.id, label: value.label }),
);

const entity36: Entity<36> = { id: 36, label: "entity-36", active: true };
const selected36 = project(entity36, ["id", "label"] as const);
const label36: `entity-36` = field(selected36, "label");
export const result36: PickFields<Entity<36>, "id" | "label"> = transform(
  selected36,
  value => ({ id: value.id, label: value.label }),
);

const entity37: Entity<37> = { id: 37, label: "entity-37", active: false };
const selected37 = project(entity37, ["id", "label"] as const);
const label37: `entity-37` = field(selected37, "label");
export const result37: PickFields<Entity<37>, "id" | "label"> = transform(
  selected37,
  value => ({ id: value.id, label: value.label }),
);

const entity38: Entity<38> = { id: 38, label: "entity-38", active: true };
const selected38 = project(entity38, ["id", "label"] as const);
const label38: `entity-38` = field(selected38, "label");
export const result38: PickFields<Entity<38>, "id" | "label"> = transform(
  selected38,
  value => ({ id: value.id, label: value.label }),
);

const entity39: Entity<39> = { id: 39, label: "entity-39", active: false };
const selected39 = project(entity39, ["id", "label"] as const);
const label39: `entity-39` = field(selected39, "label");
export const result39: PickFields<Entity<39>, "id" | "label"> = transform(
  selected39,
  value => ({ id: value.id, label: value.label }),
);

const entity40: Entity<40> = { id: 40, label: "entity-40", active: true };
const selected40 = project(entity40, ["id", "label"] as const);
const label40: `entity-40` = field(selected40, "label");
export const result40: PickFields<Entity<40>, "id" | "label"> = transform(
  selected40,
  value => ({ id: value.id, label: value.label }),
);

const entity41: Entity<41> = { id: 41, label: "entity-41", active: false };
const selected41 = project(entity41, ["id", "label"] as const);
const label41: `entity-41` = field(selected41, "label");
export const result41: PickFields<Entity<41>, "id" | "label"> = transform(
  selected41,
  value => ({ id: value.id, label: value.label }),
);

const entity42: Entity<42> = { id: 42, label: "entity-42", active: true };
const selected42 = project(entity42, ["id", "label"] as const);
const label42: `entity-42` = field(selected42, "label");
export const result42: PickFields<Entity<42>, "id" | "label"> = transform(
  selected42,
  value => ({ id: value.id, label: value.label }),
);

const entity43: Entity<43> = { id: 43, label: "entity-43", active: false };
const selected43 = project(entity43, ["id", "label"] as const);
const label43: `entity-43` = field(selected43, "label");
export const result43: PickFields<Entity<43>, "id" | "label"> = transform(
  selected43,
  value => ({ id: value.id, label: value.label }),
);

const entity44: Entity<44> = { id: 44, label: "entity-44", active: true };
const selected44 = project(entity44, ["id", "label"] as const);
const label44: `entity-44` = field(selected44, "label");
export const result44: PickFields<Entity<44>, "id" | "label"> = transform(
  selected44,
  value => ({ id: value.id, label: value.label }),
);

const entity45: Entity<45> = { id: 45, label: "entity-45", active: false };
const selected45 = project(entity45, ["id", "label"] as const);
const label45: `entity-45` = field(selected45, "label");
export const result45: PickFields<Entity<45>, "id" | "label"> = transform(
  selected45,
  value => ({ id: value.id, label: value.label }),
);

const entity46: Entity<46> = { id: 46, label: "entity-46", active: true };
const selected46 = project(entity46, ["id", "label"] as const);
const label46: `entity-46` = field(selected46, "label");
export const result46: PickFields<Entity<46>, "id" | "label"> = transform(
  selected46,
  value => ({ id: value.id, label: value.label }),
);

const entity47: Entity<47> = { id: 47, label: "entity-47", active: false };
const selected47 = project(entity47, ["id", "label"] as const);
const label47: `entity-47` = field(selected47, "label");
export const result47: PickFields<Entity<47>, "id" | "label"> = transform(
  selected47,
  value => ({ id: value.id, label: value.label }),
);

const entity48: Entity<48> = { id: 48, label: "entity-48", active: true };
const selected48 = project(entity48, ["id", "label"] as const);
const label48: `entity-48` = field(selected48, "label");
export const result48: PickFields<Entity<48>, "id" | "label"> = transform(
  selected48,
  value => ({ id: value.id, label: value.label }),
);

const entity49: Entity<49> = { id: 49, label: "entity-49", active: false };
const selected49 = project(entity49, ["id", "label"] as const);
const label49: `entity-49` = field(selected49, "label");
export const result49: PickFields<Entity<49>, "id" | "label"> = transform(
  selected49,
  value => ({ id: value.id, label: value.label }),
);

const entity50: Entity<50> = { id: 50, label: "entity-50", active: true };
const selected50 = project(entity50, ["id", "label"] as const);
const label50: `entity-50` = field(selected50, "label");
export const result50: PickFields<Entity<50>, "id" | "label"> = transform(
  selected50,
  value => ({ id: value.id, label: value.label }),
);

const entity51: Entity<51> = { id: 51, label: "entity-51", active: false };
const selected51 = project(entity51, ["id", "label"] as const);
const label51: `entity-51` = field(selected51, "label");
export const result51: PickFields<Entity<51>, "id" | "label"> = transform(
  selected51,
  value => ({ id: value.id, label: value.label }),
);

const entity52: Entity<52> = { id: 52, label: "entity-52", active: true };
const selected52 = project(entity52, ["id", "label"] as const);
const label52: `entity-52` = field(selected52, "label");
export const result52: PickFields<Entity<52>, "id" | "label"> = transform(
  selected52,
  value => ({ id: value.id, label: value.label }),
);

const entity53: Entity<53> = { id: 53, label: "entity-53", active: false };
const selected53 = project(entity53, ["id", "label"] as const);
const label53: `entity-53` = field(selected53, "label");
export const result53: PickFields<Entity<53>, "id" | "label"> = transform(
  selected53,
  value => ({ id: value.id, label: value.label }),
);

const entity54: Entity<54> = { id: 54, label: "entity-54", active: true };
const selected54 = project(entity54, ["id", "label"] as const);
const label54: `entity-54` = field(selected54, "label");
export const result54: PickFields<Entity<54>, "id" | "label"> = transform(
  selected54,
  value => ({ id: value.id, label: value.label }),
);

const entity55: Entity<55> = { id: 55, label: "entity-55", active: false };
const selected55 = project(entity55, ["id", "label"] as const);
const label55: `entity-55` = field(selected55, "label");
export const result55: PickFields<Entity<55>, "id" | "label"> = transform(
  selected55,
  value => ({ id: value.id, label: value.label }),
);

const entity56: Entity<56> = { id: 56, label: "entity-56", active: true };
const selected56 = project(entity56, ["id", "label"] as const);
const label56: `entity-56` = field(selected56, "label");
export const result56: PickFields<Entity<56>, "id" | "label"> = transform(
  selected56,
  value => ({ id: value.id, label: value.label }),
);

const entity57: Entity<57> = { id: 57, label: "entity-57", active: false };
const selected57 = project(entity57, ["id", "label"] as const);
const label57: `entity-57` = field(selected57, "label");
export const result57: PickFields<Entity<57>, "id" | "label"> = transform(
  selected57,
  value => ({ id: value.id, label: value.label }),
);

const entity58: Entity<58> = { id: 58, label: "entity-58", active: true };
const selected58 = project(entity58, ["id", "label"] as const);
const label58: `entity-58` = field(selected58, "label");
export const result58: PickFields<Entity<58>, "id" | "label"> = transform(
  selected58,
  value => ({ id: value.id, label: value.label }),
);

const entity59: Entity<59> = { id: 59, label: "entity-59", active: false };
const selected59 = project(entity59, ["id", "label"] as const);
const label59: `entity-59` = field(selected59, "label");
export const result59: PickFields<Entity<59>, "id" | "label"> = transform(
  selected59,
  value => ({ id: value.id, label: value.label }),
);

const entity60: Entity<60> = { id: 60, label: "entity-60", active: true };
const selected60 = project(entity60, ["id", "label"] as const);
const label60: `entity-60` = field(selected60, "label");
export const result60: PickFields<Entity<60>, "id" | "label"> = transform(
  selected60,
  value => ({ id: value.id, label: value.label }),
);

const entity61: Entity<61> = { id: 61, label: "entity-61", active: false };
const selected61 = project(entity61, ["id", "label"] as const);
const label61: `entity-61` = field(selected61, "label");
export const result61: PickFields<Entity<61>, "id" | "label"> = transform(
  selected61,
  value => ({ id: value.id, label: value.label }),
);

const entity62: Entity<62> = { id: 62, label: "entity-62", active: true };
const selected62 = project(entity62, ["id", "label"] as const);
const label62: `entity-62` = field(selected62, "label");
export const result62: PickFields<Entity<62>, "id" | "label"> = transform(
  selected62,
  value => ({ id: value.id, label: value.label }),
);

const entity63: Entity<63> = { id: 63, label: "entity-63", active: false };
const selected63 = project(entity63, ["id", "label"] as const);
const label63: `entity-63` = field(selected63, "label");
export const result63: PickFields<Entity<63>, "id" | "label"> = transform(
  selected63,
  value => ({ id: value.id, label: value.label }),
);

const entity64: Entity<64> = { id: 64, label: "entity-64", active: true };
const selected64 = project(entity64, ["id", "label"] as const);
const label64: `entity-64` = field(selected64, "label");
export const result64: PickFields<Entity<64>, "id" | "label"> = transform(
  selected64,
  value => ({ id: value.id, label: value.label }),
);

const entity65: Entity<65> = { id: 65, label: "entity-65", active: false };
const selected65 = project(entity65, ["id", "label"] as const);
const label65: `entity-65` = field(selected65, "label");
export const result65: PickFields<Entity<65>, "id" | "label"> = transform(
  selected65,
  value => ({ id: value.id, label: value.label }),
);

const entity66: Entity<66> = { id: 66, label: "entity-66", active: true };
const selected66 = project(entity66, ["id", "label"] as const);
const label66: `entity-66` = field(selected66, "label");
export const result66: PickFields<Entity<66>, "id" | "label"> = transform(
  selected66,
  value => ({ id: value.id, label: value.label }),
);

const entity67: Entity<67> = { id: 67, label: "entity-67", active: false };
const selected67 = project(entity67, ["id", "label"] as const);
const label67: `entity-67` = field(selected67, "label");
export const result67: PickFields<Entity<67>, "id" | "label"> = transform(
  selected67,
  value => ({ id: value.id, label: value.label }),
);

const entity68: Entity<68> = { id: 68, label: "entity-68", active: true };
const selected68 = project(entity68, ["id", "label"] as const);
const label68: `entity-68` = field(selected68, "label");
export const result68: PickFields<Entity<68>, "id" | "label"> = transform(
  selected68,
  value => ({ id: value.id, label: value.label }),
);

const entity69: Entity<69> = { id: 69, label: "entity-69", active: false };
const selected69 = project(entity69, ["id", "label"] as const);
const label69: `entity-69` = field(selected69, "label");
export const result69: PickFields<Entity<69>, "id" | "label"> = transform(
  selected69,
  value => ({ id: value.id, label: value.label }),
);

const entity70: Entity<70> = { id: 70, label: "entity-70", active: true };
const selected70 = project(entity70, ["id", "label"] as const);
const label70: `entity-70` = field(selected70, "label");
export const result70: PickFields<Entity<70>, "id" | "label"> = transform(
  selected70,
  value => ({ id: value.id, label: value.label }),
);

const entity71: Entity<71> = { id: 71, label: "entity-71", active: false };
const selected71 = project(entity71, ["id", "label"] as const);
const label71: `entity-71` = field(selected71, "label");
export const result71: PickFields<Entity<71>, "id" | "label"> = transform(
  selected71,
  value => ({ id: value.id, label: value.label }),
);

const entity72: Entity<72> = { id: 72, label: "entity-72", active: true };
const selected72 = project(entity72, ["id", "label"] as const);
const label72: `entity-72` = field(selected72, "label");
export const result72: PickFields<Entity<72>, "id" | "label"> = transform(
  selected72,
  value => ({ id: value.id, label: value.label }),
);

const entity73: Entity<73> = { id: 73, label: "entity-73", active: false };
const selected73 = project(entity73, ["id", "label"] as const);
const label73: `entity-73` = field(selected73, "label");
export const result73: PickFields<Entity<73>, "id" | "label"> = transform(
  selected73,
  value => ({ id: value.id, label: value.label }),
);

const entity74: Entity<74> = { id: 74, label: "entity-74", active: true };
const selected74 = project(entity74, ["id", "label"] as const);
const label74: `entity-74` = field(selected74, "label");
export const result74: PickFields<Entity<74>, "id" | "label"> = transform(
  selected74,
  value => ({ id: value.id, label: value.label }),
);

const entity75: Entity<75> = { id: 75, label: "entity-75", active: false };
const selected75 = project(entity75, ["id", "label"] as const);
const label75: `entity-75` = field(selected75, "label");
export const result75: PickFields<Entity<75>, "id" | "label"> = transform(
  selected75,
  value => ({ id: value.id, label: value.label }),
);

const entity76: Entity<76> = { id: 76, label: "entity-76", active: true };
const selected76 = project(entity76, ["id", "label"] as const);
const label76: `entity-76` = field(selected76, "label");
export const result76: PickFields<Entity<76>, "id" | "label"> = transform(
  selected76,
  value => ({ id: value.id, label: value.label }),
);

const entity77: Entity<77> = { id: 77, label: "entity-77", active: false };
const selected77 = project(entity77, ["id", "label"] as const);
const label77: `entity-77` = field(selected77, "label");
export const result77: PickFields<Entity<77>, "id" | "label"> = transform(
  selected77,
  value => ({ id: value.id, label: value.label }),
);

const entity78: Entity<78> = { id: 78, label: "entity-78", active: true };
const selected78 = project(entity78, ["id", "label"] as const);
const label78: `entity-78` = field(selected78, "label");
export const result78: PickFields<Entity<78>, "id" | "label"> = transform(
  selected78,
  value => ({ id: value.id, label: value.label }),
);

const entity79: Entity<79> = { id: 79, label: "entity-79", active: false };
const selected79 = project(entity79, ["id", "label"] as const);
const label79: `entity-79` = field(selected79, "label");
export const result79: PickFields<Entity<79>, "id" | "label"> = transform(
  selected79,
  value => ({ id: value.id, label: value.label }),
);

const entity80: Entity<80> = { id: 80, label: "entity-80", active: true };
const selected80 = project(entity80, ["id", "label"] as const);
const label80: `entity-80` = field(selected80, "label");
export const result80: PickFields<Entity<80>, "id" | "label"> = transform(
  selected80,
  value => ({ id: value.id, label: value.label }),
);

const entity81: Entity<81> = { id: 81, label: "entity-81", active: false };
const selected81 = project(entity81, ["id", "label"] as const);
const label81: `entity-81` = field(selected81, "label");
export const result81: PickFields<Entity<81>, "id" | "label"> = transform(
  selected81,
  value => ({ id: value.id, label: value.label }),
);

const entity82: Entity<82> = { id: 82, label: "entity-82", active: true };
const selected82 = project(entity82, ["id", "label"] as const);
const label82: `entity-82` = field(selected82, "label");
export const result82: PickFields<Entity<82>, "id" | "label"> = transform(
  selected82,
  value => ({ id: value.id, label: value.label }),
);

const entity83: Entity<83> = { id: 83, label: "entity-83", active: false };
const selected83 = project(entity83, ["id", "label"] as const);
const label83: `entity-83` = field(selected83, "label");
export const result83: PickFields<Entity<83>, "id" | "label"> = transform(
  selected83,
  value => ({ id: value.id, label: value.label }),
);

const entity84: Entity<84> = { id: 84, label: "entity-84", active: true };
const selected84 = project(entity84, ["id", "label"] as const);
const label84: `entity-84` = field(selected84, "label");
export const result84: PickFields<Entity<84>, "id" | "label"> = transform(
  selected84,
  value => ({ id: value.id, label: value.label }),
);

const entity85: Entity<85> = { id: 85, label: "entity-85", active: false };
const selected85 = project(entity85, ["id", "label"] as const);
const label85: `entity-85` = field(selected85, "label");
export const result85: PickFields<Entity<85>, "id" | "label"> = transform(
  selected85,
  value => ({ id: value.id, label: value.label }),
);

const entity86: Entity<86> = { id: 86, label: "entity-86", active: true };
const selected86 = project(entity86, ["id", "label"] as const);
const label86: `entity-86` = field(selected86, "label");
export const result86: PickFields<Entity<86>, "id" | "label"> = transform(
  selected86,
  value => ({ id: value.id, label: value.label }),
);

const entity87: Entity<87> = { id: 87, label: "entity-87", active: false };
const selected87 = project(entity87, ["id", "label"] as const);
const label87: `entity-87` = field(selected87, "label");
export const result87: PickFields<Entity<87>, "id" | "label"> = transform(
  selected87,
  value => ({ id: value.id, label: value.label }),
);

const entity88: Entity<88> = { id: 88, label: "entity-88", active: true };
const selected88 = project(entity88, ["id", "label"] as const);
const label88: `entity-88` = field(selected88, "label");
export const result88: PickFields<Entity<88>, "id" | "label"> = transform(
  selected88,
  value => ({ id: value.id, label: value.label }),
);

const entity89: Entity<89> = { id: 89, label: "entity-89", active: false };
const selected89 = project(entity89, ["id", "label"] as const);
const label89: `entity-89` = field(selected89, "label");
export const result89: PickFields<Entity<89>, "id" | "label"> = transform(
  selected89,
  value => ({ id: value.id, label: value.label }),
);

const entity90: Entity<90> = { id: 90, label: "entity-90", active: true };
const selected90 = project(entity90, ["id", "label"] as const);
const label90: `entity-90` = field(selected90, "label");
export const result90: PickFields<Entity<90>, "id" | "label"> = transform(
  selected90,
  value => ({ id: value.id, label: value.label }),
);

const entity91: Entity<91> = { id: 91, label: "entity-91", active: false };
const selected91 = project(entity91, ["id", "label"] as const);
const label91: `entity-91` = field(selected91, "label");
export const result91: PickFields<Entity<91>, "id" | "label"> = transform(
  selected91,
  value => ({ id: value.id, label: value.label }),
);

const entity92: Entity<92> = { id: 92, label: "entity-92", active: true };
const selected92 = project(entity92, ["id", "label"] as const);
const label92: `entity-92` = field(selected92, "label");
export const result92: PickFields<Entity<92>, "id" | "label"> = transform(
  selected92,
  value => ({ id: value.id, label: value.label }),
);

const entity93: Entity<93> = { id: 93, label: "entity-93", active: false };
const selected93 = project(entity93, ["id", "label"] as const);
const label93: `entity-93` = field(selected93, "label");
export const result93: PickFields<Entity<93>, "id" | "label"> = transform(
  selected93,
  value => ({ id: value.id, label: value.label }),
);

const entity94: Entity<94> = { id: 94, label: "entity-94", active: true };
const selected94 = project(entity94, ["id", "label"] as const);
const label94: `entity-94` = field(selected94, "label");
export const result94: PickFields<Entity<94>, "id" | "label"> = transform(
  selected94,
  value => ({ id: value.id, label: value.label }),
);

const entity95: Entity<95> = { id: 95, label: "entity-95", active: false };
const selected95 = project(entity95, ["id", "label"] as const);
const label95: `entity-95` = field(selected95, "label");
export const result95: PickFields<Entity<95>, "id" | "label"> = transform(
  selected95,
  value => ({ id: value.id, label: value.label }),
);

const entity96: Entity<96> = { id: 96, label: "entity-96", active: true };
const selected96 = project(entity96, ["id", "label"] as const);
const label96: `entity-96` = field(selected96, "label");
export const result96: PickFields<Entity<96>, "id" | "label"> = transform(
  selected96,
  value => ({ id: value.id, label: value.label }),
);

const entity97: Entity<97> = { id: 97, label: "entity-97", active: false };
const selected97 = project(entity97, ["id", "label"] as const);
const label97: `entity-97` = field(selected97, "label");
export const result97: PickFields<Entity<97>, "id" | "label"> = transform(
  selected97,
  value => ({ id: value.id, label: value.label }),
);

const entity98: Entity<98> = { id: 98, label: "entity-98", active: true };
const selected98 = project(entity98, ["id", "label"] as const);
const label98: `entity-98` = field(selected98, "label");
export const result98: PickFields<Entity<98>, "id" | "label"> = transform(
  selected98,
  value => ({ id: value.id, label: value.label }),
);

const entity99: Entity<99> = { id: 99, label: "entity-99", active: false };
const selected99 = project(entity99, ["id", "label"] as const);
const label99: `entity-99` = field(selected99, "label");
export const result99: PickFields<Entity<99>, "id" | "label"> = transform(
  selected99,
  value => ({ id: value.id, label: value.label }),
);

const entity100: Entity<100> = { id: 100, label: "entity-100", active: true };
const selected100 = project(entity100, ["id", "label"] as const);
const label100: `entity-100` = field(selected100, "label");
export const result100: PickFields<Entity<100>, "id" | "label"> = transform(
  selected100,
  value => ({ id: value.id, label: value.label }),
);

const entity101: Entity<101> = { id: 101, label: "entity-101", active: false };
const selected101 = project(entity101, ["id", "label"] as const);
const label101: `entity-101` = field(selected101, "label");
export const result101: PickFields<Entity<101>, "id" | "label"> = transform(
  selected101,
  value => ({ id: value.id, label: value.label }),
);

const entity102: Entity<102> = { id: 102, label: "entity-102", active: true };
const selected102 = project(entity102, ["id", "label"] as const);
const label102: `entity-102` = field(selected102, "label");
export const result102: PickFields<Entity<102>, "id" | "label"> = transform(
  selected102,
  value => ({ id: value.id, label: value.label }),
);

const entity103: Entity<103> = { id: 103, label: "entity-103", active: false };
const selected103 = project(entity103, ["id", "label"] as const);
const label103: `entity-103` = field(selected103, "label");
export const result103: PickFields<Entity<103>, "id" | "label"> = transform(
  selected103,
  value => ({ id: value.id, label: value.label }),
);

const entity104: Entity<104> = { id: 104, label: "entity-104", active: true };
const selected104 = project(entity104, ["id", "label"] as const);
const label104: `entity-104` = field(selected104, "label");
export const result104: PickFields<Entity<104>, "id" | "label"> = transform(
  selected104,
  value => ({ id: value.id, label: value.label }),
);

const entity105: Entity<105> = { id: 105, label: "entity-105", active: false };
const selected105 = project(entity105, ["id", "label"] as const);
const label105: `entity-105` = field(selected105, "label");
export const result105: PickFields<Entity<105>, "id" | "label"> = transform(
  selected105,
  value => ({ id: value.id, label: value.label }),
);

const entity106: Entity<106> = { id: 106, label: "entity-106", active: true };
const selected106 = project(entity106, ["id", "label"] as const);
const label106: `entity-106` = field(selected106, "label");
export const result106: PickFields<Entity<106>, "id" | "label"> = transform(
  selected106,
  value => ({ id: value.id, label: value.label }),
);

const entity107: Entity<107> = { id: 107, label: "entity-107", active: false };
const selected107 = project(entity107, ["id", "label"] as const);
const label107: `entity-107` = field(selected107, "label");
export const result107: PickFields<Entity<107>, "id" | "label"> = transform(
  selected107,
  value => ({ id: value.id, label: value.label }),
);

const entity108: Entity<108> = { id: 108, label: "entity-108", active: true };
const selected108 = project(entity108, ["id", "label"] as const);
const label108: `entity-108` = field(selected108, "label");
export const result108: PickFields<Entity<108>, "id" | "label"> = transform(
  selected108,
  value => ({ id: value.id, label: value.label }),
);

const entity109: Entity<109> = { id: 109, label: "entity-109", active: false };
const selected109 = project(entity109, ["id", "label"] as const);
const label109: `entity-109` = field(selected109, "label");
export const result109: PickFields<Entity<109>, "id" | "label"> = transform(
  selected109,
  value => ({ id: value.id, label: value.label }),
);

const entity110: Entity<110> = { id: 110, label: "entity-110", active: true };
const selected110 = project(entity110, ["id", "label"] as const);
const label110: `entity-110` = field(selected110, "label");
export const result110: PickFields<Entity<110>, "id" | "label"> = transform(
  selected110,
  value => ({ id: value.id, label: value.label }),
);

const entity111: Entity<111> = { id: 111, label: "entity-111", active: false };
const selected111 = project(entity111, ["id", "label"] as const);
const label111: `entity-111` = field(selected111, "label");
export const result111: PickFields<Entity<111>, "id" | "label"> = transform(
  selected111,
  value => ({ id: value.id, label: value.label }),
);

const entity112: Entity<112> = { id: 112, label: "entity-112", active: true };
const selected112 = project(entity112, ["id", "label"] as const);
const label112: `entity-112` = field(selected112, "label");
export const result112: PickFields<Entity<112>, "id" | "label"> = transform(
  selected112,
  value => ({ id: value.id, label: value.label }),
);

const entity113: Entity<113> = { id: 113, label: "entity-113", active: false };
const selected113 = project(entity113, ["id", "label"] as const);
const label113: `entity-113` = field(selected113, "label");
export const result113: PickFields<Entity<113>, "id" | "label"> = transform(
  selected113,
  value => ({ id: value.id, label: value.label }),
);

const entity114: Entity<114> = { id: 114, label: "entity-114", active: true };
const selected114 = project(entity114, ["id", "label"] as const);
const label114: `entity-114` = field(selected114, "label");
export const result114: PickFields<Entity<114>, "id" | "label"> = transform(
  selected114,
  value => ({ id: value.id, label: value.label }),
);

const entity115: Entity<115> = { id: 115, label: "entity-115", active: false };
const selected115 = project(entity115, ["id", "label"] as const);
const label115: `entity-115` = field(selected115, "label");
export const result115: PickFields<Entity<115>, "id" | "label"> = transform(
  selected115,
  value => ({ id: value.id, label: value.label }),
);

const entity116: Entity<116> = { id: 116, label: "entity-116", active: true };
const selected116 = project(entity116, ["id", "label"] as const);
const label116: `entity-116` = field(selected116, "label");
export const result116: PickFields<Entity<116>, "id" | "label"> = transform(
  selected116,
  value => ({ id: value.id, label: value.label }),
);

const entity117: Entity<117> = { id: 117, label: "entity-117", active: false };
const selected117 = project(entity117, ["id", "label"] as const);
const label117: `entity-117` = field(selected117, "label");
export const result117: PickFields<Entity<117>, "id" | "label"> = transform(
  selected117,
  value => ({ id: value.id, label: value.label }),
);

const entity118: Entity<118> = { id: 118, label: "entity-118", active: true };
const selected118 = project(entity118, ["id", "label"] as const);
const label118: `entity-118` = field(selected118, "label");
export const result118: PickFields<Entity<118>, "id" | "label"> = transform(
  selected118,
  value => ({ id: value.id, label: value.label }),
);

const entity119: Entity<119> = { id: 119, label: "entity-119", active: false };
const selected119 = project(entity119, ["id", "label"] as const);
const label119: `entity-119` = field(selected119, "label");
export const result119: PickFields<Entity<119>, "id" | "label"> = transform(
  selected119,
  value => ({ id: value.id, label: value.label }),
);

const entity120: Entity<120> = { id: 120, label: "entity-120", active: true };
const selected120 = project(entity120, ["id", "label"] as const);
const label120: `entity-120` = field(selected120, "label");
export const result120: PickFields<Entity<120>, "id" | "label"> = transform(
  selected120,
  value => ({ id: value.id, label: value.label }),
);

const entity121: Entity<121> = { id: 121, label: "entity-121", active: false };
const selected121 = project(entity121, ["id", "label"] as const);
const label121: `entity-121` = field(selected121, "label");
export const result121: PickFields<Entity<121>, "id" | "label"> = transform(
  selected121,
  value => ({ id: value.id, label: value.label }),
);

const entity122: Entity<122> = { id: 122, label: "entity-122", active: true };
const selected122 = project(entity122, ["id", "label"] as const);
const label122: `entity-122` = field(selected122, "label");
export const result122: PickFields<Entity<122>, "id" | "label"> = transform(
  selected122,
  value => ({ id: value.id, label: value.label }),
);

const entity123: Entity<123> = { id: 123, label: "entity-123", active: false };
const selected123 = project(entity123, ["id", "label"] as const);
const label123: `entity-123` = field(selected123, "label");
export const result123: PickFields<Entity<123>, "id" | "label"> = transform(
  selected123,
  value => ({ id: value.id, label: value.label }),
);

const entity124: Entity<124> = { id: 124, label: "entity-124", active: true };
const selected124 = project(entity124, ["id", "label"] as const);
const label124: `entity-124` = field(selected124, "label");
export const result124: PickFields<Entity<124>, "id" | "label"> = transform(
  selected124,
  value => ({ id: value.id, label: value.label }),
);

const entity125: Entity<125> = { id: 125, label: "entity-125", active: false };
const selected125 = project(entity125, ["id", "label"] as const);
const label125: `entity-125` = field(selected125, "label");
export const result125: PickFields<Entity<125>, "id" | "label"> = transform(
  selected125,
  value => ({ id: value.id, label: value.label }),
);

const entity126: Entity<126> = { id: 126, label: "entity-126", active: true };
const selected126 = project(entity126, ["id", "label"] as const);
const label126: `entity-126` = field(selected126, "label");
export const result126: PickFields<Entity<126>, "id" | "label"> = transform(
  selected126,
  value => ({ id: value.id, label: value.label }),
);

const entity127: Entity<127> = { id: 127, label: "entity-127", active: false };
const selected127 = project(entity127, ["id", "label"] as const);
const label127: `entity-127` = field(selected127, "label");
export const result127: PickFields<Entity<127>, "id" | "label"> = transform(
  selected127,
  value => ({ id: value.id, label: value.label }),
);

const entity128: Entity<128> = { id: 128, label: "entity-128", active: true };
const selected128 = project(entity128, ["id", "label"] as const);
const label128: `entity-128` = field(selected128, "label");
export const result128: PickFields<Entity<128>, "id" | "label"> = transform(
  selected128,
  value => ({ id: value.id, label: value.label }),
);

const entity129: Entity<129> = { id: 129, label: "entity-129", active: false };
const selected129 = project(entity129, ["id", "label"] as const);
const label129: `entity-129` = field(selected129, "label");
export const result129: PickFields<Entity<129>, "id" | "label"> = transform(
  selected129,
  value => ({ id: value.id, label: value.label }),
);

const entity130: Entity<130> = { id: 130, label: "entity-130", active: true };
const selected130 = project(entity130, ["id", "label"] as const);
const label130: `entity-130` = field(selected130, "label");
export const result130: PickFields<Entity<130>, "id" | "label"> = transform(
  selected130,
  value => ({ id: value.id, label: value.label }),
);

const entity131: Entity<131> = { id: 131, label: "entity-131", active: false };
const selected131 = project(entity131, ["id", "label"] as const);
const label131: `entity-131` = field(selected131, "label");
export const result131: PickFields<Entity<131>, "id" | "label"> = transform(
  selected131,
  value => ({ id: value.id, label: value.label }),
);

const entity132: Entity<132> = { id: 132, label: "entity-132", active: true };
const selected132 = project(entity132, ["id", "label"] as const);
const label132: `entity-132` = field(selected132, "label");
export const result132: PickFields<Entity<132>, "id" | "label"> = transform(
  selected132,
  value => ({ id: value.id, label: value.label }),
);

const entity133: Entity<133> = { id: 133, label: "entity-133", active: false };
const selected133 = project(entity133, ["id", "label"] as const);
const label133: `entity-133` = field(selected133, "label");
export const result133: PickFields<Entity<133>, "id" | "label"> = transform(
  selected133,
  value => ({ id: value.id, label: value.label }),
);

const entity134: Entity<134> = { id: 134, label: "entity-134", active: true };
const selected134 = project(entity134, ["id", "label"] as const);
const label134: `entity-134` = field(selected134, "label");
export const result134: PickFields<Entity<134>, "id" | "label"> = transform(
  selected134,
  value => ({ id: value.id, label: value.label }),
);

const entity135: Entity<135> = { id: 135, label: "entity-135", active: false };
const selected135 = project(entity135, ["id", "label"] as const);
const label135: `entity-135` = field(selected135, "label");
export const result135: PickFields<Entity<135>, "id" | "label"> = transform(
  selected135,
  value => ({ id: value.id, label: value.label }),
);

const entity136: Entity<136> = { id: 136, label: "entity-136", active: true };
const selected136 = project(entity136, ["id", "label"] as const);
const label136: `entity-136` = field(selected136, "label");
export const result136: PickFields<Entity<136>, "id" | "label"> = transform(
  selected136,
  value => ({ id: value.id, label: value.label }),
);

const entity137: Entity<137> = { id: 137, label: "entity-137", active: false };
const selected137 = project(entity137, ["id", "label"] as const);
const label137: `entity-137` = field(selected137, "label");
export const result137: PickFields<Entity<137>, "id" | "label"> = transform(
  selected137,
  value => ({ id: value.id, label: value.label }),
);

const entity138: Entity<138> = { id: 138, label: "entity-138", active: true };
const selected138 = project(entity138, ["id", "label"] as const);
const label138: `entity-138` = field(selected138, "label");
export const result138: PickFields<Entity<138>, "id" | "label"> = transform(
  selected138,
  value => ({ id: value.id, label: value.label }),
);

const entity139: Entity<139> = { id: 139, label: "entity-139", active: false };
const selected139 = project(entity139, ["id", "label"] as const);
const label139: `entity-139` = field(selected139, "label");
export const result139: PickFields<Entity<139>, "id" | "label"> = transform(
  selected139,
  value => ({ id: value.id, label: value.label }),
);

const entity140: Entity<140> = { id: 140, label: "entity-140", active: true };
const selected140 = project(entity140, ["id", "label"] as const);
const label140: `entity-140` = field(selected140, "label");
export const result140: PickFields<Entity<140>, "id" | "label"> = transform(
  selected140,
  value => ({ id: value.id, label: value.label }),
);

const entity141: Entity<141> = { id: 141, label: "entity-141", active: false };
const selected141 = project(entity141, ["id", "label"] as const);
const label141: `entity-141` = field(selected141, "label");
export const result141: PickFields<Entity<141>, "id" | "label"> = transform(
  selected141,
  value => ({ id: value.id, label: value.label }),
);

const entity142: Entity<142> = { id: 142, label: "entity-142", active: true };
const selected142 = project(entity142, ["id", "label"] as const);
const label142: `entity-142` = field(selected142, "label");
export const result142: PickFields<Entity<142>, "id" | "label"> = transform(
  selected142,
  value => ({ id: value.id, label: value.label }),
);

const entity143: Entity<143> = { id: 143, label: "entity-143", active: false };
const selected143 = project(entity143, ["id", "label"] as const);
const label143: `entity-143` = field(selected143, "label");
export const result143: PickFields<Entity<143>, "id" | "label"> = transform(
  selected143,
  value => ({ id: value.id, label: value.label }),
);

const entity144: Entity<144> = { id: 144, label: "entity-144", active: true };
const selected144 = project(entity144, ["id", "label"] as const);
const label144: `entity-144` = field(selected144, "label");
export const result144: PickFields<Entity<144>, "id" | "label"> = transform(
  selected144,
  value => ({ id: value.id, label: value.label }),
);

const entity145: Entity<145> = { id: 145, label: "entity-145", active: false };
const selected145 = project(entity145, ["id", "label"] as const);
const label145: `entity-145` = field(selected145, "label");
export const result145: PickFields<Entity<145>, "id" | "label"> = transform(
  selected145,
  value => ({ id: value.id, label: value.label }),
);

const entity146: Entity<146> = { id: 146, label: "entity-146", active: true };
const selected146 = project(entity146, ["id", "label"] as const);
const label146: `entity-146` = field(selected146, "label");
export const result146: PickFields<Entity<146>, "id" | "label"> = transform(
  selected146,
  value => ({ id: value.id, label: value.label }),
);

const entity147: Entity<147> = { id: 147, label: "entity-147", active: false };
const selected147 = project(entity147, ["id", "label"] as const);
const label147: `entity-147` = field(selected147, "label");
export const result147: PickFields<Entity<147>, "id" | "label"> = transform(
  selected147,
  value => ({ id: value.id, label: value.label }),
);

const entity148: Entity<148> = { id: 148, label: "entity-148", active: true };
const selected148 = project(entity148, ["id", "label"] as const);
const label148: `entity-148` = field(selected148, "label");
export const result148: PickFields<Entity<148>, "id" | "label"> = transform(
  selected148,
  value => ({ id: value.id, label: value.label }),
);

const entity149: Entity<149> = { id: 149, label: "entity-149", active: false };
const selected149 = project(entity149, ["id", "label"] as const);
const label149: `entity-149` = field(selected149, "label");
export const result149: PickFields<Entity<149>, "id" | "label"> = transform(
  selected149,
  value => ({ id: value.id, label: value.label }),
);

const entity150: Entity<150> = { id: 150, label: "entity-150", active: true };
const selected150 = project(entity150, ["id", "label"] as const);
const label150: `entity-150` = field(selected150, "label");
export const result150: PickFields<Entity<150>, "id" | "label"> = transform(
  selected150,
  value => ({ id: value.id, label: value.label }),
);

const entity151: Entity<151> = { id: 151, label: "entity-151", active: false };
const selected151 = project(entity151, ["id", "label"] as const);
const label151: `entity-151` = field(selected151, "label");
export const result151: PickFields<Entity<151>, "id" | "label"> = transform(
  selected151,
  value => ({ id: value.id, label: value.label }),
);

const entity152: Entity<152> = { id: 152, label: "entity-152", active: true };
const selected152 = project(entity152, ["id", "label"] as const);
const label152: `entity-152` = field(selected152, "label");
export const result152: PickFields<Entity<152>, "id" | "label"> = transform(
  selected152,
  value => ({ id: value.id, label: value.label }),
);

const entity153: Entity<153> = { id: 153, label: "entity-153", active: false };
const selected153 = project(entity153, ["id", "label"] as const);
const label153: `entity-153` = field(selected153, "label");
export const result153: PickFields<Entity<153>, "id" | "label"> = transform(
  selected153,
  value => ({ id: value.id, label: value.label }),
);

const entity154: Entity<154> = { id: 154, label: "entity-154", active: true };
const selected154 = project(entity154, ["id", "label"] as const);
const label154: `entity-154` = field(selected154, "label");
export const result154: PickFields<Entity<154>, "id" | "label"> = transform(
  selected154,
  value => ({ id: value.id, label: value.label }),
);

const entity155: Entity<155> = { id: 155, label: "entity-155", active: false };
const selected155 = project(entity155, ["id", "label"] as const);
const label155: `entity-155` = field(selected155, "label");
export const result155: PickFields<Entity<155>, "id" | "label"> = transform(
  selected155,
  value => ({ id: value.id, label: value.label }),
);

const entity156: Entity<156> = { id: 156, label: "entity-156", active: true };
const selected156 = project(entity156, ["id", "label"] as const);
const label156: `entity-156` = field(selected156, "label");
export const result156: PickFields<Entity<156>, "id" | "label"> = transform(
  selected156,
  value => ({ id: value.id, label: value.label }),
);

const entity157: Entity<157> = { id: 157, label: "entity-157", active: false };
const selected157 = project(entity157, ["id", "label"] as const);
const label157: `entity-157` = field(selected157, "label");
export const result157: PickFields<Entity<157>, "id" | "label"> = transform(
  selected157,
  value => ({ id: value.id, label: value.label }),
);

const entity158: Entity<158> = { id: 158, label: "entity-158", active: true };
const selected158 = project(entity158, ["id", "label"] as const);
const label158: `entity-158` = field(selected158, "label");
export const result158: PickFields<Entity<158>, "id" | "label"> = transform(
  selected158,
  value => ({ id: value.id, label: value.label }),
);

const entity159: Entity<159> = { id: 159, label: "entity-159", active: false };
const selected159 = project(entity159, ["id", "label"] as const);
const label159: `entity-159` = field(selected159, "label");
export const result159: PickFields<Entity<159>, "id" | "label"> = transform(
  selected159,
  value => ({ id: value.id, label: value.label }),
);

const entity160: Entity<160> = { id: 160, label: "entity-160", active: true };
const selected160 = project(entity160, ["id", "label"] as const);
const label160: `entity-160` = field(selected160, "label");
export const result160: PickFields<Entity<160>, "id" | "label"> = transform(
  selected160,
  value => ({ id: value.id, label: value.label }),
);

const entity161: Entity<161> = { id: 161, label: "entity-161", active: false };
const selected161 = project(entity161, ["id", "label"] as const);
const label161: `entity-161` = field(selected161, "label");
export const result161: PickFields<Entity<161>, "id" | "label"> = transform(
  selected161,
  value => ({ id: value.id, label: value.label }),
);

const entity162: Entity<162> = { id: 162, label: "entity-162", active: true };
const selected162 = project(entity162, ["id", "label"] as const);
const label162: `entity-162` = field(selected162, "label");
export const result162: PickFields<Entity<162>, "id" | "label"> = transform(
  selected162,
  value => ({ id: value.id, label: value.label }),
);

const entity163: Entity<163> = { id: 163, label: "entity-163", active: false };
const selected163 = project(entity163, ["id", "label"] as const);
const label163: `entity-163` = field(selected163, "label");
export const result163: PickFields<Entity<163>, "id" | "label"> = transform(
  selected163,
  value => ({ id: value.id, label: value.label }),
);

const entity164: Entity<164> = { id: 164, label: "entity-164", active: true };
const selected164 = project(entity164, ["id", "label"] as const);
const label164: `entity-164` = field(selected164, "label");
export const result164: PickFields<Entity<164>, "id" | "label"> = transform(
  selected164,
  value => ({ id: value.id, label: value.label }),
);

const entity165: Entity<165> = { id: 165, label: "entity-165", active: false };
const selected165 = project(entity165, ["id", "label"] as const);
const label165: `entity-165` = field(selected165, "label");
export const result165: PickFields<Entity<165>, "id" | "label"> = transform(
  selected165,
  value => ({ id: value.id, label: value.label }),
);

const entity166: Entity<166> = { id: 166, label: "entity-166", active: true };
const selected166 = project(entity166, ["id", "label"] as const);
const label166: `entity-166` = field(selected166, "label");
export const result166: PickFields<Entity<166>, "id" | "label"> = transform(
  selected166,
  value => ({ id: value.id, label: value.label }),
);

const entity167: Entity<167> = { id: 167, label: "entity-167", active: false };
const selected167 = project(entity167, ["id", "label"] as const);
const label167: `entity-167` = field(selected167, "label");
export const result167: PickFields<Entity<167>, "id" | "label"> = transform(
  selected167,
  value => ({ id: value.id, label: value.label }),
);

const entity168: Entity<168> = { id: 168, label: "entity-168", active: true };
const selected168 = project(entity168, ["id", "label"] as const);
const label168: `entity-168` = field(selected168, "label");
export const result168: PickFields<Entity<168>, "id" | "label"> = transform(
  selected168,
  value => ({ id: value.id, label: value.label }),
);

const entity169: Entity<169> = { id: 169, label: "entity-169", active: false };
const selected169 = project(entity169, ["id", "label"] as const);
const label169: `entity-169` = field(selected169, "label");
export const result169: PickFields<Entity<169>, "id" | "label"> = transform(
  selected169,
  value => ({ id: value.id, label: value.label }),
);

const entity170: Entity<170> = { id: 170, label: "entity-170", active: true };
const selected170 = project(entity170, ["id", "label"] as const);
const label170: `entity-170` = field(selected170, "label");
export const result170: PickFields<Entity<170>, "id" | "label"> = transform(
  selected170,
  value => ({ id: value.id, label: value.label }),
);

const entity171: Entity<171> = { id: 171, label: "entity-171", active: false };
const selected171 = project(entity171, ["id", "label"] as const);
const label171: `entity-171` = field(selected171, "label");
export const result171: PickFields<Entity<171>, "id" | "label"> = transform(
  selected171,
  value => ({ id: value.id, label: value.label }),
);

const entity172: Entity<172> = { id: 172, label: "entity-172", active: true };
const selected172 = project(entity172, ["id", "label"] as const);
const label172: `entity-172` = field(selected172, "label");
export const result172: PickFields<Entity<172>, "id" | "label"> = transform(
  selected172,
  value => ({ id: value.id, label: value.label }),
);

const entity173: Entity<173> = { id: 173, label: "entity-173", active: false };
const selected173 = project(entity173, ["id", "label"] as const);
const label173: `entity-173` = field(selected173, "label");
export const result173: PickFields<Entity<173>, "id" | "label"> = transform(
  selected173,
  value => ({ id: value.id, label: value.label }),
);

const entity174: Entity<174> = { id: 174, label: "entity-174", active: true };
const selected174 = project(entity174, ["id", "label"] as const);
const label174: `entity-174` = field(selected174, "label");
export const result174: PickFields<Entity<174>, "id" | "label"> = transform(
  selected174,
  value => ({ id: value.id, label: value.label }),
);

const entity175: Entity<175> = { id: 175, label: "entity-175", active: false };
const selected175 = project(entity175, ["id", "label"] as const);
const label175: `entity-175` = field(selected175, "label");
export const result175: PickFields<Entity<175>, "id" | "label"> = transform(
  selected175,
  value => ({ id: value.id, label: value.label }),
);

const entity176: Entity<176> = { id: 176, label: "entity-176", active: true };
const selected176 = project(entity176, ["id", "label"] as const);
const label176: `entity-176` = field(selected176, "label");
export const result176: PickFields<Entity<176>, "id" | "label"> = transform(
  selected176,
  value => ({ id: value.id, label: value.label }),
);

const entity177: Entity<177> = { id: 177, label: "entity-177", active: false };
const selected177 = project(entity177, ["id", "label"] as const);
const label177: `entity-177` = field(selected177, "label");
export const result177: PickFields<Entity<177>, "id" | "label"> = transform(
  selected177,
  value => ({ id: value.id, label: value.label }),
);

const entity178: Entity<178> = { id: 178, label: "entity-178", active: true };
const selected178 = project(entity178, ["id", "label"] as const);
const label178: `entity-178` = field(selected178, "label");
export const result178: PickFields<Entity<178>, "id" | "label"> = transform(
  selected178,
  value => ({ id: value.id, label: value.label }),
);

const entity179: Entity<179> = { id: 179, label: "entity-179", active: false };
const selected179 = project(entity179, ["id", "label"] as const);
const label179: `entity-179` = field(selected179, "label");
export const result179: PickFields<Entity<179>, "id" | "label"> = transform(
  selected179,
  value => ({ id: value.id, label: value.label }),
);

const entity180: Entity<180> = { id: 180, label: "entity-180", active: true };
const selected180 = project(entity180, ["id", "label"] as const);
const label180: `entity-180` = field(selected180, "label");
export const result180: PickFields<Entity<180>, "id" | "label"> = transform(
  selected180,
  value => ({ id: value.id, label: value.label }),
);

const entity181: Entity<181> = { id: 181, label: "entity-181", active: false };
const selected181 = project(entity181, ["id", "label"] as const);
const label181: `entity-181` = field(selected181, "label");
export const result181: PickFields<Entity<181>, "id" | "label"> = transform(
  selected181,
  value => ({ id: value.id, label: value.label }),
);

const entity182: Entity<182> = { id: 182, label: "entity-182", active: true };
const selected182 = project(entity182, ["id", "label"] as const);
const label182: `entity-182` = field(selected182, "label");
export const result182: PickFields<Entity<182>, "id" | "label"> = transform(
  selected182,
  value => ({ id: value.id, label: value.label }),
);

const entity183: Entity<183> = { id: 183, label: "entity-183", active: false };
const selected183 = project(entity183, ["id", "label"] as const);
const label183: `entity-183` = field(selected183, "label");
export const result183: PickFields<Entity<183>, "id" | "label"> = transform(
  selected183,
  value => ({ id: value.id, label: value.label }),
);

const entity184: Entity<184> = { id: 184, label: "entity-184", active: true };
const selected184 = project(entity184, ["id", "label"] as const);
const label184: `entity-184` = field(selected184, "label");
export const result184: PickFields<Entity<184>, "id" | "label"> = transform(
  selected184,
  value => ({ id: value.id, label: value.label }),
);

const entity185: Entity<185> = { id: 185, label: "entity-185", active: false };
const selected185 = project(entity185, ["id", "label"] as const);
const label185: `entity-185` = field(selected185, "label");
export const result185: PickFields<Entity<185>, "id" | "label"> = transform(
  selected185,
  value => ({ id: value.id, label: value.label }),
);

const entity186: Entity<186> = { id: 186, label: "entity-186", active: true };
const selected186 = project(entity186, ["id", "label"] as const);
const label186: `entity-186` = field(selected186, "label");
export const result186: PickFields<Entity<186>, "id" | "label"> = transform(
  selected186,
  value => ({ id: value.id, label: value.label }),
);

const entity187: Entity<187> = { id: 187, label: "entity-187", active: false };
const selected187 = project(entity187, ["id", "label"] as const);
const label187: `entity-187` = field(selected187, "label");
export const result187: PickFields<Entity<187>, "id" | "label"> = transform(
  selected187,
  value => ({ id: value.id, label: value.label }),
);

const entity188: Entity<188> = { id: 188, label: "entity-188", active: true };
const selected188 = project(entity188, ["id", "label"] as const);
const label188: `entity-188` = field(selected188, "label");
export const result188: PickFields<Entity<188>, "id" | "label"> = transform(
  selected188,
  value => ({ id: value.id, label: value.label }),
);

const entity189: Entity<189> = { id: 189, label: "entity-189", active: false };
const selected189 = project(entity189, ["id", "label"] as const);
const label189: `entity-189` = field(selected189, "label");
export const result189: PickFields<Entity<189>, "id" | "label"> = transform(
  selected189,
  value => ({ id: value.id, label: value.label }),
);

const entity190: Entity<190> = { id: 190, label: "entity-190", active: true };
const selected190 = project(entity190, ["id", "label"] as const);
const label190: `entity-190` = field(selected190, "label");
export const result190: PickFields<Entity<190>, "id" | "label"> = transform(
  selected190,
  value => ({ id: value.id, label: value.label }),
);

const entity191: Entity<191> = { id: 191, label: "entity-191", active: false };
const selected191 = project(entity191, ["id", "label"] as const);
const label191: `entity-191` = field(selected191, "label");
export const result191: PickFields<Entity<191>, "id" | "label"> = transform(
  selected191,
  value => ({ id: value.id, label: value.label }),
);

const entity192: Entity<192> = { id: 192, label: "entity-192", active: true };
const selected192 = project(entity192, ["id", "label"] as const);
const label192: `entity-192` = field(selected192, "label");
export const result192: PickFields<Entity<192>, "id" | "label"> = transform(
  selected192,
  value => ({ id: value.id, label: value.label }),
);

const entity193: Entity<193> = { id: 193, label: "entity-193", active: false };
const selected193 = project(entity193, ["id", "label"] as const);
const label193: `entity-193` = field(selected193, "label");
export const result193: PickFields<Entity<193>, "id" | "label"> = transform(
  selected193,
  value => ({ id: value.id, label: value.label }),
);

const entity194: Entity<194> = { id: 194, label: "entity-194", active: true };
const selected194 = project(entity194, ["id", "label"] as const);
const label194: `entity-194` = field(selected194, "label");
export const result194: PickFields<Entity<194>, "id" | "label"> = transform(
  selected194,
  value => ({ id: value.id, label: value.label }),
);

const entity195: Entity<195> = { id: 195, label: "entity-195", active: false };
const selected195 = project(entity195, ["id", "label"] as const);
const label195: `entity-195` = field(selected195, "label");
export const result195: PickFields<Entity<195>, "id" | "label"> = transform(
  selected195,
  value => ({ id: value.id, label: value.label }),
);

const entity196: Entity<196> = { id: 196, label: "entity-196", active: true };
const selected196 = project(entity196, ["id", "label"] as const);
const label196: `entity-196` = field(selected196, "label");
export const result196: PickFields<Entity<196>, "id" | "label"> = transform(
  selected196,
  value => ({ id: value.id, label: value.label }),
);

const entity197: Entity<197> = { id: 197, label: "entity-197", active: false };
const selected197 = project(entity197, ["id", "label"] as const);
const label197: `entity-197` = field(selected197, "label");
export const result197: PickFields<Entity<197>, "id" | "label"> = transform(
  selected197,
  value => ({ id: value.id, label: value.label }),
);

const entity198: Entity<198> = { id: 198, label: "entity-198", active: true };
const selected198 = project(entity198, ["id", "label"] as const);
const label198: `entity-198` = field(selected198, "label");
export const result198: PickFields<Entity<198>, "id" | "label"> = transform(
  selected198,
  value => ({ id: value.id, label: value.label }),
);

const entity199: Entity<199> = { id: 199, label: "entity-199", active: false };
const selected199 = project(entity199, ["id", "label"] as const);
const label199: `entity-199` = field(selected199, "label");
export const result199: PickFields<Entity<199>, "id" | "label"> = transform(
  selected199,
  value => ({ id: value.id, label: value.label }),
);

const entity200: Entity<200> = { id: 200, label: "entity-200", active: true };
const selected200 = project(entity200, ["id", "label"] as const);
const label200: `entity-200` = field(selected200, "label");
export const result200: PickFields<Entity<200>, "id" | "label"> = transform(
  selected200,
  value => ({ id: value.id, label: value.label }),
);

const entity201: Entity<201> = { id: 201, label: "entity-201", active: false };
const selected201 = project(entity201, ["id", "label"] as const);
const label201: `entity-201` = field(selected201, "label");
export const result201: PickFields<Entity<201>, "id" | "label"> = transform(
  selected201,
  value => ({ id: value.id, label: value.label }),
);

const entity202: Entity<202> = { id: 202, label: "entity-202", active: true };
const selected202 = project(entity202, ["id", "label"] as const);
const label202: `entity-202` = field(selected202, "label");
export const result202: PickFields<Entity<202>, "id" | "label"> = transform(
  selected202,
  value => ({ id: value.id, label: value.label }),
);

const entity203: Entity<203> = { id: 203, label: "entity-203", active: false };
const selected203 = project(entity203, ["id", "label"] as const);
const label203: `entity-203` = field(selected203, "label");
export const result203: PickFields<Entity<203>, "id" | "label"> = transform(
  selected203,
  value => ({ id: value.id, label: value.label }),
);

const entity204: Entity<204> = { id: 204, label: "entity-204", active: true };
const selected204 = project(entity204, ["id", "label"] as const);
const label204: `entity-204` = field(selected204, "label");
export const result204: PickFields<Entity<204>, "id" | "label"> = transform(
  selected204,
  value => ({ id: value.id, label: value.label }),
);

const entity205: Entity<205> = { id: 205, label: "entity-205", active: false };
const selected205 = project(entity205, ["id", "label"] as const);
const label205: `entity-205` = field(selected205, "label");
export const result205: PickFields<Entity<205>, "id" | "label"> = transform(
  selected205,
  value => ({ id: value.id, label: value.label }),
);

const entity206: Entity<206> = { id: 206, label: "entity-206", active: true };
const selected206 = project(entity206, ["id", "label"] as const);
const label206: `entity-206` = field(selected206, "label");
export const result206: PickFields<Entity<206>, "id" | "label"> = transform(
  selected206,
  value => ({ id: value.id, label: value.label }),
);

const entity207: Entity<207> = { id: 207, label: "entity-207", active: false };
const selected207 = project(entity207, ["id", "label"] as const);
const label207: `entity-207` = field(selected207, "label");
export const result207: PickFields<Entity<207>, "id" | "label"> = transform(
  selected207,
  value => ({ id: value.id, label: value.label }),
);

const entity208: Entity<208> = { id: 208, label: "entity-208", active: true };
const selected208 = project(entity208, ["id", "label"] as const);
const label208: `entity-208` = field(selected208, "label");
export const result208: PickFields<Entity<208>, "id" | "label"> = transform(
  selected208,
  value => ({ id: value.id, label: value.label }),
);

const entity209: Entity<209> = { id: 209, label: "entity-209", active: false };
const selected209 = project(entity209, ["id", "label"] as const);
const label209: `entity-209` = field(selected209, "label");
export const result209: PickFields<Entity<209>, "id" | "label"> = transform(
  selected209,
  value => ({ id: value.id, label: value.label }),
);

const entity210: Entity<210> = { id: 210, label: "entity-210", active: true };
const selected210 = project(entity210, ["id", "label"] as const);
const label210: `entity-210` = field(selected210, "label");
export const result210: PickFields<Entity<210>, "id" | "label"> = transform(
  selected210,
  value => ({ id: value.id, label: value.label }),
);

const entity211: Entity<211> = { id: 211, label: "entity-211", active: false };
const selected211 = project(entity211, ["id", "label"] as const);
const label211: `entity-211` = field(selected211, "label");
export const result211: PickFields<Entity<211>, "id" | "label"> = transform(
  selected211,
  value => ({ id: value.id, label: value.label }),
);

const entity212: Entity<212> = { id: 212, label: "entity-212", active: true };
const selected212 = project(entity212, ["id", "label"] as const);
const label212: `entity-212` = field(selected212, "label");
export const result212: PickFields<Entity<212>, "id" | "label"> = transform(
  selected212,
  value => ({ id: value.id, label: value.label }),
);

const entity213: Entity<213> = { id: 213, label: "entity-213", active: false };
const selected213 = project(entity213, ["id", "label"] as const);
const label213: `entity-213` = field(selected213, "label");
export const result213: PickFields<Entity<213>, "id" | "label"> = transform(
  selected213,
  value => ({ id: value.id, label: value.label }),
);

const entity214: Entity<214> = { id: 214, label: "entity-214", active: true };
const selected214 = project(entity214, ["id", "label"] as const);
const label214: `entity-214` = field(selected214, "label");
export const result214: PickFields<Entity<214>, "id" | "label"> = transform(
  selected214,
  value => ({ id: value.id, label: value.label }),
);

const entity215: Entity<215> = { id: 215, label: "entity-215", active: false };
const selected215 = project(entity215, ["id", "label"] as const);
const label215: `entity-215` = field(selected215, "label");
export const result215: PickFields<Entity<215>, "id" | "label"> = transform(
  selected215,
  value => ({ id: value.id, label: value.label }),
);

const entity216: Entity<216> = { id: 216, label: "entity-216", active: true };
const selected216 = project(entity216, ["id", "label"] as const);
const label216: `entity-216` = field(selected216, "label");
export const result216: PickFields<Entity<216>, "id" | "label"> = transform(
  selected216,
  value => ({ id: value.id, label: value.label }),
);

const entity217: Entity<217> = { id: 217, label: "entity-217", active: false };
const selected217 = project(entity217, ["id", "label"] as const);
const label217: `entity-217` = field(selected217, "label");
export const result217: PickFields<Entity<217>, "id" | "label"> = transform(
  selected217,
  value => ({ id: value.id, label: value.label }),
);

const entity218: Entity<218> = { id: 218, label: "entity-218", active: true };
const selected218 = project(entity218, ["id", "label"] as const);
const label218: `entity-218` = field(selected218, "label");
export const result218: PickFields<Entity<218>, "id" | "label"> = transform(
  selected218,
  value => ({ id: value.id, label: value.label }),
);

const entity219: Entity<219> = { id: 219, label: "entity-219", active: false };
const selected219 = project(entity219, ["id", "label"] as const);
const label219: `entity-219` = field(selected219, "label");
export const result219: PickFields<Entity<219>, "id" | "label"> = transform(
  selected219,
  value => ({ id: value.id, label: value.label }),
);

const entity220: Entity<220> = { id: 220, label: "entity-220", active: true };
const selected220 = project(entity220, ["id", "label"] as const);
const label220: `entity-220` = field(selected220, "label");
export const result220: PickFields<Entity<220>, "id" | "label"> = transform(
  selected220,
  value => ({ id: value.id, label: value.label }),
);

const entity221: Entity<221> = { id: 221, label: "entity-221", active: false };
const selected221 = project(entity221, ["id", "label"] as const);
const label221: `entity-221` = field(selected221, "label");
export const result221: PickFields<Entity<221>, "id" | "label"> = transform(
  selected221,
  value => ({ id: value.id, label: value.label }),
);

const entity222: Entity<222> = { id: 222, label: "entity-222", active: true };
const selected222 = project(entity222, ["id", "label"] as const);
const label222: `entity-222` = field(selected222, "label");
export const result222: PickFields<Entity<222>, "id" | "label"> = transform(
  selected222,
  value => ({ id: value.id, label: value.label }),
);

const entity223: Entity<223> = { id: 223, label: "entity-223", active: false };
const selected223 = project(entity223, ["id", "label"] as const);
const label223: `entity-223` = field(selected223, "label");
export const result223: PickFields<Entity<223>, "id" | "label"> = transform(
  selected223,
  value => ({ id: value.id, label: value.label }),
);

const entity224: Entity<224> = { id: 224, label: "entity-224", active: true };
const selected224 = project(entity224, ["id", "label"] as const);
const label224: `entity-224` = field(selected224, "label");
export const result224: PickFields<Entity<224>, "id" | "label"> = transform(
  selected224,
  value => ({ id: value.id, label: value.label }),
);

const entity225: Entity<225> = { id: 225, label: "entity-225", active: false };
const selected225 = project(entity225, ["id", "label"] as const);
const label225: `entity-225` = field(selected225, "label");
export const result225: PickFields<Entity<225>, "id" | "label"> = transform(
  selected225,
  value => ({ id: value.id, label: value.label }),
);

const entity226: Entity<226> = { id: 226, label: "entity-226", active: true };
const selected226 = project(entity226, ["id", "label"] as const);
const label226: `entity-226` = field(selected226, "label");
export const result226: PickFields<Entity<226>, "id" | "label"> = transform(
  selected226,
  value => ({ id: value.id, label: value.label }),
);

const entity227: Entity<227> = { id: 227, label: "entity-227", active: false };
const selected227 = project(entity227, ["id", "label"] as const);
const label227: `entity-227` = field(selected227, "label");
export const result227: PickFields<Entity<227>, "id" | "label"> = transform(
  selected227,
  value => ({ id: value.id, label: value.label }),
);

const entity228: Entity<228> = { id: 228, label: "entity-228", active: true };
const selected228 = project(entity228, ["id", "label"] as const);
const label228: `entity-228` = field(selected228, "label");
export const result228: PickFields<Entity<228>, "id" | "label"> = transform(
  selected228,
  value => ({ id: value.id, label: value.label }),
);

const entity229: Entity<229> = { id: 229, label: "entity-229", active: false };
const selected229 = project(entity229, ["id", "label"] as const);
const label229: `entity-229` = field(selected229, "label");
export const result229: PickFields<Entity<229>, "id" | "label"> = transform(
  selected229,
  value => ({ id: value.id, label: value.label }),
);

const entity230: Entity<230> = { id: 230, label: "entity-230", active: true };
const selected230 = project(entity230, ["id", "label"] as const);
const label230: `entity-230` = field(selected230, "label");
export const result230: PickFields<Entity<230>, "id" | "label"> = transform(
  selected230,
  value => ({ id: value.id, label: value.label }),
);

const entity231: Entity<231> = { id: 231, label: "entity-231", active: false };
const selected231 = project(entity231, ["id", "label"] as const);
const label231: `entity-231` = field(selected231, "label");
export const result231: PickFields<Entity<231>, "id" | "label"> = transform(
  selected231,
  value => ({ id: value.id, label: value.label }),
);

const entity232: Entity<232> = { id: 232, label: "entity-232", active: true };
const selected232 = project(entity232, ["id", "label"] as const);
const label232: `entity-232` = field(selected232, "label");
export const result232: PickFields<Entity<232>, "id" | "label"> = transform(
  selected232,
  value => ({ id: value.id, label: value.label }),
);

const entity233: Entity<233> = { id: 233, label: "entity-233", active: false };
const selected233 = project(entity233, ["id", "label"] as const);
const label233: `entity-233` = field(selected233, "label");
export const result233: PickFields<Entity<233>, "id" | "label"> = transform(
  selected233,
  value => ({ id: value.id, label: value.label }),
);

const entity234: Entity<234> = { id: 234, label: "entity-234", active: true };
const selected234 = project(entity234, ["id", "label"] as const);
const label234: `entity-234` = field(selected234, "label");
export const result234: PickFields<Entity<234>, "id" | "label"> = transform(
  selected234,
  value => ({ id: value.id, label: value.label }),
);

const entity235: Entity<235> = { id: 235, label: "entity-235", active: false };
const selected235 = project(entity235, ["id", "label"] as const);
const label235: `entity-235` = field(selected235, "label");
export const result235: PickFields<Entity<235>, "id" | "label"> = transform(
  selected235,
  value => ({ id: value.id, label: value.label }),
);

const entity236: Entity<236> = { id: 236, label: "entity-236", active: true };
const selected236 = project(entity236, ["id", "label"] as const);
const label236: `entity-236` = field(selected236, "label");
export const result236: PickFields<Entity<236>, "id" | "label"> = transform(
  selected236,
  value => ({ id: value.id, label: value.label }),
);

const entity237: Entity<237> = { id: 237, label: "entity-237", active: false };
const selected237 = project(entity237, ["id", "label"] as const);
const label237: `entity-237` = field(selected237, "label");
export const result237: PickFields<Entity<237>, "id" | "label"> = transform(
  selected237,
  value => ({ id: value.id, label: value.label }),
);

const entity238: Entity<238> = { id: 238, label: "entity-238", active: true };
const selected238 = project(entity238, ["id", "label"] as const);
const label238: `entity-238` = field(selected238, "label");
export const result238: PickFields<Entity<238>, "id" | "label"> = transform(
  selected238,
  value => ({ id: value.id, label: value.label }),
);

const entity239: Entity<239> = { id: 239, label: "entity-239", active: false };
const selected239 = project(entity239, ["id", "label"] as const);
const label239: `entity-239` = field(selected239, "label");
export const result239: PickFields<Entity<239>, "id" | "label"> = transform(
  selected239,
  value => ({ id: value.id, label: value.label }),
);

const entity240: Entity<240> = { id: 240, label: "entity-240", active: true };
const selected240 = project(entity240, ["id", "label"] as const);
const label240: `entity-240` = field(selected240, "label");
export const result240: PickFields<Entity<240>, "id" | "label"> = transform(
  selected240,
  value => ({ id: value.id, label: value.label }),
);

const entity241: Entity<241> = { id: 241, label: "entity-241", active: false };
const selected241 = project(entity241, ["id", "label"] as const);
const label241: `entity-241` = field(selected241, "label");
export const result241: PickFields<Entity<241>, "id" | "label"> = transform(
  selected241,
  value => ({ id: value.id, label: value.label }),
);

const entity242: Entity<242> = { id: 242, label: "entity-242", active: true };
const selected242 = project(entity242, ["id", "label"] as const);
const label242: `entity-242` = field(selected242, "label");
export const result242: PickFields<Entity<242>, "id" | "label"> = transform(
  selected242,
  value => ({ id: value.id, label: value.label }),
);

const entity243: Entity<243> = { id: 243, label: "entity-243", active: false };
const selected243 = project(entity243, ["id", "label"] as const);
const label243: `entity-243` = field(selected243, "label");
export const result243: PickFields<Entity<243>, "id" | "label"> = transform(
  selected243,
  value => ({ id: value.id, label: value.label }),
);

const entity244: Entity<244> = { id: 244, label: "entity-244", active: true };
const selected244 = project(entity244, ["id", "label"] as const);
const label244: `entity-244` = field(selected244, "label");
export const result244: PickFields<Entity<244>, "id" | "label"> = transform(
  selected244,
  value => ({ id: value.id, label: value.label }),
);

const entity245: Entity<245> = { id: 245, label: "entity-245", active: false };
const selected245 = project(entity245, ["id", "label"] as const);
const label245: `entity-245` = field(selected245, "label");
export const result245: PickFields<Entity<245>, "id" | "label"> = transform(
  selected245,
  value => ({ id: value.id, label: value.label }),
);

const entity246: Entity<246> = { id: 246, label: "entity-246", active: true };
const selected246 = project(entity246, ["id", "label"] as const);
const label246: `entity-246` = field(selected246, "label");
export const result246: PickFields<Entity<246>, "id" | "label"> = transform(
  selected246,
  value => ({ id: value.id, label: value.label }),
);

const entity247: Entity<247> = { id: 247, label: "entity-247", active: false };
const selected247 = project(entity247, ["id", "label"] as const);
const label247: `entity-247` = field(selected247, "label");
export const result247: PickFields<Entity<247>, "id" | "label"> = transform(
  selected247,
  value => ({ id: value.id, label: value.label }),
);

const entity248: Entity<248> = { id: 248, label: "entity-248", active: true };
const selected248 = project(entity248, ["id", "label"] as const);
const label248: `entity-248` = field(selected248, "label");
export const result248: PickFields<Entity<248>, "id" | "label"> = transform(
  selected248,
  value => ({ id: value.id, label: value.label }),
);

const entity249: Entity<249> = { id: 249, label: "entity-249", active: false };
const selected249 = project(entity249, ["id", "label"] as const);
const label249: `entity-249` = field(selected249, "label");
export const result249: PickFields<Entity<249>, "id" | "label"> = transform(
  selected249,
  value => ({ id: value.id, label: value.label }),
);

const entity250: Entity<250> = { id: 250, label: "entity-250", active: true };
const selected250 = project(entity250, ["id", "label"] as const);
const label250: `entity-250` = field(selected250, "label");
export const result250: PickFields<Entity<250>, "id" | "label"> = transform(
  selected250,
  value => ({ id: value.id, label: value.label }),
);

const entity251: Entity<251> = { id: 251, label: "entity-251", active: false };
const selected251 = project(entity251, ["id", "label"] as const);
const label251: `entity-251` = field(selected251, "label");
export const result251: PickFields<Entity<251>, "id" | "label"> = transform(
  selected251,
  value => ({ id: value.id, label: value.label }),
);

const entity252: Entity<252> = { id: 252, label: "entity-252", active: true };
const selected252 = project(entity252, ["id", "label"] as const);
const label252: `entity-252` = field(selected252, "label");
export const result252: PickFields<Entity<252>, "id" | "label"> = transform(
  selected252,
  value => ({ id: value.id, label: value.label }),
);

const entity253: Entity<253> = { id: 253, label: "entity-253", active: false };
const selected253 = project(entity253, ["id", "label"] as const);
const label253: `entity-253` = field(selected253, "label");
export const result253: PickFields<Entity<253>, "id" | "label"> = transform(
  selected253,
  value => ({ id: value.id, label: value.label }),
);

const entity254: Entity<254> = { id: 254, label: "entity-254", active: true };
const selected254 = project(entity254, ["id", "label"] as const);
const label254: `entity-254` = field(selected254, "label");
export const result254: PickFields<Entity<254>, "id" | "label"> = transform(
  selected254,
  value => ({ id: value.id, label: value.label }),
);

const entity255: Entity<255> = { id: 255, label: "entity-255", active: false };
const selected255 = project(entity255, ["id", "label"] as const);
const label255: `entity-255` = field(selected255, "label");
export const result255: PickFields<Entity<255>, "id" | "label"> = transform(
  selected255,
  value => ({ id: value.id, label: value.label }),
);

