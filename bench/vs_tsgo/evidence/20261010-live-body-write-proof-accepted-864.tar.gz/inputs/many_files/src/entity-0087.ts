export interface Entity87<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity87<U>;
}

export type Result87<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap87<T> = T extends Result87<infer U, unknown> ? U : never;

export function transform87<T, U>(
  input: Entity87<T>,
  fn: (value: T) => U,
): Result87<Entity87<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker87: Result87<number> = { ok: true, value: 87 };
