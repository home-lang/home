export interface Entity140<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity140<U>;
}

export type Result140<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap140<T> = T extends Result140<infer U, unknown> ? U : never;

export function transform140<T, U>(
  input: Entity140<T>,
  fn: (value: T) => U,
): Result140<Entity140<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker140: Result140<number> = { ok: true, value: 140 };
