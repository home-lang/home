export interface Entity39<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity39<U>;
}

export type Result39<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap39<T> = T extends Result39<infer U, unknown> ? U : never;

export function transform39<T, U>(
  input: Entity39<T>,
  fn: (value: T) => U,
): Result39<Entity39<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker39: Result39<number> = { ok: true, value: 39 };
