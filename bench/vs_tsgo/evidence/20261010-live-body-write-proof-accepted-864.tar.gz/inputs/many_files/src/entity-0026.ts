export interface Entity26<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity26<U>;
}

export type Result26<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap26<T> = T extends Result26<infer U, unknown> ? U : never;

export function transform26<T, U>(
  input: Entity26<T>,
  fn: (value: T) => U,
): Result26<Entity26<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker26: Result26<number> = { ok: true, value: 26 };
