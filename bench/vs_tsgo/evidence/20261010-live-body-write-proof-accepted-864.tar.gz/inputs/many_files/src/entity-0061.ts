export interface Entity61<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity61<U>;
}

export type Result61<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap61<T> = T extends Result61<infer U, unknown> ? U : never;

export function transform61<T, U>(
  input: Entity61<T>,
  fn: (value: T) => U,
): Result61<Entity61<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker61: Result61<number> = { ok: true, value: 61 };
