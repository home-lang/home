export interface Entity124<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity124<U>;
}

export type Result124<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap124<T> = T extends Result124<infer U, unknown> ? U : never;

export function transform124<T, U>(
  input: Entity124<T>,
  fn: (value: T) => U,
): Result124<Entity124<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker124: Result124<number> = { ok: true, value: 124 };
