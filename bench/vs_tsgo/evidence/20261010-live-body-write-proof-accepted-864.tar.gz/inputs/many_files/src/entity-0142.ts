export interface Entity142<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity142<U>;
}

export type Result142<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap142<T> = T extends Result142<infer U, unknown> ? U : never;

export function transform142<T, U>(
  input: Entity142<T>,
  fn: (value: T) => U,
): Result142<Entity142<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker142: Result142<number> = { ok: true, value: 142 };
