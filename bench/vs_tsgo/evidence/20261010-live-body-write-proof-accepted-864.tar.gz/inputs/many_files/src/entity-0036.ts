export interface Entity36<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity36<U>;
}

export type Result36<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap36<T> = T extends Result36<infer U, unknown> ? U : never;

export function transform36<T, U>(
  input: Entity36<T>,
  fn: (value: T) => U,
): Result36<Entity36<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker36: Result36<number> = { ok: true, value: 36 };
