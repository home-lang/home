export interface Entity75<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity75<U>;
}

export type Result75<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap75<T> = T extends Result75<infer U, unknown> ? U : never;

export function transform75<T, U>(
  input: Entity75<T>,
  fn: (value: T) => U,
): Result75<Entity75<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker75: Result75<number> = { ok: true, value: 75 };
