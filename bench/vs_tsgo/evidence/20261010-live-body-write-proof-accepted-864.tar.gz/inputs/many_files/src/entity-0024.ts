export interface Entity24<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity24<U>;
}

export type Result24<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap24<T> = T extends Result24<infer U, unknown> ? U : never;

export function transform24<T, U>(
  input: Entity24<T>,
  fn: (value: T) => U,
): Result24<Entity24<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker24: Result24<number> = { ok: true, value: 24 };
