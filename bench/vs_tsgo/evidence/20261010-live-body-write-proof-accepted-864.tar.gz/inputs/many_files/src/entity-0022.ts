export interface Entity22<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity22<U>;
}

export type Result22<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap22<T> = T extends Result22<infer U, unknown> ? U : never;

export function transform22<T, U>(
  input: Entity22<T>,
  fn: (value: T) => U,
): Result22<Entity22<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker22: Result22<number> = { ok: true, value: 22 };
