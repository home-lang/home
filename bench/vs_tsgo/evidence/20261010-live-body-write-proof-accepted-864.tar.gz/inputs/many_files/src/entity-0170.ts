export interface Entity170<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity170<U>;
}

export type Result170<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap170<T> = T extends Result170<infer U, unknown> ? U : never;

export function transform170<T, U>(
  input: Entity170<T>,
  fn: (value: T) => U,
): Result170<Entity170<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker170: Result170<number> = { ok: true, value: 170 };
