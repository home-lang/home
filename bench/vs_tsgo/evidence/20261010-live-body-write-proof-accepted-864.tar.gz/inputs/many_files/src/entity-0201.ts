export interface Entity201<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity201<U>;
}

export type Result201<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap201<T> = T extends Result201<infer U, unknown> ? U : never;

export function transform201<T, U>(
  input: Entity201<T>,
  fn: (value: T) => U,
): Result201<Entity201<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker201: Result201<number> = { ok: true, value: 201 };
