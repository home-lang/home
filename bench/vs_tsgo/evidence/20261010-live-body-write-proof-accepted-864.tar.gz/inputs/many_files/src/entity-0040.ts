export interface Entity40<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity40<U>;
}

export type Result40<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap40<T> = T extends Result40<infer U, unknown> ? U : never;

export function transform40<T, U>(
  input: Entity40<T>,
  fn: (value: T) => U,
): Result40<Entity40<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker40: Result40<number> = { ok: true, value: 40 };
