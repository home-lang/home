export interface Entity165<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity165<U>;
}

export type Result165<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap165<T> = T extends Result165<infer U, unknown> ? U : never;

export function transform165<T, U>(
  input: Entity165<T>,
  fn: (value: T) => U,
): Result165<Entity165<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker165: Result165<number> = { ok: true, value: 165 };
