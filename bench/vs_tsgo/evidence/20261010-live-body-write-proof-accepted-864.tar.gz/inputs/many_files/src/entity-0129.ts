export interface Entity129<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity129<U>;
}

export type Result129<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap129<T> = T extends Result129<infer U, unknown> ? U : never;

export function transform129<T, U>(
  input: Entity129<T>,
  fn: (value: T) => U,
): Result129<Entity129<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker129: Result129<number> = { ok: true, value: 129 };
