export interface Entity149<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity149<U>;
}

export type Result149<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap149<T> = T extends Result149<infer U, unknown> ? U : never;

export function transform149<T, U>(
  input: Entity149<T>,
  fn: (value: T) => U,
): Result149<Entity149<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker149: Result149<number> = { ok: true, value: 149 };
