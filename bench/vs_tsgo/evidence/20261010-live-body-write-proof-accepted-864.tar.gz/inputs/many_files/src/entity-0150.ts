export interface Entity150<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity150<U>;
}

export type Result150<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap150<T> = T extends Result150<infer U, unknown> ? U : never;

export function transform150<T, U>(
  input: Entity150<T>,
  fn: (value: T) => U,
): Result150<Entity150<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker150: Result150<number> = { ok: true, value: 150 };
