export interface Entity134<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity134<U>;
}

export type Result134<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap134<T> = T extends Result134<infer U, unknown> ? U : never;

export function transform134<T, U>(
  input: Entity134<T>,
  fn: (value: T) => U,
): Result134<Entity134<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker134: Result134<number> = { ok: true, value: 134 };
