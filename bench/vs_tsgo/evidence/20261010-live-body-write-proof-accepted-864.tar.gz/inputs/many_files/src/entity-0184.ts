export interface Entity184<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity184<U>;
}

export type Result184<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap184<T> = T extends Result184<infer U, unknown> ? U : never;

export function transform184<T, U>(
  input: Entity184<T>,
  fn: (value: T) => U,
): Result184<Entity184<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker184: Result184<number> = { ok: true, value: 184 };
