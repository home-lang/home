export interface Entity125<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity125<U>;
}

export type Result125<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap125<T> = T extends Result125<infer U, unknown> ? U : never;

export function transform125<T, U>(
  input: Entity125<T>,
  fn: (value: T) => U,
): Result125<Entity125<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker125: Result125<number> = { ok: true, value: 125 };
