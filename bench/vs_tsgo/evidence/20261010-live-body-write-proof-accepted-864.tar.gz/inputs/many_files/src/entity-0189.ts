export interface Entity189<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity189<U>;
}

export type Result189<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap189<T> = T extends Result189<infer U, unknown> ? U : never;

export function transform189<T, U>(
  input: Entity189<T>,
  fn: (value: T) => U,
): Result189<Entity189<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker189: Result189<number> = { ok: true, value: 189 };
