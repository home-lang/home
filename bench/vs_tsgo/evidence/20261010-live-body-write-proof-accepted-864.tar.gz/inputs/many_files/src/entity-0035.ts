export interface Entity35<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity35<U>;
}

export type Result35<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap35<T> = T extends Result35<infer U, unknown> ? U : never;

export function transform35<T, U>(
  input: Entity35<T>,
  fn: (value: T) => U,
): Result35<Entity35<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker35: Result35<number> = { ok: true, value: 35 };
