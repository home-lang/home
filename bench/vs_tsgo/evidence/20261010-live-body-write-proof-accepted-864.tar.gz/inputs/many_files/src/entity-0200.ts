export interface Entity200<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity200<U>;
}

export type Result200<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap200<T> = T extends Result200<infer U, unknown> ? U : never;

export function transform200<T, U>(
  input: Entity200<T>,
  fn: (value: T) => U,
): Result200<Entity200<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker200: Result200<number> = { ok: true, value: 200 };
