export interface Entity102<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity102<U>;
}

export type Result102<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap102<T> = T extends Result102<infer U, unknown> ? U : never;

export function transform102<T, U>(
  input: Entity102<T>,
  fn: (value: T) => U,
): Result102<Entity102<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker102: Result102<number> = { ok: true, value: 102 };
