export interface Entity28<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity28<U>;
}

export type Result28<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap28<T> = T extends Result28<infer U, unknown> ? U : never;

export function transform28<T, U>(
  input: Entity28<T>,
  fn: (value: T) => U,
): Result28<Entity28<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker28: Result28<number> = { ok: true, value: 28 };
