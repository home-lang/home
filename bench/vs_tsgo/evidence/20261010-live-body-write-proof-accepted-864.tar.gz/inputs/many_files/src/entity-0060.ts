export interface Entity60<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity60<U>;
}

export type Result60<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap60<T> = T extends Result60<infer U, unknown> ? U : never;

export function transform60<T, U>(
  input: Entity60<T>,
  fn: (value: T) => U,
): Result60<Entity60<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker60: Result60<number> = { ok: true, value: 60 };
