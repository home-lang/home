export interface Entity188<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity188<U>;
}

export type Result188<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap188<T> = T extends Result188<infer U, unknown> ? U : never;

export function transform188<T, U>(
  input: Entity188<T>,
  fn: (value: T) => U,
): Result188<Entity188<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker188: Result188<number> = { ok: true, value: 188 };
