export interface Entity98<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity98<U>;
}

export type Result98<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap98<T> = T extends Result98<infer U, unknown> ? U : never;

export function transform98<T, U>(
  input: Entity98<T>,
  fn: (value: T) => U,
): Result98<Entity98<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker98: Result98<number> = { ok: true, value: 98 };
