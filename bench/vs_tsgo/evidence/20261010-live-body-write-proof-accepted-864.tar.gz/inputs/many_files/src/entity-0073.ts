export interface Entity73<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity73<U>;
}

export type Result73<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap73<T> = T extends Result73<infer U, unknown> ? U : never;

export function transform73<T, U>(
  input: Entity73<T>,
  fn: (value: T) => U,
): Result73<Entity73<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker73: Result73<number> = { ok: true, value: 73 };
