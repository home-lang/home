export interface Entity41<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity41<U>;
}

export type Result41<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap41<T> = T extends Result41<infer U, unknown> ? U : never;

export function transform41<T, U>(
  input: Entity41<T>,
  fn: (value: T) => U,
): Result41<Entity41<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker41: Result41<number> = { ok: true, value: 41 };
