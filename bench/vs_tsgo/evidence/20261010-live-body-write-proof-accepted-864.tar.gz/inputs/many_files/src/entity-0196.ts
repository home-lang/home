export interface Entity196<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity196<U>;
}

export type Result196<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap196<T> = T extends Result196<infer U, unknown> ? U : never;

export function transform196<T, U>(
  input: Entity196<T>,
  fn: (value: T) => U,
): Result196<Entity196<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker196: Result196<number> = { ok: true, value: 196 };
