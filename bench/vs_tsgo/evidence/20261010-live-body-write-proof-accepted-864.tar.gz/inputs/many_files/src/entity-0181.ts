export interface Entity181<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity181<U>;
}

export type Result181<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap181<T> = T extends Result181<infer U, unknown> ? U : never;

export function transform181<T, U>(
  input: Entity181<T>,
  fn: (value: T) => U,
): Result181<Entity181<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker181: Result181<number> = { ok: true, value: 181 };
