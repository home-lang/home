export interface Entity206<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity206<U>;
}

export type Result206<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap206<T> = T extends Result206<infer U, unknown> ? U : never;

export function transform206<T, U>(
  input: Entity206<T>,
  fn: (value: T) => U,
): Result206<Entity206<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker206: Result206<number> = { ok: true, value: 206 };
