export interface Entity139<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity139<U>;
}

export type Result139<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap139<T> = T extends Result139<infer U, unknown> ? U : never;

export function transform139<T, U>(
  input: Entity139<T>,
  fn: (value: T) => U,
): Result139<Entity139<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker139: Result139<number> = { ok: true, value: 139 };
