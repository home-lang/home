export interface Entity171<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity171<U>;
}

export type Result171<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap171<T> = T extends Result171<infer U, unknown> ? U : never;

export function transform171<T, U>(
  input: Entity171<T>,
  fn: (value: T) => U,
): Result171<Entity171<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker171: Result171<number> = { ok: true, value: 171 };
