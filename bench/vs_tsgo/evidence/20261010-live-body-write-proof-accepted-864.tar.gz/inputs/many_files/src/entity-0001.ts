export interface Entity1<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity1<U>;
}

export type Result1<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap1<T> = T extends Result1<infer U, unknown> ? U : never;

export function transform1<T, U>(
  input: Entity1<T>,
  fn: (value: T) => U,
): Result1<Entity1<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker1: Result1<number> = { ok: true, value: 1 };
