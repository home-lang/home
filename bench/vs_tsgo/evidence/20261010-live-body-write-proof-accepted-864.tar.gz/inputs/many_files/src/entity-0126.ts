export interface Entity126<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity126<U>;
}

export type Result126<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap126<T> = T extends Result126<infer U, unknown> ? U : never;

export function transform126<T, U>(
  input: Entity126<T>,
  fn: (value: T) => U,
): Result126<Entity126<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker126: Result126<number> = { ok: true, value: 126 };
