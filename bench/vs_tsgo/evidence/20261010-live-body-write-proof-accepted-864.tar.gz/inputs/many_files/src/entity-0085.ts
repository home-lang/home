export interface Entity85<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity85<U>;
}

export type Result85<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap85<T> = T extends Result85<infer U, unknown> ? U : never;

export function transform85<T, U>(
  input: Entity85<T>,
  fn: (value: T) => U,
): Result85<Entity85<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker85: Result85<number> = { ok: true, value: 85 };
