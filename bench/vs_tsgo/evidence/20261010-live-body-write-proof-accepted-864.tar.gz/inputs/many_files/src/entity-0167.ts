export interface Entity167<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity167<U>;
}

export type Result167<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap167<T> = T extends Result167<infer U, unknown> ? U : never;

export function transform167<T, U>(
  input: Entity167<T>,
  fn: (value: T) => U,
): Result167<Entity167<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker167: Result167<number> = { ok: true, value: 167 };
