export interface Entity111<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity111<U>;
}

export type Result111<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap111<T> = T extends Result111<infer U, unknown> ? U : never;

export function transform111<T, U>(
  input: Entity111<T>,
  fn: (value: T) => U,
): Result111<Entity111<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker111: Result111<number> = { ok: true, value: 111 };
