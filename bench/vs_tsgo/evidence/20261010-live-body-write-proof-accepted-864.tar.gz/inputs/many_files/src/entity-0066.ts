export interface Entity66<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity66<U>;
}

export type Result66<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap66<T> = T extends Result66<infer U, unknown> ? U : never;

export function transform66<T, U>(
  input: Entity66<T>,
  fn: (value: T) => U,
): Result66<Entity66<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker66: Result66<number> = { ok: true, value: 66 };
