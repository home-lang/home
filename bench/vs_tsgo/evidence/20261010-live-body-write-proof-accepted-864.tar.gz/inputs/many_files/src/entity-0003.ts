export interface Entity3<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity3<U>;
}

export type Result3<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap3<T> = T extends Result3<infer U, unknown> ? U : never;

export function transform3<T, U>(
  input: Entity3<T>,
  fn: (value: T) => U,
): Result3<Entity3<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker3: Result3<number> = { ok: true, value: 3 };
