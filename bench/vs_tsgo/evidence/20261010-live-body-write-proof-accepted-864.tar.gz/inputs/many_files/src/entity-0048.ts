export interface Entity48<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity48<U>;
}

export type Result48<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap48<T> = T extends Result48<infer U, unknown> ? U : never;

export function transform48<T, U>(
  input: Entity48<T>,
  fn: (value: T) => U,
): Result48<Entity48<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker48: Result48<number> = { ok: true, value: 48 };
