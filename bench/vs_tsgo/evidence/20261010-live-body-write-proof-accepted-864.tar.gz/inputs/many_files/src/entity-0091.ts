export interface Entity91<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity91<U>;
}

export type Result91<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap91<T> = T extends Result91<infer U, unknown> ? U : never;

export function transform91<T, U>(
  input: Entity91<T>,
  fn: (value: T) => U,
): Result91<Entity91<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker91: Result91<number> = { ok: true, value: 91 };
