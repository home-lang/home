export interface Entity58<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity58<U>;
}

export type Result58<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap58<T> = T extends Result58<infer U, unknown> ? U : never;

export function transform58<T, U>(
  input: Entity58<T>,
  fn: (value: T) => U,
): Result58<Entity58<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker58: Result58<number> = { ok: true, value: 58 };
