export interface Entity117<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity117<U>;
}

export type Result117<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap117<T> = T extends Result117<infer U, unknown> ? U : never;

export function transform117<T, U>(
  input: Entity117<T>,
  fn: (value: T) => U,
): Result117<Entity117<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker117: Result117<number> = { ok: true, value: 117 };
