export interface Entity77<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity77<U>;
}

export type Result77<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap77<T> = T extends Result77<infer U, unknown> ? U : never;

export function transform77<T, U>(
  input: Entity77<T>,
  fn: (value: T) => U,
): Result77<Entity77<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker77: Result77<number> = { ok: true, value: 77 };
