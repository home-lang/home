export interface Entity4<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity4<U>;
}

export type Result4<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap4<T> = T extends Result4<infer U, unknown> ? U : never;

export function transform4<T, U>(
  input: Entity4<T>,
  fn: (value: T) => U,
): Result4<Entity4<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker4: Result4<number> = { ok: true, value: 4 };
