export interface Entity130<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity130<U>;
}

export type Result130<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap130<T> = T extends Result130<infer U, unknown> ? U : never;

export function transform130<T, U>(
  input: Entity130<T>,
  fn: (value: T) => U,
): Result130<Entity130<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker130: Result130<number> = { ok: true, value: 130 };
