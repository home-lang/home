export interface Entity80<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity80<U>;
}

export type Result80<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap80<T> = T extends Result80<infer U, unknown> ? U : never;

export function transform80<T, U>(
  input: Entity80<T>,
  fn: (value: T) => U,
): Result80<Entity80<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker80: Result80<number> = { ok: true, value: 80 };
