export interface Entity161<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity161<U>;
}

export type Result161<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap161<T> = T extends Result161<infer U, unknown> ? U : never;

export function transform161<T, U>(
  input: Entity161<T>,
  fn: (value: T) => U,
): Result161<Entity161<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker161: Result161<number> = { ok: true, value: 161 };
