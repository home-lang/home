export interface Entity177<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity177<U>;
}

export type Result177<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap177<T> = T extends Result177<infer U, unknown> ? U : never;

export function transform177<T, U>(
  input: Entity177<T>,
  fn: (value: T) => U,
): Result177<Entity177<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker177: Result177<number> = { ok: true, value: 177 };
