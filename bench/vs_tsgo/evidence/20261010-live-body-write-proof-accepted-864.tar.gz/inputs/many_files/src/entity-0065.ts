export interface Entity65<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity65<U>;
}

export type Result65<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap65<T> = T extends Result65<infer U, unknown> ? U : never;

export function transform65<T, U>(
  input: Entity65<T>,
  fn: (value: T) => U,
): Result65<Entity65<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker65: Result65<number> = { ok: true, value: 65 };
