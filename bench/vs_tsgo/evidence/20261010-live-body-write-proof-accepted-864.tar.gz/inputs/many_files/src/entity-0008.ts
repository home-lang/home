export interface Entity8<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity8<U>;
}

export type Result8<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap8<T> = T extends Result8<infer U, unknown> ? U : never;

export function transform8<T, U>(
  input: Entity8<T>,
  fn: (value: T) => U,
): Result8<Entity8<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker8: Result8<number> = { ok: true, value: 8 };
