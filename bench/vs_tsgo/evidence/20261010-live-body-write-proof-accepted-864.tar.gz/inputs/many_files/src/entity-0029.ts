export interface Entity29<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity29<U>;
}

export type Result29<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap29<T> = T extends Result29<infer U, unknown> ? U : never;

export function transform29<T, U>(
  input: Entity29<T>,
  fn: (value: T) => U,
): Result29<Entity29<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker29: Result29<number> = { ok: true, value: 29 };
