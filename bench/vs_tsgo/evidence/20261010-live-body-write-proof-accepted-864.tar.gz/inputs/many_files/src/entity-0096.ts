export interface Entity96<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity96<U>;
}

export type Result96<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap96<T> = T extends Result96<infer U, unknown> ? U : never;

export function transform96<T, U>(
  input: Entity96<T>,
  fn: (value: T) => U,
): Result96<Entity96<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker96: Result96<number> = { ok: true, value: 96 };
