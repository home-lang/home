export interface Entity113<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity113<U>;
}

export type Result113<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap113<T> = T extends Result113<infer U, unknown> ? U : never;

export function transform113<T, U>(
  input: Entity113<T>,
  fn: (value: T) => U,
): Result113<Entity113<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker113: Result113<number> = { ok: true, value: 113 };
