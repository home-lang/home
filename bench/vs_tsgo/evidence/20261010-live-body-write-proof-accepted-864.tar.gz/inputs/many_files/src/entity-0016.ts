export interface Entity16<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity16<U>;
}

export type Result16<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap16<T> = T extends Result16<infer U, unknown> ? U : never;

export function transform16<T, U>(
  input: Entity16<T>,
  fn: (value: T) => U,
): Result16<Entity16<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker16: Result16<number> = { ok: true, value: 16 };
