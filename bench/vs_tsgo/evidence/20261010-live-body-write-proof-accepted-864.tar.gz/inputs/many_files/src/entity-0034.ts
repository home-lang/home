export interface Entity34<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity34<U>;
}

export type Result34<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap34<T> = T extends Result34<infer U, unknown> ? U : never;

export function transform34<T, U>(
  input: Entity34<T>,
  fn: (value: T) => U,
): Result34<Entity34<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker34: Result34<number> = { ok: true, value: 34 };
