export interface Entity89<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity89<U>;
}

export type Result89<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap89<T> = T extends Result89<infer U, unknown> ? U : never;

export function transform89<T, U>(
  input: Entity89<T>,
  fn: (value: T) => U,
): Result89<Entity89<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker89: Result89<number> = { ok: true, value: 89 };
