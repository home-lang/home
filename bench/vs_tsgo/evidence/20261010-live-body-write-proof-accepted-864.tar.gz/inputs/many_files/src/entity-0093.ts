export interface Entity93<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity93<U>;
}

export type Result93<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap93<T> = T extends Result93<infer U, unknown> ? U : never;

export function transform93<T, U>(
  input: Entity93<T>,
  fn: (value: T) => U,
): Result93<Entity93<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker93: Result93<number> = { ok: true, value: 93 };
