export interface Entity148<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity148<U>;
}

export type Result148<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap148<T> = T extends Result148<infer U, unknown> ? U : never;

export function transform148<T, U>(
  input: Entity148<T>,
  fn: (value: T) => U,
): Result148<Entity148<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker148: Result148<number> = { ok: true, value: 148 };
