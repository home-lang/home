export interface Entity50<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity50<U>;
}

export type Result50<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap50<T> = T extends Result50<infer U, unknown> ? U : never;

export function transform50<T, U>(
  input: Entity50<T>,
  fn: (value: T) => U,
): Result50<Entity50<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker50: Result50<number> = { ok: true, value: 50 };
