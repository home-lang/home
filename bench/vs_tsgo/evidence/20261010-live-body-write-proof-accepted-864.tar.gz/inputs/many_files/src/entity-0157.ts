export interface Entity157<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity157<U>;
}

export type Result157<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap157<T> = T extends Result157<infer U, unknown> ? U : never;

export function transform157<T, U>(
  input: Entity157<T>,
  fn: (value: T) => U,
): Result157<Entity157<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker157: Result157<number> = { ok: true, value: 157 };
