export interface Entity15<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity15<U>;
}

export type Result15<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap15<T> = T extends Result15<infer U, unknown> ? U : never;

export function transform15<T, U>(
  input: Entity15<T>,
  fn: (value: T) => U,
): Result15<Entity15<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker15: Result15<number> = { ok: true, value: 15 };
