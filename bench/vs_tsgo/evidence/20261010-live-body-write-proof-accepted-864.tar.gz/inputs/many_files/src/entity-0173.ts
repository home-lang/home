export interface Entity173<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity173<U>;
}

export type Result173<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap173<T> = T extends Result173<infer U, unknown> ? U : never;

export function transform173<T, U>(
  input: Entity173<T>,
  fn: (value: T) => U,
): Result173<Entity173<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker173: Result173<number> = { ok: true, value: 173 };
