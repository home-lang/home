export interface Entity187<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity187<U>;
}

export type Result187<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap187<T> = T extends Result187<infer U, unknown> ? U : never;

export function transform187<T, U>(
  input: Entity187<T>,
  fn: (value: T) => U,
): Result187<Entity187<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker187: Result187<number> = { ok: true, value: 187 };
