export interface Entity145<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity145<U>;
}

export type Result145<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap145<T> = T extends Result145<infer U, unknown> ? U : never;

export function transform145<T, U>(
  input: Entity145<T>,
  fn: (value: T) => U,
): Result145<Entity145<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker145: Result145<number> = { ok: true, value: 145 };
