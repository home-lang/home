export interface Entity70<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity70<U>;
}

export type Result70<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap70<T> = T extends Result70<infer U, unknown> ? U : never;

export function transform70<T, U>(
  input: Entity70<T>,
  fn: (value: T) => U,
): Result70<Entity70<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker70: Result70<number> = { ok: true, value: 70 };
