export interface Entity112<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity112<U>;
}

export type Result112<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap112<T> = T extends Result112<infer U, unknown> ? U : never;

export function transform112<T, U>(
  input: Entity112<T>,
  fn: (value: T) => U,
): Result112<Entity112<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker112: Result112<number> = { ok: true, value: 112 };
