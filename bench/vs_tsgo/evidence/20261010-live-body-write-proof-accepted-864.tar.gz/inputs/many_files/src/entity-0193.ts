export interface Entity193<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity193<U>;
}

export type Result193<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap193<T> = T extends Result193<infer U, unknown> ? U : never;

export function transform193<T, U>(
  input: Entity193<T>,
  fn: (value: T) => U,
): Result193<Entity193<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker193: Result193<number> = { ok: true, value: 193 };
