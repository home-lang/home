export interface Entity97<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity97<U>;
}

export type Result97<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap97<T> = T extends Result97<infer U, unknown> ? U : never;

export function transform97<T, U>(
  input: Entity97<T>,
  fn: (value: T) => U,
): Result97<Entity97<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker97: Result97<number> = { ok: true, value: 97 };
