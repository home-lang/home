export interface Entity10<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity10<U>;
}

export type Result10<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap10<T> = T extends Result10<infer U, unknown> ? U : never;

export function transform10<T, U>(
  input: Entity10<T>,
  fn: (value: T) => U,
): Result10<Entity10<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker10: Result10<number> = { ok: true, value: 10 };
