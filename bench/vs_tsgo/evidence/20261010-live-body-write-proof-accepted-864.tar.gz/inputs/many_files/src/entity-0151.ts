export interface Entity151<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity151<U>;
}

export type Result151<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap151<T> = T extends Result151<infer U, unknown> ? U : never;

export function transform151<T, U>(
  input: Entity151<T>,
  fn: (value: T) => U,
): Result151<Entity151<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker151: Result151<number> = { ok: true, value: 151 };
