export interface Entity119<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity119<U>;
}

export type Result119<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap119<T> = T extends Result119<infer U, unknown> ? U : never;

export function transform119<T, U>(
  input: Entity119<T>,
  fn: (value: T) => U,
): Result119<Entity119<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker119: Result119<number> = { ok: true, value: 119 };
