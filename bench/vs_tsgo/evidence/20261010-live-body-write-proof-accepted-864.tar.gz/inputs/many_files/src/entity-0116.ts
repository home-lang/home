export interface Entity116<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity116<U>;
}

export type Result116<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap116<T> = T extends Result116<infer U, unknown> ? U : never;

export function transform116<T, U>(
  input: Entity116<T>,
  fn: (value: T) => U,
): Result116<Entity116<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker116: Result116<number> = { ok: true, value: 116 };
