export interface Entity69<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity69<U>;
}

export type Result69<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap69<T> = T extends Result69<infer U, unknown> ? U : never;

export function transform69<T, U>(
  input: Entity69<T>,
  fn: (value: T) => U,
): Result69<Entity69<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker69: Result69<number> = { ok: true, value: 69 };
