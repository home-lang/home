export interface Entity67<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity67<U>;
}

export type Result67<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap67<T> = T extends Result67<infer U, unknown> ? U : never;

export function transform67<T, U>(
  input: Entity67<T>,
  fn: (value: T) => U,
): Result67<Entity67<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker67: Result67<number> = { ok: true, value: 67 };
