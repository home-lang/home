export interface Entity42<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity42<U>;
}

export type Result42<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap42<T> = T extends Result42<infer U, unknown> ? U : never;

export function transform42<T, U>(
  input: Entity42<T>,
  fn: (value: T) => U,
): Result42<Entity42<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker42: Result42<number> = { ok: true, value: 42 };
