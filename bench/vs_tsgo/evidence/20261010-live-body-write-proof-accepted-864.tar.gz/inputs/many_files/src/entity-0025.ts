export interface Entity25<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity25<U>;
}

export type Result25<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap25<T> = T extends Result25<infer U, unknown> ? U : never;

export function transform25<T, U>(
  input: Entity25<T>,
  fn: (value: T) => U,
): Result25<Entity25<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker25: Result25<number> = { ok: true, value: 25 };
