export interface Entity5<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity5<U>;
}

export type Result5<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap5<T> = T extends Result5<infer U, unknown> ? U : never;

export function transform5<T, U>(
  input: Entity5<T>,
  fn: (value: T) => U,
): Result5<Entity5<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker5: Result5<number> = { ok: true, value: 5 };
