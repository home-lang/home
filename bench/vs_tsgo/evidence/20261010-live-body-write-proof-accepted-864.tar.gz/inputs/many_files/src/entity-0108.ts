export interface Entity108<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity108<U>;
}

export type Result108<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap108<T> = T extends Result108<infer U, unknown> ? U : never;

export function transform108<T, U>(
  input: Entity108<T>,
  fn: (value: T) => U,
): Result108<Entity108<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker108: Result108<number> = { ok: true, value: 108 };
