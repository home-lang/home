export interface Entity92<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity92<U>;
}

export type Result92<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap92<T> = T extends Result92<infer U, unknown> ? U : never;

export function transform92<T, U>(
  input: Entity92<T>,
  fn: (value: T) => U,
): Result92<Entity92<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker92: Result92<number> = { ok: true, value: 92 };
