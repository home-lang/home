export interface Entity152<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity152<U>;
}

export type Result152<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap152<T> = T extends Result152<infer U, unknown> ? U : never;

export function transform152<T, U>(
  input: Entity152<T>,
  fn: (value: T) => U,
): Result152<Entity152<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker152: Result152<number> = { ok: true, value: 152 };
