export interface Entity57<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity57<U>;
}

export type Result57<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap57<T> = T extends Result57<infer U, unknown> ? U : never;

export function transform57<T, U>(
  input: Entity57<T>,
  fn: (value: T) => U,
): Result57<Entity57<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker57: Result57<number> = { ok: true, value: 57 };
