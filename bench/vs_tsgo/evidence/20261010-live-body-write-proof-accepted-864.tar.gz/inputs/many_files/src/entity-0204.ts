export interface Entity204<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity204<U>;
}

export type Result204<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap204<T> = T extends Result204<infer U, unknown> ? U : never;

export function transform204<T, U>(
  input: Entity204<T>,
  fn: (value: T) => U,
): Result204<Entity204<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker204: Result204<number> = { ok: true, value: 204 };
