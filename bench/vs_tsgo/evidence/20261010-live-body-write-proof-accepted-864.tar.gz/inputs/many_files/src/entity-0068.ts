export interface Entity68<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity68<U>;
}

export type Result68<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap68<T> = T extends Result68<infer U, unknown> ? U : never;

export function transform68<T, U>(
  input: Entity68<T>,
  fn: (value: T) => U,
): Result68<Entity68<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker68: Result68<number> = { ok: true, value: 68 };
