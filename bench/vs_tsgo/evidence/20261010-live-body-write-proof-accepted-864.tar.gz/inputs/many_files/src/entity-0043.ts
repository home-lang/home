export interface Entity43<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity43<U>;
}

export type Result43<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap43<T> = T extends Result43<infer U, unknown> ? U : never;

export function transform43<T, U>(
  input: Entity43<T>,
  fn: (value: T) => U,
): Result43<Entity43<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker43: Result43<number> = { ok: true, value: 43 };
