export interface Entity59<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity59<U>;
}

export type Result59<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap59<T> = T extends Result59<infer U, unknown> ? U : never;

export function transform59<T, U>(
  input: Entity59<T>,
  fn: (value: T) => U,
): Result59<Entity59<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker59: Result59<number> = { ok: true, value: 59 };
