export interface Entity0<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity0<U>;
}

export type Result0<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap0<T> = T extends Result0<infer U, unknown> ? U : never;

export function transform0<T, U>(
  input: Entity0<T>,
  fn: (value: T) => U,
): Result0<Entity0<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker0: Result0<number> = { ok: true, value: 0 };
