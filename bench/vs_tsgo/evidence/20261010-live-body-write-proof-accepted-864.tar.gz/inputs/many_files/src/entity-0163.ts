export interface Entity163<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity163<U>;
}

export type Result163<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap163<T> = T extends Result163<infer U, unknown> ? U : never;

export function transform163<T, U>(
  input: Entity163<T>,
  fn: (value: T) => U,
): Result163<Entity163<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker163: Result163<number> = { ok: true, value: 163 };
