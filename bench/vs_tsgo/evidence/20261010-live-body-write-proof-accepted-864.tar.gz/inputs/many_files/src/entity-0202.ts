export interface Entity202<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity202<U>;
}

export type Result202<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap202<T> = T extends Result202<infer U, unknown> ? U : never;

export function transform202<T, U>(
  input: Entity202<T>,
  fn: (value: T) => U,
): Result202<Entity202<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker202: Result202<number> = { ok: true, value: 202 };
