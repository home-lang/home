export interface Entity37<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity37<U>;
}

export type Result37<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap37<T> = T extends Result37<infer U, unknown> ? U : never;

export function transform37<T, U>(
  input: Entity37<T>,
  fn: (value: T) => U,
): Result37<Entity37<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker37: Result37<number> = { ok: true, value: 37 };
