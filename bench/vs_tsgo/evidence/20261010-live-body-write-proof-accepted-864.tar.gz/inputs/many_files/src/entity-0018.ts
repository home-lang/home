export interface Entity18<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity18<U>;
}

export type Result18<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap18<T> = T extends Result18<infer U, unknown> ? U : never;

export function transform18<T, U>(
  input: Entity18<T>,
  fn: (value: T) => U,
): Result18<Entity18<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker18: Result18<number> = { ok: true, value: 18 };
