export interface Entity159<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity159<U>;
}

export type Result159<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap159<T> = T extends Result159<infer U, unknown> ? U : never;

export function transform159<T, U>(
  input: Entity159<T>,
  fn: (value: T) => U,
): Result159<Entity159<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker159: Result159<number> = { ok: true, value: 159 };
