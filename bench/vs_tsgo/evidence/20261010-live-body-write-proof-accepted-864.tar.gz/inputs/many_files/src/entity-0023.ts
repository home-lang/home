export interface Entity23<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity23<U>;
}

export type Result23<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap23<T> = T extends Result23<infer U, unknown> ? U : never;

export function transform23<T, U>(
  input: Entity23<T>,
  fn: (value: T) => U,
): Result23<Entity23<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker23: Result23<number> = { ok: true, value: 23 };
