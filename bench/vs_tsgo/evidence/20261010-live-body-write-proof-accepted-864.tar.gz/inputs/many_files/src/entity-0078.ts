export interface Entity78<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity78<U>;
}

export type Result78<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap78<T> = T extends Result78<infer U, unknown> ? U : never;

export function transform78<T, U>(
  input: Entity78<T>,
  fn: (value: T) => U,
): Result78<Entity78<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker78: Result78<number> = { ok: true, value: 78 };
