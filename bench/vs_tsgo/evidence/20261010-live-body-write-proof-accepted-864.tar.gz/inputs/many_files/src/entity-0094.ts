export interface Entity94<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity94<U>;
}

export type Result94<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap94<T> = T extends Result94<infer U, unknown> ? U : never;

export function transform94<T, U>(
  input: Entity94<T>,
  fn: (value: T) => U,
): Result94<Entity94<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker94: Result94<number> = { ok: true, value: 94 };
