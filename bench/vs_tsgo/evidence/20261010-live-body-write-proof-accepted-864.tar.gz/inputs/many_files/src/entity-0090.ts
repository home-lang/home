export interface Entity90<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity90<U>;
}

export type Result90<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap90<T> = T extends Result90<infer U, unknown> ? U : never;

export function transform90<T, U>(
  input: Entity90<T>,
  fn: (value: T) => U,
): Result90<Entity90<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker90: Result90<number> = { ok: true, value: 90 };
