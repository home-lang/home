export interface Entity99<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity99<U>;
}

export type Result99<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap99<T> = T extends Result99<infer U, unknown> ? U : never;

export function transform99<T, U>(
  input: Entity99<T>,
  fn: (value: T) => U,
): Result99<Entity99<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker99: Result99<number> = { ok: true, value: 99 };
