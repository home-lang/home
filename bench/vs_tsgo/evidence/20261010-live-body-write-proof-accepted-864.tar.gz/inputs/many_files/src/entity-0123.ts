export interface Entity123<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity123<U>;
}

export type Result123<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap123<T> = T extends Result123<infer U, unknown> ? U : never;

export function transform123<T, U>(
  input: Entity123<T>,
  fn: (value: T) => U,
): Result123<Entity123<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker123: Result123<number> = { ok: true, value: 123 };
