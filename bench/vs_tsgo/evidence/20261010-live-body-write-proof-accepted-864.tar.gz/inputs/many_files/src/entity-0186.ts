export interface Entity186<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity186<U>;
}

export type Result186<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap186<T> = T extends Result186<infer U, unknown> ? U : never;

export function transform186<T, U>(
  input: Entity186<T>,
  fn: (value: T) => U,
): Result186<Entity186<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker186: Result186<number> = { ok: true, value: 186 };
