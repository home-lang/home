export interface Entity135<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity135<U>;
}

export type Result135<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap135<T> = T extends Result135<infer U, unknown> ? U : never;

export function transform135<T, U>(
  input: Entity135<T>,
  fn: (value: T) => U,
): Result135<Entity135<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker135: Result135<number> = { ok: true, value: 135 };
