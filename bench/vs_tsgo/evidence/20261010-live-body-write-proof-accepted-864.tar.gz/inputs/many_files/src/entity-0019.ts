export interface Entity19<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity19<U>;
}

export type Result19<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap19<T> = T extends Result19<infer U, unknown> ? U : never;

export function transform19<T, U>(
  input: Entity19<T>,
  fn: (value: T) => U,
): Result19<Entity19<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker19: Result19<number> = { ok: true, value: 19 };
