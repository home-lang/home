export interface Entity106<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity106<U>;
}

export type Result106<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap106<T> = T extends Result106<infer U, unknown> ? U : never;

export function transform106<T, U>(
  input: Entity106<T>,
  fn: (value: T) => U,
): Result106<Entity106<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker106: Result106<number> = { ok: true, value: 106 };
