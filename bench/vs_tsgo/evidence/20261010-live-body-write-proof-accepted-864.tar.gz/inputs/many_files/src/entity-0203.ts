export interface Entity203<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity203<U>;
}

export type Result203<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap203<T> = T extends Result203<infer U, unknown> ? U : never;

export function transform203<T, U>(
  input: Entity203<T>,
  fn: (value: T) => U,
): Result203<Entity203<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker203: Result203<number> = { ok: true, value: 203 };
