export interface Entity168<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity168<U>;
}

export type Result168<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap168<T> = T extends Result168<infer U, unknown> ? U : never;

export function transform168<T, U>(
  input: Entity168<T>,
  fn: (value: T) => U,
): Result168<Entity168<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker168: Result168<number> = { ok: true, value: 168 };
