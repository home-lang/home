export interface Entity153<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity153<U>;
}

export type Result153<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap153<T> = T extends Result153<infer U, unknown> ? U : never;

export function transform153<T, U>(
  input: Entity153<T>,
  fn: (value: T) => U,
): Result153<Entity153<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker153: Result153<number> = { ok: true, value: 153 };
