export interface Entity53<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity53<U>;
}

export type Result53<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap53<T> = T extends Result53<infer U, unknown> ? U : never;

export function transform53<T, U>(
  input: Entity53<T>,
  fn: (value: T) => U,
): Result53<Entity53<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker53: Result53<number> = { ok: true, value: 53 };
