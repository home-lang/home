export interface Entity175<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity175<U>;
}

export type Result175<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap175<T> = T extends Result175<infer U, unknown> ? U : never;

export function transform175<T, U>(
  input: Entity175<T>,
  fn: (value: T) => U,
): Result175<Entity175<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker175: Result175<number> = { ok: true, value: 175 };
