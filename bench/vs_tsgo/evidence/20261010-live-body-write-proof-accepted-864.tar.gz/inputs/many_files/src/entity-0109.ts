export interface Entity109<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity109<U>;
}

export type Result109<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap109<T> = T extends Result109<infer U, unknown> ? U : never;

export function transform109<T, U>(
  input: Entity109<T>,
  fn: (value: T) => U,
): Result109<Entity109<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker109: Result109<number> = { ok: true, value: 109 };
