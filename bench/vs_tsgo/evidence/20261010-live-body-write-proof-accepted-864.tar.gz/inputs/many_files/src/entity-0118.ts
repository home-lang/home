export interface Entity118<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity118<U>;
}

export type Result118<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap118<T> = T extends Result118<infer U, unknown> ? U : never;

export function transform118<T, U>(
  input: Entity118<T>,
  fn: (value: T) => U,
): Result118<Entity118<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker118: Result118<number> = { ok: true, value: 118 };
