export interface Entity74<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity74<U>;
}

export type Result74<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap74<T> = T extends Result74<infer U, unknown> ? U : never;

export function transform74<T, U>(
  input: Entity74<T>,
  fn: (value: T) => U,
): Result74<Entity74<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker74: Result74<number> = { ok: true, value: 74 };
