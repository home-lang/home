export interface Entity114<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity114<U>;
}

export type Result114<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap114<T> = T extends Result114<infer U, unknown> ? U : never;

export function transform114<T, U>(
  input: Entity114<T>,
  fn: (value: T) => U,
): Result114<Entity114<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker114: Result114<number> = { ok: true, value: 114 };
