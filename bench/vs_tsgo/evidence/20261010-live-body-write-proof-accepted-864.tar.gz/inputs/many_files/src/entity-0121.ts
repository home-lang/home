export interface Entity121<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity121<U>;
}

export type Result121<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap121<T> = T extends Result121<infer U, unknown> ? U : never;

export function transform121<T, U>(
  input: Entity121<T>,
  fn: (value: T) => U,
): Result121<Entity121<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker121: Result121<number> = { ok: true, value: 121 };
