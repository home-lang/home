export interface Entity64<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity64<U>;
}

export type Result64<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap64<T> = T extends Result64<infer U, unknown> ? U : never;

export function transform64<T, U>(
  input: Entity64<T>,
  fn: (value: T) => U,
): Result64<Entity64<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker64: Result64<number> = { ok: true, value: 64 };
