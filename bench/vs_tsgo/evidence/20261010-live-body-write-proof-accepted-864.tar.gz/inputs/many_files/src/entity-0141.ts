export interface Entity141<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity141<U>;
}

export type Result141<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap141<T> = T extends Result141<infer U, unknown> ? U : never;

export function transform141<T, U>(
  input: Entity141<T>,
  fn: (value: T) => U,
): Result141<Entity141<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker141: Result141<number> = { ok: true, value: 141 };
