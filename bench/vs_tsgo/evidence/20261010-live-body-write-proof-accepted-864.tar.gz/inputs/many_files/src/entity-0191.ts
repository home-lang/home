export interface Entity191<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity191<U>;
}

export type Result191<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap191<T> = T extends Result191<infer U, unknown> ? U : never;

export function transform191<T, U>(
  input: Entity191<T>,
  fn: (value: T) => U,
): Result191<Entity191<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker191: Result191<number> = { ok: true, value: 191 };
