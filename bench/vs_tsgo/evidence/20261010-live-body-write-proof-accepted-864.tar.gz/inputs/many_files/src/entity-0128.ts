export interface Entity128<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity128<U>;
}

export type Result128<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap128<T> = T extends Result128<infer U, unknown> ? U : never;

export function transform128<T, U>(
  input: Entity128<T>,
  fn: (value: T) => U,
): Result128<Entity128<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker128: Result128<number> = { ok: true, value: 128 };
