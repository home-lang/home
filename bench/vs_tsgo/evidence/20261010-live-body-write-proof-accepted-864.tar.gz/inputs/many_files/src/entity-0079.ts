export interface Entity79<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity79<U>;
}

export type Result79<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap79<T> = T extends Result79<infer U, unknown> ? U : never;

export function transform79<T, U>(
  input: Entity79<T>,
  fn: (value: T) => U,
): Result79<Entity79<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker79: Result79<number> = { ok: true, value: 79 };
