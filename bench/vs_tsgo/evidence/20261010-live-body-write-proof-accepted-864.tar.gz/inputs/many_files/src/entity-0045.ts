export interface Entity45<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity45<U>;
}

export type Result45<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap45<T> = T extends Result45<infer U, unknown> ? U : never;

export function transform45<T, U>(
  input: Entity45<T>,
  fn: (value: T) => U,
): Result45<Entity45<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker45: Result45<number> = { ok: true, value: 45 };
