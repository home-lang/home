export interface Entity136<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity136<U>;
}

export type Result136<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap136<T> = T extends Result136<infer U, unknown> ? U : never;

export function transform136<T, U>(
  input: Entity136<T>,
  fn: (value: T) => U,
): Result136<Entity136<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker136: Result136<number> = { ok: true, value: 136 };
