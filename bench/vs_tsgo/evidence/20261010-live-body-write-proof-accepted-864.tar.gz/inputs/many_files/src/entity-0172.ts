export interface Entity172<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity172<U>;
}

export type Result172<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap172<T> = T extends Result172<infer U, unknown> ? U : never;

export function transform172<T, U>(
  input: Entity172<T>,
  fn: (value: T) => U,
): Result172<Entity172<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker172: Result172<number> = { ok: true, value: 172 };
