export interface Entity62<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity62<U>;
}

export type Result62<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap62<T> = T extends Result62<infer U, unknown> ? U : never;

export function transform62<T, U>(
  input: Entity62<T>,
  fn: (value: T) => U,
): Result62<Entity62<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker62: Result62<number> = { ok: true, value: 62 };
