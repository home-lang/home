export interface Entity101<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity101<U>;
}

export type Result101<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap101<T> = T extends Result101<infer U, unknown> ? U : never;

export function transform101<T, U>(
  input: Entity101<T>,
  fn: (value: T) => U,
): Result101<Entity101<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker101: Result101<number> = { ok: true, value: 101 };
