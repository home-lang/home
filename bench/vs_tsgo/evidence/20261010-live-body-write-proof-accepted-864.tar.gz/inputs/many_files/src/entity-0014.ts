export interface Entity14<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity14<U>;
}

export type Result14<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap14<T> = T extends Result14<infer U, unknown> ? U : never;

export function transform14<T, U>(
  input: Entity14<T>,
  fn: (value: T) => U,
): Result14<Entity14<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker14: Result14<number> = { ok: true, value: 14 };
