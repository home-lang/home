export interface Entity164<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity164<U>;
}

export type Result164<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap164<T> = T extends Result164<infer U, unknown> ? U : never;

export function transform164<T, U>(
  input: Entity164<T>,
  fn: (value: T) => U,
): Result164<Entity164<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker164: Result164<number> = { ok: true, value: 164 };
