export interface Entity127<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity127<U>;
}

export type Result127<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap127<T> = T extends Result127<infer U, unknown> ? U : never;

export function transform127<T, U>(
  input: Entity127<T>,
  fn: (value: T) => U,
): Result127<Entity127<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker127: Result127<number> = { ok: true, value: 127 };
