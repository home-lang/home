export interface Entity115<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity115<U>;
}

export type Result115<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap115<T> = T extends Result115<infer U, unknown> ? U : never;

export function transform115<T, U>(
  input: Entity115<T>,
  fn: (value: T) => U,
): Result115<Entity115<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker115: Result115<number> = { ok: true, value: 115 };
