export interface Entity105<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity105<U>;
}

export type Result105<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap105<T> = T extends Result105<infer U, unknown> ? U : never;

export function transform105<T, U>(
  input: Entity105<T>,
  fn: (value: T) => U,
): Result105<Entity105<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker105: Result105<number> = { ok: true, value: 105 };
