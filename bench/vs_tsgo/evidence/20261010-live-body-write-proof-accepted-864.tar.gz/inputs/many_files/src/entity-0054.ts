export interface Entity54<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity54<U>;
}

export type Result54<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap54<T> = T extends Result54<infer U, unknown> ? U : never;

export function transform54<T, U>(
  input: Entity54<T>,
  fn: (value: T) => U,
): Result54<Entity54<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker54: Result54<number> = { ok: true, value: 54 };
