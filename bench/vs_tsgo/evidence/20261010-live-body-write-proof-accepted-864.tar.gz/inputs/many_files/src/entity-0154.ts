export interface Entity154<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity154<U>;
}

export type Result154<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap154<T> = T extends Result154<infer U, unknown> ? U : never;

export function transform154<T, U>(
  input: Entity154<T>,
  fn: (value: T) => U,
): Result154<Entity154<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker154: Result154<number> = { ok: true, value: 154 };
