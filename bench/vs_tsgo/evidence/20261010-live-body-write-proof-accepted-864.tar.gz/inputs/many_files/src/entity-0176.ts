export interface Entity176<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity176<U>;
}

export type Result176<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap176<T> = T extends Result176<infer U, unknown> ? U : never;

export function transform176<T, U>(
  input: Entity176<T>,
  fn: (value: T) => U,
): Result176<Entity176<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker176: Result176<number> = { ok: true, value: 176 };
