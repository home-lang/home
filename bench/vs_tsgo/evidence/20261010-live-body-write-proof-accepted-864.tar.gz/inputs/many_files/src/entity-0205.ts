export interface Entity205<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity205<U>;
}

export type Result205<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap205<T> = T extends Result205<infer U, unknown> ? U : never;

export function transform205<T, U>(
  input: Entity205<T>,
  fn: (value: T) => U,
): Result205<Entity205<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker205: Result205<number> = { ok: true, value: 205 };
