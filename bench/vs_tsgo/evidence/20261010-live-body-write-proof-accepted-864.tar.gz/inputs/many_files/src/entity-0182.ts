export interface Entity182<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity182<U>;
}

export type Result182<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap182<T> = T extends Result182<infer U, unknown> ? U : never;

export function transform182<T, U>(
  input: Entity182<T>,
  fn: (value: T) => U,
): Result182<Entity182<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker182: Result182<number> = { ok: true, value: 182 };
