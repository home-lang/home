export interface Entity31<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity31<U>;
}

export type Result31<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap31<T> = T extends Result31<infer U, unknown> ? U : never;

export function transform31<T, U>(
  input: Entity31<T>,
  fn: (value: T) => U,
): Result31<Entity31<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker31: Result31<number> = { ok: true, value: 31 };
