export interface Entity146<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity146<U>;
}

export type Result146<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap146<T> = T extends Result146<infer U, unknown> ? U : never;

export function transform146<T, U>(
  input: Entity146<T>,
  fn: (value: T) => U,
): Result146<Entity146<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker146: Result146<number> = { ok: true, value: 146 };
