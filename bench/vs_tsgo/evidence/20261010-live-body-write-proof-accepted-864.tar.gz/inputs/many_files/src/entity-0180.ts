export interface Entity180<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity180<U>;
}

export type Result180<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap180<T> = T extends Result180<infer U, unknown> ? U : never;

export function transform180<T, U>(
  input: Entity180<T>,
  fn: (value: T) => U,
): Result180<Entity180<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker180: Result180<number> = { ok: true, value: 180 };
