export interface Entity195<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity195<U>;
}

export type Result195<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap195<T> = T extends Result195<infer U, unknown> ? U : never;

export function transform195<T, U>(
  input: Entity195<T>,
  fn: (value: T) => U,
): Result195<Entity195<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker195: Result195<number> = { ok: true, value: 195 };
