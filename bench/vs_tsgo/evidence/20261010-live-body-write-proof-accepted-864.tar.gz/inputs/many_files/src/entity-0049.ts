export interface Entity49<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity49<U>;
}

export type Result49<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap49<T> = T extends Result49<infer U, unknown> ? U : never;

export function transform49<T, U>(
  input: Entity49<T>,
  fn: (value: T) => U,
): Result49<Entity49<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker49: Result49<number> = { ok: true, value: 49 };
