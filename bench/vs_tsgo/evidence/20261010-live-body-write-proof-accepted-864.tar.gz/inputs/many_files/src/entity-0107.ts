export interface Entity107<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity107<U>;
}

export type Result107<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap107<T> = T extends Result107<infer U, unknown> ? U : never;

export function transform107<T, U>(
  input: Entity107<T>,
  fn: (value: T) => U,
): Result107<Entity107<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker107: Result107<number> = { ok: true, value: 107 };
