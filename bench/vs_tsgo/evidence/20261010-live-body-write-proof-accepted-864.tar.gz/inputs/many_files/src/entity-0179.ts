export interface Entity179<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity179<U>;
}

export type Result179<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap179<T> = T extends Result179<infer U, unknown> ? U : never;

export function transform179<T, U>(
  input: Entity179<T>,
  fn: (value: T) => U,
): Result179<Entity179<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker179: Result179<number> = { ok: true, value: 179 };
