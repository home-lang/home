export interface Entity83<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity83<U>;
}

export type Result83<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap83<T> = T extends Result83<infer U, unknown> ? U : never;

export function transform83<T, U>(
  input: Entity83<T>,
  fn: (value: T) => U,
): Result83<Entity83<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker83: Result83<number> = { ok: true, value: 83 };
