export interface Entity183<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity183<U>;
}

export type Result183<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap183<T> = T extends Result183<infer U, unknown> ? U : never;

export function transform183<T, U>(
  input: Entity183<T>,
  fn: (value: T) => U,
): Result183<Entity183<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker183: Result183<number> = { ok: true, value: 183 };
