export interface Entity95<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity95<U>;
}

export type Result95<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap95<T> = T extends Result95<infer U, unknown> ? U : never;

export function transform95<T, U>(
  input: Entity95<T>,
  fn: (value: T) => U,
): Result95<Entity95<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker95: Result95<number> = { ok: true, value: 95 };
