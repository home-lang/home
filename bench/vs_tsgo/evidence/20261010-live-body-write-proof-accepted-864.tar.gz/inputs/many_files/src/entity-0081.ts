export interface Entity81<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity81<U>;
}

export type Result81<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap81<T> = T extends Result81<infer U, unknown> ? U : never;

export function transform81<T, U>(
  input: Entity81<T>,
  fn: (value: T) => U,
): Result81<Entity81<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker81: Result81<number> = { ok: true, value: 81 };
