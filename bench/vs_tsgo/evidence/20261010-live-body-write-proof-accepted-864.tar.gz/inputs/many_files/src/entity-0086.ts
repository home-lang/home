export interface Entity86<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity86<U>;
}

export type Result86<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap86<T> = T extends Result86<infer U, unknown> ? U : never;

export function transform86<T, U>(
  input: Entity86<T>,
  fn: (value: T) => U,
): Result86<Entity86<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker86: Result86<number> = { ok: true, value: 86 };
