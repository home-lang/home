export interface Entity71<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity71<U>;
}

export type Result71<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap71<T> = T extends Result71<infer U, unknown> ? U : never;

export function transform71<T, U>(
  input: Entity71<T>,
  fn: (value: T) => U,
): Result71<Entity71<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker71: Result71<number> = { ok: true, value: 71 };
