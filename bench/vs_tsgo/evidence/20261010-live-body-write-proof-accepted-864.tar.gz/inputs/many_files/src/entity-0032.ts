export interface Entity32<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity32<U>;
}

export type Result32<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap32<T> = T extends Result32<infer U, unknown> ? U : never;

export function transform32<T, U>(
  input: Entity32<T>,
  fn: (value: T) => U,
): Result32<Entity32<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker32: Result32<number> = { ok: true, value: 32 };
