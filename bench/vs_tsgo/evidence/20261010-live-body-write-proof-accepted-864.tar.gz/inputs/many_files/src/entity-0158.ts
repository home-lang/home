export interface Entity158<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity158<U>;
}

export type Result158<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap158<T> = T extends Result158<infer U, unknown> ? U : never;

export function transform158<T, U>(
  input: Entity158<T>,
  fn: (value: T) => U,
): Result158<Entity158<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker158: Result158<number> = { ok: true, value: 158 };
