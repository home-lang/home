export interface Entity30<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity30<U>;
}

export type Result30<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap30<T> = T extends Result30<infer U, unknown> ? U : never;

export function transform30<T, U>(
  input: Entity30<T>,
  fn: (value: T) => U,
): Result30<Entity30<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker30: Result30<number> = { ok: true, value: 30 };
