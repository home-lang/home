export interface Entity207<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity207<U>;
}

export type Result207<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap207<T> = T extends Result207<infer U, unknown> ? U : never;

export function transform207<T, U>(
  input: Entity207<T>,
  fn: (value: T) => U,
): Result207<Entity207<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker207: Result207<number> = { ok: true, value: 207 };
