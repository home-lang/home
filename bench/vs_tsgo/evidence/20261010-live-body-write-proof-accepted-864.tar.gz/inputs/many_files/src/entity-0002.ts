export interface Entity2<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity2<U>;
}

export type Result2<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap2<T> = T extends Result2<infer U, unknown> ? U : never;

export function transform2<T, U>(
  input: Entity2<T>,
  fn: (value: T) => U,
): Result2<Entity2<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker2: Result2<number> = { ok: true, value: 2 };
