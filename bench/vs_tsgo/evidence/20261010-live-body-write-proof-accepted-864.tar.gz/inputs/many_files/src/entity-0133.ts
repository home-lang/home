export interface Entity133<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity133<U>;
}

export type Result133<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap133<T> = T extends Result133<infer U, unknown> ? U : never;

export function transform133<T, U>(
  input: Entity133<T>,
  fn: (value: T) => U,
): Result133<Entity133<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker133: Result133<number> = { ok: true, value: 133 };
