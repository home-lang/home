export interface Entity197<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity197<U>;
}

export type Result197<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap197<T> = T extends Result197<infer U, unknown> ? U : never;

export function transform197<T, U>(
  input: Entity197<T>,
  fn: (value: T) => U,
): Result197<Entity197<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker197: Result197<number> = { ok: true, value: 197 };
