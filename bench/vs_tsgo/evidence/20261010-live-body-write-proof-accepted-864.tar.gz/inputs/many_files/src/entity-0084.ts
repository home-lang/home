export interface Entity84<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity84<U>;
}

export type Result84<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap84<T> = T extends Result84<infer U, unknown> ? U : never;

export function transform84<T, U>(
  input: Entity84<T>,
  fn: (value: T) => U,
): Result84<Entity84<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker84: Result84<number> = { ok: true, value: 84 };
