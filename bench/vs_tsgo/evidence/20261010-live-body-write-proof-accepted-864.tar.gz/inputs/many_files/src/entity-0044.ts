export interface Entity44<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity44<U>;
}

export type Result44<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap44<T> = T extends Result44<infer U, unknown> ? U : never;

export function transform44<T, U>(
  input: Entity44<T>,
  fn: (value: T) => U,
): Result44<Entity44<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker44: Result44<number> = { ok: true, value: 44 };
