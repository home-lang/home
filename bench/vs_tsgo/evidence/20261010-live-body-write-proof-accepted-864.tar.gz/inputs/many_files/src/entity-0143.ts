export interface Entity143<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity143<U>;
}

export type Result143<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap143<T> = T extends Result143<infer U, unknown> ? U : never;

export function transform143<T, U>(
  input: Entity143<T>,
  fn: (value: T) => U,
): Result143<Entity143<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker143: Result143<number> = { ok: true, value: 143 };
