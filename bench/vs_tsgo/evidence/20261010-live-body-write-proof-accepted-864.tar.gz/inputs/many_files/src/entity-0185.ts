export interface Entity185<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity185<U>;
}

export type Result185<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap185<T> = T extends Result185<infer U, unknown> ? U : never;

export function transform185<T, U>(
  input: Entity185<T>,
  fn: (value: T) => U,
): Result185<Entity185<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker185: Result185<number> = { ok: true, value: 185 };
