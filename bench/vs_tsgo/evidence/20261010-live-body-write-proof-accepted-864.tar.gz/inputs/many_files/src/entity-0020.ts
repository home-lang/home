export interface Entity20<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity20<U>;
}

export type Result20<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap20<T> = T extends Result20<infer U, unknown> ? U : never;

export function transform20<T, U>(
  input: Entity20<T>,
  fn: (value: T) => U,
): Result20<Entity20<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker20: Result20<number> = { ok: true, value: 20 };
