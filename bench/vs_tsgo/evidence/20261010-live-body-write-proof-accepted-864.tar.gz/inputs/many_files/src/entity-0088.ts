export interface Entity88<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity88<U>;
}

export type Result88<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap88<T> = T extends Result88<infer U, unknown> ? U : never;

export function transform88<T, U>(
  input: Entity88<T>,
  fn: (value: T) => U,
): Result88<Entity88<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker88: Result88<number> = { ok: true, value: 88 };
