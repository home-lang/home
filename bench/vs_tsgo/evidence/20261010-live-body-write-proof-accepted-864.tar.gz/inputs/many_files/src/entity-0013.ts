export interface Entity13<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity13<U>;
}

export type Result13<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap13<T> = T extends Result13<infer U, unknown> ? U : never;

export function transform13<T, U>(
  input: Entity13<T>,
  fn: (value: T) => U,
): Result13<Entity13<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker13: Result13<number> = { ok: true, value: 13 };
