export interface Entity120<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity120<U>;
}

export type Result120<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap120<T> = T extends Result120<infer U, unknown> ? U : never;

export function transform120<T, U>(
  input: Entity120<T>,
  fn: (value: T) => U,
): Result120<Entity120<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker120: Result120<number> = { ok: true, value: 120 };
