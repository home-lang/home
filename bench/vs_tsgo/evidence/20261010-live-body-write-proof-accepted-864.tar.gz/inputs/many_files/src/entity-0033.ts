export interface Entity33<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity33<U>;
}

export type Result33<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap33<T> = T extends Result33<infer U, unknown> ? U : never;

export function transform33<T, U>(
  input: Entity33<T>,
  fn: (value: T) => U,
): Result33<Entity33<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker33: Result33<number> = { ok: true, value: 33 };
