export interface Entity52<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity52<U>;
}

export type Result52<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap52<T> = T extends Result52<infer U, unknown> ? U : never;

export function transform52<T, U>(
  input: Entity52<T>,
  fn: (value: T) => U,
): Result52<Entity52<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker52: Result52<number> = { ok: true, value: 52 };
