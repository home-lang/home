export interface Entity56<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity56<U>;
}

export type Result56<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap56<T> = T extends Result56<infer U, unknown> ? U : never;

export function transform56<T, U>(
  input: Entity56<T>,
  fn: (value: T) => U,
): Result56<Entity56<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker56: Result56<number> = { ok: true, value: 56 };
