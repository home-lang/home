export interface Entity38<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity38<U>;
}

export type Result38<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap38<T> = T extends Result38<infer U, unknown> ? U : never;

export function transform38<T, U>(
  input: Entity38<T>,
  fn: (value: T) => U,
): Result38<Entity38<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker38: Result38<number> = { ok: true, value: 38 };
