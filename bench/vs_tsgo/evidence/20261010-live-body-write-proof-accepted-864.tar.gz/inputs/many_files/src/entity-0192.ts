export interface Entity192<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity192<U>;
}

export type Result192<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap192<T> = T extends Result192<infer U, unknown> ? U : never;

export function transform192<T, U>(
  input: Entity192<T>,
  fn: (value: T) => U,
): Result192<Entity192<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker192: Result192<number> = { ok: true, value: 192 };
