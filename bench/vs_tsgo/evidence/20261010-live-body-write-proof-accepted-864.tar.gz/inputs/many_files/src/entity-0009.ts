export interface Entity9<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity9<U>;
}

export type Result9<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap9<T> = T extends Result9<infer U, unknown> ? U : never;

export function transform9<T, U>(
  input: Entity9<T>,
  fn: (value: T) => U,
): Result9<Entity9<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker9: Result9<number> = { ok: true, value: 9 };
