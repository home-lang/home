export interface Entity174<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity174<U>;
}

export type Result174<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap174<T> = T extends Result174<infer U, unknown> ? U : never;

export function transform174<T, U>(
  input: Entity174<T>,
  fn: (value: T) => U,
): Result174<Entity174<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker174: Result174<number> = { ok: true, value: 174 };
