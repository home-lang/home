export interface Entity199<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity199<U>;
}

export type Result199<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap199<T> = T extends Result199<infer U, unknown> ? U : never;

export function transform199<T, U>(
  input: Entity199<T>,
  fn: (value: T) => U,
): Result199<Entity199<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker199: Result199<number> = { ok: true, value: 199 };
