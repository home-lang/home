export interface Entity55<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity55<U>;
}

export type Result55<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap55<T> = T extends Result55<infer U, unknown> ? U : never;

export function transform55<T, U>(
  input: Entity55<T>,
  fn: (value: T) => U,
): Result55<Entity55<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker55: Result55<number> = { ok: true, value: 55 };
