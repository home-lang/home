export interface Entity190<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity190<U>;
}

export type Result190<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap190<T> = T extends Result190<infer U, unknown> ? U : never;

export function transform190<T, U>(
  input: Entity190<T>,
  fn: (value: T) => U,
): Result190<Entity190<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker190: Result190<number> = { ok: true, value: 190 };
