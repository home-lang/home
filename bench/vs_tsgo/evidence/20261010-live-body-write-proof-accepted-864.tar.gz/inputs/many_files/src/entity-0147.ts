export interface Entity147<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity147<U>;
}

export type Result147<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap147<T> = T extends Result147<infer U, unknown> ? U : never;

export function transform147<T, U>(
  input: Entity147<T>,
  fn: (value: T) => U,
): Result147<Entity147<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker147: Result147<number> = { ok: true, value: 147 };
