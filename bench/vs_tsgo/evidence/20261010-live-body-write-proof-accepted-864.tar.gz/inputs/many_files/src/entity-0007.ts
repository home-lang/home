export interface Entity7<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity7<U>;
}

export type Result7<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap7<T> = T extends Result7<infer U, unknown> ? U : never;

export function transform7<T, U>(
  input: Entity7<T>,
  fn: (value: T) => U,
): Result7<Entity7<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker7: Result7<number> = { ok: true, value: 7 };
