export interface Entity131<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity131<U>;
}

export type Result131<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap131<T> = T extends Result131<infer U, unknown> ? U : never;

export function transform131<T, U>(
  input: Entity131<T>,
  fn: (value: T) => U,
): Result131<Entity131<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker131: Result131<number> = { ok: true, value: 131 };
