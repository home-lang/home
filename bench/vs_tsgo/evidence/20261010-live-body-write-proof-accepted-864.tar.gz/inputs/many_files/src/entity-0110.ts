export interface Entity110<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity110<U>;
}

export type Result110<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap110<T> = T extends Result110<infer U, unknown> ? U : never;

export function transform110<T, U>(
  input: Entity110<T>,
  fn: (value: T) => U,
): Result110<Entity110<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker110: Result110<number> = { ok: true, value: 110 };
