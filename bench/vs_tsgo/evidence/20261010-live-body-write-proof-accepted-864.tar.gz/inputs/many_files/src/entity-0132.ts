export interface Entity132<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity132<U>;
}

export type Result132<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap132<T> = T extends Result132<infer U, unknown> ? U : never;

export function transform132<T, U>(
  input: Entity132<T>,
  fn: (value: T) => U,
): Result132<Entity132<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker132: Result132<number> = { ok: true, value: 132 };
