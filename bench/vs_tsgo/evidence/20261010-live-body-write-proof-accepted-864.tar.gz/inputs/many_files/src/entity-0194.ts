export interface Entity194<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity194<U>;
}

export type Result194<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap194<T> = T extends Result194<infer U, unknown> ? U : never;

export function transform194<T, U>(
  input: Entity194<T>,
  fn: (value: T) => U,
): Result194<Entity194<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker194: Result194<number> = { ok: true, value: 194 };
