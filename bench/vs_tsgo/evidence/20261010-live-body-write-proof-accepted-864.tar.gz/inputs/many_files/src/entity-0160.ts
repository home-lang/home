export interface Entity160<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity160<U>;
}

export type Result160<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap160<T> = T extends Result160<infer U, unknown> ? U : never;

export function transform160<T, U>(
  input: Entity160<T>,
  fn: (value: T) => U,
): Result160<Entity160<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker160: Result160<number> = { ok: true, value: 160 };
