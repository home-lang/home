export interface Entity178<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity178<U>;
}

export type Result178<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap178<T> = T extends Result178<infer U, unknown> ? U : never;

export function transform178<T, U>(
  input: Entity178<T>,
  fn: (value: T) => U,
): Result178<Entity178<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker178: Result178<number> = { ok: true, value: 178 };
