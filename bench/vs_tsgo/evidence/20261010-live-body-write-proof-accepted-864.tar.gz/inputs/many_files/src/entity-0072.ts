export interface Entity72<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity72<U>;
}

export type Result72<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap72<T> = T extends Result72<infer U, unknown> ? U : never;

export function transform72<T, U>(
  input: Entity72<T>,
  fn: (value: T) => U,
): Result72<Entity72<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker72: Result72<number> = { ok: true, value: 72 };
