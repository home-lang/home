export interface Entity162<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity162<U>;
}

export type Result162<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap162<T> = T extends Result162<infer U, unknown> ? U : never;

export function transform162<T, U>(
  input: Entity162<T>,
  fn: (value: T) => U,
): Result162<Entity162<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker162: Result162<number> = { ok: true, value: 162 };
