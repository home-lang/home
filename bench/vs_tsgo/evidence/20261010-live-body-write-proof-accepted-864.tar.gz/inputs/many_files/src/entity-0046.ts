export interface Entity46<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity46<U>;
}

export type Result46<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap46<T> = T extends Result46<infer U, unknown> ? U : never;

export function transform46<T, U>(
  input: Entity46<T>,
  fn: (value: T) => U,
): Result46<Entity46<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker46: Result46<number> = { ok: true, value: 46 };
