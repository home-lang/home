export interface Entity12<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity12<U>;
}

export type Result12<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap12<T> = T extends Result12<infer U, unknown> ? U : never;

export function transform12<T, U>(
  input: Entity12<T>,
  fn: (value: T) => U,
): Result12<Entity12<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker12: Result12<number> = { ok: true, value: 12 };
