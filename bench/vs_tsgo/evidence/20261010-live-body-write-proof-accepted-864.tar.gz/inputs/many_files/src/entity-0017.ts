export interface Entity17<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity17<U>;
}

export type Result17<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap17<T> = T extends Result17<infer U, unknown> ? U : never;

export function transform17<T, U>(
  input: Entity17<T>,
  fn: (value: T) => U,
): Result17<Entity17<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker17: Result17<number> = { ok: true, value: 17 };
