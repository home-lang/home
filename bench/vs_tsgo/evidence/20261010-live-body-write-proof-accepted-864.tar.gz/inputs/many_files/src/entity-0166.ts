export interface Entity166<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity166<U>;
}

export type Result166<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap166<T> = T extends Result166<infer U, unknown> ? U : never;

export function transform166<T, U>(
  input: Entity166<T>,
  fn: (value: T) => U,
): Result166<Entity166<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker166: Result166<number> = { ok: true, value: 166 };
