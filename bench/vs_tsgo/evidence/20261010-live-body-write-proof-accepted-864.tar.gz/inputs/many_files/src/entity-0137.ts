export interface Entity137<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity137<U>;
}

export type Result137<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap137<T> = T extends Result137<infer U, unknown> ? U : never;

export function transform137<T, U>(
  input: Entity137<T>,
  fn: (value: T) => U,
): Result137<Entity137<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker137: Result137<number> = { ok: true, value: 137 };
