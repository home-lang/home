export interface Entity155<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity155<U>;
}

export type Result155<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap155<T> = T extends Result155<infer U, unknown> ? U : never;

export function transform155<T, U>(
  input: Entity155<T>,
  fn: (value: T) => U,
): Result155<Entity155<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker155: Result155<number> = { ok: true, value: 155 };
