export interface Entity82<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity82<U>;
}

export type Result82<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap82<T> = T extends Result82<infer U, unknown> ? U : never;

export function transform82<T, U>(
  input: Entity82<T>,
  fn: (value: T) => U,
): Result82<Entity82<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker82: Result82<number> = { ok: true, value: 82 };
