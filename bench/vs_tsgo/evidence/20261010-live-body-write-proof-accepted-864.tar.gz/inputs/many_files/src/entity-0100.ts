export interface Entity100<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity100<U>;
}

export type Result100<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap100<T> = T extends Result100<infer U, unknown> ? U : never;

export function transform100<T, U>(
  input: Entity100<T>,
  fn: (value: T) => U,
): Result100<Entity100<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker100: Result100<number> = { ok: true, value: 100 };
