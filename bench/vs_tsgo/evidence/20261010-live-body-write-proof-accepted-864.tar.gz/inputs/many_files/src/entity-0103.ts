export interface Entity103<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity103<U>;
}

export type Result103<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap103<T> = T extends Result103<infer U, unknown> ? U : never;

export function transform103<T, U>(
  input: Entity103<T>,
  fn: (value: T) => U,
): Result103<Entity103<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker103: Result103<number> = { ok: true, value: 103 };
