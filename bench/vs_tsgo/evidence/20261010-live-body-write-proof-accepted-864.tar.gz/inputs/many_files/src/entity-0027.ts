export interface Entity27<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity27<U>;
}

export type Result27<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap27<T> = T extends Result27<infer U, unknown> ? U : never;

export function transform27<T, U>(
  input: Entity27<T>,
  fn: (value: T) => U,
): Result27<Entity27<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker27: Result27<number> = { ok: true, value: 27 };
