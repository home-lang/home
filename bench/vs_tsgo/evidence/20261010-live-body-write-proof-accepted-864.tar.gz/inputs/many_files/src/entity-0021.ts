export interface Entity21<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity21<U>;
}

export type Result21<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap21<T> = T extends Result21<infer U, unknown> ? U : never;

export function transform21<T, U>(
  input: Entity21<T>,
  fn: (value: T) => U,
): Result21<Entity21<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker21: Result21<number> = { ok: true, value: 21 };
