export interface Entity76<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity76<U>;
}

export type Result76<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap76<T> = T extends Result76<infer U, unknown> ? U : never;

export function transform76<T, U>(
  input: Entity76<T>,
  fn: (value: T) => U,
): Result76<Entity76<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker76: Result76<number> = { ok: true, value: 76 };
