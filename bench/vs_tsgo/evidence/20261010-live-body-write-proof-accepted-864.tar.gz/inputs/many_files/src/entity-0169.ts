export interface Entity169<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity169<U>;
}

export type Result169<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap169<T> = T extends Result169<infer U, unknown> ? U : never;

export function transform169<T, U>(
  input: Entity169<T>,
  fn: (value: T) => U,
): Result169<Entity169<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker169: Result169<number> = { ok: true, value: 169 };
