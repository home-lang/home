export interface Entity138<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity138<U>;
}

export type Result138<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap138<T> = T extends Result138<infer U, unknown> ? U : never;

export function transform138<T, U>(
  input: Entity138<T>,
  fn: (value: T) => U,
): Result138<Entity138<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker138: Result138<number> = { ok: true, value: 138 };
