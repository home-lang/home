export interface Entity63<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity63<U>;
}

export type Result63<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap63<T> = T extends Result63<infer U, unknown> ? U : never;

export function transform63<T, U>(
  input: Entity63<T>,
  fn: (value: T) => U,
): Result63<Entity63<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker63: Result63<number> = { ok: true, value: 63 };
