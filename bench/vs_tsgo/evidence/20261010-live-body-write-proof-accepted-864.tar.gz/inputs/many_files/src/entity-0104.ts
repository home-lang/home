export interface Entity104<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity104<U>;
}

export type Result104<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap104<T> = T extends Result104<infer U, unknown> ? U : never;

export function transform104<T, U>(
  input: Entity104<T>,
  fn: (value: T) => U,
): Result104<Entity104<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker104: Result104<number> = { ok: true, value: 104 };
