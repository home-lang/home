export interface Entity47<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity47<U>;
}

export type Result47<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap47<T> = T extends Result47<infer U, unknown> ? U : never;

export function transform47<T, U>(
  input: Entity47<T>,
  fn: (value: T) => U,
): Result47<Entity47<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker47: Result47<number> = { ok: true, value: 47 };
