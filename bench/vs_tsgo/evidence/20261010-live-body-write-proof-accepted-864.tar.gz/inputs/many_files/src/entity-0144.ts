export interface Entity144<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity144<U>;
}

export type Result144<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap144<T> = T extends Result144<infer U, unknown> ? U : never;

export function transform144<T, U>(
  input: Entity144<T>,
  fn: (value: T) => U,
): Result144<Entity144<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker144: Result144<number> = { ok: true, value: 144 };
