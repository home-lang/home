export interface Entity6<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity6<U>;
}

export type Result6<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap6<T> = T extends Result6<infer U, unknown> ? U : never;

export function transform6<T, U>(
  input: Entity6<T>,
  fn: (value: T) => U,
): Result6<Entity6<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker6: Result6<number> = { ok: true, value: 6 };
