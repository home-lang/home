export interface Entity51<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity51<U>;
}

export type Result51<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap51<T> = T extends Result51<infer U, unknown> ? U : never;

export function transform51<T, U>(
  input: Entity51<T>,
  fn: (value: T) => U,
): Result51<Entity51<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker51: Result51<number> = { ok: true, value: 51 };
