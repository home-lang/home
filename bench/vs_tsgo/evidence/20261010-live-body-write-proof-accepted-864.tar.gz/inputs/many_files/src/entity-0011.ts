export interface Entity11<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity11<U>;
}

export type Result11<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap11<T> = T extends Result11<infer U, unknown> ? U : never;

export function transform11<T, U>(
  input: Entity11<T>,
  fn: (value: T) => U,
): Result11<Entity11<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker11: Result11<number> = { ok: true, value: 11 };
