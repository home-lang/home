export interface Entity156<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity156<U>;
}

export type Result156<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap156<T> = T extends Result156<infer U, unknown> ? U : never;

export function transform156<T, U>(
  input: Entity156<T>,
  fn: (value: T) => U,
): Result156<Entity156<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker156: Result156<number> = { ok: true, value: 156 };
