export interface Entity122<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity122<U>;
}

export type Result122<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap122<T> = T extends Result122<infer U, unknown> ? U : never;

export function transform122<T, U>(
  input: Entity122<T>,
  fn: (value: T) => U,
): Result122<Entity122<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker122: Result122<number> = { ok: true, value: 122 };
