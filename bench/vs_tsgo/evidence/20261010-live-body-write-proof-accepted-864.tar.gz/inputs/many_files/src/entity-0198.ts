export interface Entity198<T> {
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity198<U>;
}

export type Result198<T, E = string> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export type Unwrap198<T> = T extends Result198<infer U, unknown> ? U : never;

export function transform198<T, U>(
  input: Entity198<T>,
  fn: (value: T) => U,
): Result198<Entity198<U>> {
  return { ok: true, value: input.map(fn) };
}

export const marker198: Result198<number> = { ok: true, value: 198 };
