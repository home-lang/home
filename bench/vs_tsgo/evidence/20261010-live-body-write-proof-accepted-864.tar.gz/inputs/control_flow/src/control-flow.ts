type WorkflowEvent<N extends number> =
  | { readonly kind: "queued"; readonly id: N }
  | { readonly kind: "running"; readonly id: N; readonly progress: number }
  | { readonly kind: "complete"; readonly id: N; readonly output: { readonly label: string; readonly score: number } }
  | { readonly kind: "failed"; readonly id: N; readonly error: { readonly message: string; readonly retryable: boolean } };

interface Summary<N extends number> {
  readonly id: N;
  readonly label: string;
  readonly score: number;
  readonly terminal: boolean;
}

export function summarize0(event: WorkflowEvent<0>): Summary<0> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary0: Summary<0> = summarize0({
  kind: "complete", id: 0, output: { label: "item-0", score: 0 },
});

export function summarize1(event: WorkflowEvent<1>): Summary<1> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary1: Summary<1> = summarize1({
  kind: "complete", id: 1, output: { label: "item-1", score: 1 },
});

export function summarize2(event: WorkflowEvent<2>): Summary<2> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary2: Summary<2> = summarize2({
  kind: "complete", id: 2, output: { label: "item-2", score: 2 },
});

export function summarize3(event: WorkflowEvent<3>): Summary<3> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary3: Summary<3> = summarize3({
  kind: "complete", id: 3, output: { label: "item-3", score: 3 },
});

export function summarize4(event: WorkflowEvent<4>): Summary<4> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary4: Summary<4> = summarize4({
  kind: "complete", id: 4, output: { label: "item-4", score: 4 },
});

export function summarize5(event: WorkflowEvent<5>): Summary<5> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary5: Summary<5> = summarize5({
  kind: "complete", id: 5, output: { label: "item-5", score: 5 },
});

export function summarize6(event: WorkflowEvent<6>): Summary<6> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary6: Summary<6> = summarize6({
  kind: "complete", id: 6, output: { label: "item-6", score: 6 },
});

export function summarize7(event: WorkflowEvent<7>): Summary<7> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary7: Summary<7> = summarize7({
  kind: "complete", id: 7, output: { label: "item-7", score: 7 },
});

export function summarize8(event: WorkflowEvent<8>): Summary<8> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary8: Summary<8> = summarize8({
  kind: "complete", id: 8, output: { label: "item-8", score: 8 },
});

export function summarize9(event: WorkflowEvent<9>): Summary<9> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary9: Summary<9> = summarize9({
  kind: "complete", id: 9, output: { label: "item-9", score: 9 },
});

export function summarize10(event: WorkflowEvent<10>): Summary<10> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary10: Summary<10> = summarize10({
  kind: "complete", id: 10, output: { label: "item-10", score: 10 },
});

export function summarize11(event: WorkflowEvent<11>): Summary<11> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary11: Summary<11> = summarize11({
  kind: "complete", id: 11, output: { label: "item-11", score: 11 },
});

export function summarize12(event: WorkflowEvent<12>): Summary<12> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary12: Summary<12> = summarize12({
  kind: "complete", id: 12, output: { label: "item-12", score: 12 },
});

export function summarize13(event: WorkflowEvent<13>): Summary<13> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary13: Summary<13> = summarize13({
  kind: "complete", id: 13, output: { label: "item-13", score: 13 },
});

export function summarize14(event: WorkflowEvent<14>): Summary<14> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary14: Summary<14> = summarize14({
  kind: "complete", id: 14, output: { label: "item-14", score: 14 },
});

export function summarize15(event: WorkflowEvent<15>): Summary<15> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary15: Summary<15> = summarize15({
  kind: "complete", id: 15, output: { label: "item-15", score: 15 },
});

export function summarize16(event: WorkflowEvent<16>): Summary<16> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary16: Summary<16> = summarize16({
  kind: "complete", id: 16, output: { label: "item-16", score: 16 },
});

export function summarize17(event: WorkflowEvent<17>): Summary<17> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary17: Summary<17> = summarize17({
  kind: "complete", id: 17, output: { label: "item-17", score: 17 },
});

export function summarize18(event: WorkflowEvent<18>): Summary<18> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary18: Summary<18> = summarize18({
  kind: "complete", id: 18, output: { label: "item-18", score: 18 },
});

export function summarize19(event: WorkflowEvent<19>): Summary<19> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary19: Summary<19> = summarize19({
  kind: "complete", id: 19, output: { label: "item-19", score: 19 },
});

export function summarize20(event: WorkflowEvent<20>): Summary<20> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary20: Summary<20> = summarize20({
  kind: "complete", id: 20, output: { label: "item-20", score: 20 },
});

export function summarize21(event: WorkflowEvent<21>): Summary<21> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary21: Summary<21> = summarize21({
  kind: "complete", id: 21, output: { label: "item-21", score: 21 },
});

export function summarize22(event: WorkflowEvent<22>): Summary<22> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary22: Summary<22> = summarize22({
  kind: "complete", id: 22, output: { label: "item-22", score: 22 },
});

export function summarize23(event: WorkflowEvent<23>): Summary<23> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary23: Summary<23> = summarize23({
  kind: "complete", id: 23, output: { label: "item-23", score: 23 },
});

export function summarize24(event: WorkflowEvent<24>): Summary<24> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary24: Summary<24> = summarize24({
  kind: "complete", id: 24, output: { label: "item-24", score: 24 },
});

export function summarize25(event: WorkflowEvent<25>): Summary<25> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary25: Summary<25> = summarize25({
  kind: "complete", id: 25, output: { label: "item-25", score: 25 },
});

export function summarize26(event: WorkflowEvent<26>): Summary<26> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary26: Summary<26> = summarize26({
  kind: "complete", id: 26, output: { label: "item-26", score: 26 },
});

export function summarize27(event: WorkflowEvent<27>): Summary<27> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary27: Summary<27> = summarize27({
  kind: "complete", id: 27, output: { label: "item-27", score: 27 },
});

export function summarize28(event: WorkflowEvent<28>): Summary<28> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary28: Summary<28> = summarize28({
  kind: "complete", id: 28, output: { label: "item-28", score: 28 },
});

export function summarize29(event: WorkflowEvent<29>): Summary<29> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary29: Summary<29> = summarize29({
  kind: "complete", id: 29, output: { label: "item-29", score: 29 },
});

export function summarize30(event: WorkflowEvent<30>): Summary<30> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary30: Summary<30> = summarize30({
  kind: "complete", id: 30, output: { label: "item-30", score: 30 },
});

export function summarize31(event: WorkflowEvent<31>): Summary<31> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary31: Summary<31> = summarize31({
  kind: "complete", id: 31, output: { label: "item-31", score: 31 },
});

export function summarize32(event: WorkflowEvent<32>): Summary<32> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary32: Summary<32> = summarize32({
  kind: "complete", id: 32, output: { label: "item-32", score: 32 },
});

export function summarize33(event: WorkflowEvent<33>): Summary<33> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary33: Summary<33> = summarize33({
  kind: "complete", id: 33, output: { label: "item-33", score: 33 },
});

export function summarize34(event: WorkflowEvent<34>): Summary<34> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary34: Summary<34> = summarize34({
  kind: "complete", id: 34, output: { label: "item-34", score: 34 },
});

export function summarize35(event: WorkflowEvent<35>): Summary<35> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary35: Summary<35> = summarize35({
  kind: "complete", id: 35, output: { label: "item-35", score: 35 },
});

export function summarize36(event: WorkflowEvent<36>): Summary<36> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary36: Summary<36> = summarize36({
  kind: "complete", id: 36, output: { label: "item-36", score: 36 },
});

export function summarize37(event: WorkflowEvent<37>): Summary<37> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary37: Summary<37> = summarize37({
  kind: "complete", id: 37, output: { label: "item-37", score: 37 },
});

export function summarize38(event: WorkflowEvent<38>): Summary<38> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary38: Summary<38> = summarize38({
  kind: "complete", id: 38, output: { label: "item-38", score: 38 },
});

export function summarize39(event: WorkflowEvent<39>): Summary<39> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary39: Summary<39> = summarize39({
  kind: "complete", id: 39, output: { label: "item-39", score: 39 },
});

export function summarize40(event: WorkflowEvent<40>): Summary<40> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary40: Summary<40> = summarize40({
  kind: "complete", id: 40, output: { label: "item-40", score: 40 },
});

export function summarize41(event: WorkflowEvent<41>): Summary<41> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary41: Summary<41> = summarize41({
  kind: "complete", id: 41, output: { label: "item-41", score: 41 },
});

export function summarize42(event: WorkflowEvent<42>): Summary<42> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary42: Summary<42> = summarize42({
  kind: "complete", id: 42, output: { label: "item-42", score: 42 },
});

export function summarize43(event: WorkflowEvent<43>): Summary<43> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary43: Summary<43> = summarize43({
  kind: "complete", id: 43, output: { label: "item-43", score: 43 },
});

export function summarize44(event: WorkflowEvent<44>): Summary<44> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary44: Summary<44> = summarize44({
  kind: "complete", id: 44, output: { label: "item-44", score: 44 },
});

export function summarize45(event: WorkflowEvent<45>): Summary<45> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary45: Summary<45> = summarize45({
  kind: "complete", id: 45, output: { label: "item-45", score: 45 },
});

export function summarize46(event: WorkflowEvent<46>): Summary<46> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary46: Summary<46> = summarize46({
  kind: "complete", id: 46, output: { label: "item-46", score: 46 },
});

export function summarize47(event: WorkflowEvent<47>): Summary<47> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary47: Summary<47> = summarize47({
  kind: "complete", id: 47, output: { label: "item-47", score: 47 },
});

export function summarize48(event: WorkflowEvent<48>): Summary<48> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary48: Summary<48> = summarize48({
  kind: "complete", id: 48, output: { label: "item-48", score: 48 },
});

export function summarize49(event: WorkflowEvent<49>): Summary<49> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary49: Summary<49> = summarize49({
  kind: "complete", id: 49, output: { label: "item-49", score: 49 },
});

export function summarize50(event: WorkflowEvent<50>): Summary<50> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary50: Summary<50> = summarize50({
  kind: "complete", id: 50, output: { label: "item-50", score: 50 },
});

export function summarize51(event: WorkflowEvent<51>): Summary<51> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary51: Summary<51> = summarize51({
  kind: "complete", id: 51, output: { label: "item-51", score: 51 },
});

export function summarize52(event: WorkflowEvent<52>): Summary<52> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary52: Summary<52> = summarize52({
  kind: "complete", id: 52, output: { label: "item-52", score: 52 },
});

export function summarize53(event: WorkflowEvent<53>): Summary<53> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary53: Summary<53> = summarize53({
  kind: "complete", id: 53, output: { label: "item-53", score: 53 },
});

export function summarize54(event: WorkflowEvent<54>): Summary<54> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary54: Summary<54> = summarize54({
  kind: "complete", id: 54, output: { label: "item-54", score: 54 },
});

export function summarize55(event: WorkflowEvent<55>): Summary<55> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary55: Summary<55> = summarize55({
  kind: "complete", id: 55, output: { label: "item-55", score: 55 },
});

export function summarize56(event: WorkflowEvent<56>): Summary<56> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary56: Summary<56> = summarize56({
  kind: "complete", id: 56, output: { label: "item-56", score: 56 },
});

export function summarize57(event: WorkflowEvent<57>): Summary<57> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary57: Summary<57> = summarize57({
  kind: "complete", id: 57, output: { label: "item-57", score: 57 },
});

export function summarize58(event: WorkflowEvent<58>): Summary<58> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary58: Summary<58> = summarize58({
  kind: "complete", id: 58, output: { label: "item-58", score: 58 },
});

export function summarize59(event: WorkflowEvent<59>): Summary<59> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary59: Summary<59> = summarize59({
  kind: "complete", id: 59, output: { label: "item-59", score: 59 },
});

export function summarize60(event: WorkflowEvent<60>): Summary<60> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary60: Summary<60> = summarize60({
  kind: "complete", id: 60, output: { label: "item-60", score: 60 },
});

export function summarize61(event: WorkflowEvent<61>): Summary<61> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary61: Summary<61> = summarize61({
  kind: "complete", id: 61, output: { label: "item-61", score: 61 },
});

export function summarize62(event: WorkflowEvent<62>): Summary<62> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary62: Summary<62> = summarize62({
  kind: "complete", id: 62, output: { label: "item-62", score: 62 },
});

export function summarize63(event: WorkflowEvent<63>): Summary<63> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary63: Summary<63> = summarize63({
  kind: "complete", id: 63, output: { label: "item-63", score: 63 },
});

export function summarize64(event: WorkflowEvent<64>): Summary<64> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary64: Summary<64> = summarize64({
  kind: "complete", id: 64, output: { label: "item-64", score: 64 },
});

export function summarize65(event: WorkflowEvent<65>): Summary<65> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary65: Summary<65> = summarize65({
  kind: "complete", id: 65, output: { label: "item-65", score: 65 },
});

export function summarize66(event: WorkflowEvent<66>): Summary<66> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary66: Summary<66> = summarize66({
  kind: "complete", id: 66, output: { label: "item-66", score: 66 },
});

export function summarize67(event: WorkflowEvent<67>): Summary<67> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary67: Summary<67> = summarize67({
  kind: "complete", id: 67, output: { label: "item-67", score: 67 },
});

export function summarize68(event: WorkflowEvent<68>): Summary<68> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary68: Summary<68> = summarize68({
  kind: "complete", id: 68, output: { label: "item-68", score: 68 },
});

export function summarize69(event: WorkflowEvent<69>): Summary<69> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary69: Summary<69> = summarize69({
  kind: "complete", id: 69, output: { label: "item-69", score: 69 },
});

export function summarize70(event: WorkflowEvent<70>): Summary<70> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary70: Summary<70> = summarize70({
  kind: "complete", id: 70, output: { label: "item-70", score: 70 },
});

export function summarize71(event: WorkflowEvent<71>): Summary<71> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary71: Summary<71> = summarize71({
  kind: "complete", id: 71, output: { label: "item-71", score: 71 },
});

export function summarize72(event: WorkflowEvent<72>): Summary<72> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary72: Summary<72> = summarize72({
  kind: "complete", id: 72, output: { label: "item-72", score: 72 },
});

export function summarize73(event: WorkflowEvent<73>): Summary<73> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary73: Summary<73> = summarize73({
  kind: "complete", id: 73, output: { label: "item-73", score: 73 },
});

export function summarize74(event: WorkflowEvent<74>): Summary<74> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary74: Summary<74> = summarize74({
  kind: "complete", id: 74, output: { label: "item-74", score: 74 },
});

export function summarize75(event: WorkflowEvent<75>): Summary<75> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary75: Summary<75> = summarize75({
  kind: "complete", id: 75, output: { label: "item-75", score: 75 },
});

export function summarize76(event: WorkflowEvent<76>): Summary<76> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary76: Summary<76> = summarize76({
  kind: "complete", id: 76, output: { label: "item-76", score: 76 },
});

export function summarize77(event: WorkflowEvent<77>): Summary<77> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary77: Summary<77> = summarize77({
  kind: "complete", id: 77, output: { label: "item-77", score: 77 },
});

export function summarize78(event: WorkflowEvent<78>): Summary<78> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary78: Summary<78> = summarize78({
  kind: "complete", id: 78, output: { label: "item-78", score: 78 },
});

export function summarize79(event: WorkflowEvent<79>): Summary<79> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary79: Summary<79> = summarize79({
  kind: "complete", id: 79, output: { label: "item-79", score: 79 },
});

export function summarize80(event: WorkflowEvent<80>): Summary<80> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary80: Summary<80> = summarize80({
  kind: "complete", id: 80, output: { label: "item-80", score: 80 },
});

export function summarize81(event: WorkflowEvent<81>): Summary<81> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary81: Summary<81> = summarize81({
  kind: "complete", id: 81, output: { label: "item-81", score: 81 },
});

export function summarize82(event: WorkflowEvent<82>): Summary<82> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary82: Summary<82> = summarize82({
  kind: "complete", id: 82, output: { label: "item-82", score: 82 },
});

export function summarize83(event: WorkflowEvent<83>): Summary<83> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary83: Summary<83> = summarize83({
  kind: "complete", id: 83, output: { label: "item-83", score: 83 },
});

export function summarize84(event: WorkflowEvent<84>): Summary<84> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary84: Summary<84> = summarize84({
  kind: "complete", id: 84, output: { label: "item-84", score: 84 },
});

export function summarize85(event: WorkflowEvent<85>): Summary<85> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary85: Summary<85> = summarize85({
  kind: "complete", id: 85, output: { label: "item-85", score: 85 },
});

export function summarize86(event: WorkflowEvent<86>): Summary<86> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary86: Summary<86> = summarize86({
  kind: "complete", id: 86, output: { label: "item-86", score: 86 },
});

export function summarize87(event: WorkflowEvent<87>): Summary<87> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary87: Summary<87> = summarize87({
  kind: "complete", id: 87, output: { label: "item-87", score: 87 },
});

export function summarize88(event: WorkflowEvent<88>): Summary<88> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary88: Summary<88> = summarize88({
  kind: "complete", id: 88, output: { label: "item-88", score: 88 },
});

export function summarize89(event: WorkflowEvent<89>): Summary<89> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary89: Summary<89> = summarize89({
  kind: "complete", id: 89, output: { label: "item-89", score: 89 },
});

export function summarize90(event: WorkflowEvent<90>): Summary<90> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary90: Summary<90> = summarize90({
  kind: "complete", id: 90, output: { label: "item-90", score: 90 },
});

export function summarize91(event: WorkflowEvent<91>): Summary<91> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary91: Summary<91> = summarize91({
  kind: "complete", id: 91, output: { label: "item-91", score: 91 },
});

export function summarize92(event: WorkflowEvent<92>): Summary<92> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary92: Summary<92> = summarize92({
  kind: "complete", id: 92, output: { label: "item-92", score: 92 },
});

export function summarize93(event: WorkflowEvent<93>): Summary<93> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary93: Summary<93> = summarize93({
  kind: "complete", id: 93, output: { label: "item-93", score: 93 },
});

export function summarize94(event: WorkflowEvent<94>): Summary<94> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary94: Summary<94> = summarize94({
  kind: "complete", id: 94, output: { label: "item-94", score: 94 },
});

export function summarize95(event: WorkflowEvent<95>): Summary<95> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary95: Summary<95> = summarize95({
  kind: "complete", id: 95, output: { label: "item-95", score: 95 },
});

export function summarize96(event: WorkflowEvent<96>): Summary<96> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary96: Summary<96> = summarize96({
  kind: "complete", id: 96, output: { label: "item-96", score: 96 },
});

export function summarize97(event: WorkflowEvent<97>): Summary<97> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary97: Summary<97> = summarize97({
  kind: "complete", id: 97, output: { label: "item-97", score: 97 },
});

export function summarize98(event: WorkflowEvent<98>): Summary<98> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary98: Summary<98> = summarize98({
  kind: "complete", id: 98, output: { label: "item-98", score: 98 },
});

export function summarize99(event: WorkflowEvent<99>): Summary<99> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary99: Summary<99> = summarize99({
  kind: "complete", id: 99, output: { label: "item-99", score: 99 },
});

export function summarize100(event: WorkflowEvent<100>): Summary<100> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary100: Summary<100> = summarize100({
  kind: "complete", id: 100, output: { label: "item-100", score: 100 },
});

export function summarize101(event: WorkflowEvent<101>): Summary<101> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary101: Summary<101> = summarize101({
  kind: "complete", id: 101, output: { label: "item-101", score: 101 },
});

export function summarize102(event: WorkflowEvent<102>): Summary<102> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary102: Summary<102> = summarize102({
  kind: "complete", id: 102, output: { label: "item-102", score: 102 },
});

export function summarize103(event: WorkflowEvent<103>): Summary<103> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary103: Summary<103> = summarize103({
  kind: "complete", id: 103, output: { label: "item-103", score: 103 },
});

export function summarize104(event: WorkflowEvent<104>): Summary<104> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary104: Summary<104> = summarize104({
  kind: "complete", id: 104, output: { label: "item-104", score: 104 },
});

export function summarize105(event: WorkflowEvent<105>): Summary<105> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary105: Summary<105> = summarize105({
  kind: "complete", id: 105, output: { label: "item-105", score: 105 },
});

export function summarize106(event: WorkflowEvent<106>): Summary<106> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary106: Summary<106> = summarize106({
  kind: "complete", id: 106, output: { label: "item-106", score: 106 },
});

export function summarize107(event: WorkflowEvent<107>): Summary<107> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary107: Summary<107> = summarize107({
  kind: "complete", id: 107, output: { label: "item-107", score: 107 },
});

export function summarize108(event: WorkflowEvent<108>): Summary<108> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary108: Summary<108> = summarize108({
  kind: "complete", id: 108, output: { label: "item-108", score: 108 },
});

export function summarize109(event: WorkflowEvent<109>): Summary<109> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary109: Summary<109> = summarize109({
  kind: "complete", id: 109, output: { label: "item-109", score: 109 },
});

export function summarize110(event: WorkflowEvent<110>): Summary<110> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary110: Summary<110> = summarize110({
  kind: "complete", id: 110, output: { label: "item-110", score: 110 },
});

export function summarize111(event: WorkflowEvent<111>): Summary<111> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary111: Summary<111> = summarize111({
  kind: "complete", id: 111, output: { label: "item-111", score: 111 },
});

export function summarize112(event: WorkflowEvent<112>): Summary<112> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary112: Summary<112> = summarize112({
  kind: "complete", id: 112, output: { label: "item-112", score: 112 },
});

export function summarize113(event: WorkflowEvent<113>): Summary<113> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary113: Summary<113> = summarize113({
  kind: "complete", id: 113, output: { label: "item-113", score: 113 },
});

export function summarize114(event: WorkflowEvent<114>): Summary<114> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary114: Summary<114> = summarize114({
  kind: "complete", id: 114, output: { label: "item-114", score: 114 },
});

export function summarize115(event: WorkflowEvent<115>): Summary<115> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary115: Summary<115> = summarize115({
  kind: "complete", id: 115, output: { label: "item-115", score: 115 },
});

export function summarize116(event: WorkflowEvent<116>): Summary<116> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary116: Summary<116> = summarize116({
  kind: "complete", id: 116, output: { label: "item-116", score: 116 },
});

export function summarize117(event: WorkflowEvent<117>): Summary<117> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary117: Summary<117> = summarize117({
  kind: "complete", id: 117, output: { label: "item-117", score: 117 },
});

export function summarize118(event: WorkflowEvent<118>): Summary<118> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary118: Summary<118> = summarize118({
  kind: "complete", id: 118, output: { label: "item-118", score: 118 },
});

export function summarize119(event: WorkflowEvent<119>): Summary<119> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary119: Summary<119> = summarize119({
  kind: "complete", id: 119, output: { label: "item-119", score: 119 },
});

export function summarize120(event: WorkflowEvent<120>): Summary<120> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary120: Summary<120> = summarize120({
  kind: "complete", id: 120, output: { label: "item-120", score: 120 },
});

export function summarize121(event: WorkflowEvent<121>): Summary<121> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary121: Summary<121> = summarize121({
  kind: "complete", id: 121, output: { label: "item-121", score: 121 },
});

export function summarize122(event: WorkflowEvent<122>): Summary<122> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary122: Summary<122> = summarize122({
  kind: "complete", id: 122, output: { label: "item-122", score: 122 },
});

export function summarize123(event: WorkflowEvent<123>): Summary<123> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary123: Summary<123> = summarize123({
  kind: "complete", id: 123, output: { label: "item-123", score: 123 },
});

export function summarize124(event: WorkflowEvent<124>): Summary<124> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary124: Summary<124> = summarize124({
  kind: "complete", id: 124, output: { label: "item-124", score: 124 },
});

export function summarize125(event: WorkflowEvent<125>): Summary<125> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary125: Summary<125> = summarize125({
  kind: "complete", id: 125, output: { label: "item-125", score: 125 },
});

export function summarize126(event: WorkflowEvent<126>): Summary<126> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary126: Summary<126> = summarize126({
  kind: "complete", id: 126, output: { label: "item-126", score: 126 },
});

export function summarize127(event: WorkflowEvent<127>): Summary<127> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary127: Summary<127> = summarize127({
  kind: "complete", id: 127, output: { label: "item-127", score: 127 },
});

export function summarize128(event: WorkflowEvent<128>): Summary<128> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary128: Summary<128> = summarize128({
  kind: "complete", id: 128, output: { label: "item-128", score: 128 },
});

export function summarize129(event: WorkflowEvent<129>): Summary<129> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary129: Summary<129> = summarize129({
  kind: "complete", id: 129, output: { label: "item-129", score: 129 },
});

export function summarize130(event: WorkflowEvent<130>): Summary<130> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary130: Summary<130> = summarize130({
  kind: "complete", id: 130, output: { label: "item-130", score: 130 },
});

export function summarize131(event: WorkflowEvent<131>): Summary<131> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary131: Summary<131> = summarize131({
  kind: "complete", id: 131, output: { label: "item-131", score: 131 },
});

export function summarize132(event: WorkflowEvent<132>): Summary<132> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary132: Summary<132> = summarize132({
  kind: "complete", id: 132, output: { label: "item-132", score: 132 },
});

export function summarize133(event: WorkflowEvent<133>): Summary<133> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary133: Summary<133> = summarize133({
  kind: "complete", id: 133, output: { label: "item-133", score: 133 },
});

export function summarize134(event: WorkflowEvent<134>): Summary<134> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary134: Summary<134> = summarize134({
  kind: "complete", id: 134, output: { label: "item-134", score: 134 },
});

export function summarize135(event: WorkflowEvent<135>): Summary<135> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary135: Summary<135> = summarize135({
  kind: "complete", id: 135, output: { label: "item-135", score: 135 },
});

export function summarize136(event: WorkflowEvent<136>): Summary<136> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary136: Summary<136> = summarize136({
  kind: "complete", id: 136, output: { label: "item-136", score: 136 },
});

export function summarize137(event: WorkflowEvent<137>): Summary<137> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary137: Summary<137> = summarize137({
  kind: "complete", id: 137, output: { label: "item-137", score: 137 },
});

export function summarize138(event: WorkflowEvent<138>): Summary<138> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary138: Summary<138> = summarize138({
  kind: "complete", id: 138, output: { label: "item-138", score: 138 },
});

export function summarize139(event: WorkflowEvent<139>): Summary<139> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary139: Summary<139> = summarize139({
  kind: "complete", id: 139, output: { label: "item-139", score: 139 },
});

export function summarize140(event: WorkflowEvent<140>): Summary<140> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary140: Summary<140> = summarize140({
  kind: "complete", id: 140, output: { label: "item-140", score: 140 },
});

export function summarize141(event: WorkflowEvent<141>): Summary<141> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary141: Summary<141> = summarize141({
  kind: "complete", id: 141, output: { label: "item-141", score: 141 },
});

export function summarize142(event: WorkflowEvent<142>): Summary<142> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary142: Summary<142> = summarize142({
  kind: "complete", id: 142, output: { label: "item-142", score: 142 },
});

export function summarize143(event: WorkflowEvent<143>): Summary<143> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary143: Summary<143> = summarize143({
  kind: "complete", id: 143, output: { label: "item-143", score: 143 },
});

export function summarize144(event: WorkflowEvent<144>): Summary<144> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary144: Summary<144> = summarize144({
  kind: "complete", id: 144, output: { label: "item-144", score: 144 },
});

export function summarize145(event: WorkflowEvent<145>): Summary<145> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary145: Summary<145> = summarize145({
  kind: "complete", id: 145, output: { label: "item-145", score: 145 },
});

export function summarize146(event: WorkflowEvent<146>): Summary<146> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary146: Summary<146> = summarize146({
  kind: "complete", id: 146, output: { label: "item-146", score: 146 },
});

export function summarize147(event: WorkflowEvent<147>): Summary<147> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary147: Summary<147> = summarize147({
  kind: "complete", id: 147, output: { label: "item-147", score: 147 },
});

export function summarize148(event: WorkflowEvent<148>): Summary<148> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary148: Summary<148> = summarize148({
  kind: "complete", id: 148, output: { label: "item-148", score: 148 },
});

export function summarize149(event: WorkflowEvent<149>): Summary<149> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary149: Summary<149> = summarize149({
  kind: "complete", id: 149, output: { label: "item-149", score: 149 },
});

export function summarize150(event: WorkflowEvent<150>): Summary<150> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary150: Summary<150> = summarize150({
  kind: "complete", id: 150, output: { label: "item-150", score: 150 },
});

export function summarize151(event: WorkflowEvent<151>): Summary<151> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary151: Summary<151> = summarize151({
  kind: "complete", id: 151, output: { label: "item-151", score: 151 },
});

export function summarize152(event: WorkflowEvent<152>): Summary<152> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary152: Summary<152> = summarize152({
  kind: "complete", id: 152, output: { label: "item-152", score: 152 },
});

export function summarize153(event: WorkflowEvent<153>): Summary<153> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary153: Summary<153> = summarize153({
  kind: "complete", id: 153, output: { label: "item-153", score: 153 },
});

export function summarize154(event: WorkflowEvent<154>): Summary<154> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary154: Summary<154> = summarize154({
  kind: "complete", id: 154, output: { label: "item-154", score: 154 },
});

export function summarize155(event: WorkflowEvent<155>): Summary<155> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary155: Summary<155> = summarize155({
  kind: "complete", id: 155, output: { label: "item-155", score: 155 },
});

export function summarize156(event: WorkflowEvent<156>): Summary<156> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary156: Summary<156> = summarize156({
  kind: "complete", id: 156, output: { label: "item-156", score: 156 },
});

export function summarize157(event: WorkflowEvent<157>): Summary<157> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary157: Summary<157> = summarize157({
  kind: "complete", id: 157, output: { label: "item-157", score: 157 },
});

export function summarize158(event: WorkflowEvent<158>): Summary<158> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary158: Summary<158> = summarize158({
  kind: "complete", id: 158, output: { label: "item-158", score: 158 },
});

export function summarize159(event: WorkflowEvent<159>): Summary<159> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary159: Summary<159> = summarize159({
  kind: "complete", id: 159, output: { label: "item-159", score: 159 },
});

export function summarize160(event: WorkflowEvent<160>): Summary<160> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary160: Summary<160> = summarize160({
  kind: "complete", id: 160, output: { label: "item-160", score: 160 },
});

export function summarize161(event: WorkflowEvent<161>): Summary<161> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary161: Summary<161> = summarize161({
  kind: "complete", id: 161, output: { label: "item-161", score: 161 },
});

export function summarize162(event: WorkflowEvent<162>): Summary<162> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary162: Summary<162> = summarize162({
  kind: "complete", id: 162, output: { label: "item-162", score: 162 },
});

export function summarize163(event: WorkflowEvent<163>): Summary<163> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary163: Summary<163> = summarize163({
  kind: "complete", id: 163, output: { label: "item-163", score: 163 },
});

export function summarize164(event: WorkflowEvent<164>): Summary<164> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary164: Summary<164> = summarize164({
  kind: "complete", id: 164, output: { label: "item-164", score: 164 },
});

export function summarize165(event: WorkflowEvent<165>): Summary<165> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary165: Summary<165> = summarize165({
  kind: "complete", id: 165, output: { label: "item-165", score: 165 },
});

export function summarize166(event: WorkflowEvent<166>): Summary<166> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary166: Summary<166> = summarize166({
  kind: "complete", id: 166, output: { label: "item-166", score: 166 },
});

export function summarize167(event: WorkflowEvent<167>): Summary<167> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary167: Summary<167> = summarize167({
  kind: "complete", id: 167, output: { label: "item-167", score: 167 },
});

export function summarize168(event: WorkflowEvent<168>): Summary<168> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary168: Summary<168> = summarize168({
  kind: "complete", id: 168, output: { label: "item-168", score: 168 },
});

export function summarize169(event: WorkflowEvent<169>): Summary<169> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary169: Summary<169> = summarize169({
  kind: "complete", id: 169, output: { label: "item-169", score: 169 },
});

export function summarize170(event: WorkflowEvent<170>): Summary<170> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary170: Summary<170> = summarize170({
  kind: "complete", id: 170, output: { label: "item-170", score: 170 },
});

export function summarize171(event: WorkflowEvent<171>): Summary<171> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary171: Summary<171> = summarize171({
  kind: "complete", id: 171, output: { label: "item-171", score: 171 },
});

export function summarize172(event: WorkflowEvent<172>): Summary<172> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary172: Summary<172> = summarize172({
  kind: "complete", id: 172, output: { label: "item-172", score: 172 },
});

export function summarize173(event: WorkflowEvent<173>): Summary<173> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary173: Summary<173> = summarize173({
  kind: "complete", id: 173, output: { label: "item-173", score: 173 },
});

export function summarize174(event: WorkflowEvent<174>): Summary<174> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary174: Summary<174> = summarize174({
  kind: "complete", id: 174, output: { label: "item-174", score: 174 },
});

export function summarize175(event: WorkflowEvent<175>): Summary<175> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary175: Summary<175> = summarize175({
  kind: "complete", id: 175, output: { label: "item-175", score: 175 },
});

export function summarize176(event: WorkflowEvent<176>): Summary<176> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary176: Summary<176> = summarize176({
  kind: "complete", id: 176, output: { label: "item-176", score: 176 },
});

export function summarize177(event: WorkflowEvent<177>): Summary<177> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary177: Summary<177> = summarize177({
  kind: "complete", id: 177, output: { label: "item-177", score: 177 },
});

export function summarize178(event: WorkflowEvent<178>): Summary<178> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary178: Summary<178> = summarize178({
  kind: "complete", id: 178, output: { label: "item-178", score: 178 },
});

export function summarize179(event: WorkflowEvent<179>): Summary<179> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary179: Summary<179> = summarize179({
  kind: "complete", id: 179, output: { label: "item-179", score: 179 },
});

export function summarize180(event: WorkflowEvent<180>): Summary<180> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary180: Summary<180> = summarize180({
  kind: "complete", id: 180, output: { label: "item-180", score: 180 },
});

export function summarize181(event: WorkflowEvent<181>): Summary<181> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary181: Summary<181> = summarize181({
  kind: "complete", id: 181, output: { label: "item-181", score: 181 },
});

export function summarize182(event: WorkflowEvent<182>): Summary<182> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary182: Summary<182> = summarize182({
  kind: "complete", id: 182, output: { label: "item-182", score: 182 },
});

export function summarize183(event: WorkflowEvent<183>): Summary<183> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary183: Summary<183> = summarize183({
  kind: "complete", id: 183, output: { label: "item-183", score: 183 },
});

export function summarize184(event: WorkflowEvent<184>): Summary<184> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary184: Summary<184> = summarize184({
  kind: "complete", id: 184, output: { label: "item-184", score: 184 },
});

export function summarize185(event: WorkflowEvent<185>): Summary<185> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary185: Summary<185> = summarize185({
  kind: "complete", id: 185, output: { label: "item-185", score: 185 },
});

export function summarize186(event: WorkflowEvent<186>): Summary<186> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary186: Summary<186> = summarize186({
  kind: "complete", id: 186, output: { label: "item-186", score: 186 },
});

export function summarize187(event: WorkflowEvent<187>): Summary<187> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary187: Summary<187> = summarize187({
  kind: "complete", id: 187, output: { label: "item-187", score: 187 },
});

export function summarize188(event: WorkflowEvent<188>): Summary<188> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary188: Summary<188> = summarize188({
  kind: "complete", id: 188, output: { label: "item-188", score: 188 },
});

export function summarize189(event: WorkflowEvent<189>): Summary<189> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary189: Summary<189> = summarize189({
  kind: "complete", id: 189, output: { label: "item-189", score: 189 },
});

export function summarize190(event: WorkflowEvent<190>): Summary<190> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary190: Summary<190> = summarize190({
  kind: "complete", id: 190, output: { label: "item-190", score: 190 },
});

export function summarize191(event: WorkflowEvent<191>): Summary<191> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary191: Summary<191> = summarize191({
  kind: "complete", id: 191, output: { label: "item-191", score: 191 },
});

export function summarize192(event: WorkflowEvent<192>): Summary<192> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary192: Summary<192> = summarize192({
  kind: "complete", id: 192, output: { label: "item-192", score: 192 },
});

export function summarize193(event: WorkflowEvent<193>): Summary<193> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary193: Summary<193> = summarize193({
  kind: "complete", id: 193, output: { label: "item-193", score: 193 },
});

export function summarize194(event: WorkflowEvent<194>): Summary<194> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary194: Summary<194> = summarize194({
  kind: "complete", id: 194, output: { label: "item-194", score: 194 },
});

export function summarize195(event: WorkflowEvent<195>): Summary<195> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary195: Summary<195> = summarize195({
  kind: "complete", id: 195, output: { label: "item-195", score: 195 },
});

export function summarize196(event: WorkflowEvent<196>): Summary<196> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary196: Summary<196> = summarize196({
  kind: "complete", id: 196, output: { label: "item-196", score: 196 },
});

export function summarize197(event: WorkflowEvent<197>): Summary<197> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary197: Summary<197> = summarize197({
  kind: "complete", id: 197, output: { label: "item-197", score: 197 },
});

export function summarize198(event: WorkflowEvent<198>): Summary<198> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary198: Summary<198> = summarize198({
  kind: "complete", id: 198, output: { label: "item-198", score: 198 },
});

export function summarize199(event: WorkflowEvent<199>): Summary<199> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary199: Summary<199> = summarize199({
  kind: "complete", id: 199, output: { label: "item-199", score: 199 },
});

export function summarize200(event: WorkflowEvent<200>): Summary<200> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary200: Summary<200> = summarize200({
  kind: "complete", id: 200, output: { label: "item-200", score: 200 },
});

export function summarize201(event: WorkflowEvent<201>): Summary<201> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary201: Summary<201> = summarize201({
  kind: "complete", id: 201, output: { label: "item-201", score: 201 },
});

export function summarize202(event: WorkflowEvent<202>): Summary<202> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary202: Summary<202> = summarize202({
  kind: "complete", id: 202, output: { label: "item-202", score: 202 },
});

export function summarize203(event: WorkflowEvent<203>): Summary<203> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary203: Summary<203> = summarize203({
  kind: "complete", id: 203, output: { label: "item-203", score: 203 },
});

export function summarize204(event: WorkflowEvent<204>): Summary<204> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary204: Summary<204> = summarize204({
  kind: "complete", id: 204, output: { label: "item-204", score: 204 },
});

export function summarize205(event: WorkflowEvent<205>): Summary<205> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary205: Summary<205> = summarize205({
  kind: "complete", id: 205, output: { label: "item-205", score: 205 },
});

export function summarize206(event: WorkflowEvent<206>): Summary<206> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary206: Summary<206> = summarize206({
  kind: "complete", id: 206, output: { label: "item-206", score: 206 },
});

export function summarize207(event: WorkflowEvent<207>): Summary<207> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary207: Summary<207> = summarize207({
  kind: "complete", id: 207, output: { label: "item-207", score: 207 },
});

export function summarize208(event: WorkflowEvent<208>): Summary<208> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary208: Summary<208> = summarize208({
  kind: "complete", id: 208, output: { label: "item-208", score: 208 },
});

export function summarize209(event: WorkflowEvent<209>): Summary<209> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary209: Summary<209> = summarize209({
  kind: "complete", id: 209, output: { label: "item-209", score: 209 },
});

export function summarize210(event: WorkflowEvent<210>): Summary<210> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary210: Summary<210> = summarize210({
  kind: "complete", id: 210, output: { label: "item-210", score: 210 },
});

export function summarize211(event: WorkflowEvent<211>): Summary<211> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary211: Summary<211> = summarize211({
  kind: "complete", id: 211, output: { label: "item-211", score: 211 },
});

export function summarize212(event: WorkflowEvent<212>): Summary<212> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary212: Summary<212> = summarize212({
  kind: "complete", id: 212, output: { label: "item-212", score: 212 },
});

export function summarize213(event: WorkflowEvent<213>): Summary<213> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary213: Summary<213> = summarize213({
  kind: "complete", id: 213, output: { label: "item-213", score: 213 },
});

export function summarize214(event: WorkflowEvent<214>): Summary<214> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary214: Summary<214> = summarize214({
  kind: "complete", id: 214, output: { label: "item-214", score: 214 },
});

export function summarize215(event: WorkflowEvent<215>): Summary<215> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary215: Summary<215> = summarize215({
  kind: "complete", id: 215, output: { label: "item-215", score: 215 },
});

export function summarize216(event: WorkflowEvent<216>): Summary<216> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary216: Summary<216> = summarize216({
  kind: "complete", id: 216, output: { label: "item-216", score: 216 },
});

export function summarize217(event: WorkflowEvent<217>): Summary<217> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary217: Summary<217> = summarize217({
  kind: "complete", id: 217, output: { label: "item-217", score: 217 },
});

export function summarize218(event: WorkflowEvent<218>): Summary<218> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary218: Summary<218> = summarize218({
  kind: "complete", id: 218, output: { label: "item-218", score: 218 },
});

export function summarize219(event: WorkflowEvent<219>): Summary<219> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary219: Summary<219> = summarize219({
  kind: "complete", id: 219, output: { label: "item-219", score: 219 },
});

export function summarize220(event: WorkflowEvent<220>): Summary<220> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary220: Summary<220> = summarize220({
  kind: "complete", id: 220, output: { label: "item-220", score: 220 },
});

export function summarize221(event: WorkflowEvent<221>): Summary<221> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary221: Summary<221> = summarize221({
  kind: "complete", id: 221, output: { label: "item-221", score: 221 },
});

export function summarize222(event: WorkflowEvent<222>): Summary<222> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary222: Summary<222> = summarize222({
  kind: "complete", id: 222, output: { label: "item-222", score: 222 },
});

export function summarize223(event: WorkflowEvent<223>): Summary<223> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary223: Summary<223> = summarize223({
  kind: "complete", id: 223, output: { label: "item-223", score: 223 },
});

export function summarize224(event: WorkflowEvent<224>): Summary<224> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary224: Summary<224> = summarize224({
  kind: "complete", id: 224, output: { label: "item-224", score: 224 },
});

export function summarize225(event: WorkflowEvent<225>): Summary<225> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary225: Summary<225> = summarize225({
  kind: "complete", id: 225, output: { label: "item-225", score: 225 },
});

export function summarize226(event: WorkflowEvent<226>): Summary<226> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary226: Summary<226> = summarize226({
  kind: "complete", id: 226, output: { label: "item-226", score: 226 },
});

export function summarize227(event: WorkflowEvent<227>): Summary<227> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary227: Summary<227> = summarize227({
  kind: "complete", id: 227, output: { label: "item-227", score: 227 },
});

export function summarize228(event: WorkflowEvent<228>): Summary<228> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary228: Summary<228> = summarize228({
  kind: "complete", id: 228, output: { label: "item-228", score: 228 },
});

export function summarize229(event: WorkflowEvent<229>): Summary<229> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary229: Summary<229> = summarize229({
  kind: "complete", id: 229, output: { label: "item-229", score: 229 },
});

export function summarize230(event: WorkflowEvent<230>): Summary<230> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary230: Summary<230> = summarize230({
  kind: "complete", id: 230, output: { label: "item-230", score: 230 },
});

export function summarize231(event: WorkflowEvent<231>): Summary<231> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary231: Summary<231> = summarize231({
  kind: "complete", id: 231, output: { label: "item-231", score: 231 },
});

export function summarize232(event: WorkflowEvent<232>): Summary<232> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary232: Summary<232> = summarize232({
  kind: "complete", id: 232, output: { label: "item-232", score: 232 },
});

export function summarize233(event: WorkflowEvent<233>): Summary<233> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary233: Summary<233> = summarize233({
  kind: "complete", id: 233, output: { label: "item-233", score: 233 },
});

export function summarize234(event: WorkflowEvent<234>): Summary<234> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary234: Summary<234> = summarize234({
  kind: "complete", id: 234, output: { label: "item-234", score: 234 },
});

export function summarize235(event: WorkflowEvent<235>): Summary<235> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary235: Summary<235> = summarize235({
  kind: "complete", id: 235, output: { label: "item-235", score: 235 },
});

export function summarize236(event: WorkflowEvent<236>): Summary<236> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary236: Summary<236> = summarize236({
  kind: "complete", id: 236, output: { label: "item-236", score: 236 },
});

export function summarize237(event: WorkflowEvent<237>): Summary<237> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary237: Summary<237> = summarize237({
  kind: "complete", id: 237, output: { label: "item-237", score: 237 },
});

export function summarize238(event: WorkflowEvent<238>): Summary<238> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary238: Summary<238> = summarize238({
  kind: "complete", id: 238, output: { label: "item-238", score: 238 },
});

export function summarize239(event: WorkflowEvent<239>): Summary<239> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary239: Summary<239> = summarize239({
  kind: "complete", id: 239, output: { label: "item-239", score: 239 },
});

export function summarize240(event: WorkflowEvent<240>): Summary<240> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary240: Summary<240> = summarize240({
  kind: "complete", id: 240, output: { label: "item-240", score: 240 },
});

export function summarize241(event: WorkflowEvent<241>): Summary<241> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary241: Summary<241> = summarize241({
  kind: "complete", id: 241, output: { label: "item-241", score: 241 },
});

export function summarize242(event: WorkflowEvent<242>): Summary<242> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary242: Summary<242> = summarize242({
  kind: "complete", id: 242, output: { label: "item-242", score: 242 },
});

export function summarize243(event: WorkflowEvent<243>): Summary<243> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary243: Summary<243> = summarize243({
  kind: "complete", id: 243, output: { label: "item-243", score: 243 },
});

export function summarize244(event: WorkflowEvent<244>): Summary<244> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary244: Summary<244> = summarize244({
  kind: "complete", id: 244, output: { label: "item-244", score: 244 },
});

export function summarize245(event: WorkflowEvent<245>): Summary<245> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary245: Summary<245> = summarize245({
  kind: "complete", id: 245, output: { label: "item-245", score: 245 },
});

export function summarize246(event: WorkflowEvent<246>): Summary<246> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary246: Summary<246> = summarize246({
  kind: "complete", id: 246, output: { label: "item-246", score: 246 },
});

export function summarize247(event: WorkflowEvent<247>): Summary<247> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary247: Summary<247> = summarize247({
  kind: "complete", id: 247, output: { label: "item-247", score: 247 },
});

export function summarize248(event: WorkflowEvent<248>): Summary<248> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary248: Summary<248> = summarize248({
  kind: "complete", id: 248, output: { label: "item-248", score: 248 },
});

export function summarize249(event: WorkflowEvent<249>): Summary<249> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary249: Summary<249> = summarize249({
  kind: "complete", id: 249, output: { label: "item-249", score: 249 },
});

export function summarize250(event: WorkflowEvent<250>): Summary<250> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary250: Summary<250> = summarize250({
  kind: "complete", id: 250, output: { label: "item-250", score: 250 },
});

export function summarize251(event: WorkflowEvent<251>): Summary<251> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary251: Summary<251> = summarize251({
  kind: "complete", id: 251, output: { label: "item-251", score: 251 },
});

export function summarize252(event: WorkflowEvent<252>): Summary<252> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary252: Summary<252> = summarize252({
  kind: "complete", id: 252, output: { label: "item-252", score: 252 },
});

export function summarize253(event: WorkflowEvent<253>): Summary<253> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary253: Summary<253> = summarize253({
  kind: "complete", id: 253, output: { label: "item-253", score: 253 },
});

export function summarize254(event: WorkflowEvent<254>): Summary<254> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary254: Summary<254> = summarize254({
  kind: "complete", id: 254, output: { label: "item-254", score: 254 },
});

export function summarize255(event: WorkflowEvent<255>): Summary<255> {
  let label: string;
  let score: number;
  let terminal: boolean;
  switch (event.kind) {
    case "queued":
      label = "queued";
      score = 0;
      terminal = false;
      break;
    case "running":
      label = "running";
      score = event.progress;
      terminal = false;
      break;
    case "complete":
      label = event.output.label;
      score = event.output.score;
      terminal = true;
      break;
    case "failed":
      label = event.error.message;
      score = event.error.retryable ? 1 : 0;
      terminal = true;
      break;
    default: {
      const exhaustive: never = event;
      return exhaustive;
    }
  }
  return { id: event.id, label, score, terminal };
}

export const summary255: Summary<255> = summarize255({
  kind: "complete", id: 255, output: { label: "item-255", score: 255 },
});

