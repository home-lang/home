interface BindingRecord0 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection0 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings0(input: BindingRecord0): BindingProjection0 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured0: BindingProjection0 = projectBindings0({
  id: 0,
  meta: { label: "item-0", score: 0 },
  slots: [0, "slot-0"],
});
export const consumedBindings0: readonly [number, string, boolean] = [
  destructured0.id, destructured0.second, destructured0.active,
];

interface BindingRecord1 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection1 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings1(input: BindingRecord1): BindingProjection1 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured1: BindingProjection1 = projectBindings1({
  id: 1,
  meta: { label: "item-1", score: 1 },
  slots: [1, "slot-1"],
  active: false,
});
export const consumedBindings1: readonly [number, string, boolean] = [
  destructured1.id, destructured1.second, destructured1.active,
];

interface BindingRecord2 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection2 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings2(input: BindingRecord2): BindingProjection2 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured2: BindingProjection2 = projectBindings2({
  id: 2,
  meta: { label: "item-2", score: 2 },
  slots: [2, "slot-2"],
});
export const consumedBindings2: readonly [number, string, boolean] = [
  destructured2.id, destructured2.second, destructured2.active,
];

interface BindingRecord3 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection3 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings3(input: BindingRecord3): BindingProjection3 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured3: BindingProjection3 = projectBindings3({
  id: 3,
  meta: { label: "item-3", score: 3 },
  slots: [3, "slot-3"],
  active: false,
});
export const consumedBindings3: readonly [number, string, boolean] = [
  destructured3.id, destructured3.second, destructured3.active,
];

interface BindingRecord4 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection4 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings4(input: BindingRecord4): BindingProjection4 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured4: BindingProjection4 = projectBindings4({
  id: 4,
  meta: { label: "item-4", score: 4 },
  slots: [4, "slot-4"],
});
export const consumedBindings4: readonly [number, string, boolean] = [
  destructured4.id, destructured4.second, destructured4.active,
];

interface BindingRecord5 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection5 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings5(input: BindingRecord5): BindingProjection5 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured5: BindingProjection5 = projectBindings5({
  id: 5,
  meta: { label: "item-5", score: 5 },
  slots: [5, "slot-5"],
  active: false,
});
export const consumedBindings5: readonly [number, string, boolean] = [
  destructured5.id, destructured5.second, destructured5.active,
];

interface BindingRecord6 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection6 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings6(input: BindingRecord6): BindingProjection6 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured6: BindingProjection6 = projectBindings6({
  id: 6,
  meta: { label: "item-6", score: 6 },
  slots: [6, "slot-6"],
});
export const consumedBindings6: readonly [number, string, boolean] = [
  destructured6.id, destructured6.second, destructured6.active,
];

interface BindingRecord7 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection7 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings7(input: BindingRecord7): BindingProjection7 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured7: BindingProjection7 = projectBindings7({
  id: 7,
  meta: { label: "item-7", score: 7 },
  slots: [7, "slot-7"],
  active: false,
});
export const consumedBindings7: readonly [number, string, boolean] = [
  destructured7.id, destructured7.second, destructured7.active,
];

interface BindingRecord8 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection8 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings8(input: BindingRecord8): BindingProjection8 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured8: BindingProjection8 = projectBindings8({
  id: 8,
  meta: { label: "item-8", score: 8 },
  slots: [8, "slot-8"],
});
export const consumedBindings8: readonly [number, string, boolean] = [
  destructured8.id, destructured8.second, destructured8.active,
];

interface BindingRecord9 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection9 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings9(input: BindingRecord9): BindingProjection9 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured9: BindingProjection9 = projectBindings9({
  id: 9,
  meta: { label: "item-9", score: 9 },
  slots: [9, "slot-9"],
  active: false,
});
export const consumedBindings9: readonly [number, string, boolean] = [
  destructured9.id, destructured9.second, destructured9.active,
];

interface BindingRecord10 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection10 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings10(input: BindingRecord10): BindingProjection10 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured10: BindingProjection10 = projectBindings10({
  id: 10,
  meta: { label: "item-10", score: 10 },
  slots: [10, "slot-10"],
});
export const consumedBindings10: readonly [number, string, boolean] = [
  destructured10.id, destructured10.second, destructured10.active,
];

interface BindingRecord11 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection11 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings11(input: BindingRecord11): BindingProjection11 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured11: BindingProjection11 = projectBindings11({
  id: 11,
  meta: { label: "item-11", score: 11 },
  slots: [11, "slot-11"],
  active: false,
});
export const consumedBindings11: readonly [number, string, boolean] = [
  destructured11.id, destructured11.second, destructured11.active,
];

interface BindingRecord12 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection12 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings12(input: BindingRecord12): BindingProjection12 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured12: BindingProjection12 = projectBindings12({
  id: 12,
  meta: { label: "item-12", score: 12 },
  slots: [12, "slot-12"],
});
export const consumedBindings12: readonly [number, string, boolean] = [
  destructured12.id, destructured12.second, destructured12.active,
];

interface BindingRecord13 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection13 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings13(input: BindingRecord13): BindingProjection13 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured13: BindingProjection13 = projectBindings13({
  id: 13,
  meta: { label: "item-13", score: 13 },
  slots: [13, "slot-13"],
  active: false,
});
export const consumedBindings13: readonly [number, string, boolean] = [
  destructured13.id, destructured13.second, destructured13.active,
];

interface BindingRecord14 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection14 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings14(input: BindingRecord14): BindingProjection14 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured14: BindingProjection14 = projectBindings14({
  id: 14,
  meta: { label: "item-14", score: 14 },
  slots: [14, "slot-14"],
});
export const consumedBindings14: readonly [number, string, boolean] = [
  destructured14.id, destructured14.second, destructured14.active,
];

interface BindingRecord15 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection15 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings15(input: BindingRecord15): BindingProjection15 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured15: BindingProjection15 = projectBindings15({
  id: 15,
  meta: { label: "item-15", score: 15 },
  slots: [15, "slot-15"],
  active: false,
});
export const consumedBindings15: readonly [number, string, boolean] = [
  destructured15.id, destructured15.second, destructured15.active,
];

interface BindingRecord16 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection16 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings16(input: BindingRecord16): BindingProjection16 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured16: BindingProjection16 = projectBindings16({
  id: 16,
  meta: { label: "item-16", score: 16 },
  slots: [16, "slot-16"],
});
export const consumedBindings16: readonly [number, string, boolean] = [
  destructured16.id, destructured16.second, destructured16.active,
];

interface BindingRecord17 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection17 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings17(input: BindingRecord17): BindingProjection17 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured17: BindingProjection17 = projectBindings17({
  id: 17,
  meta: { label: "item-17", score: 17 },
  slots: [17, "slot-17"],
  active: false,
});
export const consumedBindings17: readonly [number, string, boolean] = [
  destructured17.id, destructured17.second, destructured17.active,
];

interface BindingRecord18 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection18 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings18(input: BindingRecord18): BindingProjection18 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured18: BindingProjection18 = projectBindings18({
  id: 18,
  meta: { label: "item-18", score: 18 },
  slots: [18, "slot-18"],
});
export const consumedBindings18: readonly [number, string, boolean] = [
  destructured18.id, destructured18.second, destructured18.active,
];

interface BindingRecord19 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection19 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings19(input: BindingRecord19): BindingProjection19 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured19: BindingProjection19 = projectBindings19({
  id: 19,
  meta: { label: "item-19", score: 19 },
  slots: [19, "slot-19"],
  active: false,
});
export const consumedBindings19: readonly [number, string, boolean] = [
  destructured19.id, destructured19.second, destructured19.active,
];

interface BindingRecord20 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection20 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings20(input: BindingRecord20): BindingProjection20 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured20: BindingProjection20 = projectBindings20({
  id: 20,
  meta: { label: "item-20", score: 20 },
  slots: [20, "slot-20"],
});
export const consumedBindings20: readonly [number, string, boolean] = [
  destructured20.id, destructured20.second, destructured20.active,
];

interface BindingRecord21 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection21 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings21(input: BindingRecord21): BindingProjection21 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured21: BindingProjection21 = projectBindings21({
  id: 21,
  meta: { label: "item-21", score: 21 },
  slots: [21, "slot-21"],
  active: false,
});
export const consumedBindings21: readonly [number, string, boolean] = [
  destructured21.id, destructured21.second, destructured21.active,
];

interface BindingRecord22 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection22 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings22(input: BindingRecord22): BindingProjection22 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured22: BindingProjection22 = projectBindings22({
  id: 22,
  meta: { label: "item-22", score: 22 },
  slots: [22, "slot-22"],
});
export const consumedBindings22: readonly [number, string, boolean] = [
  destructured22.id, destructured22.second, destructured22.active,
];

interface BindingRecord23 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection23 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings23(input: BindingRecord23): BindingProjection23 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured23: BindingProjection23 = projectBindings23({
  id: 23,
  meta: { label: "item-23", score: 23 },
  slots: [23, "slot-23"],
  active: false,
});
export const consumedBindings23: readonly [number, string, boolean] = [
  destructured23.id, destructured23.second, destructured23.active,
];

interface BindingRecord24 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection24 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings24(input: BindingRecord24): BindingProjection24 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured24: BindingProjection24 = projectBindings24({
  id: 24,
  meta: { label: "item-24", score: 24 },
  slots: [24, "slot-24"],
});
export const consumedBindings24: readonly [number, string, boolean] = [
  destructured24.id, destructured24.second, destructured24.active,
];

interface BindingRecord25 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection25 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings25(input: BindingRecord25): BindingProjection25 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured25: BindingProjection25 = projectBindings25({
  id: 25,
  meta: { label: "item-25", score: 25 },
  slots: [25, "slot-25"],
  active: false,
});
export const consumedBindings25: readonly [number, string, boolean] = [
  destructured25.id, destructured25.second, destructured25.active,
];

interface BindingRecord26 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection26 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings26(input: BindingRecord26): BindingProjection26 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured26: BindingProjection26 = projectBindings26({
  id: 26,
  meta: { label: "item-26", score: 26 },
  slots: [26, "slot-26"],
});
export const consumedBindings26: readonly [number, string, boolean] = [
  destructured26.id, destructured26.second, destructured26.active,
];

interface BindingRecord27 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection27 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings27(input: BindingRecord27): BindingProjection27 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured27: BindingProjection27 = projectBindings27({
  id: 27,
  meta: { label: "item-27", score: 27 },
  slots: [27, "slot-27"],
  active: false,
});
export const consumedBindings27: readonly [number, string, boolean] = [
  destructured27.id, destructured27.second, destructured27.active,
];

interface BindingRecord28 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection28 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings28(input: BindingRecord28): BindingProjection28 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured28: BindingProjection28 = projectBindings28({
  id: 28,
  meta: { label: "item-28", score: 28 },
  slots: [28, "slot-28"],
});
export const consumedBindings28: readonly [number, string, boolean] = [
  destructured28.id, destructured28.second, destructured28.active,
];

interface BindingRecord29 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection29 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings29(input: BindingRecord29): BindingProjection29 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured29: BindingProjection29 = projectBindings29({
  id: 29,
  meta: { label: "item-29", score: 29 },
  slots: [29, "slot-29"],
  active: false,
});
export const consumedBindings29: readonly [number, string, boolean] = [
  destructured29.id, destructured29.second, destructured29.active,
];

interface BindingRecord30 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection30 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings30(input: BindingRecord30): BindingProjection30 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured30: BindingProjection30 = projectBindings30({
  id: 30,
  meta: { label: "item-30", score: 30 },
  slots: [30, "slot-30"],
});
export const consumedBindings30: readonly [number, string, boolean] = [
  destructured30.id, destructured30.second, destructured30.active,
];

interface BindingRecord31 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection31 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings31(input: BindingRecord31): BindingProjection31 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured31: BindingProjection31 = projectBindings31({
  id: 31,
  meta: { label: "item-31", score: 31 },
  slots: [31, "slot-31"],
  active: false,
});
export const consumedBindings31: readonly [number, string, boolean] = [
  destructured31.id, destructured31.second, destructured31.active,
];

interface BindingRecord32 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection32 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings32(input: BindingRecord32): BindingProjection32 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured32: BindingProjection32 = projectBindings32({
  id: 32,
  meta: { label: "item-32", score: 32 },
  slots: [32, "slot-32"],
});
export const consumedBindings32: readonly [number, string, boolean] = [
  destructured32.id, destructured32.second, destructured32.active,
];

interface BindingRecord33 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection33 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings33(input: BindingRecord33): BindingProjection33 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured33: BindingProjection33 = projectBindings33({
  id: 33,
  meta: { label: "item-33", score: 33 },
  slots: [33, "slot-33"],
  active: false,
});
export const consumedBindings33: readonly [number, string, boolean] = [
  destructured33.id, destructured33.second, destructured33.active,
];

interface BindingRecord34 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection34 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings34(input: BindingRecord34): BindingProjection34 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured34: BindingProjection34 = projectBindings34({
  id: 34,
  meta: { label: "item-34", score: 34 },
  slots: [34, "slot-34"],
});
export const consumedBindings34: readonly [number, string, boolean] = [
  destructured34.id, destructured34.second, destructured34.active,
];

interface BindingRecord35 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection35 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings35(input: BindingRecord35): BindingProjection35 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured35: BindingProjection35 = projectBindings35({
  id: 35,
  meta: { label: "item-35", score: 35 },
  slots: [35, "slot-35"],
  active: false,
});
export const consumedBindings35: readonly [number, string, boolean] = [
  destructured35.id, destructured35.second, destructured35.active,
];

interface BindingRecord36 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection36 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings36(input: BindingRecord36): BindingProjection36 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured36: BindingProjection36 = projectBindings36({
  id: 36,
  meta: { label: "item-36", score: 36 },
  slots: [36, "slot-36"],
});
export const consumedBindings36: readonly [number, string, boolean] = [
  destructured36.id, destructured36.second, destructured36.active,
];

interface BindingRecord37 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection37 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings37(input: BindingRecord37): BindingProjection37 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured37: BindingProjection37 = projectBindings37({
  id: 37,
  meta: { label: "item-37", score: 37 },
  slots: [37, "slot-37"],
  active: false,
});
export const consumedBindings37: readonly [number, string, boolean] = [
  destructured37.id, destructured37.second, destructured37.active,
];

interface BindingRecord38 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection38 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings38(input: BindingRecord38): BindingProjection38 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured38: BindingProjection38 = projectBindings38({
  id: 38,
  meta: { label: "item-38", score: 38 },
  slots: [38, "slot-38"],
});
export const consumedBindings38: readonly [number, string, boolean] = [
  destructured38.id, destructured38.second, destructured38.active,
];

interface BindingRecord39 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection39 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings39(input: BindingRecord39): BindingProjection39 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured39: BindingProjection39 = projectBindings39({
  id: 39,
  meta: { label: "item-39", score: 39 },
  slots: [39, "slot-39"],
  active: false,
});
export const consumedBindings39: readonly [number, string, boolean] = [
  destructured39.id, destructured39.second, destructured39.active,
];

interface BindingRecord40 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection40 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings40(input: BindingRecord40): BindingProjection40 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured40: BindingProjection40 = projectBindings40({
  id: 40,
  meta: { label: "item-40", score: 40 },
  slots: [40, "slot-40"],
});
export const consumedBindings40: readonly [number, string, boolean] = [
  destructured40.id, destructured40.second, destructured40.active,
];

interface BindingRecord41 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection41 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings41(input: BindingRecord41): BindingProjection41 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured41: BindingProjection41 = projectBindings41({
  id: 41,
  meta: { label: "item-41", score: 41 },
  slots: [41, "slot-41"],
  active: false,
});
export const consumedBindings41: readonly [number, string, boolean] = [
  destructured41.id, destructured41.second, destructured41.active,
];

interface BindingRecord42 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection42 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings42(input: BindingRecord42): BindingProjection42 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured42: BindingProjection42 = projectBindings42({
  id: 42,
  meta: { label: "item-42", score: 42 },
  slots: [42, "slot-42"],
});
export const consumedBindings42: readonly [number, string, boolean] = [
  destructured42.id, destructured42.second, destructured42.active,
];

interface BindingRecord43 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection43 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings43(input: BindingRecord43): BindingProjection43 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured43: BindingProjection43 = projectBindings43({
  id: 43,
  meta: { label: "item-43", score: 43 },
  slots: [43, "slot-43"],
  active: false,
});
export const consumedBindings43: readonly [number, string, boolean] = [
  destructured43.id, destructured43.second, destructured43.active,
];

interface BindingRecord44 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection44 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings44(input: BindingRecord44): BindingProjection44 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured44: BindingProjection44 = projectBindings44({
  id: 44,
  meta: { label: "item-44", score: 44 },
  slots: [44, "slot-44"],
});
export const consumedBindings44: readonly [number, string, boolean] = [
  destructured44.id, destructured44.second, destructured44.active,
];

interface BindingRecord45 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection45 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings45(input: BindingRecord45): BindingProjection45 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured45: BindingProjection45 = projectBindings45({
  id: 45,
  meta: { label: "item-45", score: 45 },
  slots: [45, "slot-45"],
  active: false,
});
export const consumedBindings45: readonly [number, string, boolean] = [
  destructured45.id, destructured45.second, destructured45.active,
];

interface BindingRecord46 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection46 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings46(input: BindingRecord46): BindingProjection46 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured46: BindingProjection46 = projectBindings46({
  id: 46,
  meta: { label: "item-46", score: 46 },
  slots: [46, "slot-46"],
});
export const consumedBindings46: readonly [number, string, boolean] = [
  destructured46.id, destructured46.second, destructured46.active,
];

interface BindingRecord47 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection47 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings47(input: BindingRecord47): BindingProjection47 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured47: BindingProjection47 = projectBindings47({
  id: 47,
  meta: { label: "item-47", score: 47 },
  slots: [47, "slot-47"],
  active: false,
});
export const consumedBindings47: readonly [number, string, boolean] = [
  destructured47.id, destructured47.second, destructured47.active,
];

interface BindingRecord48 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection48 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings48(input: BindingRecord48): BindingProjection48 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured48: BindingProjection48 = projectBindings48({
  id: 48,
  meta: { label: "item-48", score: 48 },
  slots: [48, "slot-48"],
});
export const consumedBindings48: readonly [number, string, boolean] = [
  destructured48.id, destructured48.second, destructured48.active,
];

interface BindingRecord49 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection49 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings49(input: BindingRecord49): BindingProjection49 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured49: BindingProjection49 = projectBindings49({
  id: 49,
  meta: { label: "item-49", score: 49 },
  slots: [49, "slot-49"],
  active: false,
});
export const consumedBindings49: readonly [number, string, boolean] = [
  destructured49.id, destructured49.second, destructured49.active,
];

interface BindingRecord50 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection50 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings50(input: BindingRecord50): BindingProjection50 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured50: BindingProjection50 = projectBindings50({
  id: 50,
  meta: { label: "item-50", score: 50 },
  slots: [50, "slot-50"],
});
export const consumedBindings50: readonly [number, string, boolean] = [
  destructured50.id, destructured50.second, destructured50.active,
];

interface BindingRecord51 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection51 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings51(input: BindingRecord51): BindingProjection51 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured51: BindingProjection51 = projectBindings51({
  id: 51,
  meta: { label: "item-51", score: 51 },
  slots: [51, "slot-51"],
  active: false,
});
export const consumedBindings51: readonly [number, string, boolean] = [
  destructured51.id, destructured51.second, destructured51.active,
];

interface BindingRecord52 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection52 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings52(input: BindingRecord52): BindingProjection52 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured52: BindingProjection52 = projectBindings52({
  id: 52,
  meta: { label: "item-52", score: 52 },
  slots: [52, "slot-52"],
});
export const consumedBindings52: readonly [number, string, boolean] = [
  destructured52.id, destructured52.second, destructured52.active,
];

interface BindingRecord53 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection53 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings53(input: BindingRecord53): BindingProjection53 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured53: BindingProjection53 = projectBindings53({
  id: 53,
  meta: { label: "item-53", score: 53 },
  slots: [53, "slot-53"],
  active: false,
});
export const consumedBindings53: readonly [number, string, boolean] = [
  destructured53.id, destructured53.second, destructured53.active,
];

interface BindingRecord54 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection54 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings54(input: BindingRecord54): BindingProjection54 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured54: BindingProjection54 = projectBindings54({
  id: 54,
  meta: { label: "item-54", score: 54 },
  slots: [54, "slot-54"],
});
export const consumedBindings54: readonly [number, string, boolean] = [
  destructured54.id, destructured54.second, destructured54.active,
];

interface BindingRecord55 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection55 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings55(input: BindingRecord55): BindingProjection55 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured55: BindingProjection55 = projectBindings55({
  id: 55,
  meta: { label: "item-55", score: 55 },
  slots: [55, "slot-55"],
  active: false,
});
export const consumedBindings55: readonly [number, string, boolean] = [
  destructured55.id, destructured55.second, destructured55.active,
];

interface BindingRecord56 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection56 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings56(input: BindingRecord56): BindingProjection56 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured56: BindingProjection56 = projectBindings56({
  id: 56,
  meta: { label: "item-56", score: 56 },
  slots: [56, "slot-56"],
});
export const consumedBindings56: readonly [number, string, boolean] = [
  destructured56.id, destructured56.second, destructured56.active,
];

interface BindingRecord57 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection57 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings57(input: BindingRecord57): BindingProjection57 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured57: BindingProjection57 = projectBindings57({
  id: 57,
  meta: { label: "item-57", score: 57 },
  slots: [57, "slot-57"],
  active: false,
});
export const consumedBindings57: readonly [number, string, boolean] = [
  destructured57.id, destructured57.second, destructured57.active,
];

interface BindingRecord58 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection58 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings58(input: BindingRecord58): BindingProjection58 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured58: BindingProjection58 = projectBindings58({
  id: 58,
  meta: { label: "item-58", score: 58 },
  slots: [58, "slot-58"],
});
export const consumedBindings58: readonly [number, string, boolean] = [
  destructured58.id, destructured58.second, destructured58.active,
];

interface BindingRecord59 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection59 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings59(input: BindingRecord59): BindingProjection59 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured59: BindingProjection59 = projectBindings59({
  id: 59,
  meta: { label: "item-59", score: 59 },
  slots: [59, "slot-59"],
  active: false,
});
export const consumedBindings59: readonly [number, string, boolean] = [
  destructured59.id, destructured59.second, destructured59.active,
];

interface BindingRecord60 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection60 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings60(input: BindingRecord60): BindingProjection60 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured60: BindingProjection60 = projectBindings60({
  id: 60,
  meta: { label: "item-60", score: 60 },
  slots: [60, "slot-60"],
});
export const consumedBindings60: readonly [number, string, boolean] = [
  destructured60.id, destructured60.second, destructured60.active,
];

interface BindingRecord61 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection61 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings61(input: BindingRecord61): BindingProjection61 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured61: BindingProjection61 = projectBindings61({
  id: 61,
  meta: { label: "item-61", score: 61 },
  slots: [61, "slot-61"],
  active: false,
});
export const consumedBindings61: readonly [number, string, boolean] = [
  destructured61.id, destructured61.second, destructured61.active,
];

interface BindingRecord62 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection62 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings62(input: BindingRecord62): BindingProjection62 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured62: BindingProjection62 = projectBindings62({
  id: 62,
  meta: { label: "item-62", score: 62 },
  slots: [62, "slot-62"],
});
export const consumedBindings62: readonly [number, string, boolean] = [
  destructured62.id, destructured62.second, destructured62.active,
];

interface BindingRecord63 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection63 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings63(input: BindingRecord63): BindingProjection63 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured63: BindingProjection63 = projectBindings63({
  id: 63,
  meta: { label: "item-63", score: 63 },
  slots: [63, "slot-63"],
  active: false,
});
export const consumedBindings63: readonly [number, string, boolean] = [
  destructured63.id, destructured63.second, destructured63.active,
];

interface BindingRecord64 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection64 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings64(input: BindingRecord64): BindingProjection64 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured64: BindingProjection64 = projectBindings64({
  id: 64,
  meta: { label: "item-64", score: 64 },
  slots: [64, "slot-64"],
});
export const consumedBindings64: readonly [number, string, boolean] = [
  destructured64.id, destructured64.second, destructured64.active,
];

interface BindingRecord65 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection65 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings65(input: BindingRecord65): BindingProjection65 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured65: BindingProjection65 = projectBindings65({
  id: 65,
  meta: { label: "item-65", score: 65 },
  slots: [65, "slot-65"],
  active: false,
});
export const consumedBindings65: readonly [number, string, boolean] = [
  destructured65.id, destructured65.second, destructured65.active,
];

interface BindingRecord66 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection66 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings66(input: BindingRecord66): BindingProjection66 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured66: BindingProjection66 = projectBindings66({
  id: 66,
  meta: { label: "item-66", score: 66 },
  slots: [66, "slot-66"],
});
export const consumedBindings66: readonly [number, string, boolean] = [
  destructured66.id, destructured66.second, destructured66.active,
];

interface BindingRecord67 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection67 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings67(input: BindingRecord67): BindingProjection67 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured67: BindingProjection67 = projectBindings67({
  id: 67,
  meta: { label: "item-67", score: 67 },
  slots: [67, "slot-67"],
  active: false,
});
export const consumedBindings67: readonly [number, string, boolean] = [
  destructured67.id, destructured67.second, destructured67.active,
];

interface BindingRecord68 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection68 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings68(input: BindingRecord68): BindingProjection68 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured68: BindingProjection68 = projectBindings68({
  id: 68,
  meta: { label: "item-68", score: 68 },
  slots: [68, "slot-68"],
});
export const consumedBindings68: readonly [number, string, boolean] = [
  destructured68.id, destructured68.second, destructured68.active,
];

interface BindingRecord69 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection69 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings69(input: BindingRecord69): BindingProjection69 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured69: BindingProjection69 = projectBindings69({
  id: 69,
  meta: { label: "item-69", score: 69 },
  slots: [69, "slot-69"],
  active: false,
});
export const consumedBindings69: readonly [number, string, boolean] = [
  destructured69.id, destructured69.second, destructured69.active,
];

interface BindingRecord70 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection70 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings70(input: BindingRecord70): BindingProjection70 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured70: BindingProjection70 = projectBindings70({
  id: 70,
  meta: { label: "item-70", score: 70 },
  slots: [70, "slot-70"],
});
export const consumedBindings70: readonly [number, string, boolean] = [
  destructured70.id, destructured70.second, destructured70.active,
];

interface BindingRecord71 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection71 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings71(input: BindingRecord71): BindingProjection71 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured71: BindingProjection71 = projectBindings71({
  id: 71,
  meta: { label: "item-71", score: 71 },
  slots: [71, "slot-71"],
  active: false,
});
export const consumedBindings71: readonly [number, string, boolean] = [
  destructured71.id, destructured71.second, destructured71.active,
];

interface BindingRecord72 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection72 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings72(input: BindingRecord72): BindingProjection72 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured72: BindingProjection72 = projectBindings72({
  id: 72,
  meta: { label: "item-72", score: 72 },
  slots: [72, "slot-72"],
});
export const consumedBindings72: readonly [number, string, boolean] = [
  destructured72.id, destructured72.second, destructured72.active,
];

interface BindingRecord73 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection73 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings73(input: BindingRecord73): BindingProjection73 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured73: BindingProjection73 = projectBindings73({
  id: 73,
  meta: { label: "item-73", score: 73 },
  slots: [73, "slot-73"],
  active: false,
});
export const consumedBindings73: readonly [number, string, boolean] = [
  destructured73.id, destructured73.second, destructured73.active,
];

interface BindingRecord74 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection74 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings74(input: BindingRecord74): BindingProjection74 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured74: BindingProjection74 = projectBindings74({
  id: 74,
  meta: { label: "item-74", score: 74 },
  slots: [74, "slot-74"],
});
export const consumedBindings74: readonly [number, string, boolean] = [
  destructured74.id, destructured74.second, destructured74.active,
];

interface BindingRecord75 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection75 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings75(input: BindingRecord75): BindingProjection75 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured75: BindingProjection75 = projectBindings75({
  id: 75,
  meta: { label: "item-75", score: 75 },
  slots: [75, "slot-75"],
  active: false,
});
export const consumedBindings75: readonly [number, string, boolean] = [
  destructured75.id, destructured75.second, destructured75.active,
];

interface BindingRecord76 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection76 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings76(input: BindingRecord76): BindingProjection76 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured76: BindingProjection76 = projectBindings76({
  id: 76,
  meta: { label: "item-76", score: 76 },
  slots: [76, "slot-76"],
});
export const consumedBindings76: readonly [number, string, boolean] = [
  destructured76.id, destructured76.second, destructured76.active,
];

interface BindingRecord77 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection77 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings77(input: BindingRecord77): BindingProjection77 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured77: BindingProjection77 = projectBindings77({
  id: 77,
  meta: { label: "item-77", score: 77 },
  slots: [77, "slot-77"],
  active: false,
});
export const consumedBindings77: readonly [number, string, boolean] = [
  destructured77.id, destructured77.second, destructured77.active,
];

interface BindingRecord78 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection78 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings78(input: BindingRecord78): BindingProjection78 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured78: BindingProjection78 = projectBindings78({
  id: 78,
  meta: { label: "item-78", score: 78 },
  slots: [78, "slot-78"],
});
export const consumedBindings78: readonly [number, string, boolean] = [
  destructured78.id, destructured78.second, destructured78.active,
];

interface BindingRecord79 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection79 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings79(input: BindingRecord79): BindingProjection79 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured79: BindingProjection79 = projectBindings79({
  id: 79,
  meta: { label: "item-79", score: 79 },
  slots: [79, "slot-79"],
  active: false,
});
export const consumedBindings79: readonly [number, string, boolean] = [
  destructured79.id, destructured79.second, destructured79.active,
];

interface BindingRecord80 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection80 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings80(input: BindingRecord80): BindingProjection80 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured80: BindingProjection80 = projectBindings80({
  id: 80,
  meta: { label: "item-80", score: 80 },
  slots: [80, "slot-80"],
});
export const consumedBindings80: readonly [number, string, boolean] = [
  destructured80.id, destructured80.second, destructured80.active,
];

interface BindingRecord81 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection81 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings81(input: BindingRecord81): BindingProjection81 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured81: BindingProjection81 = projectBindings81({
  id: 81,
  meta: { label: "item-81", score: 81 },
  slots: [81, "slot-81"],
  active: false,
});
export const consumedBindings81: readonly [number, string, boolean] = [
  destructured81.id, destructured81.second, destructured81.active,
];

interface BindingRecord82 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection82 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings82(input: BindingRecord82): BindingProjection82 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured82: BindingProjection82 = projectBindings82({
  id: 82,
  meta: { label: "item-82", score: 82 },
  slots: [82, "slot-82"],
});
export const consumedBindings82: readonly [number, string, boolean] = [
  destructured82.id, destructured82.second, destructured82.active,
];

interface BindingRecord83 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection83 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings83(input: BindingRecord83): BindingProjection83 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured83: BindingProjection83 = projectBindings83({
  id: 83,
  meta: { label: "item-83", score: 83 },
  slots: [83, "slot-83"],
  active: false,
});
export const consumedBindings83: readonly [number, string, boolean] = [
  destructured83.id, destructured83.second, destructured83.active,
];

interface BindingRecord84 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection84 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings84(input: BindingRecord84): BindingProjection84 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured84: BindingProjection84 = projectBindings84({
  id: 84,
  meta: { label: "item-84", score: 84 },
  slots: [84, "slot-84"],
});
export const consumedBindings84: readonly [number, string, boolean] = [
  destructured84.id, destructured84.second, destructured84.active,
];

interface BindingRecord85 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection85 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings85(input: BindingRecord85): BindingProjection85 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured85: BindingProjection85 = projectBindings85({
  id: 85,
  meta: { label: "item-85", score: 85 },
  slots: [85, "slot-85"],
  active: false,
});
export const consumedBindings85: readonly [number, string, boolean] = [
  destructured85.id, destructured85.second, destructured85.active,
];

interface BindingRecord86 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection86 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings86(input: BindingRecord86): BindingProjection86 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured86: BindingProjection86 = projectBindings86({
  id: 86,
  meta: { label: "item-86", score: 86 },
  slots: [86, "slot-86"],
});
export const consumedBindings86: readonly [number, string, boolean] = [
  destructured86.id, destructured86.second, destructured86.active,
];

interface BindingRecord87 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection87 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings87(input: BindingRecord87): BindingProjection87 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured87: BindingProjection87 = projectBindings87({
  id: 87,
  meta: { label: "item-87", score: 87 },
  slots: [87, "slot-87"],
  active: false,
});
export const consumedBindings87: readonly [number, string, boolean] = [
  destructured87.id, destructured87.second, destructured87.active,
];

interface BindingRecord88 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection88 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings88(input: BindingRecord88): BindingProjection88 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured88: BindingProjection88 = projectBindings88({
  id: 88,
  meta: { label: "item-88", score: 88 },
  slots: [88, "slot-88"],
});
export const consumedBindings88: readonly [number, string, boolean] = [
  destructured88.id, destructured88.second, destructured88.active,
];

interface BindingRecord89 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection89 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings89(input: BindingRecord89): BindingProjection89 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured89: BindingProjection89 = projectBindings89({
  id: 89,
  meta: { label: "item-89", score: 89 },
  slots: [89, "slot-89"],
  active: false,
});
export const consumedBindings89: readonly [number, string, boolean] = [
  destructured89.id, destructured89.second, destructured89.active,
];

interface BindingRecord90 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection90 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings90(input: BindingRecord90): BindingProjection90 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured90: BindingProjection90 = projectBindings90({
  id: 90,
  meta: { label: "item-90", score: 90 },
  slots: [90, "slot-90"],
});
export const consumedBindings90: readonly [number, string, boolean] = [
  destructured90.id, destructured90.second, destructured90.active,
];

interface BindingRecord91 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection91 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings91(input: BindingRecord91): BindingProjection91 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured91: BindingProjection91 = projectBindings91({
  id: 91,
  meta: { label: "item-91", score: 91 },
  slots: [91, "slot-91"],
  active: false,
});
export const consumedBindings91: readonly [number, string, boolean] = [
  destructured91.id, destructured91.second, destructured91.active,
];

interface BindingRecord92 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection92 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings92(input: BindingRecord92): BindingProjection92 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured92: BindingProjection92 = projectBindings92({
  id: 92,
  meta: { label: "item-92", score: 92 },
  slots: [92, "slot-92"],
});
export const consumedBindings92: readonly [number, string, boolean] = [
  destructured92.id, destructured92.second, destructured92.active,
];

interface BindingRecord93 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection93 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings93(input: BindingRecord93): BindingProjection93 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured93: BindingProjection93 = projectBindings93({
  id: 93,
  meta: { label: "item-93", score: 93 },
  slots: [93, "slot-93"],
  active: false,
});
export const consumedBindings93: readonly [number, string, boolean] = [
  destructured93.id, destructured93.second, destructured93.active,
];

interface BindingRecord94 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection94 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings94(input: BindingRecord94): BindingProjection94 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured94: BindingProjection94 = projectBindings94({
  id: 94,
  meta: { label: "item-94", score: 94 },
  slots: [94, "slot-94"],
});
export const consumedBindings94: readonly [number, string, boolean] = [
  destructured94.id, destructured94.second, destructured94.active,
];

interface BindingRecord95 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection95 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings95(input: BindingRecord95): BindingProjection95 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured95: BindingProjection95 = projectBindings95({
  id: 95,
  meta: { label: "item-95", score: 95 },
  slots: [95, "slot-95"],
  active: false,
});
export const consumedBindings95: readonly [number, string, boolean] = [
  destructured95.id, destructured95.second, destructured95.active,
];

interface BindingRecord96 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection96 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings96(input: BindingRecord96): BindingProjection96 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured96: BindingProjection96 = projectBindings96({
  id: 96,
  meta: { label: "item-96", score: 96 },
  slots: [96, "slot-96"],
});
export const consumedBindings96: readonly [number, string, boolean] = [
  destructured96.id, destructured96.second, destructured96.active,
];

interface BindingRecord97 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection97 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings97(input: BindingRecord97): BindingProjection97 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured97: BindingProjection97 = projectBindings97({
  id: 97,
  meta: { label: "item-97", score: 97 },
  slots: [97, "slot-97"],
  active: false,
});
export const consumedBindings97: readonly [number, string, boolean] = [
  destructured97.id, destructured97.second, destructured97.active,
];

interface BindingRecord98 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection98 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings98(input: BindingRecord98): BindingProjection98 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured98: BindingProjection98 = projectBindings98({
  id: 98,
  meta: { label: "item-98", score: 98 },
  slots: [98, "slot-98"],
});
export const consumedBindings98: readonly [number, string, boolean] = [
  destructured98.id, destructured98.second, destructured98.active,
];

interface BindingRecord99 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection99 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings99(input: BindingRecord99): BindingProjection99 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured99: BindingProjection99 = projectBindings99({
  id: 99,
  meta: { label: "item-99", score: 99 },
  slots: [99, "slot-99"],
  active: false,
});
export const consumedBindings99: readonly [number, string, boolean] = [
  destructured99.id, destructured99.second, destructured99.active,
];

interface BindingRecord100 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection100 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings100(input: BindingRecord100): BindingProjection100 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured100: BindingProjection100 = projectBindings100({
  id: 100,
  meta: { label: "item-100", score: 100 },
  slots: [100, "slot-100"],
});
export const consumedBindings100: readonly [number, string, boolean] = [
  destructured100.id, destructured100.second, destructured100.active,
];

interface BindingRecord101 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection101 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings101(input: BindingRecord101): BindingProjection101 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured101: BindingProjection101 = projectBindings101({
  id: 101,
  meta: { label: "item-101", score: 101 },
  slots: [101, "slot-101"],
  active: false,
});
export const consumedBindings101: readonly [number, string, boolean] = [
  destructured101.id, destructured101.second, destructured101.active,
];

interface BindingRecord102 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection102 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings102(input: BindingRecord102): BindingProjection102 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured102: BindingProjection102 = projectBindings102({
  id: 102,
  meta: { label: "item-102", score: 102 },
  slots: [102, "slot-102"],
});
export const consumedBindings102: readonly [number, string, boolean] = [
  destructured102.id, destructured102.second, destructured102.active,
];

interface BindingRecord103 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection103 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings103(input: BindingRecord103): BindingProjection103 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured103: BindingProjection103 = projectBindings103({
  id: 103,
  meta: { label: "item-103", score: 103 },
  slots: [103, "slot-103"],
  active: false,
});
export const consumedBindings103: readonly [number, string, boolean] = [
  destructured103.id, destructured103.second, destructured103.active,
];

interface BindingRecord104 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection104 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings104(input: BindingRecord104): BindingProjection104 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured104: BindingProjection104 = projectBindings104({
  id: 104,
  meta: { label: "item-104", score: 104 },
  slots: [104, "slot-104"],
});
export const consumedBindings104: readonly [number, string, boolean] = [
  destructured104.id, destructured104.second, destructured104.active,
];

interface BindingRecord105 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection105 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings105(input: BindingRecord105): BindingProjection105 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured105: BindingProjection105 = projectBindings105({
  id: 105,
  meta: { label: "item-105", score: 105 },
  slots: [105, "slot-105"],
  active: false,
});
export const consumedBindings105: readonly [number, string, boolean] = [
  destructured105.id, destructured105.second, destructured105.active,
];

interface BindingRecord106 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection106 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings106(input: BindingRecord106): BindingProjection106 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured106: BindingProjection106 = projectBindings106({
  id: 106,
  meta: { label: "item-106", score: 106 },
  slots: [106, "slot-106"],
});
export const consumedBindings106: readonly [number, string, boolean] = [
  destructured106.id, destructured106.second, destructured106.active,
];

interface BindingRecord107 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection107 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings107(input: BindingRecord107): BindingProjection107 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured107: BindingProjection107 = projectBindings107({
  id: 107,
  meta: { label: "item-107", score: 107 },
  slots: [107, "slot-107"],
  active: false,
});
export const consumedBindings107: readonly [number, string, boolean] = [
  destructured107.id, destructured107.second, destructured107.active,
];

interface BindingRecord108 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection108 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings108(input: BindingRecord108): BindingProjection108 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured108: BindingProjection108 = projectBindings108({
  id: 108,
  meta: { label: "item-108", score: 108 },
  slots: [108, "slot-108"],
});
export const consumedBindings108: readonly [number, string, boolean] = [
  destructured108.id, destructured108.second, destructured108.active,
];

interface BindingRecord109 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection109 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings109(input: BindingRecord109): BindingProjection109 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured109: BindingProjection109 = projectBindings109({
  id: 109,
  meta: { label: "item-109", score: 109 },
  slots: [109, "slot-109"],
  active: false,
});
export const consumedBindings109: readonly [number, string, boolean] = [
  destructured109.id, destructured109.second, destructured109.active,
];

interface BindingRecord110 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection110 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings110(input: BindingRecord110): BindingProjection110 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured110: BindingProjection110 = projectBindings110({
  id: 110,
  meta: { label: "item-110", score: 110 },
  slots: [110, "slot-110"],
});
export const consumedBindings110: readonly [number, string, boolean] = [
  destructured110.id, destructured110.second, destructured110.active,
];

interface BindingRecord111 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection111 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings111(input: BindingRecord111): BindingProjection111 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured111: BindingProjection111 = projectBindings111({
  id: 111,
  meta: { label: "item-111", score: 111 },
  slots: [111, "slot-111"],
  active: false,
});
export const consumedBindings111: readonly [number, string, boolean] = [
  destructured111.id, destructured111.second, destructured111.active,
];

interface BindingRecord112 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection112 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings112(input: BindingRecord112): BindingProjection112 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured112: BindingProjection112 = projectBindings112({
  id: 112,
  meta: { label: "item-112", score: 112 },
  slots: [112, "slot-112"],
});
export const consumedBindings112: readonly [number, string, boolean] = [
  destructured112.id, destructured112.second, destructured112.active,
];

interface BindingRecord113 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection113 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings113(input: BindingRecord113): BindingProjection113 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured113: BindingProjection113 = projectBindings113({
  id: 113,
  meta: { label: "item-113", score: 113 },
  slots: [113, "slot-113"],
  active: false,
});
export const consumedBindings113: readonly [number, string, boolean] = [
  destructured113.id, destructured113.second, destructured113.active,
];

interface BindingRecord114 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection114 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings114(input: BindingRecord114): BindingProjection114 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured114: BindingProjection114 = projectBindings114({
  id: 114,
  meta: { label: "item-114", score: 114 },
  slots: [114, "slot-114"],
});
export const consumedBindings114: readonly [number, string, boolean] = [
  destructured114.id, destructured114.second, destructured114.active,
];

interface BindingRecord115 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection115 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings115(input: BindingRecord115): BindingProjection115 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured115: BindingProjection115 = projectBindings115({
  id: 115,
  meta: { label: "item-115", score: 115 },
  slots: [115, "slot-115"],
  active: false,
});
export const consumedBindings115: readonly [number, string, boolean] = [
  destructured115.id, destructured115.second, destructured115.active,
];

interface BindingRecord116 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection116 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings116(input: BindingRecord116): BindingProjection116 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured116: BindingProjection116 = projectBindings116({
  id: 116,
  meta: { label: "item-116", score: 116 },
  slots: [116, "slot-116"],
});
export const consumedBindings116: readonly [number, string, boolean] = [
  destructured116.id, destructured116.second, destructured116.active,
];

interface BindingRecord117 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection117 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings117(input: BindingRecord117): BindingProjection117 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured117: BindingProjection117 = projectBindings117({
  id: 117,
  meta: { label: "item-117", score: 117 },
  slots: [117, "slot-117"],
  active: false,
});
export const consumedBindings117: readonly [number, string, boolean] = [
  destructured117.id, destructured117.second, destructured117.active,
];

interface BindingRecord118 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection118 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings118(input: BindingRecord118): BindingProjection118 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured118: BindingProjection118 = projectBindings118({
  id: 118,
  meta: { label: "item-118", score: 118 },
  slots: [118, "slot-118"],
});
export const consumedBindings118: readonly [number, string, boolean] = [
  destructured118.id, destructured118.second, destructured118.active,
];

interface BindingRecord119 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection119 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings119(input: BindingRecord119): BindingProjection119 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured119: BindingProjection119 = projectBindings119({
  id: 119,
  meta: { label: "item-119", score: 119 },
  slots: [119, "slot-119"],
  active: false,
});
export const consumedBindings119: readonly [number, string, boolean] = [
  destructured119.id, destructured119.second, destructured119.active,
];

interface BindingRecord120 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection120 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings120(input: BindingRecord120): BindingProjection120 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured120: BindingProjection120 = projectBindings120({
  id: 120,
  meta: { label: "item-120", score: 120 },
  slots: [120, "slot-120"],
});
export const consumedBindings120: readonly [number, string, boolean] = [
  destructured120.id, destructured120.second, destructured120.active,
];

interface BindingRecord121 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection121 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings121(input: BindingRecord121): BindingProjection121 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured121: BindingProjection121 = projectBindings121({
  id: 121,
  meta: { label: "item-121", score: 121 },
  slots: [121, "slot-121"],
  active: false,
});
export const consumedBindings121: readonly [number, string, boolean] = [
  destructured121.id, destructured121.second, destructured121.active,
];

interface BindingRecord122 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection122 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings122(input: BindingRecord122): BindingProjection122 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured122: BindingProjection122 = projectBindings122({
  id: 122,
  meta: { label: "item-122", score: 122 },
  slots: [122, "slot-122"],
});
export const consumedBindings122: readonly [number, string, boolean] = [
  destructured122.id, destructured122.second, destructured122.active,
];

interface BindingRecord123 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection123 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings123(input: BindingRecord123): BindingProjection123 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured123: BindingProjection123 = projectBindings123({
  id: 123,
  meta: { label: "item-123", score: 123 },
  slots: [123, "slot-123"],
  active: false,
});
export const consumedBindings123: readonly [number, string, boolean] = [
  destructured123.id, destructured123.second, destructured123.active,
];

interface BindingRecord124 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection124 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings124(input: BindingRecord124): BindingProjection124 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured124: BindingProjection124 = projectBindings124({
  id: 124,
  meta: { label: "item-124", score: 124 },
  slots: [124, "slot-124"],
});
export const consumedBindings124: readonly [number, string, boolean] = [
  destructured124.id, destructured124.second, destructured124.active,
];

interface BindingRecord125 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection125 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings125(input: BindingRecord125): BindingProjection125 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured125: BindingProjection125 = projectBindings125({
  id: 125,
  meta: { label: "item-125", score: 125 },
  slots: [125, "slot-125"],
  active: false,
});
export const consumedBindings125: readonly [number, string, boolean] = [
  destructured125.id, destructured125.second, destructured125.active,
];

interface BindingRecord126 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection126 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings126(input: BindingRecord126): BindingProjection126 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured126: BindingProjection126 = projectBindings126({
  id: 126,
  meta: { label: "item-126", score: 126 },
  slots: [126, "slot-126"],
});
export const consumedBindings126: readonly [number, string, boolean] = [
  destructured126.id, destructured126.second, destructured126.active,
];

interface BindingRecord127 {
  readonly id: number;
  readonly meta: { readonly label: string; readonly score: number };
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}

interface BindingProjection127 {
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}

function projectBindings127(input: BindingRecord127): BindingProjection127 {
  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;
  const spread = { ...identity, active, label, score, first, second };
  return spread;
}

export const destructured127: BindingProjection127 = projectBindings127({
  id: 127,
  meta: { label: "item-127", score: 127 },
  slots: [127, "slot-127"],
  active: false,
});
export const consumedBindings127: readonly [number, string, boolean] = [
  destructured127.id, destructured127.second, destructured127.active,
];

