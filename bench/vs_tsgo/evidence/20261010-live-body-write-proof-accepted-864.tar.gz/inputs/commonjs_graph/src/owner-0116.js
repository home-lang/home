class Service116 {
  id = 116;
  label = "service-116";
  meta = { active: true, score: 116 };
}
class Alternate116 {
  id = 116;
  label = 116;
  meta = { active: true, score: 116 };
}
module.exports = new Service116();
module.exports = new Alternate116();
