class Service68 {
  id = 68;
  label = "service-68";
  meta = { active: true, score: 68 };
}
class Alternate68 {
  id = 68;
  label = 68;
  meta = { active: true, score: 68 };
}
module.exports = new Service68();
module.exports = new Alternate68();
