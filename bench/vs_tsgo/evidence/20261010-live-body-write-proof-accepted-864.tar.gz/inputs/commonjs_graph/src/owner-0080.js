class Service80 {
  id = 80;
  label = "service-80";
  meta = { active: true, score: 80 };
}
class Alternate80 {
  id = 80;
  label = 80;
  meta = { active: true, score: 80 };
}
module.exports = new Service80();
module.exports = new Alternate80();
