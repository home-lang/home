class Service52 {
  id = 52;
  label = "service-52";
  meta = { active: true, score: 52 };
}
class Alternate52 {
  id = 52;
  label = 52;
  meta = { active: true, score: 52 };
}
module.exports = new Service52();
module.exports = new Alternate52();
