class Service29 {
  id = 29;
  label = "service-29";
  meta = { active: false, score: 29 };
}
class Alternate29 {
  id = 29;
  label = 29;
  meta = { active: false, score: 29 };
}
module.exports = new Service29();
module.exports = new Alternate29();
