class Service77 {
  id = 77;
  label = "service-77";
  meta = { active: false, score: 77 };
}
class Alternate77 {
  id = 77;
  label = 77;
  meta = { active: false, score: 77 };
}
module.exports = new Service77();
module.exports = new Alternate77();
