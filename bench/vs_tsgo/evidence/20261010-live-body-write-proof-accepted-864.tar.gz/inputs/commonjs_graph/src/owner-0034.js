class Service34 {
  id = 34;
  label = "service-34";
  meta = { active: true, score: 34 };
}
class Alternate34 {
  id = 34;
  label = 34;
  meta = { active: true, score: 34 };
}
module.exports = new Service34();
module.exports = new Alternate34();
