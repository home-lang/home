class Service69 {
  id = 69;
  label = "service-69";
  meta = { active: false, score: 69 };
}
class Alternate69 {
  id = 69;
  label = 69;
  meta = { active: false, score: 69 };
}
module.exports = new Service69();
module.exports = new Alternate69();
