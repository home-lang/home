class Service51 {
  id = 51;
  label = "service-51";
  meta = { active: false, score: 51 };
}
class Alternate51 {
  id = 51;
  label = 51;
  meta = { active: false, score: 51 };
}
module.exports = new Service51();
module.exports = new Alternate51();
