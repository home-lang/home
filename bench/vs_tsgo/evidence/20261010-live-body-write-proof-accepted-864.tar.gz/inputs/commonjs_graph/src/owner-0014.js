class Service14 {
  id = 14;
  label = "service-14";
  meta = { active: true, score: 14 };
}
class Alternate14 {
  id = 14;
  label = 14;
  meta = { active: true, score: 14 };
}
module.exports = new Service14();
module.exports = new Alternate14();
