class Service93 {
  id = 93;
  label = "service-93";
  meta = { active: false, score: 93 };
}
class Alternate93 {
  id = 93;
  label = 93;
  meta = { active: false, score: 93 };
}
module.exports = new Service93();
module.exports = new Alternate93();
