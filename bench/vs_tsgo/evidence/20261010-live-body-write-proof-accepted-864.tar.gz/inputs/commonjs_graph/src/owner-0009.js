class Service9 {
  id = 9;
  label = "service-9";
  meta = { active: false, score: 9 };
}
class Alternate9 {
  id = 9;
  label = 9;
  meta = { active: false, score: 9 };
}
module.exports = new Service9();
module.exports = new Alternate9();
