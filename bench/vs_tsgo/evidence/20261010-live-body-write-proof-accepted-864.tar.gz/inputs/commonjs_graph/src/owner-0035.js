class Service35 {
  id = 35;
  label = "service-35";
  meta = { active: false, score: 35 };
}
class Alternate35 {
  id = 35;
  label = 35;
  meta = { active: false, score: 35 };
}
module.exports = new Service35();
module.exports = new Alternate35();
