class Service12 {
  id = 12;
  label = "service-12";
  meta = { active: true, score: 12 };
}
class Alternate12 {
  id = 12;
  label = 12;
  meta = { active: true, score: 12 };
}
module.exports = new Service12();
module.exports = new Alternate12();
