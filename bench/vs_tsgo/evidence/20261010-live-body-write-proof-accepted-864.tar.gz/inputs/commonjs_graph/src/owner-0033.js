class Service33 {
  id = 33;
  label = "service-33";
  meta = { active: false, score: 33 };
}
class Alternate33 {
  id = 33;
  label = 33;
  meta = { active: false, score: 33 };
}
module.exports = new Service33();
module.exports = new Alternate33();
