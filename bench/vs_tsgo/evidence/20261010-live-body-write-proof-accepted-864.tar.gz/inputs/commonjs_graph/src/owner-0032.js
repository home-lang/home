class Service32 {
  id = 32;
  label = "service-32";
  meta = { active: true, score: 32 };
}
class Alternate32 {
  id = 32;
  label = 32;
  meta = { active: true, score: 32 };
}
module.exports = new Service32();
module.exports = new Alternate32();
