class Service19 {
  id = 19;
  label = "service-19";
  meta = { active: false, score: 19 };
}
class Alternate19 {
  id = 19;
  label = 19;
  meta = { active: false, score: 19 };
}
module.exports = new Service19();
module.exports = new Alternate19();
