class Service119 {
  id = 119;
  label = "service-119";
  meta = { active: false, score: 119 };
}
class Alternate119 {
  id = 119;
  label = 119;
  meta = { active: false, score: 119 };
}
module.exports = new Service119();
module.exports = new Alternate119();
