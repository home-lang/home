class Service110 {
  id = 110;
  label = "service-110";
  meta = { active: true, score: 110 };
}
class Alternate110 {
  id = 110;
  label = 110;
  meta = { active: true, score: 110 };
}
module.exports = new Service110();
module.exports = new Alternate110();
