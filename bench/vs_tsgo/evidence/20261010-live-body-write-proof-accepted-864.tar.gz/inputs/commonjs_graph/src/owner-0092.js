class Service92 {
  id = 92;
  label = "service-92";
  meta = { active: true, score: 92 };
}
class Alternate92 {
  id = 92;
  label = 92;
  meta = { active: true, score: 92 };
}
module.exports = new Service92();
module.exports = new Alternate92();
