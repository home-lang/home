class Service101 {
  id = 101;
  label = "service-101";
  meta = { active: false, score: 101 };
}
class Alternate101 {
  id = 101;
  label = 101;
  meta = { active: false, score: 101 };
}
module.exports = new Service101();
module.exports = new Alternate101();
