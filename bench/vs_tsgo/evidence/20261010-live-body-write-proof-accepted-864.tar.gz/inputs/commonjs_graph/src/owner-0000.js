class Service0 {
  id = 0;
  label = "service-0";
  meta = { active: true, score: 0 };
}
class Alternate0 {
  id = 0;
  label = 0;
  meta = { active: true, score: 0 };
}
module.exports = new Service0();
module.exports = new Alternate0();
