class Service26 {
  id = 26;
  label = "service-26";
  meta = { active: true, score: 26 };
}
class Alternate26 {
  id = 26;
  label = 26;
  meta = { active: true, score: 26 };
}
module.exports = new Service26();
module.exports = new Alternate26();
