class Service108 {
  id = 108;
  label = "service-108";
  meta = { active: true, score: 108 };
}
class Alternate108 {
  id = 108;
  label = 108;
  meta = { active: true, score: 108 };
}
module.exports = new Service108();
module.exports = new Alternate108();
