class Service23 {
  id = 23;
  label = "service-23";
  meta = { active: false, score: 23 };
}
class Alternate23 {
  id = 23;
  label = 23;
  meta = { active: false, score: 23 };
}
module.exports = new Service23();
module.exports = new Alternate23();
