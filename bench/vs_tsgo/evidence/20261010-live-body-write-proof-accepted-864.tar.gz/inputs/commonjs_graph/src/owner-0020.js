class Service20 {
  id = 20;
  label = "service-20";
  meta = { active: true, score: 20 };
}
class Alternate20 {
  id = 20;
  label = 20;
  meta = { active: true, score: 20 };
}
module.exports = new Service20();
module.exports = new Alternate20();
