class Service1 {
  id = 1;
  label = "service-1";
  meta = { active: false, score: 1 };
}
class Alternate1 {
  id = 1;
  label = 1;
  meta = { active: false, score: 1 };
}
module.exports = new Service1();
module.exports = new Alternate1();
