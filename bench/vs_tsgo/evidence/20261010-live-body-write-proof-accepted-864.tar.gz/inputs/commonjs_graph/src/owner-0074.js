class Service74 {
  id = 74;
  label = "service-74";
  meta = { active: true, score: 74 };
}
class Alternate74 {
  id = 74;
  label = 74;
  meta = { active: true, score: 74 };
}
module.exports = new Service74();
module.exports = new Alternate74();
