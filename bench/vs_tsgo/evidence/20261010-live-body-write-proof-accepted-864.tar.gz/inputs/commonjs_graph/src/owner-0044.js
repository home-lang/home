class Service44 {
  id = 44;
  label = "service-44";
  meta = { active: true, score: 44 };
}
class Alternate44 {
  id = 44;
  label = 44;
  meta = { active: true, score: 44 };
}
module.exports = new Service44();
module.exports = new Alternate44();
