class Service71 {
  id = 71;
  label = "service-71";
  meta = { active: false, score: 71 };
}
class Alternate71 {
  id = 71;
  label = 71;
  meta = { active: false, score: 71 };
}
module.exports = new Service71();
module.exports = new Alternate71();
