class Service88 {
  id = 88;
  label = "service-88";
  meta = { active: true, score: 88 };
}
class Alternate88 {
  id = 88;
  label = 88;
  meta = { active: true, score: 88 };
}
module.exports = new Service88();
module.exports = new Alternate88();
