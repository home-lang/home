class Service86 {
  id = 86;
  label = "service-86";
  meta = { active: true, score: 86 };
}
class Alternate86 {
  id = 86;
  label = 86;
  meta = { active: true, score: 86 };
}
module.exports = new Service86();
module.exports = new Alternate86();
