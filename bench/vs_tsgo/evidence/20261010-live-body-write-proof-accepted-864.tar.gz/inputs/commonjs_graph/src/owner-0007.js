class Service7 {
  id = 7;
  label = "service-7";
  meta = { active: false, score: 7 };
}
class Alternate7 {
  id = 7;
  label = 7;
  meta = { active: false, score: 7 };
}
module.exports = new Service7();
module.exports = new Alternate7();
