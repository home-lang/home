class Service55 {
  id = 55;
  label = "service-55";
  meta = { active: false, score: 55 };
}
class Alternate55 {
  id = 55;
  label = 55;
  meta = { active: false, score: 55 };
}
module.exports = new Service55();
module.exports = new Alternate55();
