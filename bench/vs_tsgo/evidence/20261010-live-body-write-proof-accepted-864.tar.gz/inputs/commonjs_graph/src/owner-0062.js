class Service62 {
  id = 62;
  label = "service-62";
  meta = { active: true, score: 62 };
}
class Alternate62 {
  id = 62;
  label = 62;
  meta = { active: true, score: 62 };
}
module.exports = new Service62();
module.exports = new Alternate62();
