class Service90 {
  id = 90;
  label = "service-90";
  meta = { active: true, score: 90 };
}
class Alternate90 {
  id = 90;
  label = 90;
  meta = { active: true, score: 90 };
}
module.exports = new Service90();
module.exports = new Alternate90();
