class Service61 {
  id = 61;
  label = "service-61";
  meta = { active: false, score: 61 };
}
class Alternate61 {
  id = 61;
  label = 61;
  meta = { active: false, score: 61 };
}
module.exports = new Service61();
module.exports = new Alternate61();
