class Service105 {
  id = 105;
  label = "service-105";
  meta = { active: false, score: 105 };
}
class Alternate105 {
  id = 105;
  label = 105;
  meta = { active: false, score: 105 };
}
module.exports = new Service105();
module.exports = new Alternate105();
