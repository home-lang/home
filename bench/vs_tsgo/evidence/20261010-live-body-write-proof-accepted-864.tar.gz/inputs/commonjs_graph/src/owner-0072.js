class Service72 {
  id = 72;
  label = "service-72";
  meta = { active: true, score: 72 };
}
class Alternate72 {
  id = 72;
  label = 72;
  meta = { active: true, score: 72 };
}
module.exports = new Service72();
module.exports = new Alternate72();
