class Service40 {
  id = 40;
  label = "service-40";
  meta = { active: true, score: 40 };
}
class Alternate40 {
  id = 40;
  label = 40;
  meta = { active: true, score: 40 };
}
module.exports = new Service40();
module.exports = new Alternate40();
