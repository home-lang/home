class Service30 {
  id = 30;
  label = "service-30";
  meta = { active: true, score: 30 };
}
class Alternate30 {
  id = 30;
  label = 30;
  meta = { active: true, score: 30 };
}
module.exports = new Service30();
module.exports = new Alternate30();
