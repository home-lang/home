class Service106 {
  id = 106;
  label = "service-106";
  meta = { active: true, score: 106 };
}
class Alternate106 {
  id = 106;
  label = 106;
  meta = { active: true, score: 106 };
}
module.exports = new Service106();
module.exports = new Alternate106();
