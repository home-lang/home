class Service60 {
  id = 60;
  label = "service-60";
  meta = { active: true, score: 60 };
}
class Alternate60 {
  id = 60;
  label = 60;
  meta = { active: true, score: 60 };
}
module.exports = new Service60();
module.exports = new Alternate60();
