class Service115 {
  id = 115;
  label = "service-115";
  meta = { active: false, score: 115 };
}
class Alternate115 {
  id = 115;
  label = 115;
  meta = { active: false, score: 115 };
}
module.exports = new Service115();
module.exports = new Alternate115();
