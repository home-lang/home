class Service103 {
  id = 103;
  label = "service-103";
  meta = { active: false, score: 103 };
}
class Alternate103 {
  id = 103;
  label = 103;
  meta = { active: false, score: 103 };
}
module.exports = new Service103();
module.exports = new Alternate103();
