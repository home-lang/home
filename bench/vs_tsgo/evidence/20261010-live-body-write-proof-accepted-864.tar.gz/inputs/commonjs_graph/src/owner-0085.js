class Service85 {
  id = 85;
  label = "service-85";
  meta = { active: false, score: 85 };
}
class Alternate85 {
  id = 85;
  label = 85;
  meta = { active: false, score: 85 };
}
module.exports = new Service85();
module.exports = new Alternate85();
