class Service120 {
  id = 120;
  label = "service-120";
  meta = { active: true, score: 120 };
}
class Alternate120 {
  id = 120;
  label = 120;
  meta = { active: true, score: 120 };
}
module.exports = new Service120();
module.exports = new Alternate120();
