class Service97 {
  id = 97;
  label = "service-97";
  meta = { active: false, score: 97 };
}
class Alternate97 {
  id = 97;
  label = 97;
  meta = { active: false, score: 97 };
}
module.exports = new Service97();
module.exports = new Alternate97();
