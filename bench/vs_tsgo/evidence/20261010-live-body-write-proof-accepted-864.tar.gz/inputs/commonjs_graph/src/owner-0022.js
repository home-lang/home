class Service22 {
  id = 22;
  label = "service-22";
  meta = { active: true, score: 22 };
}
class Alternate22 {
  id = 22;
  label = 22;
  meta = { active: true, score: 22 };
}
module.exports = new Service22();
module.exports = new Alternate22();
