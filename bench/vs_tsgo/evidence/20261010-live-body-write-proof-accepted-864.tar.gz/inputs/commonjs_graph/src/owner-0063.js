class Service63 {
  id = 63;
  label = "service-63";
  meta = { active: false, score: 63 };
}
class Alternate63 {
  id = 63;
  label = 63;
  meta = { active: false, score: 63 };
}
module.exports = new Service63();
module.exports = new Alternate63();
