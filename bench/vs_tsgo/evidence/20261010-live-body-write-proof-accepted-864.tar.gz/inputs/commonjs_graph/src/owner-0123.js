class Service123 {
  id = 123;
  label = "service-123";
  meta = { active: false, score: 123 };
}
class Alternate123 {
  id = 123;
  label = 123;
  meta = { active: false, score: 123 };
}
module.exports = new Service123();
module.exports = new Alternate123();
