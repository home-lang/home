class Service10 {
  id = 10;
  label = "service-10";
  meta = { active: true, score: 10 };
}
class Alternate10 {
  id = 10;
  label = 10;
  meta = { active: true, score: 10 };
}
module.exports = new Service10();
module.exports = new Alternate10();
