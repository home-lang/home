class Service42 {
  id = 42;
  label = "service-42";
  meta = { active: true, score: 42 };
}
class Alternate42 {
  id = 42;
  label = 42;
  meta = { active: true, score: 42 };
}
module.exports = new Service42();
module.exports = new Alternate42();
