class Service47 {
  id = 47;
  label = "service-47";
  meta = { active: false, score: 47 };
}
class Alternate47 {
  id = 47;
  label = 47;
  meta = { active: false, score: 47 };
}
module.exports = new Service47();
module.exports = new Alternate47();
