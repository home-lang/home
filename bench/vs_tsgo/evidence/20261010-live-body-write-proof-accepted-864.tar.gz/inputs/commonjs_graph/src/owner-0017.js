class Service17 {
  id = 17;
  label = "service-17";
  meta = { active: false, score: 17 };
}
class Alternate17 {
  id = 17;
  label = 17;
  meta = { active: false, score: 17 };
}
module.exports = new Service17();
module.exports = new Alternate17();
