class Service107 {
  id = 107;
  label = "service-107";
  meta = { active: false, score: 107 };
}
class Alternate107 {
  id = 107;
  label = 107;
  meta = { active: false, score: 107 };
}
module.exports = new Service107();
module.exports = new Alternate107();
