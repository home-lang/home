class Service39 {
  id = 39;
  label = "service-39";
  meta = { active: false, score: 39 };
}
class Alternate39 {
  id = 39;
  label = 39;
  meta = { active: false, score: 39 };
}
module.exports = new Service39();
module.exports = new Alternate39();
