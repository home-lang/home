class Service18 {
  id = 18;
  label = "service-18";
  meta = { active: true, score: 18 };
}
class Alternate18 {
  id = 18;
  label = 18;
  meta = { active: true, score: 18 };
}
module.exports = new Service18();
module.exports = new Alternate18();
