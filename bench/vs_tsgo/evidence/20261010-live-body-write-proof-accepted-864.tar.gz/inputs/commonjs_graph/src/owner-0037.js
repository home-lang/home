class Service37 {
  id = 37;
  label = "service-37";
  meta = { active: false, score: 37 };
}
class Alternate37 {
  id = 37;
  label = 37;
  meta = { active: false, score: 37 };
}
module.exports = new Service37();
module.exports = new Alternate37();
