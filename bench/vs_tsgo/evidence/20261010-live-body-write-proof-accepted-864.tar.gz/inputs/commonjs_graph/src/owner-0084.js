class Service84 {
  id = 84;
  label = "service-84";
  meta = { active: true, score: 84 };
}
class Alternate84 {
  id = 84;
  label = 84;
  meta = { active: true, score: 84 };
}
module.exports = new Service84();
module.exports = new Alternate84();
