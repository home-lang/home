class Service73 {
  id = 73;
  label = "service-73";
  meta = { active: false, score: 73 };
}
class Alternate73 {
  id = 73;
  label = 73;
  meta = { active: false, score: 73 };
}
module.exports = new Service73();
module.exports = new Alternate73();
