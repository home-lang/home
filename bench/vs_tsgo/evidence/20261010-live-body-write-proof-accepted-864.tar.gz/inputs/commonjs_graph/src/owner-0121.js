class Service121 {
  id = 121;
  label = "service-121";
  meta = { active: false, score: 121 };
}
class Alternate121 {
  id = 121;
  label = 121;
  meta = { active: false, score: 121 };
}
module.exports = new Service121();
module.exports = new Alternate121();
