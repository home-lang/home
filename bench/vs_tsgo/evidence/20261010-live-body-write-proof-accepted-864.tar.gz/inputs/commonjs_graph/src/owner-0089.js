class Service89 {
  id = 89;
  label = "service-89";
  meta = { active: false, score: 89 };
}
class Alternate89 {
  id = 89;
  label = 89;
  meta = { active: false, score: 89 };
}
module.exports = new Service89();
module.exports = new Alternate89();
