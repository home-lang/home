class Service100 {
  id = 100;
  label = "service-100";
  meta = { active: true, score: 100 };
}
class Alternate100 {
  id = 100;
  label = 100;
  meta = { active: true, score: 100 };
}
module.exports = new Service100();
module.exports = new Alternate100();
