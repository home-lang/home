class Service58 {
  id = 58;
  label = "service-58";
  meta = { active: true, score: 58 };
}
class Alternate58 {
  id = 58;
  label = 58;
  meta = { active: true, score: 58 };
}
module.exports = new Service58();
module.exports = new Alternate58();
