class Service28 {
  id = 28;
  label = "service-28";
  meta = { active: true, score: 28 };
}
class Alternate28 {
  id = 28;
  label = 28;
  meta = { active: true, score: 28 };
}
module.exports = new Service28();
module.exports = new Alternate28();
