class Service127 {
  id = 127;
  label = "service-127";
  meta = { active: false, score: 127 };
}
class Alternate127 {
  id = 127;
  label = 127;
  meta = { active: false, score: 127 };
}
module.exports = new Service127();
module.exports = new Alternate127();
