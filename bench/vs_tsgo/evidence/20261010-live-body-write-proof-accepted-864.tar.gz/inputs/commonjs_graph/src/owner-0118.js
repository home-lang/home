class Service118 {
  id = 118;
  label = "service-118";
  meta = { active: true, score: 118 };
}
class Alternate118 {
  id = 118;
  label = 118;
  meta = { active: true, score: 118 };
}
module.exports = new Service118();
module.exports = new Alternate118();
