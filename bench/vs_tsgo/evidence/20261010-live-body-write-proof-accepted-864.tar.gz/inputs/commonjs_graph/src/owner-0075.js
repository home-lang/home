class Service75 {
  id = 75;
  label = "service-75";
  meta = { active: false, score: 75 };
}
class Alternate75 {
  id = 75;
  label = 75;
  meta = { active: false, score: 75 };
}
module.exports = new Service75();
module.exports = new Alternate75();
