class Service66 {
  id = 66;
  label = "service-66";
  meta = { active: true, score: 66 };
}
class Alternate66 {
  id = 66;
  label = 66;
  meta = { active: true, score: 66 };
}
module.exports = new Service66();
module.exports = new Alternate66();
