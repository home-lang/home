class Service46 {
  id = 46;
  label = "service-46";
  meta = { active: true, score: 46 };
}
class Alternate46 {
  id = 46;
  label = 46;
  meta = { active: true, score: 46 };
}
module.exports = new Service46();
module.exports = new Alternate46();
