class Service102 {
  id = 102;
  label = "service-102";
  meta = { active: true, score: 102 };
}
class Alternate102 {
  id = 102;
  label = 102;
  meta = { active: true, score: 102 };
}
module.exports = new Service102();
module.exports = new Alternate102();
