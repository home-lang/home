class Service104 {
  id = 104;
  label = "service-104";
  meta = { active: true, score: 104 };
}
class Alternate104 {
  id = 104;
  label = 104;
  meta = { active: true, score: 104 };
}
module.exports = new Service104();
module.exports = new Alternate104();
