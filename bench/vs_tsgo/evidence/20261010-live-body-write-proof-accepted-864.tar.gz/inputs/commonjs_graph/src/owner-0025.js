class Service25 {
  id = 25;
  label = "service-25";
  meta = { active: false, score: 25 };
}
class Alternate25 {
  id = 25;
  label = 25;
  meta = { active: false, score: 25 };
}
module.exports = new Service25();
module.exports = new Alternate25();
