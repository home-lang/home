class Service41 {
  id = 41;
  label = "service-41";
  meta = { active: false, score: 41 };
}
class Alternate41 {
  id = 41;
  label = 41;
  meta = { active: false, score: 41 };
}
module.exports = new Service41();
module.exports = new Alternate41();
