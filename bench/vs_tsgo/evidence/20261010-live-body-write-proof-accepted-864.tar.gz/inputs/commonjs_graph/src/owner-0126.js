class Service126 {
  id = 126;
  label = "service-126";
  meta = { active: true, score: 126 };
}
class Alternate126 {
  id = 126;
  label = 126;
  meta = { active: true, score: 126 };
}
module.exports = new Service126();
module.exports = new Alternate126();
