class Service45 {
  id = 45;
  label = "service-45";
  meta = { active: false, score: 45 };
}
class Alternate45 {
  id = 45;
  label = 45;
  meta = { active: false, score: 45 };
}
module.exports = new Service45();
module.exports = new Alternate45();
