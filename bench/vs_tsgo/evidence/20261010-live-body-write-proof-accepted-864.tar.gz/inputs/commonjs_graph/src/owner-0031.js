class Service31 {
  id = 31;
  label = "service-31";
  meta = { active: false, score: 31 };
}
class Alternate31 {
  id = 31;
  label = 31;
  meta = { active: false, score: 31 };
}
module.exports = new Service31();
module.exports = new Alternate31();
