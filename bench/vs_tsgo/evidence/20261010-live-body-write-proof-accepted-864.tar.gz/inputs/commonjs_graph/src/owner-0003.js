class Service3 {
  id = 3;
  label = "service-3";
  meta = { active: false, score: 3 };
}
class Alternate3 {
  id = 3;
  label = 3;
  meta = { active: false, score: 3 };
}
module.exports = new Service3();
module.exports = new Alternate3();
