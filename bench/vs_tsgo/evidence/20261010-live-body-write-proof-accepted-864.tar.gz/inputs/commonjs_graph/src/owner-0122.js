class Service122 {
  id = 122;
  label = "service-122";
  meta = { active: true, score: 122 };
}
class Alternate122 {
  id = 122;
  label = 122;
  meta = { active: true, score: 122 };
}
module.exports = new Service122();
module.exports = new Alternate122();
