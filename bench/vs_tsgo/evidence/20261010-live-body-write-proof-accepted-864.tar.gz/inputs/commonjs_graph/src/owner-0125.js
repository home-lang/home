class Service125 {
  id = 125;
  label = "service-125";
  meta = { active: false, score: 125 };
}
class Alternate125 {
  id = 125;
  label = 125;
  meta = { active: false, score: 125 };
}
module.exports = new Service125();
module.exports = new Alternate125();
