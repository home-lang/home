class Service50 {
  id = 50;
  label = "service-50";
  meta = { active: true, score: 50 };
}
class Alternate50 {
  id = 50;
  label = 50;
  meta = { active: true, score: 50 };
}
module.exports = new Service50();
module.exports = new Alternate50();
