class Service15 {
  id = 15;
  label = "service-15";
  meta = { active: false, score: 15 };
}
class Alternate15 {
  id = 15;
  label = 15;
  meta = { active: false, score: 15 };
}
module.exports = new Service15();
module.exports = new Alternate15();
