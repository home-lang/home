class Service112 {
  id = 112;
  label = "service-112";
  meta = { active: true, score: 112 };
}
class Alternate112 {
  id = 112;
  label = 112;
  meta = { active: true, score: 112 };
}
module.exports = new Service112();
module.exports = new Alternate112();
