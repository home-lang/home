class Service83 {
  id = 83;
  label = "service-83";
  meta = { active: false, score: 83 };
}
class Alternate83 {
  id = 83;
  label = 83;
  meta = { active: false, score: 83 };
}
module.exports = new Service83();
module.exports = new Alternate83();
