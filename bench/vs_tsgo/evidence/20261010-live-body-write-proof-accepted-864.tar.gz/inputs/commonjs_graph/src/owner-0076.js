class Service76 {
  id = 76;
  label = "service-76";
  meta = { active: true, score: 76 };
}
class Alternate76 {
  id = 76;
  label = 76;
  meta = { active: true, score: 76 };
}
module.exports = new Service76();
module.exports = new Alternate76();
