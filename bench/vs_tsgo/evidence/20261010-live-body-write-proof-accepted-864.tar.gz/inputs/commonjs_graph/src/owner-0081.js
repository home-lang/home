class Service81 {
  id = 81;
  label = "service-81";
  meta = { active: false, score: 81 };
}
class Alternate81 {
  id = 81;
  label = 81;
  meta = { active: false, score: 81 };
}
module.exports = new Service81();
module.exports = new Alternate81();
