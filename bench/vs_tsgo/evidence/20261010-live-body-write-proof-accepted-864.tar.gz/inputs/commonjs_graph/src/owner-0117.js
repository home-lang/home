class Service117 {
  id = 117;
  label = "service-117";
  meta = { active: false, score: 117 };
}
class Alternate117 {
  id = 117;
  label = 117;
  meta = { active: false, score: 117 };
}
module.exports = new Service117();
module.exports = new Alternate117();
