class Service91 {
  id = 91;
  label = "service-91";
  meta = { active: false, score: 91 };
}
class Alternate91 {
  id = 91;
  label = 91;
  meta = { active: false, score: 91 };
}
module.exports = new Service91();
module.exports = new Alternate91();
