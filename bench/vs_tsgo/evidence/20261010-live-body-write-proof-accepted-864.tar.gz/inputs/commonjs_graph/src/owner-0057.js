class Service57 {
  id = 57;
  label = "service-57";
  meta = { active: false, score: 57 };
}
class Alternate57 {
  id = 57;
  label = 57;
  meta = { active: false, score: 57 };
}
module.exports = new Service57();
module.exports = new Alternate57();
