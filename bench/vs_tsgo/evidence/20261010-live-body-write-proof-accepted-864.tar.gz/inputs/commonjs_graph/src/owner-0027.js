class Service27 {
  id = 27;
  label = "service-27";
  meta = { active: false, score: 27 };
}
class Alternate27 {
  id = 27;
  label = 27;
  meta = { active: false, score: 27 };
}
module.exports = new Service27();
module.exports = new Alternate27();
