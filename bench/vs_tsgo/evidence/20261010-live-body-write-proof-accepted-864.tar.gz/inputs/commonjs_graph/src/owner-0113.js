class Service113 {
  id = 113;
  label = "service-113";
  meta = { active: false, score: 113 };
}
class Alternate113 {
  id = 113;
  label = 113;
  meta = { active: false, score: 113 };
}
module.exports = new Service113();
module.exports = new Alternate113();
