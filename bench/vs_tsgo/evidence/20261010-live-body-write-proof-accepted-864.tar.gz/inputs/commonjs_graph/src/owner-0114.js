class Service114 {
  id = 114;
  label = "service-114";
  meta = { active: true, score: 114 };
}
class Alternate114 {
  id = 114;
  label = 114;
  meta = { active: true, score: 114 };
}
module.exports = new Service114();
module.exports = new Alternate114();
