class Service124 {
  id = 124;
  label = "service-124";
  meta = { active: true, score: 124 };
}
class Alternate124 {
  id = 124;
  label = 124;
  meta = { active: true, score: 124 };
}
module.exports = new Service124();
module.exports = new Alternate124();
