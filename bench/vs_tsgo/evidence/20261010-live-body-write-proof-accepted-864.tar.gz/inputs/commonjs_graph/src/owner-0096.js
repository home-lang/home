class Service96 {
  id = 96;
  label = "service-96";
  meta = { active: true, score: 96 };
}
class Alternate96 {
  id = 96;
  label = 96;
  meta = { active: true, score: 96 };
}
module.exports = new Service96();
module.exports = new Alternate96();
