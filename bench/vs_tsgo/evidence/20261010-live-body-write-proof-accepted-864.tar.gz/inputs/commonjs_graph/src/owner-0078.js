class Service78 {
  id = 78;
  label = "service-78";
  meta = { active: true, score: 78 };
}
class Alternate78 {
  id = 78;
  label = 78;
  meta = { active: true, score: 78 };
}
module.exports = new Service78();
module.exports = new Alternate78();
