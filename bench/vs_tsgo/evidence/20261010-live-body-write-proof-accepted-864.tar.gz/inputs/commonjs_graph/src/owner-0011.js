class Service11 {
  id = 11;
  label = "service-11";
  meta = { active: false, score: 11 };
}
class Alternate11 {
  id = 11;
  label = 11;
  meta = { active: false, score: 11 };
}
module.exports = new Service11();
module.exports = new Alternate11();
