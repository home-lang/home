class Service94 {
  id = 94;
  label = "service-94";
  meta = { active: true, score: 94 };
}
class Alternate94 {
  id = 94;
  label = 94;
  meta = { active: true, score: 94 };
}
module.exports = new Service94();
module.exports = new Alternate94();
