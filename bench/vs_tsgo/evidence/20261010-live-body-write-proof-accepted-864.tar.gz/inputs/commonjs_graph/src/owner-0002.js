class Service2 {
  id = 2;
  label = "service-2";
  meta = { active: true, score: 2 };
}
class Alternate2 {
  id = 2;
  label = 2;
  meta = { active: true, score: 2 };
}
module.exports = new Service2();
module.exports = new Alternate2();
