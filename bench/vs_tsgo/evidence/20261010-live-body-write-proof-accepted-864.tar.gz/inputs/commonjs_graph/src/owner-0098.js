class Service98 {
  id = 98;
  label = "service-98";
  meta = { active: true, score: 98 };
}
class Alternate98 {
  id = 98;
  label = 98;
  meta = { active: true, score: 98 };
}
module.exports = new Service98();
module.exports = new Alternate98();
