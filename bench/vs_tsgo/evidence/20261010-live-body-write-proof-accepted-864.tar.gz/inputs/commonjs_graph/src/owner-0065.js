class Service65 {
  id = 65;
  label = "service-65";
  meta = { active: false, score: 65 };
}
class Alternate65 {
  id = 65;
  label = 65;
  meta = { active: false, score: 65 };
}
module.exports = new Service65();
module.exports = new Alternate65();
