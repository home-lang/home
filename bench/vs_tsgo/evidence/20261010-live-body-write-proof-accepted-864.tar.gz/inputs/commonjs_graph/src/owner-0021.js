class Service21 {
  id = 21;
  label = "service-21";
  meta = { active: false, score: 21 };
}
class Alternate21 {
  id = 21;
  label = 21;
  meta = { active: false, score: 21 };
}
module.exports = new Service21();
module.exports = new Alternate21();
