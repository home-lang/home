class Service48 {
  id = 48;
  label = "service-48";
  meta = { active: true, score: 48 };
}
class Alternate48 {
  id = 48;
  label = 48;
  meta = { active: true, score: 48 };
}
module.exports = new Service48();
module.exports = new Alternate48();
