class Service38 {
  id = 38;
  label = "service-38";
  meta = { active: true, score: 38 };
}
class Alternate38 {
  id = 38;
  label = 38;
  meta = { active: true, score: 38 };
}
module.exports = new Service38();
module.exports = new Alternate38();
