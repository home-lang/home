class Service43 {
  id = 43;
  label = "service-43";
  meta = { active: false, score: 43 };
}
class Alternate43 {
  id = 43;
  label = 43;
  meta = { active: false, score: 43 };
}
module.exports = new Service43();
module.exports = new Alternate43();
