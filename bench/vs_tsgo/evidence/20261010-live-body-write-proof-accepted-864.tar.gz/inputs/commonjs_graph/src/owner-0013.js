class Service13 {
  id = 13;
  label = "service-13";
  meta = { active: false, score: 13 };
}
class Alternate13 {
  id = 13;
  label = 13;
  meta = { active: false, score: 13 };
}
module.exports = new Service13();
module.exports = new Alternate13();
