class Service24 {
  id = 24;
  label = "service-24";
  meta = { active: true, score: 24 };
}
class Alternate24 {
  id = 24;
  label = 24;
  meta = { active: true, score: 24 };
}
module.exports = new Service24();
module.exports = new Alternate24();
