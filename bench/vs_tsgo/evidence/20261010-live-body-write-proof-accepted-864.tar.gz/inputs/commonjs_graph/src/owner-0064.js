class Service64 {
  id = 64;
  label = "service-64";
  meta = { active: true, score: 64 };
}
class Alternate64 {
  id = 64;
  label = 64;
  meta = { active: true, score: 64 };
}
module.exports = new Service64();
module.exports = new Alternate64();
