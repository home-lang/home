class Service53 {
  id = 53;
  label = "service-53";
  meta = { active: false, score: 53 };
}
class Alternate53 {
  id = 53;
  label = 53;
  meta = { active: false, score: 53 };
}
module.exports = new Service53();
module.exports = new Alternate53();
