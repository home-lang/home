class Service70 {
  id = 70;
  label = "service-70";
  meta = { active: true, score: 70 };
}
class Alternate70 {
  id = 70;
  label = 70;
  meta = { active: true, score: 70 };
}
module.exports = new Service70();
module.exports = new Alternate70();
