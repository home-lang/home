class Service99 {
  id = 99;
  label = "service-99";
  meta = { active: false, score: 99 };
}
class Alternate99 {
  id = 99;
  label = 99;
  meta = { active: false, score: 99 };
}
module.exports = new Service99();
module.exports = new Alternate99();
