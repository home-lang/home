class Service5 {
  id = 5;
  label = "service-5";
  meta = { active: false, score: 5 };
}
class Alternate5 {
  id = 5;
  label = 5;
  meta = { active: false, score: 5 };
}
module.exports = new Service5();
module.exports = new Alternate5();
