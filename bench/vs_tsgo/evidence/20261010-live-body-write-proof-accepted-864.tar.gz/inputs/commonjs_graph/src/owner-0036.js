class Service36 {
  id = 36;
  label = "service-36";
  meta = { active: true, score: 36 };
}
class Alternate36 {
  id = 36;
  label = 36;
  meta = { active: true, score: 36 };
}
module.exports = new Service36();
module.exports = new Alternate36();
