class Service87 {
  id = 87;
  label = "service-87";
  meta = { active: false, score: 87 };
}
class Alternate87 {
  id = 87;
  label = 87;
  meta = { active: false, score: 87 };
}
module.exports = new Service87();
module.exports = new Alternate87();
