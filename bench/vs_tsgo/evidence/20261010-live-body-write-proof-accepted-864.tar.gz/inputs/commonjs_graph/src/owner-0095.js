class Service95 {
  id = 95;
  label = "service-95";
  meta = { active: false, score: 95 };
}
class Alternate95 {
  id = 95;
  label = 95;
  meta = { active: false, score: 95 };
}
module.exports = new Service95();
module.exports = new Alternate95();
