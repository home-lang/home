class Service111 {
  id = 111;
  label = "service-111";
  meta = { active: false, score: 111 };
}
class Alternate111 {
  id = 111;
  label = 111;
  meta = { active: false, score: 111 };
}
module.exports = new Service111();
module.exports = new Alternate111();
