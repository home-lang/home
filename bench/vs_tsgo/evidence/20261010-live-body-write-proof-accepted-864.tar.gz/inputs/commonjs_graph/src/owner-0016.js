class Service16 {
  id = 16;
  label = "service-16";
  meta = { active: true, score: 16 };
}
class Alternate16 {
  id = 16;
  label = 16;
  meta = { active: true, score: 16 };
}
module.exports = new Service16();
module.exports = new Alternate16();
