class Service6 {
  id = 6;
  label = "service-6";
  meta = { active: true, score: 6 };
}
class Alternate6 {
  id = 6;
  label = 6;
  meta = { active: true, score: 6 };
}
module.exports = new Service6();
module.exports = new Alternate6();
