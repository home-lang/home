class Service4 {
  id = 4;
  label = "service-4";
  meta = { active: true, score: 4 };
}
class Alternate4 {
  id = 4;
  label = 4;
  meta = { active: true, score: 4 };
}
module.exports = new Service4();
module.exports = new Alternate4();
