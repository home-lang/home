class Service67 {
  id = 67;
  label = "service-67";
  meta = { active: false, score: 67 };
}
class Alternate67 {
  id = 67;
  label = 67;
  meta = { active: false, score: 67 };
}
module.exports = new Service67();
module.exports = new Alternate67();
