class Service8 {
  id = 8;
  label = "service-8";
  meta = { active: true, score: 8 };
}
class Alternate8 {
  id = 8;
  label = 8;
  meta = { active: true, score: 8 };
}
module.exports = new Service8();
module.exports = new Alternate8();
