interface View0<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base0<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived0 extends Base0<{ readonly label: string; readonly score: number }, 0> implements View0<0> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(0, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance0: Derived0 = new Derived0("item-0", 0);
const view0: View0<0> = instance0;
export const classResult0: readonly [0, string, number, string] = [
  view0.id, view0.label, instance0.score(), view0.describe("class"),
];

interface View1<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base1<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived1 extends Base1<{ readonly label: string; readonly score: number }, 1> implements View1<1> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(1, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance1: Derived1 = new Derived1("item-1", 1);
const view1: View1<1> = instance1;
export const classResult1: readonly [1, string, number, string] = [
  view1.id, view1.label, instance1.score(), view1.describe("class"),
];

interface View2<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base2<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived2 extends Base2<{ readonly label: string; readonly score: number }, 2> implements View2<2> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(2, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance2: Derived2 = new Derived2("item-2", 2);
const view2: View2<2> = instance2;
export const classResult2: readonly [2, string, number, string] = [
  view2.id, view2.label, instance2.score(), view2.describe("class"),
];

interface View3<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base3<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived3 extends Base3<{ readonly label: string; readonly score: number }, 3> implements View3<3> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(3, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance3: Derived3 = new Derived3("item-3", 3);
const view3: View3<3> = instance3;
export const classResult3: readonly [3, string, number, string] = [
  view3.id, view3.label, instance3.score(), view3.describe("class"),
];

interface View4<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base4<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived4 extends Base4<{ readonly label: string; readonly score: number }, 4> implements View4<4> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(4, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance4: Derived4 = new Derived4("item-4", 4);
const view4: View4<4> = instance4;
export const classResult4: readonly [4, string, number, string] = [
  view4.id, view4.label, instance4.score(), view4.describe("class"),
];

interface View5<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base5<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived5 extends Base5<{ readonly label: string; readonly score: number }, 5> implements View5<5> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(5, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance5: Derived5 = new Derived5("item-5", 5);
const view5: View5<5> = instance5;
export const classResult5: readonly [5, string, number, string] = [
  view5.id, view5.label, instance5.score(), view5.describe("class"),
];

interface View6<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base6<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived6 extends Base6<{ readonly label: string; readonly score: number }, 6> implements View6<6> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(6, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance6: Derived6 = new Derived6("item-6", 6);
const view6: View6<6> = instance6;
export const classResult6: readonly [6, string, number, string] = [
  view6.id, view6.label, instance6.score(), view6.describe("class"),
];

interface View7<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base7<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived7 extends Base7<{ readonly label: string; readonly score: number }, 7> implements View7<7> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(7, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance7: Derived7 = new Derived7("item-7", 7);
const view7: View7<7> = instance7;
export const classResult7: readonly [7, string, number, string] = [
  view7.id, view7.label, instance7.score(), view7.describe("class"),
];

interface View8<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base8<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived8 extends Base8<{ readonly label: string; readonly score: number }, 8> implements View8<8> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(8, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance8: Derived8 = new Derived8("item-8", 8);
const view8: View8<8> = instance8;
export const classResult8: readonly [8, string, number, string] = [
  view8.id, view8.label, instance8.score(), view8.describe("class"),
];

interface View9<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base9<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived9 extends Base9<{ readonly label: string; readonly score: number }, 9> implements View9<9> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(9, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance9: Derived9 = new Derived9("item-9", 9);
const view9: View9<9> = instance9;
export const classResult9: readonly [9, string, number, string] = [
  view9.id, view9.label, instance9.score(), view9.describe("class"),
];

interface View10<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base10<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived10 extends Base10<{ readonly label: string; readonly score: number }, 10> implements View10<10> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(10, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance10: Derived10 = new Derived10("item-10", 10);
const view10: View10<10> = instance10;
export const classResult10: readonly [10, string, number, string] = [
  view10.id, view10.label, instance10.score(), view10.describe("class"),
];

interface View11<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base11<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived11 extends Base11<{ readonly label: string; readonly score: number }, 11> implements View11<11> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(11, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance11: Derived11 = new Derived11("item-11", 11);
const view11: View11<11> = instance11;
export const classResult11: readonly [11, string, number, string] = [
  view11.id, view11.label, instance11.score(), view11.describe("class"),
];

interface View12<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base12<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived12 extends Base12<{ readonly label: string; readonly score: number }, 12> implements View12<12> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(12, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance12: Derived12 = new Derived12("item-12", 12);
const view12: View12<12> = instance12;
export const classResult12: readonly [12, string, number, string] = [
  view12.id, view12.label, instance12.score(), view12.describe("class"),
];

interface View13<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base13<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived13 extends Base13<{ readonly label: string; readonly score: number }, 13> implements View13<13> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(13, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance13: Derived13 = new Derived13("item-13", 13);
const view13: View13<13> = instance13;
export const classResult13: readonly [13, string, number, string] = [
  view13.id, view13.label, instance13.score(), view13.describe("class"),
];

interface View14<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base14<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived14 extends Base14<{ readonly label: string; readonly score: number }, 14> implements View14<14> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(14, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance14: Derived14 = new Derived14("item-14", 14);
const view14: View14<14> = instance14;
export const classResult14: readonly [14, string, number, string] = [
  view14.id, view14.label, instance14.score(), view14.describe("class"),
];

interface View15<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base15<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived15 extends Base15<{ readonly label: string; readonly score: number }, 15> implements View15<15> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(15, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance15: Derived15 = new Derived15("item-15", 15);
const view15: View15<15> = instance15;
export const classResult15: readonly [15, string, number, string] = [
  view15.id, view15.label, instance15.score(), view15.describe("class"),
];

interface View16<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base16<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived16 extends Base16<{ readonly label: string; readonly score: number }, 16> implements View16<16> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(16, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance16: Derived16 = new Derived16("item-16", 16);
const view16: View16<16> = instance16;
export const classResult16: readonly [16, string, number, string] = [
  view16.id, view16.label, instance16.score(), view16.describe("class"),
];

interface View17<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base17<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived17 extends Base17<{ readonly label: string; readonly score: number }, 17> implements View17<17> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(17, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance17: Derived17 = new Derived17("item-17", 17);
const view17: View17<17> = instance17;
export const classResult17: readonly [17, string, number, string] = [
  view17.id, view17.label, instance17.score(), view17.describe("class"),
];

interface View18<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base18<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived18 extends Base18<{ readonly label: string; readonly score: number }, 18> implements View18<18> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(18, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance18: Derived18 = new Derived18("item-18", 18);
const view18: View18<18> = instance18;
export const classResult18: readonly [18, string, number, string] = [
  view18.id, view18.label, instance18.score(), view18.describe("class"),
];

interface View19<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base19<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived19 extends Base19<{ readonly label: string; readonly score: number }, 19> implements View19<19> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(19, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance19: Derived19 = new Derived19("item-19", 19);
const view19: View19<19> = instance19;
export const classResult19: readonly [19, string, number, string] = [
  view19.id, view19.label, instance19.score(), view19.describe("class"),
];

interface View20<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base20<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived20 extends Base20<{ readonly label: string; readonly score: number }, 20> implements View20<20> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(20, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance20: Derived20 = new Derived20("item-20", 20);
const view20: View20<20> = instance20;
export const classResult20: readonly [20, string, number, string] = [
  view20.id, view20.label, instance20.score(), view20.describe("class"),
];

interface View21<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base21<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived21 extends Base21<{ readonly label: string; readonly score: number }, 21> implements View21<21> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(21, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance21: Derived21 = new Derived21("item-21", 21);
const view21: View21<21> = instance21;
export const classResult21: readonly [21, string, number, string] = [
  view21.id, view21.label, instance21.score(), view21.describe("class"),
];

interface View22<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base22<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived22 extends Base22<{ readonly label: string; readonly score: number }, 22> implements View22<22> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(22, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance22: Derived22 = new Derived22("item-22", 22);
const view22: View22<22> = instance22;
export const classResult22: readonly [22, string, number, string] = [
  view22.id, view22.label, instance22.score(), view22.describe("class"),
];

interface View23<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base23<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived23 extends Base23<{ readonly label: string; readonly score: number }, 23> implements View23<23> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(23, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance23: Derived23 = new Derived23("item-23", 23);
const view23: View23<23> = instance23;
export const classResult23: readonly [23, string, number, string] = [
  view23.id, view23.label, instance23.score(), view23.describe("class"),
];

interface View24<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base24<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived24 extends Base24<{ readonly label: string; readonly score: number }, 24> implements View24<24> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(24, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance24: Derived24 = new Derived24("item-24", 24);
const view24: View24<24> = instance24;
export const classResult24: readonly [24, string, number, string] = [
  view24.id, view24.label, instance24.score(), view24.describe("class"),
];

interface View25<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base25<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived25 extends Base25<{ readonly label: string; readonly score: number }, 25> implements View25<25> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(25, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance25: Derived25 = new Derived25("item-25", 25);
const view25: View25<25> = instance25;
export const classResult25: readonly [25, string, number, string] = [
  view25.id, view25.label, instance25.score(), view25.describe("class"),
];

interface View26<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base26<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived26 extends Base26<{ readonly label: string; readonly score: number }, 26> implements View26<26> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(26, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance26: Derived26 = new Derived26("item-26", 26);
const view26: View26<26> = instance26;
export const classResult26: readonly [26, string, number, string] = [
  view26.id, view26.label, instance26.score(), view26.describe("class"),
];

interface View27<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base27<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived27 extends Base27<{ readonly label: string; readonly score: number }, 27> implements View27<27> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(27, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance27: Derived27 = new Derived27("item-27", 27);
const view27: View27<27> = instance27;
export const classResult27: readonly [27, string, number, string] = [
  view27.id, view27.label, instance27.score(), view27.describe("class"),
];

interface View28<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base28<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived28 extends Base28<{ readonly label: string; readonly score: number }, 28> implements View28<28> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(28, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance28: Derived28 = new Derived28("item-28", 28);
const view28: View28<28> = instance28;
export const classResult28: readonly [28, string, number, string] = [
  view28.id, view28.label, instance28.score(), view28.describe("class"),
];

interface View29<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base29<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived29 extends Base29<{ readonly label: string; readonly score: number }, 29> implements View29<29> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(29, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance29: Derived29 = new Derived29("item-29", 29);
const view29: View29<29> = instance29;
export const classResult29: readonly [29, string, number, string] = [
  view29.id, view29.label, instance29.score(), view29.describe("class"),
];

interface View30<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base30<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived30 extends Base30<{ readonly label: string; readonly score: number }, 30> implements View30<30> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(30, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance30: Derived30 = new Derived30("item-30", 30);
const view30: View30<30> = instance30;
export const classResult30: readonly [30, string, number, string] = [
  view30.id, view30.label, instance30.score(), view30.describe("class"),
];

interface View31<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base31<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived31 extends Base31<{ readonly label: string; readonly score: number }, 31> implements View31<31> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(31, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance31: Derived31 = new Derived31("item-31", 31);
const view31: View31<31> = instance31;
export const classResult31: readonly [31, string, number, string] = [
  view31.id, view31.label, instance31.score(), view31.describe("class"),
];

interface View32<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base32<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived32 extends Base32<{ readonly label: string; readonly score: number }, 32> implements View32<32> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(32, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance32: Derived32 = new Derived32("item-32", 32);
const view32: View32<32> = instance32;
export const classResult32: readonly [32, string, number, string] = [
  view32.id, view32.label, instance32.score(), view32.describe("class"),
];

interface View33<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base33<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived33 extends Base33<{ readonly label: string; readonly score: number }, 33> implements View33<33> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(33, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance33: Derived33 = new Derived33("item-33", 33);
const view33: View33<33> = instance33;
export const classResult33: readonly [33, string, number, string] = [
  view33.id, view33.label, instance33.score(), view33.describe("class"),
];

interface View34<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base34<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived34 extends Base34<{ readonly label: string; readonly score: number }, 34> implements View34<34> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(34, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance34: Derived34 = new Derived34("item-34", 34);
const view34: View34<34> = instance34;
export const classResult34: readonly [34, string, number, string] = [
  view34.id, view34.label, instance34.score(), view34.describe("class"),
];

interface View35<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base35<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived35 extends Base35<{ readonly label: string; readonly score: number }, 35> implements View35<35> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(35, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance35: Derived35 = new Derived35("item-35", 35);
const view35: View35<35> = instance35;
export const classResult35: readonly [35, string, number, string] = [
  view35.id, view35.label, instance35.score(), view35.describe("class"),
];

interface View36<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base36<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived36 extends Base36<{ readonly label: string; readonly score: number }, 36> implements View36<36> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(36, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance36: Derived36 = new Derived36("item-36", 36);
const view36: View36<36> = instance36;
export const classResult36: readonly [36, string, number, string] = [
  view36.id, view36.label, instance36.score(), view36.describe("class"),
];

interface View37<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base37<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived37 extends Base37<{ readonly label: string; readonly score: number }, 37> implements View37<37> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(37, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance37: Derived37 = new Derived37("item-37", 37);
const view37: View37<37> = instance37;
export const classResult37: readonly [37, string, number, string] = [
  view37.id, view37.label, instance37.score(), view37.describe("class"),
];

interface View38<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base38<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived38 extends Base38<{ readonly label: string; readonly score: number }, 38> implements View38<38> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(38, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance38: Derived38 = new Derived38("item-38", 38);
const view38: View38<38> = instance38;
export const classResult38: readonly [38, string, number, string] = [
  view38.id, view38.label, instance38.score(), view38.describe("class"),
];

interface View39<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base39<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived39 extends Base39<{ readonly label: string; readonly score: number }, 39> implements View39<39> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(39, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance39: Derived39 = new Derived39("item-39", 39);
const view39: View39<39> = instance39;
export const classResult39: readonly [39, string, number, string] = [
  view39.id, view39.label, instance39.score(), view39.describe("class"),
];

interface View40<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base40<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived40 extends Base40<{ readonly label: string; readonly score: number }, 40> implements View40<40> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(40, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance40: Derived40 = new Derived40("item-40", 40);
const view40: View40<40> = instance40;
export const classResult40: readonly [40, string, number, string] = [
  view40.id, view40.label, instance40.score(), view40.describe("class"),
];

interface View41<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base41<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived41 extends Base41<{ readonly label: string; readonly score: number }, 41> implements View41<41> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(41, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance41: Derived41 = new Derived41("item-41", 41);
const view41: View41<41> = instance41;
export const classResult41: readonly [41, string, number, string] = [
  view41.id, view41.label, instance41.score(), view41.describe("class"),
];

interface View42<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base42<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived42 extends Base42<{ readonly label: string; readonly score: number }, 42> implements View42<42> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(42, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance42: Derived42 = new Derived42("item-42", 42);
const view42: View42<42> = instance42;
export const classResult42: readonly [42, string, number, string] = [
  view42.id, view42.label, instance42.score(), view42.describe("class"),
];

interface View43<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base43<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived43 extends Base43<{ readonly label: string; readonly score: number }, 43> implements View43<43> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(43, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance43: Derived43 = new Derived43("item-43", 43);
const view43: View43<43> = instance43;
export const classResult43: readonly [43, string, number, string] = [
  view43.id, view43.label, instance43.score(), view43.describe("class"),
];

interface View44<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base44<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived44 extends Base44<{ readonly label: string; readonly score: number }, 44> implements View44<44> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(44, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance44: Derived44 = new Derived44("item-44", 44);
const view44: View44<44> = instance44;
export const classResult44: readonly [44, string, number, string] = [
  view44.id, view44.label, instance44.score(), view44.describe("class"),
];

interface View45<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base45<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived45 extends Base45<{ readonly label: string; readonly score: number }, 45> implements View45<45> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(45, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance45: Derived45 = new Derived45("item-45", 45);
const view45: View45<45> = instance45;
export const classResult45: readonly [45, string, number, string] = [
  view45.id, view45.label, instance45.score(), view45.describe("class"),
];

interface View46<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base46<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived46 extends Base46<{ readonly label: string; readonly score: number }, 46> implements View46<46> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(46, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance46: Derived46 = new Derived46("item-46", 46);
const view46: View46<46> = instance46;
export const classResult46: readonly [46, string, number, string] = [
  view46.id, view46.label, instance46.score(), view46.describe("class"),
];

interface View47<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base47<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived47 extends Base47<{ readonly label: string; readonly score: number }, 47> implements View47<47> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(47, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance47: Derived47 = new Derived47("item-47", 47);
const view47: View47<47> = instance47;
export const classResult47: readonly [47, string, number, string] = [
  view47.id, view47.label, instance47.score(), view47.describe("class"),
];

interface View48<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base48<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived48 extends Base48<{ readonly label: string; readonly score: number }, 48> implements View48<48> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(48, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance48: Derived48 = new Derived48("item-48", 48);
const view48: View48<48> = instance48;
export const classResult48: readonly [48, string, number, string] = [
  view48.id, view48.label, instance48.score(), view48.describe("class"),
];

interface View49<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base49<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived49 extends Base49<{ readonly label: string; readonly score: number }, 49> implements View49<49> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(49, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance49: Derived49 = new Derived49("item-49", 49);
const view49: View49<49> = instance49;
export const classResult49: readonly [49, string, number, string] = [
  view49.id, view49.label, instance49.score(), view49.describe("class"),
];

interface View50<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base50<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived50 extends Base50<{ readonly label: string; readonly score: number }, 50> implements View50<50> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(50, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance50: Derived50 = new Derived50("item-50", 50);
const view50: View50<50> = instance50;
export const classResult50: readonly [50, string, number, string] = [
  view50.id, view50.label, instance50.score(), view50.describe("class"),
];

interface View51<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base51<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived51 extends Base51<{ readonly label: string; readonly score: number }, 51> implements View51<51> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(51, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance51: Derived51 = new Derived51("item-51", 51);
const view51: View51<51> = instance51;
export const classResult51: readonly [51, string, number, string] = [
  view51.id, view51.label, instance51.score(), view51.describe("class"),
];

interface View52<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base52<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived52 extends Base52<{ readonly label: string; readonly score: number }, 52> implements View52<52> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(52, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance52: Derived52 = new Derived52("item-52", 52);
const view52: View52<52> = instance52;
export const classResult52: readonly [52, string, number, string] = [
  view52.id, view52.label, instance52.score(), view52.describe("class"),
];

interface View53<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base53<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived53 extends Base53<{ readonly label: string; readonly score: number }, 53> implements View53<53> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(53, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance53: Derived53 = new Derived53("item-53", 53);
const view53: View53<53> = instance53;
export const classResult53: readonly [53, string, number, string] = [
  view53.id, view53.label, instance53.score(), view53.describe("class"),
];

interface View54<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base54<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived54 extends Base54<{ readonly label: string; readonly score: number }, 54> implements View54<54> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(54, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance54: Derived54 = new Derived54("item-54", 54);
const view54: View54<54> = instance54;
export const classResult54: readonly [54, string, number, string] = [
  view54.id, view54.label, instance54.score(), view54.describe("class"),
];

interface View55<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base55<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived55 extends Base55<{ readonly label: string; readonly score: number }, 55> implements View55<55> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(55, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance55: Derived55 = new Derived55("item-55", 55);
const view55: View55<55> = instance55;
export const classResult55: readonly [55, string, number, string] = [
  view55.id, view55.label, instance55.score(), view55.describe("class"),
];

interface View56<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base56<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived56 extends Base56<{ readonly label: string; readonly score: number }, 56> implements View56<56> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(56, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance56: Derived56 = new Derived56("item-56", 56);
const view56: View56<56> = instance56;
export const classResult56: readonly [56, string, number, string] = [
  view56.id, view56.label, instance56.score(), view56.describe("class"),
];

interface View57<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base57<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived57 extends Base57<{ readonly label: string; readonly score: number }, 57> implements View57<57> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(57, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance57: Derived57 = new Derived57("item-57", 57);
const view57: View57<57> = instance57;
export const classResult57: readonly [57, string, number, string] = [
  view57.id, view57.label, instance57.score(), view57.describe("class"),
];

interface View58<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base58<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived58 extends Base58<{ readonly label: string; readonly score: number }, 58> implements View58<58> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(58, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance58: Derived58 = new Derived58("item-58", 58);
const view58: View58<58> = instance58;
export const classResult58: readonly [58, string, number, string] = [
  view58.id, view58.label, instance58.score(), view58.describe("class"),
];

interface View59<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base59<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived59 extends Base59<{ readonly label: string; readonly score: number }, 59> implements View59<59> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(59, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance59: Derived59 = new Derived59("item-59", 59);
const view59: View59<59> = instance59;
export const classResult59: readonly [59, string, number, string] = [
  view59.id, view59.label, instance59.score(), view59.describe("class"),
];

interface View60<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base60<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived60 extends Base60<{ readonly label: string; readonly score: number }, 60> implements View60<60> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(60, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance60: Derived60 = new Derived60("item-60", 60);
const view60: View60<60> = instance60;
export const classResult60: readonly [60, string, number, string] = [
  view60.id, view60.label, instance60.score(), view60.describe("class"),
];

interface View61<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base61<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived61 extends Base61<{ readonly label: string; readonly score: number }, 61> implements View61<61> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(61, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance61: Derived61 = new Derived61("item-61", 61);
const view61: View61<61> = instance61;
export const classResult61: readonly [61, string, number, string] = [
  view61.id, view61.label, instance61.score(), view61.describe("class"),
];

interface View62<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base62<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived62 extends Base62<{ readonly label: string; readonly score: number }, 62> implements View62<62> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(62, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance62: Derived62 = new Derived62("item-62", 62);
const view62: View62<62> = instance62;
export const classResult62: readonly [62, string, number, string] = [
  view62.id, view62.label, instance62.score(), view62.describe("class"),
];

interface View63<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base63<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived63 extends Base63<{ readonly label: string; readonly score: number }, 63> implements View63<63> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(63, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance63: Derived63 = new Derived63("item-63", 63);
const view63: View63<63> = instance63;
export const classResult63: readonly [63, string, number, string] = [
  view63.id, view63.label, instance63.score(), view63.describe("class"),
];

interface View64<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base64<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived64 extends Base64<{ readonly label: string; readonly score: number }, 64> implements View64<64> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(64, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance64: Derived64 = new Derived64("item-64", 64);
const view64: View64<64> = instance64;
export const classResult64: readonly [64, string, number, string] = [
  view64.id, view64.label, instance64.score(), view64.describe("class"),
];

interface View65<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base65<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived65 extends Base65<{ readonly label: string; readonly score: number }, 65> implements View65<65> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(65, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance65: Derived65 = new Derived65("item-65", 65);
const view65: View65<65> = instance65;
export const classResult65: readonly [65, string, number, string] = [
  view65.id, view65.label, instance65.score(), view65.describe("class"),
];

interface View66<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base66<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived66 extends Base66<{ readonly label: string; readonly score: number }, 66> implements View66<66> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(66, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance66: Derived66 = new Derived66("item-66", 66);
const view66: View66<66> = instance66;
export const classResult66: readonly [66, string, number, string] = [
  view66.id, view66.label, instance66.score(), view66.describe("class"),
];

interface View67<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base67<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived67 extends Base67<{ readonly label: string; readonly score: number }, 67> implements View67<67> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(67, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance67: Derived67 = new Derived67("item-67", 67);
const view67: View67<67> = instance67;
export const classResult67: readonly [67, string, number, string] = [
  view67.id, view67.label, instance67.score(), view67.describe("class"),
];

interface View68<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base68<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived68 extends Base68<{ readonly label: string; readonly score: number }, 68> implements View68<68> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(68, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance68: Derived68 = new Derived68("item-68", 68);
const view68: View68<68> = instance68;
export const classResult68: readonly [68, string, number, string] = [
  view68.id, view68.label, instance68.score(), view68.describe("class"),
];

interface View69<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base69<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived69 extends Base69<{ readonly label: string; readonly score: number }, 69> implements View69<69> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(69, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance69: Derived69 = new Derived69("item-69", 69);
const view69: View69<69> = instance69;
export const classResult69: readonly [69, string, number, string] = [
  view69.id, view69.label, instance69.score(), view69.describe("class"),
];

interface View70<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base70<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived70 extends Base70<{ readonly label: string; readonly score: number }, 70> implements View70<70> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(70, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance70: Derived70 = new Derived70("item-70", 70);
const view70: View70<70> = instance70;
export const classResult70: readonly [70, string, number, string] = [
  view70.id, view70.label, instance70.score(), view70.describe("class"),
];

interface View71<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base71<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived71 extends Base71<{ readonly label: string; readonly score: number }, 71> implements View71<71> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(71, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance71: Derived71 = new Derived71("item-71", 71);
const view71: View71<71> = instance71;
export const classResult71: readonly [71, string, number, string] = [
  view71.id, view71.label, instance71.score(), view71.describe("class"),
];

interface View72<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base72<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived72 extends Base72<{ readonly label: string; readonly score: number }, 72> implements View72<72> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(72, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance72: Derived72 = new Derived72("item-72", 72);
const view72: View72<72> = instance72;
export const classResult72: readonly [72, string, number, string] = [
  view72.id, view72.label, instance72.score(), view72.describe("class"),
];

interface View73<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base73<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived73 extends Base73<{ readonly label: string; readonly score: number }, 73> implements View73<73> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(73, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance73: Derived73 = new Derived73("item-73", 73);
const view73: View73<73> = instance73;
export const classResult73: readonly [73, string, number, string] = [
  view73.id, view73.label, instance73.score(), view73.describe("class"),
];

interface View74<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base74<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived74 extends Base74<{ readonly label: string; readonly score: number }, 74> implements View74<74> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(74, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance74: Derived74 = new Derived74("item-74", 74);
const view74: View74<74> = instance74;
export const classResult74: readonly [74, string, number, string] = [
  view74.id, view74.label, instance74.score(), view74.describe("class"),
];

interface View75<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base75<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived75 extends Base75<{ readonly label: string; readonly score: number }, 75> implements View75<75> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(75, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance75: Derived75 = new Derived75("item-75", 75);
const view75: View75<75> = instance75;
export const classResult75: readonly [75, string, number, string] = [
  view75.id, view75.label, instance75.score(), view75.describe("class"),
];

interface View76<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base76<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived76 extends Base76<{ readonly label: string; readonly score: number }, 76> implements View76<76> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(76, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance76: Derived76 = new Derived76("item-76", 76);
const view76: View76<76> = instance76;
export const classResult76: readonly [76, string, number, string] = [
  view76.id, view76.label, instance76.score(), view76.describe("class"),
];

interface View77<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base77<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived77 extends Base77<{ readonly label: string; readonly score: number }, 77> implements View77<77> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(77, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance77: Derived77 = new Derived77("item-77", 77);
const view77: View77<77> = instance77;
export const classResult77: readonly [77, string, number, string] = [
  view77.id, view77.label, instance77.score(), view77.describe("class"),
];

interface View78<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base78<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived78 extends Base78<{ readonly label: string; readonly score: number }, 78> implements View78<78> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(78, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance78: Derived78 = new Derived78("item-78", 78);
const view78: View78<78> = instance78;
export const classResult78: readonly [78, string, number, string] = [
  view78.id, view78.label, instance78.score(), view78.describe("class"),
];

interface View79<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base79<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived79 extends Base79<{ readonly label: string; readonly score: number }, 79> implements View79<79> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(79, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance79: Derived79 = new Derived79("item-79", 79);
const view79: View79<79> = instance79;
export const classResult79: readonly [79, string, number, string] = [
  view79.id, view79.label, instance79.score(), view79.describe("class"),
];

interface View80<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base80<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived80 extends Base80<{ readonly label: string; readonly score: number }, 80> implements View80<80> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(80, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance80: Derived80 = new Derived80("item-80", 80);
const view80: View80<80> = instance80;
export const classResult80: readonly [80, string, number, string] = [
  view80.id, view80.label, instance80.score(), view80.describe("class"),
];

interface View81<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base81<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived81 extends Base81<{ readonly label: string; readonly score: number }, 81> implements View81<81> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(81, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance81: Derived81 = new Derived81("item-81", 81);
const view81: View81<81> = instance81;
export const classResult81: readonly [81, string, number, string] = [
  view81.id, view81.label, instance81.score(), view81.describe("class"),
];

interface View82<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base82<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived82 extends Base82<{ readonly label: string; readonly score: number }, 82> implements View82<82> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(82, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance82: Derived82 = new Derived82("item-82", 82);
const view82: View82<82> = instance82;
export const classResult82: readonly [82, string, number, string] = [
  view82.id, view82.label, instance82.score(), view82.describe("class"),
];

interface View83<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base83<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived83 extends Base83<{ readonly label: string; readonly score: number }, 83> implements View83<83> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(83, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance83: Derived83 = new Derived83("item-83", 83);
const view83: View83<83> = instance83;
export const classResult83: readonly [83, string, number, string] = [
  view83.id, view83.label, instance83.score(), view83.describe("class"),
];

interface View84<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base84<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived84 extends Base84<{ readonly label: string; readonly score: number }, 84> implements View84<84> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(84, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance84: Derived84 = new Derived84("item-84", 84);
const view84: View84<84> = instance84;
export const classResult84: readonly [84, string, number, string] = [
  view84.id, view84.label, instance84.score(), view84.describe("class"),
];

interface View85<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base85<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived85 extends Base85<{ readonly label: string; readonly score: number }, 85> implements View85<85> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(85, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance85: Derived85 = new Derived85("item-85", 85);
const view85: View85<85> = instance85;
export const classResult85: readonly [85, string, number, string] = [
  view85.id, view85.label, instance85.score(), view85.describe("class"),
];

interface View86<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base86<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived86 extends Base86<{ readonly label: string; readonly score: number }, 86> implements View86<86> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(86, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance86: Derived86 = new Derived86("item-86", 86);
const view86: View86<86> = instance86;
export const classResult86: readonly [86, string, number, string] = [
  view86.id, view86.label, instance86.score(), view86.describe("class"),
];

interface View87<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base87<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived87 extends Base87<{ readonly label: string; readonly score: number }, 87> implements View87<87> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(87, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance87: Derived87 = new Derived87("item-87", 87);
const view87: View87<87> = instance87;
export const classResult87: readonly [87, string, number, string] = [
  view87.id, view87.label, instance87.score(), view87.describe("class"),
];

interface View88<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base88<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived88 extends Base88<{ readonly label: string; readonly score: number }, 88> implements View88<88> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(88, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance88: Derived88 = new Derived88("item-88", 88);
const view88: View88<88> = instance88;
export const classResult88: readonly [88, string, number, string] = [
  view88.id, view88.label, instance88.score(), view88.describe("class"),
];

interface View89<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base89<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived89 extends Base89<{ readonly label: string; readonly score: number }, 89> implements View89<89> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(89, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance89: Derived89 = new Derived89("item-89", 89);
const view89: View89<89> = instance89;
export const classResult89: readonly [89, string, number, string] = [
  view89.id, view89.label, instance89.score(), view89.describe("class"),
];

interface View90<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base90<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived90 extends Base90<{ readonly label: string; readonly score: number }, 90> implements View90<90> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(90, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance90: Derived90 = new Derived90("item-90", 90);
const view90: View90<90> = instance90;
export const classResult90: readonly [90, string, number, string] = [
  view90.id, view90.label, instance90.score(), view90.describe("class"),
];

interface View91<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base91<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived91 extends Base91<{ readonly label: string; readonly score: number }, 91> implements View91<91> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(91, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance91: Derived91 = new Derived91("item-91", 91);
const view91: View91<91> = instance91;
export const classResult91: readonly [91, string, number, string] = [
  view91.id, view91.label, instance91.score(), view91.describe("class"),
];

interface View92<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base92<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived92 extends Base92<{ readonly label: string; readonly score: number }, 92> implements View92<92> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(92, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance92: Derived92 = new Derived92("item-92", 92);
const view92: View92<92> = instance92;
export const classResult92: readonly [92, string, number, string] = [
  view92.id, view92.label, instance92.score(), view92.describe("class"),
];

interface View93<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base93<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived93 extends Base93<{ readonly label: string; readonly score: number }, 93> implements View93<93> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(93, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance93: Derived93 = new Derived93("item-93", 93);
const view93: View93<93> = instance93;
export const classResult93: readonly [93, string, number, string] = [
  view93.id, view93.label, instance93.score(), view93.describe("class"),
];

interface View94<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base94<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived94 extends Base94<{ readonly label: string; readonly score: number }, 94> implements View94<94> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(94, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance94: Derived94 = new Derived94("item-94", 94);
const view94: View94<94> = instance94;
export const classResult94: readonly [94, string, number, string] = [
  view94.id, view94.label, instance94.score(), view94.describe("class"),
];

interface View95<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base95<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived95 extends Base95<{ readonly label: string; readonly score: number }, 95> implements View95<95> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(95, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance95: Derived95 = new Derived95("item-95", 95);
const view95: View95<95> = instance95;
export const classResult95: readonly [95, string, number, string] = [
  view95.id, view95.label, instance95.score(), view95.describe("class"),
];

interface View96<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base96<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived96 extends Base96<{ readonly label: string; readonly score: number }, 96> implements View96<96> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(96, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance96: Derived96 = new Derived96("item-96", 96);
const view96: View96<96> = instance96;
export const classResult96: readonly [96, string, number, string] = [
  view96.id, view96.label, instance96.score(), view96.describe("class"),
];

interface View97<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base97<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived97 extends Base97<{ readonly label: string; readonly score: number }, 97> implements View97<97> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(97, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance97: Derived97 = new Derived97("item-97", 97);
const view97: View97<97> = instance97;
export const classResult97: readonly [97, string, number, string] = [
  view97.id, view97.label, instance97.score(), view97.describe("class"),
];

interface View98<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base98<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived98 extends Base98<{ readonly label: string; readonly score: number }, 98> implements View98<98> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(98, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance98: Derived98 = new Derived98("item-98", 98);
const view98: View98<98> = instance98;
export const classResult98: readonly [98, string, number, string] = [
  view98.id, view98.label, instance98.score(), view98.describe("class"),
];

interface View99<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base99<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived99 extends Base99<{ readonly label: string; readonly score: number }, 99> implements View99<99> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(99, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance99: Derived99 = new Derived99("item-99", 99);
const view99: View99<99> = instance99;
export const classResult99: readonly [99, string, number, string] = [
  view99.id, view99.label, instance99.score(), view99.describe("class"),
];

interface View100<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base100<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived100 extends Base100<{ readonly label: string; readonly score: number }, 100> implements View100<100> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(100, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance100: Derived100 = new Derived100("item-100", 100);
const view100: View100<100> = instance100;
export const classResult100: readonly [100, string, number, string] = [
  view100.id, view100.label, instance100.score(), view100.describe("class"),
];

interface View101<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base101<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived101 extends Base101<{ readonly label: string; readonly score: number }, 101> implements View101<101> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(101, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance101: Derived101 = new Derived101("item-101", 101);
const view101: View101<101> = instance101;
export const classResult101: readonly [101, string, number, string] = [
  view101.id, view101.label, instance101.score(), view101.describe("class"),
];

interface View102<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base102<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived102 extends Base102<{ readonly label: string; readonly score: number }, 102> implements View102<102> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(102, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance102: Derived102 = new Derived102("item-102", 102);
const view102: View102<102> = instance102;
export const classResult102: readonly [102, string, number, string] = [
  view102.id, view102.label, instance102.score(), view102.describe("class"),
];

interface View103<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base103<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived103 extends Base103<{ readonly label: string; readonly score: number }, 103> implements View103<103> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(103, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance103: Derived103 = new Derived103("item-103", 103);
const view103: View103<103> = instance103;
export const classResult103: readonly [103, string, number, string] = [
  view103.id, view103.label, instance103.score(), view103.describe("class"),
];

interface View104<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base104<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived104 extends Base104<{ readonly label: string; readonly score: number }, 104> implements View104<104> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(104, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance104: Derived104 = new Derived104("item-104", 104);
const view104: View104<104> = instance104;
export const classResult104: readonly [104, string, number, string] = [
  view104.id, view104.label, instance104.score(), view104.describe("class"),
];

interface View105<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base105<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived105 extends Base105<{ readonly label: string; readonly score: number }, 105> implements View105<105> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(105, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance105: Derived105 = new Derived105("item-105", 105);
const view105: View105<105> = instance105;
export const classResult105: readonly [105, string, number, string] = [
  view105.id, view105.label, instance105.score(), view105.describe("class"),
];

interface View106<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base106<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived106 extends Base106<{ readonly label: string; readonly score: number }, 106> implements View106<106> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(106, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance106: Derived106 = new Derived106("item-106", 106);
const view106: View106<106> = instance106;
export const classResult106: readonly [106, string, number, string] = [
  view106.id, view106.label, instance106.score(), view106.describe("class"),
];

interface View107<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base107<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived107 extends Base107<{ readonly label: string; readonly score: number }, 107> implements View107<107> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(107, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance107: Derived107 = new Derived107("item-107", 107);
const view107: View107<107> = instance107;
export const classResult107: readonly [107, string, number, string] = [
  view107.id, view107.label, instance107.score(), view107.describe("class"),
];

interface View108<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base108<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived108 extends Base108<{ readonly label: string; readonly score: number }, 108> implements View108<108> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(108, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance108: Derived108 = new Derived108("item-108", 108);
const view108: View108<108> = instance108;
export const classResult108: readonly [108, string, number, string] = [
  view108.id, view108.label, instance108.score(), view108.describe("class"),
];

interface View109<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base109<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived109 extends Base109<{ readonly label: string; readonly score: number }, 109> implements View109<109> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(109, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance109: Derived109 = new Derived109("item-109", 109);
const view109: View109<109> = instance109;
export const classResult109: readonly [109, string, number, string] = [
  view109.id, view109.label, instance109.score(), view109.describe("class"),
];

interface View110<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base110<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived110 extends Base110<{ readonly label: string; readonly score: number }, 110> implements View110<110> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(110, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance110: Derived110 = new Derived110("item-110", 110);
const view110: View110<110> = instance110;
export const classResult110: readonly [110, string, number, string] = [
  view110.id, view110.label, instance110.score(), view110.describe("class"),
];

interface View111<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base111<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived111 extends Base111<{ readonly label: string; readonly score: number }, 111> implements View111<111> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(111, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance111: Derived111 = new Derived111("item-111", 111);
const view111: View111<111> = instance111;
export const classResult111: readonly [111, string, number, string] = [
  view111.id, view111.label, instance111.score(), view111.describe("class"),
];

interface View112<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base112<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived112 extends Base112<{ readonly label: string; readonly score: number }, 112> implements View112<112> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(112, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance112: Derived112 = new Derived112("item-112", 112);
const view112: View112<112> = instance112;
export const classResult112: readonly [112, string, number, string] = [
  view112.id, view112.label, instance112.score(), view112.describe("class"),
];

interface View113<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base113<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived113 extends Base113<{ readonly label: string; readonly score: number }, 113> implements View113<113> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(113, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance113: Derived113 = new Derived113("item-113", 113);
const view113: View113<113> = instance113;
export const classResult113: readonly [113, string, number, string] = [
  view113.id, view113.label, instance113.score(), view113.describe("class"),
];

interface View114<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base114<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived114 extends Base114<{ readonly label: string; readonly score: number }, 114> implements View114<114> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(114, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance114: Derived114 = new Derived114("item-114", 114);
const view114: View114<114> = instance114;
export const classResult114: readonly [114, string, number, string] = [
  view114.id, view114.label, instance114.score(), view114.describe("class"),
];

interface View115<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base115<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived115 extends Base115<{ readonly label: string; readonly score: number }, 115> implements View115<115> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(115, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance115: Derived115 = new Derived115("item-115", 115);
const view115: View115<115> = instance115;
export const classResult115: readonly [115, string, number, string] = [
  view115.id, view115.label, instance115.score(), view115.describe("class"),
];

interface View116<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base116<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived116 extends Base116<{ readonly label: string; readonly score: number }, 116> implements View116<116> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(116, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance116: Derived116 = new Derived116("item-116", 116);
const view116: View116<116> = instance116;
export const classResult116: readonly [116, string, number, string] = [
  view116.id, view116.label, instance116.score(), view116.describe("class"),
];

interface View117<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base117<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived117 extends Base117<{ readonly label: string; readonly score: number }, 117> implements View117<117> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(117, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance117: Derived117 = new Derived117("item-117", 117);
const view117: View117<117> = instance117;
export const classResult117: readonly [117, string, number, string] = [
  view117.id, view117.label, instance117.score(), view117.describe("class"),
];

interface View118<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base118<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived118 extends Base118<{ readonly label: string; readonly score: number }, 118> implements View118<118> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(118, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance118: Derived118 = new Derived118("item-118", 118);
const view118: View118<118> = instance118;
export const classResult118: readonly [118, string, number, string] = [
  view118.id, view118.label, instance118.score(), view118.describe("class"),
];

interface View119<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base119<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived119 extends Base119<{ readonly label: string; readonly score: number }, 119> implements View119<119> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(119, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance119: Derived119 = new Derived119("item-119", 119);
const view119: View119<119> = instance119;
export const classResult119: readonly [119, string, number, string] = [
  view119.id, view119.label, instance119.score(), view119.describe("class"),
];

interface View120<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base120<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived120 extends Base120<{ readonly label: string; readonly score: number }, 120> implements View120<120> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(120, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance120: Derived120 = new Derived120("item-120", 120);
const view120: View120<120> = instance120;
export const classResult120: readonly [120, string, number, string] = [
  view120.id, view120.label, instance120.score(), view120.describe("class"),
];

interface View121<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base121<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived121 extends Base121<{ readonly label: string; readonly score: number }, 121> implements View121<121> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(121, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance121: Derived121 = new Derived121("item-121", 121);
const view121: View121<121> = instance121;
export const classResult121: readonly [121, string, number, string] = [
  view121.id, view121.label, instance121.score(), view121.describe("class"),
];

interface View122<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base122<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived122 extends Base122<{ readonly label: string; readonly score: number }, 122> implements View122<122> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(122, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance122: Derived122 = new Derived122("item-122", 122);
const view122: View122<122> = instance122;
export const classResult122: readonly [122, string, number, string] = [
  view122.id, view122.label, instance122.score(), view122.describe("class"),
];

interface View123<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base123<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived123 extends Base123<{ readonly label: string; readonly score: number }, 123> implements View123<123> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(123, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance123: Derived123 = new Derived123("item-123", 123);
const view123: View123<123> = instance123;
export const classResult123: readonly [123, string, number, string] = [
  view123.id, view123.label, instance123.score(), view123.describe("class"),
];

interface View124<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base124<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived124 extends Base124<{ readonly label: string; readonly score: number }, 124> implements View124<124> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(124, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance124: Derived124 = new Derived124("item-124", 124);
const view124: View124<124> = instance124;
export const classResult124: readonly [124, string, number, string] = [
  view124.id, view124.label, instance124.score(), view124.describe("class"),
];

interface View125<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base125<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived125 extends Base125<{ readonly label: string; readonly score: number }, 125> implements View125<125> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(125, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance125: Derived125 = new Derived125("item-125", 125);
const view125: View125<125> = instance125;
export const classResult125: readonly [125, string, number, string] = [
  view125.id, view125.label, instance125.score(), view125.describe("class"),
];

interface View126<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base126<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived126 extends Base126<{ readonly label: string; readonly score: number }, 126> implements View126<126> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(126, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance126: Derived126 = new Derived126("item-126", 126);
const view126: View126<126> = instance126;
export const classResult126: readonly [126, string, number, string] = [
  view126.id, view126.label, instance126.score(), view126.describe("class"),
];

interface View127<N extends number> {
  readonly id: N;
  readonly label: string;
  describe(prefix: string): string;
}

class Base127<T, N extends number> {
  constructor(public readonly id: N, protected readonly value: T) {}
  getValue(): T { return this.value; }
  describe(prefix: string): string { return prefix; }
}

class Derived127 extends Base127<{ readonly label: string; readonly score: number }, 127> implements View127<127> {
  readonly label: string;
  constructor(label: string, score: number) {
    super(127, { label, score });
    this.label = label;
  }
  override getValue(): { readonly label: string; readonly score: number } {
    return super.getValue();
  }
  override describe(prefix: string): string {
    return `${prefix}:${this.label}`;
  }
  score(): number { return this.getValue().score; }
}

const instance127: Derived127 = new Derived127("item-127", 127);
const view127: View127<127> = instance127;
export const classResult127: readonly [127, string, number, string] = [
  view127.id, view127.label, instance127.score(), view127.describe("class"),
];

