type Primitive = string | number | boolean | bigint | symbol | null | undefined;
type DeepReadonly<T> = T extends Primitive ? T : T extends readonly (infer U)[] ? readonly DeepReadonly<U>[] : { readonly [K in keyof T]: DeepReadonly<T[K]> };
type Paths<T> = T extends object ? { [K in keyof T & string]: K | `${K}.${Paths<T[K]> & string}` }[keyof T & string] : never;
interface Model0<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel0 = DeepReadonly<Model0<{ name: string; score: number }>>;
type ModelPaths0 = Paths<Model0<{ name: string; score: number }>>;
const path0: ModelPaths0 = "nested.left.name";
interface Model1<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel1 = DeepReadonly<Model1<{ name: string; score: number }>>;
type ModelPaths1 = Paths<Model1<{ name: string; score: number }>>;
const path1: ModelPaths1 = "nested.left.name";
interface Model2<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel2 = DeepReadonly<Model2<{ name: string; score: number }>>;
type ModelPaths2 = Paths<Model2<{ name: string; score: number }>>;
const path2: ModelPaths2 = "nested.left.name";
interface Model3<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel3 = DeepReadonly<Model3<{ name: string; score: number }>>;
type ModelPaths3 = Paths<Model3<{ name: string; score: number }>>;
const path3: ModelPaths3 = "nested.left.name";
interface Model4<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel4 = DeepReadonly<Model4<{ name: string; score: number }>>;
type ModelPaths4 = Paths<Model4<{ name: string; score: number }>>;
const path4: ModelPaths4 = "nested.left.name";
interface Model5<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel5 = DeepReadonly<Model5<{ name: string; score: number }>>;
type ModelPaths5 = Paths<Model5<{ name: string; score: number }>>;
const path5: ModelPaths5 = "nested.left.name";
interface Model6<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel6 = DeepReadonly<Model6<{ name: string; score: number }>>;
type ModelPaths6 = Paths<Model6<{ name: string; score: number }>>;
const path6: ModelPaths6 = "nested.left.name";
interface Model7<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel7 = DeepReadonly<Model7<{ name: string; score: number }>>;
type ModelPaths7 = Paths<Model7<{ name: string; score: number }>>;
const path7: ModelPaths7 = "nested.left.name";
interface Model8<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel8 = DeepReadonly<Model8<{ name: string; score: number }>>;
type ModelPaths8 = Paths<Model8<{ name: string; score: number }>>;
const path8: ModelPaths8 = "nested.left.name";
interface Model9<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel9 = DeepReadonly<Model9<{ name: string; score: number }>>;
type ModelPaths9 = Paths<Model9<{ name: string; score: number }>>;
const path9: ModelPaths9 = "nested.left.name";
interface Model10<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel10 = DeepReadonly<Model10<{ name: string; score: number }>>;
type ModelPaths10 = Paths<Model10<{ name: string; score: number }>>;
const path10: ModelPaths10 = "nested.left.name";
interface Model11<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel11 = DeepReadonly<Model11<{ name: string; score: number }>>;
type ModelPaths11 = Paths<Model11<{ name: string; score: number }>>;
const path11: ModelPaths11 = "nested.left.name";
interface Model12<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel12 = DeepReadonly<Model12<{ name: string; score: number }>>;
type ModelPaths12 = Paths<Model12<{ name: string; score: number }>>;
const path12: ModelPaths12 = "nested.left.name";
interface Model13<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel13 = DeepReadonly<Model13<{ name: string; score: number }>>;
type ModelPaths13 = Paths<Model13<{ name: string; score: number }>>;
const path13: ModelPaths13 = "nested.left.name";
interface Model14<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel14 = DeepReadonly<Model14<{ name: string; score: number }>>;
type ModelPaths14 = Paths<Model14<{ name: string; score: number }>>;
const path14: ModelPaths14 = "nested.left.name";
interface Model15<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel15 = DeepReadonly<Model15<{ name: string; score: number }>>;
type ModelPaths15 = Paths<Model15<{ name: string; score: number }>>;
const path15: ModelPaths15 = "nested.left.name";
interface Model16<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel16 = DeepReadonly<Model16<{ name: string; score: number }>>;
type ModelPaths16 = Paths<Model16<{ name: string; score: number }>>;
const path16: ModelPaths16 = "nested.left.name";
interface Model17<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel17 = DeepReadonly<Model17<{ name: string; score: number }>>;
type ModelPaths17 = Paths<Model17<{ name: string; score: number }>>;
const path17: ModelPaths17 = "nested.left.name";
interface Model18<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel18 = DeepReadonly<Model18<{ name: string; score: number }>>;
type ModelPaths18 = Paths<Model18<{ name: string; score: number }>>;
const path18: ModelPaths18 = "nested.left.name";
interface Model19<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel19 = DeepReadonly<Model19<{ name: string; score: number }>>;
type ModelPaths19 = Paths<Model19<{ name: string; score: number }>>;
const path19: ModelPaths19 = "nested.left.name";
interface Model20<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel20 = DeepReadonly<Model20<{ name: string; score: number }>>;
type ModelPaths20 = Paths<Model20<{ name: string; score: number }>>;
const path20: ModelPaths20 = "nested.left.name";
interface Model21<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel21 = DeepReadonly<Model21<{ name: string; score: number }>>;
type ModelPaths21 = Paths<Model21<{ name: string; score: number }>>;
const path21: ModelPaths21 = "nested.left.name";
interface Model22<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel22 = DeepReadonly<Model22<{ name: string; score: number }>>;
type ModelPaths22 = Paths<Model22<{ name: string; score: number }>>;
const path22: ModelPaths22 = "nested.left.name";
interface Model23<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel23 = DeepReadonly<Model23<{ name: string; score: number }>>;
type ModelPaths23 = Paths<Model23<{ name: string; score: number }>>;
const path23: ModelPaths23 = "nested.left.name";
interface Model24<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel24 = DeepReadonly<Model24<{ name: string; score: number }>>;
type ModelPaths24 = Paths<Model24<{ name: string; score: number }>>;
const path24: ModelPaths24 = "nested.left.name";
interface Model25<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel25 = DeepReadonly<Model25<{ name: string; score: number }>>;
type ModelPaths25 = Paths<Model25<{ name: string; score: number }>>;
const path25: ModelPaths25 = "nested.left.name";
interface Model26<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel26 = DeepReadonly<Model26<{ name: string; score: number }>>;
type ModelPaths26 = Paths<Model26<{ name: string; score: number }>>;
const path26: ModelPaths26 = "nested.left.name";
interface Model27<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel27 = DeepReadonly<Model27<{ name: string; score: number }>>;
type ModelPaths27 = Paths<Model27<{ name: string; score: number }>>;
const path27: ModelPaths27 = "nested.left.name";
interface Model28<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel28 = DeepReadonly<Model28<{ name: string; score: number }>>;
type ModelPaths28 = Paths<Model28<{ name: string; score: number }>>;
const path28: ModelPaths28 = "nested.left.name";
interface Model29<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel29 = DeepReadonly<Model29<{ name: string; score: number }>>;
type ModelPaths29 = Paths<Model29<{ name: string; score: number }>>;
const path29: ModelPaths29 = "nested.left.name";
interface Model30<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel30 = DeepReadonly<Model30<{ name: string; score: number }>>;
type ModelPaths30 = Paths<Model30<{ name: string; score: number }>>;
const path30: ModelPaths30 = "nested.left.name";
interface Model31<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel31 = DeepReadonly<Model31<{ name: string; score: number }>>;
type ModelPaths31 = Paths<Model31<{ name: string; score: number }>>;
const path31: ModelPaths31 = "nested.left.name";
interface Model32<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel32 = DeepReadonly<Model32<{ name: string; score: number }>>;
type ModelPaths32 = Paths<Model32<{ name: string; score: number }>>;
const path32: ModelPaths32 = "nested.left.name";
interface Model33<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel33 = DeepReadonly<Model33<{ name: string; score: number }>>;
type ModelPaths33 = Paths<Model33<{ name: string; score: number }>>;
const path33: ModelPaths33 = "nested.left.name";
interface Model34<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel34 = DeepReadonly<Model34<{ name: string; score: number }>>;
type ModelPaths34 = Paths<Model34<{ name: string; score: number }>>;
const path34: ModelPaths34 = "nested.left.name";
interface Model35<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel35 = DeepReadonly<Model35<{ name: string; score: number }>>;
type ModelPaths35 = Paths<Model35<{ name: string; score: number }>>;
const path35: ModelPaths35 = "nested.left.name";
interface Model36<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel36 = DeepReadonly<Model36<{ name: string; score: number }>>;
type ModelPaths36 = Paths<Model36<{ name: string; score: number }>>;
const path36: ModelPaths36 = "nested.left.name";
interface Model37<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel37 = DeepReadonly<Model37<{ name: string; score: number }>>;
type ModelPaths37 = Paths<Model37<{ name: string; score: number }>>;
const path37: ModelPaths37 = "nested.left.name";
interface Model38<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel38 = DeepReadonly<Model38<{ name: string; score: number }>>;
type ModelPaths38 = Paths<Model38<{ name: string; score: number }>>;
const path38: ModelPaths38 = "nested.left.name";
interface Model39<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel39 = DeepReadonly<Model39<{ name: string; score: number }>>;
type ModelPaths39 = Paths<Model39<{ name: string; score: number }>>;
const path39: ModelPaths39 = "nested.left.name";
interface Model40<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel40 = DeepReadonly<Model40<{ name: string; score: number }>>;
type ModelPaths40 = Paths<Model40<{ name: string; score: number }>>;
const path40: ModelPaths40 = "nested.left.name";
interface Model41<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel41 = DeepReadonly<Model41<{ name: string; score: number }>>;
type ModelPaths41 = Paths<Model41<{ name: string; score: number }>>;
const path41: ModelPaths41 = "nested.left.name";
interface Model42<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel42 = DeepReadonly<Model42<{ name: string; score: number }>>;
type ModelPaths42 = Paths<Model42<{ name: string; score: number }>>;
const path42: ModelPaths42 = "nested.left.name";
interface Model43<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel43 = DeepReadonly<Model43<{ name: string; score: number }>>;
type ModelPaths43 = Paths<Model43<{ name: string; score: number }>>;
const path43: ModelPaths43 = "nested.left.name";
interface Model44<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel44 = DeepReadonly<Model44<{ name: string; score: number }>>;
type ModelPaths44 = Paths<Model44<{ name: string; score: number }>>;
const path44: ModelPaths44 = "nested.left.name";
interface Model45<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel45 = DeepReadonly<Model45<{ name: string; score: number }>>;
type ModelPaths45 = Paths<Model45<{ name: string; score: number }>>;
const path45: ModelPaths45 = "nested.left.name";
interface Model46<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel46 = DeepReadonly<Model46<{ name: string; score: number }>>;
type ModelPaths46 = Paths<Model46<{ name: string; score: number }>>;
const path46: ModelPaths46 = "nested.left.name";
interface Model47<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel47 = DeepReadonly<Model47<{ name: string; score: number }>>;
type ModelPaths47 = Paths<Model47<{ name: string; score: number }>>;
const path47: ModelPaths47 = "nested.left.name";
interface Model48<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel48 = DeepReadonly<Model48<{ name: string; score: number }>>;
type ModelPaths48 = Paths<Model48<{ name: string; score: number }>>;
const path48: ModelPaths48 = "nested.left.name";
interface Model49<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel49 = DeepReadonly<Model49<{ name: string; score: number }>>;
type ModelPaths49 = Paths<Model49<{ name: string; score: number }>>;
const path49: ModelPaths49 = "nested.left.name";
interface Model50<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel50 = DeepReadonly<Model50<{ name: string; score: number }>>;
type ModelPaths50 = Paths<Model50<{ name: string; score: number }>>;
const path50: ModelPaths50 = "nested.left.name";
interface Model51<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel51 = DeepReadonly<Model51<{ name: string; score: number }>>;
type ModelPaths51 = Paths<Model51<{ name: string; score: number }>>;
const path51: ModelPaths51 = "nested.left.name";
interface Model52<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel52 = DeepReadonly<Model52<{ name: string; score: number }>>;
type ModelPaths52 = Paths<Model52<{ name: string; score: number }>>;
const path52: ModelPaths52 = "nested.left.name";
interface Model53<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel53 = DeepReadonly<Model53<{ name: string; score: number }>>;
type ModelPaths53 = Paths<Model53<{ name: string; score: number }>>;
const path53: ModelPaths53 = "nested.left.name";
interface Model54<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel54 = DeepReadonly<Model54<{ name: string; score: number }>>;
type ModelPaths54 = Paths<Model54<{ name: string; score: number }>>;
const path54: ModelPaths54 = "nested.left.name";
interface Model55<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel55 = DeepReadonly<Model55<{ name: string; score: number }>>;
type ModelPaths55 = Paths<Model55<{ name: string; score: number }>>;
const path55: ModelPaths55 = "nested.left.name";
interface Model56<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel56 = DeepReadonly<Model56<{ name: string; score: number }>>;
type ModelPaths56 = Paths<Model56<{ name: string; score: number }>>;
const path56: ModelPaths56 = "nested.left.name";
interface Model57<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel57 = DeepReadonly<Model57<{ name: string; score: number }>>;
type ModelPaths57 = Paths<Model57<{ name: string; score: number }>>;
const path57: ModelPaths57 = "nested.left.name";
interface Model58<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel58 = DeepReadonly<Model58<{ name: string; score: number }>>;
type ModelPaths58 = Paths<Model58<{ name: string; score: number }>>;
const path58: ModelPaths58 = "nested.left.name";
interface Model59<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel59 = DeepReadonly<Model59<{ name: string; score: number }>>;
type ModelPaths59 = Paths<Model59<{ name: string; score: number }>>;
const path59: ModelPaths59 = "nested.left.name";
interface Model60<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel60 = DeepReadonly<Model60<{ name: string; score: number }>>;
type ModelPaths60 = Paths<Model60<{ name: string; score: number }>>;
const path60: ModelPaths60 = "nested.left.name";
interface Model61<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel61 = DeepReadonly<Model61<{ name: string; score: number }>>;
type ModelPaths61 = Paths<Model61<{ name: string; score: number }>>;
const path61: ModelPaths61 = "nested.left.name";
interface Model62<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel62 = DeepReadonly<Model62<{ name: string; score: number }>>;
type ModelPaths62 = Paths<Model62<{ name: string; score: number }>>;
const path62: ModelPaths62 = "nested.left.name";
interface Model63<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel63 = DeepReadonly<Model63<{ name: string; score: number }>>;
type ModelPaths63 = Paths<Model63<{ name: string; score: number }>>;
const path63: ModelPaths63 = "nested.left.name";
interface Model64<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel64 = DeepReadonly<Model64<{ name: string; score: number }>>;
type ModelPaths64 = Paths<Model64<{ name: string; score: number }>>;
const path64: ModelPaths64 = "nested.left.name";
interface Model65<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel65 = DeepReadonly<Model65<{ name: string; score: number }>>;
type ModelPaths65 = Paths<Model65<{ name: string; score: number }>>;
const path65: ModelPaths65 = "nested.left.name";
interface Model66<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel66 = DeepReadonly<Model66<{ name: string; score: number }>>;
type ModelPaths66 = Paths<Model66<{ name: string; score: number }>>;
const path66: ModelPaths66 = "nested.left.name";
interface Model67<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel67 = DeepReadonly<Model67<{ name: string; score: number }>>;
type ModelPaths67 = Paths<Model67<{ name: string; score: number }>>;
const path67: ModelPaths67 = "nested.left.name";
interface Model68<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel68 = DeepReadonly<Model68<{ name: string; score: number }>>;
type ModelPaths68 = Paths<Model68<{ name: string; score: number }>>;
const path68: ModelPaths68 = "nested.left.name";
interface Model69<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel69 = DeepReadonly<Model69<{ name: string; score: number }>>;
type ModelPaths69 = Paths<Model69<{ name: string; score: number }>>;
const path69: ModelPaths69 = "nested.left.name";
interface Model70<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel70 = DeepReadonly<Model70<{ name: string; score: number }>>;
type ModelPaths70 = Paths<Model70<{ name: string; score: number }>>;
const path70: ModelPaths70 = "nested.left.name";
interface Model71<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel71 = DeepReadonly<Model71<{ name: string; score: number }>>;
type ModelPaths71 = Paths<Model71<{ name: string; score: number }>>;
const path71: ModelPaths71 = "nested.left.name";
interface Model72<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel72 = DeepReadonly<Model72<{ name: string; score: number }>>;
type ModelPaths72 = Paths<Model72<{ name: string; score: number }>>;
const path72: ModelPaths72 = "nested.left.name";
interface Model73<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel73 = DeepReadonly<Model73<{ name: string; score: number }>>;
type ModelPaths73 = Paths<Model73<{ name: string; score: number }>>;
const path73: ModelPaths73 = "nested.left.name";
interface Model74<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel74 = DeepReadonly<Model74<{ name: string; score: number }>>;
type ModelPaths74 = Paths<Model74<{ name: string; score: number }>>;
const path74: ModelPaths74 = "nested.left.name";
interface Model75<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel75 = DeepReadonly<Model75<{ name: string; score: number }>>;
type ModelPaths75 = Paths<Model75<{ name: string; score: number }>>;
const path75: ModelPaths75 = "nested.left.name";
interface Model76<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel76 = DeepReadonly<Model76<{ name: string; score: number }>>;
type ModelPaths76 = Paths<Model76<{ name: string; score: number }>>;
const path76: ModelPaths76 = "nested.left.name";
interface Model77<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel77 = DeepReadonly<Model77<{ name: string; score: number }>>;
type ModelPaths77 = Paths<Model77<{ name: string; score: number }>>;
const path77: ModelPaths77 = "nested.left.name";
interface Model78<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel78 = DeepReadonly<Model78<{ name: string; score: number }>>;
type ModelPaths78 = Paths<Model78<{ name: string; score: number }>>;
const path78: ModelPaths78 = "nested.left.name";
interface Model79<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel79 = DeepReadonly<Model79<{ name: string; score: number }>>;
type ModelPaths79 = Paths<Model79<{ name: string; score: number }>>;
const path79: ModelPaths79 = "nested.left.name";
interface Model80<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel80 = DeepReadonly<Model80<{ name: string; score: number }>>;
type ModelPaths80 = Paths<Model80<{ name: string; score: number }>>;
const path80: ModelPaths80 = "nested.left.name";
interface Model81<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel81 = DeepReadonly<Model81<{ name: string; score: number }>>;
type ModelPaths81 = Paths<Model81<{ name: string; score: number }>>;
const path81: ModelPaths81 = "nested.left.name";
interface Model82<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel82 = DeepReadonly<Model82<{ name: string; score: number }>>;
type ModelPaths82 = Paths<Model82<{ name: string; score: number }>>;
const path82: ModelPaths82 = "nested.left.name";
interface Model83<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel83 = DeepReadonly<Model83<{ name: string; score: number }>>;
type ModelPaths83 = Paths<Model83<{ name: string; score: number }>>;
const path83: ModelPaths83 = "nested.left.name";
interface Model84<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel84 = DeepReadonly<Model84<{ name: string; score: number }>>;
type ModelPaths84 = Paths<Model84<{ name: string; score: number }>>;
const path84: ModelPaths84 = "nested.left.name";
interface Model85<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel85 = DeepReadonly<Model85<{ name: string; score: number }>>;
type ModelPaths85 = Paths<Model85<{ name: string; score: number }>>;
const path85: ModelPaths85 = "nested.left.name";
interface Model86<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel86 = DeepReadonly<Model86<{ name: string; score: number }>>;
type ModelPaths86 = Paths<Model86<{ name: string; score: number }>>;
const path86: ModelPaths86 = "nested.left.name";
interface Model87<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel87 = DeepReadonly<Model87<{ name: string; score: number }>>;
type ModelPaths87 = Paths<Model87<{ name: string; score: number }>>;
const path87: ModelPaths87 = "nested.left.name";
interface Model88<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel88 = DeepReadonly<Model88<{ name: string; score: number }>>;
type ModelPaths88 = Paths<Model88<{ name: string; score: number }>>;
const path88: ModelPaths88 = "nested.left.name";
interface Model89<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel89 = DeepReadonly<Model89<{ name: string; score: number }>>;
type ModelPaths89 = Paths<Model89<{ name: string; score: number }>>;
const path89: ModelPaths89 = "nested.left.name";
interface Model90<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel90 = DeepReadonly<Model90<{ name: string; score: number }>>;
type ModelPaths90 = Paths<Model90<{ name: string; score: number }>>;
const path90: ModelPaths90 = "nested.left.name";
interface Model91<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel91 = DeepReadonly<Model91<{ name: string; score: number }>>;
type ModelPaths91 = Paths<Model91<{ name: string; score: number }>>;
const path91: ModelPaths91 = "nested.left.name";
interface Model92<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel92 = DeepReadonly<Model92<{ name: string; score: number }>>;
type ModelPaths92 = Paths<Model92<{ name: string; score: number }>>;
const path92: ModelPaths92 = "nested.left.name";
interface Model93<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel93 = DeepReadonly<Model93<{ name: string; score: number }>>;
type ModelPaths93 = Paths<Model93<{ name: string; score: number }>>;
const path93: ModelPaths93 = "nested.left.name";
interface Model94<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel94 = DeepReadonly<Model94<{ name: string; score: number }>>;
type ModelPaths94 = Paths<Model94<{ name: string; score: number }>>;
const path94: ModelPaths94 = "nested.left.name";
interface Model95<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel95 = DeepReadonly<Model95<{ name: string; score: number }>>;
type ModelPaths95 = Paths<Model95<{ name: string; score: number }>>;
const path95: ModelPaths95 = "nested.left.name";
interface Model96<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel96 = DeepReadonly<Model96<{ name: string; score: number }>>;
type ModelPaths96 = Paths<Model96<{ name: string; score: number }>>;
const path96: ModelPaths96 = "nested.left.name";
interface Model97<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel97 = DeepReadonly<Model97<{ name: string; score: number }>>;
type ModelPaths97 = Paths<Model97<{ name: string; score: number }>>;
const path97: ModelPaths97 = "nested.left.name";
interface Model98<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel98 = DeepReadonly<Model98<{ name: string; score: number }>>;
type ModelPaths98 = Paths<Model98<{ name: string; score: number }>>;
const path98: ModelPaths98 = "nested.left.name";
interface Model99<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel99 = DeepReadonly<Model99<{ name: string; score: number }>>;
type ModelPaths99 = Paths<Model99<{ name: string; score: number }>>;
const path99: ModelPaths99 = "nested.left.name";
interface Model100<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel100 = DeepReadonly<Model100<{ name: string; score: number }>>;
type ModelPaths100 = Paths<Model100<{ name: string; score: number }>>;
const path100: ModelPaths100 = "nested.left.name";
interface Model101<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel101 = DeepReadonly<Model101<{ name: string; score: number }>>;
type ModelPaths101 = Paths<Model101<{ name: string; score: number }>>;
const path101: ModelPaths101 = "nested.left.name";
interface Model102<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel102 = DeepReadonly<Model102<{ name: string; score: number }>>;
type ModelPaths102 = Paths<Model102<{ name: string; score: number }>>;
const path102: ModelPaths102 = "nested.left.name";
interface Model103<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel103 = DeepReadonly<Model103<{ name: string; score: number }>>;
type ModelPaths103 = Paths<Model103<{ name: string; score: number }>>;
const path103: ModelPaths103 = "nested.left.name";
interface Model104<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel104 = DeepReadonly<Model104<{ name: string; score: number }>>;
type ModelPaths104 = Paths<Model104<{ name: string; score: number }>>;
const path104: ModelPaths104 = "nested.left.name";
interface Model105<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel105 = DeepReadonly<Model105<{ name: string; score: number }>>;
type ModelPaths105 = Paths<Model105<{ name: string; score: number }>>;
const path105: ModelPaths105 = "nested.left.name";
interface Model106<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel106 = DeepReadonly<Model106<{ name: string; score: number }>>;
type ModelPaths106 = Paths<Model106<{ name: string; score: number }>>;
const path106: ModelPaths106 = "nested.left.name";
interface Model107<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel107 = DeepReadonly<Model107<{ name: string; score: number }>>;
type ModelPaths107 = Paths<Model107<{ name: string; score: number }>>;
const path107: ModelPaths107 = "nested.left.name";
interface Model108<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel108 = DeepReadonly<Model108<{ name: string; score: number }>>;
type ModelPaths108 = Paths<Model108<{ name: string; score: number }>>;
const path108: ModelPaths108 = "nested.left.name";
interface Model109<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel109 = DeepReadonly<Model109<{ name: string; score: number }>>;
type ModelPaths109 = Paths<Model109<{ name: string; score: number }>>;
const path109: ModelPaths109 = "nested.left.name";
interface Model110<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel110 = DeepReadonly<Model110<{ name: string; score: number }>>;
type ModelPaths110 = Paths<Model110<{ name: string; score: number }>>;
const path110: ModelPaths110 = "nested.left.name";
interface Model111<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel111 = DeepReadonly<Model111<{ name: string; score: number }>>;
type ModelPaths111 = Paths<Model111<{ name: string; score: number }>>;
const path111: ModelPaths111 = "nested.left.name";
interface Model112<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel112 = DeepReadonly<Model112<{ name: string; score: number }>>;
type ModelPaths112 = Paths<Model112<{ name: string; score: number }>>;
const path112: ModelPaths112 = "nested.left.name";
interface Model113<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel113 = DeepReadonly<Model113<{ name: string; score: number }>>;
type ModelPaths113 = Paths<Model113<{ name: string; score: number }>>;
const path113: ModelPaths113 = "nested.left.name";
interface Model114<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel114 = DeepReadonly<Model114<{ name: string; score: number }>>;
type ModelPaths114 = Paths<Model114<{ name: string; score: number }>>;
const path114: ModelPaths114 = "nested.left.name";
interface Model115<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel115 = DeepReadonly<Model115<{ name: string; score: number }>>;
type ModelPaths115 = Paths<Model115<{ name: string; score: number }>>;
const path115: ModelPaths115 = "nested.left.name";
interface Model116<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel116 = DeepReadonly<Model116<{ name: string; score: number }>>;
type ModelPaths116 = Paths<Model116<{ name: string; score: number }>>;
const path116: ModelPaths116 = "nested.left.name";
interface Model117<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel117 = DeepReadonly<Model117<{ name: string; score: number }>>;
type ModelPaths117 = Paths<Model117<{ name: string; score: number }>>;
const path117: ModelPaths117 = "nested.left.name";
interface Model118<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel118 = DeepReadonly<Model118<{ name: string; score: number }>>;
type ModelPaths118 = Paths<Model118<{ name: string; score: number }>>;
const path118: ModelPaths118 = "nested.left.name";
interface Model119<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel119 = DeepReadonly<Model119<{ name: string; score: number }>>;
type ModelPaths119 = Paths<Model119<{ name: string; score: number }>>;
const path119: ModelPaths119 = "nested.left.name";
interface Model120<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel120 = DeepReadonly<Model120<{ name: string; score: number }>>;
type ModelPaths120 = Paths<Model120<{ name: string; score: number }>>;
const path120: ModelPaths120 = "nested.left.name";
interface Model121<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel121 = DeepReadonly<Model121<{ name: string; score: number }>>;
type ModelPaths121 = Paths<Model121<{ name: string; score: number }>>;
const path121: ModelPaths121 = "nested.left.name";
interface Model122<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel122 = DeepReadonly<Model122<{ name: string; score: number }>>;
type ModelPaths122 = Paths<Model122<{ name: string; score: number }>>;
const path122: ModelPaths122 = "nested.left.name";
interface Model123<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel123 = DeepReadonly<Model123<{ name: string; score: number }>>;
type ModelPaths123 = Paths<Model123<{ name: string; score: number }>>;
const path123: ModelPaths123 = "nested.left.name";
interface Model124<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel124 = DeepReadonly<Model124<{ name: string; score: number }>>;
type ModelPaths124 = Paths<Model124<{ name: string; score: number }>>;
const path124: ModelPaths124 = "nested.left.name";
interface Model125<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel125 = DeepReadonly<Model125<{ name: string; score: number }>>;
type ModelPaths125 = Paths<Model125<{ name: string; score: number }>>;
const path125: ModelPaths125 = "nested.left.name";
interface Model126<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel126 = DeepReadonly<Model126<{ name: string; score: number }>>;
type ModelPaths126 = Paths<Model126<{ name: string; score: number }>>;
const path126: ModelPaths126 = "nested.left.name";
interface Model127<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel127 = DeepReadonly<Model127<{ name: string; score: number }>>;
type ModelPaths127 = Paths<Model127<{ name: string; score: number }>>;
const path127: ModelPaths127 = "nested.left.name";
interface Model128<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel128 = DeepReadonly<Model128<{ name: string; score: number }>>;
type ModelPaths128 = Paths<Model128<{ name: string; score: number }>>;
const path128: ModelPaths128 = "nested.left.name";
interface Model129<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel129 = DeepReadonly<Model129<{ name: string; score: number }>>;
type ModelPaths129 = Paths<Model129<{ name: string; score: number }>>;
const path129: ModelPaths129 = "nested.left.name";
interface Model130<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel130 = DeepReadonly<Model130<{ name: string; score: number }>>;
type ModelPaths130 = Paths<Model130<{ name: string; score: number }>>;
const path130: ModelPaths130 = "nested.left.name";
interface Model131<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel131 = DeepReadonly<Model131<{ name: string; score: number }>>;
type ModelPaths131 = Paths<Model131<{ name: string; score: number }>>;
const path131: ModelPaths131 = "nested.left.name";
interface Model132<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel132 = DeepReadonly<Model132<{ name: string; score: number }>>;
type ModelPaths132 = Paths<Model132<{ name: string; score: number }>>;
const path132: ModelPaths132 = "nested.left.name";
interface Model133<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel133 = DeepReadonly<Model133<{ name: string; score: number }>>;
type ModelPaths133 = Paths<Model133<{ name: string; score: number }>>;
const path133: ModelPaths133 = "nested.left.name";
interface Model134<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel134 = DeepReadonly<Model134<{ name: string; score: number }>>;
type ModelPaths134 = Paths<Model134<{ name: string; score: number }>>;
const path134: ModelPaths134 = "nested.left.name";
interface Model135<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel135 = DeepReadonly<Model135<{ name: string; score: number }>>;
type ModelPaths135 = Paths<Model135<{ name: string; score: number }>>;
const path135: ModelPaths135 = "nested.left.name";
interface Model136<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel136 = DeepReadonly<Model136<{ name: string; score: number }>>;
type ModelPaths136 = Paths<Model136<{ name: string; score: number }>>;
const path136: ModelPaths136 = "nested.left.name";
interface Model137<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel137 = DeepReadonly<Model137<{ name: string; score: number }>>;
type ModelPaths137 = Paths<Model137<{ name: string; score: number }>>;
const path137: ModelPaths137 = "nested.left.name";
interface Model138<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel138 = DeepReadonly<Model138<{ name: string; score: number }>>;
type ModelPaths138 = Paths<Model138<{ name: string; score: number }>>;
const path138: ModelPaths138 = "nested.left.name";
interface Model139<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel139 = DeepReadonly<Model139<{ name: string; score: number }>>;
type ModelPaths139 = Paths<Model139<{ name: string; score: number }>>;
const path139: ModelPaths139 = "nested.left.name";
interface Model140<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel140 = DeepReadonly<Model140<{ name: string; score: number }>>;
type ModelPaths140 = Paths<Model140<{ name: string; score: number }>>;
const path140: ModelPaths140 = "nested.left.name";
interface Model141<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel141 = DeepReadonly<Model141<{ name: string; score: number }>>;
type ModelPaths141 = Paths<Model141<{ name: string; score: number }>>;
const path141: ModelPaths141 = "nested.left.name";
interface Model142<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel142 = DeepReadonly<Model142<{ name: string; score: number }>>;
type ModelPaths142 = Paths<Model142<{ name: string; score: number }>>;
const path142: ModelPaths142 = "nested.left.name";
interface Model143<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel143 = DeepReadonly<Model143<{ name: string; score: number }>>;
type ModelPaths143 = Paths<Model143<{ name: string; score: number }>>;
const path143: ModelPaths143 = "nested.left.name";
interface Model144<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel144 = DeepReadonly<Model144<{ name: string; score: number }>>;
type ModelPaths144 = Paths<Model144<{ name: string; score: number }>>;
const path144: ModelPaths144 = "nested.left.name";
interface Model145<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel145 = DeepReadonly<Model145<{ name: string; score: number }>>;
type ModelPaths145 = Paths<Model145<{ name: string; score: number }>>;
const path145: ModelPaths145 = "nested.left.name";
interface Model146<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel146 = DeepReadonly<Model146<{ name: string; score: number }>>;
type ModelPaths146 = Paths<Model146<{ name: string; score: number }>>;
const path146: ModelPaths146 = "nested.left.name";
interface Model147<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel147 = DeepReadonly<Model147<{ name: string; score: number }>>;
type ModelPaths147 = Paths<Model147<{ name: string; score: number }>>;
const path147: ModelPaths147 = "nested.left.name";
interface Model148<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel148 = DeepReadonly<Model148<{ name: string; score: number }>>;
type ModelPaths148 = Paths<Model148<{ name: string; score: number }>>;
const path148: ModelPaths148 = "nested.left.name";
interface Model149<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel149 = DeepReadonly<Model149<{ name: string; score: number }>>;
type ModelPaths149 = Paths<Model149<{ name: string; score: number }>>;
const path149: ModelPaths149 = "nested.left.name";
interface Model150<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel150 = DeepReadonly<Model150<{ name: string; score: number }>>;
type ModelPaths150 = Paths<Model150<{ name: string; score: number }>>;
const path150: ModelPaths150 = "nested.left.name";
interface Model151<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel151 = DeepReadonly<Model151<{ name: string; score: number }>>;
type ModelPaths151 = Paths<Model151<{ name: string; score: number }>>;
const path151: ModelPaths151 = "nested.left.name";
interface Model152<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel152 = DeepReadonly<Model152<{ name: string; score: number }>>;
type ModelPaths152 = Paths<Model152<{ name: string; score: number }>>;
const path152: ModelPaths152 = "nested.left.name";
interface Model153<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel153 = DeepReadonly<Model153<{ name: string; score: number }>>;
type ModelPaths153 = Paths<Model153<{ name: string; score: number }>>;
const path153: ModelPaths153 = "nested.left.name";
interface Model154<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel154 = DeepReadonly<Model154<{ name: string; score: number }>>;
type ModelPaths154 = Paths<Model154<{ name: string; score: number }>>;
const path154: ModelPaths154 = "nested.left.name";
interface Model155<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel155 = DeepReadonly<Model155<{ name: string; score: number }>>;
type ModelPaths155 = Paths<Model155<{ name: string; score: number }>>;
const path155: ModelPaths155 = "nested.left.name";
interface Model156<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel156 = DeepReadonly<Model156<{ name: string; score: number }>>;
type ModelPaths156 = Paths<Model156<{ name: string; score: number }>>;
const path156: ModelPaths156 = "nested.left.name";
interface Model157<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel157 = DeepReadonly<Model157<{ name: string; score: number }>>;
type ModelPaths157 = Paths<Model157<{ name: string; score: number }>>;
const path157: ModelPaths157 = "nested.left.name";
interface Model158<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel158 = DeepReadonly<Model158<{ name: string; score: number }>>;
type ModelPaths158 = Paths<Model158<{ name: string; score: number }>>;
const path158: ModelPaths158 = "nested.left.name";
interface Model159<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel159 = DeepReadonly<Model159<{ name: string; score: number }>>;
type ModelPaths159 = Paths<Model159<{ name: string; score: number }>>;
const path159: ModelPaths159 = "nested.left.name";
interface Model160<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel160 = DeepReadonly<Model160<{ name: string; score: number }>>;
type ModelPaths160 = Paths<Model160<{ name: string; score: number }>>;
const path160: ModelPaths160 = "nested.left.name";
interface Model161<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel161 = DeepReadonly<Model161<{ name: string; score: number }>>;
type ModelPaths161 = Paths<Model161<{ name: string; score: number }>>;
const path161: ModelPaths161 = "nested.left.name";
interface Model162<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel162 = DeepReadonly<Model162<{ name: string; score: number }>>;
type ModelPaths162 = Paths<Model162<{ name: string; score: number }>>;
const path162: ModelPaths162 = "nested.left.name";
interface Model163<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel163 = DeepReadonly<Model163<{ name: string; score: number }>>;
type ModelPaths163 = Paths<Model163<{ name: string; score: number }>>;
const path163: ModelPaths163 = "nested.left.name";
interface Model164<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel164 = DeepReadonly<Model164<{ name: string; score: number }>>;
type ModelPaths164 = Paths<Model164<{ name: string; score: number }>>;
const path164: ModelPaths164 = "nested.left.name";
interface Model165<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel165 = DeepReadonly<Model165<{ name: string; score: number }>>;
type ModelPaths165 = Paths<Model165<{ name: string; score: number }>>;
const path165: ModelPaths165 = "nested.left.name";
interface Model166<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel166 = DeepReadonly<Model166<{ name: string; score: number }>>;
type ModelPaths166 = Paths<Model166<{ name: string; score: number }>>;
const path166: ModelPaths166 = "nested.left.name";
interface Model167<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel167 = DeepReadonly<Model167<{ name: string; score: number }>>;
type ModelPaths167 = Paths<Model167<{ name: string; score: number }>>;
const path167: ModelPaths167 = "nested.left.name";
interface Model168<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel168 = DeepReadonly<Model168<{ name: string; score: number }>>;
type ModelPaths168 = Paths<Model168<{ name: string; score: number }>>;
const path168: ModelPaths168 = "nested.left.name";
interface Model169<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel169 = DeepReadonly<Model169<{ name: string; score: number }>>;
type ModelPaths169 = Paths<Model169<{ name: string; score: number }>>;
const path169: ModelPaths169 = "nested.left.name";
interface Model170<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel170 = DeepReadonly<Model170<{ name: string; score: number }>>;
type ModelPaths170 = Paths<Model170<{ name: string; score: number }>>;
const path170: ModelPaths170 = "nested.left.name";
interface Model171<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel171 = DeepReadonly<Model171<{ name: string; score: number }>>;
type ModelPaths171 = Paths<Model171<{ name: string; score: number }>>;
const path171: ModelPaths171 = "nested.left.name";
interface Model172<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel172 = DeepReadonly<Model172<{ name: string; score: number }>>;
type ModelPaths172 = Paths<Model172<{ name: string; score: number }>>;
const path172: ModelPaths172 = "nested.left.name";
interface Model173<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel173 = DeepReadonly<Model173<{ name: string; score: number }>>;
type ModelPaths173 = Paths<Model173<{ name: string; score: number }>>;
const path173: ModelPaths173 = "nested.left.name";
interface Model174<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel174 = DeepReadonly<Model174<{ name: string; score: number }>>;
type ModelPaths174 = Paths<Model174<{ name: string; score: number }>>;
const path174: ModelPaths174 = "nested.left.name";
interface Model175<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel175 = DeepReadonly<Model175<{ name: string; score: number }>>;
type ModelPaths175 = Paths<Model175<{ name: string; score: number }>>;
const path175: ModelPaths175 = "nested.left.name";
interface Model176<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel176 = DeepReadonly<Model176<{ name: string; score: number }>>;
type ModelPaths176 = Paths<Model176<{ name: string; score: number }>>;
const path176: ModelPaths176 = "nested.left.name";
interface Model177<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel177 = DeepReadonly<Model177<{ name: string; score: number }>>;
type ModelPaths177 = Paths<Model177<{ name: string; score: number }>>;
const path177: ModelPaths177 = "nested.left.name";
interface Model178<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel178 = DeepReadonly<Model178<{ name: string; score: number }>>;
type ModelPaths178 = Paths<Model178<{ name: string; score: number }>>;
const path178: ModelPaths178 = "nested.left.name";
interface Model179<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel179 = DeepReadonly<Model179<{ name: string; score: number }>>;
type ModelPaths179 = Paths<Model179<{ name: string; score: number }>>;
const path179: ModelPaths179 = "nested.left.name";
interface Model180<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel180 = DeepReadonly<Model180<{ name: string; score: number }>>;
type ModelPaths180 = Paths<Model180<{ name: string; score: number }>>;
const path180: ModelPaths180 = "nested.left.name";
interface Model181<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel181 = DeepReadonly<Model181<{ name: string; score: number }>>;
type ModelPaths181 = Paths<Model181<{ name: string; score: number }>>;
const path181: ModelPaths181 = "nested.left.name";
interface Model182<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel182 = DeepReadonly<Model182<{ name: string; score: number }>>;
type ModelPaths182 = Paths<Model182<{ name: string; score: number }>>;
const path182: ModelPaths182 = "nested.left.name";
interface Model183<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel183 = DeepReadonly<Model183<{ name: string; score: number }>>;
type ModelPaths183 = Paths<Model183<{ name: string; score: number }>>;
const path183: ModelPaths183 = "nested.left.name";
interface Model184<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel184 = DeepReadonly<Model184<{ name: string; score: number }>>;
type ModelPaths184 = Paths<Model184<{ name: string; score: number }>>;
const path184: ModelPaths184 = "nested.left.name";
interface Model185<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel185 = DeepReadonly<Model185<{ name: string; score: number }>>;
type ModelPaths185 = Paths<Model185<{ name: string; score: number }>>;
const path185: ModelPaths185 = "nested.left.name";
interface Model186<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel186 = DeepReadonly<Model186<{ name: string; score: number }>>;
type ModelPaths186 = Paths<Model186<{ name: string; score: number }>>;
const path186: ModelPaths186 = "nested.left.name";
interface Model187<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel187 = DeepReadonly<Model187<{ name: string; score: number }>>;
type ModelPaths187 = Paths<Model187<{ name: string; score: number }>>;
const path187: ModelPaths187 = "nested.left.name";
interface Model188<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel188 = DeepReadonly<Model188<{ name: string; score: number }>>;
type ModelPaths188 = Paths<Model188<{ name: string; score: number }>>;
const path188: ModelPaths188 = "nested.left.name";
interface Model189<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel189 = DeepReadonly<Model189<{ name: string; score: number }>>;
type ModelPaths189 = Paths<Model189<{ name: string; score: number }>>;
const path189: ModelPaths189 = "nested.left.name";
interface Model190<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel190 = DeepReadonly<Model190<{ name: string; score: number }>>;
type ModelPaths190 = Paths<Model190<{ name: string; score: number }>>;
const path190: ModelPaths190 = "nested.left.name";
interface Model191<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel191 = DeepReadonly<Model191<{ name: string; score: number }>>;
type ModelPaths191 = Paths<Model191<{ name: string; score: number }>>;
const path191: ModelPaths191 = "nested.left.name";
interface Model192<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel192 = DeepReadonly<Model192<{ name: string; score: number }>>;
type ModelPaths192 = Paths<Model192<{ name: string; score: number }>>;
const path192: ModelPaths192 = "nested.left.name";
interface Model193<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel193 = DeepReadonly<Model193<{ name: string; score: number }>>;
type ModelPaths193 = Paths<Model193<{ name: string; score: number }>>;
const path193: ModelPaths193 = "nested.left.name";
interface Model194<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel194 = DeepReadonly<Model194<{ name: string; score: number }>>;
type ModelPaths194 = Paths<Model194<{ name: string; score: number }>>;
const path194: ModelPaths194 = "nested.left.name";
interface Model195<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel195 = DeepReadonly<Model195<{ name: string; score: number }>>;
type ModelPaths195 = Paths<Model195<{ name: string; score: number }>>;
const path195: ModelPaths195 = "nested.left.name";
interface Model196<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel196 = DeepReadonly<Model196<{ name: string; score: number }>>;
type ModelPaths196 = Paths<Model196<{ name: string; score: number }>>;
const path196: ModelPaths196 = "nested.left.name";
interface Model197<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel197 = DeepReadonly<Model197<{ name: string; score: number }>>;
type ModelPaths197 = Paths<Model197<{ name: string; score: number }>>;
const path197: ModelPaths197 = "nested.left.name";
interface Model198<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel198 = DeepReadonly<Model198<{ name: string; score: number }>>;
type ModelPaths198 = Paths<Model198<{ name: string; score: number }>>;
const path198: ModelPaths198 = "nested.left.name";
interface Model199<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel199 = DeepReadonly<Model199<{ name: string; score: number }>>;
type ModelPaths199 = Paths<Model199<{ name: string; score: number }>>;
const path199: ModelPaths199 = "nested.left.name";
interface Model200<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel200 = DeepReadonly<Model200<{ name: string; score: number }>>;
type ModelPaths200 = Paths<Model200<{ name: string; score: number }>>;
const path200: ModelPaths200 = "nested.left.name";
interface Model201<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel201 = DeepReadonly<Model201<{ name: string; score: number }>>;
type ModelPaths201 = Paths<Model201<{ name: string; score: number }>>;
const path201: ModelPaths201 = "nested.left.name";
interface Model202<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel202 = DeepReadonly<Model202<{ name: string; score: number }>>;
type ModelPaths202 = Paths<Model202<{ name: string; score: number }>>;
const path202: ModelPaths202 = "nested.left.name";
interface Model203<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel203 = DeepReadonly<Model203<{ name: string; score: number }>>;
type ModelPaths203 = Paths<Model203<{ name: string; score: number }>>;
const path203: ModelPaths203 = "nested.left.name";
interface Model204<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel204 = DeepReadonly<Model204<{ name: string; score: number }>>;
type ModelPaths204 = Paths<Model204<{ name: string; score: number }>>;
const path204: ModelPaths204 = "nested.left.name";
interface Model205<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel205 = DeepReadonly<Model205<{ name: string; score: number }>>;
type ModelPaths205 = Paths<Model205<{ name: string; score: number }>>;
const path205: ModelPaths205 = "nested.left.name";
interface Model206<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel206 = DeepReadonly<Model206<{ name: string; score: number }>>;
type ModelPaths206 = Paths<Model206<{ name: string; score: number }>>;
const path206: ModelPaths206 = "nested.left.name";
interface Model207<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel207 = DeepReadonly<Model207<{ name: string; score: number }>>;
type ModelPaths207 = Paths<Model207<{ name: string; score: number }>>;
const path207: ModelPaths207 = "nested.left.name";
interface Model208<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel208 = DeepReadonly<Model208<{ name: string; score: number }>>;
type ModelPaths208 = Paths<Model208<{ name: string; score: number }>>;
const path208: ModelPaths208 = "nested.left.name";
interface Model209<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel209 = DeepReadonly<Model209<{ name: string; score: number }>>;
type ModelPaths209 = Paths<Model209<{ name: string; score: number }>>;
const path209: ModelPaths209 = "nested.left.name";
interface Model210<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel210 = DeepReadonly<Model210<{ name: string; score: number }>>;
type ModelPaths210 = Paths<Model210<{ name: string; score: number }>>;
const path210: ModelPaths210 = "nested.left.name";
interface Model211<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel211 = DeepReadonly<Model211<{ name: string; score: number }>>;
type ModelPaths211 = Paths<Model211<{ name: string; score: number }>>;
const path211: ModelPaths211 = "nested.left.name";
interface Model212<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel212 = DeepReadonly<Model212<{ name: string; score: number }>>;
type ModelPaths212 = Paths<Model212<{ name: string; score: number }>>;
const path212: ModelPaths212 = "nested.left.name";
interface Model213<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel213 = DeepReadonly<Model213<{ name: string; score: number }>>;
type ModelPaths213 = Paths<Model213<{ name: string; score: number }>>;
const path213: ModelPaths213 = "nested.left.name";
interface Model214<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel214 = DeepReadonly<Model214<{ name: string; score: number }>>;
type ModelPaths214 = Paths<Model214<{ name: string; score: number }>>;
const path214: ModelPaths214 = "nested.left.name";
interface Model215<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel215 = DeepReadonly<Model215<{ name: string; score: number }>>;
type ModelPaths215 = Paths<Model215<{ name: string; score: number }>>;
const path215: ModelPaths215 = "nested.left.name";
interface Model216<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel216 = DeepReadonly<Model216<{ name: string; score: number }>>;
type ModelPaths216 = Paths<Model216<{ name: string; score: number }>>;
const path216: ModelPaths216 = "nested.left.name";
interface Model217<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel217 = DeepReadonly<Model217<{ name: string; score: number }>>;
type ModelPaths217 = Paths<Model217<{ name: string; score: number }>>;
const path217: ModelPaths217 = "nested.left.name";
interface Model218<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel218 = DeepReadonly<Model218<{ name: string; score: number }>>;
type ModelPaths218 = Paths<Model218<{ name: string; score: number }>>;
const path218: ModelPaths218 = "nested.left.name";
interface Model219<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel219 = DeepReadonly<Model219<{ name: string; score: number }>>;
type ModelPaths219 = Paths<Model219<{ name: string; score: number }>>;
const path219: ModelPaths219 = "nested.left.name";
interface Model220<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel220 = DeepReadonly<Model220<{ name: string; score: number }>>;
type ModelPaths220 = Paths<Model220<{ name: string; score: number }>>;
const path220: ModelPaths220 = "nested.left.name";
interface Model221<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel221 = DeepReadonly<Model221<{ name: string; score: number }>>;
type ModelPaths221 = Paths<Model221<{ name: string; score: number }>>;
const path221: ModelPaths221 = "nested.left.name";
interface Model222<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel222 = DeepReadonly<Model222<{ name: string; score: number }>>;
type ModelPaths222 = Paths<Model222<{ name: string; score: number }>>;
const path222: ModelPaths222 = "nested.left.name";
interface Model223<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel223 = DeepReadonly<Model223<{ name: string; score: number }>>;
type ModelPaths223 = Paths<Model223<{ name: string; score: number }>>;
const path223: ModelPaths223 = "nested.left.name";
interface Model224<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel224 = DeepReadonly<Model224<{ name: string; score: number }>>;
type ModelPaths224 = Paths<Model224<{ name: string; score: number }>>;
const path224: ModelPaths224 = "nested.left.name";
interface Model225<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel225 = DeepReadonly<Model225<{ name: string; score: number }>>;
type ModelPaths225 = Paths<Model225<{ name: string; score: number }>>;
const path225: ModelPaths225 = "nested.left.name";
interface Model226<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel226 = DeepReadonly<Model226<{ name: string; score: number }>>;
type ModelPaths226 = Paths<Model226<{ name: string; score: number }>>;
const path226: ModelPaths226 = "nested.left.name";
interface Model227<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel227 = DeepReadonly<Model227<{ name: string; score: number }>>;
type ModelPaths227 = Paths<Model227<{ name: string; score: number }>>;
const path227: ModelPaths227 = "nested.left.name";
interface Model228<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel228 = DeepReadonly<Model228<{ name: string; score: number }>>;
type ModelPaths228 = Paths<Model228<{ name: string; score: number }>>;
const path228: ModelPaths228 = "nested.left.name";
interface Model229<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel229 = DeepReadonly<Model229<{ name: string; score: number }>>;
type ModelPaths229 = Paths<Model229<{ name: string; score: number }>>;
const path229: ModelPaths229 = "nested.left.name";
interface Model230<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel230 = DeepReadonly<Model230<{ name: string; score: number }>>;
type ModelPaths230 = Paths<Model230<{ name: string; score: number }>>;
const path230: ModelPaths230 = "nested.left.name";
interface Model231<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel231 = DeepReadonly<Model231<{ name: string; score: number }>>;
type ModelPaths231 = Paths<Model231<{ name: string; score: number }>>;
const path231: ModelPaths231 = "nested.left.name";
interface Model232<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel232 = DeepReadonly<Model232<{ name: string; score: number }>>;
type ModelPaths232 = Paths<Model232<{ name: string; score: number }>>;
const path232: ModelPaths232 = "nested.left.name";
interface Model233<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel233 = DeepReadonly<Model233<{ name: string; score: number }>>;
type ModelPaths233 = Paths<Model233<{ name: string; score: number }>>;
const path233: ModelPaths233 = "nested.left.name";
interface Model234<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel234 = DeepReadonly<Model234<{ name: string; score: number }>>;
type ModelPaths234 = Paths<Model234<{ name: string; score: number }>>;
const path234: ModelPaths234 = "nested.left.name";
interface Model235<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel235 = DeepReadonly<Model235<{ name: string; score: number }>>;
type ModelPaths235 = Paths<Model235<{ name: string; score: number }>>;
const path235: ModelPaths235 = "nested.left.name";
interface Model236<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel236 = DeepReadonly<Model236<{ name: string; score: number }>>;
type ModelPaths236 = Paths<Model236<{ name: string; score: number }>>;
const path236: ModelPaths236 = "nested.left.name";
interface Model237<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel237 = DeepReadonly<Model237<{ name: string; score: number }>>;
type ModelPaths237 = Paths<Model237<{ name: string; score: number }>>;
const path237: ModelPaths237 = "nested.left.name";
interface Model238<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel238 = DeepReadonly<Model238<{ name: string; score: number }>>;
type ModelPaths238 = Paths<Model238<{ name: string; score: number }>>;
const path238: ModelPaths238 = "nested.left.name";
interface Model239<T> { id: number; payload: T; nested: { left: T; right: readonly T[] }; }
type ReadonlyModel239 = DeepReadonly<Model239<{ name: string; score: number }>>;
type ModelPaths239 = Paths<Model239<{ name: string; score: number }>>;
const path239: ModelPaths239 = "nested.left.name";
