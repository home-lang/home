import { Model20, make20 } from "./module-0020";

export interface Model21<T> {
  readonly current: T;
  readonly previous: Model20<T>;
}

export function make21<T>(value: T): Model21<T> {
  return { current: value, previous: make20(value) };
}

export const marker21: Model21<number> = make21(21);
