import { Model28, make28 } from "./module-0028";

export interface Model29<T> {
  readonly current: T;
  readonly previous: Model28<T>;
}

export function make29<T>(value: T): Model29<T> {
  return { current: value, previous: make28(value) };
}

export const marker29: Model29<number> = make29(29);
