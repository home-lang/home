import { Model37, make37 } from "./module-0037";

export interface Model38<T> {
  readonly current: T;
  readonly previous: Model37<T>;
}

export function make38<T>(value: T): Model38<T> {
  return { current: value, previous: make37(value) };
}

export const marker38: Model38<number> = make38(38);
