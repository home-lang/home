import { Model79, make79 } from "./module-0079";

export interface Model80<T> {
  readonly current: T;
  readonly previous: Model79<T>;
}

export function make80<T>(value: T): Model80<T> {
  return { current: value, previous: make79(value) };
}

export const marker80: Model80<number> = make80(80);
