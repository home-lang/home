import { Model43, make43 } from "./module-0043";

export interface Model44<T> {
  readonly current: T;
  readonly previous: Model43<T>;
}

export function make44<T>(value: T): Model44<T> {
  return { current: value, previous: make43(value) };
}

export const marker44: Model44<number> = make44(44);
