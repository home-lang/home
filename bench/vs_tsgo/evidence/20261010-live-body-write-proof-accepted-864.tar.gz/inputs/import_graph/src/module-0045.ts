import { Model44, make44 } from "./module-0044";

export interface Model45<T> {
  readonly current: T;
  readonly previous: Model44<T>;
}

export function make45<T>(value: T): Model45<T> {
  return { current: value, previous: make44(value) };
}

export const marker45: Model45<number> = make45(45);
