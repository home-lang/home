import { Model115, make115 } from "./module-0115";

export interface Model116<T> {
  readonly current: T;
  readonly previous: Model115<T>;
}

export function make116<T>(value: T): Model116<T> {
  return { current: value, previous: make115(value) };
}

export const marker116: Model116<number> = make116(116);
