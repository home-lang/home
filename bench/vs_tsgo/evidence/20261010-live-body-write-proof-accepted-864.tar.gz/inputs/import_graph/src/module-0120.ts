import { Model119, make119 } from "./module-0119";

export interface Model120<T> {
  readonly current: T;
  readonly previous: Model119<T>;
}

export function make120<T>(value: T): Model120<T> {
  return { current: value, previous: make119(value) };
}

export const marker120: Model120<number> = make120(120);
