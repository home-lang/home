import { Model56, make56 } from "./module-0056";

export interface Model57<T> {
  readonly current: T;
  readonly previous: Model56<T>;
}

export function make57<T>(value: T): Model57<T> {
  return { current: value, previous: make56(value) };
}

export const marker57: Model57<number> = make57(57);
