import { Model47, make47 } from "./module-0047";

export interface Model48<T> {
  readonly current: T;
  readonly previous: Model47<T>;
}

export function make48<T>(value: T): Model48<T> {
  return { current: value, previous: make47(value) };
}

export const marker48: Model48<number> = make48(48);
