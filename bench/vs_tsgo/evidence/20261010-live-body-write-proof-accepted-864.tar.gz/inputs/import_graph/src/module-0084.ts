import { Model83, make83 } from "./module-0083";

export interface Model84<T> {
  readonly current: T;
  readonly previous: Model83<T>;
}

export function make84<T>(value: T): Model84<T> {
  return { current: value, previous: make83(value) };
}

export const marker84: Model84<number> = make84(84);
