import { Model64, make64 } from "./module-0064";

export interface Model65<T> {
  readonly current: T;
  readonly previous: Model64<T>;
}

export function make65<T>(value: T): Model65<T> {
  return { current: value, previous: make64(value) };
}

export const marker65: Model65<number> = make65(65);
