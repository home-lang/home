import { Model117, make117 } from "./module-0117";

export interface Model118<T> {
  readonly current: T;
  readonly previous: Model117<T>;
}

export function make118<T>(value: T): Model118<T> {
  return { current: value, previous: make117(value) };
}

export const marker118: Model118<number> = make118(118);
