import { Model113, make113 } from "./module-0113";

export interface Model114<T> {
  readonly current: T;
  readonly previous: Model113<T>;
}

export function make114<T>(value: T): Model114<T> {
  return { current: value, previous: make113(value) };
}

export const marker114: Model114<number> = make114(114);
