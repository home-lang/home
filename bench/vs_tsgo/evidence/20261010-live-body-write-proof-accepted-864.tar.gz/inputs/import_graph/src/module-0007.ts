import { Model6, make6 } from "./module-0006";

export interface Model7<T> {
  readonly current: T;
  readonly previous: Model6<T>;
}

export function make7<T>(value: T): Model7<T> {
  return { current: value, previous: make6(value) };
}

export const marker7: Model7<number> = make7(7);
