import { Model14, make14 } from "./module-0014";

export interface Model15<T> {
  readonly current: T;
  readonly previous: Model14<T>;
}

export function make15<T>(value: T): Model15<T> {
  return { current: value, previous: make14(value) };
}

export const marker15: Model15<number> = make15(15);
