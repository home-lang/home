import { Model76, make76 } from "./module-0076";

export interface Model77<T> {
  readonly current: T;
  readonly previous: Model76<T>;
}

export function make77<T>(value: T): Model77<T> {
  return { current: value, previous: make76(value) };
}

export const marker77: Model77<number> = make77(77);
