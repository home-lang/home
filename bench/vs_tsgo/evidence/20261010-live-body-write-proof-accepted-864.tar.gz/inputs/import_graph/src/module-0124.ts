import { Model123, make123 } from "./module-0123";

export interface Model124<T> {
  readonly current: T;
  readonly previous: Model123<T>;
}

export function make124<T>(value: T): Model124<T> {
  return { current: value, previous: make123(value) };
}

export const marker124: Model124<number> = make124(124);
