import { Model52, make52 } from "./module-0052";

export interface Model53<T> {
  readonly current: T;
  readonly previous: Model52<T>;
}

export function make53<T>(value: T): Model53<T> {
  return { current: value, previous: make52(value) };
}

export const marker53: Model53<number> = make53(53);
