import { Model107, make107 } from "./module-0107";

export interface Model108<T> {
  readonly current: T;
  readonly previous: Model107<T>;
}

export function make108<T>(value: T): Model108<T> {
  return { current: value, previous: make107(value) };
}

export const marker108: Model108<number> = make108(108);
