import { Model10, make10 } from "./module-0010";

export interface Model11<T> {
  readonly current: T;
  readonly previous: Model10<T>;
}

export function make11<T>(value: T): Model11<T> {
  return { current: value, previous: make10(value) };
}

export const marker11: Model11<number> = make11(11);
