import { Model40, make40 } from "./module-0040";

export interface Model41<T> {
  readonly current: T;
  readonly previous: Model40<T>;
}

export function make41<T>(value: T): Model41<T> {
  return { current: value, previous: make40(value) };
}

export const marker41: Model41<number> = make41(41);
