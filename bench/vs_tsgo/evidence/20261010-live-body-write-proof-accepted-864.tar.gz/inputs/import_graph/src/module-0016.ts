import { Model15, make15 } from "./module-0015";

export interface Model16<T> {
  readonly current: T;
  readonly previous: Model15<T>;
}

export function make16<T>(value: T): Model16<T> {
  return { current: value, previous: make15(value) };
}

export const marker16: Model16<number> = make16(16);
