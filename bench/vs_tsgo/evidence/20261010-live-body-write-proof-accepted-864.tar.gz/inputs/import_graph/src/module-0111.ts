import { Model110, make110 } from "./module-0110";

export interface Model111<T> {
  readonly current: T;
  readonly previous: Model110<T>;
}

export function make111<T>(value: T): Model111<T> {
  return { current: value, previous: make110(value) };
}

export const marker111: Model111<number> = make111(111);
