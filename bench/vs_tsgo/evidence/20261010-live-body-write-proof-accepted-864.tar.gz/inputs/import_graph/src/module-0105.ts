import { Model104, make104 } from "./module-0104";

export interface Model105<T> {
  readonly current: T;
  readonly previous: Model104<T>;
}

export function make105<T>(value: T): Model105<T> {
  return { current: value, previous: make104(value) };
}

export const marker105: Model105<number> = make105(105);
