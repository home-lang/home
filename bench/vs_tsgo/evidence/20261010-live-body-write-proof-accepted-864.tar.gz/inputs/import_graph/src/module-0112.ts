import { Model111, make111 } from "./module-0111";

export interface Model112<T> {
  readonly current: T;
  readonly previous: Model111<T>;
}

export function make112<T>(value: T): Model112<T> {
  return { current: value, previous: make111(value) };
}

export const marker112: Model112<number> = make112(112);
