import { Model13, make13 } from "./module-0013";

export interface Model14<T> {
  readonly current: T;
  readonly previous: Model13<T>;
}

export function make14<T>(value: T): Model14<T> {
  return { current: value, previous: make13(value) };
}

export const marker14: Model14<number> = make14(14);
