import { Model108, make108 } from "./module-0108";

export interface Model109<T> {
  readonly current: T;
  readonly previous: Model108<T>;
}

export function make109<T>(value: T): Model109<T> {
  return { current: value, previous: make108(value) };
}

export const marker109: Model109<number> = make109(109);
