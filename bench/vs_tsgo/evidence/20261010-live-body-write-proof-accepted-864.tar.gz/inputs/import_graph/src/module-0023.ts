import { Model22, make22 } from "./module-0022";

export interface Model23<T> {
  readonly current: T;
  readonly previous: Model22<T>;
}

export function make23<T>(value: T): Model23<T> {
  return { current: value, previous: make22(value) };
}

export const marker23: Model23<number> = make23(23);
