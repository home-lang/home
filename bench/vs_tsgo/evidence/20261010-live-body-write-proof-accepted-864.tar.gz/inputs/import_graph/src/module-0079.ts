import { Model78, make78 } from "./module-0078";

export interface Model79<T> {
  readonly current: T;
  readonly previous: Model78<T>;
}

export function make79<T>(value: T): Model79<T> {
  return { current: value, previous: make78(value) };
}

export const marker79: Model79<number> = make79(79);
