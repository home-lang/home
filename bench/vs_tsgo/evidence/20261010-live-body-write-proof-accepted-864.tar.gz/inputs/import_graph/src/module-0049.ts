import { Model48, make48 } from "./module-0048";

export interface Model49<T> {
  readonly current: T;
  readonly previous: Model48<T>;
}

export function make49<T>(value: T): Model49<T> {
  return { current: value, previous: make48(value) };
}

export const marker49: Model49<number> = make49(49);
