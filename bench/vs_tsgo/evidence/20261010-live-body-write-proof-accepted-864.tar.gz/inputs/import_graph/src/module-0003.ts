import { Model2, make2 } from "./module-0002";

export interface Model3<T> {
  readonly current: T;
  readonly previous: Model2<T>;
}

export function make3<T>(value: T): Model3<T> {
  return { current: value, previous: make2(value) };
}

export const marker3: Model3<number> = make3(3);
