import { Model72, make72 } from "./module-0072";

export interface Model73<T> {
  readonly current: T;
  readonly previous: Model72<T>;
}

export function make73<T>(value: T): Model73<T> {
  return { current: value, previous: make72(value) };
}

export const marker73: Model73<number> = make73(73);
