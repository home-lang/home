import { Model102, make102 } from "./module-0102";

export interface Model103<T> {
  readonly current: T;
  readonly previous: Model102<T>;
}

export function make103<T>(value: T): Model103<T> {
  return { current: value, previous: make102(value) };
}

export const marker103: Model103<number> = make103(103);
