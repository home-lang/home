import { Model62, make62 } from "./module-0062";

export interface Model63<T> {
  readonly current: T;
  readonly previous: Model62<T>;
}

export function make63<T>(value: T): Model63<T> {
  return { current: value, previous: make62(value) };
}

export const marker63: Model63<number> = make63(63);
