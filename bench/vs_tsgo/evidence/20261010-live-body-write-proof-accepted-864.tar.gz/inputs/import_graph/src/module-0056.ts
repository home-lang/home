import { Model55, make55 } from "./module-0055";

export interface Model56<T> {
  readonly current: T;
  readonly previous: Model55<T>;
}

export function make56<T>(value: T): Model56<T> {
  return { current: value, previous: make55(value) };
}

export const marker56: Model56<number> = make56(56);
