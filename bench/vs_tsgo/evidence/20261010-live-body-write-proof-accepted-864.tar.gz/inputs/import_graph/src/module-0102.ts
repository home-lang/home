import { Model101, make101 } from "./module-0101";

export interface Model102<T> {
  readonly current: T;
  readonly previous: Model101<T>;
}

export function make102<T>(value: T): Model102<T> {
  return { current: value, previous: make101(value) };
}

export const marker102: Model102<number> = make102(102);
