import { Model82, make82 } from "./module-0082";

export interface Model83<T> {
  readonly current: T;
  readonly previous: Model82<T>;
}

export function make83<T>(value: T): Model83<T> {
  return { current: value, previous: make82(value) };
}

export const marker83: Model83<number> = make83(83);
