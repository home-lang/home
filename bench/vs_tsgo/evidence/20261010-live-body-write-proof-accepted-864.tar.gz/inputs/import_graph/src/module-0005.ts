import { Model4, make4 } from "./module-0004";

export interface Model5<T> {
  readonly current: T;
  readonly previous: Model4<T>;
}

export function make5<T>(value: T): Model5<T> {
  return { current: value, previous: make4(value) };
}

export const marker5: Model5<number> = make5(5);
