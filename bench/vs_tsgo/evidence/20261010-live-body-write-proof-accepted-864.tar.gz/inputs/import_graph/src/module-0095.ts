import { Model94, make94 } from "./module-0094";

export interface Model95<T> {
  readonly current: T;
  readonly previous: Model94<T>;
}

export function make95<T>(value: T): Model95<T> {
  return { current: value, previous: make94(value) };
}

export const marker95: Model95<number> = make95(95);
