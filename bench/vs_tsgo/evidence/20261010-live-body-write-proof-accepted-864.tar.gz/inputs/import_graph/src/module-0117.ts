import { Model116, make116 } from "./module-0116";

export interface Model117<T> {
  readonly current: T;
  readonly previous: Model116<T>;
}

export function make117<T>(value: T): Model117<T> {
  return { current: value, previous: make116(value) };
}

export const marker117: Model117<number> = make117(117);
