import { Model121, make121 } from "./module-0121";

export interface Model122<T> {
  readonly current: T;
  readonly previous: Model121<T>;
}

export function make122<T>(value: T): Model122<T> {
  return { current: value, previous: make121(value) };
}

export const marker122: Model122<number> = make122(122);
