import { Model59, make59 } from "./module-0059";

export interface Model60<T> {
  readonly current: T;
  readonly previous: Model59<T>;
}

export function make60<T>(value: T): Model60<T> {
  return { current: value, previous: make59(value) };
}

export const marker60: Model60<number> = make60(60);
