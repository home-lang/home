import { Model73, make73 } from "./module-0073";

export interface Model74<T> {
  readonly current: T;
  readonly previous: Model73<T>;
}

export function make74<T>(value: T): Model74<T> {
  return { current: value, previous: make73(value) };
}

export const marker74: Model74<number> = make74(74);
