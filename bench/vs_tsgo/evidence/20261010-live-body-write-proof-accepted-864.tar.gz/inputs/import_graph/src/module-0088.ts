import { Model87, make87 } from "./module-0087";

export interface Model88<T> {
  readonly current: T;
  readonly previous: Model87<T>;
}

export function make88<T>(value: T): Model88<T> {
  return { current: value, previous: make87(value) };
}

export const marker88: Model88<number> = make88(88);
