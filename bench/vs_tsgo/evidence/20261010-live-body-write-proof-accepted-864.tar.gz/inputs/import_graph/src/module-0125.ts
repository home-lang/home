import { Model124, make124 } from "./module-0124";

export interface Model125<T> {
  readonly current: T;
  readonly previous: Model124<T>;
}

export function make125<T>(value: T): Model125<T> {
  return { current: value, previous: make124(value) };
}

export const marker125: Model125<number> = make125(125);
