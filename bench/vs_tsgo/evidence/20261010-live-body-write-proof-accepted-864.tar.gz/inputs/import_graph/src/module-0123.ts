import { Model122, make122 } from "./module-0122";

export interface Model123<T> {
  readonly current: T;
  readonly previous: Model122<T>;
}

export function make123<T>(value: T): Model123<T> {
  return { current: value, previous: make122(value) };
}

export const marker123: Model123<number> = make123(123);
