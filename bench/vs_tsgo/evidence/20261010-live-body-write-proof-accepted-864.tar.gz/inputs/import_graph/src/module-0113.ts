import { Model112, make112 } from "./module-0112";

export interface Model113<T> {
  readonly current: T;
  readonly previous: Model112<T>;
}

export function make113<T>(value: T): Model113<T> {
  return { current: value, previous: make112(value) };
}

export const marker113: Model113<number> = make113(113);
