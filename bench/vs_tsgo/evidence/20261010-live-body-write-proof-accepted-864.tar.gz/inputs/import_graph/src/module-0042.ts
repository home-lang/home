import { Model41, make41 } from "./module-0041";

export interface Model42<T> {
  readonly current: T;
  readonly previous: Model41<T>;
}

export function make42<T>(value: T): Model42<T> {
  return { current: value, previous: make41(value) };
}

export const marker42: Model42<number> = make42(42);
