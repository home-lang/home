import { Model95, make95 } from "./module-0095";

export interface Model96<T> {
  readonly current: T;
  readonly previous: Model95<T>;
}

export function make96<T>(value: T): Model96<T> {
  return { current: value, previous: make95(value) };
}

export const marker96: Model96<number> = make96(96);
