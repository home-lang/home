import { Model49, make49 } from "./module-0049";

export interface Model50<T> {
  readonly current: T;
  readonly previous: Model49<T>;
}

export function make50<T>(value: T): Model50<T> {
  return { current: value, previous: make49(value) };
}

export const marker50: Model50<number> = make50(50);
