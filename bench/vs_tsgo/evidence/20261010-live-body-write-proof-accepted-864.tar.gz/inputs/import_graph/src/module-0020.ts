import { Model19, make19 } from "./module-0019";

export interface Model20<T> {
  readonly current: T;
  readonly previous: Model19<T>;
}

export function make20<T>(value: T): Model20<T> {
  return { current: value, previous: make19(value) };
}

export const marker20: Model20<number> = make20(20);
