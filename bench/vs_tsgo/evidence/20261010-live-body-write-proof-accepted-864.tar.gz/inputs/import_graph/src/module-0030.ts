import { Model29, make29 } from "./module-0029";

export interface Model30<T> {
  readonly current: T;
  readonly previous: Model29<T>;
}

export function make30<T>(value: T): Model30<T> {
  return { current: value, previous: make29(value) };
}

export const marker30: Model30<number> = make30(30);
