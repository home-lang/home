import { Model18, make18 } from "./module-0018";

export interface Model19<T> {
  readonly current: T;
  readonly previous: Model18<T>;
}

export function make19<T>(value: T): Model19<T> {
  return { current: value, previous: make18(value) };
}

export const marker19: Model19<number> = make19(19);
