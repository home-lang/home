import { Model58, make58 } from "./module-0058";

export interface Model59<T> {
  readonly current: T;
  readonly previous: Model58<T>;
}

export function make59<T>(value: T): Model59<T> {
  return { current: value, previous: make58(value) };
}

export const marker59: Model59<number> = make59(59);
