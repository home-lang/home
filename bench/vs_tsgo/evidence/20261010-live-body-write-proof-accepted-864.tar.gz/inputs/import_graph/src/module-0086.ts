import { Model85, make85 } from "./module-0085";

export interface Model86<T> {
  readonly current: T;
  readonly previous: Model85<T>;
}

export function make86<T>(value: T): Model86<T> {
  return { current: value, previous: make85(value) };
}

export const marker86: Model86<number> = make86(86);
