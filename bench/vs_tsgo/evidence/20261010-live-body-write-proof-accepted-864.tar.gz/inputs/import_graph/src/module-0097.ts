import { Model96, make96 } from "./module-0096";

export interface Model97<T> {
  readonly current: T;
  readonly previous: Model96<T>;
}

export function make97<T>(value: T): Model97<T> {
  return { current: value, previous: make96(value) };
}

export const marker97: Model97<number> = make97(97);
