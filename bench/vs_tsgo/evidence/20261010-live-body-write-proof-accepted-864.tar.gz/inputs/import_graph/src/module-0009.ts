import { Model8, make8 } from "./module-0008";

export interface Model9<T> {
  readonly current: T;
  readonly previous: Model8<T>;
}

export function make9<T>(value: T): Model9<T> {
  return { current: value, previous: make8(value) };
}

export const marker9: Model9<number> = make9(9);
