import { Model33, make33 } from "./module-0033";

export interface Model34<T> {
  readonly current: T;
  readonly previous: Model33<T>;
}

export function make34<T>(value: T): Model34<T> {
  return { current: value, previous: make33(value) };
}

export const marker34: Model34<number> = make34(34);
