import { Model27, make27 } from "./module-0027";

export interface Model28<T> {
  readonly current: T;
  readonly previous: Model27<T>;
}

export function make28<T>(value: T): Model28<T> {
  return { current: value, previous: make27(value) };
}

export const marker28: Model28<number> = make28(28);
