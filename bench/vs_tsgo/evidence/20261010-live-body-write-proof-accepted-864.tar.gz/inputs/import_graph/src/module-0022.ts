import { Model21, make21 } from "./module-0021";

export interface Model22<T> {
  readonly current: T;
  readonly previous: Model21<T>;
}

export function make22<T>(value: T): Model22<T> {
  return { current: value, previous: make21(value) };
}

export const marker22: Model22<number> = make22(22);
