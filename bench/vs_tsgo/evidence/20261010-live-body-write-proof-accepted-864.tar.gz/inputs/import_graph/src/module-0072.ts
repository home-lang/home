import { Model71, make71 } from "./module-0071";

export interface Model72<T> {
  readonly current: T;
  readonly previous: Model71<T>;
}

export function make72<T>(value: T): Model72<T> {
  return { current: value, previous: make71(value) };
}

export const marker72: Model72<number> = make72(72);
