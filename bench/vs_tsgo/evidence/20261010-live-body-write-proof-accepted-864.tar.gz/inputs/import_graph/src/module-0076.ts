import { Model75, make75 } from "./module-0075";

export interface Model76<T> {
  readonly current: T;
  readonly previous: Model75<T>;
}

export function make76<T>(value: T): Model76<T> {
  return { current: value, previous: make75(value) };
}

export const marker76: Model76<number> = make76(76);
