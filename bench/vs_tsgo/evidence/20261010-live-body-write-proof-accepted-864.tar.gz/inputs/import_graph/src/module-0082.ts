import { Model81, make81 } from "./module-0081";

export interface Model82<T> {
  readonly current: T;
  readonly previous: Model81<T>;
}

export function make82<T>(value: T): Model82<T> {
  return { current: value, previous: make81(value) };
}

export const marker82: Model82<number> = make82(82);
