import { Model30, make30 } from "./module-0030";

export interface Model31<T> {
  readonly current: T;
  readonly previous: Model30<T>;
}

export function make31<T>(value: T): Model31<T> {
  return { current: value, previous: make30(value) };
}

export const marker31: Model31<number> = make31(31);
