import { Model86, make86 } from "./module-0086";

export interface Model87<T> {
  readonly current: T;
  readonly previous: Model86<T>;
}

export function make87<T>(value: T): Model87<T> {
  return { current: value, previous: make86(value) };
}

export const marker87: Model87<number> = make87(87);
