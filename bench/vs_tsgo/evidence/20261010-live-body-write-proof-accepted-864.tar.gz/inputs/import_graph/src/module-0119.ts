import { Model118, make118 } from "./module-0118";

export interface Model119<T> {
  readonly current: T;
  readonly previous: Model118<T>;
}

export function make119<T>(value: T): Model119<T> {
  return { current: value, previous: make118(value) };
}

export const marker119: Model119<number> = make119(119);
