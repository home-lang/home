import { Model77, make77 } from "./module-0077";

export interface Model78<T> {
  readonly current: T;
  readonly previous: Model77<T>;
}

export function make78<T>(value: T): Model78<T> {
  return { current: value, previous: make77(value) };
}

export const marker78: Model78<number> = make78(78);
