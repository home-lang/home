import { Model35, make35 } from "./module-0035";

export interface Model36<T> {
  readonly current: T;
  readonly previous: Model35<T>;
}

export function make36<T>(value: T): Model36<T> {
  return { current: value, previous: make35(value) };
}

export const marker36: Model36<number> = make36(36);
