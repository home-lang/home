import { Model17, make17 } from "./module-0017";

export interface Model18<T> {
  readonly current: T;
  readonly previous: Model17<T>;
}

export function make18<T>(value: T): Model18<T> {
  return { current: value, previous: make17(value) };
}

export const marker18: Model18<number> = make18(18);
