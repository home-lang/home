import { Model103, make103 } from "./module-0103";

export interface Model104<T> {
  readonly current: T;
  readonly previous: Model103<T>;
}

export function make104<T>(value: T): Model104<T> {
  return { current: value, previous: make103(value) };
}

export const marker104: Model104<number> = make104(104);
