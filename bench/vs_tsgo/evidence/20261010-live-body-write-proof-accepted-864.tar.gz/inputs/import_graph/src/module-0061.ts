import { Model60, make60 } from "./module-0060";

export interface Model61<T> {
  readonly current: T;
  readonly previous: Model60<T>;
}

export function make61<T>(value: T): Model61<T> {
  return { current: value, previous: make60(value) };
}

export const marker61: Model61<number> = make61(61);
