import { Model16, make16 } from "./module-0016";

export interface Model17<T> {
  readonly current: T;
  readonly previous: Model16<T>;
}

export function make17<T>(value: T): Model17<T> {
  return { current: value, previous: make16(value) };
}

export const marker17: Model17<number> = make17(17);
