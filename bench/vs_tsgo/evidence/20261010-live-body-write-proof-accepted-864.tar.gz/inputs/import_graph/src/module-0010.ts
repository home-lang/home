import { Model9, make9 } from "./module-0009";

export interface Model10<T> {
  readonly current: T;
  readonly previous: Model9<T>;
}

export function make10<T>(value: T): Model10<T> {
  return { current: value, previous: make9(value) };
}

export const marker10: Model10<number> = make10(10);
