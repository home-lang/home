import { Model105, make105 } from "./module-0105";

export interface Model106<T> {
  readonly current: T;
  readonly previous: Model105<T>;
}

export function make106<T>(value: T): Model106<T> {
  return { current: value, previous: make105(value) };
}

export const marker106: Model106<number> = make106(106);
