import { Model63, make63 } from "./module-0063";

export interface Model64<T> {
  readonly current: T;
  readonly previous: Model63<T>;
}

export function make64<T>(value: T): Model64<T> {
  return { current: value, previous: make63(value) };
}

export const marker64: Model64<number> = make64(64);
