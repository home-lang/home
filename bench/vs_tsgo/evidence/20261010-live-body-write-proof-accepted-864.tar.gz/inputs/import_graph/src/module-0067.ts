import { Model66, make66 } from "./module-0066";

export interface Model67<T> {
  readonly current: T;
  readonly previous: Model66<T>;
}

export function make67<T>(value: T): Model67<T> {
  return { current: value, previous: make66(value) };
}

export const marker67: Model67<number> = make67(67);
