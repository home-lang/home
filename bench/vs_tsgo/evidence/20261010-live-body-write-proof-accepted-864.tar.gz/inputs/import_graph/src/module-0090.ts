import { Model89, make89 } from "./module-0089";

export interface Model90<T> {
  readonly current: T;
  readonly previous: Model89<T>;
}

export function make90<T>(value: T): Model90<T> {
  return { current: value, previous: make89(value) };
}

export const marker90: Model90<number> = make90(90);
