import { Model70, make70 } from "./module-0070";

export interface Model71<T> {
  readonly current: T;
  readonly previous: Model70<T>;
}

export function make71<T>(value: T): Model71<T> {
  return { current: value, previous: make70(value) };
}

export const marker71: Model71<number> = make71(71);
