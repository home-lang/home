import { Model5, make5 } from "./module-0005";

export interface Model6<T> {
  readonly current: T;
  readonly previous: Model5<T>;
}

export function make6<T>(value: T): Model6<T> {
  return { current: value, previous: make5(value) };
}

export const marker6: Model6<number> = make6(6);
