import { Model106, make106 } from "./module-0106";

export interface Model107<T> {
  readonly current: T;
  readonly previous: Model106<T>;
}

export function make107<T>(value: T): Model107<T> {
  return { current: value, previous: make106(value) };
}

export const marker107: Model107<number> = make107(107);
