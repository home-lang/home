import { Model91, make91 } from "./module-0091";

export interface Model92<T> {
  readonly current: T;
  readonly previous: Model91<T>;
}

export function make92<T>(value: T): Model92<T> {
  return { current: value, previous: make91(value) };
}

export const marker92: Model92<number> = make92(92);
