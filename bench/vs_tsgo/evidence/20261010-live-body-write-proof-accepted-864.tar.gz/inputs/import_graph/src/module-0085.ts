import { Model84, make84 } from "./module-0084";

export interface Model85<T> {
  readonly current: T;
  readonly previous: Model84<T>;
}

export function make85<T>(value: T): Model85<T> {
  return { current: value, previous: make84(value) };
}

export const marker85: Model85<number> = make85(85);
