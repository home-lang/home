import { Model1, make1 } from "./module-0001";

export interface Model2<T> {
  readonly current: T;
  readonly previous: Model1<T>;
}

export function make2<T>(value: T): Model2<T> {
  return { current: value, previous: make1(value) };
}

export const marker2: Model2<number> = make2(2);
