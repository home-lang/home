import { Model12, make12 } from "./module-0012";

export interface Model13<T> {
  readonly current: T;
  readonly previous: Model12<T>;
}

export function make13<T>(value: T): Model13<T> {
  return { current: value, previous: make12(value) };
}

export const marker13: Model13<number> = make13(13);
