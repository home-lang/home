import { Model114, make114 } from "./module-0114";

export interface Model115<T> {
  readonly current: T;
  readonly previous: Model114<T>;
}

export function make115<T>(value: T): Model115<T> {
  return { current: value, previous: make114(value) };
}

export const marker115: Model115<number> = make115(115);
