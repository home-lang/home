import { Model46, make46 } from "./module-0046";

export interface Model47<T> {
  readonly current: T;
  readonly previous: Model46<T>;
}

export function make47<T>(value: T): Model47<T> {
  return { current: value, previous: make46(value) };
}

export const marker47: Model47<number> = make47(47);
