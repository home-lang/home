import { Model93, make93 } from "./module-0093";

export interface Model94<T> {
  readonly current: T;
  readonly previous: Model93<T>;
}

export function make94<T>(value: T): Model94<T> {
  return { current: value, previous: make93(value) };
}

export const marker94: Model94<number> = make94(94);
