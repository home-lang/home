import { Model39, make39 } from "./module-0039";

export interface Model40<T> {
  readonly current: T;
  readonly previous: Model39<T>;
}

export function make40<T>(value: T): Model40<T> {
  return { current: value, previous: make39(value) };
}

export const marker40: Model40<number> = make40(40);
