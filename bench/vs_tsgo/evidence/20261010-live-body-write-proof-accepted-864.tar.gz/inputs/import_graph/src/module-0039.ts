import { Model38, make38 } from "./module-0038";

export interface Model39<T> {
  readonly current: T;
  readonly previous: Model38<T>;
}

export function make39<T>(value: T): Model39<T> {
  return { current: value, previous: make38(value) };
}

export const marker39: Model39<number> = make39(39);
