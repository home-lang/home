import { Model51, make51 } from "./module-0051";

export interface Model52<T> {
  readonly current: T;
  readonly previous: Model51<T>;
}

export function make52<T>(value: T): Model52<T> {
  return { current: value, previous: make51(value) };
}

export const marker52: Model52<number> = make52(52);
