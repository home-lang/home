import { Model65, make65 } from "./module-0065";

export interface Model66<T> {
  readonly current: T;
  readonly previous: Model65<T>;
}

export function make66<T>(value: T): Model66<T> {
  return { current: value, previous: make65(value) };
}

export const marker66: Model66<number> = make66(66);
