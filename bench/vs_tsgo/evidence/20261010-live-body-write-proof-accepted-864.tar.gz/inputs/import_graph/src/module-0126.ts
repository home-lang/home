import { Model125, make125 } from "./module-0125";

export interface Model126<T> {
  readonly current: T;
  readonly previous: Model125<T>;
}

export function make126<T>(value: T): Model126<T> {
  return { current: value, previous: make125(value) };
}

export const marker126: Model126<number> = make126(126);
