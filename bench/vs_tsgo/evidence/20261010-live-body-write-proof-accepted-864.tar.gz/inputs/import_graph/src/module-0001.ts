import { Model0, make0 } from "./module-0000";

export interface Model1<T> {
  readonly current: T;
  readonly previous: Model0<T>;
}

export function make1<T>(value: T): Model1<T> {
  return { current: value, previous: make0(value) };
}

export const marker1: Model1<number> = make1(1);
