import { Model92, make92 } from "./module-0092";

export interface Model93<T> {
  readonly current: T;
  readonly previous: Model92<T>;
}

export function make93<T>(value: T): Model93<T> {
  return { current: value, previous: make92(value) };
}

export const marker93: Model93<number> = make93(93);
