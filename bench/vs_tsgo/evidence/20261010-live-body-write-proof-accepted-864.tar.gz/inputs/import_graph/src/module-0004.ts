import { Model3, make3 } from "./module-0003";

export interface Model4<T> {
  readonly current: T;
  readonly previous: Model3<T>;
}

export function make4<T>(value: T): Model4<T> {
  return { current: value, previous: make3(value) };
}

export const marker4: Model4<number> = make4(4);
