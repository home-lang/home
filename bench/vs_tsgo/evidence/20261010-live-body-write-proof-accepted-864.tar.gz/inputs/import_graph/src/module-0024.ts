import { Model23, make23 } from "./module-0023";

export interface Model24<T> {
  readonly current: T;
  readonly previous: Model23<T>;
}

export function make24<T>(value: T): Model24<T> {
  return { current: value, previous: make23(value) };
}

export const marker24: Model24<number> = make24(24);
