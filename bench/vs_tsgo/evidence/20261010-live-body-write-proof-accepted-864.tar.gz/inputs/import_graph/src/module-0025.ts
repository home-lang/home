import { Model24, make24 } from "./module-0024";

export interface Model25<T> {
  readonly current: T;
  readonly previous: Model24<T>;
}

export function make25<T>(value: T): Model25<T> {
  return { current: value, previous: make24(value) };
}

export const marker25: Model25<number> = make25(25);
