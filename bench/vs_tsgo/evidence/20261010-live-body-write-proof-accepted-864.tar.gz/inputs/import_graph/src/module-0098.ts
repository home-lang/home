import { Model97, make97 } from "./module-0097";

export interface Model98<T> {
  readonly current: T;
  readonly previous: Model97<T>;
}

export function make98<T>(value: T): Model98<T> {
  return { current: value, previous: make97(value) };
}

export const marker98: Model98<number> = make98(98);
