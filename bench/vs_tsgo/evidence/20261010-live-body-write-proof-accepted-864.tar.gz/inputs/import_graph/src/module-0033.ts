import { Model32, make32 } from "./module-0032";

export interface Model33<T> {
  readonly current: T;
  readonly previous: Model32<T>;
}

export function make33<T>(value: T): Model33<T> {
  return { current: value, previous: make32(value) };
}

export const marker33: Model33<number> = make33(33);
