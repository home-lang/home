import { Model31, make31 } from "./module-0031";

export interface Model32<T> {
  readonly current: T;
  readonly previous: Model31<T>;
}

export function make32<T>(value: T): Model32<T> {
  return { current: value, previous: make31(value) };
}

export const marker32: Model32<number> = make32(32);
