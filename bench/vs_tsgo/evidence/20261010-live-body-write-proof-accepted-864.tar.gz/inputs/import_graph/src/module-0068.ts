import { Model67, make67 } from "./module-0067";

export interface Model68<T> {
  readonly current: T;
  readonly previous: Model67<T>;
}

export function make68<T>(value: T): Model68<T> {
  return { current: value, previous: make67(value) };
}

export const marker68: Model68<number> = make68(68);
