import { Model88, make88 } from "./module-0088";

export interface Model89<T> {
  readonly current: T;
  readonly previous: Model88<T>;
}

export function make89<T>(value: T): Model89<T> {
  return { current: value, previous: make88(value) };
}

export const marker89: Model89<number> = make89(89);
