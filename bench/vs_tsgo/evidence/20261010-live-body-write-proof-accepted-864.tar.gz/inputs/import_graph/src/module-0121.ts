import { Model120, make120 } from "./module-0120";

export interface Model121<T> {
  readonly current: T;
  readonly previous: Model120<T>;
}

export function make121<T>(value: T): Model121<T> {
  return { current: value, previous: make120(value) };
}

export const marker121: Model121<number> = make121(121);
