import { Model74, make74 } from "./module-0074";

export interface Model75<T> {
  readonly current: T;
  readonly previous: Model74<T>;
}

export function make75<T>(value: T): Model75<T> {
  return { current: value, previous: make74(value) };
}

export const marker75: Model75<number> = make75(75);
