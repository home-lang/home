import { Model36, make36 } from "./module-0036";

export interface Model37<T> {
  readonly current: T;
  readonly previous: Model36<T>;
}

export function make37<T>(value: T): Model37<T> {
  return { current: value, previous: make36(value) };
}

export const marker37: Model37<number> = make37(37);
