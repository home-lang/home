import { Model7, make7 } from "./module-0007";

export interface Model8<T> {
  readonly current: T;
  readonly previous: Model7<T>;
}

export function make8<T>(value: T): Model8<T> {
  return { current: value, previous: make7(value) };
}

export const marker8: Model8<number> = make8(8);
