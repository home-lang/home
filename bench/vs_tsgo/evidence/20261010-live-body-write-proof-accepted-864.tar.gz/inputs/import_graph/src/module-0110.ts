import { Model109, make109 } from "./module-0109";

export interface Model110<T> {
  readonly current: T;
  readonly previous: Model109<T>;
}

export function make110<T>(value: T): Model110<T> {
  return { current: value, previous: make109(value) };
}

export const marker110: Model110<number> = make110(110);
