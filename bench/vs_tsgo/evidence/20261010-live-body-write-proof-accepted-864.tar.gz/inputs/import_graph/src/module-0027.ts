import { Model26, make26 } from "./module-0026";

export interface Model27<T> {
  readonly current: T;
  readonly previous: Model26<T>;
}

export function make27<T>(value: T): Model27<T> {
  return { current: value, previous: make26(value) };
}

export const marker27: Model27<number> = make27(27);
