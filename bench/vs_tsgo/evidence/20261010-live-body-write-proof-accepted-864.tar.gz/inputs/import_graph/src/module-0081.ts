import { Model80, make80 } from "./module-0080";

export interface Model81<T> {
  readonly current: T;
  readonly previous: Model80<T>;
}

export function make81<T>(value: T): Model81<T> {
  return { current: value, previous: make80(value) };
}

export const marker81: Model81<number> = make81(81);
