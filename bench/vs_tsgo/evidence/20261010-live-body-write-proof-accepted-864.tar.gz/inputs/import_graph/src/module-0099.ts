import { Model98, make98 } from "./module-0098";

export interface Model99<T> {
  readonly current: T;
  readonly previous: Model98<T>;
}

export function make99<T>(value: T): Model99<T> {
  return { current: value, previous: make98(value) };
}

export const marker99: Model99<number> = make99(99);
