import { Model45, make45 } from "./module-0045";

export interface Model46<T> {
  readonly current: T;
  readonly previous: Model45<T>;
}

export function make46<T>(value: T): Model46<T> {
  return { current: value, previous: make45(value) };
}

export const marker46: Model46<number> = make46(46);
