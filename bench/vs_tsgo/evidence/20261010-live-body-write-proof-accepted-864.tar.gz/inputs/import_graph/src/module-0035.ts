import { Model34, make34 } from "./module-0034";

export interface Model35<T> {
  readonly current: T;
  readonly previous: Model34<T>;
}

export function make35<T>(value: T): Model35<T> {
  return { current: value, previous: make34(value) };
}

export const marker35: Model35<number> = make35(35);
