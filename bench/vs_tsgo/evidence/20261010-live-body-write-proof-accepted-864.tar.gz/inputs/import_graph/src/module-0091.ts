import { Model90, make90 } from "./module-0090";

export interface Model91<T> {
  readonly current: T;
  readonly previous: Model90<T>;
}

export function make91<T>(value: T): Model91<T> {
  return { current: value, previous: make90(value) };
}

export const marker91: Model91<number> = make91(91);
