import { Model100, make100 } from "./module-0100";

export interface Model101<T> {
  readonly current: T;
  readonly previous: Model100<T>;
}

export function make101<T>(value: T): Model101<T> {
  return { current: value, previous: make100(value) };
}

export const marker101: Model101<number> = make101(101);
