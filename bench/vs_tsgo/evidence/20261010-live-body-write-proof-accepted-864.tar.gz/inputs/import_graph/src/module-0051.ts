import { Model50, make50 } from "./module-0050";

export interface Model51<T> {
  readonly current: T;
  readonly previous: Model50<T>;
}

export function make51<T>(value: T): Model51<T> {
  return { current: value, previous: make50(value) };
}

export const marker51: Model51<number> = make51(51);
