import { Model61, make61 } from "./module-0061";

export interface Model62<T> {
  readonly current: T;
  readonly previous: Model61<T>;
}

export function make62<T>(value: T): Model62<T> {
  return { current: value, previous: make61(value) };
}

export const marker62: Model62<number> = make62(62);
