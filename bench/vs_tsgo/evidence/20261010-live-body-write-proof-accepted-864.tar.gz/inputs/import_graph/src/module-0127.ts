import { Model126, make126 } from "./module-0126";

export interface Model127<T> {
  readonly current: T;
  readonly previous: Model126<T>;
}

export function make127<T>(value: T): Model127<T> {
  return { current: value, previous: make126(value) };
}

export const marker127: Model127<number> = make127(127);
