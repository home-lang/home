import { Model25, make25 } from "./module-0025";

export interface Model26<T> {
  readonly current: T;
  readonly previous: Model25<T>;
}

export function make26<T>(value: T): Model26<T> {
  return { current: value, previous: make25(value) };
}

export const marker26: Model26<number> = make26(26);
