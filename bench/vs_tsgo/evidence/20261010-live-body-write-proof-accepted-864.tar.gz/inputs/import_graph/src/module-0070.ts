import { Model69, make69 } from "./module-0069";

export interface Model70<T> {
  readonly current: T;
  readonly previous: Model69<T>;
}

export function make70<T>(value: T): Model70<T> {
  return { current: value, previous: make69(value) };
}

export const marker70: Model70<number> = make70(70);
