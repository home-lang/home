import { Model68, make68 } from "./module-0068";

export interface Model69<T> {
  readonly current: T;
  readonly previous: Model68<T>;
}

export function make69<T>(value: T): Model69<T> {
  return { current: value, previous: make68(value) };
}

export const marker69: Model69<number> = make69(69);
