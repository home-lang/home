export interface Model0<T> {
  readonly current: T;
}

export function make0<T>(value: T): Model0<T> {
  return { current: value };
}

export const marker0: Model0<number> = make0(0);
