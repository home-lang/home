import { Model42, make42 } from "./module-0042";

export interface Model43<T> {
  readonly current: T;
  readonly previous: Model42<T>;
}

export function make43<T>(value: T): Model43<T> {
  return { current: value, previous: make42(value) };
}

export const marker43: Model43<number> = make43(43);
