import { Model57, make57 } from "./module-0057";

export interface Model58<T> {
  readonly current: T;
  readonly previous: Model57<T>;
}

export function make58<T>(value: T): Model58<T> {
  return { current: value, previous: make57(value) };
}

export const marker58: Model58<number> = make58(58);
