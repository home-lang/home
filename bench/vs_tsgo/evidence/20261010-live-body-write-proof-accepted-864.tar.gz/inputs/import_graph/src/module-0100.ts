import { Model99, make99 } from "./module-0099";

export interface Model100<T> {
  readonly current: T;
  readonly previous: Model99<T>;
}

export function make100<T>(value: T): Model100<T> {
  return { current: value, previous: make99(value) };
}

export const marker100: Model100<number> = make100(100);
