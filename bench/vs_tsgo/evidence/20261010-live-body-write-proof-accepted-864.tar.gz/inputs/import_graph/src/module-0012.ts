import { Model11, make11 } from "./module-0011";

export interface Model12<T> {
  readonly current: T;
  readonly previous: Model11<T>;
}

export function make12<T>(value: T): Model12<T> {
  return { current: value, previous: make11(value) };
}

export const marker12: Model12<number> = make12(12);
