#!/usr/bin/env python3
"""Reproducible frontend benchmarks for tsc, tsgo, and home-tsc."""

from __future__ import annotations

import argparse
import datetime as dt
import gzip
import hashlib
import io
import json
import os
import platform
import re
import shlex
import shutil
import subprocess
import sys
import tarfile
import tempfile
from pathlib import Path

import compare
import competitors

try:
    import tomllib
except ModuleNotFoundError:  # Python 3.10 and older
    tomllib = None

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
CORPUS = HERE / "corpus"
TOOLS = HERE / ".tools"
TSC_TOOLS = TOOLS / "tsc"
TSGO_TOOLS = TOOLS / "tsgo"
RESULTS = HERE / "results"
EVIDENCE = HERE / "evidence"
MANIFEST = HERE / "corpus.toml"


def run(command: list[str], *, cwd: Path | None = None, check: bool = True) -> subprocess.CompletedProcess[str]:
    print("+", " ".join(command), flush=True)
    return subprocess.run(command, cwd=cwd, check=check, text=True)


def manifest() -> dict:
    if tomllib is not None:
        with MANIFEST.open("rb") as handle:
            return tomllib.load(handle)

    # The benchmark manifest intentionally uses only tables and scalar values,
    # so older system Pythons do not need a third-party TOML dependency.
    result: dict = {}
    current = result
    for raw_line in MANIFEST.read_text(encoding="utf-8").splitlines():
        line = raw_line.split("#", 1)[0].strip()
        if not line:
            continue
        if line.startswith("[") and line.endswith("]"):
            current = result
            for part in line[1:-1].split("."):
                current = current.setdefault(part, {})
            continue
        key, raw_value = (part.strip() for part in line.split("=", 1))
        if raw_value.startswith('"'):
            current[key] = json.loads(raw_value)
        else:
            current[key] = int(raw_value)
    return result


def write(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def sysctl_value(name: str) -> str | None:
    try:
        result = subprocess.run(
            ["sysctl", "-n", name],
            check=False,
            capture_output=True,
            text=True,
        )
    except OSError:
        return None
    value = result.stdout.strip() if result.returncode == 0 else ""
    return value or None


def cpu_model() -> str:
    if platform.system() == "Darwin":
        return sysctl_value("machdep.cpu.brand_string") or platform.processor() or platform.machine()
    if platform.system() == "Linux":
        try:
            for line in Path("/proc/cpuinfo").read_text(encoding="utf-8").splitlines():
                key, separator, value = line.partition(":")
                if separator and key.strip() in {"model name", "Hardware"} and value.strip():
                    return value.strip()
        except OSError:
            pass
    return platform.processor() or platform.machine()


def host_metadata() -> dict[str, object]:
    logical_cores = os.cpu_count()
    if type(logical_cores) is not int or logical_cores < 1:
        raise SystemExit("cannot determine benchmark host logical core count")
    host: dict[str, object] = {
        "os": platform.system(),
        "os_release": platform.release(),
        "architecture": platform.machine(),
        "cpu_model": cpu_model(),
        "logical_cores": logical_cores,
    }
    if platform.system() == "Darwin":
        if machine_model := sysctl_value("hw.model"):
            host["machine_model"] = machine_model
    return host


def shared_config(*, jsx: bool = False, check_js: bool = False) -> str:
    compiler_options: dict[str, object] = {
        "strict": True,
        "noEmit": True,
        "noLib": True,
        "skipLibCheck": True,
        "pretty": False,
    }
    if jsx:
        compiler_options["jsx"] = "preserve"
    if check_js:
        compiler_options["allowJs"] = True
        compiler_options["checkJs"] = True
    if jsx:
        include = ["src/**/*.ts", "src/**/*.tsx"]
    elif check_js:
        include = ["src/**/*.js", "src/**/*.d.ts"]
    else:
        include = ["src/**/*.ts"]
    return json.dumps(
        {
            "compilerOptions": compiler_options,
            "include": include,
        },
        indent=2,
    ) + "\n"


def generate_minimal_lib(directory: Path) -> None:
    write(
        directory / "src/lib.d.ts",
        "interface Object {}\n"
        "interface Function {}\n"
        "interface CallableFunction extends Function {}\n"
        "interface NewableFunction extends Function {}\n"
        "interface IArguments { readonly length: number; [index: number]: unknown; }\n"
        "interface String {}\n"
        "interface Number {}\n"
        "interface Boolean {}\n"
        "interface RegExp {}\n"
        "interface Array<T> { readonly length: number; [index: number]: T; }\n"
        "interface ReadonlyArray<T> { readonly length: number; readonly [index: number]: T; }\n",
    )


def generate_startup(directory: Path) -> None:
    write(directory / "tsconfig.json", shared_config())
    generate_minimal_lib(directory)
    write(
        directory / "src/index.ts",
        "type Pair<T> = readonly [T, T];\n"
        "const pair: Pair<number> = [1, 2];\n"
        "export const total: number = pair[0] + pair[1];\n",
    )


def many_file_source(index: int) -> str:
    return f"""export interface Entity{index}<T> {{
  readonly id: number;
  readonly value: T;
  map<U>(fn: (value: T) => U): Entity{index}<U>;
}}

export type Result{index}<T, E = string> =
  | {{ readonly ok: true; readonly value: T }}
  | {{ readonly ok: false; readonly error: E }};

export type Unwrap{index}<T> = T extends Result{index}<infer U, unknown> ? U : never;

export function transform{index}<T, U>(
  input: Entity{index}<T>,
  fn: (value: T) => U,
): Result{index}<Entity{index}<U>> {{
  return {{ ok: true, value: input.map(fn) }};
}}

export const marker{index}: Result{index}<number> = {{ ok: true, value: {index} }};
"""


def generate_many_files(directory: Path, files: int) -> None:
    write(directory / "tsconfig.json", shared_config())
    generate_minimal_lib(directory)
    for index in range(files):
        write(directory / f"src/entity-{index:04d}.ts", many_file_source(index))


def generate_deep_types(directory: Path, repetitions: int) -> None:
    write(directory / "tsconfig.json", shared_config())
    generate_minimal_lib(directory)
    blocks = [
        "type Primitive = string | number | boolean | bigint | symbol | null | undefined;\n",
        "type DeepReadonly<T> = T extends Primitive ? T : T extends readonly (infer U)[] ? readonly DeepReadonly<U>[] : { readonly [K in keyof T]: DeepReadonly<T[K]> };\n",
        "type Paths<T> = T extends object ? { [K in keyof T & string]: K | `${K}.${Paths<T[K]> & string}` }[keyof T & string] : never;\n",
    ]
    for index in range(repetitions):
        blocks.append(
            f"interface Model{index}<T> {{ id: number; payload: T; nested: {{ left: T; right: readonly T[] }}; }}\n"
            f"type ReadonlyModel{index} = DeepReadonly<Model{index}<{{ name: string; score: number }}>>;\n"
            f"type ModelPaths{index} = Paths<Model{index}<{{ name: string; score: number }}>>;\n"
            f"const path{index}: ModelPaths{index} = \"nested.left.name\";\n"
        )
    write(directory / "src/deep-types.ts", "".join(blocks))


def import_graph_source(index: int) -> str:
    if index == 0:
        return """export interface Model0<T> {
  readonly current: T;
}

export function make0<T>(value: T): Model0<T> {
  return { current: value };
}

export const marker0: Model0<number> = make0(0);
"""

    previous = index - 1
    return f"""import {{ Model{previous}, make{previous} }} from "./module-{previous:04d}";

export interface Model{index}<T> {{
  readonly current: T;
  readonly previous: Model{previous}<T>;
}}

export function make{index}<T>(value: T): Model{index}<T> {{
  return {{ current: value, previous: make{previous}(value) }};
}}

export const marker{index}: Model{index}<number> = make{index}({index});
"""


def generate_import_graph(directory: Path, modules: int) -> None:
    write(directory / "tsconfig.json", shared_config())
    generate_minimal_lib(directory)
    for index in range(modules):
        write(directory / f"src/module-{index:04d}.ts", import_graph_source(index))
    last = modules - 1
    write(
        directory / "src/index.ts",
        f'import {{ Model{last}, make{last} }} from "./module-{last:04d}";\n'
        f"export const result: Model{last}<string> = make{last}(\"home\");\n",
    )


def reexport_leaf_source(index: int) -> str:
    return f"""export interface Item{index}<T> {{
  readonly id: number;
  readonly value: T;
}}

export function create{index}<T>(value: T): Item{index}<T> {{
  return {{ id: {index}, value }};
}}
"""


def generate_reexport_graph(directory: Path, leaves: int, barrel_size: int) -> None:
    if leaves % barrel_size != 0:
        raise ValueError("reexport graph leaves must be divisible by barrel size")
    write(directory / "tsconfig.json", shared_config())
    generate_minimal_lib(directory)
    for index in range(leaves):
        write(directory / f"src/leaf-{index:04d}.ts", reexport_leaf_source(index))

    index_lines: list[str] = []
    barrel_count = leaves // barrel_size
    for barrel in range(barrel_count):
        first = barrel * barrel_size
        exports = [
            f'export * from "./leaf-{leaf:04d}";\n'
            for leaf in range(first, first + barrel_size)
        ]
        write(directory / f"src/barrel-{barrel:02d}.ts", "".join(exports))
        index_lines.append(
            f'import {{ Item{first}, create{first} }} from "./barrel-{barrel:02d}";\n'
            f"const value{barrel}: Item{first}<number> = create{first}({first});\n"
        )
    values = ", ".join(f"value{barrel}.value" for barrel in range(barrel_count))
    index_lines.append(f"export const values = [{values}] as const;\n")
    write(directory / "src/index.ts", "".join(index_lines))


def generate_tsx_components(directory: Path, components: int) -> None:
    write(directory / "tsconfig.json", shared_config(jsx=True))
    generate_minimal_lib(directory)
    blocks = [
        "declare global {\n"
        "  namespace JSX {\n"
        "    interface Element { readonly kind: string; }\n"
        "    interface IntrinsicElements {\n"
        "      article: { readonly id?: string; readonly children?: unknown };\n"
        "      h2: { readonly children?: unknown };\n"
        "      span: { readonly children?: unknown };\n"
        "    }\n"
        "  }\n"
        "}\n\n"
        "interface CardProps<T> {\n"
        "  readonly label: string;\n"
        "  readonly value: T;\n"
        "  readonly active: boolean;\n"
        "}\n\n"
    ]
    for index in range(components):
        blocks.append(
            f"export function Card{index}(props: CardProps<number>): JSX.Element {{\n"
            "  return (\n"
            f'    <article id="card-{index}">\n'
            "      <h2>{props.label}</h2>\n"
            "      <span>{props.active ? props.value : 0}</span>\n"
            "    </article>\n"
            "  );\n"
            "}\n\n"
            f'export const card{index}: JSX.Element = <Card{index} label="Card {index}" value={{{index}}} active={{{index} % 2 == 0}} />;\n\n'
        )
    write(directory / "src/components.tsx", "".join(blocks))


def generate_generic_calls(directory: Path, calls: int) -> None:
    write(directory / "tsconfig.json", shared_config())
    generate_minimal_lib(directory)
    blocks = [
        "interface Entity<N extends number> {\n"
        "  readonly id: N;\n"
        "  readonly label: `entity-${N}`;\n"
        "  readonly active: boolean;\n"
        "}\n\n"
        "type PickFields<T, K extends keyof T> = { readonly [P in K]: T[P] };\n\n"
        "declare function project<T, K extends readonly (keyof T)[]>(\n"
        "  value: T,\n"
        "  keys: K,\n"
        "): PickFields<T, K[number]>;\n\n"
        "declare function field<T, K extends keyof T>(value: T, key: K): T[K];\n\n"
        "declare function transform<T, U>(value: T, mapper: (input: T) => U): U;\n\n"
    ]
    for index in range(calls):
        active = "true" if index % 2 == 0 else "false"
        blocks.append(
            f"const entity{index}: Entity<{index}> = {{ id: {index}, label: \"entity-{index}\", active: {active} }};\n"
            f'const selected{index} = project(entity{index}, ["id", "label"] as const);\n'
            f'const label{index}: `entity-{index}` = field(selected{index}, "label");\n'
            f"export const result{index}: PickFields<Entity<{index}>, \"id\" | \"label\"> = transform(\n"
            f"  selected{index},\n"
            "  value => ({ id: value.id, label: value.label }),\n"
            ");\n\n"
        )
    write(directory / "src/generic-calls.ts", "".join(blocks))


def generate_control_flow(directory: Path, functions: int) -> None:
    write(directory / "tsconfig.json", shared_config())
    generate_minimal_lib(directory)
    blocks = [
        "type WorkflowEvent<N extends number> =\n"
        "  | { readonly kind: \"queued\"; readonly id: N }\n"
        "  | { readonly kind: \"running\"; readonly id: N; readonly progress: number }\n"
        "  | { readonly kind: \"complete\"; readonly id: N; readonly output: { readonly label: string; readonly score: number } }\n"
        "  | { readonly kind: \"failed\"; readonly id: N; readonly error: { readonly message: string; readonly retryable: boolean } };\n\n"
        "interface Summary<N extends number> {\n"
        "  readonly id: N;\n"
        "  readonly label: string;\n"
        "  readonly score: number;\n"
        "  readonly terminal: boolean;\n"
        "}\n\n"
    ]
    for index in range(functions):
        blocks.append(
            f"export function summarize{index}(event: WorkflowEvent<{index}>): Summary<{index}> {{\n"
            "  let label: string;\n"
            "  let score: number;\n"
            "  let terminal: boolean;\n"
            "  switch (event.kind) {\n"
            "    case \"queued\":\n"
            "      label = \"queued\";\n"
            "      score = 0;\n"
            "      terminal = false;\n"
            "      break;\n"
            "    case \"running\":\n"
            "      label = \"running\";\n"
            "      score = event.progress;\n"
            "      terminal = false;\n"
            "      break;\n"
            "    case \"complete\":\n"
            "      label = event.output.label;\n"
            "      score = event.output.score;\n"
            "      terminal = true;\n"
            "      break;\n"
            "    case \"failed\":\n"
            "      label = event.error.message;\n"
            "      score = event.error.retryable ? 1 : 0;\n"
            "      terminal = true;\n"
            "      break;\n"
            "    default: {\n"
            "      const exhaustive: never = event;\n"
            "      return exhaustive;\n"
            "    }\n"
            "  }\n"
            "  return { id: event.id, label, score, terminal };\n"
            "}\n\n"
            f"export const summary{index}: Summary<{index}> = summarize{index}({{\n"
            f"  kind: \"complete\", id: {index}, output: {{ label: \"item-{index}\", score: {index} }},\n"
            "});\n\n"
        )
    write(directory / "src/control-flow.ts", "".join(blocks))


def generate_type_predicates(directory: Path, families: int) -> None:
    write(directory / "tsconfig.json", shared_config())
    generate_minimal_lib(directory)
    blocks: list[str] = []
    for index in range(families):
        active = "true" if index % 2 == 0 else "false"
        blocks.append(
            f"interface Ready{index} {{\n"
            '  readonly kind: "ready";\n'
            f"  readonly id: {index};\n"
            "  readonly payload: { readonly label: string; readonly score: number };\n"
            "  readonly meta: { readonly active: boolean };\n"
            "}\n\n"
            f"interface Pending{index} {{\n"
            '  readonly kind: "pending";\n'
            f"  readonly id: {index};\n"
            "  readonly progress: number;\n"
            "}\n\n"
            f"interface Failed{index} {{\n"
            '  readonly kind: "failed";\n'
            f"  readonly id: {index};\n"
            "  readonly error: { readonly message: string; readonly retryable: boolean };\n"
            "}\n\n"
            f"type Input{index} = Ready{index} | Pending{index} | Failed{index};\n\n"
            f"function isReady{index}(value: Input{index}): value is Ready{index} {{\n"
            '  return value.kind === "ready";\n'
            "}\n\n"
            f"function assertReady{index}(value: Input{index}): asserts value is Ready{index} {{\n"
            f"  if (!isReady{index}(value)) throw value;\n"
            "}\n\n"
            f"function summarize{index}(value: Input{index}): readonly [{index}, string, number, boolean] {{\n"
            f"  if (isReady{index}(value)) {{\n"
            "    return [value.id, value.payload.label, value.payload.score, value.meta.active];\n"
            "  }\n"
            f'  return [value.id, value.kind, 0, false];\n'
            "}\n\n"
            f"function requireReady{index}(value: Input{index}): Ready{index} {{\n"
            f"  assertReady{index}(value);\n"
            "  return value;\n"
            "}\n\n"
            f"const candidate{index}: Input{index} = {{\n"
            f'  kind: "ready", id: {index},\n'
            f'  payload: {{ label: "item-{index}", score: {index} }},\n'
            f"  meta: {{ active: {active} }},\n"
            "};\n"
            f"const summary{index} = summarize{index}(candidate{index});\n"
            f"const required{index}: Ready{index} = requireReady{index}(candidate{index});\n"
            f"export const predicateResult{index}: readonly [{index}, string, number, boolean, string] = [\n"
            f"  summary{index}[0], summary{index}[1], summary{index}[2], summary{index}[3], required{index}.payload.label,\n"
            "];\n\n"
        )
    write(directory / "src/type-predicates.ts", "".join(blocks))


def generate_null_safe_access(directory: Path, families: int) -> None:
    write(directory / "tsconfig.json", shared_config())
    generate_minimal_lib(directory)
    blocks: list[str] = []
    for index in range(families):
        metric_index = index % 2
        blocks.append(
            f"interface NullableRecord{index} {{\n"
            f"  readonly id: {index};\n"
            "  readonly fallback: string;\n"
            "  readonly profile?: {\n"
            "    readonly label?: string;\n"
            "    readonly metrics?: readonly [number, number];\n"
            "    readonly format?: (prefix: string) => string;\n"
            "  };\n"
            "}\n\n"
            f"function readNullable{index}(\n"
            f"  value: NullableRecord{index} | null | undefined,\n"
            "): readonly [number, string, number, string, string] {\n"
            f'  const label = value?.profile?.label ?? value?.fallback ?? "missing-{index}";\n'
            f"  const score = value?.profile?.metrics?.[{metric_index}] ?? 0;\n"
            "  const formatted = value?.profile?.format?.(label) ?? label;\n"
            "  const fallback = value!.fallback;\n"
            f"  return [value?.id ?? {index}, label, score, formatted, fallback];\n"
            "}\n\n"
            f"const nullableInput{index}: NullableRecord{index} = {{\n"
            f"  id: {index},\n"
            f'  fallback: "fallback-{index}",\n'
            "  profile: {\n"
            f'    label: "item-{index}",\n'
            f"    metrics: [{index}, {index + 1}],\n"
            "    format: (prefix) => prefix,\n"
            "  },\n"
            "};\n"
            f"export const nullSafeResult{index}: readonly [number, string, number, string, string] =\n"
            f"  readNullable{index}(nullableInput{index});\n\n"
        )
    write(directory / "src/null-safe-access.ts", "".join(blocks))


def generate_destructuring(directory: Path, families: int) -> None:
    write(directory / "tsconfig.json", shared_config())
    generate_minimal_lib(directory)
    blocks: list[str] = []
    for index in range(families):
        active = "  active: false,\n" if index % 2 else ""
        blocks.append(f"""interface BindingRecord{index} {{
  readonly id: number;
  readonly meta: {{ readonly label: string; readonly score: number }};
  readonly slots: readonly [number, string];
  readonly active?: boolean;
}}

interface BindingProjection{index} {{
  readonly id: number;
  readonly active: boolean;
  readonly label: string;
  readonly score: number;
  readonly first: number;
  readonly second: string;
}}

function projectBindings{index}(input: BindingRecord{index}): BindingProjection{index} {{
  const {{ meta: {{ label, score }}, slots: [first, second], active = true, ...identity }} = input;
  const spread = {{ ...identity, active, label, score, first, second }};
  return spread;
}}

export const destructured{index}: BindingProjection{index} = projectBindings{index}({{
  id: {index},
  meta: {{ label: "item-{index}", score: {index} }},
  slots: [{index}, "slot-{index}"],
{active}}});
export const consumedBindings{index}: readonly [number, string, boolean] = [
  destructured{index}.id, destructured{index}.second, destructured{index}.active,
];

""")
    write(directory / "src/destructuring.ts", "".join(blocks))


def generate_overload_resolution(directory: Path, groups: int) -> None:
    write(directory / "tsconfig.json", shared_config())
    generate_minimal_lib(directory)
    blocks = [
        "interface RouteResult<K extends string, N extends number, V> {\n"
        "  readonly kind: K;\n"
        "  readonly id: N;\n"
        "  readonly value: V;\n"
        "}\n\n"
        "declare function route<N extends number>(kind: \"text\", id: N, payload: string): RouteResult<\"text\", N, string>;\n"
        "declare function route<N extends number>(kind: \"count\", id: N, payload: number): RouteResult<\"count\", N, number>;\n"
        "declare function route<N extends number>(kind: \"flag\", id: N, payload: boolean): RouteResult<\"flag\", N, boolean>;\n"
        "declare function route<N extends number>(kind: \"point\", id: N, payload: { readonly x: number; readonly y: number }): RouteResult<\"point\", N, { readonly x: number; readonly y: number }>;\n"
        "declare function route<N extends number>(kind: \"pair\", id: N, payload: readonly [string, number]): RouteResult<\"pair\", N, readonly [string, number]>;\n"
        "declare function route<N extends number>(kind: \"record\", id: N, payload: { readonly label: string; readonly active: boolean }): RouteResult<\"record\", N, { readonly label: string; readonly active: boolean }>;\n"
        "declare function route<N extends number>(kind: \"callback\", id: N, payload: (value: number) => string): RouteResult<\"callback\", N, (value: number) => string>;\n"
        "declare function route<N extends number>(kind: \"nested\", id: N, payload: { readonly meta: { readonly id: number } }): RouteResult<\"nested\", N, { readonly meta: { readonly id: number } }>;\n\n"
    ]
    for index in range(groups):
        active = "true" if index % 2 == 0 else "false"
        blocks.append(
            f'const text{index}: RouteResult<"text", {index}, string> = route("text", {index}, "item-{index}");\n'
            f'const count{index}: RouteResult<"count", {index}, number> = route("count", {index}, {index});\n'
            f'const flag{index}: RouteResult<"flag", {index}, boolean> = route("flag", {index}, {active});\n'
            f'const point{index}: RouteResult<"point", {index}, {{ readonly x: number; readonly y: number }}> = route("point", {index}, {{ x: {index}, y: {index + 1} }});\n'
            f'const pair{index}: RouteResult<"pair", {index}, readonly [string, number]> = route("pair", {index}, ["item-{index}", {index}] as const);\n'
            f'const record{index}: RouteResult<"record", {index}, {{ readonly label: string; readonly active: boolean }}> = route("record", {index}, {{ label: "item-{index}", active: {active} }});\n'
            f'const callback{index}: RouteResult<"callback", {index}, (value: number) => string> = route("callback", {index}, (value: number) => `item-{index}-${{value}}`);\n'
            f'const nested{index}: RouteResult<"nested", {index}, {{ readonly meta: {{ readonly id: number }} }}> = route("nested", {index}, {{ meta: {{ id: {index} }} }});\n'
            f"export const overloadResult{index}: readonly [{index}, string, number, boolean, number, string, string, number] = [\n"
            f"  text{index}.id, text{index}.value, count{index}.value, flag{index}.value, point{index}.value.x,\n"
            f"  pair{index}.value[0], callback{index}.value({index}), nested{index}.value.meta.id,\n"
            "];\n\n"
        )
    write(directory / "src/overload-resolution.ts", "".join(blocks))


def generate_class_hierarchy(directory: Path, families: int) -> None:
    write(directory / "tsconfig.json", shared_config())
    generate_minimal_lib(directory)
    blocks: list[str] = []
    for index in range(families):
        blocks.append(
            f"interface View{index}<N extends number> {{\n"
            "  readonly id: N;\n"
            "  readonly label: string;\n"
            "  describe(prefix: string): string;\n"
            "}\n\n"
            f"class Base{index}<T, N extends number> {{\n"
            "  constructor(public readonly id: N, protected readonly value: T) {}\n"
            "  getValue(): T { return this.value; }\n"
            "  describe(prefix: string): string { return prefix; }\n"
            "}\n\n"
            f"class Derived{index} extends Base{index}<{{ readonly label: string; readonly score: number }}, {index}> implements View{index}<{index}> {{\n"
            "  readonly label: string;\n"
            "  constructor(label: string, score: number) {\n"
            f"    super({index}, {{ label, score }});\n"
            "    this.label = label;\n"
            "  }\n"
            "  override getValue(): { readonly label: string; readonly score: number } {\n"
            "    return super.getValue();\n"
            "  }\n"
            "  override describe(prefix: string): string {\n"
            "    return `${prefix}:${this.label}`;\n"
            "  }\n"
            "  score(): number { return this.getValue().score; }\n"
            "}\n\n"
            f'const instance{index}: Derived{index} = new Derived{index}("item-{index}", {index});\n'
            f"const view{index}: View{index}<{index}> = instance{index};\n"
            f"export const classResult{index}: readonly [{index}, string, number, string] = [\n"
            f'  view{index}.id, view{index}.label, instance{index}.score(), view{index}.describe("class"),\n'
            "];\n\n"
        )
    write(directory / "src/class-hierarchy.ts", "".join(blocks))


def generate_structural_objects(directory: Path, families: int) -> None:
    write(directory / "tsconfig.json", shared_config())
    generate_minimal_lib(directory)
    blocks: list[str] = []
    for index in range(families):
        active = "true" if index % 2 == 0 else "false"
        blocks.append(
            f"interface Target{index}<N extends number> {{\n"
            "  readonly id: N;\n"
            "  readonly nested: {\n"
            "    readonly label: string;\n"
            "    readonly optional?: { readonly active: boolean };\n"
            "  };\n"
            "  readonly pair: readonly [string, number];\n"
            "  readonly flags: { readonly enabled: boolean } & { readonly visible: boolean };\n"
            "  transform: <T extends { readonly value: number }>(input: T) => { readonly id: N; readonly input: T };\n"
            "}\n\n"
            f"type Source{index} = {{\n"
            f"  readonly id: {index};\n"
            "  readonly nested: {\n"
            "    readonly label: string;\n"
            "    readonly optional: { readonly active: boolean };\n"
            "    readonly extra: number;\n"
            "  };\n"
            "  readonly pair: readonly [string, number];\n"
            "  readonly flags: { readonly enabled: boolean; readonly visible: boolean; readonly extra: string };\n"
            f"  transform: <T extends {{ readonly value: number }}>(input: T) => {{ readonly id: {index}; readonly input: T; readonly extra: boolean }};\n"
            "  readonly extra: string;\n"
            "};\n\n"
            f"function transform{index}<T extends {{ readonly value: number }}>(input: T): {{ readonly id: {index}; readonly input: T; readonly extra: boolean }} {{\n"
            f"  return {{ id: {index}, input, extra: true }};\n"
            "}\n\n"
            f"const source{index}: Source{index} = {{\n"
            f"  id: {index},\n"
            f'  nested: {{ label: "item-{index}", optional: {{ active: {active} }}, extra: {index} }},\n'
            f'  pair: ["item-{index}", {index}],\n'
            f'  flags: {{ enabled: {active}, visible: true, extra: "flag-{index}" }},\n'
            f"  transform: transform{index},\n"
            f'  extra: "source-{index}",\n'
            "};\n\n"
            f"const target{index}: Target{index}<{index}> = source{index};\n"
            f"function consume{index}(value: Target{index}<{index}>): readonly [{index}, string, number, boolean, number] {{\n"
            f"  const transformed = value.transform({{ value: {index}, label: \"value-{index}\" }});\n"
            "  return [value.id, value.nested.label, value.pair[1], value.flags.visible, transformed.input.value];\n"
            "}\n"
            f"export const structuralResult{index}: readonly [{index}, string, number, boolean, number] = consume{index}(source{index});\n\n"
        )
    write(directory / "src/structural-objects.ts", "".join(blocks))


def generate_interface_composition(directory: Path, families: int) -> None:
    write(directory / "tsconfig.json", shared_config())
    generate_minimal_lib(directory)
    blocks: list[str] = []
    for index in range(families):
        active = "true" if index % 2 == 0 else "false"
        blocks.append(
            f"interface Identity{index}<N extends number> {{\n"
            "  readonly id: N;\n"
            "}\n\n"
            f"interface Payload{index}<T> {{\n"
            "  readonly payload: T;\n"
            "}\n\n"
            f"interface Composite{index}<T, N extends number> extends Identity{index}<N>, Payload{index}<T> {{\n"
            "  readonly label: string;\n"
            "}\n\n"
            f"interface Composite{index}<T, N extends number> {{\n"
            "  readonly meta: { readonly active: boolean; readonly tags: readonly [string, number] };\n"
            "  summarize(prefix: string): string;\n"
            "}\n\n"
            f"namespace Composite{index} {{\n"
            "  export interface Snapshot<N extends number> {\n"
            "    readonly id: N;\n"
            "    readonly summary: string;\n"
            "  }\n"
            "  export function snapshot<N extends number>(\n"
            "    value: { readonly id: N; summarize(prefix: string): string },\n"
            "  ): Snapshot<N> {\n"
            '    return { id: value.id, summary: value.summarize("merged") };\n'
            "  }\n"
            "}\n\n"
            f"const composite{index}: Composite{index}<{{ readonly value: number; readonly name: string }}, {index}> = {{\n"
            f"  id: {index},\n"
            f'  payload: {{ value: {index}, name: "item-{index}" }},\n'
            f'  label: "composite-{index}",\n'
            f'  meta: {{ active: {active}, tags: ["tag-{index}", {index}] }},\n'
            "  summarize(prefix: string): string { return `${prefix}:${this.label}`; },\n"
            "};\n\n"
            f"const snapshot{index}: Composite{index}.Snapshot<{index}> = Composite{index}.snapshot(composite{index});\n"
            f"function consumeComposite{index}(value: Composite{index}<{{ readonly value: number; readonly name: string }}, {index}>): readonly [{index}, string, number, boolean, string] {{\n"
            "  return [value.id, value.label, value.payload.value, value.meta.active, value.summarize(\"consume\")];\n"
            "}\n"
            f"export const interfaceResult{index}: readonly [{index}, string, number, boolean, string, string] = [\n"
            f"  ...consumeComposite{index}(composite{index}), snapshot{index}.summary,\n"
            "];\n\n"
        )
    write(directory / "src/interface-composition.ts", "".join(blocks))


def generate_variadic_tuples(directory: Path, families: int) -> None:
    write(directory / "tsconfig.json", shared_config())
    generate_minimal_lib(directory)
    blocks = [
        "type Head<T extends readonly unknown[]> = "
        "T extends readonly [infer H, ...readonly unknown[]] ? H : never;\n"
        "type Tail<T extends readonly unknown[]> = "
        "T extends readonly [unknown, ...infer R] ? readonly [...R] : readonly [];\n\n"
        "declare function concat<A extends readonly unknown[], B extends readonly unknown[]>(\n"
        "  left: A,\n"
        "  right: B,\n"
        "): readonly [...A, ...B];\n\n"
        "declare function capture<T extends readonly unknown[]>(...values: T): T;\n\n"
    ]
    for index in range(families):
        active = "true" if index % 2 == 0 else "false"
        blocks.append(
            f'const left{index} = [{index}, "item-{index}", {{ value: {index} }}] as const;\n'
            f'const right{index} = [{active}, [{index}, "tail-{index}"] as const] as const;\n'
            f"const combined{index} = concat(left{index}, right{index});\n"
            f"type Tuple{index} = readonly [\n"
            f"  {index},\n"
            f'  "item-{index}",\n'
            f"  {{ readonly value: {index} }},\n"
            f"  {active},\n"
            f'  readonly [{index}, "tail-{index}"],\n'
            "];\n"
            f"const checked{index}: Tuple{index} = combined{index};\n"
            f"const head{index}: Head<Tuple{index}> = {index};\n"
            f"const tail{index}: Tail<Tuple{index}> = [\n"
            f'  "item-{index}", {{ value: {index} }}, {active}, [{index}, "tail-{index}"],\n'
            "];\n"
            f"const captured{index} = capture(...checked{index});\n"
            f"function consumeTuple{index}(value: Tuple{index}): readonly [{index}, \"item-{index}\", {active}, number] {{\n"
            "  return [value[0], value[1], value[3], value.length];\n"
            "}\n"
            f"export const tupleResult{index} = {{\n"
            f"  head: head{index}, tail: tail{index}, result: consumeTuple{index}(captured{index}),\n"
            "};\n\n"
        )
    write(directory / "src/variadic-tuples.ts", "".join(blocks))


def generate_checkjs_jsdoc(directory: Path, families: int) -> None:
    write(directory / "tsconfig.json", shared_config(check_js=True))
    generate_minimal_lib(directory)
    blocks = ["// @ts-check\n\n"]
    for index in range(families):
        active = "true" if index % 2 == 0 else "false"
        blocks.append(
            "/**\n"
            f" * @typedef {{object}} Model{index}\n"
            " * @property {number} id\n"
            " * @property {string} name\n"
            " * @property {{ active: boolean, label: string }} meta\n"
            " */\n\n"
            "/**\n"
            " * @template T\n"
            f" * @typedef {{object}} Box{index}\n"
            " * @property {T} value\n"
            " * @property {string} label\n"
            " */\n\n"
            "/**\n"
            f" * @callback Project{index}\n"
            f" * @param {{Model{index}}} input\n"
            " * @returns {string}\n"
            " */\n\n"
            "/**\n"
            f" * @template {{Model{index}}} T\n"
            " * @param {T} value\n"
            " * @returns {T}\n"
            " */\n"
            f"function preserve{index}(value) {{\n"
            "  return value;\n"
            "}\n\n"
            f"class Store{index} {{\n"
            "  /**\n"
            f"   * @param {{Box{index}<Model{index}>}} box\n"
            "   */\n"
            "  constructor(box) {\n"
            "    this.box = box;\n"
            "  }\n\n"
            "  /**\n"
            f"   * @param {{Project{index}}} project\n"
            "   * @returns {string}\n"
            "   */\n"
            "  read(project) {\n"
            "    return project(this.box.value);\n"
            "  }\n"
            "}\n\n"
            f"/** @type {{Model{index}}} */\n"
            f"const model{index} = {{\n"
            f'  id: {index}, name: "model-{index}", meta: {{ active: {active}, label: "meta-{index}" }},\n'
            "};\n"
            f"const preserved{index} = preserve{index}(model{index});\n"
            f"/** @type {{Box{index}<Model{index}>}} */\n"
            f"const box{index} = {{ value: preserved{index}, label: \"box-{index}\" }};\n"
            f"/** @type {{Project{index}}} */\n"
            f"const project{index} = (input) => `${{input.meta.label}}:${{input.name}}`;\n"
            f"const store{index} = new Store{index}(box{index});\n"
            f"const rendered{index} = store{index}.read(project{index});\n"
            "/** @type {{ id: number, name: string, active: boolean, rendered: string }} */\n"
            f"export const jsdocResult{index} = {{\n"
            f"  id: preserved{index}.id,\n"
            f"  name: preserved{index}.name,\n"
            f"  active: preserved{index}.meta.active,\n"
            f"  rendered: rendered{index},\n"
            "};\n\n"
        )
    write(directory / "src/checkjs-jsdoc.js", "".join(blocks).rstrip() + "\n")


def generate_commonjs_graph(directory: Path, families: int) -> None:
    if families < 1:
        raise ValueError("CommonJS graph workloads require at least one family")
    write(directory / "tsconfig.json", shared_config(check_js=True))
    generate_minimal_lib(directory)
    app: list[str] = []
    for index in range(families):
        suffix = f"{index:04d}"
        active = "true" if index % 2 == 0 else "false"
        write(
            directory / f"src/owner-{suffix}.js",
            f"class Service{index} {{\n"
            f"  id = {index};\n"
            f'  label = "service-{index}";\n'
            f'  meta = {{ active: {active}, score: {index} }};\n'
            "}\n"
            f"class Alternate{index} {{\n"
            f"  id = {index};\n"
            f"  label = {index};\n"
            f'  meta = {{ active: {active}, score: {index} }};\n'
            "}\n"
            f"module.exports = new Service{index}();\n"
            f"module.exports = new Alternate{index}();\n",
        )
        app.append(
            f'const service{index} = require("./owner-{suffix}");\n'
            f"/** @type {{number}} */ const id{index} = service{index}.id;\n"
            f"/** @type {{string | number}} */ const label{index} = service{index}.label;\n"
            f"/** @type {{boolean}} */ const active{index} = service{index}.meta.active;\n"
            f"/** @type {{number}} */ const score{index} = service{index}.meta.score;\n"
        )
    write(directory / "src/index.js", "".join(app))


def generate_recursive_generics(directory: Path, families: int) -> None:
    if families < 1:
        raise ValueError("recursive generic workloads require at least one family")
    write(directory / "tsconfig.json", shared_config())
    generate_minimal_lib(directory)
    write(directory / "src/owner.ts",
          "type Link<T> = { readonly item: T; readonly next: Link<T[]> };\n"
          "export declare class Box<T> { readonly value: Link<T>; }\n")
    blocks = ["import { Box } from './owner';\n"]
    for index in range(families):
        blocks.append(
            f"interface Payload{index} {{ readonly id: number; readonly tag{index}: string; }}\n"
            f"declare const source{index}: Box<Payload{index}>;\n"
            f"const selected{index} = source{index}.value.next.next.next.next.item;\n"
            f"const typed{index}: Payload{index}[][][][] = selected{index};\n"
            f"const leaf{index}: number = selected{index}[0][0][0][0].id;\n"
        )
    write(directory / "src/recursive-generics.ts", "".join(blocks))


def cmd_corpus() -> None:
    cfg = manifest()["generated"]
    shutil.rmtree(CORPUS, ignore_errors=True)
    generate_startup(CORPUS / "startup")
    generate_many_files(CORPUS / "many_files", cfg["many_files_count"])
    generate_deep_types(CORPUS / "deep_types", cfg["deep_types_repetitions"])
    generate_import_graph(CORPUS / "import_graph", cfg["import_graph_modules"])
    generate_reexport_graph(
        CORPUS / "reexport_graph",
        cfg["reexport_graph_leaves"],
        cfg["reexport_graph_barrel_size"],
    )
    generate_tsx_components(CORPUS / "tsx_components", cfg["tsx_components"])
    generate_generic_calls(CORPUS / "generic_calls", cfg["generic_calls"])
    generate_control_flow(CORPUS / "control_flow", cfg["control_flow_functions"])
    generate_type_predicates(
        CORPUS / "type_predicates",
        cfg["type_predicate_families"],
    )
    generate_type_predicates(
        CORPUS / "type_predicates_large",
        cfg["type_predicate_large_families"],
    )
    generate_null_safe_access(
        CORPUS / "null_safe_access",
        cfg["null_safe_access_families"],
    )
    generate_destructuring(CORPUS / "destructuring", cfg["destructuring_families"])
    generate_overload_resolution(CORPUS / "overload_resolution", cfg["overload_call_groups"])
    generate_class_hierarchy(CORPUS / "class_hierarchy", cfg["class_hierarchy_families"])
    generate_structural_objects(CORPUS / "structural_objects", cfg["structural_object_families"])
    generate_interface_composition(
        CORPUS / "interface_composition",
        cfg["interface_composition_families"],
    )
    generate_variadic_tuples(
        CORPUS / "variadic_tuples",
        cfg["variadic_tuple_families"],
    )
    generate_checkjs_jsdoc(
        CORPUS / "checkjs_jsdoc",
        cfg["checkjs_jsdoc_families"],
    )
    generate_commonjs_graph(
        CORPUS / "commonjs_graph",
        cfg["commonjs_graph_families"],
    )
    generate_recursive_generics(CORPUS / "recursive_generics", cfg["recursive_generic_families"])
    print(f"Generated deterministic corpus in {CORPUS}")


def cmd_setup() -> None:
    versions = manifest()["compilers"]
    run(
        [
            "npm",
            "install",
            "--no-save",
            "--no-package-lock",
            "--prefix",
            str(TSC_TOOLS),
            f"typescript@{versions['tsc']['version']}",
        ]
    )
    run(
        [
            "npm",
            "install",
            "--no-save",
            "--no-package-lock",
            "--prefix",
            str(TSGO_TOOLS),
            f"typescript@{versions['tsgo']['version']}",
        ]
    )


def compiler_commands(profiles: dict | None = None) -> dict[str, list[str]]:
    home = Path(os.environ.get("HOME_TSC", ROOT / "zig-out/bin/home-tsc"))
    commands = {
        "tsc": [str(TSC_TOOLS / "node_modules/.bin/tsc")],
        "tsgo": [str(native_tsgo_payload())],
        "home": [str(home)],
    }
    for name, profile in (profiles or {}).items():
        if name in commands:
            raise SystemExit(f"competitor cannot replace a required compiler: {name}")
        commands[name] = list(profile.command)
    missing = [name for name, command in commands.items() if not Path(command[0]).is_file()]
    if missing:
        raise SystemExit(f"missing {', '.join(missing)}; run './run.sh setup' and build home-tsc")
    return commands


def version_output(command: list[str]) -> str:
    result = subprocess.run(command + ["--version"], check=True, capture_output=True, text=True)
    return (result.stdout or result.stderr).strip()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def artifact_provenance(path: Path) -> dict[str, object]:
    requested = path.absolute()
    resolved = path.resolve(strict=True)
    if not resolved.is_file():
        raise SystemExit(f"benchmark artifact is not a file: {resolved}")
    return {
        "path": str(requested),
        "resolved_path": str(resolved),
        "size": resolved.stat().st_size,
        "sha256": sha256_file(resolved),
    }


def native_tsgo_payload() -> Path:
    system = {"Darwin": "darwin", "Linux": "linux", "Windows": "win32"}.get(platform.system())
    machine = platform.machine().lower()
    architecture = {
        "amd64": "x64",
        "x86_64": "x64",
        "aarch64": "arm64",
        "arm64": "arm64",
    }.get(machine)
    if system is None or architecture is None:
        raise SystemExit(f"cannot identify native TS 7 payload for {platform.system()} {platform.machine()}")
    executable = "tsc.exe" if system == "win32" else "tsc"
    return (
        TSGO_TOOLS
        / "node_modules"
        / "@typescript"
        / f"typescript-{system}-{architecture}"
        / "lib"
        / executable
    )


def resolved_tool(name: str) -> Path:
    path = shutil.which(name)
    if path is None:
        raise SystemExit(f"{name} is required for benchmark provenance")
    return Path(path)


def benchmark_provenance(commands: dict[str, list[str]], profiles: dict | None = None) -> dict[str, object]:
    node = resolved_tool("node")
    hyperfine = resolved_tool("hyperfine")
    tsc_payload = TSC_TOOLS / "node_modules" / "typescript" / "lib" / "_tsc.js"
    records: dict[str, object] = {
        "schema": 1,
        "compilers": {
            "tsc": {
                "command": commands["tsc"],
                "launcher": artifact_provenance(Path(commands["tsc"][0])),
                "payload": artifact_provenance(tsc_payload),
            },
            "tsgo": {
                "command": commands["tsgo"],
                "launcher": artifact_provenance(Path(commands["tsgo"][0])),
                "payload": artifact_provenance(native_tsgo_payload()),
            },
            "home": {
                "command": commands["home"],
                "executable": artifact_provenance(Path(commands["home"][0])),
            },
        },
        "tools": {
            "node": {
                "version": version_output([str(node)]),
                "executable": artifact_provenance(node),
            },
            "hyperfine": {
                "version": version_output([str(hyperfine)]),
                "executable": artifact_provenance(hyperfine),
            },
            "python": {
                "version": platform.python_version(),
                "executable": artifact_provenance(Path(sys.executable)),
            },
        },
    }
    for name, profile in (profiles or {}).items():
        if commands.get(name) != list(profile.command):
            raise SystemExit(f"{name} measured command differs from its profile")
        records["compilers"][name] = profile.provenance(artifact_provenance)
    if profiles:
        records["inputs"] = {
            "corpus": competitors.payload_inventory(CORPUS),
            "manifest": artifact_provenance(MANIFEST),
            "harness": [artifact_provenance(HERE / filename) for filename in ("run.py", "compare.py", "competitors.py")],
            "cwd": str(Path.cwd().resolve()),
            "project_context": [artifact_provenance(ROOT / filename) for filename in ("package.json", "bunfig.toml") if (ROOT / filename).is_file()],
        }
    return records


def verified_compiler_versions(commands: dict[str, list[str]], profiles: dict | None = None) -> dict[str, str]:
    profiles = profiles or {}
    versions = {name: version_output(command) for name, command in commands.items() if name not in profiles}
    for name, profile in profiles.items():
        result = subprocess.run(list(profile.version_command), check=True, capture_output=True, text=True)
        if result.stdout and result.stderr:
            raise SystemExit(f"{name} version probe produced conflicting output streams")
        output = (result.stdout or result.stderr).strip()
        if output != profile.expected_version:
            raise SystemExit(f"{name} version mismatch: expected {profile.expected_version!r}, got {output!r}")
        versions[name] = output
    pinned = manifest()["compilers"]
    for name in ("tsc", "tsgo"):
        expected = f"Version {pinned[name]['version']}"
        if versions.get(name) != expected:
            raise SystemExit(
                f"{name} version mismatch: expected {expected!r}, got {versions.get(name)!r}; "
                "run './bench/vs_tsgo/run.sh setup' before benchmarking"
            )
    return versions


def admission_process(name: str, command: list[str], workload: str, *, expected_codes=None,
                      positive_output="silent", trace: list | None = None):
    result = subprocess.run(command, capture_output=True, text=True)
    output = result.stdout + result.stderr
    codes = sorted(re.findall(r"\berror TS(\d+):", output))
    if expected_codes is None:
        passed = result.returncode == 0 and competitors.successful_output(result.stdout, result.stderr, positive_output)
    else:
        passed = result.returncode in (1, 2) and codes == sorted(expected_codes)
    if trace is not None:
        trace.append({"compiler": name, "workload": workload, "kind": "positive" if expected_codes is None else "negative",
                      "command": command, "exit_code": result.returncode, "stdout": result.stdout, "stderr": result.stderr,
                      "positive_output": positive_output, "expected_codes": expected_codes, "codes": codes, "passed": passed})
    return result, passed


def validate(commands: dict[str, list[str]], workload: str, *, profiles: dict | None = None,
             trace: list | None = None) -> None:
    config = CORPUS / workload / "tsconfig.json"
    for name, command in commands.items():
        profile = (profiles or {}).get(name)
        result, passed = admission_process(name, command + ["--noEmit", "-p", str(config)], workload,
                                           positive_output=profile.positive_output if profile else "silent", trace=trace)
        if not passed:
            details = (result.stdout + result.stderr).strip()
            raise SystemExit(f"{name} failed validation for {workload}:\n{details}")
    options = {"trace": trace} if trace is not None else {}
    if workload == "destructuring":
        validate_destructuring_negatives(commands, **options)
    elif workload in ("type_predicates", "type_predicates_large"):
        validate_type_predicate_negatives(commands, workload, **options)
    elif workload in ("import_graph", "reexport_graph"):
        validate_graph_negatives(commands, workload, **options)
    elif workload == "variadic_tuples":
        validate_variadic_tuple_negatives(commands, **options)
    elif workload == "commonjs_graph":
        validate_commonjs_graph_negatives(commands, **options)
    elif workload == "recursive_generics":
        validate_recursive_generic_negatives(commands, **options)
    elif workload == "checkjs_jsdoc":
        validate_checkjs_jsdoc_negatives(commands, **options)
    elif workload == "null_safe_access":
        validate_null_safe_access_negatives(commands, **options)


def validate_null_safe_access_negatives(commands: dict[str, list[str]], *, trace: list | None = None) -> None:
    # Validate the inferred locals inside the timed functions, not just their
    # explicit exported tuple annotations. A checker must preserve optional
    # access/call results, nullish fallbacks, arguments and tuple bounds.
    families = manifest()["generated"]["null_safe_access_families"]
    indices = sorted({0, families // 2, families - 1})
    with tempfile.TemporaryDirectory(prefix="home-bench-nullsafe-") as temporary:
        project = Path(temporary) / "project"
        shutil.copytree(CORPUS / "null_safe_access", project)
        source = project / "src/null-safe-access.ts"
        content = source.read_text(encoding="utf-8")
        for index in indices:
            start = content.index(f"function readNullable{index}(")
            anchor = content.index("  const fallback = value!.fallback;", start)
            invalid = """  const invalidLabel: boolean = label;
  const invalidScore: string = score;
  const invalidFormatted: number = formatted;
  const invalidFallback: number = value!.fallback;
  const invalidOptionalLabel: string = value?.profile?.label;
  const invalidOptionalCall: string = value?.profile?.format?.(label);
  value?.profile?.format?.(123);
  value?.profile?.metrics?.[2];
  value?.profile?.missing;
  void invalidLabel; void invalidScore; void invalidFormatted;
  void invalidFallback; void invalidOptionalLabel; void invalidOptionalCall;
"""
            content = content[:anchor] + invalid + content[anchor:]
        write(source, content)
        expected = ["2322"] * (6 * len(indices)) + ["2339", "2345", "2493"] * len(indices)
        for name, command in commands.items():
            result, passed = admission_process(name, command + ["--noEmit", "-p", str(project / "tsconfig.json")],
                "null_safe_access", expected_codes=expected, trace=trace)
            if not passed:
                raise SystemExit(f"{name} failed null_safe_access negative controls:\n{result.stdout + result.stderr}")


def validate_checkjs_jsdoc_negatives(commands: dict[str, list[str]], *, trace: list | None = None) -> None:
    # Check the actual typedef, generic-preserved, callback and instance results
    # from the timed source. Never admit a checker that erased them to any.
    families = manifest()["generated"]["checkjs_jsdoc_families"]
    indices = sorted({0, families // 2, families - 1})
    invalid = "".join(
        f"/** @type {{boolean}} */ const wrongId{i} = preserved{i}.id;\n"
        f"preserved{i}.missing;\n"
        f"/** @type {{number}} */ const wrongCallback{i} = project{i}(model{i});\n"
        f"store{i}.read(123);\n"
        f"/** @type {{Box{i}<Model{i}>}} */ const wrongBox{i} = {{ value: {{ id: \"wrong\", name: \"x\", meta: {{ active: true, label: \"x\" }} }}, label: \"x\" }};\n"
        for i in indices
    )
    with tempfile.TemporaryDirectory(prefix="home-bench-jsdoc-") as temporary:
        project = Path(temporary) / "project"
        shutil.copytree(CORPUS / "checkjs_jsdoc", project)
        source = project / "src/checkjs-jsdoc.js"
        write(source, source.read_text(encoding="utf-8") + invalid)
        expected = ["2322"] * (3 * len(indices)) + ["2339"] * len(indices) + ["2345"] * len(indices)
        for name, command in commands.items():
            result, passed = admission_process(name, command + ["--noEmit", "-p", str(project / "tsconfig.json")],
                "checkjs_jsdoc", expected_codes=expected, trace=trace)
            if not passed:
                raise SystemExit(f"{name} failed checkjs_jsdoc negative controls:\n{result.stdout + result.stderr}")


def validate_commonjs_graph_negatives(commands: dict[str, list[str]], *, trace: list | None = None) -> None:
    families = manifest()["generated"]["commonjs_graph_families"]
    indices = sorted({0, families // 2, families - 1})
    invalid = "".join(
        f"/** @type {{boolean}} */ const wrongLabel{index} = service{index}.label;\n"
        f"const missing{index} = service{index}.missing;\n"
        for index in indices
    )
    with tempfile.TemporaryDirectory(prefix="home-bench-commonjs-") as temporary:
        project = Path(temporary) / "project"
        shutil.copytree(CORPUS / "commonjs_graph", project)
        source_path = project / "src/index.js"
        write(source_path, source_path.read_text(encoding="utf-8") + invalid)
        for name, command in commands.items():
            expected = ["2322"] * len(indices) + ["2339"] * len(indices)
            result, passed = admission_process(name, command + ["--noEmit", "-p", str(project / "tsconfig.json")],
                                               "commonjs_graph", expected_codes=expected, trace=trace)
            details = result.stdout + result.stderr
            if not passed:
                raise SystemExit(f"{name} failed commonjs_graph negative controls:\n{details}")


def validate_recursive_generic_negatives(commands: dict[str, list[str]], *, trace: list | None = None) -> None:
    families = manifest()["generated"]["recursive_generic_families"]
    indices = sorted({0, families // 2, families - 1})
    invalid = "".join(
        f"const wrongLeaf{index}: string = selected{index}[0][0][0][0].id;\n"
        f"const wrongContainer{index}: {{ id: string }}[][][][] = selected{index};\n"
        f"const missing{index} = selected{index}[0][0][0][0].missing;\n"
        for index in indices
    )
    with tempfile.TemporaryDirectory(prefix="home-bench-recursive-") as temporary:
        project = Path(temporary) / "project"
        shutil.copytree(CORPUS / "recursive_generics", project)
        source_path = project / "src/recursive-generics.ts"
        write(source_path, source_path.read_text(encoding="utf-8") + invalid)
        for name, command in commands.items():
            result, passed = admission_process(name, command + ["--noEmit", "-p", str(project / "tsconfig.json")],
                                               "recursive_generics", expected_codes=["2322"] * (2 * len(indices)) + ["2339"] * len(indices), trace=trace)
            details = result.stdout + result.stderr
            if not passed:
                raise SystemExit(f"{name} failed recursive_generics negative controls:\n{details}")


def validate_variadic_tuple_negatives(commands: dict[str, list[str]], *, trace: list | None = None) -> None:
    # Exercise the actual inferred/conditional/spread results from the timed
    # workload. Mutations are confined to a temporary copy and are never timed.
    invalid = """
const invalidConcatResult: string = combined0[0];
const invalidConditionalHead: Head<Tuple0> = "wrong";
const invalidConditionalTail: number = tail0[0];
const invalidCapturedSpread: number = captured0[1];
const invalidConsumedResult: string = tupleResult0.result[2];
combined0[0] = 0;
const invalidTupleBounds = combined0[5];
"""
    with tempfile.TemporaryDirectory(prefix="home-bench-tuples-") as temporary:
        project = Path(temporary) / "project"
        shutil.copytree(CORPUS / "variadic_tuples", project)
        source_path = project / "src/variadic-tuples.ts"
        write(source_path, source_path.read_text(encoding="utf-8") + invalid)
        for name, command in commands.items():
            result, passed = admission_process(name, command + ["--noEmit", "-p", str(project / "tsconfig.json")],
                                               "variadic_tuples", expected_codes=["2322"] * 5 + ["2493", "2540"], trace=trace)
            details = result.stdout + result.stderr
            if not passed:
                raise SystemExit(f"{name} failed variadic_tuples negative controls:\n{details}")


def validate_graph_negatives(commands: dict[str, list[str]], workload: str, *, trace: list | None = None) -> None:
    # Exercise the imported generic shape itself, not a locally declared
    # equivalent. Accepting the positive graph with imported `any` is not
    # equivalent semantic work and cannot qualify for timing (#487).
    invalid = {
        "import_graph": "\nexport const invalidImportedProperty: number = result.current;\nresult.missing;\n",
        "reexport_graph": "\nexport const invalidImportedProperty: string = value0.value;\nvalue0.missing;\n",
    }[workload]
    with tempfile.TemporaryDirectory(prefix="home-bench-graph-") as temporary:
        project = Path(temporary) / "project"
        shutil.copytree(CORPUS / workload, project)
        source_path = project / "src/index.ts"
        write(source_path, source_path.read_text(encoding="utf-8") + invalid)
        for name, command in commands.items():
            result, passed = admission_process(name, command + ["--noEmit", "-p", str(project / "tsconfig.json")],
                                               workload, expected_codes=["2322", "2339"], trace=trace)
            details = result.stdout + result.stderr
            if not passed:
                raise SystemExit(f"{name} failed {workload} negative controls:\n{details}")


def validate_type_predicate_negatives(commands: dict[str, list[str]], workload: str, *, trace: list | None = None) -> None:
    # Both guards and assertion functions must narrow to the real object
    # shape, not any or the original union. These mutations are never timed.
    with tempfile.TemporaryDirectory(prefix="home-bench-predicates-") as temporary:
        project = Path(temporary) / "project"
        shutil.copytree(CORPUS / workload, project)
        source_path = project / "src/type-predicates.ts"
        source = source_path.read_text(encoding="utf-8")
        anchors = ["  if (isReady0(value)) {\n", "  assertReady0(value);\n"]
        for index, anchor in enumerate(anchors):
            if source.count(anchor) != 1:
                raise SystemExit("type-predicate negative-control anchor is not unique")
            invalid = (
                f"  const invalidLabel{index}: number = value.payload.label;\n"
                f"  const invalidProgress{index} = value.progress;\n"
            )
            source = source.replace(anchor, anchor + invalid, 1)
        write(source_path, source)
        for name, command in commands.items():
            result, passed = admission_process(name, command + ["--noEmit", "-p", str(project / "tsconfig.json")],
                                               workload, expected_codes=["2322"] * 2 + ["2339"] * 2, trace=trace)
            details = result.stdout + result.stderr
            if not passed:
                raise SystemExit(f"{name} failed {workload} negative controls:\n{details}")


def validate_destructuring_negatives(commands: dict[str, list[str]], *, trace: list | None = None) -> None:
    # Check the inferred bindings themselves so a checker cannot pass the
    # positive workload by erasing projections to any or retaining removed keys.
    with tempfile.TemporaryDirectory(prefix="home-bench-destructuring-") as temporary:
        project = Path(temporary) / "project"
        shutil.copytree(CORPUS / "destructuring", project)
        source_path = project / "src/destructuring.ts"
        source = source_path.read_text(encoding="utf-8")
        anchor = (
            "function projectBindings0(input: BindingRecord0): BindingProjection0 {\n"
            "  const { meta: { label, score }, slots: [first, second], active = true, ...identity } = input;\n"
        )
        if source.count(anchor) != 1:
            raise SystemExit("destructuring negative-control anchor is not unique")
        invalid = (
            "  const invalidLabel: number = label;\n"
            "  const invalidTuple: number = second;\n"
            "  const invalidRest: string = identity.id;\n"
            "  const invalidDefault: string = active;\n"
            "  const invalidOmitted = identity.meta;\n"
        )
        write(source_path, source.replace(anchor, anchor + invalid, 1))
        for name, command in commands.items():
            result, passed = admission_process(name, command + ["--noEmit", "-p", str(project / "tsconfig.json")],
                                               "destructuring", expected_codes=["2322"] * 4 + ["2339"], trace=trace)
            details = result.stdout + result.stderr
            if not passed:
                raise SystemExit(f"{name} failed destructuring negative controls:\n{details}")


def selected_workloads(requested: list[str] | None) -> list[str]:
    available = manifest()["workloads"]
    if requested is None:
        return list(available)
    if not requested:
        raise SystemExit("select at least one workload")
    if len(set(requested)) != len(requested):
        raise SystemExit("duplicate workloads would overwrite measured rounds")
    unknown = [name for name in requested if name not in available]
    if unknown:
        raise SystemExit(f"unknown workload: {', '.join(unknown)}")
    return list(requested)


def cmd_cold(runs: int, warmup: int, workloads: list[str] | None = None,
             competitor_manifest: Path | None = None) -> Path:
    workloads = selected_workloads(workloads)
    profiles = competitors.load_profiles(competitor_manifest)
    if not shutil.which("hyperfine"):
        raise SystemExit("hyperfine is required (brew install hyperfine)")
    if not CORPUS.is_dir():
        cmd_corpus()
    commands = compiler_commands(profiles) if profiles else compiler_commands()
    versions = verified_compiler_versions(commands, profiles) if profiles else verified_compiler_versions(commands)
    def provenance():
        return benchmark_provenance(commands, profiles) if profiles else benchmark_provenance(commands)
    preflight_provenance = provenance()
    # Validate the entire selection before creating a result directory or
    # timing any workload. A later admission failure must not leave an
    # apparently complete report containing only the earlier/easier cases.
    trace = []
    stamp = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    admission_path = RESULTS / "admission" / f"{stamp}-{os.getpid()}.json"
    try:
        for workload in workloads:
            validate(commands, workload, profiles=profiles, trace=trace)
        admitted_provenance = provenance()
        if admitted_provenance != preflight_provenance:
            raise SystemExit("benchmark artifacts changed during admission; no timing results were created")
    except BaseException as error:
        if admission_path:
            write(admission_path, json.dumps({"schema": 1, "passed": False, "error": str(error),
                                             "records": trace, "before": preflight_provenance}, indent=2) + "\n")
            print(f"Failed admission retained: {admission_path}", file=sys.stderr)
        raise
    stamp = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    output = RESULTS / stamp
    output.mkdir(parents=True)
    metadata = {
        "schema": 3 if profiles else 2,
        "timestamp_utc": stamp,
        "system": platform.platform(),
        "machine": platform.machine(),
        "processor": platform.processor(),
        "host": host_metadata(),
        "runs": runs,
        "warmup": warmup,
        "schedule": "round-robin interleaved",
        "validation_schema": 5,
        "workloads": workloads,
        "compilers": versions,
        "provenance": {
            "status": "measuring",
            "before": preflight_provenance,
            "after": None,
        },
    }
    metadata_path = output / "metadata.json"
    if trace is not None:
        admission = {"schema": 1, "passed": True, "records": trace,
                     "before": preflight_provenance, "after": admitted_provenance}
        write(output / "admission.jsonl", json.dumps(admission) + "\n")
        write(admission_path, json.dumps(admission, indent=2) + "\n")
        metadata["admission"] = {"path": "admission.jsonl", "sha256": sha256_file(output / "admission.jsonl"),
                                 "records": len(trace)}
    write(metadata_path, json.dumps(metadata, indent=2) + "\n")
    try:
        for workload in workloads:
            config = CORPUS / workload / "tsconfig.json"
            benchmarks = {
                name: command + ["--noEmit", "-p", str(config)]
                for name, command in commands.items()
            }
            names = list(benchmarks)

            # Warm and measure in balanced round-robin order. Running every sample
            # for compiler A before compiler B lets changing workstation load bias
            # the comparison; rotating the order makes each compiler occupy every
            # position equally while retaining Hyperfine's process timer.
            for index in range(warmup):
                order = names[index % len(names) :] + names[: index % len(names)]
                for name in order:
                    subprocess.run(
                        benchmarks[name],
                        check=True,
                        stdout=subprocess.DEVNULL,
                        stderr=subprocess.DEVNULL,
                    )

            print(f"+ hyperfine interleaved {workload}: {runs} runs after {warmup} warmups", flush=True)
            for index in range(runs):
                offset = index % len(names)
                order = names[offset:] + names[:offset]
                command_line = [
                    "hyperfine",
                    "--shell=none",
                    "--runs",
                    "1",
                    "--style",
                    "none",
                    "--export-json",
                    str(output / f"{workload}-round-{index:03d}.json"),
                ]
                for name in order:
                    command_line.extend(
                        [
                            "--command-name",
                            f"{name} {workload}",
                            shlex.join(benchmarks[name]),
                        ]
                    )
                subprocess.run(command_line, check=True)
    except BaseException as error:
        metadata["provenance"]["status"] = "incomplete"
        metadata["failure"] = {"type": type(error).__name__, "message": str(error)}
        try:
            metadata["provenance"]["after"] = provenance()
        except BaseException as provenance_error:
            metadata["provenance"]["after_error"] = str(provenance_error)
        write(metadata_path, json.dumps(metadata, indent=2) + "\n")
        raise

    final_provenance = provenance()
    metadata["provenance"]["after"] = final_provenance
    if final_provenance != preflight_provenance:
        metadata["provenance"]["status"] = "changed"
        write(metadata_path, json.dumps(metadata, indent=2) + "\n")
        raise SystemExit(f"benchmark artifacts changed during measurement; retained invalid results in {output}")
    metadata["provenance"]["status"] = "verified"
    write(metadata_path, json.dumps(metadata, indent=2) + "\n")
    print(f"Results: {output}")
    return output


def is_completed_result(path: Path) -> bool:
    metadata_path = path / "metadata.json"
    try:
        metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return False

    provenance = metadata.get("provenance", {})
    workloads = metadata.get("workloads")
    runs = metadata.get("runs")
    if provenance.get("status") != "verified" or not isinstance(workloads, list) or not workloads:
        return False
    if not isinstance(runs, int) or isinstance(runs, bool) or runs <= 0:
        return False

    return all(
        (path / f"{workload}-round-{index:03d}.json").is_file()
        for workload in workloads
        for index in range(runs)
    )


def latest_results() -> Path:
    candidates = []
    if RESULTS.is_dir():
        candidates = sorted(path for path in RESULTS.iterdir() if path.is_dir() and is_completed_result(path))
    if not candidates:
        raise SystemExit("no completed verified results found; run './run.sh cold'")
    return candidates[-1]


def normalize_public_paths(value: object, aliases: dict[str, str] | None = None) -> object:
    aliases = aliases or {str(ROOT.resolve()): "$REPO"}
    if isinstance(value, dict):
        return {key: normalize_public_paths(item, aliases) for key, item in value.items()}
    if isinstance(value, list):
        return [normalize_public_paths(item, aliases) for item in value]
    if isinstance(value, str):
        for root, label in sorted(aliases.items(), key=lambda item: len(item[0]), reverse=True):
            if value == root:
                value = label
            else:
                value = value.replace(root + os.sep, label + "/")
    return value


def publication_aliases(metadata: dict, admission: dict | None) -> dict[str, str]:
    root = str(ROOT.resolve())
    aliases = {root: "$REPO"}
    if admission is None:
        return aliases
    for name, entry in metadata["provenance"]["before"]["compilers"].items():
        for index, payload in enumerate(entry.get("payloads", [])):
            path = payload["path"]
            if not Path(path).is_relative_to(root):
                aliases[path] = f"$COMPILER_{name}_PAYLOAD_{index}"
        for kind in ("executable", "launcher", "payload", "manifest"):
            artifact = entry.get(kind, {})
            for key in ("path", "resolved_path"):
                path = artifact.get(key)
                if path and not Path(path).is_relative_to(root):
                    aliases[path] = "$COMPETITOR_MANIFEST" if kind == "manifest" else f"$COMPILER_{name}_{kind}"
    for name, entry in metadata["provenance"]["before"].get("tools", {}).items():
        for key in ("path", "resolved_path"):
            path = entry.get("executable", {}).get(key)
            if path and not Path(path).is_relative_to(root):
                aliases[path] = f"$TOOL_{name}"
    for record in admission["records"]:
        if record["kind"] == "negative":
            directory = Path(record["command"][-1]).parent
            aliases[str(directory)] = f"$CONTROL_{record['workload']}"
            aliases[str(directory.resolve())] = f"$CONTROL_{record['workload']}"
    return aliases


def evidence_members(source: Path, metadata: dict) -> dict[str, bytes]:
    prefix = f"ts-frontend-benchmark-{source.name}"
    members = {
        f"{prefix}/{path.name}": path.read_bytes()
        for path in sorted(source.glob("*-round-*.json"))
    }
    admission = json.loads((source / "admission.jsonl").read_text()) if metadata.get("admission") else None
    aliases = publication_aliases(metadata, admission)
    public_metadata = normalize_public_paths(metadata, aliases)
    if admission is not None:
        published = (json.dumps(normalize_public_paths(admission, aliases)) + "\n").encode()
        members[f"{prefix}/admission.jsonl"] = published
        public_metadata["admission"]["sha256"] = hashlib.sha256(published).hexdigest()
    members[f"{prefix}/metadata.json"] = (json.dumps(public_metadata, indent=2) + "\n").encode()
    explanation = (
        "Every *-round-*.json file is the byte-for-byte Hyperfine output from the measured run.\n"
        "Known repository, compiler/tool, and temporary-control paths in metadata and admission are normalized before publication.\n"
        "When present, admission.jsonl retains all commands, exits, stdout and stderr with only those path prefixes normalized.\n"
        "SHA256SUMS covers the published metadata and every raw round file.\n"
    )
    members[f"{prefix}/README.txt"] = explanation.encode()
    checksums = "".join(
        f"{hashlib.sha256(content).hexdigest()}  {name.removeprefix(prefix + '/')}\n"
        for name, content in sorted(members.items())
    )
    members[f"{prefix}/SHA256SUMS"] = checksums.encode()
    return members


def write_evidence_archive(output: Path, members: dict[str, bytes]) -> None:
    tar_buffer = io.BytesIO()
    with tarfile.open(fileobj=tar_buffer, mode="w", format=tarfile.PAX_FORMAT) as archive:
        for name, content in sorted(members.items()):
            info = tarfile.TarInfo(name)
            info.size = len(content)
            info.mtime = 0
            info.mode = 0o644
            info.uid = 0
            info.gid = 0
            info.uname = ""
            info.gname = ""
            archive.addfile(info, io.BytesIO(content))
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("wb") as raw:
        with gzip.GzipFile(filename="", mode="wb", fileobj=raw, mtime=0) as compressed:
            compressed.write(tar_buffer.getvalue())


def cmd_evidence(directory: Path | None, output: Path | None) -> Path:
    source = directory or latest_results()
    if not is_completed_result(source):
        raise SystemExit(f"cannot package incomplete or unverified benchmark results: {source}")
    try:
        metadata = json.loads((source / "metadata.json").read_text(encoding="utf-8"))
        compare.validate_interleaved_rounds(source, metadata)
    except (json.JSONDecodeError, OSError, ValueError) as error:
        raise SystemExit(f"cannot package benchmark evidence from {source}: {error}") from error
    destination = output or EVIDENCE / f"{source.name}.tar.gz"
    write_evidence_archive(destination, evidence_members(source, metadata))
    print(f"Evidence: {destination}")
    return destination


def cmd_report(directory: Path | None) -> None:
    source = directory or latest_results()
    run([sys.executable, str(HERE / "compare.py"), str(source)])


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("corpus", help="regenerate deterministic benchmark inputs")
    sub.add_parser("setup", help="install pinned tsc and tsgo locally")
    cold = sub.add_parser("cold", help="run validated cold frontend benchmarks")
    cold.add_argument("--runs", type=int, default=10)
    cold.add_argument("--warmup", type=int, default=3)
    cold.add_argument("--workload", action="append", help="select a workload; repeat for several (default: all)")
    cold.add_argument("--competitor-manifest", type=Path, help="add pinned native compilers from a JSON manifest")
    report = sub.add_parser("report", help="render a Markdown report")
    report.add_argument("results", nargs="?", type=Path)
    evidence = sub.add_parser("evidence", help="package verified raw results for publication")
    evidence.add_argument("results", nargs="?", type=Path)
    evidence.add_argument("--output", type=Path)
    sub.add_parser("all", help="generate corpus, set up tools, benchmark, and report")
    args = parser.parse_args()
    if args.command == "corpus":
        cmd_corpus()
    elif args.command == "setup":
        cmd_setup()
    elif args.command == "cold":
        cmd_cold(args.runs, args.warmup, args.workload, args.competitor_manifest)
    elif args.command == "report":
        cmd_report(args.results)
    elif args.command == "evidence":
        cmd_evidence(args.results, args.output)
    else:
        cmd_corpus()
        cmd_setup()
        cmd_report(cmd_cold(10, 3))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
