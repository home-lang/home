import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
profile = Path('/Users/chris/.cache/home-ts-current-profile.5dNJoB')
assert json.loads((root / 'lint-command.json').read_text())['exit'] == 1
assert '22074 problems (11461 errors, 10613 warnings)' in (root / 'lint.log').read_text()
record = {'source_at_lint': '624916ec4210bb13ebbc8e9368f9f28d9152cb89',
          'matrix_session': {'session': 77454, 'status': 'terminal', 'exit': 0},
          'profile_session': {'session': 59623, 'status': 'terminal', 'exit': 0},
          'lint_session': {'session': 75437, 'status': 'terminal', 'exit': 1},
          'lint_errors': 11461, 'lint_warnings': 10613, 'autofixes': False,
          'changed_files': ['README.md', 'docs/docs/TS_PERFORMANCE.md'],
          'matrix_admissions': 145, 'matrix_samples': 3000, 'profile_admissions': 62,
          'diagnostic_image_timing_samples': 0, 'guard_changes': False}
(root / 'publication-context.json').write_text(json.dumps(record, indent=2) + '\n')
entries = {name: (root / name).read_bytes() for name in ('lint.py', 'lint.log', 'lint-command.json',
           'publication-context.json', 'verify_docs.py', 'package_publication_context.py')}
entries['profile/verify_profile_docs.py'] = (profile / 'verify_profile_docs.py').read_bytes()
checksums = ''.join(hashlib.sha256(data).hexdigest() + '  ' + name + '\n' for name, data in sorted(entries.items()))
count = len(entries)
entries['SHA256SUMS'] = checksums.encode()
name = '20261009-restored-matrix-profile-publication-context-854'
path = repo / 'bench/vs_tsgo/evidence' / (name + '.tar.gz')
assert not path.exists()
with path.open('wb') as output:
    with gzip.GzipFile(filename='', mode='wb', fileobj=output, mtime=0) as gz:
        with tarfile.open(fileobj=gz, mode='w') as tar:
            for filename, data in sorted(entries.items()):
                info = tarfile.TarInfo(name + '/' + filename)
                info.size, info.mode, info.mtime = len(data), 0o644, 0
                tar.addfile(info, io.BytesIO(data))
with tarfile.open(path) as tar:
    for row in checksums.splitlines():
        expected, filename = row.split('  ', 1)
        assert hashlib.sha256(tar.extractfile(name + '/' + filename).read()).hexdigest() == expected
result = {'archive': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'payload_checksums': count}
(root / 'publication-archive.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
