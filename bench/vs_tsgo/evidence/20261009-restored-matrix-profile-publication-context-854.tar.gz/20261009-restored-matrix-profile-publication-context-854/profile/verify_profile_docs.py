import json
from pathlib import Path

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
profile = json.loads((root / 'verified-profile.json').read_text())
archive = json.loads((root / 'archive.json').read_text())
docs = (repo / 'docs/docs/TS_PERFORMANCE.md').read_text()
section = docs.split('## Restored current-main profile (2026-10-09 UTC)', 1)[1].split('\n## ', 1)[0]
for key in ('native_sha256', 'diagnostic_sha256', 'text_sha256'):
    assert profile[key] in section
assert archive['sha256'] in section and f"**{archive['payload_checksums']}**" in section
for name, mapping in profile['symbol_mapping'].items():
    assert mapping['start'] in section
    assert ', '.join(str(offset) for offset in mapping['displayed_sampled_offsets']) in section
for name in ('memberAccessReceiverIsRequireAssignmentBinding', 'resolveValueDeclInStmt',
             'jsDocTypeForPreviousIdentifierDecl', 'moduleNamespaceTypeForLocalImport',
             'collectFunctionSignaturesFromStatements', 'virtualSectionStartForNode',
             'requireImportAssignmentMemberType'):
    early = profile['samples']['early']['leaf_observations_at_least_five']['diag_l_check.Checker.' + name]
    later = profile['samples']['middle']['leaf_observations_at_least_five']['diag_l_check.Checker.' + name]
    assert f'| `{name}` | {early} | {later} |' in section
assert 'not whole-run CPU percentages' in section
assert 'prologue/epilogue' in section and 'no fallback\nvirtual-section filter' in section
print('Profile counts, exact hashes, symbol/offset scope and cautions verify.')
