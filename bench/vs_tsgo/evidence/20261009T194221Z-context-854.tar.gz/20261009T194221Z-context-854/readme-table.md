| Workload | tsc 6.0.3 median | native TS 7.0.2 median | Home median | Rust tsc-rs 0.1.0 median | Bun canary median | Home vs fastest competitor |
|---|---:|---:|---:|---:|---:|---:|
| Startup (one small file) | 64.1 ms | 7.4 ms | 2.9 ms | 5.9 ms | 6.3 ms | **2.03× faster** |
| 256 independent files | 197.9 ms | 22.2 ms | 21.0 ms | 15.5 ms | 12.6 ms | 1.67× slower |
| 128-module import chain | 152.3 ms | 16.0 ms | 18.6 ms | 12.8 ms | 17.6 ms | 1.45× slower |
| 64 modules through 8 barrel re-exports | 99.3 ms | 10.6 ms | 12.1 ms | 9.0 ms | 8.9 ms | 1.37× slower |
| Deep conditional / mapped / template types | 132.9 ms | 21.7 ms | 21.2 ms | 14.2 ms | 13.5 ms | 1.57× slower |
| Recursive generics | 157.2 ms | 40.2 ms | 14.6 ms | 33.0 ms | 9.4 ms | 1.55× slower |
| Checked JavaScript with JSDoc | 214.7 ms | 24.3 ms | 28.1 ms | 23.7 ms | 14.0 ms | 2.00× slower |
| Control-flow narrowing (256 unions) | 209.4 ms | 28.8 ms | 27.0 ms | 25.7 ms | 17.1 ms | 1.58× slower |
| 256 type-predicate families | 241.2 ms | 40.7 ms | 33.3 ms | 34.7 ms | 23.2 ms | 1.43× slower |
| 2,048 type-predicate families | 1,003.6 ms | 306.5 ms | 243.5 ms | 268.4 ms | 162.9 ms | 1.49× slower |
