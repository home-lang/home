| Workload | tsc 6.0.3 median | native TS 7.0.2 median | Home median | Rust tsc-rs 0.1.0 median | Bun canary median | Home vs fastest competitor |
|---|---:|---:|---:|---:|---:|---:|
| `checkjs_jsdoc` | 214.7 ms | 24.3 ms | 28.1 ms | 23.7 ms | 14.0 ms | 2.00× slower |
| `class_hierarchy` | 188.4 ms | 21.4 ms | 23.3 ms | 17.8 ms | 13.7 ms | 1.71× slower |
| `commonjs_graph` | 158.5 ms | 18.6 ms | 18.2 ms | 15.2 ms | 12.3 ms | 1.48× slower |
| `control_flow` | 209.4 ms | 28.8 ms | 27.0 ms | 25.7 ms | 17.1 ms | 1.58× slower |
| `deep_types` | 132.9 ms | 21.7 ms | 21.2 ms | 14.2 ms | 13.5 ms | 1.57× slower |
| `destructuring` | 134.7 ms | 16.4 ms | 14.7 ms | 14.0 ms | 10.5 ms | 1.40× slower |
| `generic_calls` | 197.3 ms | 24.8 ms | 24.6 ms | 21.0 ms | 15.7 ms | 1.57× slower |
| `import_graph` | 152.3 ms | 16.0 ms | 18.6 ms | 12.8 ms | 17.6 ms | 1.45× slower |
| `interface_composition` | 220.7 ms | 34.0 ms | 35.7 ms | 25.3 ms | 18.6 ms | 1.92× slower |
| `many_files` | 197.9 ms | 22.2 ms | 21.0 ms | 15.5 ms | 12.6 ms | 1.67× slower |
| `null_safe_access` | 188.0 ms | 26.4 ms | 31.9 ms | 22.1 ms | 15.9 ms | 2.01× slower |
| `overload_resolution` | 197.8 ms | 32.6 ms | 23.6 ms | 26.2 ms | 19.8 ms | 1.19× slower |
| `recursive_generics` | 157.2 ms | 40.2 ms | 14.6 ms | 33.0 ms | 9.4 ms | 1.55× slower |
| `reexport_graph` | 99.3 ms | 10.6 ms | 12.1 ms | 9.0 ms | 8.9 ms | 1.37× slower |
| `startup` | 64.1 ms | 7.4 ms | 2.9 ms | 5.9 ms | 6.3 ms | **2.03× faster** |
| `structural_objects` | 192.3 ms | 27.8 ms | 23.4 ms | 23.3 ms | 17.3 ms | 1.36× slower |
| `tsx_components` | 177.9 ms | 17.1 ms | 20.2 ms | 15.3 ms | 10.9 ms | 1.85× slower |
| `type_predicates` | 241.2 ms | 40.7 ms | 33.3 ms | 34.7 ms | 23.2 ms | 1.43× slower |
| `type_predicates_large` | 1,003.6 ms | 306.5 ms | 243.5 ms | 268.4 ms | 162.9 ms | 1.49× slower |
| `variadic_tuples` | 270.6 ms | 47.8 ms | 33.0 ms | 35.6 ms | 20.2 ms | 1.63× slower |
