import hashlib
import json
from pathlib import Path
import re
import subprocess

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
provenance = json.loads((root / 'provenance.json').read_text())
assert len(provenance['admissions']) == 62 and all(row['passed'] for row in provenance['admissions'])
assert not provenance['diagnostic_image_used_for_timing']
assert (root / 'original-text.bin').read_bytes() == (root / 'renamed-text.bin').read_bytes()
assert hashlib.sha256((root / 'original-text.bin').read_bytes()).hexdigest() == provenance['text_sha256']
record = json.loads((root / 'checkjs8192-profile.json').read_text())
assert record['compiler_exit'] == 0 and not record['stdout'] and not record['stderr']
assert record['input_hash_before'] == record['input_hash_after']
assert [row['label'] for row in record['samples']] == ['early', 'middle']
samples = {}
for row in record['samples']:
    assert row['sample_exit'] == 0
    data = Path(row['path']).read_text()
    main = re.search(r'^\s+(\d+) Thread_\d+\s+DispatchQueue_1:', data, re.MULTILINE)
    assert main
    top = data.split('Sort by top of stack, same collapsed (when >= 5):', 1)[1].split('Binary Images:', 1)[0]
    leaves = {}
    for line in top.splitlines():
        match = re.match(r'\s+(.+?)\s+\(in .+?\)\s+(\d+)\s*$', line)
        if match:
            leaves[match.group(1)] = int(match.group(2))
    samples[row['label']] = {'main_thread_observations': int(main.group(1)), 'leaf_observations_at_least_five': leaves}
source = subprocess.check_output(['git', 'show', provenance['source'] + ':packages/ts_checker/src/check.zig'], cwd=repo)
for name, begin, end in [('virtual-section-source.zig', '    fn virtualSectionStartForNode(', '    fn virtualSectionStartForPos('),
    ('require-binding-source.zig', '    fn memberAccessReceiverIsRequireAssignmentBinding(', '    fn ')]:
    start = source.index(begin.encode())
    stop = source.index(end.encode(), start + len(begin))
    (root / name).write_bytes(source[start:stop])
binary = root / 'home-tsc-profile'
symbols = []
for line in subprocess.check_output(['nm', str(binary)], text=True).splitlines():
    match = re.match(r'^([0-9a-f]+) [tT] (.+)$', line)
    if match:
        symbols.append((int(match.group(1), 16), match.group(2)))
symbols.sort()
mapped = {}
for name, function in [('virtual-section-loop', 'virtualSectionStartForNode'),
    ('require-binding-loop', 'memberAccessReceiverIsRequireAssignmentBinding')]:
    matches = [(address, symbol) for address, symbol in symbols if symbol.endswith('.' + function)]
    assert len(matches) == 1, matches
    start, symbol = matches[0]
    stop = next(address for address, _ in symbols if address > start)
    offsets = set()
    for row in record['samples']:
        offsets.update(int(value) for value in re.findall(re.escape(symbol) + r'\s+\+\s+(\d+)', Path(row['path']).read_text()))
    mapped[function] = {'symbol': symbol, 'start': hex(start), 'stop': hex(stop), 'sampled_offsets': sorted(offsets)}
    command = ['/Users/chris/.local/share/pantry/global/bin/llvm-objdump', '--disassemble',
        '--start-address=' + hex(start), '--stop-address=' + hex(stop), str(binary)]
    result = subprocess.run(command, capture_output=True, text=True, check=True)
    (root / (name + '-assembly.txt')).write_text(result.stdout)
    (root / (name + '-command.json')).write_text(json.dumps(command, indent=2) + '\n')
report = {'source': provenance['source'], 'native_sha256': provenance['binary_sha256'],
    'diagnostic_sha256': provenance['diagnostic_sha256'], 'text_sha256': provenance['text_sha256'],
    'admissions': 62, 'samples': samples,
    'interpretation': 'Separate one-second exploratory leaf counts, not whole-run CPU percentages or causal speed proof',
    'source_candidates': ['virtualSectionStartForNode', 'memberAccessReceiverIsRequireAssignmentBinding'],
    'symbol_mapping': mapped,
    'timing_samples_from_diagnostic_image': 0}
(root / 'verified-profile.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
