    fn virtualSectionStartForNode(self: *Checker, node: NodeId) usize {
        const src = self.source orelse return 0;
        if (!self.sourceHasVirtualFilenameSections()) return 0;
        if (self.virtual_section_start_cache.get(node)) |cached| return cached;
        const span = self.hir.spanOf(node);
        const last = self.virtual_section_index.start(self.gpa, src, span.start);
        self.virtual_section_start_cache.put(self.gpa, node, last) catch {};
        return last;
    }

