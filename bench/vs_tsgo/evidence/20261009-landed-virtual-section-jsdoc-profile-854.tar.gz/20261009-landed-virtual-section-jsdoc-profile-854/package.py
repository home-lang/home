import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
subprocess.run(['python3', str(root / 'verify_profile.py')], check=True)
assert json.loads((root / 'profile-command.json').read_text())['exit'] == 0
entries = {}
for filename in ('profile.py', 'logged_profile.py', 'verify_profile.py', 'verify_profile-first.py', 'archive-first.json', 'package.py', 'profile.log', 'profile-command.json',
    'provenance.json', 'verified-profile.json', 'checkjs8192-profile.json', 'checkjs8192-early-sample.txt',
    'checkjs8192-middle-sample.txt', 'original-text.bin', 'renamed-text.bin', 'symbol-map.txt',
    'virtual-section-source.zig', 'require-binding-source.zig', 'virtual-section-loop-assembly.txt',
    'virtual-section-loop-command.json', 'require-binding-loop-assembly.txt', 'require-binding-loop-command.json'):
    entries[filename] = (root / filename).read_bytes()
for child in sorted((root / 'checkjs-scale-8192').rglob('*')):
    if child.is_file():
        entries['inputs/checkjs-scale-8192/' + child.relative_to(root / 'checkjs-scale-8192').as_posix()] = child.read_bytes()
for filename in ('run.py', 'compare.py', 'competitors.py', 'corpus.toml'):
    entries['harness/' + filename] = (repo / 'bench/vs_tsgo' / filename).read_bytes()
name = '20261009-landed-virtual-section-jsdoc-profile-854'
checksums = ''.join(hashlib.sha256(data).hexdigest() + '  ' + path + '\n' for path, data in sorted(entries.items()))
count = len(entries)
entries['SHA256SUMS'] = checksums.encode()
archive = repo / 'bench/vs_tsgo/evidence' / (name + '.tar.gz')
assert not archive.exists()
with archive.open('wb') as output:
    with gzip.GzipFile(filename='', mode='wb', fileobj=output, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as tar:
            for path, data in sorted(entries.items()):
                info = tarfile.TarInfo(name + '/' + path)
                info.size, info.mode, info.mtime = len(data), 0o644, 0
                tar.addfile(info, io.BytesIO(data))
with tarfile.open(archive) as tar:
    for line in checksums.splitlines():
        digest, path = line.split('  ', 1)
        assert hashlib.sha256(tar.extractfile(name + '/' + path).read()).hexdigest() == digest
report = {'archive': str(archive), 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'payload_checksums': count}
(root / 'archive.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report), flush=True)
