import hashlib
import json
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
parent = 'abe538a8638ed4542abfa7b256f3a2711a1f59c6'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip() == parent
patch = subprocess.check_output(['git', 'diff', '--', 'packages/ts_checker/src/check.zig'], cwd=repo)
assert not (root / 'first-draft.patch').exists()
(root / 'first-draft.patch').write_bytes(patch)
(root / 'initial-provenance.json').write_text(json.dumps({
    'source_parent': parent,
    'first_draft_patch_sha256': hashlib.sha256(patch).hexdigest(),
    'parent_binary_sha256': hashlib.sha256((root / 'home-tsc-parent').read_bytes()).hexdigest(),
    'mapped_profile_source': '624916ec4210bb13ebbc8e9368f9f28d9152cb89',
    'timing_acceptance': 'pending; no timing samples yet'}, indent=2) + '\n')
print('Preserved complete initial source/test draft against the exact landed parent.')
