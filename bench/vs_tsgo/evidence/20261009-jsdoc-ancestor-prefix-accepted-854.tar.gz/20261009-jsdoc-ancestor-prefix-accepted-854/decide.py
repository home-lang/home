"""Evaluate the frozen acceptance rules only after the complete protocol."""
import json
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
subprocess.run(['python3', str(root / 'verify_pairs.py')], check=True)
verified = json.loads((root / 'verified-pairs.json').read_text())
assert verified['complete'] and verified['admissions'] == 660
assert verified['rounds'] == 382 + 30 * len(verified['independent_rechecks'])
independent = {name: values for name, values in verified['summaries'].items()
    if name.startswith(('confirmation/', 'confirmation_large-', 'recheck/', 'interface-risk/'))}
regressions = {name: values['paired_saving_ci95'] for name, values in independent.items()
    if values['paired_saving_ci95'][1] < 0}
large = verified['large_confirmation']
supported_target = large['paired_saving_ci95'][0] > 0 and large['batch_mean_saving_ci95'][0] > 0
warnings = {name: {'parent_median': values['parent_median'], 'candidate_median': values['candidate_median'],
    'paired_saving_ci95': values['paired_saving_ci95']}
    for name, values in verified['summaries'].items()
    if values['candidate_median'] > values['parent_median'] or values['paired_saving_ci95'][0] <= 0}
provenance = json.loads((root / 'candidate-provenance.json').read_text())
assert provenance['all_full_module_gates_passed'] and provenance['same_frozen_initial_patch_required']
zod = json.loads((root / 'zod-comparison.json').read_text())
assert zod['complete_primary_messages_equal'] and zod['added'] == zod['removed'] == 0
decision = {
    'status': 'accepted' if supported_target and not regressions else 'rejected',
    'source_commit': 'pending',
    'parent_source': provenance['parent_source'],
    'binaries': provenance['binaries'],
    'candidate_patch_sha256': provenance['candidate_patch_sha256'],
    'protocol_sha256': provenance['protocol_sha256'],
    'independent_confirmed_regressions': regressions,
    'large_target_supported_by_pair_and_batch_intervals': supported_target,
    'large_target': {key: value for key, value in large.items() if key != 'samples'},
    'all_inconclusive_or_adverse_point_estimates': warnings,
    'all_observations_retained': True,
    'whole_goal_achieved': False,
    'interpretation': 'Scoped exact-parent Home A/B only; inconclusive intervals do not prove equivalence, no five-compiler or all-platform leadership claim. No repeat-to-pass or alignment changes.'
}
assert not (root / 'decision.json').exists()
(root / 'decision.json').write_text(json.dumps(decision, indent=2) + '\n')
print(json.dumps({key: decision[key] for key in ('status', 'independent_confirmed_regressions', 'large_target_supported_by_pair_and_batch_intervals', 'source_commit')}))
