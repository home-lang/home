"""Persist observational progress; missing output is never a failed/completed job."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
patch = subprocess.check_output(['git', 'diff', '--', 'packages/ts_checker/src/check.zig'], cwd=repo)
assert hashlib.sha256(patch).hexdigest() == json.loads((root / 'initial-provenance.json').read_text())['first_draft_patch_sha256']
phases = ('parent-build', 'checker-first', 'checker', 'program', 'driver', 'cli', 'entrypoint', 'build', 'zod-parent', 'zod-candidate', 'harness')
commands = {name: json.loads((root / (name + '-command.json')).read_text()) if (root / (name + '-command.json')).exists() else None for name in phases}
processes = subprocess.check_output(['ps', '-axo', 'pid,ppid,etime,command']).decode().splitlines()
owned = [line for line in processes if str(root) in line and 'current_state.py' not in line]
state = {
    'observed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip(),
    'status': subprocess.check_output(['git', 'status', '--short'], cwd=repo).decode(),
    'candidate_patch_sha256': hashlib.sha256(patch).hexdigest(),
    'protocol_sha256': hashlib.sha256((root / 'protocol.json').read_bytes()).hexdigest(),
    'commands': commands,
    'observed_owned_processes': owned,
    'gate_session': {'session': 17509, 'status': 'terminal', 'exit': 0},
    'measurement_session': 73751,
    'completed_timing_phases': {path.parent.name: json.loads(path.read_text())['stage'] for path in sorted(root.glob('paired-*/summary.json'))},
    'acceptance': 'pending; frozen native A/B running, no production candidate commit',
    'next_step': 'Observe live measurement session73751; require all predeclared phases and verify_pairs.py before acceptance. Do not duplicate live work or infer missing outputs are failures.'
}
(root / 'current-state.json').write_text(json.dumps(state, indent=2) + '\n')
print(json.dumps({'completed': {name: value['exit'] for name, value in commands.items() if value is not None}, 'owned_processes': owned, 'acceptance': state['acceptance']}))
