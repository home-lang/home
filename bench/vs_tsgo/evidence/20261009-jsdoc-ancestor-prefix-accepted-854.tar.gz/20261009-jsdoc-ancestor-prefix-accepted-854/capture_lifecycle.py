"""Record verified terminal commands and native publication provenance."""
import datetime
import hashlib
import json
from pathlib import Path
import re
import subprocess

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
labels = ['parent-build', 'checker-first', 'checker', 'program', 'driver', 'cli', 'entrypoint', 'build', 'zod-parent', 'zod-candidate', 'harness', 'screen', 'confirmation', 'families', 'recheck', 'interface-risk']
labels += [f'confirmation_large-{n}' for n in range(5)]
records = {}
for name in labels:
    command = json.loads((root / (name + '-command.json')).read_text())
    assert command['exit'] == 0
    log = (root / (name + '.log')).read_text()
    peaks = [int(value) for value in re.findall(r'peak tree footprint (\d+) MB', log)]
    low = [int(value) for value in re.findall(r'host low-water (\d+)%', log)]
    records[name] = {'status': 'terminal', **command, 'peak_tree_mb': max(peaks) if peaks else None,
        'host_low_water_percent': min(low) if low else None}
verified = json.loads((root / 'verified-pairs.json').read_text())
assert verified['complete'] and verified['admissions'] == 660
decision = json.loads((root / 'decision.json').read_text())
assert decision['source_commit'] != 'pending'
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip()
if decision['status'] == 'accepted':
    assert head == decision['source_commit']
    patch = subprocess.check_output(['git', 'show', '--format=', head, '--', 'packages/ts_checker/src/check.zig'], cwd=repo)
    assert patch == (root / 'candidate.patch').read_bytes()
    assert hashlib.sha256((repo / 'zig-out/bin/home-tsc').read_bytes()).hexdigest() == decision['binaries']['candidate']
lint = json.loads((root / 'lint-command.json').read_text())
assert lint['exit'] in (0, 1)
report = {'observed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'source_at_publication': head, 'decision': decision['status'], 'commands': records,
    'gate_session': {'session': 17509, 'status': 'terminal', 'exit': 0},
    'measurement_session': {'session': 73751, 'status': 'terminal', 'exit': 0},
    'lint_session': {'session': 83964, 'status': 'terminal', 'exit': lint['exit']},
    'host': {'uname': subprocess.check_output(['uname', '-a']).decode().strip(),
        'hardware': subprocess.check_output(['sysctl', '-n', 'hw.model', 'hw.ncpu', 'machdep.cpu.brand_string']).decode().splitlines()},
    'tools': {'hyperfine': subprocess.check_output(['hyperfine', '--version']).decode().strip(),
        'python': subprocess.check_output(['python3', '--version']).decode().strip(),
        'zig': '/Users/chris/Code/Home/lang-bun-port/zig-out/toolchains/zig-aarch64-macos-0.17.0-dev.2163+89ff10d56/zig'},
    'rounds': verified['rounds'], 'admissions': verified['admissions'],
    'guard': {'timeout_seconds': 600, 'tree_mb': 3840, 'disk_admission_mb': 1024, 'disk_continuation_mb': 512},
    'all_attempt_logs_retained': True, 'timing_exclusions': 0,
    'whole_goal': 'incomplete; no universal leadership, Zod admission, C++ admission or other-platform result established'}
(root / 'final-job-lifecycle.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'source': head, 'decision': decision['status'], 'rounds': verified['rounds'], 'admissions': verified['admissions'], 'all_commands_terminal': True}))
