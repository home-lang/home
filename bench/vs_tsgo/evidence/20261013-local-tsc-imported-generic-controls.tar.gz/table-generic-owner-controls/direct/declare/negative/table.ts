import type { Table, TableOptions, TableRow } from "./types";
export declare function createTable<Row extends TableRow = TableRow>(options: TableOptions<Row>): Table<Row>;
