import type { Table, TableOptions, TableRow } from "./types";
export function createTable<Row extends TableRow = TableRow>(options: TableOptions<Row>): Table<Row> { throw "unreachable"; }
