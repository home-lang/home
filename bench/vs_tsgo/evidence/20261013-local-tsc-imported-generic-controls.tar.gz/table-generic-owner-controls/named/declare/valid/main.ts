import { createTable } from "./index";
import type { Table, TableDriver } from "./types";
declare const driver: TableDriver<{ id: number }>;
const table = createTable({ driver, index:"products", searchFields:["name"], ranking:{rules:["ok"]} });
const check: Table<{id:number}> = table;
