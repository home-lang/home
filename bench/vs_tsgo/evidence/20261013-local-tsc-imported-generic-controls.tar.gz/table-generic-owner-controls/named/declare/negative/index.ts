export { createTable } from "./table";
