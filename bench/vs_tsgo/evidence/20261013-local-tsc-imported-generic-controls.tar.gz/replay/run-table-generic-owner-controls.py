from pathlib import Path
import argparse,hashlib,json,os,re,subprocess
parser=argparse.ArgumentParser();parser.add_argument('--home',type=Path,required=True);parser.add_argument('--output',type=Path,required=True);args=parser.parse_args();r=Path.cwd();base=r/'.home-cache/owner-transfer/table-generic-owner-controls';h=json.loads((base/'input-hashes.json').read_text());rows=[];args.output.mkdir(exist_ok=False)
for config in sorted(base.rglob('tsconfig.json')):
 case=str(config.parent.relative_to(base));results=[]
 for engine,image in [('reference',r/'.home-cache/owner-transfer/reference-typescript-7.0.2/lib/tsc'),('home',args.home.resolve())]:
  env=os.environ.copy();env.update(HOME_RUN_MAX_MB='3840',HOME_RUN_LABEL='optional-indexed-'+engine)
  command=[str(image),'--project','tsconfig.json','--pretty','false'];result=subprocess.run(command,cwd=config.parent,env=env,capture_output=True,text=True,timeout=60)
  assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==v for p,v in h.items())
  diagnostics=sorted(re.findall(r'([^\r\n]+?)\((\d+),(\d+)\): error TS(\d+):',result.stdout+result.stderr));row={'case':case,'engine':engine,'exit':result.returncode,'stdout':result.stdout,'stderr':result.stderr,'diagnostics':diagnostics};rows.append(row);results.append(row)
  (args.output/'summary.json').write_text(json.dumps({'observations':rows,'inputs_unchanged':True},indent=2)+'\n')
 print(case,[(x['engine'],x['exit'],x['diagnostics']) for x in results],flush=True)
 assert results[0]['exit'] in [0,1] and results[1]['exit'] in [0,1]
summary={'observations':rows,'inputs_unchanged':True,'matched':all(rows[i]['exit']==rows[i+1]['exit'] and rows[i]['diagnostics']==rows[i+1]['diagnostics'] for i in range(0,len(rows),2))};(args.output/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print('matched',summary['matched'])
