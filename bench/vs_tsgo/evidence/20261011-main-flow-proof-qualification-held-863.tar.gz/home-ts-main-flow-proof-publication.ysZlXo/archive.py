import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

root = Path(__file__).resolve().parent
cache = root.parent
repo = Path('/Users/chris/.codex/worktrees/ts863-qualification-docs/lang')
names = [
    'home-ts-main-flow-proof-integration.dYlSre',
    'home-ts-recursive-metadata-controls.9Ocgi8',
    'home-ts-pinned-base-probes.YDPfnt',
    'home-ts-namespace-type-fact-controls.AWPMy0',
    'home-ts-import-spelling-controls.5j4zJX',
    'home-ts-asserting-initializer-controls.PXq9Rd',
    'home-ts-nullable-object-diagnostic.C6a6XI',
    root.name,
]
for name in names[1:6]:
    assert (cache / name / 'results.json').is_file()
assert json.loads((cache / names[-2] / 'guard-terminal.json').read_text())['exit'] == 124
archive = repo / 'bench/vs_tsgo/evidence/20261011-main-flow-proof-qualification-held-863.tar.gz'
assert not archive.exists()
files = []
for name in names:
    for path in sorted((cache / name).rglob('*')):
        if not path.is_file() or path.is_symlink() or '__pycache__' in path.parts:
            continue
        assert '.zig-cache' not in path.parts
        files.append((str(path.relative_to(cache)), path))
manifest = [{'path': name, 'bytes': path.stat().st_size,
             'sha256': hashlib.sha256(path.read_bytes()).hexdigest()} for name, path in files]
content = json.dumps({'payloads': manifest, 'timings_taken': False, 'source_adopted': False}, indent=2) + '\n'
patch = '*** Begin Patch\n*** Add File: ' + str(root / 'manifest.json') + '\n'
patch += ''.join('+' + line + '\n' for line in content.splitlines()) + '*** End Patch\n'
subprocess.run(['apply_patch', patch], check=True, capture_output=True)
with tarfile.open(archive, 'w:gz') as bundle:
    for name, path in files:
        bundle.add(path, arcname=name, recursive=False)
    bundle.add(root / 'manifest.json', arcname=root.name + '/manifest.json', recursive=False)
with tarfile.open(archive, 'r:gz') as bundle:
    expected = json.load(bundle.extractfile(root.name + '/manifest.json'))['payloads']
    assert len(bundle.getmembers()) == len(expected) + 1
    for row in expected:
        data = bundle.extractfile(row['path']).read()
        assert len(data) == row['bytes']
        assert hashlib.sha256(data).hexdigest() == row['sha256']
print(json.dumps({'archive': str(archive), 'payload_checksums_verified': len(expected),
    'archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'bytes': archive.stat().st_size}), flush=True)
