import * as factory from "./factory";
declare class Collection<T>{add(value:T):this;has(value:T):boolean;}
type Literal=string|number|bigint|boolean|null|undefined;
type LiteralPart=Exclude<Literal,symbol>;
interface BaseDef{kind:string;}
interface BaseState<O=unknown,I=unknown>{def:BaseDef;output:O;input:I;traits:Collection<string>;bag:Record<string,unknown>;}
interface Metadata<O,I>{readonly types?:{output:O;input:I};validate(value:unknown):{value:O};}
type MetadataOf<T extends Base>=Metadata<T["state"]["output"],T["state"]["input"]>;
interface Base<O=unknown,I=unknown,S extends BaseState<O,I>=BaseState<O,I>>{state:S;metadata:MetadataOf<this>;}
interface NestedState extends BaseState<LiteralPart,LiteralPart>{label:string;}
interface Nested extends Base{state:NestedState;}
type Part=LiteralPart|Nested;
interface ModelDef extends BaseDef{kind:"model";parts:Part[];}
interface ModelState<T extends string=string>extends BaseState<T,T>{def:ModelDef;}
interface Model<T extends string=string>extends Base{state:ModelState<T>;}
const result:factory.Creator<Model>=factory.create("model",(instance,def)=>{
 for(const part of def.parts)if(typeof part==="object"&&part!==null){const text:number=part.state.label;part.missing;void text;}
 void instance;
});void result;
