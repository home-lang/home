import hashlib
import json
from pathlib import Path
import sys

root = Path(__file__).resolve().parent
integration = Path('/Users/chris/.cache/home-ts-main-flow-proof-integration.dYlSre')
original = Path('/Users/chris/.cache/home-ts-callable-intersection-facts.34PC25')
runner = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
sys.path.insert(0, str(runner / 'bench/vs_tsgo'))
import run
import competitors

assert not (root / 'results.json').exists()
build = json.loads((integration / 'candidate-build.json').read_text())
candidate = integration / 'candidate-home-tsc'
parent = integration / 'baseline-home-tsc'
assert hashlib.sha256(candidate.read_bytes()).hexdigest() == build['native_sha256']
assert hashlib.sha256(parent.read_bytes()).hexdigest() == json.loads((integration / 'baseline-build.json').read_text())['native_sha256']
trace = []
before = {}
for variant in ['recursive-parent', 'metadata-this', 'both', 'both-global-set']:
    for negative in [False, True]:
        name = variant + ('-negative' if negative else '-positive')
        project = root / name
        previous = original / ('collection-factory-negative' if negative else 'collection-factory-positive')
        for relative in ['tsconfig.json', 'src/util.d.ts', 'src/factory.ts']:
            run.write(project / relative, (previous / relative).read_text())
        run.generate_minimal_lib(project)
        source = (previous / 'src/main.ts').read_text()
        if variant in ['recursive-parent', 'both', 'both-global-set']:
            source = source.replace('bag:Record<string,unknown>;', 'bag:Record<string,unknown>;parent?:Base<O,I>;')
        if variant in ['metadata-this', 'both', 'both-global-set']:
            source = source.replace('interface Base<O=', 'interface Metadata<O,I>{readonly types?:{output:O;input:I};validate(value:unknown):{value:O};}\ntype MetadataOf<T extends Base>=Metadata<T["state"]["output"],T["state"]["input"]>;\ninterface Base<O=')
            source = source.replace('{state:S;}', '{state:S;metadata:MetadataOf<this>;}')
        if variant == 'both-global-set':
            source = source.replace('declare class Collection<T>{add(value:T):this;has(value:T):boolean;}\n', '')
            source = source.replace('traits:Collection<string>;', 'traits:Set<string>;')
            library = project / 'src/lib.d.ts'
            run.write(library, library.read_text() + 'interface Set<T>{add(value:T):this;has(value:T):boolean;}\n')
        run.write(project / 'src/main.ts', source)
        before[name] = competitors.inventory_hash(competitors.payload_inventory(project))
        commands = run.compiler_commands()
        commands['home'] = [str(candidate)]
        commands['parent'] = [str(parent)]
        for compiler, command in commands.items():
            result, passed = run.admission_process(compiler, command + ['--noEmit', '-p', str(project / 'tsconfig.json')],
                name, expected_codes=['2322', '2339'] if negative else None, trace=trace)
            (root / 'results.json').write_text(json.dumps({'records': trace, 'before': before, 'timings_taken': False}, indent=2) + '\n')
            print(name, compiler, result.returncode, passed, trace[-1]['codes'], flush=True)
after = {name: competitors.inventory_hash(competitors.payload_inventory(root / name)) for name in before}
assert before == after
summary = {'records': trace, 'before': before, 'after': after, 'timings_taken': False,
           'candidate_sha256': build['native_sha256'], 'parent_sha256': hashlib.sha256(parent.read_bytes()).hexdigest(),
           'reference_controls_valid': all(row['passed'] for row in trace if row['compiler'] in ['tsc', 'tsgo'])}
(root / 'results.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({'checks': len(trace), 'passed': sum(row['passed'] for row in trace), 'reference_controls_valid': summary['reference_controls_valid']}), flush=True)
