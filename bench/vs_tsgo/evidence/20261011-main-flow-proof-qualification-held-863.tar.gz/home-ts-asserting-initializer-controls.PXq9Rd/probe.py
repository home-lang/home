import hashlib
import json
from pathlib import Path
import sys

root = Path(__file__).resolve().parent
integration = Path('/Users/chris/.cache/home-ts-main-flow-proof-integration.dYlSre')
original = Path('/Users/chris/.cache/home-ts-callable-intersection-facts.34PC25')
runner = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
sys.path.insert(0, str(runner / 'bench/vs_tsgo'))
import run
import competitors

assert not (root / 'results.json').exists()
candidate = integration / 'candidate-home-tsc'
parent = integration / 'baseline-home-tsc'
assert hashlib.sha256(candidate.read_bytes()).hexdigest() == json.loads((integration / 'candidate-build.json').read_text())['native_sha256']
trace = []
before = {}
for variant in ['none', 'assert-before', 'assert-after', 'assert-in-loop']:
    for negative in [False, True]:
        name = variant + ('-negative' if negative else '-positive')
        project = root / name
        prior = original / ('collection-factory-negative' if negative else 'collection-factory-positive')
        for relative in ['tsconfig.json', 'src/util.d.ts']:
            run.write(project / relative, (prior / relative).read_text())
        run.generate_minimal_lib(project)
        owner = (prior / 'src/factory.ts').read_text()
        owner += 'export interface Root{state:{def:{kind:string};};}\nexport declare const base:Creator<Root>;\n'
        run.write(project / 'src/factory.ts', owner)
        source = (prior / 'src/main.ts').read_text()
        assertion = 'factory.base.init(instance,def);'
        if variant == 'assert-before':
            source = source.replace(' for(const part', ' ' + assertion + '\n for(const part')
        if variant == 'assert-after':
            source = source.replace(' void instance;', ' ' + assertion + '\n void instance;')
        if variant == 'assert-in-loop':
            source = source.replace('part!==null){', 'part!==null){' + assertion)
        run.write(project / 'src/main.ts', source)
        before[name] = competitors.inventory_hash(competitors.payload_inventory(project))
        commands = run.compiler_commands()
        commands['home'] = [str(candidate)]
        commands['parent'] = [str(parent)]
        for compiler, command in commands.items():
            result, passed = run.admission_process(compiler, command + ['--noEmit', '-p', str(project / 'tsconfig.json')],
                name, expected_codes=['2322', '2339'] if negative else None, trace=trace)
            (root / 'results.json').write_text(json.dumps({'records': trace, 'before': before, 'timings_taken': False}, indent=2) + '\n')
            print(name, compiler, result.returncode, passed, trace[-1]['codes'], flush=True)
after = {name: competitors.inventory_hash(competitors.payload_inventory(root / name)) for name in before}
assert before == after
(root / 'results.json').write_text(json.dumps({'records': trace, 'before': before, 'after': after,
    'reference_controls_valid': all(row['passed'] for row in trace if row['compiler'] in ['tsc', 'tsgo']), 'timings_taken': False}, indent=2) + '\n')
