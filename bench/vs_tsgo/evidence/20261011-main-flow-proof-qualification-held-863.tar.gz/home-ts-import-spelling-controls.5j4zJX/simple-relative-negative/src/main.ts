import type * as api from "./owner";
interface Derived extends api.Base<number>{}
declare const value:Derived;
const count:string=value.value;
value.missing;
void count;
