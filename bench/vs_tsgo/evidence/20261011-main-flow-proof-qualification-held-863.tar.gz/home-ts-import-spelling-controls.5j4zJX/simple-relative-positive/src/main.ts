import type * as api from "./owner";
interface Derived extends api.Base<number>{}
declare const value:Derived;
const count:number=value.value;
void count;
