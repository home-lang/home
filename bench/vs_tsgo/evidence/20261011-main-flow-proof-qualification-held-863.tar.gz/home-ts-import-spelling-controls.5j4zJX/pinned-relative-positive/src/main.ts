import type * as schema from "../../../home-ts-zod-admission.RzJCwi/source/package/src/v4/core/schemas.js";
import * as core from "../../../home-ts-zod-admission.RzJCwi/source/package/src/v4/core/core.js";
type LiteralPart=string|number|bigint|boolean|null|undefined;
interface TokenState extends schema.$ZodTypeInternals<LiteralPart,LiteralPart>{pattern:RegExp;}
interface Token extends schema.$ZodType{_zod:TokenState;}
type Part=LiteralPart|Token;
declare const def:{parts:Part[];};
for(const part of def.parts)if(typeof part==="object"&&part!==null){const pattern:RegExp=part._zod.pattern;void pattern;}
