import type * as api from "/Users/chris/.cache/home-ts-import-spelling-controls.5j4zJX/simple-absolute-negative/src/owner";
interface Derived extends api.Base<number>{}
declare const value:Derived;
const count:string=value.value;
value.missing;
void count;
