export interface Base<T=string>{value:T;}
export declare const Base:{new():Base;};
