import type * as api from "/Users/chris/.cache/home-ts-import-spelling-controls.5j4zJX/simple-absolute-positive/src/owner";
interface Derived extends api.Base<number>{}
declare const value:Derived;
const count:number=value.value;
void count;
