import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

root = Path(__file__).resolve().parent
integration = Path('/Users/chris/.cache/home-ts-main-flow-proof-integration.dYlSre')
pinned = Path('/Users/chris/.cache/home-ts-pinned-base-probes.YDPfnt')
package = Path('/Users/chris/.cache/home-ts-zod-admission.RzJCwi/source/package')
runner = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
sys.path.insert(0, str(runner / 'bench/vs_tsgo'))
import run
import competitors

assert not (root / 'results.json').exists()
candidate = integration / 'candidate-home-tsc'
parent = integration / 'baseline-home-tsc'
assert hashlib.sha256(candidate.read_bytes()).hexdigest() == json.loads((integration / 'candidate-build.json').read_text())['native_sha256']
library_before = competitors.inventory_hash(competitors.payload_inventory(package))
records = []
before = {}
for family in ['simple', 'pinned']:
    for spelling in ['relative', 'absolute']:
        for negative in [False, True]:
            name = family + '-' + spelling + ('-negative' if negative else '-positive')
            project = root / name
            if family == 'simple':
                run.write(project / 'tsconfig.json', run.shared_config())
                run.generate_minimal_lib(project)
                run.write(project / 'src/owner.ts', 'export interface Base<T=string>{value:T;}\nexport declare const Base:{new():Base;};\n')
                specifier = './owner' if spelling == 'relative' else str(project / 'src/owner.ts')
                if spelling == 'absolute':
                    specifier = specifier[:-3]
                source = f'import type * as api from "{specifier}";\ninterface Derived extends api.Base<number>{{}}\ndeclare const value:Derived;\nconst count:' + ('string' if negative else 'number') + '=value.value;\n'
                if negative:
                    source += 'value.missing;\n'
                source += 'void count;\n'
            else:
                prior = pinned / ('derived-parts-negative' if negative else 'derived-parts-positive')
                for relative in ['tsconfig.json', 'package.json']:
                    run.write(project / relative, (prior / relative).read_text())
                source = (prior / 'src/main.ts').read_text()
                if spelling == 'relative':
                    for filename in ['schemas.js', 'core.js']:
                        absolute = package / 'src/v4/core' / filename
                        relative = os.path.relpath(absolute, project / 'src')
                        assert relative.startswith('.')
                        source = source.replace(str(absolute), relative)
            run.write(project / 'src/main.ts', source)
            before[name] = competitors.inventory_hash(competitors.payload_inventory(project))
            commands = run.compiler_commands()
            commands['home'] = [str(candidate)]
            commands['parent'] = [str(parent)]
            for compiler, command in commands.items():
                argv = command + ['--noEmit', '-p', str(project / 'tsconfig.json')]
                result = subprocess.run(argv, capture_output=True, text=True)
                output = result.stdout + result.stderr
                codes = re.findall(r'\bTS(\d+):', output)
                local_lines = [line for line in output.splitlines() if str(project / 'src/main.ts') in line or ('src/main.ts(' in line and compiler in ['tsc', 'tsgo'])]
                local_codes = re.findall(r'\bTS(\d+):', '\n'.join(local_lines))
                expected = ['2322', '2339'] if negative else []
                reference_valid = sorted(codes) == sorted(expected) if compiler in ['tsc', 'tsgo'] else None
                records.append({'workload': name, 'compiler': compiler, 'command': argv, 'exit': result.returncode,
                    'stdout': result.stdout, 'stderr': result.stderr, 'all_codes': codes, 'consumer_codes': local_codes,
                    'reference_control_valid': reference_valid, 'timings_taken': False})
                (root / 'results.json').write_text(json.dumps({'records': records, 'before': before, 'library_before': library_before, 'timings_taken': False}, indent=2) + '\n')
                print(name, compiler, result.returncode, 'all', len(codes), 'consumer', local_codes, 'reference', reference_valid, flush=True)
after = {name: competitors.inventory_hash(competitors.payload_inventory(root / name)) for name in before}
library_after = competitors.inventory_hash(competitors.payload_inventory(package))
assert before == after and library_before == library_after
(root / 'results.json').write_text(json.dumps({'records': records, 'before': before, 'after': after,
    'library_before': library_before, 'library_after': library_after, 'timings_taken': False,
    'scope': 'Import-spelling diagnostic comparison only; all full outputs retained; original library files unchanged'}, indent=2) + '\n')
