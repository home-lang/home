export interface Base<O=string>{state:{value:O};marker:`prefix-${string}`;}
export declare const Base:{new():Base;};
