type Marker<N extends string>=`prefix-${N}`;
export interface Base<O=string>{state:{value:O};marker:Marker<"fixed">;}
export declare const Base:{new():Base;};
