import type * as api from "./owner";
interface Derived extends api.Base<number>{}
declare const model:Derived;
const value:string=model.state.value;
model.missing;
void value;
