export interface Base<O=string>{state:{value:O};marker:string;}
export declare const Base:{new():Base;};
