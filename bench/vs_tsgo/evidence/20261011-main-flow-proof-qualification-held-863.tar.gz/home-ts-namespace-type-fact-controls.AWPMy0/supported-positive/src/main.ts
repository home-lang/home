import type * as api from "./owner";
interface Derived extends api.Base<number>{}
declare const model:Derived;
const value:number=model.state.value;
void value;
