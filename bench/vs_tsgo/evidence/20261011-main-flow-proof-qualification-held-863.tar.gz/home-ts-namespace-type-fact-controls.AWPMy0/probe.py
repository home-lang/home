import hashlib
import json
from pathlib import Path
import sys

root = Path(__file__).resolve().parent
integration = Path('/Users/chris/.cache/home-ts-main-flow-proof-integration.dYlSre')
runner = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
sys.path.insert(0, str(runner / 'bench/vs_tsgo'))
import run
import competitors

assert not (root / 'results.json').exists()
candidate = integration / 'candidate-home-tsc'
parent = integration / 'baseline-home-tsc'
assert hashlib.sha256(candidate.read_bytes()).hexdigest() == json.loads((integration / 'candidate-build.json').read_text())['native_sha256']
trace = []
before = {}
for variant in ['supported', 'template-member', 'template-alias']:
    for negative in [False, True]:
        name = variant + ('-negative' if negative else '-positive')
        project = root / name
        run.write(project / 'tsconfig.json', run.shared_config())
        run.generate_minimal_lib(project)
        marker = 'string' if variant == 'supported' else '`prefix-${string}`' if variant == 'template-member' else 'Marker<"fixed">'
        owner = 'type Marker<N extends string>=`prefix-${N}`;\n' if variant == 'template-alias' else ''
        owner += f'export interface Base<O=string>{{state:{{value:O}};marker:{marker};}}\nexport declare const Base:{{new():Base;}};\n'
        run.write(project / 'src/owner.ts', owner)
        source = 'import type * as api from "./owner";\ninterface Derived extends api.Base<number>{}\ndeclare const model:Derived;\n'
        source += 'const value:' + ('string' if negative else 'number') + '=model.state.value;\n'
        if negative:
            source += 'model.missing;\n'
        source += 'void value;\n'
        run.write(project / 'src/main.ts', source)
        before[name] = competitors.inventory_hash(competitors.payload_inventory(project))
        commands = run.compiler_commands()
        commands['home'] = [str(candidate)]
        commands['parent'] = [str(parent)]
        for compiler, command in commands.items():
            result, passed = run.admission_process(compiler, command + ['--noEmit', '-p', str(project / 'tsconfig.json')],
                name, expected_codes=['2322', '2339'] if negative else None, trace=trace)
            (root / 'results.json').write_text(json.dumps({'records': trace, 'before': before, 'timings_taken': False}, indent=2) + '\n')
            print(name, compiler, result.returncode, passed, trace[-1]['codes'], flush=True)
after = {name: competitors.inventory_hash(competitors.payload_inventory(root / name)) for name in before}
assert before == after
(root / 'results.json').write_text(json.dumps({'records': trace, 'before': before, 'after': after, 'timings_taken': False,
    'references_valid': all(row['passed'] for row in trace if row['compiler'] in ['tsc', 'tsgo'])}, indent=2) + '\n')
