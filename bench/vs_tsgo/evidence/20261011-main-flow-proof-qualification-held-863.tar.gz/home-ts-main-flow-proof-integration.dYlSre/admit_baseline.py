import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

root = Path(__file__).resolve().parent
old = Path('/Users/chris/.cache/home-ts-context-flow-proof-invalidation.k02vkc')
runner_repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
sys.path.insert(0, str(runner_repo / 'bench/vs_tsgo'))
import run
import competitors

build = json.loads((root / 'baseline-build.json').read_text())
assert build['exit'] == 0
binary = root / 'baseline-home-tsc'
assert hashlib.sha256(binary.read_bytes()).hexdigest() == build['native_sha256']
assert not (root / 'baseline-diagnostics.json').exists()
prior = json.loads((old / 'diagnostic-admission.json').read_text())
assert prior['passed'] and len(prior['records']) == 168
cases = []
for row in prior['records']:
    if row['compiler'] != 'tsc':
        continue
    command = row['command']
    project = Path(command[command.index('-p') + 1]).parent
    cases.append((row['workload'], project, row['expected_codes']))
assert len(cases) == 56
before = {name: competitors.inventory_hash(competitors.payload_inventory(project)) for name, project, _ in cases}
assert before == prior['after']
trace = []
record = {'source_revision': build['source_revision'], 'native_sha256': build['native_sha256'],
          'before': before, 'records': trace, 'timings_taken': False}
for name, project, codes in cases:
    result, passed = run.admission_process('home', [str(binary), '--noEmit', '-p', str(project / 'tsconfig.json')],
                                          name, expected_codes=codes, trace=trace)
    (root / 'baseline-diagnostics.json').write_text(json.dumps(record, indent=2) + '\n')
    print(name, result.returncode, passed, trace[-1]['codes'], flush=True)
after = {name: competitors.inventory_hash(competitors.payload_inventory(project)) for name, project, _ in cases}
assert before == after
record.update(after=after, passed=sum(row['passed'] for row in trace), failed=sum(not row['passed'] for row in trace),
              interpretation='Retain baseline failures; not candidate qualification')
(root / 'baseline-diagnostics.json').write_text(json.dumps(record, indent=2) + '\n')
zod_root = Path('/Users/chris/.cache/home-ts-zod-admission.RzJCwi/source/package')
zod_before = competitors.inventory_hash(competitors.payload_inventory(zod_root))
command = [str(binary), '--noEmit', '-p', str(zod_root / 'tsconfig.benchmark.json'), '--home-list-unmodeled-any']
result = subprocess.run(command, capture_output=True, text=True)
output = result.stdout + result.stderr
counts = {code: len(re.findall(r'\b' + code + r':', output)) for code in sorted(set(re.findall(r'\b((?:TS|HM)\d+):', output)))}
zod_after = competitors.inventory_hash(competitors.payload_inventory(zod_root))
assert zod_before == zod_after
(root / 'baseline-zod.json').write_text(json.dumps({'command': command, 'exit': result.returncode, 'stdout': result.stdout,
    'stderr': result.stderr, 'counts': counts, 'before': zod_before, 'after': zod_after,
    'native_sha256': build['native_sha256'], 'timings_taken': False, 'admitted': result.returncode == 0 and output == ''}, indent=2) + '\n')
print(json.dumps({'diagnostic_passed': record['passed'], 'diagnostic_failed': record['failed'], 'zod_exit': result.returncode, 'zod_counts': counts}), flush=True)
