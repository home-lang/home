import difflib
import json
from pathlib import Path
import re
import subprocess

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts863-qualification-docs/lang')
qualified = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
assert json.loads((root / 'baseline-build.json').read_text())['exit'] == 0
assert (root / 'baseline-zod.json').exists()
assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=repo) == b''

def function(text, name):
    start = text.index('    fn ' + name + '(')
    end = text.index('\n    }\n', start) + len('\n    }\n')
    return text[start:end]

def test(text, name):
    start = text.index('test "' + name + '" {')
    end = text.index('\n}\n', start) + len('\n}\n')
    return text[start:end]

def apply(path, before, after):
    diff = ''.join(list(difflib.unified_diff(before.splitlines(True), after.splitlines(True)))[2:])
    diff = re.sub(r'^@@.*@@.*$', '@@', diff, flags=re.M)
    subprocess.run(['apply_patch', '*** Begin Patch\n*** Update File: ' + str(path) + '\n' + diff + '*** End Patch\n'], check=True, cwd=repo)

checker_path = Path('packages/ts_checker/src/check.zig')
before = (repo / checker_path).read_text()
old = (qualified / checker_path).read_text()
after = before
replace = ['contextualCallArgumentType', 'iterableElementType', 'applyLogicalAssignmentFlow',
           'narrowTypeByTypeofComparison', 'contextualParameterTypeForSignature', 'lookupObjectMember',
           'resolveExactIndexedAccessForArgument', 'clearCachedTypesWithin', 'clearCachedTypesWithinSlow']
for name in replace:
    after = after.replace(function(after, name), function(old, name), 1)
after = after.replace('    fn narrowTypeByTypeofComparison(', function(old, 'typeofObjectMemberIsDefinitelyCallable') + '\n    fn narrowTypeByTypeofComparison(', 1)
helpers = function(old, 'concreteIndexedContextObject') + '\n' + function(old, 'concreteIndexedContextObjectInner')
after = after.replace('    fn resolveExactIndexedAccessForArgument(', helpers + '\n    fn resolveExactIndexedAccessForArgument(', 1)
start = old.index('                const concrete_object = (try self.concreteIndexedContextObject(new_obj))')
end = old.index('                // A concrete exact member', start)
insertion = old[start:end]
needle = '            const new_idx = try self.substituteType(ia.index, subs);\n            if (!self.containsFreeTypeParameter(new_idx)) {\n'
assert after.count(needle) == 1
after = after.replace(needle, needle + insertion, 1)
# Root==node also owns a flow proof in the fallback clearing path.
slow = function(after, 'clearCachedTypesWithinSlow')
root_branch = '                self.hir.setType(node, types.Primitive.none);\n                continue;'
assert root_branch in slow
slow = slow.replace(root_branch, '                self.hir.setType(node, types.Primitive.none);\n                _ = self.resolved_flow_member_accesses.remove(node);\n                continue;', 1)
after = after.replace(function(after, 'clearCachedTypesWithinSlow'), slow, 1)
checker_tests = [
    'checker: typeof object retains known nullable union members and checks their properties',
    'checker: logical assignment of a closed literal member does not widen its key domain',
    'checker: poststatement logical flow reuses checked result for identifiers and members',
    'checker: iterable elements resolve source-owned unions before member narrowing',
    'checker: typeof object excludes plain function constituents without losing object members',
    'checker: clearing contextual types invalidates only matching flow member proofs',
    'checker: exact nested indexed context ignores polymorphic this in an unrelated sibling',
]
for name in checker_tests:
    assert 'test "' + name + '"' not in before
    block = test(old, name)
    if 'clearing contextual types' in name:
        marker = '        try s.checker.reportPropertyDoesNotExistOnType('
        assert marker in block
        extra = '''        try s.checker.resolved_flow_member_accesses.put(T.allocator, inside, {});
        s.hir.setType(inside, types.Primitive.string_t);
        if (slow) s.checker.clearCachedTypesWithinSlow(inside) else s.checker.clearCachedTypesWithin(inside);
        try T.expect(!s.checker.resolved_flow_member_accesses.contains(inside));
        try T.expect(s.checker.resolved_flow_member_accesses.contains(outside));
        try T.expectEqual(types.Primitive.none, s.hir.typeOf(inside));
        try T.expectEqual(types.Primitive.string_t, s.hir.typeOf(outside));
'''
        block = block.replace(marker, extra + marker, 1)
    after += '\n' + block
assert 'std.debug.print' not in '\n'.join(line for line in difflib.unified_diff(before.splitlines(), after.splitlines()) if line.startswith('+'))
apply(checker_path, before, after)
program_path = Path('packages/ts_program/src/ts_program.zig')
before = (repo / program_path).read_text()
old = (qualified / program_path).read_text()
after = before
for name in ['Program: contextual generic factory callbacks retain dependent defaults and return parameter identity',
             'Program: collection polymorphic this does not erase dependent factory callback context']:
    assert 'test "' + name + '"' not in before
    after += '\n' + test(old, name)
apply(program_path, before, after)
print('Integrated missing qualified contextual behaviors; main Record/schema/builder implementation preserved; added root-proof invalidation oracle', flush=True)
