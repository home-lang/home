import hashlib
import json
from pathlib import Path
import shutil
import subprocess

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts863-qualification-docs/lang')
assert json.loads((root/'program.json').read_text())['exit'] == 0
assert json.loads((root/'checker.json').read_text())['exit'] == 0
assert subprocess.check_output(['git','diff'],cwd=repo).decode() == (root/'source.patch').read_text()
command = ['/Users/chris/Code/Home/lang-bun-port/zig-out/toolchains/zig-aarch64-macos-0.17.0-dev.2163+89ff10d56/zig',
           'build', 'home-tsc', '-Doptimize=ReleaseFast', '-Dhome-tsc-strip=true', '-Denable_jsc=false', '-j1', '--summary', 'all']
with (root / 'candidate-build.log').open('w') as output:
    result = subprocess.run(command, cwd=repo, stdout=output, stderr=subprocess.STDOUT)
record = {'command': command, 'exit': result.returncode,
          'source_parent': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip(),
          'source_patch': subprocess.check_output(['git', 'diff'], cwd=repo).decode()}
if result.returncode == 0:
    native = repo / 'zig-out/bin/home-tsc'
    record['native_sha256'] = hashlib.sha256(native.read_bytes()).hexdigest()
    frozen = root / 'candidate-home-tsc'
    assert not frozen.exists()
    shutil.copy2(native, frozen)
    assert hashlib.sha256(frozen.read_bytes()).hexdigest() == record['native_sha256']
(root / 'candidate-build.json').write_text(json.dumps(record, indent=2) + '\n')
print((root / 'candidate-build.log').read_text(), flush=True)
raise SystemExit(result.returncode)
