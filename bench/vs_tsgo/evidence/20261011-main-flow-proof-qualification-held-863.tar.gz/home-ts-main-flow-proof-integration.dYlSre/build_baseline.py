import hashlib
import json
from pathlib import Path
import shutil
import subprocess

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts863-qualification-docs/lang')
revision = '65a0332fe01d0b60a7a3387c9ebbc0aebaa789b2'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip() == revision
assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=repo) == b''
assert not (root / 'baseline-build.json').exists()
command = ['/Users/chris/Code/Home/lang-bun-port/zig-out/toolchains/zig-aarch64-macos-0.17.0-dev.2163+89ff10d56/zig',
           'build', 'home-tsc', '-Doptimize=ReleaseFast', '-Dhome-tsc-strip=true', '-Denable_jsc=false', '-j1', '--summary', 'all']
with (root / 'baseline-build.log').open('w') as output:
    result = subprocess.run(command, cwd=repo, stdout=output, stderr=subprocess.STDOUT)
record = {'source_revision': revision, 'command': command, 'exit': result.returncode, 'timings_taken': False,
          'purpose': 'Clean latest-main baseline including independently landed Record and #846 fixes'}
assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=repo) == b''
if result.returncode == 0:
    binary = root / 'baseline-home-tsc'
    shutil.copy2(repo / 'zig-out/bin/home-tsc', binary)
    record['native_sha256'] = hashlib.sha256(binary.read_bytes()).hexdigest()
(root / 'baseline-build.json').write_text(json.dumps(record, indent=2) + '\n')
print((root / 'baseline-build.log').read_text()[-3500:], flush=True)
print(json.dumps(record), flush=True)
raise SystemExit(result.returncode)
