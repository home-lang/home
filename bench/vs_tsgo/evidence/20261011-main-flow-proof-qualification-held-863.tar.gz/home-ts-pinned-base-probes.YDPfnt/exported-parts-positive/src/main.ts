import type * as schema from "/Users/chris/.cache/home-ts-zod-admission.RzJCwi/source/package/src/v4/core/schemas.js";
import * as core from "/Users/chris/.cache/home-ts-zod-admission.RzJCwi/source/package/src/v4/core/core.js";
declare const def:schema.$ZodTemplateLiteralDef;
for(const part of def.parts)if(typeof part==="object"&&part!==null){const pattern:RegExp=part._zod.pattern;void pattern;}
