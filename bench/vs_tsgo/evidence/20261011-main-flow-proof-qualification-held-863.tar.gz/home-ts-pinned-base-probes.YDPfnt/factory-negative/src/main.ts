import type * as schema from "/Users/chris/.cache/home-ts-zod-admission.RzJCwi/source/package/src/v4/core/schemas.js";
import * as core from "/Users/chris/.cache/home-ts-zod-admission.RzJCwi/source/package/src/v4/core/core.js";
type LiteralPart=string|number|bigint|boolean|null|undefined;
interface TokenState extends schema.$ZodTypeInternals<LiteralPart,LiteralPart>{pattern:RegExp;}
interface Token extends schema.$ZodType{_zod:TokenState;}
type Part=LiteralPart|Token;
interface ModelDef extends schema.$ZodTypeDef{type:"template_literal";parts:Part[];}
interface ModelState extends schema.$ZodTypeInternals<string,string>{def:ModelDef;pattern:RegExp;}
interface Model extends schema.$ZodType{_zod:ModelState;}
const result:core.$constructor<Model>=core.$constructor("model",(instance,def)=>{
for(const part of def.parts)if(typeof part==="object"&&part!==null){const pattern:number=part._zod.pattern;part.missing;void pattern;}
void instance;});void result;
