import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

root = Path(__file__).resolve().parent
integration = Path('/Users/chris/.cache/home-ts-main-flow-proof-integration.dYlSre')
package = Path('/Users/chris/.cache/home-ts-zod-admission.RzJCwi/source/package')
runner = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
sys.path.insert(0, str(runner / 'bench/vs_tsgo'))
import run
import competitors

assert not (root / 'results.json').exists()
before_library = competitors.inventory_hash(competitors.payload_inventory(package))
candidate = integration / 'candidate-home-tsc'
parent = integration / 'baseline-home-tsc'
assert hashlib.sha256(candidate.read_bytes()).hexdigest() == json.loads((integration / 'candidate-build.json').read_text())['native_sha256']
records = []
inputs = {}
for variant in ['exported-parts', 'derived-parts', 'factory']:
    for negative in [False, True]:
        name = variant + ('-negative' if negative else '-positive')
        project = root / name
        config = json.loads((package / 'tsconfig.benchmark.json').read_text())
        config['include'] = ['src/**/*.ts']
        config.pop('exclude', None)
        run.write(project / 'tsconfig.json', json.dumps(config, indent=2) + '\n')
        run.write(project / 'package.json', '{"type":"module"}\n')
        source = f'import type * as schema from "{package}/src/v4/core/schemas.js";\nimport * as core from "{package}/src/v4/core/core.js";\n'
        if variant != 'exported-parts':
            source += '''type LiteralPart=string|number|bigint|boolean|null|undefined;
interface TokenState extends schema.$ZodTypeInternals<LiteralPart,LiteralPart>{pattern:RegExp;}
interface Token extends schema.$ZodType{_zod:TokenState;}
type Part=LiteralPart|Token;
'''
        if variant == 'factory':
            source += '''interface ModelDef extends schema.$ZodTypeDef{type:"template_literal";parts:Part[];}
interface ModelState extends schema.$ZodTypeInternals<string,string>{def:ModelDef;pattern:RegExp;}
interface Model extends schema.$ZodType{_zod:ModelState;}
const result:core.$constructor<Model>=core.$constructor("model",(instance,def)=>{
'''
        else:
            source += 'declare const def:' + ('schema.$ZodTemplateLiteralDef' if variant == 'exported-parts' else '{parts:Part[];}') + ';\n'
        source += 'for(const part of def.parts)if(typeof part==="object"&&part!==null){'
        source += ('const pattern:number=part._zod.pattern;part.missing;' if negative else 'const pattern:RegExp=part._zod.pattern;')
        source += 'void pattern;}\n'
        if variant == 'factory':
            source += 'void instance;});void result;\n'
        run.write(project / 'src/main.ts', source)
        inputs[name] = competitors.inventory_hash(competitors.payload_inventory(project))
        commands = run.compiler_commands()
        commands['home'] = [str(candidate)]
        commands['parent'] = [str(parent)]
        for compiler, command in commands.items():
            argv = command + ['--noEmit', '-p', str(project / 'tsconfig.json')]
            result = subprocess.run(argv, capture_output=True, text=True)
            output = result.stdout + result.stderr
            codes = re.findall(r'\b(?:TS|HM)(\d+):', output)
            # Keep complete imported-graph output. Consumer-local codes are
            # diagnostic observations, not filtered project admission.
            local_lines = [line for line in output.splitlines() if str(project / 'src/main.ts') in line or ('src/main.ts(' in line and compiler in ['tsc', 'tsgo'])]
            local_codes = re.findall(r'\bTS(\d+):', '\n'.join(local_lines))
            expected = ['2322', '2339'] if negative else []
            reference_valid = result.returncode == (2 if compiler == 'tsc' and negative else 1 if compiler == 'tsgo' and negative else 0) and sorted(codes) == sorted(expected) if compiler in ['tsc', 'tsgo'] else None
            records.append({'compiler': compiler, 'workload': name, 'command': argv, 'exit': result.returncode,
                'stdout': result.stdout, 'stderr': result.stderr, 'all_codes': codes, 'consumer_codes': local_codes,
                'reference_control_valid': reference_valid, 'project_admitted': result.returncode == 0 and output == '' if not negative else False,
                'timings_taken': False})
            (root / 'results.json').write_text(json.dumps({'records': records, 'inputs': inputs, 'library_before': before_library, 'timings_taken': False}, indent=2) + '\n')
            print(name, compiler, result.returncode, 'total', len(codes), 'consumer', local_codes, 'reference', reference_valid, flush=True)
after_inputs = {name: competitors.inventory_hash(competitors.payload_inventory(root / name)) for name in inputs}
after_library = competitors.inventory_hash(competitors.payload_inventory(package))
assert inputs == after_inputs and before_library == after_library
(root / 'results.json').write_text(json.dumps({'records': records, 'inputs': inputs, 'after_inputs': after_inputs,
    'library_before': before_library, 'library_after': after_library, 'timings_taken': False,
    'scope': 'Same transitive pinned imports and strict configuration for every compiler; no original library edits or discarded diagnostics'}, indent=2) + '\n')
