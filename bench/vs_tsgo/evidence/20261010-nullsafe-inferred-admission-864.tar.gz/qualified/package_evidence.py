import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
previous = Path('/Users/chris/.cache/home-ts-record-matrix.SuDiXe')
verified = json.loads((root / 'verified-admission.json').read_text())
assert verified['passed'] and verified['admissions'] == 150 and verified['timings_taken'] is False
assert 'Ran 147 tests' in (root / 'harness.log').read_text() and (root / 'harness.log').read_text().rstrip().endswith('OK')
assert hashlib.sha256((repo / 'zig-out/bin/home-tsc').read_bytes()).hexdigest() == verified['native_sha256']
assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=repo).decode() == ''
source = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip()
assert source == '5a5db509af878cc8163fe680640e8b7d9e9ab1d6'
entries = {}
for name in ['admit.py', 'context.json', 'admission.jsonl', 'verified-admission.json', 'retain_harness.py',
             'harness.log', 'initial-unit-expectation-failure.json', 'package_evidence.py']:
    entries['qualified/' + name] = (root / name).read_bytes()
for name in ['audit_nullsafe_controls.py', 'nullsafe-control-audit.json']:
    entries['initial-probe/' + name] = (previous / name).read_bytes()
for directory, prefix in [(previous / 'nullsafe-negative-project', 'initial-negative-project'),
                          (repo / 'bench/vs_tsgo/corpus/null_safe_access', 'unchanged-timed-project')]:
    for path in sorted(directory.rglob('*')):
        if path.is_file():
            entries[prefix + '/' + str(path.relative_to(directory))] = path.read_bytes()
for name in ['run.py', 'compare.py', 'test_run.py', 'test_compare.py', 'competitors.py', 'corpus.toml']:
    entries['harness/' + name] = (repo / 'bench/vs_tsgo' / name).read_bytes()
entries['harness/darwin-arm64.json'] = (repo / 'bench/vs_tsgo/profiles/darwin-arm64.json').read_bytes()
publication = {'source_commit': source, 'qualified_context': json.loads((root / 'context.json').read_text())['source_parent'],
    'patch_sha256': verified['patch_sha256'], 'native_sha256': verified['native_sha256'],
    'validation_schema': 5, 'admissions': 150, 'nullsafe_errors_per_negative': 27,
    'harness_tests': 147, 'timings_taken': False, 'compiler_and_timed_corpus_unchanged': True,
    'old_protocol_four_results_not_relabeled': True, 'universal_leadership_proven': False}
entries['publication.json'] = (json.dumps(publication, indent=2) + '\n').encode()
checksums = {name: hashlib.sha256(data).hexdigest() for name, data in entries.items()}
entries['SHA256SUMS'] = ''.join(checksums[name] + '  ' + name + '\n' for name in sorted(checksums)).encode()
output = repo / 'bench/vs_tsgo/evidence/20261010-nullsafe-inferred-admission-864.tar.gz'
assert not output.exists()
with output.open('xb') as raw:
    with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as tar:
            for name, data in sorted(entries.items()):
                item = tarfile.TarInfo(name)
                item.size, item.mode = len(data), 0o644
                tar.addfile(item, io.BytesIO(data))
with tarfile.open(output, 'r:gz') as tar:
    for name, digest in checksums.items():
        assert hashlib.sha256(tar.extractfile(name).read()).hexdigest() == digest
result = {'archive': str(output.relative_to(repo)), 'sha256': hashlib.sha256(output.read_bytes()).hexdigest(),
          'payload_checksums': len(checksums), 'bytes': output.stat().st_size, 'verified': True}
(root / 'package-evidence.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result), flush=True)
