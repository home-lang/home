import hashlib
import json
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
sys.path.insert(0, str(repo / 'bench/vs_tsgo'))
import run
import compare
import competitors

expected = 'd58ddc54a147b3ad8b177a98a6b5cda04fd4df77595c5ccf44da690de5d57b32'
assert hashlib.sha256((repo / 'zig-out/bin/home-tsc').read_bytes()).hexdigest() == expected
profiles = competitors.load_profiles(repo / 'bench/vs_tsgo/profiles/darwin-arm64.json')
commands = run.compiler_commands(profiles)
versions = run.verified_compiler_versions(commands, profiles)
workloads = run.selected_workloads(None)
before = run.benchmark_provenance(commands, profiles)
trace = []
record = {'schema': 1, 'passed': False, 'before': before, 'after': None, 'records': trace}
context = {'validation_schema': 5, 'versions': versions, 'workloads': workloads, 'native_sha256': expected,
           'source_parent': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip(),
           'source_patch': subprocess.check_output(['git', 'diff'], cwd=repo).decode(), 'timings_taken': False}
(root / 'context.json').write_text(json.dumps(context, indent=2) + '\n')
try:
    for workload in workloads:
        run.validate(commands, workload, profiles=profiles, trace=trace)
        (root / 'admission.jsonl').write_text(json.dumps(record, indent=2) + '\n')
        print(workload, 'admitted', flush=True)
    after = run.benchmark_provenance(commands, profiles)
    assert after == before
    record['after'] = after
    assert len(trace) == 150 and all(row['passed'] for row in trace)
    record['passed'] = True
except BaseException as error:
    record['error'] = str(error)
    raise
finally:
    (root / 'admission.jsonl').write_text(json.dumps(record, indent=2) + '\n')
raw = (root / 'admission.jsonl').read_bytes()
metadata = {'validation_schema': 5, 'admission': {'path': 'admission.jsonl',
            'sha256': hashlib.sha256(raw).hexdigest(), 'records': 150},
            'provenance': {'status': 'verified', 'before': before, 'after': after}}
compare.validate_admission(root, metadata, list(commands), workloads)
nullsafe = [row for row in trace if row['workload'] == 'null_safe_access']
assert len(nullsafe) == 10
for row in nullsafe:
    if row['kind'] == 'negative':
        assert row['codes'] == sorted(['2322'] * 18 + ['2339', '2345', '2493'] * 3)
summary = {'passed': True, 'validation_schema': 5, 'admissions': 150, 'nullsafe_admissions': 10,
           'nullsafe_errors_per_negative': 27, 'native_sha256': expected,
           'timings_taken': False, 'corpus_and_compiler_provenance_unchanged': True,
           'patch_sha256': hashlib.sha256(context['source_patch'].encode()).hexdigest()}
(root / 'verified-admission.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary), flush=True)
