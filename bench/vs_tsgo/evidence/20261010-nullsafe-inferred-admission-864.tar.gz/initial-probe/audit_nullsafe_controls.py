"""Untimed proposed controls on actual inferred locals; timed corpus untouched."""
import hashlib
import json
from pathlib import Path
import shutil
import sys

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
sys.path.insert(0, str(repo / 'bench/vs_tsgo'))
import run
import competitors

native = repo / 'zig-out/bin/home-tsc'
assert hashlib.sha256(native.read_bytes()).hexdigest() == 'd58ddc54a147b3ad8b177a98a6b5cda04fd4df77595c5ccf44da690de5d57b32'
profiles = competitors.load_profiles(repo / 'bench/vs_tsgo/profiles/darwin-arm64.json')
commands = run.compiler_commands(profiles)
versions = run.verified_compiler_versions(commands, profiles)
original = repo / 'bench/vs_tsgo/corpus/null_safe_access'
before = {str(path.relative_to(original)): hashlib.sha256(path.read_bytes()).hexdigest()
          for path in original.rglob('*') if path.is_file()}
negative = root / 'nullsafe-negative-project'
assert not negative.exists()
shutil.copytree(original, negative)
source = negative / 'src/null-safe-access.ts'
content = source.read_text()
families = run.manifest()['generated']['null_safe_access_families']
indices = sorted({0, families // 2, families - 1})
for index in indices:
    start = content.index('function readNullable' + str(index) + '(')
    anchor = content.index('  const fallback = value!.fallback;', start)
    controls = '''  const invalidLabel: boolean = label;
  const invalidScore: string = score;
  const invalidFormatted: number = formatted;
  const invalidFallback: number = value!.fallback;
  const invalidOptionalLabel: string = value?.profile?.label;
  const invalidOptionalCall: string = value?.profile?.format?.(label);
  value?.profile?.format?.(123);
  value?.profile?.metrics?.[2];
  value?.profile?.missing;
  void invalidLabel; void invalidScore; void invalidFormatted;
  void invalidFallback; void invalidOptionalLabel; void invalidOptionalCall;
'''
    content = content[:anchor] + controls + content[anchor:]
run.write(source, content)
expected = sorted(['2322'] * (6 * len(indices)) + ['2339', '2345', '2493'] * len(indices))
trace = []
record = {'versions': versions, 'indices': indices, 'expected_codes': expected,
          'timings_taken': False, 'original_input_hashes': before, 'records': trace}
for name, command in commands.items():
    profile = profiles.get(name)
    result, passed = run.admission_process(name, command + ['--noEmit', '-p', str(original / 'tsconfig.json')],
        'null_safe_access', positive_output=profile.positive_output if profile else 'silent', trace=trace)
    result, passed = run.admission_process(name, command + ['--noEmit', '-p', str(negative / 'tsconfig.json')],
        'null_safe_access', expected_codes=expected, trace=trace)
    (root / 'nullsafe-control-audit.json').write_text(json.dumps(record, indent=2) + '\n')
    print(name, 'negative exit', result.returncode, 'passed', passed, flush=True)
after = {str(path.relative_to(original)): hashlib.sha256(path.read_bytes()).hexdigest()
         for path in original.rglob('*') if path.is_file()}
assert after == before
record['original_inputs_unchanged'] = True
record['all_controls_passed'] = all(row['passed'] for row in trace)
(root / 'nullsafe-control-audit.json').write_text(json.dumps(record, indent=2) + '\n')
print('Proposed controls only; failures retained; no new timing or compiler change.', flush=True)
