interface NullableRecord0 {
  readonly id: 0;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable0(
  value: NullableRecord0 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-0";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const invalidLabel: boolean = label;
  const invalidScore: string = score;
  const invalidFormatted: number = formatted;
  const invalidFallback: number = value!.fallback;
  const invalidOptionalLabel: string = value?.profile?.label;
  const invalidOptionalCall: string = value?.profile?.format?.(label);
  value?.profile?.format?.(123);
  value?.profile?.metrics?.[2];
  value?.profile?.missing;
  void invalidLabel; void invalidScore; void invalidFormatted;
  void invalidFallback; void invalidOptionalLabel; void invalidOptionalCall;
  const fallback = value!.fallback;
  return [value?.id ?? 0, label, score, formatted, fallback];
}

const nullableInput0: NullableRecord0 = {
  id: 0,
  fallback: "fallback-0",
  profile: {
    label: "item-0",
    metrics: [0, 1],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult0: readonly [number, string, number, string, string] =
  readNullable0(nullableInput0);

interface NullableRecord1 {
  readonly id: 1;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable1(
  value: NullableRecord1 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-1";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 1, label, score, formatted, fallback];
}

const nullableInput1: NullableRecord1 = {
  id: 1,
  fallback: "fallback-1",
  profile: {
    label: "item-1",
    metrics: [1, 2],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult1: readonly [number, string, number, string, string] =
  readNullable1(nullableInput1);

interface NullableRecord2 {
  readonly id: 2;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable2(
  value: NullableRecord2 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-2";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 2, label, score, formatted, fallback];
}

const nullableInput2: NullableRecord2 = {
  id: 2,
  fallback: "fallback-2",
  profile: {
    label: "item-2",
    metrics: [2, 3],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult2: readonly [number, string, number, string, string] =
  readNullable2(nullableInput2);

interface NullableRecord3 {
  readonly id: 3;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable3(
  value: NullableRecord3 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-3";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 3, label, score, formatted, fallback];
}

const nullableInput3: NullableRecord3 = {
  id: 3,
  fallback: "fallback-3",
  profile: {
    label: "item-3",
    metrics: [3, 4],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult3: readonly [number, string, number, string, string] =
  readNullable3(nullableInput3);

interface NullableRecord4 {
  readonly id: 4;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable4(
  value: NullableRecord4 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-4";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 4, label, score, formatted, fallback];
}

const nullableInput4: NullableRecord4 = {
  id: 4,
  fallback: "fallback-4",
  profile: {
    label: "item-4",
    metrics: [4, 5],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult4: readonly [number, string, number, string, string] =
  readNullable4(nullableInput4);

interface NullableRecord5 {
  readonly id: 5;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable5(
  value: NullableRecord5 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-5";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 5, label, score, formatted, fallback];
}

const nullableInput5: NullableRecord5 = {
  id: 5,
  fallback: "fallback-5",
  profile: {
    label: "item-5",
    metrics: [5, 6],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult5: readonly [number, string, number, string, string] =
  readNullable5(nullableInput5);

interface NullableRecord6 {
  readonly id: 6;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable6(
  value: NullableRecord6 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-6";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 6, label, score, formatted, fallback];
}

const nullableInput6: NullableRecord6 = {
  id: 6,
  fallback: "fallback-6",
  profile: {
    label: "item-6",
    metrics: [6, 7],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult6: readonly [number, string, number, string, string] =
  readNullable6(nullableInput6);

interface NullableRecord7 {
  readonly id: 7;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable7(
  value: NullableRecord7 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-7";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 7, label, score, formatted, fallback];
}

const nullableInput7: NullableRecord7 = {
  id: 7,
  fallback: "fallback-7",
  profile: {
    label: "item-7",
    metrics: [7, 8],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult7: readonly [number, string, number, string, string] =
  readNullable7(nullableInput7);

interface NullableRecord8 {
  readonly id: 8;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable8(
  value: NullableRecord8 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-8";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 8, label, score, formatted, fallback];
}

const nullableInput8: NullableRecord8 = {
  id: 8,
  fallback: "fallback-8",
  profile: {
    label: "item-8",
    metrics: [8, 9],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult8: readonly [number, string, number, string, string] =
  readNullable8(nullableInput8);

interface NullableRecord9 {
  readonly id: 9;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable9(
  value: NullableRecord9 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-9";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 9, label, score, formatted, fallback];
}

const nullableInput9: NullableRecord9 = {
  id: 9,
  fallback: "fallback-9",
  profile: {
    label: "item-9",
    metrics: [9, 10],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult9: readonly [number, string, number, string, string] =
  readNullable9(nullableInput9);

interface NullableRecord10 {
  readonly id: 10;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable10(
  value: NullableRecord10 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-10";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 10, label, score, formatted, fallback];
}

const nullableInput10: NullableRecord10 = {
  id: 10,
  fallback: "fallback-10",
  profile: {
    label: "item-10",
    metrics: [10, 11],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult10: readonly [number, string, number, string, string] =
  readNullable10(nullableInput10);

interface NullableRecord11 {
  readonly id: 11;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable11(
  value: NullableRecord11 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-11";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 11, label, score, formatted, fallback];
}

const nullableInput11: NullableRecord11 = {
  id: 11,
  fallback: "fallback-11",
  profile: {
    label: "item-11",
    metrics: [11, 12],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult11: readonly [number, string, number, string, string] =
  readNullable11(nullableInput11);

interface NullableRecord12 {
  readonly id: 12;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable12(
  value: NullableRecord12 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-12";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 12, label, score, formatted, fallback];
}

const nullableInput12: NullableRecord12 = {
  id: 12,
  fallback: "fallback-12",
  profile: {
    label: "item-12",
    metrics: [12, 13],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult12: readonly [number, string, number, string, string] =
  readNullable12(nullableInput12);

interface NullableRecord13 {
  readonly id: 13;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable13(
  value: NullableRecord13 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-13";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 13, label, score, formatted, fallback];
}

const nullableInput13: NullableRecord13 = {
  id: 13,
  fallback: "fallback-13",
  profile: {
    label: "item-13",
    metrics: [13, 14],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult13: readonly [number, string, number, string, string] =
  readNullable13(nullableInput13);

interface NullableRecord14 {
  readonly id: 14;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable14(
  value: NullableRecord14 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-14";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 14, label, score, formatted, fallback];
}

const nullableInput14: NullableRecord14 = {
  id: 14,
  fallback: "fallback-14",
  profile: {
    label: "item-14",
    metrics: [14, 15],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult14: readonly [number, string, number, string, string] =
  readNullable14(nullableInput14);

interface NullableRecord15 {
  readonly id: 15;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable15(
  value: NullableRecord15 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-15";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 15, label, score, formatted, fallback];
}

const nullableInput15: NullableRecord15 = {
  id: 15,
  fallback: "fallback-15",
  profile: {
    label: "item-15",
    metrics: [15, 16],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult15: readonly [number, string, number, string, string] =
  readNullable15(nullableInput15);

interface NullableRecord16 {
  readonly id: 16;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable16(
  value: NullableRecord16 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-16";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 16, label, score, formatted, fallback];
}

const nullableInput16: NullableRecord16 = {
  id: 16,
  fallback: "fallback-16",
  profile: {
    label: "item-16",
    metrics: [16, 17],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult16: readonly [number, string, number, string, string] =
  readNullable16(nullableInput16);

interface NullableRecord17 {
  readonly id: 17;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable17(
  value: NullableRecord17 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-17";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 17, label, score, formatted, fallback];
}

const nullableInput17: NullableRecord17 = {
  id: 17,
  fallback: "fallback-17",
  profile: {
    label: "item-17",
    metrics: [17, 18],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult17: readonly [number, string, number, string, string] =
  readNullable17(nullableInput17);

interface NullableRecord18 {
  readonly id: 18;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable18(
  value: NullableRecord18 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-18";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 18, label, score, formatted, fallback];
}

const nullableInput18: NullableRecord18 = {
  id: 18,
  fallback: "fallback-18",
  profile: {
    label: "item-18",
    metrics: [18, 19],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult18: readonly [number, string, number, string, string] =
  readNullable18(nullableInput18);

interface NullableRecord19 {
  readonly id: 19;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable19(
  value: NullableRecord19 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-19";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 19, label, score, formatted, fallback];
}

const nullableInput19: NullableRecord19 = {
  id: 19,
  fallback: "fallback-19",
  profile: {
    label: "item-19",
    metrics: [19, 20],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult19: readonly [number, string, number, string, string] =
  readNullable19(nullableInput19);

interface NullableRecord20 {
  readonly id: 20;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable20(
  value: NullableRecord20 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-20";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 20, label, score, formatted, fallback];
}

const nullableInput20: NullableRecord20 = {
  id: 20,
  fallback: "fallback-20",
  profile: {
    label: "item-20",
    metrics: [20, 21],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult20: readonly [number, string, number, string, string] =
  readNullable20(nullableInput20);

interface NullableRecord21 {
  readonly id: 21;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable21(
  value: NullableRecord21 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-21";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 21, label, score, formatted, fallback];
}

const nullableInput21: NullableRecord21 = {
  id: 21,
  fallback: "fallback-21",
  profile: {
    label: "item-21",
    metrics: [21, 22],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult21: readonly [number, string, number, string, string] =
  readNullable21(nullableInput21);

interface NullableRecord22 {
  readonly id: 22;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable22(
  value: NullableRecord22 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-22";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 22, label, score, formatted, fallback];
}

const nullableInput22: NullableRecord22 = {
  id: 22,
  fallback: "fallback-22",
  profile: {
    label: "item-22",
    metrics: [22, 23],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult22: readonly [number, string, number, string, string] =
  readNullable22(nullableInput22);

interface NullableRecord23 {
  readonly id: 23;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable23(
  value: NullableRecord23 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-23";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 23, label, score, formatted, fallback];
}

const nullableInput23: NullableRecord23 = {
  id: 23,
  fallback: "fallback-23",
  profile: {
    label: "item-23",
    metrics: [23, 24],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult23: readonly [number, string, number, string, string] =
  readNullable23(nullableInput23);

interface NullableRecord24 {
  readonly id: 24;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable24(
  value: NullableRecord24 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-24";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 24, label, score, formatted, fallback];
}

const nullableInput24: NullableRecord24 = {
  id: 24,
  fallback: "fallback-24",
  profile: {
    label: "item-24",
    metrics: [24, 25],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult24: readonly [number, string, number, string, string] =
  readNullable24(nullableInput24);

interface NullableRecord25 {
  readonly id: 25;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable25(
  value: NullableRecord25 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-25";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 25, label, score, formatted, fallback];
}

const nullableInput25: NullableRecord25 = {
  id: 25,
  fallback: "fallback-25",
  profile: {
    label: "item-25",
    metrics: [25, 26],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult25: readonly [number, string, number, string, string] =
  readNullable25(nullableInput25);

interface NullableRecord26 {
  readonly id: 26;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable26(
  value: NullableRecord26 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-26";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 26, label, score, formatted, fallback];
}

const nullableInput26: NullableRecord26 = {
  id: 26,
  fallback: "fallback-26",
  profile: {
    label: "item-26",
    metrics: [26, 27],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult26: readonly [number, string, number, string, string] =
  readNullable26(nullableInput26);

interface NullableRecord27 {
  readonly id: 27;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable27(
  value: NullableRecord27 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-27";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 27, label, score, formatted, fallback];
}

const nullableInput27: NullableRecord27 = {
  id: 27,
  fallback: "fallback-27",
  profile: {
    label: "item-27",
    metrics: [27, 28],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult27: readonly [number, string, number, string, string] =
  readNullable27(nullableInput27);

interface NullableRecord28 {
  readonly id: 28;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable28(
  value: NullableRecord28 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-28";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 28, label, score, formatted, fallback];
}

const nullableInput28: NullableRecord28 = {
  id: 28,
  fallback: "fallback-28",
  profile: {
    label: "item-28",
    metrics: [28, 29],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult28: readonly [number, string, number, string, string] =
  readNullable28(nullableInput28);

interface NullableRecord29 {
  readonly id: 29;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable29(
  value: NullableRecord29 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-29";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 29, label, score, formatted, fallback];
}

const nullableInput29: NullableRecord29 = {
  id: 29,
  fallback: "fallback-29",
  profile: {
    label: "item-29",
    metrics: [29, 30],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult29: readonly [number, string, number, string, string] =
  readNullable29(nullableInput29);

interface NullableRecord30 {
  readonly id: 30;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable30(
  value: NullableRecord30 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-30";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 30, label, score, formatted, fallback];
}

const nullableInput30: NullableRecord30 = {
  id: 30,
  fallback: "fallback-30",
  profile: {
    label: "item-30",
    metrics: [30, 31],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult30: readonly [number, string, number, string, string] =
  readNullable30(nullableInput30);

interface NullableRecord31 {
  readonly id: 31;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable31(
  value: NullableRecord31 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-31";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 31, label, score, formatted, fallback];
}

const nullableInput31: NullableRecord31 = {
  id: 31,
  fallback: "fallback-31",
  profile: {
    label: "item-31",
    metrics: [31, 32],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult31: readonly [number, string, number, string, string] =
  readNullable31(nullableInput31);

interface NullableRecord32 {
  readonly id: 32;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable32(
  value: NullableRecord32 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-32";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 32, label, score, formatted, fallback];
}

const nullableInput32: NullableRecord32 = {
  id: 32,
  fallback: "fallback-32",
  profile: {
    label: "item-32",
    metrics: [32, 33],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult32: readonly [number, string, number, string, string] =
  readNullable32(nullableInput32);

interface NullableRecord33 {
  readonly id: 33;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable33(
  value: NullableRecord33 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-33";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 33, label, score, formatted, fallback];
}

const nullableInput33: NullableRecord33 = {
  id: 33,
  fallback: "fallback-33",
  profile: {
    label: "item-33",
    metrics: [33, 34],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult33: readonly [number, string, number, string, string] =
  readNullable33(nullableInput33);

interface NullableRecord34 {
  readonly id: 34;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable34(
  value: NullableRecord34 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-34";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 34, label, score, formatted, fallback];
}

const nullableInput34: NullableRecord34 = {
  id: 34,
  fallback: "fallback-34",
  profile: {
    label: "item-34",
    metrics: [34, 35],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult34: readonly [number, string, number, string, string] =
  readNullable34(nullableInput34);

interface NullableRecord35 {
  readonly id: 35;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable35(
  value: NullableRecord35 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-35";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 35, label, score, formatted, fallback];
}

const nullableInput35: NullableRecord35 = {
  id: 35,
  fallback: "fallback-35",
  profile: {
    label: "item-35",
    metrics: [35, 36],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult35: readonly [number, string, number, string, string] =
  readNullable35(nullableInput35);

interface NullableRecord36 {
  readonly id: 36;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable36(
  value: NullableRecord36 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-36";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 36, label, score, formatted, fallback];
}

const nullableInput36: NullableRecord36 = {
  id: 36,
  fallback: "fallback-36",
  profile: {
    label: "item-36",
    metrics: [36, 37],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult36: readonly [number, string, number, string, string] =
  readNullable36(nullableInput36);

interface NullableRecord37 {
  readonly id: 37;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable37(
  value: NullableRecord37 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-37";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 37, label, score, formatted, fallback];
}

const nullableInput37: NullableRecord37 = {
  id: 37,
  fallback: "fallback-37",
  profile: {
    label: "item-37",
    metrics: [37, 38],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult37: readonly [number, string, number, string, string] =
  readNullable37(nullableInput37);

interface NullableRecord38 {
  readonly id: 38;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable38(
  value: NullableRecord38 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-38";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 38, label, score, formatted, fallback];
}

const nullableInput38: NullableRecord38 = {
  id: 38,
  fallback: "fallback-38",
  profile: {
    label: "item-38",
    metrics: [38, 39],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult38: readonly [number, string, number, string, string] =
  readNullable38(nullableInput38);

interface NullableRecord39 {
  readonly id: 39;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable39(
  value: NullableRecord39 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-39";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 39, label, score, formatted, fallback];
}

const nullableInput39: NullableRecord39 = {
  id: 39,
  fallback: "fallback-39",
  profile: {
    label: "item-39",
    metrics: [39, 40],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult39: readonly [number, string, number, string, string] =
  readNullable39(nullableInput39);

interface NullableRecord40 {
  readonly id: 40;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable40(
  value: NullableRecord40 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-40";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 40, label, score, formatted, fallback];
}

const nullableInput40: NullableRecord40 = {
  id: 40,
  fallback: "fallback-40",
  profile: {
    label: "item-40",
    metrics: [40, 41],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult40: readonly [number, string, number, string, string] =
  readNullable40(nullableInput40);

interface NullableRecord41 {
  readonly id: 41;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable41(
  value: NullableRecord41 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-41";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 41, label, score, formatted, fallback];
}

const nullableInput41: NullableRecord41 = {
  id: 41,
  fallback: "fallback-41",
  profile: {
    label: "item-41",
    metrics: [41, 42],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult41: readonly [number, string, number, string, string] =
  readNullable41(nullableInput41);

interface NullableRecord42 {
  readonly id: 42;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable42(
  value: NullableRecord42 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-42";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 42, label, score, formatted, fallback];
}

const nullableInput42: NullableRecord42 = {
  id: 42,
  fallback: "fallback-42",
  profile: {
    label: "item-42",
    metrics: [42, 43],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult42: readonly [number, string, number, string, string] =
  readNullable42(nullableInput42);

interface NullableRecord43 {
  readonly id: 43;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable43(
  value: NullableRecord43 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-43";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 43, label, score, formatted, fallback];
}

const nullableInput43: NullableRecord43 = {
  id: 43,
  fallback: "fallback-43",
  profile: {
    label: "item-43",
    metrics: [43, 44],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult43: readonly [number, string, number, string, string] =
  readNullable43(nullableInput43);

interface NullableRecord44 {
  readonly id: 44;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable44(
  value: NullableRecord44 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-44";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 44, label, score, formatted, fallback];
}

const nullableInput44: NullableRecord44 = {
  id: 44,
  fallback: "fallback-44",
  profile: {
    label: "item-44",
    metrics: [44, 45],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult44: readonly [number, string, number, string, string] =
  readNullable44(nullableInput44);

interface NullableRecord45 {
  readonly id: 45;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable45(
  value: NullableRecord45 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-45";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 45, label, score, formatted, fallback];
}

const nullableInput45: NullableRecord45 = {
  id: 45,
  fallback: "fallback-45",
  profile: {
    label: "item-45",
    metrics: [45, 46],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult45: readonly [number, string, number, string, string] =
  readNullable45(nullableInput45);

interface NullableRecord46 {
  readonly id: 46;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable46(
  value: NullableRecord46 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-46";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 46, label, score, formatted, fallback];
}

const nullableInput46: NullableRecord46 = {
  id: 46,
  fallback: "fallback-46",
  profile: {
    label: "item-46",
    metrics: [46, 47],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult46: readonly [number, string, number, string, string] =
  readNullable46(nullableInput46);

interface NullableRecord47 {
  readonly id: 47;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable47(
  value: NullableRecord47 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-47";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 47, label, score, formatted, fallback];
}

const nullableInput47: NullableRecord47 = {
  id: 47,
  fallback: "fallback-47",
  profile: {
    label: "item-47",
    metrics: [47, 48],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult47: readonly [number, string, number, string, string] =
  readNullable47(nullableInput47);

interface NullableRecord48 {
  readonly id: 48;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable48(
  value: NullableRecord48 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-48";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 48, label, score, formatted, fallback];
}

const nullableInput48: NullableRecord48 = {
  id: 48,
  fallback: "fallback-48",
  profile: {
    label: "item-48",
    metrics: [48, 49],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult48: readonly [number, string, number, string, string] =
  readNullable48(nullableInput48);

interface NullableRecord49 {
  readonly id: 49;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable49(
  value: NullableRecord49 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-49";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 49, label, score, formatted, fallback];
}

const nullableInput49: NullableRecord49 = {
  id: 49,
  fallback: "fallback-49",
  profile: {
    label: "item-49",
    metrics: [49, 50],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult49: readonly [number, string, number, string, string] =
  readNullable49(nullableInput49);

interface NullableRecord50 {
  readonly id: 50;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable50(
  value: NullableRecord50 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-50";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 50, label, score, formatted, fallback];
}

const nullableInput50: NullableRecord50 = {
  id: 50,
  fallback: "fallback-50",
  profile: {
    label: "item-50",
    metrics: [50, 51],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult50: readonly [number, string, number, string, string] =
  readNullable50(nullableInput50);

interface NullableRecord51 {
  readonly id: 51;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable51(
  value: NullableRecord51 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-51";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 51, label, score, formatted, fallback];
}

const nullableInput51: NullableRecord51 = {
  id: 51,
  fallback: "fallback-51",
  profile: {
    label: "item-51",
    metrics: [51, 52],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult51: readonly [number, string, number, string, string] =
  readNullable51(nullableInput51);

interface NullableRecord52 {
  readonly id: 52;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable52(
  value: NullableRecord52 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-52";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 52, label, score, formatted, fallback];
}

const nullableInput52: NullableRecord52 = {
  id: 52,
  fallback: "fallback-52",
  profile: {
    label: "item-52",
    metrics: [52, 53],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult52: readonly [number, string, number, string, string] =
  readNullable52(nullableInput52);

interface NullableRecord53 {
  readonly id: 53;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable53(
  value: NullableRecord53 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-53";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 53, label, score, formatted, fallback];
}

const nullableInput53: NullableRecord53 = {
  id: 53,
  fallback: "fallback-53",
  profile: {
    label: "item-53",
    metrics: [53, 54],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult53: readonly [number, string, number, string, string] =
  readNullable53(nullableInput53);

interface NullableRecord54 {
  readonly id: 54;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable54(
  value: NullableRecord54 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-54";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 54, label, score, formatted, fallback];
}

const nullableInput54: NullableRecord54 = {
  id: 54,
  fallback: "fallback-54",
  profile: {
    label: "item-54",
    metrics: [54, 55],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult54: readonly [number, string, number, string, string] =
  readNullable54(nullableInput54);

interface NullableRecord55 {
  readonly id: 55;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable55(
  value: NullableRecord55 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-55";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 55, label, score, formatted, fallback];
}

const nullableInput55: NullableRecord55 = {
  id: 55,
  fallback: "fallback-55",
  profile: {
    label: "item-55",
    metrics: [55, 56],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult55: readonly [number, string, number, string, string] =
  readNullable55(nullableInput55);

interface NullableRecord56 {
  readonly id: 56;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable56(
  value: NullableRecord56 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-56";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 56, label, score, formatted, fallback];
}

const nullableInput56: NullableRecord56 = {
  id: 56,
  fallback: "fallback-56",
  profile: {
    label: "item-56",
    metrics: [56, 57],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult56: readonly [number, string, number, string, string] =
  readNullable56(nullableInput56);

interface NullableRecord57 {
  readonly id: 57;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable57(
  value: NullableRecord57 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-57";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 57, label, score, formatted, fallback];
}

const nullableInput57: NullableRecord57 = {
  id: 57,
  fallback: "fallback-57",
  profile: {
    label: "item-57",
    metrics: [57, 58],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult57: readonly [number, string, number, string, string] =
  readNullable57(nullableInput57);

interface NullableRecord58 {
  readonly id: 58;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable58(
  value: NullableRecord58 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-58";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 58, label, score, formatted, fallback];
}

const nullableInput58: NullableRecord58 = {
  id: 58,
  fallback: "fallback-58",
  profile: {
    label: "item-58",
    metrics: [58, 59],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult58: readonly [number, string, number, string, string] =
  readNullable58(nullableInput58);

interface NullableRecord59 {
  readonly id: 59;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable59(
  value: NullableRecord59 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-59";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 59, label, score, formatted, fallback];
}

const nullableInput59: NullableRecord59 = {
  id: 59,
  fallback: "fallback-59",
  profile: {
    label: "item-59",
    metrics: [59, 60],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult59: readonly [number, string, number, string, string] =
  readNullable59(nullableInput59);

interface NullableRecord60 {
  readonly id: 60;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable60(
  value: NullableRecord60 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-60";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 60, label, score, formatted, fallback];
}

const nullableInput60: NullableRecord60 = {
  id: 60,
  fallback: "fallback-60",
  profile: {
    label: "item-60",
    metrics: [60, 61],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult60: readonly [number, string, number, string, string] =
  readNullable60(nullableInput60);

interface NullableRecord61 {
  readonly id: 61;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable61(
  value: NullableRecord61 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-61";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 61, label, score, formatted, fallback];
}

const nullableInput61: NullableRecord61 = {
  id: 61,
  fallback: "fallback-61",
  profile: {
    label: "item-61",
    metrics: [61, 62],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult61: readonly [number, string, number, string, string] =
  readNullable61(nullableInput61);

interface NullableRecord62 {
  readonly id: 62;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable62(
  value: NullableRecord62 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-62";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 62, label, score, formatted, fallback];
}

const nullableInput62: NullableRecord62 = {
  id: 62,
  fallback: "fallback-62",
  profile: {
    label: "item-62",
    metrics: [62, 63],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult62: readonly [number, string, number, string, string] =
  readNullable62(nullableInput62);

interface NullableRecord63 {
  readonly id: 63;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable63(
  value: NullableRecord63 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-63";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 63, label, score, formatted, fallback];
}

const nullableInput63: NullableRecord63 = {
  id: 63,
  fallback: "fallback-63",
  profile: {
    label: "item-63",
    metrics: [63, 64],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult63: readonly [number, string, number, string, string] =
  readNullable63(nullableInput63);

interface NullableRecord64 {
  readonly id: 64;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable64(
  value: NullableRecord64 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-64";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 64, label, score, formatted, fallback];
}

const nullableInput64: NullableRecord64 = {
  id: 64,
  fallback: "fallback-64",
  profile: {
    label: "item-64",
    metrics: [64, 65],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult64: readonly [number, string, number, string, string] =
  readNullable64(nullableInput64);

interface NullableRecord65 {
  readonly id: 65;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable65(
  value: NullableRecord65 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-65";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 65, label, score, formatted, fallback];
}

const nullableInput65: NullableRecord65 = {
  id: 65,
  fallback: "fallback-65",
  profile: {
    label: "item-65",
    metrics: [65, 66],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult65: readonly [number, string, number, string, string] =
  readNullable65(nullableInput65);

interface NullableRecord66 {
  readonly id: 66;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable66(
  value: NullableRecord66 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-66";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 66, label, score, formatted, fallback];
}

const nullableInput66: NullableRecord66 = {
  id: 66,
  fallback: "fallback-66",
  profile: {
    label: "item-66",
    metrics: [66, 67],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult66: readonly [number, string, number, string, string] =
  readNullable66(nullableInput66);

interface NullableRecord67 {
  readonly id: 67;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable67(
  value: NullableRecord67 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-67";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 67, label, score, formatted, fallback];
}

const nullableInput67: NullableRecord67 = {
  id: 67,
  fallback: "fallback-67",
  profile: {
    label: "item-67",
    metrics: [67, 68],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult67: readonly [number, string, number, string, string] =
  readNullable67(nullableInput67);

interface NullableRecord68 {
  readonly id: 68;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable68(
  value: NullableRecord68 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-68";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 68, label, score, formatted, fallback];
}

const nullableInput68: NullableRecord68 = {
  id: 68,
  fallback: "fallback-68",
  profile: {
    label: "item-68",
    metrics: [68, 69],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult68: readonly [number, string, number, string, string] =
  readNullable68(nullableInput68);

interface NullableRecord69 {
  readonly id: 69;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable69(
  value: NullableRecord69 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-69";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 69, label, score, formatted, fallback];
}

const nullableInput69: NullableRecord69 = {
  id: 69,
  fallback: "fallback-69",
  profile: {
    label: "item-69",
    metrics: [69, 70],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult69: readonly [number, string, number, string, string] =
  readNullable69(nullableInput69);

interface NullableRecord70 {
  readonly id: 70;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable70(
  value: NullableRecord70 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-70";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 70, label, score, formatted, fallback];
}

const nullableInput70: NullableRecord70 = {
  id: 70,
  fallback: "fallback-70",
  profile: {
    label: "item-70",
    metrics: [70, 71],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult70: readonly [number, string, number, string, string] =
  readNullable70(nullableInput70);

interface NullableRecord71 {
  readonly id: 71;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable71(
  value: NullableRecord71 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-71";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 71, label, score, formatted, fallback];
}

const nullableInput71: NullableRecord71 = {
  id: 71,
  fallback: "fallback-71",
  profile: {
    label: "item-71",
    metrics: [71, 72],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult71: readonly [number, string, number, string, string] =
  readNullable71(nullableInput71);

interface NullableRecord72 {
  readonly id: 72;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable72(
  value: NullableRecord72 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-72";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 72, label, score, formatted, fallback];
}

const nullableInput72: NullableRecord72 = {
  id: 72,
  fallback: "fallback-72",
  profile: {
    label: "item-72",
    metrics: [72, 73],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult72: readonly [number, string, number, string, string] =
  readNullable72(nullableInput72);

interface NullableRecord73 {
  readonly id: 73;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable73(
  value: NullableRecord73 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-73";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 73, label, score, formatted, fallback];
}

const nullableInput73: NullableRecord73 = {
  id: 73,
  fallback: "fallback-73",
  profile: {
    label: "item-73",
    metrics: [73, 74],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult73: readonly [number, string, number, string, string] =
  readNullable73(nullableInput73);

interface NullableRecord74 {
  readonly id: 74;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable74(
  value: NullableRecord74 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-74";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 74, label, score, formatted, fallback];
}

const nullableInput74: NullableRecord74 = {
  id: 74,
  fallback: "fallback-74",
  profile: {
    label: "item-74",
    metrics: [74, 75],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult74: readonly [number, string, number, string, string] =
  readNullable74(nullableInput74);

interface NullableRecord75 {
  readonly id: 75;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable75(
  value: NullableRecord75 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-75";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 75, label, score, formatted, fallback];
}

const nullableInput75: NullableRecord75 = {
  id: 75,
  fallback: "fallback-75",
  profile: {
    label: "item-75",
    metrics: [75, 76],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult75: readonly [number, string, number, string, string] =
  readNullable75(nullableInput75);

interface NullableRecord76 {
  readonly id: 76;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable76(
  value: NullableRecord76 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-76";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 76, label, score, formatted, fallback];
}

const nullableInput76: NullableRecord76 = {
  id: 76,
  fallback: "fallback-76",
  profile: {
    label: "item-76",
    metrics: [76, 77],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult76: readonly [number, string, number, string, string] =
  readNullable76(nullableInput76);

interface NullableRecord77 {
  readonly id: 77;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable77(
  value: NullableRecord77 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-77";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 77, label, score, formatted, fallback];
}

const nullableInput77: NullableRecord77 = {
  id: 77,
  fallback: "fallback-77",
  profile: {
    label: "item-77",
    metrics: [77, 78],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult77: readonly [number, string, number, string, string] =
  readNullable77(nullableInput77);

interface NullableRecord78 {
  readonly id: 78;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable78(
  value: NullableRecord78 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-78";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 78, label, score, formatted, fallback];
}

const nullableInput78: NullableRecord78 = {
  id: 78,
  fallback: "fallback-78",
  profile: {
    label: "item-78",
    metrics: [78, 79],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult78: readonly [number, string, number, string, string] =
  readNullable78(nullableInput78);

interface NullableRecord79 {
  readonly id: 79;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable79(
  value: NullableRecord79 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-79";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 79, label, score, formatted, fallback];
}

const nullableInput79: NullableRecord79 = {
  id: 79,
  fallback: "fallback-79",
  profile: {
    label: "item-79",
    metrics: [79, 80],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult79: readonly [number, string, number, string, string] =
  readNullable79(nullableInput79);

interface NullableRecord80 {
  readonly id: 80;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable80(
  value: NullableRecord80 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-80";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 80, label, score, formatted, fallback];
}

const nullableInput80: NullableRecord80 = {
  id: 80,
  fallback: "fallback-80",
  profile: {
    label: "item-80",
    metrics: [80, 81],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult80: readonly [number, string, number, string, string] =
  readNullable80(nullableInput80);

interface NullableRecord81 {
  readonly id: 81;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable81(
  value: NullableRecord81 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-81";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 81, label, score, formatted, fallback];
}

const nullableInput81: NullableRecord81 = {
  id: 81,
  fallback: "fallback-81",
  profile: {
    label: "item-81",
    metrics: [81, 82],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult81: readonly [number, string, number, string, string] =
  readNullable81(nullableInput81);

interface NullableRecord82 {
  readonly id: 82;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable82(
  value: NullableRecord82 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-82";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 82, label, score, formatted, fallback];
}

const nullableInput82: NullableRecord82 = {
  id: 82,
  fallback: "fallback-82",
  profile: {
    label: "item-82",
    metrics: [82, 83],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult82: readonly [number, string, number, string, string] =
  readNullable82(nullableInput82);

interface NullableRecord83 {
  readonly id: 83;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable83(
  value: NullableRecord83 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-83";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 83, label, score, formatted, fallback];
}

const nullableInput83: NullableRecord83 = {
  id: 83,
  fallback: "fallback-83",
  profile: {
    label: "item-83",
    metrics: [83, 84],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult83: readonly [number, string, number, string, string] =
  readNullable83(nullableInput83);

interface NullableRecord84 {
  readonly id: 84;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable84(
  value: NullableRecord84 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-84";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 84, label, score, formatted, fallback];
}

const nullableInput84: NullableRecord84 = {
  id: 84,
  fallback: "fallback-84",
  profile: {
    label: "item-84",
    metrics: [84, 85],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult84: readonly [number, string, number, string, string] =
  readNullable84(nullableInput84);

interface NullableRecord85 {
  readonly id: 85;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable85(
  value: NullableRecord85 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-85";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 85, label, score, formatted, fallback];
}

const nullableInput85: NullableRecord85 = {
  id: 85,
  fallback: "fallback-85",
  profile: {
    label: "item-85",
    metrics: [85, 86],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult85: readonly [number, string, number, string, string] =
  readNullable85(nullableInput85);

interface NullableRecord86 {
  readonly id: 86;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable86(
  value: NullableRecord86 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-86";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 86, label, score, formatted, fallback];
}

const nullableInput86: NullableRecord86 = {
  id: 86,
  fallback: "fallback-86",
  profile: {
    label: "item-86",
    metrics: [86, 87],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult86: readonly [number, string, number, string, string] =
  readNullable86(nullableInput86);

interface NullableRecord87 {
  readonly id: 87;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable87(
  value: NullableRecord87 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-87";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 87, label, score, formatted, fallback];
}

const nullableInput87: NullableRecord87 = {
  id: 87,
  fallback: "fallback-87",
  profile: {
    label: "item-87",
    metrics: [87, 88],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult87: readonly [number, string, number, string, string] =
  readNullable87(nullableInput87);

interface NullableRecord88 {
  readonly id: 88;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable88(
  value: NullableRecord88 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-88";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 88, label, score, formatted, fallback];
}

const nullableInput88: NullableRecord88 = {
  id: 88,
  fallback: "fallback-88",
  profile: {
    label: "item-88",
    metrics: [88, 89],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult88: readonly [number, string, number, string, string] =
  readNullable88(nullableInput88);

interface NullableRecord89 {
  readonly id: 89;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable89(
  value: NullableRecord89 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-89";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 89, label, score, formatted, fallback];
}

const nullableInput89: NullableRecord89 = {
  id: 89,
  fallback: "fallback-89",
  profile: {
    label: "item-89",
    metrics: [89, 90],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult89: readonly [number, string, number, string, string] =
  readNullable89(nullableInput89);

interface NullableRecord90 {
  readonly id: 90;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable90(
  value: NullableRecord90 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-90";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 90, label, score, formatted, fallback];
}

const nullableInput90: NullableRecord90 = {
  id: 90,
  fallback: "fallback-90",
  profile: {
    label: "item-90",
    metrics: [90, 91],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult90: readonly [number, string, number, string, string] =
  readNullable90(nullableInput90);

interface NullableRecord91 {
  readonly id: 91;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable91(
  value: NullableRecord91 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-91";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 91, label, score, formatted, fallback];
}

const nullableInput91: NullableRecord91 = {
  id: 91,
  fallback: "fallback-91",
  profile: {
    label: "item-91",
    metrics: [91, 92],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult91: readonly [number, string, number, string, string] =
  readNullable91(nullableInput91);

interface NullableRecord92 {
  readonly id: 92;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable92(
  value: NullableRecord92 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-92";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 92, label, score, formatted, fallback];
}

const nullableInput92: NullableRecord92 = {
  id: 92,
  fallback: "fallback-92",
  profile: {
    label: "item-92",
    metrics: [92, 93],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult92: readonly [number, string, number, string, string] =
  readNullable92(nullableInput92);

interface NullableRecord93 {
  readonly id: 93;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable93(
  value: NullableRecord93 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-93";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 93, label, score, formatted, fallback];
}

const nullableInput93: NullableRecord93 = {
  id: 93,
  fallback: "fallback-93",
  profile: {
    label: "item-93",
    metrics: [93, 94],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult93: readonly [number, string, number, string, string] =
  readNullable93(nullableInput93);

interface NullableRecord94 {
  readonly id: 94;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable94(
  value: NullableRecord94 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-94";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 94, label, score, formatted, fallback];
}

const nullableInput94: NullableRecord94 = {
  id: 94,
  fallback: "fallback-94",
  profile: {
    label: "item-94",
    metrics: [94, 95],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult94: readonly [number, string, number, string, string] =
  readNullable94(nullableInput94);

interface NullableRecord95 {
  readonly id: 95;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable95(
  value: NullableRecord95 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-95";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 95, label, score, formatted, fallback];
}

const nullableInput95: NullableRecord95 = {
  id: 95,
  fallback: "fallback-95",
  profile: {
    label: "item-95",
    metrics: [95, 96],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult95: readonly [number, string, number, string, string] =
  readNullable95(nullableInput95);

interface NullableRecord96 {
  readonly id: 96;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable96(
  value: NullableRecord96 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-96";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 96, label, score, formatted, fallback];
}

const nullableInput96: NullableRecord96 = {
  id: 96,
  fallback: "fallback-96",
  profile: {
    label: "item-96",
    metrics: [96, 97],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult96: readonly [number, string, number, string, string] =
  readNullable96(nullableInput96);

interface NullableRecord97 {
  readonly id: 97;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable97(
  value: NullableRecord97 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-97";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 97, label, score, formatted, fallback];
}

const nullableInput97: NullableRecord97 = {
  id: 97,
  fallback: "fallback-97",
  profile: {
    label: "item-97",
    metrics: [97, 98],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult97: readonly [number, string, number, string, string] =
  readNullable97(nullableInput97);

interface NullableRecord98 {
  readonly id: 98;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable98(
  value: NullableRecord98 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-98";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 98, label, score, formatted, fallback];
}

const nullableInput98: NullableRecord98 = {
  id: 98,
  fallback: "fallback-98",
  profile: {
    label: "item-98",
    metrics: [98, 99],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult98: readonly [number, string, number, string, string] =
  readNullable98(nullableInput98);

interface NullableRecord99 {
  readonly id: 99;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable99(
  value: NullableRecord99 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-99";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 99, label, score, formatted, fallback];
}

const nullableInput99: NullableRecord99 = {
  id: 99,
  fallback: "fallback-99",
  profile: {
    label: "item-99",
    metrics: [99, 100],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult99: readonly [number, string, number, string, string] =
  readNullable99(nullableInput99);

interface NullableRecord100 {
  readonly id: 100;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable100(
  value: NullableRecord100 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-100";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 100, label, score, formatted, fallback];
}

const nullableInput100: NullableRecord100 = {
  id: 100,
  fallback: "fallback-100",
  profile: {
    label: "item-100",
    metrics: [100, 101],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult100: readonly [number, string, number, string, string] =
  readNullable100(nullableInput100);

interface NullableRecord101 {
  readonly id: 101;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable101(
  value: NullableRecord101 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-101";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 101, label, score, formatted, fallback];
}

const nullableInput101: NullableRecord101 = {
  id: 101,
  fallback: "fallback-101",
  profile: {
    label: "item-101",
    metrics: [101, 102],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult101: readonly [number, string, number, string, string] =
  readNullable101(nullableInput101);

interface NullableRecord102 {
  readonly id: 102;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable102(
  value: NullableRecord102 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-102";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 102, label, score, formatted, fallback];
}

const nullableInput102: NullableRecord102 = {
  id: 102,
  fallback: "fallback-102",
  profile: {
    label: "item-102",
    metrics: [102, 103],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult102: readonly [number, string, number, string, string] =
  readNullable102(nullableInput102);

interface NullableRecord103 {
  readonly id: 103;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable103(
  value: NullableRecord103 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-103";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 103, label, score, formatted, fallback];
}

const nullableInput103: NullableRecord103 = {
  id: 103,
  fallback: "fallback-103",
  profile: {
    label: "item-103",
    metrics: [103, 104],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult103: readonly [number, string, number, string, string] =
  readNullable103(nullableInput103);

interface NullableRecord104 {
  readonly id: 104;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable104(
  value: NullableRecord104 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-104";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 104, label, score, formatted, fallback];
}

const nullableInput104: NullableRecord104 = {
  id: 104,
  fallback: "fallback-104",
  profile: {
    label: "item-104",
    metrics: [104, 105],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult104: readonly [number, string, number, string, string] =
  readNullable104(nullableInput104);

interface NullableRecord105 {
  readonly id: 105;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable105(
  value: NullableRecord105 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-105";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 105, label, score, formatted, fallback];
}

const nullableInput105: NullableRecord105 = {
  id: 105,
  fallback: "fallback-105",
  profile: {
    label: "item-105",
    metrics: [105, 106],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult105: readonly [number, string, number, string, string] =
  readNullable105(nullableInput105);

interface NullableRecord106 {
  readonly id: 106;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable106(
  value: NullableRecord106 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-106";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 106, label, score, formatted, fallback];
}

const nullableInput106: NullableRecord106 = {
  id: 106,
  fallback: "fallback-106",
  profile: {
    label: "item-106",
    metrics: [106, 107],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult106: readonly [number, string, number, string, string] =
  readNullable106(nullableInput106);

interface NullableRecord107 {
  readonly id: 107;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable107(
  value: NullableRecord107 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-107";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 107, label, score, formatted, fallback];
}

const nullableInput107: NullableRecord107 = {
  id: 107,
  fallback: "fallback-107",
  profile: {
    label: "item-107",
    metrics: [107, 108],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult107: readonly [number, string, number, string, string] =
  readNullable107(nullableInput107);

interface NullableRecord108 {
  readonly id: 108;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable108(
  value: NullableRecord108 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-108";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 108, label, score, formatted, fallback];
}

const nullableInput108: NullableRecord108 = {
  id: 108,
  fallback: "fallback-108",
  profile: {
    label: "item-108",
    metrics: [108, 109],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult108: readonly [number, string, number, string, string] =
  readNullable108(nullableInput108);

interface NullableRecord109 {
  readonly id: 109;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable109(
  value: NullableRecord109 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-109";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 109, label, score, formatted, fallback];
}

const nullableInput109: NullableRecord109 = {
  id: 109,
  fallback: "fallback-109",
  profile: {
    label: "item-109",
    metrics: [109, 110],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult109: readonly [number, string, number, string, string] =
  readNullable109(nullableInput109);

interface NullableRecord110 {
  readonly id: 110;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable110(
  value: NullableRecord110 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-110";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 110, label, score, formatted, fallback];
}

const nullableInput110: NullableRecord110 = {
  id: 110,
  fallback: "fallback-110",
  profile: {
    label: "item-110",
    metrics: [110, 111],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult110: readonly [number, string, number, string, string] =
  readNullable110(nullableInput110);

interface NullableRecord111 {
  readonly id: 111;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable111(
  value: NullableRecord111 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-111";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 111, label, score, formatted, fallback];
}

const nullableInput111: NullableRecord111 = {
  id: 111,
  fallback: "fallback-111",
  profile: {
    label: "item-111",
    metrics: [111, 112],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult111: readonly [number, string, number, string, string] =
  readNullable111(nullableInput111);

interface NullableRecord112 {
  readonly id: 112;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable112(
  value: NullableRecord112 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-112";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 112, label, score, formatted, fallback];
}

const nullableInput112: NullableRecord112 = {
  id: 112,
  fallback: "fallback-112",
  profile: {
    label: "item-112",
    metrics: [112, 113],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult112: readonly [number, string, number, string, string] =
  readNullable112(nullableInput112);

interface NullableRecord113 {
  readonly id: 113;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable113(
  value: NullableRecord113 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-113";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 113, label, score, formatted, fallback];
}

const nullableInput113: NullableRecord113 = {
  id: 113,
  fallback: "fallback-113",
  profile: {
    label: "item-113",
    metrics: [113, 114],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult113: readonly [number, string, number, string, string] =
  readNullable113(nullableInput113);

interface NullableRecord114 {
  readonly id: 114;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable114(
  value: NullableRecord114 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-114";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 114, label, score, formatted, fallback];
}

const nullableInput114: NullableRecord114 = {
  id: 114,
  fallback: "fallback-114",
  profile: {
    label: "item-114",
    metrics: [114, 115],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult114: readonly [number, string, number, string, string] =
  readNullable114(nullableInput114);

interface NullableRecord115 {
  readonly id: 115;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable115(
  value: NullableRecord115 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-115";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 115, label, score, formatted, fallback];
}

const nullableInput115: NullableRecord115 = {
  id: 115,
  fallback: "fallback-115",
  profile: {
    label: "item-115",
    metrics: [115, 116],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult115: readonly [number, string, number, string, string] =
  readNullable115(nullableInput115);

interface NullableRecord116 {
  readonly id: 116;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable116(
  value: NullableRecord116 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-116";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 116, label, score, formatted, fallback];
}

const nullableInput116: NullableRecord116 = {
  id: 116,
  fallback: "fallback-116",
  profile: {
    label: "item-116",
    metrics: [116, 117],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult116: readonly [number, string, number, string, string] =
  readNullable116(nullableInput116);

interface NullableRecord117 {
  readonly id: 117;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable117(
  value: NullableRecord117 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-117";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 117, label, score, formatted, fallback];
}

const nullableInput117: NullableRecord117 = {
  id: 117,
  fallback: "fallback-117",
  profile: {
    label: "item-117",
    metrics: [117, 118],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult117: readonly [number, string, number, string, string] =
  readNullable117(nullableInput117);

interface NullableRecord118 {
  readonly id: 118;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable118(
  value: NullableRecord118 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-118";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 118, label, score, formatted, fallback];
}

const nullableInput118: NullableRecord118 = {
  id: 118,
  fallback: "fallback-118",
  profile: {
    label: "item-118",
    metrics: [118, 119],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult118: readonly [number, string, number, string, string] =
  readNullable118(nullableInput118);

interface NullableRecord119 {
  readonly id: 119;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable119(
  value: NullableRecord119 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-119";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 119, label, score, formatted, fallback];
}

const nullableInput119: NullableRecord119 = {
  id: 119,
  fallback: "fallback-119",
  profile: {
    label: "item-119",
    metrics: [119, 120],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult119: readonly [number, string, number, string, string] =
  readNullable119(nullableInput119);

interface NullableRecord120 {
  readonly id: 120;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable120(
  value: NullableRecord120 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-120";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 120, label, score, formatted, fallback];
}

const nullableInput120: NullableRecord120 = {
  id: 120,
  fallback: "fallback-120",
  profile: {
    label: "item-120",
    metrics: [120, 121],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult120: readonly [number, string, number, string, string] =
  readNullable120(nullableInput120);

interface NullableRecord121 {
  readonly id: 121;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable121(
  value: NullableRecord121 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-121";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 121, label, score, formatted, fallback];
}

const nullableInput121: NullableRecord121 = {
  id: 121,
  fallback: "fallback-121",
  profile: {
    label: "item-121",
    metrics: [121, 122],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult121: readonly [number, string, number, string, string] =
  readNullable121(nullableInput121);

interface NullableRecord122 {
  readonly id: 122;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable122(
  value: NullableRecord122 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-122";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 122, label, score, formatted, fallback];
}

const nullableInput122: NullableRecord122 = {
  id: 122,
  fallback: "fallback-122",
  profile: {
    label: "item-122",
    metrics: [122, 123],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult122: readonly [number, string, number, string, string] =
  readNullable122(nullableInput122);

interface NullableRecord123 {
  readonly id: 123;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable123(
  value: NullableRecord123 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-123";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 123, label, score, formatted, fallback];
}

const nullableInput123: NullableRecord123 = {
  id: 123,
  fallback: "fallback-123",
  profile: {
    label: "item-123",
    metrics: [123, 124],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult123: readonly [number, string, number, string, string] =
  readNullable123(nullableInput123);

interface NullableRecord124 {
  readonly id: 124;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable124(
  value: NullableRecord124 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-124";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 124, label, score, formatted, fallback];
}

const nullableInput124: NullableRecord124 = {
  id: 124,
  fallback: "fallback-124",
  profile: {
    label: "item-124",
    metrics: [124, 125],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult124: readonly [number, string, number, string, string] =
  readNullable124(nullableInput124);

interface NullableRecord125 {
  readonly id: 125;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable125(
  value: NullableRecord125 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-125";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 125, label, score, formatted, fallback];
}

const nullableInput125: NullableRecord125 = {
  id: 125,
  fallback: "fallback-125",
  profile: {
    label: "item-125",
    metrics: [125, 126],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult125: readonly [number, string, number, string, string] =
  readNullable125(nullableInput125);

interface NullableRecord126 {
  readonly id: 126;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable126(
  value: NullableRecord126 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-126";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 126, label, score, formatted, fallback];
}

const nullableInput126: NullableRecord126 = {
  id: 126,
  fallback: "fallback-126",
  profile: {
    label: "item-126",
    metrics: [126, 127],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult126: readonly [number, string, number, string, string] =
  readNullable126(nullableInput126);

interface NullableRecord127 {
  readonly id: 127;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable127(
  value: NullableRecord127 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-127";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 127, label, score, formatted, fallback];
}

const nullableInput127: NullableRecord127 = {
  id: 127,
  fallback: "fallback-127",
  profile: {
    label: "item-127",
    metrics: [127, 128],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult127: readonly [number, string, number, string, string] =
  readNullable127(nullableInput127);

interface NullableRecord128 {
  readonly id: 128;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable128(
  value: NullableRecord128 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-128";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const invalidLabel: boolean = label;
  const invalidScore: string = score;
  const invalidFormatted: number = formatted;
  const invalidFallback: number = value!.fallback;
  const invalidOptionalLabel: string = value?.profile?.label;
  const invalidOptionalCall: string = value?.profile?.format?.(label);
  value?.profile?.format?.(123);
  value?.profile?.metrics?.[2];
  value?.profile?.missing;
  void invalidLabel; void invalidScore; void invalidFormatted;
  void invalidFallback; void invalidOptionalLabel; void invalidOptionalCall;
  const fallback = value!.fallback;
  return [value?.id ?? 128, label, score, formatted, fallback];
}

const nullableInput128: NullableRecord128 = {
  id: 128,
  fallback: "fallback-128",
  profile: {
    label: "item-128",
    metrics: [128, 129],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult128: readonly [number, string, number, string, string] =
  readNullable128(nullableInput128);

interface NullableRecord129 {
  readonly id: 129;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable129(
  value: NullableRecord129 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-129";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 129, label, score, formatted, fallback];
}

const nullableInput129: NullableRecord129 = {
  id: 129,
  fallback: "fallback-129",
  profile: {
    label: "item-129",
    metrics: [129, 130],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult129: readonly [number, string, number, string, string] =
  readNullable129(nullableInput129);

interface NullableRecord130 {
  readonly id: 130;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable130(
  value: NullableRecord130 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-130";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 130, label, score, formatted, fallback];
}

const nullableInput130: NullableRecord130 = {
  id: 130,
  fallback: "fallback-130",
  profile: {
    label: "item-130",
    metrics: [130, 131],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult130: readonly [number, string, number, string, string] =
  readNullable130(nullableInput130);

interface NullableRecord131 {
  readonly id: 131;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable131(
  value: NullableRecord131 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-131";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 131, label, score, formatted, fallback];
}

const nullableInput131: NullableRecord131 = {
  id: 131,
  fallback: "fallback-131",
  profile: {
    label: "item-131",
    metrics: [131, 132],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult131: readonly [number, string, number, string, string] =
  readNullable131(nullableInput131);

interface NullableRecord132 {
  readonly id: 132;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable132(
  value: NullableRecord132 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-132";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 132, label, score, formatted, fallback];
}

const nullableInput132: NullableRecord132 = {
  id: 132,
  fallback: "fallback-132",
  profile: {
    label: "item-132",
    metrics: [132, 133],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult132: readonly [number, string, number, string, string] =
  readNullable132(nullableInput132);

interface NullableRecord133 {
  readonly id: 133;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable133(
  value: NullableRecord133 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-133";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 133, label, score, formatted, fallback];
}

const nullableInput133: NullableRecord133 = {
  id: 133,
  fallback: "fallback-133",
  profile: {
    label: "item-133",
    metrics: [133, 134],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult133: readonly [number, string, number, string, string] =
  readNullable133(nullableInput133);

interface NullableRecord134 {
  readonly id: 134;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable134(
  value: NullableRecord134 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-134";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 134, label, score, formatted, fallback];
}

const nullableInput134: NullableRecord134 = {
  id: 134,
  fallback: "fallback-134",
  profile: {
    label: "item-134",
    metrics: [134, 135],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult134: readonly [number, string, number, string, string] =
  readNullable134(nullableInput134);

interface NullableRecord135 {
  readonly id: 135;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable135(
  value: NullableRecord135 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-135";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 135, label, score, formatted, fallback];
}

const nullableInput135: NullableRecord135 = {
  id: 135,
  fallback: "fallback-135",
  profile: {
    label: "item-135",
    metrics: [135, 136],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult135: readonly [number, string, number, string, string] =
  readNullable135(nullableInput135);

interface NullableRecord136 {
  readonly id: 136;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable136(
  value: NullableRecord136 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-136";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 136, label, score, formatted, fallback];
}

const nullableInput136: NullableRecord136 = {
  id: 136,
  fallback: "fallback-136",
  profile: {
    label: "item-136",
    metrics: [136, 137],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult136: readonly [number, string, number, string, string] =
  readNullable136(nullableInput136);

interface NullableRecord137 {
  readonly id: 137;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable137(
  value: NullableRecord137 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-137";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 137, label, score, formatted, fallback];
}

const nullableInput137: NullableRecord137 = {
  id: 137,
  fallback: "fallback-137",
  profile: {
    label: "item-137",
    metrics: [137, 138],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult137: readonly [number, string, number, string, string] =
  readNullable137(nullableInput137);

interface NullableRecord138 {
  readonly id: 138;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable138(
  value: NullableRecord138 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-138";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 138, label, score, formatted, fallback];
}

const nullableInput138: NullableRecord138 = {
  id: 138,
  fallback: "fallback-138",
  profile: {
    label: "item-138",
    metrics: [138, 139],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult138: readonly [number, string, number, string, string] =
  readNullable138(nullableInput138);

interface NullableRecord139 {
  readonly id: 139;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable139(
  value: NullableRecord139 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-139";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 139, label, score, formatted, fallback];
}

const nullableInput139: NullableRecord139 = {
  id: 139,
  fallback: "fallback-139",
  profile: {
    label: "item-139",
    metrics: [139, 140],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult139: readonly [number, string, number, string, string] =
  readNullable139(nullableInput139);

interface NullableRecord140 {
  readonly id: 140;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable140(
  value: NullableRecord140 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-140";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 140, label, score, formatted, fallback];
}

const nullableInput140: NullableRecord140 = {
  id: 140,
  fallback: "fallback-140",
  profile: {
    label: "item-140",
    metrics: [140, 141],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult140: readonly [number, string, number, string, string] =
  readNullable140(nullableInput140);

interface NullableRecord141 {
  readonly id: 141;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable141(
  value: NullableRecord141 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-141";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 141, label, score, formatted, fallback];
}

const nullableInput141: NullableRecord141 = {
  id: 141,
  fallback: "fallback-141",
  profile: {
    label: "item-141",
    metrics: [141, 142],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult141: readonly [number, string, number, string, string] =
  readNullable141(nullableInput141);

interface NullableRecord142 {
  readonly id: 142;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable142(
  value: NullableRecord142 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-142";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 142, label, score, formatted, fallback];
}

const nullableInput142: NullableRecord142 = {
  id: 142,
  fallback: "fallback-142",
  profile: {
    label: "item-142",
    metrics: [142, 143],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult142: readonly [number, string, number, string, string] =
  readNullable142(nullableInput142);

interface NullableRecord143 {
  readonly id: 143;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable143(
  value: NullableRecord143 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-143";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 143, label, score, formatted, fallback];
}

const nullableInput143: NullableRecord143 = {
  id: 143,
  fallback: "fallback-143",
  profile: {
    label: "item-143",
    metrics: [143, 144],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult143: readonly [number, string, number, string, string] =
  readNullable143(nullableInput143);

interface NullableRecord144 {
  readonly id: 144;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable144(
  value: NullableRecord144 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-144";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 144, label, score, formatted, fallback];
}

const nullableInput144: NullableRecord144 = {
  id: 144,
  fallback: "fallback-144",
  profile: {
    label: "item-144",
    metrics: [144, 145],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult144: readonly [number, string, number, string, string] =
  readNullable144(nullableInput144);

interface NullableRecord145 {
  readonly id: 145;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable145(
  value: NullableRecord145 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-145";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 145, label, score, formatted, fallback];
}

const nullableInput145: NullableRecord145 = {
  id: 145,
  fallback: "fallback-145",
  profile: {
    label: "item-145",
    metrics: [145, 146],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult145: readonly [number, string, number, string, string] =
  readNullable145(nullableInput145);

interface NullableRecord146 {
  readonly id: 146;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable146(
  value: NullableRecord146 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-146";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 146, label, score, formatted, fallback];
}

const nullableInput146: NullableRecord146 = {
  id: 146,
  fallback: "fallback-146",
  profile: {
    label: "item-146",
    metrics: [146, 147],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult146: readonly [number, string, number, string, string] =
  readNullable146(nullableInput146);

interface NullableRecord147 {
  readonly id: 147;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable147(
  value: NullableRecord147 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-147";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 147, label, score, formatted, fallback];
}

const nullableInput147: NullableRecord147 = {
  id: 147,
  fallback: "fallback-147",
  profile: {
    label: "item-147",
    metrics: [147, 148],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult147: readonly [number, string, number, string, string] =
  readNullable147(nullableInput147);

interface NullableRecord148 {
  readonly id: 148;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable148(
  value: NullableRecord148 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-148";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 148, label, score, formatted, fallback];
}

const nullableInput148: NullableRecord148 = {
  id: 148,
  fallback: "fallback-148",
  profile: {
    label: "item-148",
    metrics: [148, 149],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult148: readonly [number, string, number, string, string] =
  readNullable148(nullableInput148);

interface NullableRecord149 {
  readonly id: 149;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable149(
  value: NullableRecord149 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-149";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 149, label, score, formatted, fallback];
}

const nullableInput149: NullableRecord149 = {
  id: 149,
  fallback: "fallback-149",
  profile: {
    label: "item-149",
    metrics: [149, 150],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult149: readonly [number, string, number, string, string] =
  readNullable149(nullableInput149);

interface NullableRecord150 {
  readonly id: 150;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable150(
  value: NullableRecord150 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-150";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 150, label, score, formatted, fallback];
}

const nullableInput150: NullableRecord150 = {
  id: 150,
  fallback: "fallback-150",
  profile: {
    label: "item-150",
    metrics: [150, 151],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult150: readonly [number, string, number, string, string] =
  readNullable150(nullableInput150);

interface NullableRecord151 {
  readonly id: 151;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable151(
  value: NullableRecord151 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-151";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 151, label, score, formatted, fallback];
}

const nullableInput151: NullableRecord151 = {
  id: 151,
  fallback: "fallback-151",
  profile: {
    label: "item-151",
    metrics: [151, 152],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult151: readonly [number, string, number, string, string] =
  readNullable151(nullableInput151);

interface NullableRecord152 {
  readonly id: 152;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable152(
  value: NullableRecord152 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-152";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 152, label, score, formatted, fallback];
}

const nullableInput152: NullableRecord152 = {
  id: 152,
  fallback: "fallback-152",
  profile: {
    label: "item-152",
    metrics: [152, 153],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult152: readonly [number, string, number, string, string] =
  readNullable152(nullableInput152);

interface NullableRecord153 {
  readonly id: 153;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable153(
  value: NullableRecord153 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-153";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 153, label, score, formatted, fallback];
}

const nullableInput153: NullableRecord153 = {
  id: 153,
  fallback: "fallback-153",
  profile: {
    label: "item-153",
    metrics: [153, 154],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult153: readonly [number, string, number, string, string] =
  readNullable153(nullableInput153);

interface NullableRecord154 {
  readonly id: 154;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable154(
  value: NullableRecord154 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-154";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 154, label, score, formatted, fallback];
}

const nullableInput154: NullableRecord154 = {
  id: 154,
  fallback: "fallback-154",
  profile: {
    label: "item-154",
    metrics: [154, 155],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult154: readonly [number, string, number, string, string] =
  readNullable154(nullableInput154);

interface NullableRecord155 {
  readonly id: 155;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable155(
  value: NullableRecord155 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-155";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 155, label, score, formatted, fallback];
}

const nullableInput155: NullableRecord155 = {
  id: 155,
  fallback: "fallback-155",
  profile: {
    label: "item-155",
    metrics: [155, 156],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult155: readonly [number, string, number, string, string] =
  readNullable155(nullableInput155);

interface NullableRecord156 {
  readonly id: 156;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable156(
  value: NullableRecord156 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-156";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 156, label, score, formatted, fallback];
}

const nullableInput156: NullableRecord156 = {
  id: 156,
  fallback: "fallback-156",
  profile: {
    label: "item-156",
    metrics: [156, 157],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult156: readonly [number, string, number, string, string] =
  readNullable156(nullableInput156);

interface NullableRecord157 {
  readonly id: 157;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable157(
  value: NullableRecord157 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-157";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 157, label, score, formatted, fallback];
}

const nullableInput157: NullableRecord157 = {
  id: 157,
  fallback: "fallback-157",
  profile: {
    label: "item-157",
    metrics: [157, 158],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult157: readonly [number, string, number, string, string] =
  readNullable157(nullableInput157);

interface NullableRecord158 {
  readonly id: 158;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable158(
  value: NullableRecord158 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-158";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 158, label, score, formatted, fallback];
}

const nullableInput158: NullableRecord158 = {
  id: 158,
  fallback: "fallback-158",
  profile: {
    label: "item-158",
    metrics: [158, 159],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult158: readonly [number, string, number, string, string] =
  readNullable158(nullableInput158);

interface NullableRecord159 {
  readonly id: 159;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable159(
  value: NullableRecord159 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-159";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 159, label, score, formatted, fallback];
}

const nullableInput159: NullableRecord159 = {
  id: 159,
  fallback: "fallback-159",
  profile: {
    label: "item-159",
    metrics: [159, 160],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult159: readonly [number, string, number, string, string] =
  readNullable159(nullableInput159);

interface NullableRecord160 {
  readonly id: 160;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable160(
  value: NullableRecord160 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-160";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 160, label, score, formatted, fallback];
}

const nullableInput160: NullableRecord160 = {
  id: 160,
  fallback: "fallback-160",
  profile: {
    label: "item-160",
    metrics: [160, 161],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult160: readonly [number, string, number, string, string] =
  readNullable160(nullableInput160);

interface NullableRecord161 {
  readonly id: 161;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable161(
  value: NullableRecord161 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-161";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 161, label, score, formatted, fallback];
}

const nullableInput161: NullableRecord161 = {
  id: 161,
  fallback: "fallback-161",
  profile: {
    label: "item-161",
    metrics: [161, 162],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult161: readonly [number, string, number, string, string] =
  readNullable161(nullableInput161);

interface NullableRecord162 {
  readonly id: 162;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable162(
  value: NullableRecord162 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-162";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 162, label, score, formatted, fallback];
}

const nullableInput162: NullableRecord162 = {
  id: 162,
  fallback: "fallback-162",
  profile: {
    label: "item-162",
    metrics: [162, 163],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult162: readonly [number, string, number, string, string] =
  readNullable162(nullableInput162);

interface NullableRecord163 {
  readonly id: 163;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable163(
  value: NullableRecord163 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-163";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 163, label, score, formatted, fallback];
}

const nullableInput163: NullableRecord163 = {
  id: 163,
  fallback: "fallback-163",
  profile: {
    label: "item-163",
    metrics: [163, 164],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult163: readonly [number, string, number, string, string] =
  readNullable163(nullableInput163);

interface NullableRecord164 {
  readonly id: 164;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable164(
  value: NullableRecord164 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-164";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 164, label, score, formatted, fallback];
}

const nullableInput164: NullableRecord164 = {
  id: 164,
  fallback: "fallback-164",
  profile: {
    label: "item-164",
    metrics: [164, 165],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult164: readonly [number, string, number, string, string] =
  readNullable164(nullableInput164);

interface NullableRecord165 {
  readonly id: 165;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable165(
  value: NullableRecord165 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-165";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 165, label, score, formatted, fallback];
}

const nullableInput165: NullableRecord165 = {
  id: 165,
  fallback: "fallback-165",
  profile: {
    label: "item-165",
    metrics: [165, 166],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult165: readonly [number, string, number, string, string] =
  readNullable165(nullableInput165);

interface NullableRecord166 {
  readonly id: 166;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable166(
  value: NullableRecord166 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-166";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 166, label, score, formatted, fallback];
}

const nullableInput166: NullableRecord166 = {
  id: 166,
  fallback: "fallback-166",
  profile: {
    label: "item-166",
    metrics: [166, 167],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult166: readonly [number, string, number, string, string] =
  readNullable166(nullableInput166);

interface NullableRecord167 {
  readonly id: 167;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable167(
  value: NullableRecord167 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-167";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 167, label, score, formatted, fallback];
}

const nullableInput167: NullableRecord167 = {
  id: 167,
  fallback: "fallback-167",
  profile: {
    label: "item-167",
    metrics: [167, 168],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult167: readonly [number, string, number, string, string] =
  readNullable167(nullableInput167);

interface NullableRecord168 {
  readonly id: 168;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable168(
  value: NullableRecord168 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-168";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 168, label, score, formatted, fallback];
}

const nullableInput168: NullableRecord168 = {
  id: 168,
  fallback: "fallback-168",
  profile: {
    label: "item-168",
    metrics: [168, 169],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult168: readonly [number, string, number, string, string] =
  readNullable168(nullableInput168);

interface NullableRecord169 {
  readonly id: 169;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable169(
  value: NullableRecord169 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-169";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 169, label, score, formatted, fallback];
}

const nullableInput169: NullableRecord169 = {
  id: 169,
  fallback: "fallback-169",
  profile: {
    label: "item-169",
    metrics: [169, 170],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult169: readonly [number, string, number, string, string] =
  readNullable169(nullableInput169);

interface NullableRecord170 {
  readonly id: 170;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable170(
  value: NullableRecord170 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-170";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 170, label, score, formatted, fallback];
}

const nullableInput170: NullableRecord170 = {
  id: 170,
  fallback: "fallback-170",
  profile: {
    label: "item-170",
    metrics: [170, 171],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult170: readonly [number, string, number, string, string] =
  readNullable170(nullableInput170);

interface NullableRecord171 {
  readonly id: 171;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable171(
  value: NullableRecord171 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-171";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 171, label, score, formatted, fallback];
}

const nullableInput171: NullableRecord171 = {
  id: 171,
  fallback: "fallback-171",
  profile: {
    label: "item-171",
    metrics: [171, 172],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult171: readonly [number, string, number, string, string] =
  readNullable171(nullableInput171);

interface NullableRecord172 {
  readonly id: 172;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable172(
  value: NullableRecord172 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-172";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 172, label, score, formatted, fallback];
}

const nullableInput172: NullableRecord172 = {
  id: 172,
  fallback: "fallback-172",
  profile: {
    label: "item-172",
    metrics: [172, 173],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult172: readonly [number, string, number, string, string] =
  readNullable172(nullableInput172);

interface NullableRecord173 {
  readonly id: 173;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable173(
  value: NullableRecord173 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-173";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 173, label, score, formatted, fallback];
}

const nullableInput173: NullableRecord173 = {
  id: 173,
  fallback: "fallback-173",
  profile: {
    label: "item-173",
    metrics: [173, 174],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult173: readonly [number, string, number, string, string] =
  readNullable173(nullableInput173);

interface NullableRecord174 {
  readonly id: 174;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable174(
  value: NullableRecord174 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-174";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 174, label, score, formatted, fallback];
}

const nullableInput174: NullableRecord174 = {
  id: 174,
  fallback: "fallback-174",
  profile: {
    label: "item-174",
    metrics: [174, 175],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult174: readonly [number, string, number, string, string] =
  readNullable174(nullableInput174);

interface NullableRecord175 {
  readonly id: 175;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable175(
  value: NullableRecord175 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-175";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 175, label, score, formatted, fallback];
}

const nullableInput175: NullableRecord175 = {
  id: 175,
  fallback: "fallback-175",
  profile: {
    label: "item-175",
    metrics: [175, 176],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult175: readonly [number, string, number, string, string] =
  readNullable175(nullableInput175);

interface NullableRecord176 {
  readonly id: 176;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable176(
  value: NullableRecord176 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-176";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 176, label, score, formatted, fallback];
}

const nullableInput176: NullableRecord176 = {
  id: 176,
  fallback: "fallback-176",
  profile: {
    label: "item-176",
    metrics: [176, 177],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult176: readonly [number, string, number, string, string] =
  readNullable176(nullableInput176);

interface NullableRecord177 {
  readonly id: 177;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable177(
  value: NullableRecord177 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-177";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 177, label, score, formatted, fallback];
}

const nullableInput177: NullableRecord177 = {
  id: 177,
  fallback: "fallback-177",
  profile: {
    label: "item-177",
    metrics: [177, 178],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult177: readonly [number, string, number, string, string] =
  readNullable177(nullableInput177);

interface NullableRecord178 {
  readonly id: 178;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable178(
  value: NullableRecord178 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-178";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 178, label, score, formatted, fallback];
}

const nullableInput178: NullableRecord178 = {
  id: 178,
  fallback: "fallback-178",
  profile: {
    label: "item-178",
    metrics: [178, 179],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult178: readonly [number, string, number, string, string] =
  readNullable178(nullableInput178);

interface NullableRecord179 {
  readonly id: 179;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable179(
  value: NullableRecord179 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-179";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 179, label, score, formatted, fallback];
}

const nullableInput179: NullableRecord179 = {
  id: 179,
  fallback: "fallback-179",
  profile: {
    label: "item-179",
    metrics: [179, 180],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult179: readonly [number, string, number, string, string] =
  readNullable179(nullableInput179);

interface NullableRecord180 {
  readonly id: 180;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable180(
  value: NullableRecord180 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-180";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 180, label, score, formatted, fallback];
}

const nullableInput180: NullableRecord180 = {
  id: 180,
  fallback: "fallback-180",
  profile: {
    label: "item-180",
    metrics: [180, 181],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult180: readonly [number, string, number, string, string] =
  readNullable180(nullableInput180);

interface NullableRecord181 {
  readonly id: 181;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable181(
  value: NullableRecord181 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-181";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 181, label, score, formatted, fallback];
}

const nullableInput181: NullableRecord181 = {
  id: 181,
  fallback: "fallback-181",
  profile: {
    label: "item-181",
    metrics: [181, 182],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult181: readonly [number, string, number, string, string] =
  readNullable181(nullableInput181);

interface NullableRecord182 {
  readonly id: 182;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable182(
  value: NullableRecord182 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-182";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 182, label, score, formatted, fallback];
}

const nullableInput182: NullableRecord182 = {
  id: 182,
  fallback: "fallback-182",
  profile: {
    label: "item-182",
    metrics: [182, 183],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult182: readonly [number, string, number, string, string] =
  readNullable182(nullableInput182);

interface NullableRecord183 {
  readonly id: 183;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable183(
  value: NullableRecord183 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-183";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 183, label, score, formatted, fallback];
}

const nullableInput183: NullableRecord183 = {
  id: 183,
  fallback: "fallback-183",
  profile: {
    label: "item-183",
    metrics: [183, 184],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult183: readonly [number, string, number, string, string] =
  readNullable183(nullableInput183);

interface NullableRecord184 {
  readonly id: 184;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable184(
  value: NullableRecord184 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-184";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 184, label, score, formatted, fallback];
}

const nullableInput184: NullableRecord184 = {
  id: 184,
  fallback: "fallback-184",
  profile: {
    label: "item-184",
    metrics: [184, 185],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult184: readonly [number, string, number, string, string] =
  readNullable184(nullableInput184);

interface NullableRecord185 {
  readonly id: 185;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable185(
  value: NullableRecord185 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-185";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 185, label, score, formatted, fallback];
}

const nullableInput185: NullableRecord185 = {
  id: 185,
  fallback: "fallback-185",
  profile: {
    label: "item-185",
    metrics: [185, 186],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult185: readonly [number, string, number, string, string] =
  readNullable185(nullableInput185);

interface NullableRecord186 {
  readonly id: 186;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable186(
  value: NullableRecord186 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-186";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 186, label, score, formatted, fallback];
}

const nullableInput186: NullableRecord186 = {
  id: 186,
  fallback: "fallback-186",
  profile: {
    label: "item-186",
    metrics: [186, 187],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult186: readonly [number, string, number, string, string] =
  readNullable186(nullableInput186);

interface NullableRecord187 {
  readonly id: 187;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable187(
  value: NullableRecord187 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-187";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 187, label, score, formatted, fallback];
}

const nullableInput187: NullableRecord187 = {
  id: 187,
  fallback: "fallback-187",
  profile: {
    label: "item-187",
    metrics: [187, 188],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult187: readonly [number, string, number, string, string] =
  readNullable187(nullableInput187);

interface NullableRecord188 {
  readonly id: 188;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable188(
  value: NullableRecord188 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-188";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 188, label, score, formatted, fallback];
}

const nullableInput188: NullableRecord188 = {
  id: 188,
  fallback: "fallback-188",
  profile: {
    label: "item-188",
    metrics: [188, 189],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult188: readonly [number, string, number, string, string] =
  readNullable188(nullableInput188);

interface NullableRecord189 {
  readonly id: 189;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable189(
  value: NullableRecord189 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-189";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 189, label, score, formatted, fallback];
}

const nullableInput189: NullableRecord189 = {
  id: 189,
  fallback: "fallback-189",
  profile: {
    label: "item-189",
    metrics: [189, 190],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult189: readonly [number, string, number, string, string] =
  readNullable189(nullableInput189);

interface NullableRecord190 {
  readonly id: 190;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable190(
  value: NullableRecord190 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-190";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 190, label, score, formatted, fallback];
}

const nullableInput190: NullableRecord190 = {
  id: 190,
  fallback: "fallback-190",
  profile: {
    label: "item-190",
    metrics: [190, 191],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult190: readonly [number, string, number, string, string] =
  readNullable190(nullableInput190);

interface NullableRecord191 {
  readonly id: 191;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable191(
  value: NullableRecord191 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-191";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 191, label, score, formatted, fallback];
}

const nullableInput191: NullableRecord191 = {
  id: 191,
  fallback: "fallback-191",
  profile: {
    label: "item-191",
    metrics: [191, 192],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult191: readonly [number, string, number, string, string] =
  readNullable191(nullableInput191);

interface NullableRecord192 {
  readonly id: 192;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable192(
  value: NullableRecord192 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-192";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 192, label, score, formatted, fallback];
}

const nullableInput192: NullableRecord192 = {
  id: 192,
  fallback: "fallback-192",
  profile: {
    label: "item-192",
    metrics: [192, 193],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult192: readonly [number, string, number, string, string] =
  readNullable192(nullableInput192);

interface NullableRecord193 {
  readonly id: 193;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable193(
  value: NullableRecord193 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-193";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 193, label, score, formatted, fallback];
}

const nullableInput193: NullableRecord193 = {
  id: 193,
  fallback: "fallback-193",
  profile: {
    label: "item-193",
    metrics: [193, 194],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult193: readonly [number, string, number, string, string] =
  readNullable193(nullableInput193);

interface NullableRecord194 {
  readonly id: 194;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable194(
  value: NullableRecord194 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-194";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 194, label, score, formatted, fallback];
}

const nullableInput194: NullableRecord194 = {
  id: 194,
  fallback: "fallback-194",
  profile: {
    label: "item-194",
    metrics: [194, 195],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult194: readonly [number, string, number, string, string] =
  readNullable194(nullableInput194);

interface NullableRecord195 {
  readonly id: 195;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable195(
  value: NullableRecord195 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-195";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 195, label, score, formatted, fallback];
}

const nullableInput195: NullableRecord195 = {
  id: 195,
  fallback: "fallback-195",
  profile: {
    label: "item-195",
    metrics: [195, 196],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult195: readonly [number, string, number, string, string] =
  readNullable195(nullableInput195);

interface NullableRecord196 {
  readonly id: 196;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable196(
  value: NullableRecord196 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-196";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 196, label, score, formatted, fallback];
}

const nullableInput196: NullableRecord196 = {
  id: 196,
  fallback: "fallback-196",
  profile: {
    label: "item-196",
    metrics: [196, 197],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult196: readonly [number, string, number, string, string] =
  readNullable196(nullableInput196);

interface NullableRecord197 {
  readonly id: 197;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable197(
  value: NullableRecord197 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-197";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 197, label, score, formatted, fallback];
}

const nullableInput197: NullableRecord197 = {
  id: 197,
  fallback: "fallback-197",
  profile: {
    label: "item-197",
    metrics: [197, 198],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult197: readonly [number, string, number, string, string] =
  readNullable197(nullableInput197);

interface NullableRecord198 {
  readonly id: 198;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable198(
  value: NullableRecord198 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-198";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 198, label, score, formatted, fallback];
}

const nullableInput198: NullableRecord198 = {
  id: 198,
  fallback: "fallback-198",
  profile: {
    label: "item-198",
    metrics: [198, 199],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult198: readonly [number, string, number, string, string] =
  readNullable198(nullableInput198);

interface NullableRecord199 {
  readonly id: 199;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable199(
  value: NullableRecord199 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-199";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 199, label, score, formatted, fallback];
}

const nullableInput199: NullableRecord199 = {
  id: 199,
  fallback: "fallback-199",
  profile: {
    label: "item-199",
    metrics: [199, 200],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult199: readonly [number, string, number, string, string] =
  readNullable199(nullableInput199);

interface NullableRecord200 {
  readonly id: 200;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable200(
  value: NullableRecord200 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-200";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 200, label, score, formatted, fallback];
}

const nullableInput200: NullableRecord200 = {
  id: 200,
  fallback: "fallback-200",
  profile: {
    label: "item-200",
    metrics: [200, 201],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult200: readonly [number, string, number, string, string] =
  readNullable200(nullableInput200);

interface NullableRecord201 {
  readonly id: 201;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable201(
  value: NullableRecord201 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-201";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 201, label, score, formatted, fallback];
}

const nullableInput201: NullableRecord201 = {
  id: 201,
  fallback: "fallback-201",
  profile: {
    label: "item-201",
    metrics: [201, 202],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult201: readonly [number, string, number, string, string] =
  readNullable201(nullableInput201);

interface NullableRecord202 {
  readonly id: 202;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable202(
  value: NullableRecord202 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-202";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 202, label, score, formatted, fallback];
}

const nullableInput202: NullableRecord202 = {
  id: 202,
  fallback: "fallback-202",
  profile: {
    label: "item-202",
    metrics: [202, 203],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult202: readonly [number, string, number, string, string] =
  readNullable202(nullableInput202);

interface NullableRecord203 {
  readonly id: 203;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable203(
  value: NullableRecord203 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-203";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 203, label, score, formatted, fallback];
}

const nullableInput203: NullableRecord203 = {
  id: 203,
  fallback: "fallback-203",
  profile: {
    label: "item-203",
    metrics: [203, 204],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult203: readonly [number, string, number, string, string] =
  readNullable203(nullableInput203);

interface NullableRecord204 {
  readonly id: 204;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable204(
  value: NullableRecord204 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-204";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 204, label, score, formatted, fallback];
}

const nullableInput204: NullableRecord204 = {
  id: 204,
  fallback: "fallback-204",
  profile: {
    label: "item-204",
    metrics: [204, 205],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult204: readonly [number, string, number, string, string] =
  readNullable204(nullableInput204);

interface NullableRecord205 {
  readonly id: 205;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable205(
  value: NullableRecord205 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-205";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 205, label, score, formatted, fallback];
}

const nullableInput205: NullableRecord205 = {
  id: 205,
  fallback: "fallback-205",
  profile: {
    label: "item-205",
    metrics: [205, 206],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult205: readonly [number, string, number, string, string] =
  readNullable205(nullableInput205);

interface NullableRecord206 {
  readonly id: 206;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable206(
  value: NullableRecord206 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-206";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 206, label, score, formatted, fallback];
}

const nullableInput206: NullableRecord206 = {
  id: 206,
  fallback: "fallback-206",
  profile: {
    label: "item-206",
    metrics: [206, 207],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult206: readonly [number, string, number, string, string] =
  readNullable206(nullableInput206);

interface NullableRecord207 {
  readonly id: 207;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable207(
  value: NullableRecord207 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-207";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 207, label, score, formatted, fallback];
}

const nullableInput207: NullableRecord207 = {
  id: 207,
  fallback: "fallback-207",
  profile: {
    label: "item-207",
    metrics: [207, 208],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult207: readonly [number, string, number, string, string] =
  readNullable207(nullableInput207);

interface NullableRecord208 {
  readonly id: 208;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable208(
  value: NullableRecord208 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-208";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 208, label, score, formatted, fallback];
}

const nullableInput208: NullableRecord208 = {
  id: 208,
  fallback: "fallback-208",
  profile: {
    label: "item-208",
    metrics: [208, 209],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult208: readonly [number, string, number, string, string] =
  readNullable208(nullableInput208);

interface NullableRecord209 {
  readonly id: 209;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable209(
  value: NullableRecord209 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-209";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 209, label, score, formatted, fallback];
}

const nullableInput209: NullableRecord209 = {
  id: 209,
  fallback: "fallback-209",
  profile: {
    label: "item-209",
    metrics: [209, 210],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult209: readonly [number, string, number, string, string] =
  readNullable209(nullableInput209);

interface NullableRecord210 {
  readonly id: 210;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable210(
  value: NullableRecord210 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-210";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 210, label, score, formatted, fallback];
}

const nullableInput210: NullableRecord210 = {
  id: 210,
  fallback: "fallback-210",
  profile: {
    label: "item-210",
    metrics: [210, 211],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult210: readonly [number, string, number, string, string] =
  readNullable210(nullableInput210);

interface NullableRecord211 {
  readonly id: 211;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable211(
  value: NullableRecord211 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-211";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 211, label, score, formatted, fallback];
}

const nullableInput211: NullableRecord211 = {
  id: 211,
  fallback: "fallback-211",
  profile: {
    label: "item-211",
    metrics: [211, 212],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult211: readonly [number, string, number, string, string] =
  readNullable211(nullableInput211);

interface NullableRecord212 {
  readonly id: 212;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable212(
  value: NullableRecord212 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-212";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 212, label, score, formatted, fallback];
}

const nullableInput212: NullableRecord212 = {
  id: 212,
  fallback: "fallback-212",
  profile: {
    label: "item-212",
    metrics: [212, 213],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult212: readonly [number, string, number, string, string] =
  readNullable212(nullableInput212);

interface NullableRecord213 {
  readonly id: 213;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable213(
  value: NullableRecord213 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-213";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 213, label, score, formatted, fallback];
}

const nullableInput213: NullableRecord213 = {
  id: 213,
  fallback: "fallback-213",
  profile: {
    label: "item-213",
    metrics: [213, 214],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult213: readonly [number, string, number, string, string] =
  readNullable213(nullableInput213);

interface NullableRecord214 {
  readonly id: 214;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable214(
  value: NullableRecord214 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-214";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 214, label, score, formatted, fallback];
}

const nullableInput214: NullableRecord214 = {
  id: 214,
  fallback: "fallback-214",
  profile: {
    label: "item-214",
    metrics: [214, 215],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult214: readonly [number, string, number, string, string] =
  readNullable214(nullableInput214);

interface NullableRecord215 {
  readonly id: 215;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable215(
  value: NullableRecord215 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-215";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 215, label, score, formatted, fallback];
}

const nullableInput215: NullableRecord215 = {
  id: 215,
  fallback: "fallback-215",
  profile: {
    label: "item-215",
    metrics: [215, 216],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult215: readonly [number, string, number, string, string] =
  readNullable215(nullableInput215);

interface NullableRecord216 {
  readonly id: 216;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable216(
  value: NullableRecord216 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-216";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 216, label, score, formatted, fallback];
}

const nullableInput216: NullableRecord216 = {
  id: 216,
  fallback: "fallback-216",
  profile: {
    label: "item-216",
    metrics: [216, 217],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult216: readonly [number, string, number, string, string] =
  readNullable216(nullableInput216);

interface NullableRecord217 {
  readonly id: 217;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable217(
  value: NullableRecord217 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-217";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 217, label, score, formatted, fallback];
}

const nullableInput217: NullableRecord217 = {
  id: 217,
  fallback: "fallback-217",
  profile: {
    label: "item-217",
    metrics: [217, 218],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult217: readonly [number, string, number, string, string] =
  readNullable217(nullableInput217);

interface NullableRecord218 {
  readonly id: 218;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable218(
  value: NullableRecord218 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-218";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 218, label, score, formatted, fallback];
}

const nullableInput218: NullableRecord218 = {
  id: 218,
  fallback: "fallback-218",
  profile: {
    label: "item-218",
    metrics: [218, 219],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult218: readonly [number, string, number, string, string] =
  readNullable218(nullableInput218);

interface NullableRecord219 {
  readonly id: 219;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable219(
  value: NullableRecord219 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-219";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 219, label, score, formatted, fallback];
}

const nullableInput219: NullableRecord219 = {
  id: 219,
  fallback: "fallback-219",
  profile: {
    label: "item-219",
    metrics: [219, 220],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult219: readonly [number, string, number, string, string] =
  readNullable219(nullableInput219);

interface NullableRecord220 {
  readonly id: 220;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable220(
  value: NullableRecord220 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-220";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 220, label, score, formatted, fallback];
}

const nullableInput220: NullableRecord220 = {
  id: 220,
  fallback: "fallback-220",
  profile: {
    label: "item-220",
    metrics: [220, 221],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult220: readonly [number, string, number, string, string] =
  readNullable220(nullableInput220);

interface NullableRecord221 {
  readonly id: 221;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable221(
  value: NullableRecord221 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-221";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 221, label, score, formatted, fallback];
}

const nullableInput221: NullableRecord221 = {
  id: 221,
  fallback: "fallback-221",
  profile: {
    label: "item-221",
    metrics: [221, 222],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult221: readonly [number, string, number, string, string] =
  readNullable221(nullableInput221);

interface NullableRecord222 {
  readonly id: 222;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable222(
  value: NullableRecord222 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-222";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 222, label, score, formatted, fallback];
}

const nullableInput222: NullableRecord222 = {
  id: 222,
  fallback: "fallback-222",
  profile: {
    label: "item-222",
    metrics: [222, 223],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult222: readonly [number, string, number, string, string] =
  readNullable222(nullableInput222);

interface NullableRecord223 {
  readonly id: 223;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable223(
  value: NullableRecord223 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-223";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 223, label, score, formatted, fallback];
}

const nullableInput223: NullableRecord223 = {
  id: 223,
  fallback: "fallback-223",
  profile: {
    label: "item-223",
    metrics: [223, 224],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult223: readonly [number, string, number, string, string] =
  readNullable223(nullableInput223);

interface NullableRecord224 {
  readonly id: 224;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable224(
  value: NullableRecord224 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-224";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 224, label, score, formatted, fallback];
}

const nullableInput224: NullableRecord224 = {
  id: 224,
  fallback: "fallback-224",
  profile: {
    label: "item-224",
    metrics: [224, 225],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult224: readonly [number, string, number, string, string] =
  readNullable224(nullableInput224);

interface NullableRecord225 {
  readonly id: 225;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable225(
  value: NullableRecord225 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-225";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 225, label, score, formatted, fallback];
}

const nullableInput225: NullableRecord225 = {
  id: 225,
  fallback: "fallback-225",
  profile: {
    label: "item-225",
    metrics: [225, 226],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult225: readonly [number, string, number, string, string] =
  readNullable225(nullableInput225);

interface NullableRecord226 {
  readonly id: 226;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable226(
  value: NullableRecord226 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-226";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 226, label, score, formatted, fallback];
}

const nullableInput226: NullableRecord226 = {
  id: 226,
  fallback: "fallback-226",
  profile: {
    label: "item-226",
    metrics: [226, 227],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult226: readonly [number, string, number, string, string] =
  readNullable226(nullableInput226);

interface NullableRecord227 {
  readonly id: 227;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable227(
  value: NullableRecord227 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-227";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 227, label, score, formatted, fallback];
}

const nullableInput227: NullableRecord227 = {
  id: 227,
  fallback: "fallback-227",
  profile: {
    label: "item-227",
    metrics: [227, 228],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult227: readonly [number, string, number, string, string] =
  readNullable227(nullableInput227);

interface NullableRecord228 {
  readonly id: 228;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable228(
  value: NullableRecord228 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-228";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 228, label, score, formatted, fallback];
}

const nullableInput228: NullableRecord228 = {
  id: 228,
  fallback: "fallback-228",
  profile: {
    label: "item-228",
    metrics: [228, 229],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult228: readonly [number, string, number, string, string] =
  readNullable228(nullableInput228);

interface NullableRecord229 {
  readonly id: 229;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable229(
  value: NullableRecord229 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-229";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 229, label, score, formatted, fallback];
}

const nullableInput229: NullableRecord229 = {
  id: 229,
  fallback: "fallback-229",
  profile: {
    label: "item-229",
    metrics: [229, 230],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult229: readonly [number, string, number, string, string] =
  readNullable229(nullableInput229);

interface NullableRecord230 {
  readonly id: 230;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable230(
  value: NullableRecord230 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-230";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 230, label, score, formatted, fallback];
}

const nullableInput230: NullableRecord230 = {
  id: 230,
  fallback: "fallback-230",
  profile: {
    label: "item-230",
    metrics: [230, 231],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult230: readonly [number, string, number, string, string] =
  readNullable230(nullableInput230);

interface NullableRecord231 {
  readonly id: 231;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable231(
  value: NullableRecord231 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-231";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 231, label, score, formatted, fallback];
}

const nullableInput231: NullableRecord231 = {
  id: 231,
  fallback: "fallback-231",
  profile: {
    label: "item-231",
    metrics: [231, 232],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult231: readonly [number, string, number, string, string] =
  readNullable231(nullableInput231);

interface NullableRecord232 {
  readonly id: 232;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable232(
  value: NullableRecord232 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-232";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 232, label, score, formatted, fallback];
}

const nullableInput232: NullableRecord232 = {
  id: 232,
  fallback: "fallback-232",
  profile: {
    label: "item-232",
    metrics: [232, 233],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult232: readonly [number, string, number, string, string] =
  readNullable232(nullableInput232);

interface NullableRecord233 {
  readonly id: 233;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable233(
  value: NullableRecord233 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-233";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 233, label, score, formatted, fallback];
}

const nullableInput233: NullableRecord233 = {
  id: 233,
  fallback: "fallback-233",
  profile: {
    label: "item-233",
    metrics: [233, 234],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult233: readonly [number, string, number, string, string] =
  readNullable233(nullableInput233);

interface NullableRecord234 {
  readonly id: 234;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable234(
  value: NullableRecord234 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-234";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 234, label, score, formatted, fallback];
}

const nullableInput234: NullableRecord234 = {
  id: 234,
  fallback: "fallback-234",
  profile: {
    label: "item-234",
    metrics: [234, 235],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult234: readonly [number, string, number, string, string] =
  readNullable234(nullableInput234);

interface NullableRecord235 {
  readonly id: 235;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable235(
  value: NullableRecord235 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-235";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 235, label, score, formatted, fallback];
}

const nullableInput235: NullableRecord235 = {
  id: 235,
  fallback: "fallback-235",
  profile: {
    label: "item-235",
    metrics: [235, 236],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult235: readonly [number, string, number, string, string] =
  readNullable235(nullableInput235);

interface NullableRecord236 {
  readonly id: 236;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable236(
  value: NullableRecord236 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-236";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 236, label, score, formatted, fallback];
}

const nullableInput236: NullableRecord236 = {
  id: 236,
  fallback: "fallback-236",
  profile: {
    label: "item-236",
    metrics: [236, 237],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult236: readonly [number, string, number, string, string] =
  readNullable236(nullableInput236);

interface NullableRecord237 {
  readonly id: 237;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable237(
  value: NullableRecord237 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-237";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 237, label, score, formatted, fallback];
}

const nullableInput237: NullableRecord237 = {
  id: 237,
  fallback: "fallback-237",
  profile: {
    label: "item-237",
    metrics: [237, 238],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult237: readonly [number, string, number, string, string] =
  readNullable237(nullableInput237);

interface NullableRecord238 {
  readonly id: 238;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable238(
  value: NullableRecord238 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-238";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 238, label, score, formatted, fallback];
}

const nullableInput238: NullableRecord238 = {
  id: 238,
  fallback: "fallback-238",
  profile: {
    label: "item-238",
    metrics: [238, 239],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult238: readonly [number, string, number, string, string] =
  readNullable238(nullableInput238);

interface NullableRecord239 {
  readonly id: 239;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable239(
  value: NullableRecord239 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-239";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 239, label, score, formatted, fallback];
}

const nullableInput239: NullableRecord239 = {
  id: 239,
  fallback: "fallback-239",
  profile: {
    label: "item-239",
    metrics: [239, 240],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult239: readonly [number, string, number, string, string] =
  readNullable239(nullableInput239);

interface NullableRecord240 {
  readonly id: 240;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable240(
  value: NullableRecord240 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-240";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 240, label, score, formatted, fallback];
}

const nullableInput240: NullableRecord240 = {
  id: 240,
  fallback: "fallback-240",
  profile: {
    label: "item-240",
    metrics: [240, 241],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult240: readonly [number, string, number, string, string] =
  readNullable240(nullableInput240);

interface NullableRecord241 {
  readonly id: 241;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable241(
  value: NullableRecord241 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-241";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 241, label, score, formatted, fallback];
}

const nullableInput241: NullableRecord241 = {
  id: 241,
  fallback: "fallback-241",
  profile: {
    label: "item-241",
    metrics: [241, 242],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult241: readonly [number, string, number, string, string] =
  readNullable241(nullableInput241);

interface NullableRecord242 {
  readonly id: 242;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable242(
  value: NullableRecord242 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-242";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 242, label, score, formatted, fallback];
}

const nullableInput242: NullableRecord242 = {
  id: 242,
  fallback: "fallback-242",
  profile: {
    label: "item-242",
    metrics: [242, 243],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult242: readonly [number, string, number, string, string] =
  readNullable242(nullableInput242);

interface NullableRecord243 {
  readonly id: 243;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable243(
  value: NullableRecord243 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-243";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 243, label, score, formatted, fallback];
}

const nullableInput243: NullableRecord243 = {
  id: 243,
  fallback: "fallback-243",
  profile: {
    label: "item-243",
    metrics: [243, 244],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult243: readonly [number, string, number, string, string] =
  readNullable243(nullableInput243);

interface NullableRecord244 {
  readonly id: 244;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable244(
  value: NullableRecord244 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-244";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 244, label, score, formatted, fallback];
}

const nullableInput244: NullableRecord244 = {
  id: 244,
  fallback: "fallback-244",
  profile: {
    label: "item-244",
    metrics: [244, 245],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult244: readonly [number, string, number, string, string] =
  readNullable244(nullableInput244);

interface NullableRecord245 {
  readonly id: 245;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable245(
  value: NullableRecord245 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-245";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 245, label, score, formatted, fallback];
}

const nullableInput245: NullableRecord245 = {
  id: 245,
  fallback: "fallback-245",
  profile: {
    label: "item-245",
    metrics: [245, 246],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult245: readonly [number, string, number, string, string] =
  readNullable245(nullableInput245);

interface NullableRecord246 {
  readonly id: 246;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable246(
  value: NullableRecord246 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-246";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 246, label, score, formatted, fallback];
}

const nullableInput246: NullableRecord246 = {
  id: 246,
  fallback: "fallback-246",
  profile: {
    label: "item-246",
    metrics: [246, 247],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult246: readonly [number, string, number, string, string] =
  readNullable246(nullableInput246);

interface NullableRecord247 {
  readonly id: 247;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable247(
  value: NullableRecord247 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-247";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 247, label, score, formatted, fallback];
}

const nullableInput247: NullableRecord247 = {
  id: 247,
  fallback: "fallback-247",
  profile: {
    label: "item-247",
    metrics: [247, 248],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult247: readonly [number, string, number, string, string] =
  readNullable247(nullableInput247);

interface NullableRecord248 {
  readonly id: 248;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable248(
  value: NullableRecord248 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-248";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 248, label, score, formatted, fallback];
}

const nullableInput248: NullableRecord248 = {
  id: 248,
  fallback: "fallback-248",
  profile: {
    label: "item-248",
    metrics: [248, 249],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult248: readonly [number, string, number, string, string] =
  readNullable248(nullableInput248);

interface NullableRecord249 {
  readonly id: 249;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable249(
  value: NullableRecord249 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-249";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 249, label, score, formatted, fallback];
}

const nullableInput249: NullableRecord249 = {
  id: 249,
  fallback: "fallback-249",
  profile: {
    label: "item-249",
    metrics: [249, 250],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult249: readonly [number, string, number, string, string] =
  readNullable249(nullableInput249);

interface NullableRecord250 {
  readonly id: 250;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable250(
  value: NullableRecord250 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-250";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 250, label, score, formatted, fallback];
}

const nullableInput250: NullableRecord250 = {
  id: 250,
  fallback: "fallback-250",
  profile: {
    label: "item-250",
    metrics: [250, 251],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult250: readonly [number, string, number, string, string] =
  readNullable250(nullableInput250);

interface NullableRecord251 {
  readonly id: 251;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable251(
  value: NullableRecord251 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-251";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 251, label, score, formatted, fallback];
}

const nullableInput251: NullableRecord251 = {
  id: 251,
  fallback: "fallback-251",
  profile: {
    label: "item-251",
    metrics: [251, 252],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult251: readonly [number, string, number, string, string] =
  readNullable251(nullableInput251);

interface NullableRecord252 {
  readonly id: 252;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable252(
  value: NullableRecord252 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-252";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 252, label, score, formatted, fallback];
}

const nullableInput252: NullableRecord252 = {
  id: 252,
  fallback: "fallback-252",
  profile: {
    label: "item-252",
    metrics: [252, 253],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult252: readonly [number, string, number, string, string] =
  readNullable252(nullableInput252);

interface NullableRecord253 {
  readonly id: 253;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable253(
  value: NullableRecord253 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-253";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 253, label, score, formatted, fallback];
}

const nullableInput253: NullableRecord253 = {
  id: 253,
  fallback: "fallback-253",
  profile: {
    label: "item-253",
    metrics: [253, 254],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult253: readonly [number, string, number, string, string] =
  readNullable253(nullableInput253);

interface NullableRecord254 {
  readonly id: 254;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable254(
  value: NullableRecord254 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-254";
  const score = value?.profile?.metrics?.[0] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const fallback = value!.fallback;
  return [value?.id ?? 254, label, score, formatted, fallback];
}

const nullableInput254: NullableRecord254 = {
  id: 254,
  fallback: "fallback-254",
  profile: {
    label: "item-254",
    metrics: [254, 255],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult254: readonly [number, string, number, string, string] =
  readNullable254(nullableInput254);

interface NullableRecord255 {
  readonly id: 255;
  readonly fallback: string;
  readonly profile?: {
    readonly label?: string;
    readonly metrics?: readonly [number, number];
    readonly format?: (prefix: string) => string;
  };
}

function readNullable255(
  value: NullableRecord255 | null | undefined,
): readonly [number, string, number, string, string] {
  const label = value?.profile?.label ?? value?.fallback ?? "missing-255";
  const score = value?.profile?.metrics?.[1] ?? 0;
  const formatted = value?.profile?.format?.(label) ?? label;
  const invalidLabel: boolean = label;
  const invalidScore: string = score;
  const invalidFormatted: number = formatted;
  const invalidFallback: number = value!.fallback;
  const invalidOptionalLabel: string = value?.profile?.label;
  const invalidOptionalCall: string = value?.profile?.format?.(label);
  value?.profile?.format?.(123);
  value?.profile?.metrics?.[2];
  value?.profile?.missing;
  void invalidLabel; void invalidScore; void invalidFormatted;
  void invalidFallback; void invalidOptionalLabel; void invalidOptionalCall;
  const fallback = value!.fallback;
  return [value?.id ?? 255, label, score, formatted, fallback];
}

const nullableInput255: NullableRecord255 = {
  id: 255,
  fallback: "fallback-255",
  profile: {
    label: "item-255",
    metrics: [255, 256],
    format: (prefix) => prefix,
  },
};
export const nullSafeResult255: readonly [number, string, number, string, string] =
  readNullable255(nullableInput255);

