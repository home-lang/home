import hashlib
import json
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
sys.path.insert(0, str(root))
from paired_statistics import validate_phase

protocol = json.loads((root / 'protocol.json').read_text())
screen = json.loads((root / 'screen-statistics.json').read_text())
risks = list(protocol['independent_regression_workloads']) + screen['additional_adverse_workloads']
phases = ['screen', 'target'] + ['risk-' + name for name in risks]
pairs = 0
admissions = 0
for phase in phases:
    command = json.loads((root / (phase + '-command.json')).read_text())
    assert command['exit'] == 0 and command['status'] == 'complete'
    assert command['guard_max_mb'] == 3840 and command['guard_seconds'] == 600
    assert 'run-bounded: peak tree footprint' in (root / (phase + '-run.log')).read_text()
    original = json.loads((root / (phase + '-statistics.json')).read_text())
    recomputed = validate_phase(phase)
    assert recomputed == original
    pairs += recomputed['pairs']
    admissions += recomputed['admissions']
assert pairs == 530 and admissions == 100
decision = json.loads((root / 'decision.json').read_text())
assert decision['decision'] == 'reject' and decision['source_changes_qualified_for_adoption'] is False
assert decision['pairs'] == pairs and decision['phase_count'] == len(phases)
assert not decision['independent_regression_losses']
assert decision['target']['paired_mean_saving_95_interval'][0] <= 0
restored = json.loads((root / 'restoration.json').read_text())
assert restored['exit'] == 0 and restored['matches_parent'] and restored['source_clean']
assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=repo).decode() == ''
assert hashlib.sha256((repo / 'zig-out/bin/home-tsc').read_bytes()).hexdigest() == protocol['parent_native_sha256'] == restored['native_sha256']
source = json.loads((root / 'verified-source.json').read_text())
candidate = json.loads((root / 'candidate-build.json').read_text())
assert hashlib.sha256(candidate['source_patch'].encode()).hexdigest() == source['patch_sha256']
assert json.loads((root / 'verified-gates.json').read_text())['passed']
assert json.loads((root / 'verified-image-admission.json').read_text())['admissions'] == 180
result = {'passed': True, 'decision': 'reject', 'pairs': pairs, 'per_phase_admissions': admissions,
          'initial_admissions': 180, 'phases': len(phases), 'all_raw_retained': True,
          'measurement_reruns': 0, 'discarded_samples': 0, 'source_restored': True,
          'native_restored_sha256': restored['native_sha256'], 'candidate_pushed': False,
          'zero_spanning_intervals_are_not_equivalence': True, 'universal_goal_complete': False}
(root / 'verified-completed.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result), flush=True)
