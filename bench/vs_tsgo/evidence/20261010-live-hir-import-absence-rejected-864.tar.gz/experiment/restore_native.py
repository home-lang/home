import hashlib
import json
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=repo).decode() == ''
decision = json.loads((root / 'decision.json').read_text())
assert decision['decision'] == 'reject'
command = ['/Users/chris/Code/Home/lang-bun-port/zig-out/toolchains/zig-aarch64-macos-0.17.0-dev.2163+89ff10d56/zig',
           'build', 'home-tsc', '-Doptimize=ReleaseFast', '-Dhome-tsc-strip=true', '-Denable_jsc=false', '-j1', '--summary', 'all']
with (root / 'restoration-build.log').open('w') as output:
    result = subprocess.run(command, cwd=repo, stdout=output, stderr=subprocess.STDOUT)
record = {'command': command, 'exit': result.returncode,
          'source': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip(),
          'source_clean': subprocess.check_output(['git', 'status', '--porcelain'], cwd=repo).decode() == ''}
if result.returncode == 0:
    record['native_sha256'] = hashlib.sha256((repo / 'zig-out/bin/home-tsc').read_bytes()).hexdigest()
    record['matches_parent'] = record['native_sha256'] == 'd58ddc54a147b3ad8b177a98a6b5cda04fd4df77595c5ccf44da690de5d57b32'
(root / 'restoration.json').write_text(json.dumps(record, indent=2) + '\n')
print((root / 'restoration-build.log').read_text(), flush=True)
assert result.returncode == 0 and record['matches_parent'] and record['source_clean']
