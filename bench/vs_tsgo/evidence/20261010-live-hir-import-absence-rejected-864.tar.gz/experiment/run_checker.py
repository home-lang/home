import json
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
revision = sys.argv[1] if len(sys.argv) > 1 else 'checker'
command = [sys.executable, '/Users/chris/.cache/home-ts-843.3BeUMH/module_tests.py', 'checker']
record = {'command': command, 'source_parent': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip(),
          'source_patch': subprocess.check_output(['git', 'diff'], cwd=repo).decode()}
with (root / (revision + '.log')).open('w') as output:
    result = subprocess.run(command, cwd=repo, stdout=output, stderr=subprocess.STDOUT)
record['exit'] = result.returncode
(root / (revision + '.json')).write_text(json.dumps(record, indent=2) + '\n')
text = (root / (revision + '.log')).read_text()
for line in text.splitlines():
    if 'FAIL' in line or 'error:' in line or 'tests passed' in line or 'passed;' in line or 'expected' in line:
        print(line, flush=True)
raise SystemExit(result.returncode)
