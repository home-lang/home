import hashlib
import json
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
parent = subprocess.check_output(['git', 'show', 'cb6b427f30b7e346961b8758edfd3b6708087360:packages/ts_checker/src/check.zig'], cwd=repo).decode()
current = (repo / 'packages/ts_checker/src/check.zig').read_text()
stop = '    /// For a top-level CommonJS'
original = parent.split('    fn moduleNamespaceTypeForLocalImport(', 1)[1].split(stop, 1)[0]
slow = current.split('    fn moduleNamespaceTypeForLocalImportSlow(', 1)[1].split(stop, 1)[0]
assert original == slow, 'Original resolver changed'
wrapper = current.split('    fn moduleNamespaceTypeForLocalImport(', 1)[1].split('    fn moduleNamespaceTypeForLocalImportSlow(', 1)[0]
assert 'if (self.hir.import_payloads.items.len == 0) return null;' in wrapper
assert 'return self.moduleNamespaceTypeForLocalImportSlow(name, anchor);' in wrapper
for forbidden in ['source_may_have', 'sourceMarker', 'cache', '.put(', 'lookupLocal', 'contains(']:
    assert forbidden not in wrapper
changed = subprocess.check_output(['git', 'diff', '--name-only'], cwd=repo).decode().splitlines()
assert changed == ['packages/ts_checker/src/check.zig']
result = {'passed': True, 'source_parent': 'cb6b427f30b7e346961b8758edfd3b6708087360',
          'original_resolver_body_byte_identical': True, 'new_state_or_cache': False,
          'source_keyword_or_filename_shortcut': False, 'live_HIR_import_pool': True,
          'patch_sha256': hashlib.sha256(subprocess.check_output(['git', 'diff'], cwd=repo)).hexdigest()}
(root / 'verified-source.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result), flush=True)
