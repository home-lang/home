"""Frozen exact-parent phases. Never repeat a completed phase or discard a sample."""
import hashlib
import json
import math
from pathlib import Path
import shlex
import subprocess
import sys

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
sys.path.insert(0, str(repo / 'bench/vs_tsgo'))
import run
import competitors

phase = sys.argv[1]
protocol = json.loads((root / 'protocol.json').read_text())
qualified = json.loads((root / 'verified-image-admission.json').read_text())
assert qualified['passed'] and qualified['admissions'] == 180
build = json.loads((root / 'candidate-build.json').read_text())
assert json.loads((root / 'checker-second.json').read_text())['exit'] == 0
assert 'All 4557 tests passed.' in (root / 'checker-second.log').read_text()
gates = json.loads((root / 'remaining-gates.json').read_text())
assert {record['target'] for record in gates} == {'program', 'driver', 'cli', 'entrypoint'}
assert all(record['exit'] == 0 for record in gates)
assert 'Ran 147 tests' in (root / 'harness.log').read_text() and (root / 'harness.log').read_text().rstrip().endswith('OK')
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip() == protocol['parent_source']
assert subprocess.check_output(['git', 'diff'], cwd=repo).decode() == build['source_patch']
commands = {'parent': [str(root / 'parent-home-tsc')], 'candidate': [str(root / 'candidate-home-tsc')]}
assert hashlib.sha256(Path(commands['parent'][0]).read_bytes()).hexdigest() == qualified['parent_sha256']
assert hashlib.sha256(Path(commands['candidate'][0]).read_bytes()).hexdigest() == qualified['candidate_sha256']
if phase == 'screen':
    workloads, pairs = run.selected_workloads(None), protocol['screen_pairs_per_workload']
elif phase == 'target':
    workloads, pairs = [protocol['independent_target']], protocol['independent_target_pairs']
elif phase.startswith('risk-'):
    name = phase[len('risk-'):]
    additional = json.loads((root / 'screen-statistics.json').read_text())['additional_adverse_workloads']
    assert name in protocol['independent_regression_workloads'] or name in additional
    workloads, pairs = [name], protocol['independent_regression_pairs']
else:
    raise ValueError('Unknown frozen phase')
output = root / phase
output.mkdir(exist_ok=False)
profiles = competitors.load_profiles(repo / 'bench/vs_tsgo/profiles/darwin-arm64.json')
all_commands = run.compiler_commands(profiles)
all_commands['home'] = commands['candidate']
def provenance():
    result = run.benchmark_provenance(all_commands, profiles)
    result['compilers']['parent'] = {'command': commands['parent'], 'executable': run.artifact_provenance(Path(commands['parent'][0]))}
    return result
before = provenance()
admitted = json.loads((root / 'image-admission.jsonl').read_text())
assert before == admitted['after']
trace = []
metadata = {'schema': 1, 'phase': phase, 'workloads': workloads, 'pairs': pairs, 'warmups': protocol['warmups'],
    'schedule': 'alternating parent/candidate order', 'source_parent': protocol['parent_source'],
    'parent_sha256': qualified['parent_sha256'], 'candidate_sha256': qualified['candidate_sha256'],
    'protocol_sha256': hashlib.sha256((root / 'protocol.json').read_bytes()).hexdigest(),
    'runner_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), 'before': before,
    'after': None, 'status': 'running', 'admissions': trace}
(output / 'metadata.json').write_text(json.dumps(metadata, indent=2) + '\n')
try:
    for workload in workloads:
        run.validate(commands, workload, trace=trace)
        (output / 'metadata.json').write_text(json.dumps(metadata, indent=2) + '\n')
        config = run.CORPUS / workload / 'tsconfig.json'
        argv = {name: command + ['--noEmit', '-p', str(config)] for name, command in commands.items()}
        names = list(argv)
        for index in range(protocol['warmups']):
            order = names[index % 2:] + names[:index % 2]
            for name in order:
                subprocess.run(argv[name], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        for index in range(pairs):
            order = names[index % 2:] + names[:index % 2]
            path = output / f'{workload}-pair-{index:03d}.json'
            timer = ['hyperfine', '--shell=none', '--runs', '1', '--style', 'none', '--export-json', str(path)]
            for name in order:
                timer += ['--command-name', name + ' ' + workload, shlex.join(argv[name])]
            subprocess.run(timer, check=True)
            data = json.loads(path.read_text())
            assert [record['command'] for record in data['results']] == [name + ' ' + workload for name in order]
            for record in data['results']:
                assert record['exit_codes'] == [0] and len(record['times']) == 1
                assert math.isfinite(record['times'][0]) and record['times'][0] > 0
        print(phase, workload, pairs, 'original pairs completed', flush=True)
    after = provenance()
    assert after == before
    assert subprocess.check_output(['git', 'diff'], cwd=repo).decode() == build['source_patch']
    metadata.update(after=after, status='complete')
except BaseException as error:
    metadata.update(status='incomplete', error={'type': type(error).__name__, 'message': str(error)})
    raise
finally:
    (output / 'metadata.json').write_text(json.dumps(metadata, indent=2) + '\n')
print(phase, 'complete without filtering or reruns', flush=True)
