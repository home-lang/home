import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
verified = json.loads((root / 'verified-completed.json').read_text())
assert verified['passed'] and verified['decision'] == 'reject' and verified['pairs'] == 530
assert verified['per_phase_admissions'] == 100 and verified['initial_admissions'] == 180
assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=repo).decode() == ''
assert hashlib.sha256((repo / 'zig-out/bin/home-tsc').read_bytes()).hexdigest() == verified['native_restored_sha256']
excluded = {'parent-home-tsc', 'candidate-home-tsc', 'next-state.json', 'final-outcome-state.json', 'package-rejection.json'}
entries = {}
for path in sorted(root.rglob('*')):
    assert not path.is_symlink()
    if path.is_file() and path.name not in excluded and '__pycache__' not in path.parts:
        entries['experiment/' + str(path.relative_to(root))] = path.read_bytes()
for name in ['run.py', 'compare.py', 'competitors.py', 'corpus.toml']:
    entries['harness/' + name] = (repo / 'bench/vs_tsgo' / name).read_bytes()
entries['harness/darwin-arm64.json'] = (repo / 'bench/vs_tsgo/profiles/darwin-arm64.json').read_bytes()
for path in sorted((repo / 'bench/vs_tsgo/corpus').rglob('*')):
    if path.is_file():
        entries['inputs/' + str(path.relative_to(repo / 'bench/vs_tsgo/corpus'))] = path.read_bytes()
publication = {**verified, 'source': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip(),
               'primary_acceptance_failed': True, 'independent_confirmed_regression': False,
               'native_binaries_excluded': True, 'all_warnings_and_original_failures_retained': True,
               'source_candidate_removed': True, 'full_competitor_rank_changed': False}
entries['publication.json'] = (json.dumps(publication, indent=2) + '\n').encode()
checksums = {name: hashlib.sha256(data).hexdigest() for name, data in entries.items()}
entries['SHA256SUMS'] = ''.join(checksums[name] + '  ' + name + '\n' for name in sorted(checksums)).encode()
output = repo / 'bench/vs_tsgo/evidence/20261010-live-hir-import-absence-rejected-864.tar.gz'
assert not output.exists()
with output.open('xb') as raw:
    with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as tar:
            for name, data in sorted(entries.items()):
                item = tarfile.TarInfo(name)
                item.size, item.mode = len(data), 0o644
                tar.addfile(item, io.BytesIO(data))
with tarfile.open(output, 'r:gz') as tar:
    for name, digest in checksums.items():
        assert hashlib.sha256(tar.extractfile(name).read()).hexdigest() == digest
result = {'archive': str(output.relative_to(repo)), 'sha256': hashlib.sha256(output.read_bytes()).hexdigest(),
          'payload_checksums': len(checksums), 'bytes': output.stat().st_size, 'verified': True}
(root / 'package-rejection.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result), flush=True)
