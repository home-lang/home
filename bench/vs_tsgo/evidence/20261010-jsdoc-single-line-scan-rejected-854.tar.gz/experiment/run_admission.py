import json
import os
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
record_path = root / 'image-admission-command.json'
assert not record_path.exists(), 'Observe original execution, do not duplicate it'
command = ['perl', 'scripts/run-bounded.pl', '600', sys.executable, str(root / 'admit_images.py')]
record = {'command': command, 'guard_max_mb': 3840, 'status': 'running'}
record_path.write_text(json.dumps(record, indent=2) + '\n')
environment = dict(os.environ, HOME_RUN_MAX_MB='3840', HOME_RUN_LABEL='ts854-single-line-scan-admission')
with (root / 'image-admission-run.log').open('w') as output:
    result = subprocess.run(command, cwd=repo, env=environment, stdout=output, stderr=subprocess.STDOUT)
record.update(exit=result.returncode, status='complete' if result.returncode == 0 else 'incomplete')
record_path.write_text(json.dumps(record, indent=2) + '\n')
print((root / 'image-admission-run.log').read_text()[-1700:], flush=True)
raise SystemExit(result.returncode)
