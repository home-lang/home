"""Audit all completed original samples; never invoke a compiler or timer."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
sys.path.insert(0, str(root))
import paired_statistics

protocol = json.loads((root / 'protocol.json').read_text())
execution = json.loads((root / 'qualified-protocol-command.json').read_text())
assert execution['status'] == 'complete' and execution['exit'] == 0
assert all(step['exit'] == 0 for step in execution['completed_steps'])
phases = ['screen', 'target'] + ['risk-' + name for name in protocol['independent_regression_workloads']]
saved_screen = json.loads((root / 'screen-statistics.json').read_text())
phases += ['risk-' + name for name in saved_screen['additional_adverse_workloads']
           if name not in protocol['independent_regression_workloads']]
reports = []
for phase in phases:
    saved = json.loads((root / (phase + '-statistics.json')).read_text())
    recomputed = paired_statistics.validate_phase(phase)
    assert saved == recomputed
    command = json.loads((root / (phase + '-command.json')).read_text())
    assert command['status'] == 'complete' and command['exit'] == 0
    log = (root / (phase + '-run.log')).read_text()
    assert 'run-bounded: peak tree footprint' in log
    reports.append(recomputed)
saved_decision = json.loads((root / 'decision.json').read_text())
subprocess.run([sys.executable, str(root / 'decide.py')], check=True)
assert json.loads((root / 'decision.json').read_text()) == saved_decision
assert saved_decision['decision'] in ('eligible', 'reject')
assert sum(report['pairs'] for report in reports) == saved_decision['pairs']
assert sum(report['admissions'] for report in reports) >= 100
result = {'passed': True, 'original_pairs': saved_decision['pairs'], 'phase_admissions': sum(report['admissions'] for report in reports),
          'initial_image_admissions': 180, 'phases': len(phases),
          'statistical_results_independently_recomputed': True,
          'measurement_repeats': 0, 'discarded_samples': 0,
          'decision': saved_decision['decision'], 'wrapper_phase_exits_all_zero': True,
          'original_image_admission_wrapper_accounting_unknown': False,
          'protocol_sha256': hashlib.sha256((root / 'protocol.json').read_bytes()).hexdigest(),
          'source_adopted': False, 'competitor_ranking_updated': False,
          'universal_goal_complete': False}
(root / 'verified-completed.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result), flush=True)
