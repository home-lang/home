import json
import os
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
phase = sys.argv[1]
record_path = root / (phase + '-command.json')
assert not record_path.exists(), 'Existing phase execution must be audited, not restarted'
command = ['perl', 'scripts/run-bounded.pl', '600', sys.executable, str(root / 'paired.py'), phase]
environment = dict(os.environ, HOME_RUN_MAX_MB='3840', HOME_RUN_LABEL='ts854-single-line-scan-' + phase)
record = {'command': command, 'guard_max_mb': 3840, 'guard_seconds': 600, 'phase': phase, 'status': 'running'}
record_path.write_text(json.dumps(record, indent=2) + '\n')
with (root / (phase + '-run.log')).open('w') as output:
    result = subprocess.run(command, cwd=repo, env=environment, stdout=output, stderr=subprocess.STDOUT)
record.update(exit=result.returncode, status='complete' if result.returncode == 0 else 'incomplete')
record_path.write_text(json.dumps(record, indent=2) + '\n')
print((root / (phase + '-run.log')).read_text()[-2200:], flush=True)
raise SystemExit(result.returncode)
