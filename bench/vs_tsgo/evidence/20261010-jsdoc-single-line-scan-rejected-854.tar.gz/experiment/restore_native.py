import hashlib
import json
import os
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
assert not (root / 'restoration.json').exists()
assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=repo).decode() == ''
command = ['perl', 'scripts/run-bounded.pl', '600',
 '/Users/chris/Code/Home/lang-bun-port/zig-out/toolchains/zig-aarch64-macos-0.17.0-dev.2163+89ff10d56/zig',
 'build', 'home-tsc', '-Doptimize=ReleaseFast', '-Dhome-tsc-strip=true', '-Denable_jsc=false', '-j1', '--summary', 'all']
environment = dict(os.environ, HOME_RUN_MAX_MB='3840', HOME_RUN_LABEL='ts854-rejected-line-scan-restore')
with (root / 'restoration-build.log').open('w') as output:
    result = subprocess.run(command, cwd=repo, env=environment, stdout=output, stderr=subprocess.STDOUT)
record = {'command': command, 'exit': result.returncode,
          'source': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip(),
          'source_candidate_removed': True, 'tests_candidate_removed': True}
if result.returncode == 0:
    record['native_sha256'] = hashlib.sha256((repo / 'zig-out/bin/home-tsc').read_bytes()).hexdigest()
    assert record['native_sha256'] == 'ff78eeff3f36f622db610d23881be7165dce31b424481318e82360f1da5935f8'
(root / 'restoration.json').write_text(json.dumps(record, indent=2) + '\n')
print((root / 'restoration-build.log').read_text(), flush=True)
print(json.dumps(record), flush=True)
raise SystemExit(result.returncode)
