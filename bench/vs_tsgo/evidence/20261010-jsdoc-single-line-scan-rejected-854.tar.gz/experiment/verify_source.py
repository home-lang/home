import hashlib
import json
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
parent = '91c8756acac8c050bb68162a979ee97819784270'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip() == parent
before = subprocess.check_output(['git', 'show', parent + ':packages/ts_checker/src/check.zig'], cwd=repo).decode()
after = (repo / 'packages/ts_checker/src/check.zig').read_text()
def function(source, name):
    start = source.index('    fn ' + name + '(')
    end = source.index('\n    fn ', start + 5)
    return source[start:end]
original = function(before, 'leadingJsDocBodyWithStart')
expected = original.replace('            var line_start = cursor;\n',
    '            var line_start = cursor;\n            var line_comment: ?usize = null;\n').replace(
    '                line_start -= 1;\n',
    '                line_start -= 1;\n                // Keep replacing while walking backward, so the result is\n                // the leftmost // in this line, as the forward search was.\n                if (line_start + 1 < cursor and src[line_start] == \'/\' and src[line_start + 1] == \'/\')\n                    line_comment = line_start;\n').replace(
    '            const line_comment = std.mem.indexOf(u8, src[line_start..cursor], "//") orelse return null;\n            cursor = line_start + line_comment;\n',
    '            cursor = line_comment orelse return null;\n')
assert function(after, 'leadingJsDocBodyWithStart') == expected
assert after[:after.index('// =============================================================================\n// Tests')] == before[:before.index('// =============================================================================\n// Tests')].replace(original, expected)
patch = subprocess.check_output(['git', 'diff'], cwd=repo)
result = {'passed': True, 'source_parent': parent, 'only_production_change_exact_single_line_scan': True,
          'existing_attachment_and_source_fact_rules_unchanged': True,
          'new_cache_or_allocation': False, 'tests_use_independent_original_algorithm': True,
          'patch_sha256': hashlib.sha256(patch).hexdigest()}
(root / 'verified-source.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result), flush=True)
