import hashlib
import json
from pathlib import Path
import re
import subprocess

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
provenance = json.loads((root / 'provenance.json').read_text())
assert len(provenance['admissions']) == 62 and all(row['passed'] for row in provenance['admissions'])
assert not provenance['diagnostic_image_used_for_timing']
assert (root / 'original-text.bin').read_bytes() == (root / 'renamed-text.bin').read_bytes()
assert hashlib.sha256((root / 'original-text.bin').read_bytes()).hexdigest() == provenance['text_sha256']
record = json.loads((root / 'checkjs8192-profile.json').read_text())
assert record['compiler_exit'] == 0 and not record['stdout'] and not record['stderr']
assert record['input_hash_before'] == record['input_hash_after']
assert [row['label'] for row in record['samples']] == ['early', 'middle']
samples = {}
for row in record['samples']:
    assert row['sample_exit'] == 0
    data = Path(row['path']).read_text()
    main = re.search(r'^\s+(\d+) Thread_\d+\s+DispatchQueue_1:', data, re.MULTILINE)
    assert main
    top = data.split('Sort by top of stack, same collapsed (when >= 5):', 1)[1].split('Binary Images:', 1)[0]
    leaves = {}
    for line in top.splitlines():
        match = re.match(r'\s+(.+?)\s+\(in .+?\)\s+(\d+)\s*$', line)
        if match:
            leaves[match.group(1)] = int(match.group(2))
    samples[row['label']] = {'main_thread_observations': int(main.group(1)), 'leaf_observations_at_least_five': leaves}
source = subprocess.check_output(['git', 'show', provenance['source'] + ':packages/ts_checker/src/check.zig'], cwd=repo)
start = source.index(b'    fn jsDocTypeForPreviousIdentifierDecl(')
stop = source.index(b'    fn reportJsDocArrayAssignmentMismatch(', start)
(root / 'original-previous-jsdoc-declaration.zig').write_bytes(source[start:stop])
binary = root / 'home-tsc-profile'
command = ['/Users/chris/.local/share/pantry/global/bin/llvm-objdump', '--disassemble',
    '--start-address=0x1003a8360', '--stop-address=0x1003a8570', str(binary)]
result = subprocess.run(command, capture_output=True, text=True, check=True)
assert '1003a8404:' in result.stdout and '1003a8418:' in result.stdout
assert 'sub\tw8, w8, #0x3' in result.stdout
assert 'virtualSectionStartForNode' in result.stdout
(root / 'previous-jsdoc-loop-assembly.txt').write_text(result.stdout)
(root / 'previous-jsdoc-loop-command.json').write_text(json.dumps(command, indent=2) + '\n')
report = {'source': provenance['source'], 'native_sha256': provenance['binary_sha256'],
    'diagnostic_sha256': provenance['diagnostic_sha256'], 'text_sha256': provenance['text_sha256'],
    'admissions': 62, 'samples': samples,
    'interpretation': 'Separate one-second exploratory leaf counts, not whole-run CPU percentages or causal speed proof',
    'source_candidate': 'jsDocTypeForPreviousIdentifierDecl / nearestPriorValueDeclInSameFunction',
    'mapped_source_function': 'nearestPriorValueDeclInSameFunction, inlined into jsDocTypeForPreviousIdentifierDecl',
    'mapped_loop': 'Full HIR ordinal scan; kinds3/4/5 var/let/const, earlier/nearest source position, identifier/name equality, enclosing-function and virtual-section eligibility',
    'symbol_start': '0x1003a8278', 'sampled_offsets': [400, 416, 432],
    'sampled_addresses': [hex(0x1003a8278 + offset) for offset in (400, 416, 432)],
    'source_scanner_sha256': hashlib.sha256(source[start:stop]).hexdigest(),
    'timing_samples_from_diagnostic_image': 0}
(root / 'verified-profile.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
