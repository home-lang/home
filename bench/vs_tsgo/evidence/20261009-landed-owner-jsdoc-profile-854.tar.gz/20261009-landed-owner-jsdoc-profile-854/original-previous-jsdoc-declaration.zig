    fn jsDocTypeForPreviousIdentifierDecl(self: *Checker, node: NodeId) CheckError!?TypeId {
        if (!self.sourceHasCheckJsDirective()) return null;
        if (node == hir_mod.none_node_id or self.hir.kindOf(node) != .identifier) return null;
        if (self.source_has_virtual_sections and
            !self.virtualSectionIsJsLike(node))
        {
            return null;
        }
        const id = hir_mod.identifierOf(self.hir, node);
        if (self.nearestPriorValueDeclInSameFunction(node, id.name)) |decl| {
            if (try self.jsDocTypeForLeadingNode(decl)) |declared_t| return declared_t;
        }
        const use_start = self.hir.spanOf(node).start;
        var cur = self.hir.parentOf(node);
        while (cur != hir_mod.none_node_id) : (cur = self.hir.parentOf(cur)) {
            const stmts: ?[]const NodeId = switch (self.hir.kindOf(cur)) {
                .block_stmt => hir_mod.blockStmts(self.hir, cur),
                .namespace_decl => hir_mod.namespaceBody(self.hir, cur),
                else => null,
            };
            if (stmts) |items| {
                for (items) |stmt| {
                    if (self.hir.spanOf(stmt).start >= use_start) break;
                    const decl = if (self.hir.kindOf(stmt) == .export_decl) hir_mod.exportOf(self.hir, stmt).decl else stmt;
                    if (decl == hir_mod.none_node_id) continue;
                    const dk = self.hir.kindOf(decl);
                    if (dk != .var_decl and dk != .let_decl and dk != .const_decl) continue;
                    const v = hir_mod.varDeclOf(self.hir, decl);
                    if (v.name == hir_mod.none_node_id or self.hir.kindOf(v.name) != .identifier) continue;
                    if (hir_mod.identifierOf(self.hir, v.name).name != id.name) continue;
                    return try self.jsDocTypeForLeadingNode(decl);
                }
            }
        }
        return null;
    }

    fn jsDocAssignmentIdentifierTypeName(self: *Checker, node: NodeId, source_t: TypeId) CheckError!?[]const u8 {
        if (node == hir_mod.none_node_id or self.hir.kindOf(node) != .identifier) return null;
        if ((try self.jsDocTypeForPreviousIdentifierDecl(node)) == null) return null;
        return try self.allocAssignmentDiagnosticTypeName(source_t);
    }

    fn nearestPriorValueDeclInSameFunction(self: *Checker, node: NodeId, name: hir_mod.StringId) ?NodeId {
        const use_start = self.hir.spanOf(node).start;
        const use_function = self.enclosingFunctionLike(node);
        var nearest = hir_mod.none_node_id;
        var nearest_start: u32 = 0;
        var candidate: NodeId = 0;
        while (candidate < self.hir.nodeCount()) : (candidate += 1) {
            const kind = self.hir.kindOf(candidate);
            if (kind != .var_decl and kind != .let_decl and kind != .const_decl) continue;
            const start = self.hir.spanOf(candidate).start;
            if (start >= use_start or (nearest != hir_mod.none_node_id and start <= nearest_start)) continue;
            const declaration = hir_mod.varDeclOf(self.hir, candidate);
            if (declaration.name == hir_mod.none_node_id or self.hir.kindOf(declaration.name) != .identifier) continue;
            if (hir_mod.identifierOf(self.hir, declaration.name).name != name) continue;
            const candidate_function = self.enclosingFunctionLike(candidate);
            if (candidate_function != use_function) {
                if (candidate_function != null or use_function == null) continue;
                const function_span = self.hir.spanOf(use_function.?);
                if (start < function_span.start or start >= function_span.end) continue;
            }
            if (self.source_has_virtual_sections and
                self.virtualSectionStartForNode(candidate) != self.virtualSectionStartForNode(node))
            {
                continue;
            }
            nearest = candidate;
            nearest_start = start;
        }
        return if (nearest == hir_mod.none_node_id) null else nearest;
    }

