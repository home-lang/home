import hashlib
import json
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
parent = '4bbbd191d83df1e8c6f44c8b0bd96a9490f57e0c'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip() == parent
patch = subprocess.check_output(['git', 'diff', '--', 'packages/ts_checker/src/check.zig'], cwd=repo)
assert not (root / 'first-draft.patch').exists()
(root / 'first-draft.patch').write_bytes(patch)
(root / 'initial-provenance.json').write_text(json.dumps({
    'source_parent': parent,
    'first_draft_patch_sha256': hashlib.sha256(patch).hexdigest(),
    'parent_binary_sha256': hashlib.sha256((root / 'home-tsc-parent').read_bytes()).hexdigest(),
    'mapped_profile_source': '96295781351d015b7ebaafbd368e66f6b21a9c33',
    'timing_acceptance': 'pending; no timing samples yet'}, indent=2) + '\n')
print('Preserved complete initial source/test draft against the exact landed parent.')
