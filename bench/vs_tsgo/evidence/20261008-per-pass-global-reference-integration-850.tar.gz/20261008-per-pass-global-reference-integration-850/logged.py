import json
from pathlib import Path
import shutil
import subprocess
import sys

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
zig = '/Users/chris/Code/Home/lang-bun-port/zig-out/toolchains/zig-aarch64-macos-0.17.0-dev.2163+89ff10d56/zig'
action = sys.argv[1]
prefix = sys.argv[2] if len(sys.argv) > 2 else ''
assert prefix in ('', 'integrated')
label = (prefix + '-' if prefix else '') + action
if action == 'build':
    payload = [zig, 'build', 'home-tsc', '-Doptimize=ReleaseFast', '-Dhome-tsc-strip=true', '-Denable_jsc=false', '-j1', '--summary', 'all']
elif action in ('screen', 'confirmation', 'families', 'recheck'):
    payload = ['python3', str(root / 'paired.py'), action]
elif action == 'global-audit':
    payload = ['python3', str(root / 'global_audit.py')]
elif action == 'global-audit-integrated':
    payload = ['python3', str(root / 'global_audit_integrated.py')]
elif action == 'zod-integrated':
    payload = ['python3', 'scripts/ts-unmodeled-any-ratchet.py', '--compiler', str(root / 'home-tsc-integrated'),
               '--write-current', str(root / 'zod-integrated.json'), '--diagnostics-output', str(root / 'zod-integrated-diagnostics.log')]
elif action == 'integrated-admission':
    payload = ['python3', str(root / 'integrated_admission.py')]
elif action == 'harness':
    payload = ['python3', '-m', 'unittest', 'discover', '-s', 'bench/vs_tsgo', '-p', 'test_*.py']
elif action in ('zod-parent', 'zod-candidate'):
    name = action.removeprefix('zod-')
    payload = ['python3', 'scripts/ts-unmodeled-any-ratchet.py', '--compiler', str(root / ('home-tsc-' + name)),
               '--write-current', str(root / (action + '.json')), '--diagnostics-output', str(root / (action + '-diagnostics.log'))]
else:
    assert action in ('program', 'checker', 'driver', 'cli', 'entrypoint')
    payload = ['python3', '/Users/chris/.cache/home-ts-843.3BeUMH/module_tests.py', action]
command = ['env', 'HOME_RUN_MAX_MB=3840', 'HOME_RUN_LABEL=ts850-' + label,
           'perl', 'scripts/run-bounded.pl', '600', *payload]
result = subprocess.run(command, cwd=repo, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
(root / (label + '-logged.log')).write_text(result.stdout)
(root / (label + '-command.json')).write_text(json.dumps({'command': command, 'exit': result.returncode}, indent=2) + '\n')
print(result.stdout[-3000:], flush=True)
if action == 'build' and result.returncode == 0:
    shutil.copy2(repo / 'zig-out/bin/home-tsc', root / ('home-tsc-integrated' if prefix else 'home-tsc-candidate'))
sys.exit(result.returncode)
