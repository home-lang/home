import hashlib
import json
from pathlib import Path
import sys

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
sys.path.insert(0, str(repo / 'bench/vs_tsgo'))
import run
import competitors

binary = root / 'home-tsc-integrated'
command = [str(binary)]
def fingerprints():
    return {'binary_sha256': run.sha256_file(binary),
        'official': competitors.inventory_hash(competitors.payload_inventory(run.CORPUS)),
        'scales': {name: competitors.inventory_hash(competitors.payload_inventory(root / name))
                   for name in ('commonjs1024', 'commonjs1024-negative', 'commonjs4096', 'commonjs4096-negative')},
        'program_source_sha256': run.sha256_file(repo / 'packages/ts_program/src/ts_program.zig'),
        'transfer_source_sha256': run.sha256_file(repo / 'packages/ts_checker/src/type_transfer.zig'),
        'runner_sha256': run.sha256_file(Path(__file__))}
before = fingerprints()
trace = []
for workload in run.manifest()['workloads']:
    run.validate({'integrated': command}, workload, trace=trace)
for workload in ('commonjs1024', 'commonjs4096'):
    for kind in ('positive', 'negative'):
        project = root / (workload if kind == 'positive' else workload + '-negative') / 'tsconfig.json'
        expected = None if kind == 'positive' else ['2322'] * 3 + ['2339'] * 3
        _, passed = run.admission_process('integrated', command + ['--noEmit', '-p', str(project)], workload,
                                          expected_codes=expected, trace=trace)
        assert passed
assert len(trace) == 32 and all(row['passed'] for row in trace)
after = fingerprints()
assert before == after
(root / 'integrated-admission.json').write_text(json.dumps({'records': trace,
    'fingerprints_before': before, 'fingerprints_after': after, 'timing_samples': 0}, indent=2) + '\n')
print(json.dumps({'admissions': len(trace), 'passed': sum(row['passed'] for row in trace),
                  'binary_sha256': before['binary_sha256'], 'timing_samples': 0}), flush=True)
