from collections import Counter
import hashlib
import json
from pathlib import Path
import re

root = Path(__file__).resolve().parent
def diagnostics(path):
    result = Counter()
    for line in path.read_text().splitlines():
        match = re.match(r'(.+?)\((\d+),(\d+)\): (error|warning) ((?:TS|HM)\d+): (.*)', line)
        if match:
            file, row, column, severity, code, message = match.groups()
            prefix = file.split('/package/', 1)[0] + '/package/'
            assert '/package/' in file
            result[(file.replace(prefix, '$PACKAGE/'), int(row), int(column), severity,
                    code, message.replace(prefix, '$PACKAGE/'))] += 1
    return result
parent = diagnostics(root / 'zod-parent-diagnostics.log')
candidate = diagnostics(root / 'zod-candidate-diagnostics.log')
metadata = {name: json.loads((root / ('zod-' + name + '.json')).read_text()) for name in ('parent', 'candidate')}
assert metadata['parent']['corpus'] == metadata['candidate']['corpus']
assert metadata['parent']['compiler_exit'] == metadata['candidate']['compiler_exit'] == 1
assert parent == candidate, {'added': list((candidate - parent).elements()), 'removed': list((parent - candidate).elements())}
assert sum(parent.values()) == 198
rows = [list(key) + [count] for key, count in sorted(parent.items())]
data = (json.dumps(rows, sort_keys=True, separators=(',', ':')) + '\n').encode()
(root / 'zod-normalized.json').write_bytes(data)
summary = {'diagnostics': sum(parent.values()),
           'ts_errors': sum(count for key, count in parent.items() if key[4].startswith('TS')),
           'hm9002': sum(count for key, count in parent.items() if key[4] == 'HM9002'),
           'added': 0, 'removed': 0, 'complete_primary_messages_equal': True,
           'normalized_sha256': hashlib.sha256(data).hexdigest(), 'production_admitted': False,
           'corpus': metadata['parent']['corpus']}
(root / 'zod-comparison.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary))
