import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
name = '20261008-per-pass-global-reference-integration-850'
summary = json.loads((root / 'integration-summary.json').read_text())
admission = json.loads((root / 'integrated-admission.json').read_text())
assert len(admission['records']) == 32 and all(row['passed'] for row in admission['records'])
assert admission['fingerprints_before'] == admission['fingerprints_after']
assert summary['binary_sha256'] == admission['fingerprints_before']['binary_sha256']
for field, path in [('program_source_sha256', 'packages/ts_program/src/ts_program.zig'),
                    ('transfer_source_sha256', 'packages/ts_checker/src/type_transfer.zig')]:
    assert hashlib.sha256((repo / path).read_bytes()).hexdigest() == admission['fingerprints_before'][field]
for action in ('integrated-checker', 'integrated-program', 'integrated-build', 'integrated-admission',
               'global-audit-integrated', 'zod-integrated'):
    assert json.loads((root / (action + '-command.json')).read_text())['exit'] == 0
assert 'All 4527 tests passed.' in (root / 'integrated-checker-logged.log').read_text()
assert 'All 247 tests passed.' in (root / 'integrated-program-logged.log').read_text()
audit_root = root / 'integrated-semantic-audit'
audit = json.loads((audit_root / 'global-audit.json').read_text())['records']
assert len(audit) == 464 and all(row['passed'] for row in audit)
entries = {}
def add(path, target):
    assert target not in entries
    entries[target] = path.read_bytes()
for filename in ('integration-summary.json', 'integrated-admission.json', 'integrated_admission.py',
                 'global_audit_integrated.py', 'logged.py', 'verify_zod.py', 'publish_integration.py',
                 'zod-integrated.json', 'zod-integrated-diagnostics.log', 'zod-candidate-diagnostics.log',
                 'zod-comparison.json', 'zod-normalized.json', 'candidate.patch'):
    add(root / filename, filename)
for action in ('integrated-checker', 'integrated-program', 'integrated-build', 'integrated-admission',
               'global-audit-integrated', 'zod-integrated'):
    for suffix in ('-command.json', '-logged.log'):
        add(root / (action + suffix), 'logs/' + action + suffix)
for child in sorted(audit_root.rglob('*')):
    if child.is_file():
        add(child, 'semantic-audit/' + child.relative_to(audit_root).as_posix())
for filename in ('packages/ts_program/src/ts_program.zig', 'packages/ts_checker/src/type_transfer.zig'):
    add(repo / filename, 'source/' + filename)
for filename in ('run.py', 'competitors.py', 'audit_globals.py', 'audit_bound_globals.py', 'corpus.toml'):
    add(repo / 'bench/vs_tsgo' / filename, 'harness/' + filename)
add(Path('/Users/chris/.cache/home-ts-843.3BeUMH/module_tests.py'), 'scripts/module_tests.py')
source_commit = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
assert source_commit == '00a9dcf8fd4cf6ce4505803f6a699e1dec6c2650'
entries['publication-scope.json'] = (json.dumps({'source_commit': source_commit,
    'integration_base': summary['integration_base'], 'verification_head': summary['verification_head'],
    'native_sha256': summary['binary_sha256'], 'timing_samples': 0,
    'frozen_ab_archive_sha256': 'ddbc0e6cc1346872078a1202290a236bc52fa0f7a0fcaefac18814231ac211ed',
    'new_competitor_ranking': False, 'footprint_guard_mb': 3840,
    'recorded_peaks_mb': {'checker': 3080, 'program': 3210, 'build': 3023,
                          'semantic_audit': 58, 'admission': 976, 'zod': 532}}, indent=2) + '\n').encode()
checksums = ''.join(hashlib.sha256(data).hexdigest() + '  ' + path + '\n' for path, data in sorted(entries.items()))
count = len(entries)
entries['SHA256SUMS'] = checksums.encode()
archive = repo / 'bench/vs_tsgo/evidence' / (name + '.tar.gz')
assert not archive.exists()
with archive.open('wb') as output:
    with gzip.GzipFile(filename='', mode='wb', fileobj=output, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as tar:
            for path, data in sorted(entries.items()):
                info = tarfile.TarInfo(name + '/' + path)
                info.size, info.mode, info.mtime = len(data), 0o644, 0
                tar.addfile(info, io.BytesIO(data))
with tarfile.open(archive) as tar:
    for line in checksums.splitlines():
        digest, path = line.split('  ', 1)
        assert hashlib.sha256(tar.extractfile(name + '/' + path).read()).hexdigest() == digest
print(json.dumps({'archive': str(archive), 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
                  'size': archive.stat().st_size, 'verified_payload_checksums': count}), flush=True)
