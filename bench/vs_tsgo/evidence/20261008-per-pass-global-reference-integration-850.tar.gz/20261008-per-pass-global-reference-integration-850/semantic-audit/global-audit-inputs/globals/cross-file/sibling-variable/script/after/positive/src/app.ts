const good: string = methods.identity('ok');
