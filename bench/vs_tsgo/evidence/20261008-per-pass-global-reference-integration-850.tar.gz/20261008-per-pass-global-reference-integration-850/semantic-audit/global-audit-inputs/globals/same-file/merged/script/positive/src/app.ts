interface Methods { identity(value: string): string; }
interface Methods { count(value: number): number; }
declare var methods: Methods;
const good: string = methods.identity('ok');
const count: number = methods.count(1);
