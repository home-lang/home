interface Methods { count(value: number): number; }
