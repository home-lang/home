const good: string = methods.identity('ok');
const bad: number = methods.identity('ok');
methods.identity(1);
methods.missing();
