interface Methods { identity(value: string): string; }
type Alias = Methods;
declare var methods: Alias;
const good: string = methods.identity('ok');
