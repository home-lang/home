interface Methods { identity(value: number): number; }
