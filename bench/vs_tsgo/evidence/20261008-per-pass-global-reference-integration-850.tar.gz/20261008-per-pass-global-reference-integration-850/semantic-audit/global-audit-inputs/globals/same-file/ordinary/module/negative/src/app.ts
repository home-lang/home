export {};
interface Methods { identity(value: string): string; }
declare var methods: Methods;
const good: string = methods.identity('ok');
const bad: number = methods.identity('ok');
methods.identity(1);
methods.missing();
