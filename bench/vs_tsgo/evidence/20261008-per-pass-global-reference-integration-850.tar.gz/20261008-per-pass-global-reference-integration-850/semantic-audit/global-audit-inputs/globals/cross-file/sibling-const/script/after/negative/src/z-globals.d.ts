declare const lexicalValue: number;
