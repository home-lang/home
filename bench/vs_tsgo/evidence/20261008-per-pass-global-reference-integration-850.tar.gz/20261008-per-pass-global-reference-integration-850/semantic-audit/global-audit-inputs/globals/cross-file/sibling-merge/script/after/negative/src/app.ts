interface Methods { identity(value: string): string; }
declare var methods: Methods;
const good: string = methods.identity('ok');
const count: number = methods.count(1);
const bad: number = methods.identity('ok');
methods.count('bad');
methods.missing();
