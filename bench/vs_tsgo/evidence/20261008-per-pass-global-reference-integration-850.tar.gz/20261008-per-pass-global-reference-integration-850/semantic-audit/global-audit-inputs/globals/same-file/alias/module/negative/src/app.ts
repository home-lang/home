export {};
interface Methods { identity(value: string): string; }
type Alias = Methods;
declare var methods: Alias;
const good: string = methods.identity('ok');
const bad: number = methods.identity('ok');
methods.identity(1);
