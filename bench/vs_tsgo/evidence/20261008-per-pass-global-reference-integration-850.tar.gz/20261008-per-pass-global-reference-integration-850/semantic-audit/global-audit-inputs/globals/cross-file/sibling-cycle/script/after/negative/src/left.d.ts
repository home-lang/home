interface Left { right: Right; }
declare var left: Left;
