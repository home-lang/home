const goodValue: string = left.right.value;
const goodCycle: Left = left.right.left;
const badValue: number = left.right.value;
