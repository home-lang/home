declare let lexicalValue: number;
