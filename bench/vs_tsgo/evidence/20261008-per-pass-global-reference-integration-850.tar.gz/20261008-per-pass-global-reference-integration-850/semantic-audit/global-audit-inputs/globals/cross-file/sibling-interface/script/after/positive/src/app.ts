declare var methods: Methods;
const good: string = methods.identity('ok');
