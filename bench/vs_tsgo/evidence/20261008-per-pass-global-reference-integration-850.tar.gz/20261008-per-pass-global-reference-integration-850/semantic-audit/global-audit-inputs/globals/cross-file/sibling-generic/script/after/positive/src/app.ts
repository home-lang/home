declare var Deferred: DeferredConstructor;
const good: string = Deferred.identity('ok');
