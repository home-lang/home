interface DeferredConstructor { identity<T>(value: T): T; }
