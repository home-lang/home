declare var sharedValue: number;
