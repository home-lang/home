const Methods = 1;
interface Methods { identity(value: string): string; }
declare var methods: Methods;
const good: string = methods.identity('ok');
