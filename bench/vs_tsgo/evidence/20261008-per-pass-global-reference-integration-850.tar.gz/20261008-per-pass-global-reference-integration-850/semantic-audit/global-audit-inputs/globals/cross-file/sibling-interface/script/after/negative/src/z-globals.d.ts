interface Methods { identity(value: string): string; }
