export {};
interface DeferredConstructor { identity<T>(value: T): T; }
declare var Deferred: DeferredConstructor;
const good: string = Deferred.identity('ok');
const bad: number = Deferred.identity('ok');
