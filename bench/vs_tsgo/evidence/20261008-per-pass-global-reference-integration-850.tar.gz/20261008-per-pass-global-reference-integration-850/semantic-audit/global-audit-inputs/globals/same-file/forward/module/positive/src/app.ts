export {};
declare var methods: Methods;
const good: string = methods.identity('ok');
interface Methods { identity(value: string): string; }
