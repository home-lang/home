const good: number = lexicalValue;
