interface Right { value: string; left: Left; }
