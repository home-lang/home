interface Methods { identity(value: string): string; }
declare var methods: Methods;
