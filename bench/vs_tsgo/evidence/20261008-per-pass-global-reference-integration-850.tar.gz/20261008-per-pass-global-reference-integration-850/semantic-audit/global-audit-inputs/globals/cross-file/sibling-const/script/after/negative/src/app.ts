const good: number = lexicalValue;
const bad: string = lexicalValue;
