for (let privateValue = 0; privateValue < 1; privateValue++) {}
