/*
export {}
*/
var sharedValue = 1;
