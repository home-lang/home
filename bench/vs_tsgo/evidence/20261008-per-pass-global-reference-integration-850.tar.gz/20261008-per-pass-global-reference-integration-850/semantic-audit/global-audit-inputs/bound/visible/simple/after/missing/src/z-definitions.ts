var sharedValue = 1;
