var sh\u0061redValue = 1;
