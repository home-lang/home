namespace Scope { export var privateValue = 1; }
