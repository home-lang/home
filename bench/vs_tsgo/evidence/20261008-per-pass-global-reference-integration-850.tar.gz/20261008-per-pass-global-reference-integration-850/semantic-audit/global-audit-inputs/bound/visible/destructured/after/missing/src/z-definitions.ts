var { sharedValue } = { sharedValue: 1 };
