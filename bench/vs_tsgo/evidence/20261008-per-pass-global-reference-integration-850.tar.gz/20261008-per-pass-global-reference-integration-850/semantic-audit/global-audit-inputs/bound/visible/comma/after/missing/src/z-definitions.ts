var first = 0, sharedValue = 1;
