const good: number = 1;
globalThis.privateValue;
