const good: number = globalThis.sharedValue;
