if (true) { var sharedValue = 1; }
