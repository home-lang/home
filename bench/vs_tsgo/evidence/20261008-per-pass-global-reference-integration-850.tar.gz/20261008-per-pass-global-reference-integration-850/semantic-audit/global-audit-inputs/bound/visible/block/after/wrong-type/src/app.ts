const good: number = globalThis.sharedValue;
const bad: string = globalThis.sharedValue;
