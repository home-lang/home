const good: number = globalThis.sharedValue;
globalThis.missingValue;
