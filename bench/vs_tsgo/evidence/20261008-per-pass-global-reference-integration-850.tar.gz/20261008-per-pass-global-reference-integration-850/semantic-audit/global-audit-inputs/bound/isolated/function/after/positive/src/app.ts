const good: number = 1;
