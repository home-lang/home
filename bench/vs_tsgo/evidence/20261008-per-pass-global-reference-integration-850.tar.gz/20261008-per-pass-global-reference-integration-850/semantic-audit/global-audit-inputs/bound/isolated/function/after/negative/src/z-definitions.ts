function scope() { var privateValue = 1; }
