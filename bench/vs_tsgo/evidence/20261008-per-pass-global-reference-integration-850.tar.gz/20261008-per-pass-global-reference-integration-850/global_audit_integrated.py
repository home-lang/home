import json
from pathlib import Path
import re
import subprocess
import sys

binaries = Path(__file__).resolve().parent
root = binaries / 'integrated-semantic-audit'
root.mkdir(exist_ok=False)
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
sys.path.insert(0, str(repo / 'bench/vs_tsgo'))
import run
import competitors
import audit_globals
import audit_bound_globals

commands = run.compiler_commands()
assert set(commands) == {'tsc', 'tsgo', 'home'}
commands.pop('home')
commands.update({'profile_baseline': [str(binaries / 'home-tsc-parent')],
                 'integrated': [str(binaries / 'home-tsc-integrated')]})
versions = run.verified_compiler_versions(commands)
def fingerprints():
    return {'compilers': {name: [run.artifact_provenance(Path(arg)) for arg in command if Path(arg).is_file()]
                          for name, command in commands.items()},
            'typescript_payload': competitors.inventory_hash(competitors.payload_inventory(run.TSC_TOOLS / 'node_modules/typescript')),
            'harness': {name: run.sha256_file(repo / 'bench/vs_tsgo' / name)
                        for name in ('run.py', 'audit_globals.py', 'audit_bound_globals.py')},
            'runner_sha256': run.sha256_file(Path(__file__))}
before = fingerprints()
inputs = root / 'global-audit-inputs'
inputs.mkdir(exist_ok=False)
records = []
for suite, cases in [('globals', audit_globals.cases()), ('bound', audit_bound_globals.cases())]:
    for case in cases:
        project = inputs / suite / case.family / case.name
        run.write(project / 'tsconfig.json', audit_globals.project_config(case))
        run.generate_minimal_lib(project)
        for filename, source in case.files.items():
            run.write(project / 'src' / filename, source)
        for name, command in commands.items():
            argv = command + ['--noEmit', '-p', str(project / 'tsconfig.json')]
            result = subprocess.run(argv, capture_output=True, text=True)
            codes = sorted(re.findall(r'\berror TS(\d+):', result.stdout + result.stderr))
            passed = (result.returncode in (1, 2) and codes == sorted(case.expected)) if case.expected else (result.returncode == 0 and not result.stdout and not result.stderr)
            records.append({'suite': suite, 'family': case.family, 'case': case.name, 'compiler': name,
                'command': argv, 'exit_code': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr,
                'expected_codes': sorted(case.expected), 'codes': codes, 'passed': passed})
        (root / 'global-audit.json').write_text(json.dumps({'records': records}, indent=2) + '\n')
summary = {name: {'checks': sum(row['compiler'] == name for row in records),
                  'failures': [row for row in records if row['compiler'] == name and not row['passed']]}
           for name in commands}
summary['input_inventory_sha256'] = competitors.inventory_hash(competitors.payload_inventory(inputs))
summary['versions'] = versions
summary['fingerprints_before'] = before
summary['fingerprints_after'] = fingerprints()
assert summary['fingerprints_before'] == summary['fingerprints_after']
(root / 'global-audit-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({name: {'checks': summary[name]['checks'], 'failures': len(summary[name]['failures'])} for name in commands}), flush=True)
assert not any(not row['passed'] for row in records), 'Semantic global controls failed; full output retained'
