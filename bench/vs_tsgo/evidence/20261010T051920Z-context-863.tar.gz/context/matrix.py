import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
source = 'b4985e4bd304ddf1fc9b6e14c375fc1de3878f2e'
compiler_source = 'a6570c80599122f4c263527bc35a1c27d65987c3'
expected = 'd58ddc54a147b3ad8b177a98a6b5cda04fd4df77595c5ccf44da690de5d57b32'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip() == source
assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=repo).decode() == ''
paths = ['packages/ts_checker', 'packages/ts_program', 'packages/ts_driver', 'packages/ts_cli',
         'packages/ts_resolver', 'packages/binder', 'packages/tsconfig', 'bench/vs_tsgo/run.py',
         'bench/vs_tsgo/corpus.toml', 'build.zig', 'build.zig.zon']
assert subprocess.check_output(['git', 'diff', '--name-only', compiler_source, source, '--'] + paths, cwd=repo).decode() == ''
environment = dict(os.environ, HOME_RUN_MAX_MB='3840', HOME_RUN_LABEL='ts863-landed-matrix-clean-build')
build = ['perl', 'scripts/run-bounded.pl', '600',
         '/Users/chris/Code/Home/lang-bun-port/zig-out/toolchains/zig-aarch64-macos-0.17.0-dev.2163+89ff10d56/zig',
         'build', 'home-tsc', '-Doptimize=ReleaseFast', '-Dhome-tsc-strip=true', '-Denable_jsc=false', '-j1', '--summary', 'all']
with (root / 'clean-build.log').open('w') as output:
    result = subprocess.run(build, cwd=repo, env=environment, stdout=output, stderr=subprocess.STDOUT)
assert result.returncode == 0, 'Build failed; timing not started'
native = root / 'home-tsc-current'
shutil.copyfile(repo / 'zig-out/bin/home-tsc', native)
native.chmod(0o755)
assert hashlib.sha256(native.read_bytes()).hexdigest() == expected
environment['HOME_TSC'] = str(native)
environment['HOME_RUN_LABEL'] = 'ts863-landed-complete-matrix'
command = ['perl', 'scripts/run-bounded.pl', '600', 'python3', 'bench/vs_tsgo/run.py',
           'cold', '--runs', '30', '--warmup', '3', '--competitor-manifest', 'bench/vs_tsgo/profiles/darwin-arm64.json']
record = {'source': source, 'compiler_source': compiler_source, 'native_sha256': expected,
          'command': command, 'build_command': build, 'build_exit': result.returncode,
          'runs': 30, 'warmup': 3, 'guard_mb': 3840, 'status': 'running',
          'runner_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(root / 'command.json').write_text(json.dumps(record, indent=2) + '\n')
with (root / 'matrix.log').open('w') as output:
    result = subprocess.run(command, cwd=repo, env=environment, stdout=output, stderr=subprocess.STDOUT)
log = (root / 'matrix.log').read_text()
record['exit'] = result.returncode
record['status'] = 'complete' if result.returncode == 0 else 'incomplete'
matches = re.findall(r'^Results: (.+)$', log, re.MULTILINE)
if result.returncode == 0:
    assert len(matches) == 1
    record['result'] = Path(matches[0]).name
(root / 'command.json').write_text(json.dumps(record, indent=2) + '\n')
print(log[-5000:], flush=True)
assert result.returncode == 0
assert hashlib.sha256(native.read_bytes()).hexdigest() == expected
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip() == source
assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=repo).decode() == ''
