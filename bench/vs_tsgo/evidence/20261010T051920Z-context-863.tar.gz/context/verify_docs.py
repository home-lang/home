import hashlib
import json
from pathlib import Path
import tarfile

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
verified = json.loads((root / 'verified.json').read_text())
readme = (repo / 'README.md').read_text()
document = (repo / 'docs/docs/TS_PERFORMANCE.md').read_text()
heading = '### Landed Record and indexed interface matrix 2026 10 10 UTC'
assert document.count(heading) == 1
section = document.split(heading, 1)[1].split('\n### ', 1)[0]
for row in (root / 'docs-table.md').read_text().splitlines()[2:]:
    assert row in section, row
for row in (root / 'readme-table.md').read_text().splitlines()[2:]:
    assert row in readme, row
assert 'Result `' + verified['result'] + '`' in readme
assert verified['source'] in section and verified['compiler_source'] in section
assert verified['native_sha256'] in section and verified['archive_sha256'] in section
assert len(verified['home_leads']) == 1 and len(verified['home_beats_go']) == 12
assert '**1/20**' in section and '**12/20**' in section and '**603 payload checksums**' in section
assert '2.02×' in section and '2.00×' in section and '1.98×' in section
assert '600 original rounds / 3,000 retained samples' in section
assert '145/145 protocol-4 admissions' in section
assert 'not an exact-parent patch A/B' in section and 'unadmitted' in section
assert '#landed-record-and-indexed-interface-matrix-2026-10-10-utc' in readme
archive = repo / 'bench/vs_tsgo/evidence' / (verified['result'] + '.tar.gz')
assert hashlib.sha256(archive.read_bytes()).hexdigest() == verified['archive_sha256']
with tarfile.open(archive, 'r:gz') as tar:
    sums = [name for name in tar.getnames() if name.endswith('/SHA256SUMS')]
    assert len(sums) == 1
    prefix = sums[0].rsplit('/', 1)[0] + '/'
    lines = tar.extractfile(sums[0]).read().decode().splitlines()
    assert len(lines) == 603
    for line in lines:
        expected, name = line.split(None, 1)
        if name.startswith('./'):
            name = name[2:]
        assert hashlib.sha256(tar.extractfile(prefix + name).read()).hexdigest() == expected
result = {'passed': True, 'result': verified['result'], 'source': verified['source'],
          'native_sha256': verified['native_sha256'], 'archive_sha256': verified['archive_sha256'],
          'archive_checksums': 603, 'rows': 20, 'samples': 3000, 'admissions': 145,
          'readme_sha256': hashlib.sha256(readme.encode()).hexdigest(),
          'document_sha256': hashlib.sha256(document.encode()).hexdigest(),
          'measurement_reruns': 0, 'discarded_samples': 0, 'universal_leadership_proven': False}
(root / 'verified-docs.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result), flush=True)
