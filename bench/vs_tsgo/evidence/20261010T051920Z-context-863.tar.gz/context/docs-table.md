| Workload | tsc 6.0.3 median | native TS 7.0.2 median | Home median | Rust tsc-rs 0.1.0 median | Bun canary median | Home vs fastest competitor |
|---|---:|---:|---:|---:|---:|---:|
| `checkjs_jsdoc` | 202.5 ms | 23.3 ms | 27.0 ms | 22.6 ms | 13.5 ms | 2.00× slower |
| `class_hierarchy` | 186.6 ms | 21.4 ms | 23.5 ms | 18.0 ms | 13.6 ms | 1.72× slower |
| `commonjs_graph` | 152.0 ms | 17.9 ms | 18.0 ms | 14.7 ms | 11.9 ms | 1.52× slower |
| `control_flow` | 192.4 ms | 27.9 ms | 26.3 ms | 25.0 ms | 16.7 ms | 1.57× slower |
| `deep_types` | 149.9 ms | 22.8 ms | 22.3 ms | 15.4 ms | 14.3 ms | 1.56× slower |
| `destructuring` | 141.6 ms | 17.3 ms | 15.6 ms | 15.1 ms | 11.1 ms | 1.40× slower |
| `generic_calls` | 185.0 ms | 23.8 ms | 23.2 ms | 19.9 ms | 15.0 ms | 1.55× slower |
| `import_graph` | 138.3 ms | 15.7 ms | 18.1 ms | 12.0 ms | 16.4 ms | 1.51× slower |
| `interface_composition` | 208.6 ms | 32.3 ms | 35.4 ms | 24.5 ms | 17.9 ms | 1.98× slower |
| `many_files` | 220.7 ms | 23.8 ms | 23.2 ms | 17.2 ms | 14.2 ms | 1.63× slower |
| `null_safe_access` | 199.0 ms | 27.4 ms | 34.1 ms | 23.6 ms | 16.9 ms | 2.02× slower |
| `overload_resolution` | 204.8 ms | 34.0 ms | 24.5 ms | 27.4 ms | 20.6 ms | 1.19× slower |
| `recursive_generics` | 157.3 ms | 41.6 ms | 14.9 ms | 33.2 ms | 9.5 ms | 1.57× slower |
| `reexport_graph` | 102.0 ms | 11.1 ms | 12.4 ms | 9.3 ms | 9.2 ms | 1.35× slower |
| `startup` | 69.5 ms | 8.0 ms | 3.2 ms | 6.3 ms | 6.6 ms | **2.00× faster** |
| `structural_objects` | 184.5 ms | 26.7 ms | 23.0 ms | 22.6 ms | 16.5 ms | 1.40× slower |
| `tsx_components` | 175.4 ms | 17.0 ms | 19.8 ms | 15.3 ms | 11.1 ms | 1.78× slower |
| `type_predicates` | 237.9 ms | 40.1 ms | 32.6 ms | 34.0 ms | 23.4 ms | 1.39× slower |
| `type_predicates_large` | 1,032.4 ms | 322.1 ms | 251.9 ms | 274.3 ms | 164.4 ms | 1.53× slower |
| `variadic_tuples` | 254.8 ms | 45.2 ms | 32.4 ms | 34.3 ms | 19.7 ms | 1.64× slower |
