import json
from pathlib import Path
import sys

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
sys.path.insert(0, str(repo / 'bench/vs_tsgo'))
import compare

data = json.loads((root / 'verified.json').read_text())
names = ['tsc', 'tsgo', 'home', 'tsc_rs', 'bun_canary']
header = '| Workload | tsc 6.0.3 median | native TS 7.0.2 median | Home median | Rust tsc-rs 0.1.0 median | Bun canary median | Home vs fastest competitor |'
separator = '|---|---:|---:|---:|---:|---:|---:|'

def row(label, key):
    values = data['rows'][key]
    formatted = [f'{values[name] * 1000:,.1f} ms' for name in names]
    formatted.append(compare.format_comparison(values['home'], min(value for name, value in values.items() if name != 'home')))
    return '| ' + label + ' | ' + ' | '.join(formatted) + ' |'

lines = [header, separator] + [row('`' + key + '`', key) for key in sorted(data['rows'])]
labels = [('Startup (one small file)', 'startup'), ('256 independent files', 'many_files'),
    ('128-module import chain', 'import_graph'), ('64 modules through 8 barrel re-exports', 'reexport_graph'),
    ('Deep conditional / mapped / template types', 'deep_types'), ('Recursive generics', 'recursive_generics'),
    ('Checked JavaScript with JSDoc', 'checkjs_jsdoc'), ('Control-flow narrowing (256 unions)', 'control_flow'),
    ('256 type-predicate families', 'type_predicates'), ('2,048 type-predicate families', 'type_predicates_large')]
readme = [header, separator] + [row(label, key) for label, key in labels]
(root / 'docs-table.md').write_text('\n'.join(lines) + '\n')
(root / 'readme-table.md').write_text('\n'.join(readme) + '\n')
gaps = sorted(((values['home'] / min(value for name, value in values.items() if name != 'home'), key)
               for key, values in data['rows'].items()), reverse=True)
(root / 'measured-gaps.json').write_text(json.dumps([{'workload': key, 'home_vs_fastest': ratio} for ratio, key in gaps], indent=2) + '\n')
print('\n'.join(lines), flush=True)
