import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
verified = json.loads((root / 'verified.json').read_text())
assert verified['rounds'] == 600 and verified['samples'] == 3000 and verified['admissions'] == 145
assert verified['native_sha256'] == 'd58ddc54a147b3ad8b177a98a6b5cda04fd4df77595c5ccf44da690de5d57b32'
assert json.loads((root / 'pickier-results.json').read_text())[-1]['exit'] == 0
doc = json.loads((root / 'verified-docs.json').read_text())
assert hashlib.sha256((repo / 'README.md').read_bytes()).hexdigest() == doc['readme_sha256']
assert hashlib.sha256((repo / 'docs/docs/TS_PERFORMANCE.md').read_bytes()).hexdigest() == doc['document_sha256']
entries = {}
names = ['matrix.py', 'command.json', 'matrix.log', 'clean-build.log', 'verify.py', 'verified.json',
    'verify_raw.py', 'verified-raw.json', 'export_evidence.py', 'export-command.json', 'export.log',
    'report_tables.py', 'docs-table.md', 'readme-table.md', 'measured-gaps.json', 'verify_docs.py',
    'verified-docs.json', 'lint_docs.py', 'pickier-results.json', 'pickier-repository.log',
    'pickier-changed_documents.log', 'package_context.py']
for name in names:
    entries['context/' + name] = (root / name).read_bytes()
for name in ['run.py', 'compare.py', 'competitors.py', 'corpus.toml', 'test_run.py', 'test_compare.py']:
    entries['harness/' + name] = (repo / 'bench/vs_tsgo' / name).read_bytes()
entries['harness/darwin-arm64.json'] = (repo / 'bench/vs_tsgo/profiles/darwin-arm64.json').read_bytes()
entries['publication/README.md'] = (repo / 'README.md').read_bytes()
entries['publication/TS_PERFORMANCE.md'] = (repo / 'docs/docs/TS_PERFORMANCE.md').read_bytes()
checksums = {name: hashlib.sha256(data).hexdigest() for name, data in entries.items()}
entries['SHA256SUMS'] = ''.join(checksums[name] + '  ' + name + '\n' for name in sorted(checksums)).encode()
output = repo / 'bench/vs_tsgo/evidence/20261010T051920Z-context-863.tar.gz'
assert not output.exists()
with output.open('xb') as raw:
    with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as tar:
            for name, data in sorted(entries.items()):
                item = tarfile.TarInfo(name)
                item.size, item.mode = len(data), 0o644
                tar.addfile(item, io.BytesIO(data))
with tarfile.open(output, 'r:gz') as tar:
    for name, digest in checksums.items():
        assert hashlib.sha256(tar.extractfile(name).read()).hexdigest() == digest
result = {'archive': str(output.relative_to(repo)), 'sha256': hashlib.sha256(output.read_bytes()).hexdigest(),
          'payload_checksums': len(checksums), 'bytes': output.stat().st_size, 'verified': True}
(root / 'context.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result), flush=True)
