"""Verify completed raw data while canonical packaging waits for its lock."""
import json
from pathlib import Path

root = Path(__file__).resolve().parent
source = (root / 'verify.py').read_text()
marker = "archive = repo / 'bench/vs_tsgo/evidence'"
assert source.count(marker) == 1
namespace = {'__file__': str(root / 'verify.py')}
exec(compile(source.split(marker, 1)[0], str(root / 'verify.py'), 'exec'), namespace)
rows = namespace['rows']
result = {'raw_data_verified': True, 'archive_verification_pending': True,
          'result': namespace['result'].name, 'rounds': 600, 'samples': 3000,
          'admissions': 145, 'rows': rows,
          'home_leads': [name for name, values in rows.items() if values['home'] == min(values.values())],
          'home_beats_go': [name for name, values in rows.items() if values['home'] < values['tsgo']],
          'leaders': {name: min(values, key=values.get) for name, values in rows.items()}}
(root / 'verified-raw.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: value for key, value in result.items() if key != 'rows'}), flush=True)
