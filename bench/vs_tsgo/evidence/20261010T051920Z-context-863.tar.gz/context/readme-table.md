| Workload | tsc 6.0.3 median | native TS 7.0.2 median | Home median | Rust tsc-rs 0.1.0 median | Bun canary median | Home vs fastest competitor |
|---|---:|---:|---:|---:|---:|---:|
| Startup (one small file) | 69.5 ms | 8.0 ms | 3.2 ms | 6.3 ms | 6.6 ms | **2.00× faster** |
| 256 independent files | 220.7 ms | 23.8 ms | 23.2 ms | 17.2 ms | 14.2 ms | 1.63× slower |
| 128-module import chain | 138.3 ms | 15.7 ms | 18.1 ms | 12.0 ms | 16.4 ms | 1.51× slower |
| 64 modules through 8 barrel re-exports | 102.0 ms | 11.1 ms | 12.4 ms | 9.3 ms | 9.2 ms | 1.35× slower |
| Deep conditional / mapped / template types | 149.9 ms | 22.8 ms | 22.3 ms | 15.4 ms | 14.3 ms | 1.56× slower |
| Recursive generics | 157.3 ms | 41.6 ms | 14.9 ms | 33.2 ms | 9.5 ms | 1.57× slower |
| Checked JavaScript with JSDoc | 202.5 ms | 23.3 ms | 27.0 ms | 22.6 ms | 13.5 ms | 2.00× slower |
| Control-flow narrowing (256 unions) | 192.4 ms | 27.9 ms | 26.3 ms | 25.0 ms | 16.7 ms | 1.57× slower |
| 256 type-predicate families | 237.9 ms | 40.1 ms | 32.6 ms | 34.0 ms | 23.4 ms | 1.39× slower |
| 2,048 type-predicate families | 1,032.4 ms | 322.1 ms | 251.9 ms | 274.3 ms | 164.4 ms | 1.53× slower |
