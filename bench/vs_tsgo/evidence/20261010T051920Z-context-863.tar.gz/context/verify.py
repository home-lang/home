import hashlib
import json
from pathlib import Path
import re
import statistics
import subprocess
import sys
import tarfile

repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
root = Path(__file__).resolve().parent
sys.path.insert(0, str(repo / 'bench/vs_tsgo'))
import compare
import competitors

command = json.loads((root / 'command.json').read_text())
assert command['exit'] == 0 and command['status'] == 'complete'
assert command['source'] == 'b4985e4bd304ddf1fc9b6e14c375fc1de3878f2e'
assert command['compiler_source'] == 'a6570c80599122f4c263527bc35a1c27d65987c3'
assert command['native_sha256'] == 'd58ddc54a147b3ad8b177a98a6b5cda04fd4df77595c5ccf44da690de5d57b32'
assert hashlib.sha256((root / 'home-tsc-current').read_bytes()).hexdigest() == command['native_sha256']
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip() == command['source']
assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=repo).decode() == ''
result = repo / 'bench/vs_tsgo/results' / command['result']
metadata = json.loads((result / 'metadata.json').read_text())
compare.validate_interleaved_rounds(result, metadata)
assert metadata['provenance']['status'] == 'verified'
assert metadata['provenance']['before'] == metadata['provenance']['after']
admission = json.loads((result / 'admission.jsonl').read_text())
assert metadata['validation_schema'] == 4
assert len(admission['records']) == 145 and all(row['passed'] for row in admission['records'])
assert len(metadata['workloads']) == 20 and len(metadata['compilers']) == 5
assert metadata['runs'] == 30 and metadata['warmup'] == 3
assert command['native_sha256'] in json.dumps(metadata['provenance']['before'])
for compiler in metadata['compilers']:
    checks = [row for row in admission['records'] if row['compiler'] == compiler]
    assert len(checks) == 29
    assert {row['workload'] for row in checks if row['kind'] == 'positive'} == set(metadata['workloads'])
    assert sum(row['kind'] == 'negative' for row in checks) == 9
    for row in checks:
        codes = sorted(re.findall(r'error TS(\d+):', row['stdout'] + row['stderr']))
        assert codes == row['codes']
        if row['kind'] == 'positive':
            assert row['exit_code'] == 0
            assert competitors.successful_output(row['stdout'], row['stderr'], row['positive_output'])
        else:
            assert row['exit_code'] in (1, 2) and codes == sorted(row['expected_codes'])
            if row['workload'] == 'checkjs_jsdoc':
                assert codes == ['2322'] * 9 + ['2339'] * 3 + ['2345'] * 3
rows = {}
assert len(list(result.glob('*-round-*.json'))) == 600
for workload in metadata['workloads']:
    samples = {name: [] for name in metadata['compilers']}
    names = list(metadata['compilers'])
    for index in range(30):
        data = json.loads((result / f'{workload}-round-{index:03d}.json').read_text())
        offset = index % len(names)
        assert [record['command'].split(' ', 1)[0] for record in data['results']] == names[offset:] + names[:offset]
        for record in data['results']:
            name = record['command'].split(' ', 1)[0]
            assert record['exit_codes'] == [0] and len(record['times']) == 1
            assert record['times'][0] > 0
            samples[name].extend(record['times'])
    assert all(len(values) == 30 for values in samples.values())
    rows[workload] = {name: statistics.median(values) for name, values in samples.items()}
archive = repo / 'bench/vs_tsgo/evidence' / (result.name + '.tar.gz')
with tarfile.open(archive) as tar:
    sums = [name for name in tar.getnames() if name.endswith('/SHA256SUMS')]
    assert len(sums) == 1
    prefix = sums[0].rsplit('/', 1)[0] + '/'
    checksums = tar.extractfile(sums[0]).read().decode().splitlines()
    for line in checksums:
        digest, relative = line.split(None, 1)
        if relative.startswith('./'):
            relative = relative[2:]
        assert hashlib.sha256(tar.extractfile(prefix + relative).read()).hexdigest() == digest
    for path in result.glob('*-round-*.json'):
        assert tar.extractfile(prefix + path.name).read() == path.read_bytes()
home_leads = [name for name, values in rows.items() if values['home'] == min(values.values())]
home_beats_go = [name for name, values in rows.items() if values['home'] < values['tsgo']]
leaders = {name: min(values, key=values.get) for name, values in rows.items()}
summary = {'result': result.name, 'source': command['source'], 'compiler_source': command['compiler_source'],
    'native_sha256': command['native_sha256'], 'rounds': 600, 'samples': 3000, 'admissions': 145,
    'verified_payload_checksums': len(checksums), 'archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
    'home_leads': home_leads, 'home_beats_go': home_beats_go, 'leaders': leaders, 'rows': rows,
    'measurement_reruns': 0, 'discarded_samples': 0, 'universal_leadership_proven': False}
(root / 'verified.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({key: value for key, value in summary.items() if key != 'rows'}), flush=True)
