import hashlib
import json
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
paths = ('README.md', 'docs/docs/TS_PERFORMANCE.md')
before = {name: hashlib.sha256((repo / name).read_bytes()).hexdigest() for name in paths}
source = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip()
command = ['env', 'HOME_RUN_MAX_MB=3840', 'HOME_RUN_LABEL=ts854-landed-prefix-matrix-docs-lint',
    'perl', 'scripts/run-bounded.pl', '600', 'bunx', '--bun', 'pickier', '.']
result = subprocess.run(command, cwd=repo, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
after = {name: hashlib.sha256((repo / name).read_bytes()).hexdigest() for name in paths}
(root / 'lint.log').write_text(result.stdout)
(root / 'lint-command.json').write_text(json.dumps({'command': command, 'exit': result.returncode,
    'source': source, 'publication_file_sha256_before': before, 'publication_file_sha256_after': after}, indent=2) + '\n')
print(result.stdout[-3000:], flush=True)
assert before == after
raise SystemExit(result.returncode)
