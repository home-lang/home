import gzip
import hashlib
import io
import json
from pathlib import Path
import sys
import tarfile

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
lint = json.loads((root / 'lint-command.json').read_text())
assert lint['exit'] == 1 and '22074 problems (11461 errors, 10613 warnings)' in (root / 'lint.log').read_text()
assert lint['publication_file_sha256_before'] == lint['publication_file_sha256_after']
for name, digest in lint['publication_file_sha256_after'].items():
    assert hashlib.sha256((repo / name).read_bytes()).hexdigest() == digest
verified = json.loads((root / 'verified.json').read_text())
assert verified['rounds'] == 600 and verified['samples'] == 3000 and verified['admissions'] == 145
record = {'source_at_lint': lint['source'], 'compiler_source': verified['compiler_source'],
    'matrix_chain_session': {'session': 89628, 'status': 'terminal', 'exit': 1, 'cause': 'first supplemental verifier assumption, not measurement failure'},
    'actual_matrix_command_exit': json.loads((root / 'command.json').read_text())['exit'],
    'successful_export_verification_session': {'session': 53713, 'status': 'terminal', 'exit': 0},
    'lint_session': {'session': int(sys.argv[1]), 'status': 'terminal', 'exit': lint['exit']},
    'lint_errors': 11461, 'lint_warnings': 10613, 'autofixes': False,
    'publication_file_sha256': lint['publication_file_sha256_after'],
    'matrix_admissions': 145, 'matrix_rounds': 600, 'matrix_samples': 3000,
    'diagnostic_image_timing_samples': 0, 'measurement_reruns': 0,
    'discarded_samples': 0, 'guard_changes': False,
    'profile_status': 'Fresh landed-source profile not yet run; older sample mappings are separately versioned',
    'remaining_goal': 'Universal leadership, Zod admission, canonical C++ admission and other-platform coverage incomplete'}
(root / 'publication-context.json').write_text(json.dumps(record, indent=2) + '\n')
names = ('lint.py', 'lint.log', 'lint-command.json', 'publication-context.json', 'verify_docs.py', 'package_publication_context.py')
entries = {name: (root / name).read_bytes() for name in names}
checksums = ''.join(hashlib.sha256(data).hexdigest() + '  ' + name + '\n' for name, data in sorted(entries.items()))
count = len(entries)
entries['SHA256SUMS'] = checksums.encode()
name = '20261009-landed-prefix-matrix-publication-context-854'
path = repo / 'bench/vs_tsgo/evidence' / (name + '.tar.gz')
assert not path.exists()
with path.open('wb') as output:
    with gzip.GzipFile(filename='', mode='wb', fileobj=output, mtime=0) as gz:
        with tarfile.open(fileobj=gz, mode='w') as tar:
            for filename, data in sorted(entries.items()):
                info = tarfile.TarInfo(name + '/' + filename)
                info.size, info.mode, info.mtime = len(data), 0o644, 0
                tar.addfile(info, io.BytesIO(data))
with tarfile.open(path) as tar:
    for row in checksums.splitlines():
        expected, filename = row.split('  ', 1)
        assert hashlib.sha256(tar.extractfile(name + '/' + filename).read()).hexdigest() == expected
result = {'archive': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'payload_checksums': count}
(root / 'publication-archive.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
