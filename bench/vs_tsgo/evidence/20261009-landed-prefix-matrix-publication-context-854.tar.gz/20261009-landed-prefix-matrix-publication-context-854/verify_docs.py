import json
from pathlib import Path
import sys

repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
root = Path(__file__).resolve().parent
sys.path.insert(0, str(repo / 'bench/vs_tsgo'))
import compare

data = json.loads((root / 'verified.json').read_text())
names = ['tsc', 'tsgo', 'home', 'tsc_rs', 'bun_canary']
def values(name):
    row = data['rows'][name]
    return [f'{row[compiler] * 1000:,.1f} ms' for compiler in names] + [
        compare.format_comparison(row['home'], min(value for compiler, value in row.items() if compiler != 'home')).replace('**', '')]
def rows(text):
    return [[cell.strip().replace('**', '') for cell in line.strip('|').split('|')]
            for line in text.splitlines() if line.startswith('| ') and ' ms |' in line]
docs = (repo / 'docs/docs/TS_PERFORMANCE.md').read_text()
section = docs.split('### Landed JSDoc ancestor-prefix matrix (2026-10-09 UTC)\n', 1)[1].split('\n### Restored current-main matrix', 1)[0]
actual = rows(section)
assert len(actual) == 20
for row in actual:
    key = row[0].strip('`')
    assert row[1:] == values(key), (key, row, values(key))
readme = (repo / 'README.md').read_text()
table = readme.split('### Measured TypeScript frontend performance\n', 1)[1].split('Home has the lowest median', 1)[0]
labels = {'Startup (one small file)': 'startup', '256 independent files': 'many_files',
    '128-module import chain': 'import_graph', '64 modules through 8 barrel re-exports': 'reexport_graph',
    'Deep conditional / mapped / template types': 'deep_types', 'Recursive generics': 'recursive_generics',
    'Checked JavaScript with JSDoc': 'checkjs_jsdoc', 'Control-flow narrowing (256 unions)': 'control_flow',
    '256 type-predicate families': 'type_predicates', '2,048 type-predicate families': 'type_predicates_large'}
actual = rows(table)
assert len(actual) == 10
for row in actual:
    assert row[1:] == values(labels[row[0]]), row
assert data['result'] in section and data['archive_sha256'] in section
assert f"**{len(data['home_leads'])}/20**" in section
assert f"**{len(data['home_beats_go'])}/20**" in section
assert f"**{len(data['home_leads'])} / 20**" in readme
assert f"**{len(data['home_beats_go'])} / 20**" in readme
print('All 20 detailed rows, 10 README rows, ratios and unrounded leadership counts match new verified raw samples.')
