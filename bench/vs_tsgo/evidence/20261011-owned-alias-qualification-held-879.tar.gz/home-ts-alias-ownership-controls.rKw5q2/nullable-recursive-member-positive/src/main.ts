type Item={next:Item|null;label:string};declare const item:Item;if(typeof item.next==="object"&&item.next!==null){const target:string=item.next.label;void target;}
