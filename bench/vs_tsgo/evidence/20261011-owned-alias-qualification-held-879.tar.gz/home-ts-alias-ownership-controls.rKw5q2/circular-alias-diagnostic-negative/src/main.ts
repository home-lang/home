type First=Second;type Second=First;
