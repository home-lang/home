const value:Later="ready";type Later=string;void value;
