type T=string;type Value=T;function work<T>(argument:T){const value:Value="ready";void value;void argument;}
