type First={peer:Second;label:string};type Second={peer:First};declare const value:First;const target:string=value.peer.peer.label;void target;
