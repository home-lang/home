type First={next:Second};type Second={next:First};declare const value:First;void value;
