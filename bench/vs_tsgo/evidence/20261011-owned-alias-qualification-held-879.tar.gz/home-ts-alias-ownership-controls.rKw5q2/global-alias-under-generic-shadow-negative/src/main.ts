type T=string;type Value=T;function work<T>(argument:T){const value:Value=123;void value;void argument;}
