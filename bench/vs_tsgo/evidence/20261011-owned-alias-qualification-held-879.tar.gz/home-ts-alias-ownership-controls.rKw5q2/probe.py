import hashlib
import json
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
runner = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
seed = Path('/Users/chris/.cache/home-ts-callable-intersection-facts.34PC25/collection-factory-positive')
sys.path.insert(0, str(runner / 'bench/vs_tsgo'))
import run
import competitors

def save(path, content):
    assert not path.exists(), path
    path.parent.mkdir(parents=True, exist_ok=True)
    patch = '*** Begin Patch\n*** Add File: ' + str(path) + '\n'
    patch += ''.join('+' + line + '\n' for line in content.splitlines()) + '*** End Patch\n'
    subprocess.run(['apply_patch'], input=patch, text=True, check=True, capture_output=True)

cases = {
    'scalar-before-declaration': ('const value:Later="ready";type Later=string;void value;',
        'const value:Later=123;type Later=string;void value;', ['2322']),
    'explicit-unknown': ('declare const value:Opaque;type Opaque=unknown;const target:unknown=value;void target;',
        'declare const value:Opaque;type Opaque=unknown;const target:string=value;void target;', ['2322']),
    'global-alias-under-generic-shadow': ('type T=string;type Value=T;function work<T>(argument:T){const value:Value="ready";void value;void argument;}',
        'type T=string;type Value=T;function work<T>(argument:T){const value:Value=123;void value;void argument;}', ['2322']),
    'sibling-local-alias': ('type Value=boolean;function first(){const value:Value="ready";type Value=string;void value;}function second(){const value:Value=123;type Value=number;void value;}',
        'type Value=boolean;function first(){const value:Value=123;type Value=string;void value;}function second(){const value:Value="ready";type Value=number;void value;}', ['2322','2322']),
    'productive-mutual-cycle': ('type First={peer:Second;label:string};type Second={peer:First};declare const value:First;const target:string=value.peer.peer.label;void target;',
        'type First={peer:Second;label:string};type Second={peer:First};declare const value:First;const target:number=value.peer.peer.label;void target;', ['2322']),
    'nullable-recursive-member': ('type Item={next:Item|null;label:string};declare const item:Item;if(typeof item.next==="object"&&item.next!==null){const target:string=item.next.label;void target;}',
        'type Item={next:Item|null;label:string};declare const item:Item;if(typeof item.next==="object"&&item.next!==null){const target:number=item.next.label;item.next.missing;void target;}', ['2322','2339']),
    'namespace-forward-alias': ('namespace Owner{export interface Model{value:Value;}export type Value=string;}declare const model:Owner.Model;const target:string=model.value;void target;',
        'namespace Owner{export interface Model{value:Value;}export type Value=string;}declare const model:Owner.Model;const target:number=model.value;void target;', ['2322']),
    'circular-alias-diagnostic': ('type First={next:Second};type Second={next:First};declare const value:First;void value;',
        'type First=Second;type Second=First;', ['2456','2456']),
}
assert not (root / 'results.json').exists()
trace = []
before = {}
for name, (positive, negative, expected) in cases.items():
    for bad, source in [(False, positive), (True, negative)]:
        workload = name + ('-negative' if bad else '-positive')
        project = root / workload
        for relative in ['tsconfig.json','src/lib.d.ts']:
            save(project / relative, (seed / relative).read_text())
        save(project / 'src/main.ts', source + '\n')
        before[workload] = competitors.inventory_hash(competitors.payload_inventory(project))
        commands = run.compiler_commands()
        commands['home'] = ['/Users/chris/.cache/home-ts-main-flow-proof-integration.dYlSre/candidate-home-tsc']
        commands['parent'] = ['/Users/chris/.cache/home-ts-main-flow-proof-integration.dYlSre/baseline-home-tsc']
        for compiler, command in commands.items():
            result, passed = run.admission_process(compiler, command + ['--noEmit','-p',str(project / 'tsconfig.json')],
                workload, expected_codes=expected if bad else None, trace=trace)
            print(workload, compiler, result.returncode, passed, trace[-1]['codes'], flush=True)
after = {name: competitors.inventory_hash(competitors.payload_inventory(root / name)) for name in before}
assert before == after
save(root / 'results.json', json.dumps({'records': trace, 'before': before, 'after': after,
    'reference_controls_valid': all(row['passed'] for row in trace if row['compiler'] in ['tsc','tsgo']),
    'scope': 'General declaration ownership, forward use, true unknown and recursion oracles; no timing or prototype admission'}, indent=2) + '\n')
