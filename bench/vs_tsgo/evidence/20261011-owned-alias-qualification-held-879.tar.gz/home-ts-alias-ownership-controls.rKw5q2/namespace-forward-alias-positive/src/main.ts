namespace Owner{export interface Model{value:Value;}export type Value=string;}declare const model:Owner.Model;const target:string=model.value;void target;
