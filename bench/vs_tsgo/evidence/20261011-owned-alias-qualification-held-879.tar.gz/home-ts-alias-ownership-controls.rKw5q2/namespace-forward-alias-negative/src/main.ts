namespace Owner{export interface Model{value:Value;}export type Value=string;}declare const model:Owner.Model;const target:number=model.value;void target;
