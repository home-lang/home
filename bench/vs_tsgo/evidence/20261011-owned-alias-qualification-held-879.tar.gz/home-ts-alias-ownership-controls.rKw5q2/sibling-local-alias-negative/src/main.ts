type Value=boolean;function first(){const value:Value=123;type Value=string;void value;}function second(){const value:Value="ready";type Value=number;void value;}
