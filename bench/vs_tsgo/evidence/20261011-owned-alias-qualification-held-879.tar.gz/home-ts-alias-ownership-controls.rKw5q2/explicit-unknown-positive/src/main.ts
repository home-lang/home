declare const value:Opaque;type Opaque=unknown;const target:unknown=value;void target;
