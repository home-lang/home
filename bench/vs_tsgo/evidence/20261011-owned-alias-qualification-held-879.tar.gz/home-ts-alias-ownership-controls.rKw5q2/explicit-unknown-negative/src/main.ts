declare const value:Opaque;type Opaque=unknown;const target:string=value;void target;
