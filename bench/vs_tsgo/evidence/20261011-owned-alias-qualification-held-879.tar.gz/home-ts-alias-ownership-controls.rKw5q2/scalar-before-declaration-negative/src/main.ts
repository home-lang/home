const value:Later=123;type Later=string;void value;
