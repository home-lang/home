import collections
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts863-qualification-docs/lang')
prior = Path('/Users/chris/.cache/home-ts-project-surface-diagnostic.AFdbFb')
package = Path('/Users/chris/.cache/home-ts-zod-admission.RzJCwi/source/package')
sys.path.insert(0, '/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang/bench/vs_tsgo')
import competitors

def save(path, content):
    assert not path.exists(), path
    patch = '*** Begin Patch\n*** Add File: ' + str(path) + '\n'
    patch += ''.join('+' + line + '\n' for line in content.splitlines()) + '*** End Patch\n'
    subprocess.run(['apply_patch'], input=patch, text=True, check=True, capture_output=True)

assert not (root / 'surface-outcome.json').exists()
assert subprocess.check_output(['git', 'diff', '--', 'packages/ts_checker/src/check.zig', 'packages/ts_program/src/ts_program.zig'], cwd=repo).decode() == (root / 'source.patch').read_text()
before_library = competitors.inventory_hash(competitors.payload_inventory(package))
installed_before = hashlib.sha256((repo / 'zig-out/bin/home-tsc').read_bytes()).hexdigest()
binary = root / 'prototype-surface'
command = json.loads((prior / 'command.json').read_text())
command = [('-femit-bin=' + str(binary)) if argument.startswith('-femit-bin=') else argument for argument in command]
save(root / 'surface-command.json', json.dumps(command, indent=2) + '\n')
with (root / 'surface-build.log').open('w') as output:
    build = subprocess.run(command, cwd=repo, stdout=output, stderr=subprocess.STDOUT)
record = {'build_exit': build.returncode, 'diagnostic_only': True, 'timings_taken': False, 'source_adopted': False,
          'scope': 'Production project admission/resolver/checker/rendering through retained project-only diagnostic entrypoint; NOT CLI admission or performance samples'}
if build.returncode == 0:
    record['native_sha256'] = hashlib.sha256(binary.read_bytes()).hexdigest()
    result = subprocess.run([str(binary), str(package / 'tsconfig.benchmark.json')], capture_output=True, text=True)
    save(root / 'zod.stdout.log', result.stdout)
    save(root / 'zod.stderr.log', result.stderr)
    record.update(zod_exit=result.returncode, zod_codes=dict(collections.Counter(re.findall(r'\b((?:TS|HM)\d+):', result.stdout))))
    observations = []
    for case_root in [Path('/Users/chris/.cache/home-ts-forward-part-controls.lTzq5k'),
                      Path('/Users/chris/.cache/home-ts-local-type-value-controls.xbVlrO'),
                      Path('/Users/chris/.cache/home-ts-callback-body-controls-pinned.B9suaD')]:
        original = json.loads((case_root / 'results.json').read_text())
        assert original['before'] == original['after']
        for name in original['before']:
            project = case_root / name
            before = competitors.inventory_hash(competitors.payload_inventory(project))
            assert before == original['before'][name]
            result = subprocess.run([str(binary), str(project / 'tsconfig.json')], capture_output=True, text=True)
            codes = re.findall(r'\b(?:TS|HM)(\d+):', result.stdout + result.stderr)
            expected = ['2322', '2339'] if name.endswith('-negative') else []
            after = competitors.inventory_hash(competitors.payload_inventory(project))
            assert before == after
            observations.append({'project': str(project), 'before': before, 'after': after,
                'exit': result.returncode, 'codes': codes, 'expected': expected,
                'diagnostic_contract_matches': result.returncode == (1 if expected else 0) and sorted(codes) == sorted(expected),
                'stdout': result.stdout, 'stderr': result.stderr, 'diagnostic_only': True, 'timings_taken': False})
            print(name, result.returncode, codes, observations[-1]['diagnostic_contract_matches'], flush=True)
    save(root / 'surface-controls.json', json.dumps(observations, indent=2) + '\n')
record['library_before'] = before_library
record['library_after'] = competitors.inventory_hash(competitors.payload_inventory(package))
record['installed_before'] = installed_before
record['installed_after'] = hashlib.sha256((repo / 'zig-out/bin/home-tsc').read_bytes()).hexdigest()
assert record['library_before'] == record['library_after']
assert record['installed_before'] == record['installed_after']
save(root / 'surface-outcome.json', json.dumps(record, indent=2) + '\n')
print(json.dumps(record), flush=True)
print((root / 'surface-build.log').read_text()[-2500:], flush=True)
raise SystemExit(build.returncode)
