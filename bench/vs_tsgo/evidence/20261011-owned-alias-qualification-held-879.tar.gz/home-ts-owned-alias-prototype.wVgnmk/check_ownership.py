import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

root = Path(__file__).resolve().parent
cases = Path('/Users/chris/.cache/home-ts-alias-ownership-controls.rKw5q2')
sys.path.insert(0, '/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang/bench/vs_tsgo')
import competitors
baseline = json.loads((cases / 'results.json').read_text())
assert baseline['reference_controls_valid'] and baseline['before'] == baseline['after']
binary = root / 'prototype-surface'
assert hashlib.sha256(binary.read_bytes()).hexdigest() == '074c84a5716737b31a460c400f503b5e1d795643c6a4172cff0f59791e93fb12'
records = []
for name, before in baseline['before'].items():
    project = cases / name
    assert competitors.inventory_hash(competitors.payload_inventory(project)) == before
    reference = next(row for row in baseline['records'] if row['compiler'] == 'tsc' and row['workload'] == name)
    expected = reference['expected_codes'] or []
    result = subprocess.run([str(binary), str(project / 'tsconfig.json')], capture_output=True, text=True)
    codes = re.findall(r'\b(?:TS|HM)(\d+):', result.stdout + result.stderr)
    after = competitors.inventory_hash(competitors.payload_inventory(project))
    assert before == after
    record = {'workload':name, 'exit':result.returncode, 'codes':codes, 'expected':expected,
              'diagnostic_contract_matches':result.returncode == (1 if expected else 0) and sorted(codes) == sorted(expected),
              'stdout':result.stdout, 'stderr':result.stderr, 'before':before, 'after':after,
              'diagnostic_only':True, 'timings_taken':False}
    records.append(record)
    print(name,result.returncode,codes,record['diagnostic_contract_matches'],flush=True)
path = root / 'ownership-observations.json'
assert not path.exists()
content = json.dumps(records,indent=2)+'\n'
patch = '*** Begin Patch\n*** Add File: '+str(path)+'\n'+''.join('+'+line+'\n' for line in content.splitlines())+'*** End Patch\n'
subprocess.run(['apply_patch'],input=patch,text=True,check=True,capture_output=True)
