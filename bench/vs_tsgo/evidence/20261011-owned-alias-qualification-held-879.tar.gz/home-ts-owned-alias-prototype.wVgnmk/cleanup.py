import hashlib
import json
from pathlib import Path
import shutil
import subprocess

evidence = Path(__file__).resolve().parent
task_targets = [
    Path('/Users/chris/.codex/worktrees/ts863-qualification-docs/lang/.zig-cache'),
    Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang/.zig-cache'),
    Path('/Users/chris/.codex/worktrees/ts-839-parent/lang/.zig-cache'),
]
assert subprocess.run(['ps', '-p', '9895,9903,9922,9923'], capture_output=True).returncode != 0
for target in task_targets:
    assert target.name == '.zig-cache' and target.is_dir() and not target.is_symlink()
    assert target.resolve() == target
    assert (target.parent / '.git').is_file()
    assert not subprocess.check_output(['git', 'ls-files', '--', '.zig-cache'], cwd=target.parent)

def digest(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(block)
    return value.hexdigest()

protected = set()
for target in task_targets:
    repo = target.parent
    tracked = subprocess.check_output(['git', 'ls-files', '-z', '--', 'packages/ts_checker', 'packages/ts_program',
        'packages/ts_cli', 'scripts/run-bounded.pl', 'README.md', 'docs/docs/TS_PERFORMANCE.md', 'bench/vs_tsgo'], cwd=repo)
    protected.update(repo / path.decode() for path in tracked.split(b'\0') if path)
    protected.update(path for path in (repo / 'zig-out/bin').glob('*') if path.is_file())
for folder in Path('/Users/chris/.cache').glob('home-ts-*'):
    if folder.is_dir():
        protected.update(path for path in folder.rglob('*') if path.is_file() and '.zig-cache' not in path.parts)
protected = sorted(path for path in protected if path.is_file())
assert all(not any(target == path or target in path.parents for target in task_targets) for path in protected)
before = {str(path): digest(path) for path in protected}
sizes = {str(target): sum(path.stat().st_size for path in target.rglob('*') if path.is_file()) for target in task_targets}
for target in task_targets:
    shutil.rmtree(target)
after = {str(path): digest(path) for path in protected}
assert before == after
record = {'deleted_generated_caches': sizes, 'protected_checksums': before,
          'all_protected_checksums_unchanged': True, 'shared_global_cache_modified': False,
          'unrelated_jobs_modified': False, 'source_adopted': False}
content = json.dumps(record, indent=2) + '\n'
patch = '*** Begin Patch\n*** Add File: ' + str(evidence / 'cleanup-outcome.json') + '\n'
patch += ''.join('+' + line + '\n' for line in content.splitlines()) + '*** End Patch\n'
subprocess.run(['apply_patch'], input=patch, text=True, check=True, capture_output=True)
print(json.dumps({'deleted_generated_caches': sizes, 'protected_files_verified': len(before),
    'all_protected_checksums_unchanged': True}), flush=True)
