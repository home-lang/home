import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

root = Path(__file__).resolve().parent
cache = root.parent
repo = Path('/Users/chris/.codex/worktrees/ts863-qualification-docs/lang')
names = [
    'home-ts-owned-alias-prototype.wVgnmk',
    'home-ts-owned-alias-hardened.Y3mOcP',
    'home-ts-owned-alias-resolved-guards.Idqxcg',
    'home-ts-alias-ownership-controls.rKw5q2',
    root.name,
]
for name in names[:3]:
    assert (cache / name / 'surface-outcome.json').is_file()
assert (cache / names[3] / 'results.json').is_file()
archive = repo / 'bench/vs_tsgo/evidence/20261011-owned-alias-qualification-held-879.tar.gz'
assert not archive.exists()
files = []
for name in names:
    for path in sorted((cache / name).rglob('*')):
        if name == 'home-ts-owned-alias-resolved-guards.Idqxcg' and path.name in {'checker.log','checker-outcome.json','driver.log','cli.log','entrypoint.log','remaining-outcome.json','state.json'}:
            continue
        if name == 'home-ts-owned-alias-prototype.wVgnmk' and path.name == 'cleanup-outcome.json':
            continue
        if name == root.name and (path.name == 'manifest.json' or path.name.endswith('.tar.gz')):
            continue
        if not path.is_file() or path.is_symlink() or '__pycache__' in path.parts:
            continue
        assert '.zig-cache' not in path.parts
        files.append((str(path.relative_to(cache)), path))
manifest = [{'path': name, 'bytes': path.stat().st_size,
             'sha256': hashlib.sha256(path.read_bytes()).hexdigest()} for name, path in files]
content = json.dumps({'payloads': manifest, 'timings_taken': False, 'source_adopted': False}, indent=2) + '\n'
patch = '*** Begin Patch\n*** Add File: ' + str(root / 'manifest.json') + '\n'
patch += ''.join('+' + line + '\n' for line in content.splitlines()) + '*** End Patch\n'
if (root / 'manifest.json').exists():
    old = (root / 'manifest.json').read_text()
    patch = '*** Begin Patch\n*** Update File: ' + str(root / 'manifest.json') + '\n@@\n'
    patch += ''.join('-' + line + '\n' for line in old.splitlines())
    patch += ''.join('+' + line + '\n' for line in content.splitlines()) + '*** End Patch\n'
subprocess.run(['apply_patch', patch], check=True, capture_output=True)
with tarfile.open(archive, 'w:gz') as bundle:
    for name, path in files:
        bundle.add(path, arcname=name, recursive=False)
    bundle.add(root / 'manifest.json', arcname=root.name + '/manifest.json', recursive=False)
with tarfile.open(archive, 'r:gz') as bundle:
    expected = json.load(bundle.extractfile(root.name + '/manifest.json'))['payloads']
    assert len(bundle.getmembers()) == len(expected) + 1
    for row in expected:
        data = bundle.extractfile(row['path']).read()
        assert len(data) == row['bytes']
        assert hashlib.sha256(data).hexdigest() == row['sha256']
print(json.dumps({'archive': str(archive), 'payload_checksums_verified': len(expected),
    'archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'bytes': archive.stat().st_size}), flush=True)
