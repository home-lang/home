export {};declare const value:Alias;const good:number=value.local;const wrong:string=value.local;value.global;
