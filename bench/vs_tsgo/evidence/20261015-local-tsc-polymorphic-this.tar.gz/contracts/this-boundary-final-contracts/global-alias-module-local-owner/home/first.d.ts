export {};declare class Base{local:number}declare global{type Alias=Base}
