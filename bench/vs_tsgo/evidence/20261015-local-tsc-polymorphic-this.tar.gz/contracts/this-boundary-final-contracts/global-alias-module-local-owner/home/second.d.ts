interface Base{global:string}
