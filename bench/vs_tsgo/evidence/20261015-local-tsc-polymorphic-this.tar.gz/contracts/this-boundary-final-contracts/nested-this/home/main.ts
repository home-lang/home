interface Inner{inner:number;self():this}interface Outer{outer:number;nested:Inner}declare const outer:Outer;const result=outer.nested.self();const good:Inner=result;const wrong:string=result;
