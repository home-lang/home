interface Inner{inner:number;self():this}interface Outer{outer:number;nested:Inner}declare const outer:Outer;class Holder{take(value:Inner):void{} pass(value:Inner){this.take(value);}}
