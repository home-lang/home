export {};interface Derived extends Base{extra:string}declare const value:Derived;const good:number=value.base;interface Invalid extends Missing{}
