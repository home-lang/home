interface Base{base:number}
