type Alias<Base>=Base;
