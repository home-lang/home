interface Base{unrelated:string}
