export {};declare const value:Alias<string>;const good:string=value;const wrong:number=value;
