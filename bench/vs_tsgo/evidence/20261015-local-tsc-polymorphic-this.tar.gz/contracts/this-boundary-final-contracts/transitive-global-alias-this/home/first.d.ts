interface Base{get<T=this>():T}type Middle=Base;type Alias=Middle;
