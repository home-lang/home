export {};declare const base:Alias;const good:string=base.get().added;const wrong:number=base.get().added;
