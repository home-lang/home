interface Box<T>{get<U=this>():U}interface Derived extends Box<number>{extra:string}declare const box:Derived;const out=box.get();const good:string=out.extra;const wrong:number=out.extra;
