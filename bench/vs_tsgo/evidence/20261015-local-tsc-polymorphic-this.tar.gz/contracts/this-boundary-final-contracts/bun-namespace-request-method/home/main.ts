export {};class Audit{take(request:Request):void{} log(request:Request):void{this.take(request);}}
