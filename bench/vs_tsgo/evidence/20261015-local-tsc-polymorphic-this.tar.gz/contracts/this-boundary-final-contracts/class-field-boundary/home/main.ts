interface Inner{inner:number;self():this}interface Outer{outer:number;nested:Inner}class Holder{value:Inner|null=null;set(value:Inner){this.value=value;}}
