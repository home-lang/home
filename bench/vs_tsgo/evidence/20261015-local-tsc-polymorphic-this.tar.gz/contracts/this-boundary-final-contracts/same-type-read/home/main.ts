interface Inner{inner:number;self():this}interface Outer{outer:number;nested:Inner}declare const outer:Outer;declare function take(value:Inner):void;take(outer.nested);
