export {};const wrong:number="bad";
