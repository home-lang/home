interface Outer{outer:number;take<T extends this>():T}declare const outer:Outer;const good:Outer=outer.take<Outer>();const wrong=outer.take<{other:boolean}>();
