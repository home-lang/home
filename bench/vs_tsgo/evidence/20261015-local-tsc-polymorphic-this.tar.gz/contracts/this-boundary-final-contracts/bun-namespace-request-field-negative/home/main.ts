export {};class Guard{request:Request|null=null;setRequest(request:Request):void{this.request=request;this.request="bad";}}
