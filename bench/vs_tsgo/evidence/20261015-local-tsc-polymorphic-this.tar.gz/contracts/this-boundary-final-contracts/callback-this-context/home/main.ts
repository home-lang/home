interface Inner{inner:number;listen(callback:(this:this)=>void):void}declare const inner:Inner;inner.listen(function(){const good:Inner=this;const wrong:string=this;});
