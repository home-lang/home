interface Inner{inner:number;check(cb:(value:Inner)=>void):void}declare const inner:Inner;inner.check(value=>{const good:Inner=value;const wrong:string=value;});
