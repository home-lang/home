import {take} from "./owner";declare const request:Request;take(request);
