export function take(request:Request):void{}
