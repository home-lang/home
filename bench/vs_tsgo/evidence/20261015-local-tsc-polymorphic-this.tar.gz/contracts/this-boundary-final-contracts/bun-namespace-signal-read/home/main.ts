export {};declare const request:Request;const signal:AbortSignal=request.signal;
