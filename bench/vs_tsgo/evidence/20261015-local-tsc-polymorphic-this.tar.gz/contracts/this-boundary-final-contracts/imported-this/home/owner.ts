export interface Inner{inner:number;self():this}export interface Outer{outer:number;nested:Inner}
