import type {Inner,Outer} from "./owner";declare const outer:Outer;const result=outer.nested.self();const good:Inner=result;const wrong:string=result;
