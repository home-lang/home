interface Box<T>{value:T;get<U=this>():U}declare const box:Box<number>;const out=box.get();const good:number=out.value;const wrong:string=out.value;
