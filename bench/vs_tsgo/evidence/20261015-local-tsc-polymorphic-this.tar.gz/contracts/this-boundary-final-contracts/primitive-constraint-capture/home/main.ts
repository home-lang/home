interface Base{base:number;take<T extends this>():T}declare const base:Base;const result=base.take<string>();
