interface Base{get<T=this>():T}
