interface Left{[n:number]:string;run(cb:(value:number)=>void):void}interface Right{[n:number]:number;run(cb:(value:number)=>void):void}declare const left:Left;const wrong:Right=left;
