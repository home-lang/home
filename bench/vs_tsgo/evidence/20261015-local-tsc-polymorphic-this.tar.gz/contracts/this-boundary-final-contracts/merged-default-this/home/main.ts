interface Base{get<T=this>():T}interface Base{added:string}declare const base:Base;const result=base.get();const good:string=result.added;const wrong:number=result.added;
