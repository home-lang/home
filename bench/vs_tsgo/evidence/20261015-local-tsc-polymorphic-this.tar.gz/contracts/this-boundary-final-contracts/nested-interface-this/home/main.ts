class Outer{outer:number=1;method(){interface Inner{inner:number;self():this}const inner={} as Inner;const value=inner.self();const good:Inner=value;const wrong:string=value;}}
