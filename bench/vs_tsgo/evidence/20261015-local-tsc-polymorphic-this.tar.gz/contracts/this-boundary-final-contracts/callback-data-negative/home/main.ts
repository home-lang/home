interface Left{value:string;run(cb:(value:number)=>void):void}interface Right{value:number;run(cb:(value:number)=>void):void}declare const left:Left;const wrong:Right=left;
