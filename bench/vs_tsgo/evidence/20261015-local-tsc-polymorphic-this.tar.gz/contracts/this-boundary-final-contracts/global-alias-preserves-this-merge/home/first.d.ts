interface Base{get<T=this>():T}type Alias=Base;
