interface Base{added:string}
