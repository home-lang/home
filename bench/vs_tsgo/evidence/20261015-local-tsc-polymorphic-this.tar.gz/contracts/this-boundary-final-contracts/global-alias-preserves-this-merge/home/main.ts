export {};declare const base:Alias;const result=base.get();const good:string=result.added;const wrong:number=result.added;
