interface Base{base:number;take<T extends this>():T}interface Derived extends Base{extra:string}declare const derived:Derived;const result=derived.take<Base>();
