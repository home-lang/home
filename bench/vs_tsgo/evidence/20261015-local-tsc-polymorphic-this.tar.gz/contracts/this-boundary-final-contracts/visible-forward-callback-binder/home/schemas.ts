export interface Payload<T>{value:T}export type CheckFn<T>=(payload:Payload<T>)=>void;
