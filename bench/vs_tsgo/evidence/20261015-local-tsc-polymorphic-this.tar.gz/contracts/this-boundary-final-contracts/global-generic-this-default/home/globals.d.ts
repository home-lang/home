interface Box<T>{value:T;get<U=this>():U}
