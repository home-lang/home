export {};interface Derived extends Box<number>{extra:string}declare const box:Derived;const out=box.get();const good:number=out.value;const extra:string=out.extra;const wrong:string=out.value;
