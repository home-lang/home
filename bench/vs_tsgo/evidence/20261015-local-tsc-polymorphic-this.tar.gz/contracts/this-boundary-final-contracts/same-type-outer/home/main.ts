interface Inner{inner:number;self():this}interface Outer{outer:number;nested:Inner}declare const outer:Outer;declare function take(value:Outer):void;take(outer);
