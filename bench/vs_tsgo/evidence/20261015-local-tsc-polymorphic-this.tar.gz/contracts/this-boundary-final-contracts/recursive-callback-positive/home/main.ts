interface Left{value:number;visit(cb:(value:Left)=>void):void}interface Right{value:number;visit(cb:(value:Right)=>void):void}declare const left:Left;const good:Right=left;
