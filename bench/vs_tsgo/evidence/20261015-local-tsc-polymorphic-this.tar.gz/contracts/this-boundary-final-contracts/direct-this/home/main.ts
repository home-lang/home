interface Base{base:number;self():this}interface Derived extends Base{extra:string}declare const derived:Derived;const result=derived.self();const good:Derived=result;const wrong:number=result.extra;
