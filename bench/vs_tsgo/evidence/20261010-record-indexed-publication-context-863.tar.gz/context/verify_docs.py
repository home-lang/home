import hashlib
import json
from pathlib import Path
import re
import subprocess
import tarfile

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
package = json.loads((root / 'package-evidence.json').read_text())
verified = json.loads((root / 'verified-final-admission.json').read_text())
archive_path = repo / package['archive']
assert hashlib.sha256(archive_path.read_bytes()).hexdigest() == package['sha256']
with tarfile.open(archive_path, 'r:gz') as archive:
    lines = archive.extractfile('SHA256SUMS').read().decode().splitlines()
    assert len(lines) == package['payload_checksums'] == 2022
    for line in lines:
        expected, name = line.split('  ', 1)
        assert hashlib.sha256(archive.extractfile(name).read()).hexdigest() == expected, name
    publication = json.loads(archive.extractfile('publication.json').read())
    assert publication['source_commit'] == 'a6570c80599122f4c263527bc35a1c27d65987c3'
    assert publication['native_sha256'] == verified['native_sha256']
    assert publication['timings_taken'] is False and publication['zod_admitted'] is False
readme = (repo / 'README.md').read_text()
document = (repo / 'docs/docs/TS_PERFORMANCE.md').read_text()
heading = 'Imported Record and indexed interface admission 2026 10 10 UTC'
assert document.count('## ' + heading) == 1
section = document.split('## ' + heading, 1)[1].split('\n## ', 1)[0]
assert package['sha256'] in section and verified['native_sha256'] in section
assert '2,022' in section and '241' in section and '244' in section and '195' in section
assert 'no sources' in section.lower() and 'unadmitted' in section.lower()
assert '46 supported checks pass' in re.sub(r'\s+', ' ', section).replace('**', '')
assert 'two finite-key checks fail' in section.replace('**', '')
assert '145/145 checks pass' in readme and 'not a refreshed performance ranking' in readme
assert '241 TS errors and two HM9002 warnings' in readme
assert 'docs/docs/TS_PERFORMANCE.md#imported-record-and-indexed-interface-admission-2026-10-10-utc' in readme
assert '(' + package['archive'] + ')' in readme
assert 'In this dated matrix, Home has the lowest median' in readme
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip() == publication['source_commit']
assert hashlib.sha256((repo / 'zig-out/bin/home-tsc').read_bytes()).hexdigest() == publication['native_sha256']
result = {'passed': True, 'archive_sha256': package['sha256'], 'payload_checksums': 2022,
          'source_commit': publication['source_commit'], 'native_sha256': publication['native_sha256'],
          'readme_sha256': hashlib.sha256(readme.encode()).hexdigest(),
          'document_sha256': hashlib.sha256(document.encode()).hexdigest(), 'timings_taken': False}
(root / 'verified-docs.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result), flush=True)
