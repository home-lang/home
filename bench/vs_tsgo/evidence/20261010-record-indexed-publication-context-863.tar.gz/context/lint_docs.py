import json
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
commands = {'repository': ['bunx', '--bun', 'pickier', '.'],
            'changed_documents': ['bunx', '--bun', 'pickier', 'README.md', 'docs/docs/TS_PERFORMANCE.md']}
records = []
for label, command in commands.items():
    with (root / ('pickier-' + label + '.log')).open('w') as output:
        result = subprocess.run(command, stdout=output, stderr=subprocess.STDOUT)
    records.append({'scope': label, 'command': command, 'exit': result.returncode})
    print(label, 'exit', result.returncode, flush=True)
    print((root / ('pickier-' + label + '.log')).read_text()[-900:], flush=True)
(root / 'pickier-results.json').write_text(json.dumps(records, indent=2) + '\n')
assert records[-1]['exit'] == 0
