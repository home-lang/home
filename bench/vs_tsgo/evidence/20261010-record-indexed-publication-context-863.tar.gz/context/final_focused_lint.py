import json
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
command = ['bunx', '--bun', 'pickier', 'README.md', 'docs/docs/TS_PERFORMANCE.md']
with (root / 'pickier-final-focused.log').open('w') as output:
    result = subprocess.run(command, stdout=output, stderr=subprocess.STDOUT)
(root / 'pickier-final-focused.json').write_text(json.dumps({'command': command, 'exit': result.returncode}, indent=2) + '\n')
print('Final changed-document lint exit', result.returncode, flush=True)
raise SystemExit(result.returncode)
