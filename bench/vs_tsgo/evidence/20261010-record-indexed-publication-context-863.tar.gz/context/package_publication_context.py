import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
verified = json.loads((root / 'verified-docs.json').read_text())
assert verified['passed']
assert hashlib.sha256((repo / 'README.md').read_bytes()).hexdigest() == verified['readme_sha256']
assert hashlib.sha256((repo / 'docs/docs/TS_PERFORMANCE.md').read_bytes()).hexdigest() == verified['document_sha256']
assert json.loads((root / 'pickier-final-focused.json').read_text())['exit'] == 0
entries = {'README.md': (repo / 'README.md').read_bytes(),
           'docs/docs/TS_PERFORMANCE.md': (repo / 'docs/docs/TS_PERFORMANCE.md').read_bytes()}
for name in ['verify_docs.py', 'verified-docs.json', 'lint_docs.py', 'pickier-results.json',
             'pickier-repository.log', 'pickier-changed_documents.log', 'final_focused_lint.py',
             'pickier-final-focused.json', 'pickier-final-focused.log', 'package-evidence.json',
             'package_publication_context.py']:
    entries['context/' + name] = (root / name).read_bytes()
checksums = {name: hashlib.sha256(data).hexdigest() for name, data in entries.items()}
entries['SHA256SUMS'] = ''.join(checksums[name] + '  ' + name + '\n' for name in sorted(checksums)).encode()
output = repo / 'bench/vs_tsgo/evidence/20261010-record-indexed-publication-context-863.tar.gz'
assert not output.exists()
with output.open('xb') as raw:
    with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as archive:
            for name, data in sorted(entries.items()):
                item = tarfile.TarInfo(name)
                item.size = len(data)
                item.mode = 0o644
                archive.addfile(item, io.BytesIO(data))
with tarfile.open(output, 'r:gz') as archive:
    for name, expected in checksums.items():
        assert hashlib.sha256(archive.extractfile(name).read()).hexdigest() == expected
record = {'archive': str(output.relative_to(repo)), 'sha256': hashlib.sha256(output.read_bytes()).hexdigest(),
          'payload_checksums': len(checksums), 'bytes': output.stat().st_size, 'verified': True}
(root / 'publication-context.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record), flush=True)
