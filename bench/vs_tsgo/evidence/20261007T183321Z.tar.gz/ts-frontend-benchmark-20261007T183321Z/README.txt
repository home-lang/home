Every *-round-*.json file is the byte-for-byte Hyperfine output from the measured run.
Only repository-local paths in metadata.json are normalized to $REPO before publication.
SHA256SUMS covers the published metadata and every raw round file.
