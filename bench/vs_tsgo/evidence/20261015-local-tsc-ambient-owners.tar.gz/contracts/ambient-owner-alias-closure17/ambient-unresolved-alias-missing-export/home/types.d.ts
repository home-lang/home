declare module "owner"{export {Unknown};}
