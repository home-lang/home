declare module "owner"{function take(path:string):void;export type {take};}
