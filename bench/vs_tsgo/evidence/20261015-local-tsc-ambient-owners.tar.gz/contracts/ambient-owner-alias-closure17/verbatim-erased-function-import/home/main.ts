import {take} from "owner";export type {take};
