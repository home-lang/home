declare module "leaf"{export class Item{}}declare module "owner"{export type {Item} from "leaf";}
