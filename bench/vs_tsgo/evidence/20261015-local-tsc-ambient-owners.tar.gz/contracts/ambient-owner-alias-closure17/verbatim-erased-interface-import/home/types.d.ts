declare module "leaf"{export interface Item{}}declare module "owner"{export type {Item} from "leaf";}
