declare module "owner"{export class Item{value:string;}}
