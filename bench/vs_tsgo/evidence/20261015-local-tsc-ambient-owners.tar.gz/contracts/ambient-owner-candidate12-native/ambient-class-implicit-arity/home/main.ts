import {Item} from "owner";new Item(1);
