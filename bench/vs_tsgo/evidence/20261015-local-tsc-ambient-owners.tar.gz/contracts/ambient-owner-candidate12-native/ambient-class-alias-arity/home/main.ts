import {Alias} from "owner";new Alias();
