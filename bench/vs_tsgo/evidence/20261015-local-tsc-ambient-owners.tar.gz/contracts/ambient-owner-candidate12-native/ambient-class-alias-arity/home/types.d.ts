declare module "leaf"{export class Item{constructor(path:string);value:string;}}declare module "owner"{export {Item as Alias} from "leaf";}
