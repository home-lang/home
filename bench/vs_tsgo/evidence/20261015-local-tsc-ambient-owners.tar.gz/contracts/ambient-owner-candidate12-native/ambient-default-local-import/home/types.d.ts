declare module "owner"{export default function take(path:string):void;}
