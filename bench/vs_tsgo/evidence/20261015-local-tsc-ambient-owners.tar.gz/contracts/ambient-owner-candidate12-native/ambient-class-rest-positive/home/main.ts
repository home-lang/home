import {Item} from "owner";new Item();new Item("a","b");
