import {take} from "owner";take("ok");
