declare module "owner"{namespace Tool{function take(path:string):void;}export=Tool;}
