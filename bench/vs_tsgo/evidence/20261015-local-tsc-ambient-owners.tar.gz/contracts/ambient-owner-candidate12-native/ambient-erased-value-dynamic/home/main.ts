export async function use():Promise<void>{const module=await import("owner");module.take("ok");}
