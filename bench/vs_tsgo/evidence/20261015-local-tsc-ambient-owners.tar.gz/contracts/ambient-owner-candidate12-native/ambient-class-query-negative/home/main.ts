export {};declare const Alias:typeof import("owner").Alias;new Alias(1);
