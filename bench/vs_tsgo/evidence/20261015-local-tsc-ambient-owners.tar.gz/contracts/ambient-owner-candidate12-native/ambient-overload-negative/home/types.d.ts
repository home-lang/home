declare module "owner"{export function take(path:string):string;export function take(path:number):number;}
