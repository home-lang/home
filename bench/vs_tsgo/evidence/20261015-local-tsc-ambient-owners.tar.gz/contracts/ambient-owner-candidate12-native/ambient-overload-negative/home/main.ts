import {take} from "owner";take(true);
