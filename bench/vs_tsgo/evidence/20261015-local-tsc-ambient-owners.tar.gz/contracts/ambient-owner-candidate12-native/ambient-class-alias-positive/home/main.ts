import {Alias} from "owner";const item=new Alias("ok");const value:string=item.value;declare const other:Alias;const text:string=other.value;
