declare module "owner"{export type Visible=string;}
