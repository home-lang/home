import {Item} from "owner";new Item<string>(1);
