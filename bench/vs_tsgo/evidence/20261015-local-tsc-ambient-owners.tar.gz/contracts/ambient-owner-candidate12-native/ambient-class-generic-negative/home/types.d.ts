declare module "owner"{export class Item<T>{constructor(value:T);value:T;}}
