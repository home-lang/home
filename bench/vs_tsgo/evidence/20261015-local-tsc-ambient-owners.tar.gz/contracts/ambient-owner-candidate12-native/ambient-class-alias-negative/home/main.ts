import {Alias} from "owner";const item=new Alias(1);
