declare module "owner"{type Hidden=string;export {Hidden as Visible};}
