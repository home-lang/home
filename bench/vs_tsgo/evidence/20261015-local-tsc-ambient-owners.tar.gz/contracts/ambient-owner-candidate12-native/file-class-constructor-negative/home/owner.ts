export class Item{value:string;constructor(path:string){this.value=path;}}
