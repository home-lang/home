import {Item} from "owner";new Item();new Item("ok");
