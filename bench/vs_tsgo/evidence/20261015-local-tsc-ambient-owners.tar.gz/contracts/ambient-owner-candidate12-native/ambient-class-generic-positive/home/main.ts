import {Item} from "owner";const item=new Item<string>("ok");const value:string=item.value;
