export async function use():Promise<void>{const {Alias}=await import("owner");new Alias(1);}
