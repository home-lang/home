import {take} from "owner";const numberResult:number=take(1);const stringResult:string=take("ok");
