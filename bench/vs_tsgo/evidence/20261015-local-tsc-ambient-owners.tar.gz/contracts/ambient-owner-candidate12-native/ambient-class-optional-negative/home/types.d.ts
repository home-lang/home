declare module "owner"{export class Item{constructor(path?:string);}}
