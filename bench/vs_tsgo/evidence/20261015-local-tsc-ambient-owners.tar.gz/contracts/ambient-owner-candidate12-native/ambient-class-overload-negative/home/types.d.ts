declare module "owner"{export class Item{constructor(path:string);constructor(path:number);}}
