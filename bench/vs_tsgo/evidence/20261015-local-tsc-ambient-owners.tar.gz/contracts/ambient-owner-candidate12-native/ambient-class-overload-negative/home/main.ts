import {Item} from "owner";new Item(true);
