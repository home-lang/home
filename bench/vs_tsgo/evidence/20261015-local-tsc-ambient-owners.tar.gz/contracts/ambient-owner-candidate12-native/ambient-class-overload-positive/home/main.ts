import {Item} from "owner";new Item("ok");new Item(1);
