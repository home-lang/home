import {Item} from "owner";new Item("a",1);
