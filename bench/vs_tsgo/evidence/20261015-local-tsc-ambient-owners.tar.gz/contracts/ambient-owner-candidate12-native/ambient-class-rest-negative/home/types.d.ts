declare module "owner"{export class Item{constructor(...paths:string[]);}}
