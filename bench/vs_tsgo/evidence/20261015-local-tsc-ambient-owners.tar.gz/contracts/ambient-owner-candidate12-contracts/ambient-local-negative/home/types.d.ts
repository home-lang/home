declare module "api"{type Path=string;export function take(path:Path):void;}
