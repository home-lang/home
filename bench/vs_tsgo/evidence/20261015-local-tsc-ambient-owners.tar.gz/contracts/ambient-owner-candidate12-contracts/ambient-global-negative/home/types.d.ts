interface Path{value:string}declare module "api"{export function take(path:Path):void;}
