import {take} from "api";take(1);
