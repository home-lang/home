declare module "leaf"{export type Path=string;}declare module "owner"{export type {Path} from "leaf";}declare module "api"{import type {Path} from "owner";export function take(path:Path):void;}
