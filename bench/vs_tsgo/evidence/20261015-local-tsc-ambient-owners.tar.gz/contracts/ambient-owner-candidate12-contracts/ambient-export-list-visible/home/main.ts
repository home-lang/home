import type {Visible} from "owner";const value:Visible=1;
