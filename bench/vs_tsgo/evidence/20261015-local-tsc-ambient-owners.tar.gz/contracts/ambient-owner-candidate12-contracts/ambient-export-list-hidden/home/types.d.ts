declare module "owner"{type Hidden=string;type Visible=number;export {Visible};}
