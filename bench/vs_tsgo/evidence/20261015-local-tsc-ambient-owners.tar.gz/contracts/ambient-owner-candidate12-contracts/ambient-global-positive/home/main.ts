import {take} from "api";take({value:"ok"});
