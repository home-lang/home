import type {Hidden} from "owner";const value:Hidden="ok";
