declare module "owner"{type Hidden=string;export interface Visible{value:number}}
