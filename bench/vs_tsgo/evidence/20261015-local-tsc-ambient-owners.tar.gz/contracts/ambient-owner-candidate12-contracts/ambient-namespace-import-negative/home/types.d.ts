declare module "owner"{export interface Path{value:string}}declare module "api"{import type * as Owner from "owner";export function take(path:Owner.Path):void;}
