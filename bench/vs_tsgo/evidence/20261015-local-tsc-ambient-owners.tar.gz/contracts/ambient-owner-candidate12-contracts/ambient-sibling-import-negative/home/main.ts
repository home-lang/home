import {take as left} from "api-left";import {take as right} from "api-right";left(1);right("bad");
