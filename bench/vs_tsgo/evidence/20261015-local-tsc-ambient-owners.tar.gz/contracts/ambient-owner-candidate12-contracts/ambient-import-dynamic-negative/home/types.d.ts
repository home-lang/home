declare module "owner"{export type Path=string;}declare module "api"{import type {Path} from "owner";export function take(path:Path):void;}
