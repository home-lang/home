export async function use():Promise<void>{const {take}=await import("api");take(1);}
