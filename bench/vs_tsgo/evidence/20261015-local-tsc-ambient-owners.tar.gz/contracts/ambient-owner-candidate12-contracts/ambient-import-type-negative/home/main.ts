import {take} from "api";take({value:1});
