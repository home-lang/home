declare module "owner"{export type Path={value:string};}declare module "api"{export function take(path:import("owner").Path):void;}
