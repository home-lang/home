import {take as left} from "api-left";import {take as right} from "api-right";left("ok");right(1);
