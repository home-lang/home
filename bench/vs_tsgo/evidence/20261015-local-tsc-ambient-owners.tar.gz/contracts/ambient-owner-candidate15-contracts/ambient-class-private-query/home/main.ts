export {};declare const Item:typeof import("owner").Item;new Item("ok");
