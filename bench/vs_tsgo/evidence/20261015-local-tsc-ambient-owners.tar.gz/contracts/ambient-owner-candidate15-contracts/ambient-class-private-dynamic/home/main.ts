export async function use():Promise<void>{const {Item}=await import("owner");new Item("ok");}
