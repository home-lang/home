export async function use():Promise<void>{const {unlink}=await import("node:fs/promises");await unlink(1);}
