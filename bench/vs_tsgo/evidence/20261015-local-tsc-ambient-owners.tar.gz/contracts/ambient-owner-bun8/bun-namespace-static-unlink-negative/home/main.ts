import {unlink} from "node:fs/promises";export async function use():Promise<void>{await unlink(1);}
