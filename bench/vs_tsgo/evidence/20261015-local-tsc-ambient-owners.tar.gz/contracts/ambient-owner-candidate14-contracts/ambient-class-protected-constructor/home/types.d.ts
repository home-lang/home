declare module "owner"{export class Item{protected constructor(path:string);}}
