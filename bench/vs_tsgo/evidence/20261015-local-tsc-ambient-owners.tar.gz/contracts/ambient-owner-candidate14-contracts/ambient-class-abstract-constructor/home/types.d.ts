declare module "owner"{export abstract class Item{constructor(path:string);}}
