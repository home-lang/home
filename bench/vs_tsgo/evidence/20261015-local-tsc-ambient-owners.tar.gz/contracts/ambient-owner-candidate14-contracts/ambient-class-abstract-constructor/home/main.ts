import {Item} from "owner";new Item("ok");
