import {Item} from "owner";const value:string=new Item("ok").value;
