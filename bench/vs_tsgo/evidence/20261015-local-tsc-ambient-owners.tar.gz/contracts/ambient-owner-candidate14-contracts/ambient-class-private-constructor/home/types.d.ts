declare module "owner"{export class Item{private constructor(path:string);}}
