import {Item} from "owner";new Item<number>(1);
