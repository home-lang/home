declare module "owner"{export class Item<T extends string>{constructor(value:T);value:T;}}
