import json
from pathlib import Path
import sys

root=Path(__file__).resolve().parent
measured=Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
implementation=Path('/Users/chris/.codex/worktrees/ts863-qualification-docs/lang')
sys.path.insert(0,str(measured/'bench/vs_tsgo'))
import run
import competitors
import compare
sys.path.insert(0,str(implementation/'bench/vs_tsgo'))
import resume
import checkpoint
source=measured/'bench/vs_tsgo/results/20261011T224925Z'
output=implementation/'bench/vs_tsgo/results/20261011T232901Z-resumed'
profiles=competitors.load_profiles(measured/'bench/vs_tsgo/profiles/darwin-arm64.json')
commands=run.compiler_commands(profiles)
def provenance():return run.benchmark_provenance(commands,profiles)

action=sys.argv[1]
if action=='init':
    plan=resume.initialize(source,output,provenance(),run.host_metadata())
    print(json.dumps({'output':str(output),'recorded_samples':plan['recorded_successful_samples'],
        'missing_samples':plan['missing_sample_count'],'partial_round':plan['partial_round'],
        'ranking_qualified':False,'measurement_started':False}),flush=True)
elif action=='workload':
    state=resume.execute_workload(output,sys.argv[2],commands,run.CORPUS,provenance,run.host_metadata)
    print(json.dumps({'workload':sys.argv[2],'status':state['status'],'sources':len(state['sources'])}),flush=True)
elif action=='finalize':
    resume.finalize(output,provenance(),run.host_metadata())
    metadata=json.loads((output/'metadata.json').read_bytes())
    checkpoint.validate_lineage(output,metadata)
    compare.validate_interleaved_rounds(output,metadata)
    print(json.dumps({'output':str(output),'rounds':len(list(output.glob('*-round-*.json'))),
        'samples':metadata['runs']*len(metadata['workloads'])*len(metadata['compilers']),
        'lineage_verified':True,'standard_protocol_verified':True,'original_samples_repeated':0}),flush=True)
else:raise ValueError('Unknown controller action')
