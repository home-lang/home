Interrupted matrix, unranked: guard exit123 at510MB, below512MB critical floor.
All original checkpoint files are byte-for-byte, including metadata paths.
150 admissions,124 complete rounds and one partial round retain621 successful samples.
Original metadata measuring status is stale: the external guard terminal records termination.
An initialization guard refusal at446MB started neither initialization nor timing.
Continuation must measure only2379 missing slots and verify immutable lineage and the complete protocol.
No selective performance ranking is valid. Source and retained compiler images are not deleted.
Implementation snapshot88b3fefaa passed191 harness tests.
