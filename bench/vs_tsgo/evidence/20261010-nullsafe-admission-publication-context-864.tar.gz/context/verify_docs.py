import hashlib
import json
from pathlib import Path
import tarfile

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
package = json.loads((root / 'package-evidence.json').read_text())
archive = repo / package['archive']
assert hashlib.sha256(archive.read_bytes()).hexdigest() == package['sha256']
with tarfile.open(archive, 'r:gz') as tar:
    lines = tar.extractfile('SHA256SUMS').read().decode().splitlines()
    assert len(lines) == package['payload_checksums'] == 24
    for line in lines:
        digest, name = line.split('  ', 1)
        assert hashlib.sha256(tar.extractfile(name).read()).hexdigest() == digest
    publication = json.loads(tar.extractfile('publication.json').read())
    assert publication['source_commit'] == '5a5db509af878cc8163fe680640e8b7d9e9ab1d6'
    assert publication['validation_schema'] == 5 and publication['admissions'] == 150
    assert publication['timings_taken'] is False and publication['nullsafe_errors_per_negative'] == 27
readme = (repo / 'README.md').read_text()
document = (repo / 'docs/docs/TS_PERFORMANCE.md').read_text()
heading = '## Null safe inferred result admission 2026 10 10 UTC'
assert document.count(heading) == 1
section = document.split(heading, 1)[1].split('\n## ', 1)[0]
assert package['sha256'] in section and publication['source_commit'] in section
for token in ['150 protocol-5 admissions', '147 harness tests', '27 errors', '24 payload checksums']:
    assert token in section, token
assert 'not retroactively called pre-timing' in section
assert '150/150 untimed admissions' in readme and 'Existing matrix remains protocol 4' in readme
assert 'TS_PERFORMANCE.md#null-safe-inferred-result-admission-2026-10-10-utc' in readme
assert hashlib.sha256((repo / 'zig-out/bin/home-tsc').read_bytes()).hexdigest() == publication['native_sha256']
result = {'passed': True, 'archive_sha256': package['sha256'], 'payload_checksums': 24,
          'admissions': 150, 'harness_tests': 147, 'errors_per_negative': 27,
          'readme_sha256': hashlib.sha256(readme.encode()).hexdigest(),
          'document_sha256': hashlib.sha256(document.encode()).hexdigest(), 'timings_taken': False}
(root / 'verified-docs.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result), flush=True)
