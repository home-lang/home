import hashlib
import json
from pathlib import Path
import subprocess
import tarfile

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
data = json.loads((root / 'verified-interrupted-data-partial.json').read_text())
archive = json.loads((root / 'incomplete-archive.json').read_text())
restored = json.loads((root / 'incomplete-restoration.json').read_text())
assert data['rounds'] == 706 and data['total_retained_admissions'] == 660
assert data['execution_qualified'] is False and data['candidate_eligible_for_production'] is False
markdown = (repo / 'docs/docs/TS_PERFORMANCE.md').read_text()
section = markdown.split('## Simple value name guard 2026 10 10 UTC\n',1)[1].split('\n## Shared function statement groups',1)[0]
assert (root / 'incomplete-tables.md').read_text().strip() in section
readme = (repo / 'README.md').read_text().split('The stateless value-name guard under ',1)[1].split('These numbers were measured',1)[0]
for phrase in ('not admitted', '706', '712', '660', '24', '30', 'disk', 'data'):
    assert phrase.lower() in readme.lower(), phrase
assert 'docs/docs/TS_PERFORMANCE.md#simple-value-name-guard-2026-10-10-utc' in readme
assert '20261010-simple-value-name-guard-incomplete-861.tar.gz' in readme
for key, label in [('confirmation/checkjs_jsdoc','Official checked JS, 30 pairs'),
                   ('confirmation/checkjs512','512 families, 30 pairs'),
                   ('families/interface_composition','Interface family screen, 10 pairs'),
                   ('recheck/interface_composition','Interface independent recheck, 30 pairs'),
                   ('interface-risk/interface_composition','Interface separate declaration check, 30 pairs'),
                   ('confirmation_large-2/checkjs8192','8,192 families, third batch data only')]:
    value = data['summaries'][key]
    line = next(line for line in readme.splitlines() if line.startswith('| '+label+' |'))
    expected = [f"{value['parent_median']*1000:,.3f} ms", f"{value['candidate_median']*1000:,.3f} ms",
                f"{value['paired_saving_ci95'][0]*1000:+,.3f}", f"{value['paired_saving_ci95'][1]*1000:+,.3f}"]
    assert all(item in line for item in expected), (label,expected)
assert archive['sha256'] in section and '2,001' in section
assert 'execution_qualified: false' in section and 'candidate_eligible_for_production: false' in section
assert 'exit 123' in section and '485 MB' in section and 'zero completed timing pairs' in section
assert '1/20' in section and '12/20' in section and 'unadmitted' in section
path = Path(archive['archive'])
assert hashlib.sha256(path.read_bytes()).hexdigest() == archive['sha256']
prefix = path.name.removesuffix('.tar.gz')
with tarfile.open(path) as tar:
    sums = tar.extractfile(prefix+'/SHA256SUMS').read().decode().splitlines()
    assert len(sums) == archive['payload_checksums'] == 2001
    for line in sums:
        digest,name=line.split('  ',1)
        assert hashlib.sha256(tar.extractfile(prefix+'/'+name).read()).hexdigest()==digest
assert subprocess.check_output(['git','diff','--name-only','--','packages'],cwd=repo).decode()==''
assert hashlib.sha256((repo/'zig-out/bin/home-tsc').read_bytes()).hexdigest()==restored['native_sha256']
subprocess.run(['git','diff','--check'],cwd=repo,check=True)
(root/'incomplete-docs-verification.json').write_text(json.dumps({'full_tables_exact':True,'readme_rows_link_verified':True,
    'payload_checksums_verified':len(sums),'restored_native_source_verified':True,
    'execution_qualified':False,'claim':'Unadmitted incomplete data, not improvement/equivalence/universal leadership'},indent=2)+'\n')
print('Incomplete scope, all tables/README rows/link,2001 payloads and restored native verified.')
