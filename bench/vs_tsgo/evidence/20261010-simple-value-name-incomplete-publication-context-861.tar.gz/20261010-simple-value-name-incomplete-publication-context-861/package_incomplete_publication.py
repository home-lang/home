import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

root=Path(__file__).resolve().parent
repo=Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
assert json.loads((root/'focused-pickier-command.json').read_text())['exit']==0
assert json.loads((root/'repo-pickier-command.json').read_text())['exit']==1
assert '11460 errors, 10614 warnings' in (root/'repo-pickier.log').read_text()
assert json.loads((root/'incomplete-docs-verification.json').read_text())['payload_checksums_verified']==2001
names=['repo-pickier.log','repo-pickier-command.json','focused-pickier.log','focused-pickier-command.json',
       'lint_publication.py','verify_incomplete_docs.py','incomplete-docs-verification.json','incomplete-restoration.json',
       'incomplete-final-lifecycle.json','capture_incomplete_lifecycle.py','incomplete-archive.json',
       'strict-frozen-verifier.log','strict-frozen-verifier-command.json','supplemental-interrupted-data.log',
       'supplemental-interrupted-data-command.json','package_incomplete_publication.py']
entries={name:(root/name).read_bytes() for name in names}
checksums=''.join(hashlib.sha256(value).hexdigest()+'  '+name+'\n' for name,value in sorted(entries.items()))
entries['SHA256SUMS']=checksums.encode()
prefix='20261010-simple-value-name-incomplete-publication-context-861'
destination=repo/'bench/vs_tsgo/evidence'/(prefix+'.tar.gz')
assert not destination.exists()
with destination.open('wb') as output:
    with gzip.GzipFile(filename='',mode='wb',fileobj=output,mtime=0) as compressed:
        with tarfile.open(fileobj=compressed,mode='w') as archive:
            for name,value in sorted(entries.items()):
                info=tarfile.TarInfo(prefix+'/'+name)
                info.size,info.mode,info.mtime=len(value),0o644,0
                archive.addfile(info,io.BytesIO(value))
with tarfile.open(destination) as archive:
    for name in names:
        assert archive.extractfile(prefix+'/'+name).read()==entries[name]
record={'archive':str(destination),'sha256':hashlib.sha256(destination.read_bytes()).hexdigest(),
        'payload_checksums':len(names),'execution_qualified':False,
        'scope':'Publication lint,claim verifier,actual failed/unknown/terminal lifecycle,strict frozen failure and separate data audit'}
(root/'incomplete-publication-archive.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))
