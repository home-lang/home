import datetime
import json
from pathlib import Path
import re

root=Path(__file__).resolve().parent
labels=['checker','binder','program','driver','cli','entrypoint','build','diagnostic-parity','zod-parent','zod-candidate','harness','parent-build','screen','confirmation','families','confirmation_large-0','confirmation_large-1','confirmation_large-3','confirmation_large-4','recheck','interface-risk','restored-build','strict-frozen-verifier','supplemental-interrupted-data']
records={}
for label in labels:
    command=json.loads((root/(label+'-command.json')).read_text())
    expected=123 if label=='confirmation_large-4' else (1 if label=='strict-frozen-verifier' else 0)
    assert command['exit']==expected
    log=(root/(label+'.log')).read_text()
    peaks=[int(value) for value in re.findall(r'peak tree footprint (\d+) MB',log)]
    records[label]={'status':'terminal',**command,'peak_tree_mb':max(peaks) if peaks else None,
                    'shared_lock_wait_retained':'waiting up to 900s for the machine lock' in log}
records['confirmation_large-2']={'status':'interrupted exit unknown','exit':None,'raw_pairs_retained':6,'bounded_execution_provenance_confirmed':False}
record={'observed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'commands':records,
        'original_session33261':{'status':'interrupted','exit':None},
        'remaining_session24692':{'status':'terminal failed','exit':1},
        'risk_session41887':{'status':'terminal','exit':0},
        'restoration_session42065':{'status':'terminal','exit':0},
        'audit_session5935':{'status':'terminal','exit':0,'original_strict_verifier_exit':1},
        'candidate_committed_or_pushed':False,'execution_qualified':False,'retained_pairs':706,
        'planned_pairs':712,'retained_admissions':660,'repeat_until_pass':False,'samples_excluded':0,
        'source_and_native_restoration':json.loads((root/'incomplete-restoration.json').read_text())}
assert not (root/'incomplete-final-lifecycle.json').exists()
(root/'incomplete-final-lifecycle.json').write_text(json.dumps(record,indent=2)+'\n')
print('All known terminal,failed and unknown job outcomes recorded without invented success.')
