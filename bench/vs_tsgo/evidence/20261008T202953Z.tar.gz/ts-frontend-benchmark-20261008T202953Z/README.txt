Every *-round-*.json file is the byte-for-byte Hyperfine output from the measured run.
Known repository, compiler/tool, and temporary-control paths in metadata and admission are normalized before publication.
When present, admission.jsonl retains all commands, exits, stdout and stderr with only those path prefixes normalized.
SHA256SUMS covers the published metadata and every raw round file.
