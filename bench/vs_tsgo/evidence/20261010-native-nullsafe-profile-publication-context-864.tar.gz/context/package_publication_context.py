import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
verified = json.loads((root / 'verified-docs.json').read_text())
assert verified['passed'] and json.loads((root / 'pickier-results.json').read_text())[-1]['exit'] == 0
assert hashlib.sha256((repo / 'README.md').read_bytes()).hexdigest() == verified['readme_sha256']
assert hashlib.sha256((repo / 'docs/docs/TS_PERFORMANCE.md').read_bytes()).hexdigest() == verified['document_sha256']
entries = {'README.md': (repo / 'README.md').read_bytes(),
           'TS_PERFORMANCE.md': (repo / 'docs/docs/TS_PERFORMANCE.md').read_bytes()}
for name in ['verify_docs.py', 'verified-docs.json', 'lint.py', 'pickier-results.json',
             'pickier-repository.log', 'pickier-changed_documents.log', 'package-profile.json',
             'package_publication_context.py']:
    entries['context/' + name] = (root / name).read_bytes()
checksums = {name: hashlib.sha256(data).hexdigest() for name, data in entries.items()}
entries['SHA256SUMS'] = ''.join(checksums[name] + '  ' + name + '\n' for name in sorted(checksums)).encode()
output = repo / 'bench/vs_tsgo/evidence/20261010-native-nullsafe-profile-publication-context-864.tar.gz'
assert not output.exists()
with output.open('xb') as raw:
    with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as tar:
            for name, data in sorted(entries.items()):
                info = tarfile.TarInfo(name)
                info.size, info.mode = len(data), 0o644
                tar.addfile(info, io.BytesIO(data))
with tarfile.open(output, 'r:gz') as tar:
    for name, digest in checksums.items():
        assert hashlib.sha256(tar.extractfile(name).read()).hexdigest() == digest
record = {'archive': str(output.relative_to(repo)), 'sha256': hashlib.sha256(output.read_bytes()).hexdigest(),
          'payload_checksums': len(checksums), 'verified': True}
(root / 'publication-context.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record), flush=True)
