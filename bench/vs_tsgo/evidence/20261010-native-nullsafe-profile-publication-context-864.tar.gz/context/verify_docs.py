import hashlib
import json
from pathlib import Path
import tarfile

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
verified = json.loads((root / 'verified-profile.json').read_text())
package = json.loads((root / 'package-profile.json').read_text())
assert verified['passed'] and package['verified']
archive = repo / package['archive']
assert hashlib.sha256(archive.read_bytes()).hexdigest() == package['sha256']
with tarfile.open(archive, 'r:gz') as tar:
    checks = tar.extractfile('SHA256SUMS').read().decode().splitlines()
    assert len(checks) == package['payload_checksums'] == 46
    for line in checks:
        digest, name = line.split('  ', 1)
        assert hashlib.sha256(tar.extractfile(name).read()).hexdigest() == digest
readme = (repo / 'README.md').read_text()
document = (repo / 'docs/docs/TS_PERFORMANCE.md').read_text()
heading = '## Exact native null safe profile 2026 10 10 UTC'
assert document.count(heading) == 1
section = document.split(heading, 1)[1].split('\n## ', 1)[0]
for token in ['817/830', '181 symbols', '46 payload checksums', '5,890', '9,675,952', '9,677,200', '633,792', '1,248', '36']:
    if token != '36':
        assert token in section, token
assert 'six complete scale' in section and '30 protocol-5 native preflight checks' in section
assert verified['source'] in section and verified['native_sha256'] in section and package['sha256'] in section
assert '0x1002eda08' in section and '188, 200' in section
assert '0x10051ab44' in section and '0x1003320c0' in section
assert 'before any sampling' in section and 'zero benchmark timing samples' in section
assert 'not' in section and 'CPU percentages' in section and 'whole-run CPU shares' in section
assert '#exact-native-null-safe-profile-2026-10-10-utc' in readme
assert '36 admission' in readme and 'not a CPU-share or speedup claim' in readme
assert hashlib.sha256((repo / 'zig-out/bin/home-tsc').read_bytes()).hexdigest() == verified['native_sha256']
result = {'passed': True, 'archive_sha256': package['sha256'], 'payload_checksums': 46,
          'native_process_runs': 1, 'admissions': 36, 'sample_windows': 2, 'timing_samples': 0,
          'readme_sha256': hashlib.sha256(readme.encode()).hexdigest(),
          'document_sha256': hashlib.sha256(document.encode()).hexdigest()}
(root / 'verified-docs.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result), flush=True)
