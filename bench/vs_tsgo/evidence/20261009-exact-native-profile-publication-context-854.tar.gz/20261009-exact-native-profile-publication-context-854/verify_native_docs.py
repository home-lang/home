import json
from pathlib import Path

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
data = json.loads((root / 'verified-native-profile.json').read_text())
archive = json.loads((root / 'archive.json').read_text())
docs = (repo / 'docs/docs/TS_PERFORMANCE.md').read_text()
section = docs.split('## Exact-native profile and byte-scope audit (2026-10-09 UTC)', 1)[1].split('\n## ', 1)[0]
readme = (repo / 'README.md').read_text()
for name, row in data['candidates'].items():
    early = ', '.join(str(value) for value in row['early_displayed_offsets']) or 'none explicitly displayed'
    middle = ', '.join(str(value) for value in row['middle_displayed_offsets']) or 'none explicitly displayed'
    assert f"| `{name}` | `{row['start']}` | {early} | {middle} |" in section
assert archive['sha256'] in section and f"**{archive['payload_checksums']}**" in section
assert data['source'] in section and data['native_sha256'] in section
assert '**31**' in section and '**826 / 823**' in section
assert '**159,369 explicitly declared linker relocations**' in section and '633,752' in section
assert '**zero undeclared changed bytes**' in section and '**5,889**' in section
assert 'not** a claim of native/diagnostic byte equality' in section
assert 'undistributed' in section and 'whole-run CPU percentages' in section
assert 'exit **125**' in section and '3,885 MB' in section and 'unsupported' in section
assert 'docs/docs/TS_PERFORMANCE.md#exact-native-profile-and-byte-scope-audit-2026-10-09-utc' in readme
assert '| Local namespace-import lookup ([#857](https://github.com/home-lang/home/issues/857)) | 188, 200 | 188, 200 |' in readme
assert '| Function-signature collection | 36, 56 | 36, 96 |' in readme
print('Exact-native profile rows, hashes, failure/guard retention, count limitations and README links verify.')
