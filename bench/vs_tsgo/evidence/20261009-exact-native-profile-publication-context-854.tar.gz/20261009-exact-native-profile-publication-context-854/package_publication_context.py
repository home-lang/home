import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import tarfile

root = Path(__file__).resolve().parent
repo = Path('/Users/chris/.codex/worktrees/ts-bench-snapshot-837/lang')
full = json.loads((root / 'lint-command.json').read_text())
focused = json.loads((root / 'focused-lint-command.json').read_text())
assert full['exit'] == 1 and focused['exit'] == 0
assert focused['publication_file_sha256_before'] == focused['publication_file_sha256_after']
for name, expected in focused['publication_file_sha256_after'].items():
    assert hashlib.sha256((repo / name).read_bytes()).hexdigest() == expected
counts = re.findall(r'(\d+) problems \((\d+) errors, (\d+) warnings\)', (root / 'lint.log').read_text())
assert counts
source = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip()
record = {'source_at_publication': source, 'sampled_source': 'b6608b14c631db91be6099e78c957ab67a3b5266',
    'native_sha256': '68c6ed517f9125ae1b570ff2e585c5b368745389af828258f6621fe5e6e0311c',
    'native_profile_session': {'session': 49954, 'status': 'terminal', 'exit': 0},
    'archive_session': {'session': 75913, 'status': 'terminal', 'exit': 0},
    'repo_lint_session': {'session': 76319, 'status': 'terminal', 'exit': 1},
    'repo_lint_errors': int(counts[-1][1]), 'repo_lint_warnings': int(counts[-1][2]),
    'focused_final_docs_lint_exit': 0, 'focused_final_docs_sha256': focused['publication_file_sha256_after'],
    'relocation_exclusion_scope': 'Whole relocation-sized words at declared sites, not just immediate operand bits; no opcode-identity claim at excluded sites',
    'native_admissions': 31, 'diagnostic_images_sampled_or_timed': 0,
    'collapsed_function_counts_invented': False, 'autofixes': False,
    'guard_raised': False, 'unstripped_build_guard_exit': 125,
    'profile_archive': json.loads((root / 'archive.json').read_text()),
    'remaining_goal': 'Universal performance, Zod admission, C++ and other-platform admission incomplete; prospective code work in #857'}
(root / 'publication-context.json').write_text(json.dumps(record, indent=2) + '\n')
names = ('lint.py', 'lint.log', 'lint-command.json', 'focused_lint.py', 'focused-lint.log', 'focused-lint-command.json',
    'verify_native_docs.py', 'publication-context.json', 'package_publication_context.py')
entries = {name: (root / name).read_bytes() for name in names}
checksums = ''.join(hashlib.sha256(data).hexdigest() + '  ' + name + '\n' for name, data in sorted(entries.items()))
count = len(entries)
entries['SHA256SUMS'] = checksums.encode()
name = '20261009-exact-native-profile-publication-context-854'
path = repo / 'bench/vs_tsgo/evidence' / (name + '.tar.gz')
assert not path.exists()
with path.open('wb') as output:
    with gzip.GzipFile(filename='', mode='wb', fileobj=output, mtime=0) as gz:
        with tarfile.open(fileobj=gz, mode='w') as tar:
            for filename, data in sorted(entries.items()):
                item = tarfile.TarInfo(name + '/' + filename)
                item.size, item.mode, item.mtime = len(data), 0o644, 0
                tar.addfile(item, io.BytesIO(data))
with tarfile.open(path) as tar:
    for line in checksums.splitlines():
        expected, filename = line.split('  ', 1)
        assert hashlib.sha256(tar.extractfile(name + '/' + filename).read()).hexdigest() == expected
report = {'archive': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'payload_checksums': count}
(root / 'publication-archive.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report))
