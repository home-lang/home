interface O { run?: (value: number) => string }
declare function accept(v: O["run"]): void;
accept(undefined);
accept((v: number) => "ok");
accept((v: string) => "wrong");
