interface O { value?: number }
declare function accept(v: O["value"]): void;
accept(undefined);
accept(1);
accept("wrong");
