interface O { inner: { value?: number } }
declare function accept(v: O["inner"]["value"]): void;
accept(undefined);
accept("wrong");
