interface O { optional?: number; required: number }
declare function accept(v: O["optional" | "required"]): void;
accept(undefined);
accept("wrong");
