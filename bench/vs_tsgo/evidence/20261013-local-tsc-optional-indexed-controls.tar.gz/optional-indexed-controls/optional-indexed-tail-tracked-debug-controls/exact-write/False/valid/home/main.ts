interface O { value?: number }
declare let o: O;
o["value"] = 1;
