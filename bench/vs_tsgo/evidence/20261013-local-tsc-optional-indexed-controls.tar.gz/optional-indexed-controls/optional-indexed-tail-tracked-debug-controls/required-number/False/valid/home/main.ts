interface O { value: number }
declare function accept(v: O["value"]): void;
accept(1);
