from pathlib import Path
import subprocess,json,hashlib,re,os
r=Path.cwd();o=r/'.home-cache/owner-transfer';home=o/'this-boundary-final-release/bin/home-tsc';z=r/'.home-cache/toolchains/zig-aarch64-macos-0.17.0-dev.2163+89ff10d56/zig'
def git(*args):return subprocess.run(['git',*args],cwd=r,capture_output=True,text=True,check=True).stdout.strip()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert not git('status','--porcelain')
freeze=json.loads((o/'this-boundary-source-freeze.json').read_text());assert all(sha(p)==h for p,h in freeze.items())
before=git('rev-parse','HEAD');target=git('rev-parse','origin/main');base=git('merge-base',before,target);paths=git('diff','--name-only',base,target).splitlines();assert git('rev-list','--count','origin/main..HEAD')=='1'
assert not any(re.match(r'^(packages/(ts|hir/|binder/|string_interner/)|scripts/tests/test-ts-|pantry/zig-dtsx)',p) for p in paths),paths
report={'before':before,'target':target,'base':base,'incoming_paths':paths,'binary_before':sha(home),'steps':[]}
env=os.environ.copy();env.update(GIT_COMMITTER_NAME='Chris Breuer',GIT_COMMITTER_EMAIL='chrisbreuer93@gmail.com')
subprocess.run(['git','rebase','origin/main'],cwd=r,env=env,check=True)
common=['-Denable_jsc=false','-j1','--summary','all','--cache-dir','.home-cache/generic-return-zig-cache']
steps=[(scope,[z,'build','test','-Dfilter='+scope,*common]) for scope in ['ts_checker','ts_driver','ts_program']]
steps.append(('build',[z,'build','home-tsc','-Doptimize=ReleaseFast','-Dhome-tsc-strip=true',*common,'--prefix',home.parent.parent]))
for name,args in steps:
 with(o/('this-boundary-rebase-'+name+'.log')).open('w') as f:x=subprocess.run([str(a) for a in args],stdout=f,stderr=subprocess.STDOUT)
 report['steps'].append({'name':name,'exit':x.returncode});(o/'this-boundary-rebase-validation.json').write_text(json.dumps(report,indent=2)+'\n');print(name,x.returncode,flush=True)
 if x.returncode:raise SystemExit(x.returncode)
report['after']=git('rev-parse','HEAD');report['binary_after']=sha(home);assert report['binary_before']==report['binary_after']
changed=[p for p,h in freeze.items() if sha(p)!=h];assert all(str(Path(p).relative_to(r)) in paths for p in changed)
report['frozen_changes']=changed;report['binary_unchanged']=True
(o/'this-boundary-rebase-validation.json').write_text(json.dumps(report,indent=2)+'\n')
print('rebase validated, binary unchanged',flush=True)
# Reuse the saved runner logic with separate evidence paths, leaving the
# frozen runner and actual compiler path untouched.
source=(r/'.home-cache/table-replacement/replay-this-boundary-final.py').read_text().replace("'this-boundary-final-summary.json'","'this-boundary-rebase-summary.json'").replace("'this-boundary-final-'+name","'this-boundary-rebase-'+name")
exec(compile(source,'rebase-table-replay','exec'),{'__name__':'__main__'})
