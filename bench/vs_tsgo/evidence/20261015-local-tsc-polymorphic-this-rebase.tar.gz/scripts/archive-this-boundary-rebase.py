from pathlib import Path
import subprocess,json,hashlib,tarfile,io
r=Path.cwd();o=r/'.home-cache/owner-transfer';items={}
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def add(p,n):items[n]=Path(p).read_text().replace(str(r),'<workspace>').replace('<home>','<home>').encode()
report=json.loads((o/'this-boundary-rebase-validation.json').read_text());assert report['binary_unchanged'] and len(report['steps'])==4 and all(x['exit']==0 for x in report['steps'])
assert report['binary_after']==sha(o/'this-boundary-final-release/bin/home-tsc')
table=json.loads((r/'.home-cache/table-replacement/this-boundary-rebase-summary.json').read_text());assert table['replacement_verified'] and not table['input_changes_after']
old=json.loads((o/'this-boundary-source-freeze.json').read_text());changed=[p for p,h in old.items() if sha(p)!=h];assert changed==report['frozen_changes']
paths=set(old)|{str(r/p) for p in subprocess.run(['git','ls-files','--','*.zig'],capture_output=True,text=True,check=True).stdout.splitlines()};new={p:sha(p) for p in sorted(paths)}
(o/'this-boundary-rebase-source-freeze-before.json').write_text(json.dumps(old,indent=2)+'\n');(o/'this-boundary-rebase-source-freeze-after.json').write_text(json.dumps(new,indent=2)+'\n')
delta={'changed':changed,'added':sorted(paths-set(old)),'before_count':len(old),'after_count':len(new),'binary_unchanged':True};(o/'this-boundary-rebase-source-delta.json').write_text(json.dumps(delta,indent=2)+'\n')
public={k:table[k] for k in ['replacement_verified','positive_comparison_passed','negative_comparison_passed','input_changes_after','negative_observations']};public['input_count']=len(table['input_hashes']);public['summary_sha256']=sha(r/'.home-cache/table-replacement/this-boundary-rebase-summary.json');(o/'this-boundary-rebase-table-outcome.json').write_text(json.dumps(public,indent=2)+'\n')
for p in sorted(o.glob('this-boundary-rebase-*.log'))+sorted(o.glob('this-boundary-rebase-*.json')):add(p,'rebase/'+p.name)
for p in [o/'rebase-this-boundary-publication.py',o/'archive-this-boundary-rebase.py']:add(p,'scripts/'+p.name)
items['MANIFEST.json']=json.dumps({n:hashlib.sha256(b).hexdigest() for n,b in items.items()},indent=2).encode();p=r/'bench/vs_tsgo/evidence/20261015-local-tsc-polymorphic-this-rebase.tar.gz'
with tarfile.open(p,'w:gz') as t:
 for n,b in items.items():
  info=tarfile.TarInfo(n);info.size=len(b);info.mtime=0;t.addfile(info,io.BytesIO(b))
with tarfile.open(p) as t:
 manifest=json.load(t.extractfile('MANIFEST.json'))
 for n,h in manifest.items():assert hashlib.sha256(t.extractfile(n).read()).hexdigest()==h
result={'path':str(p.relative_to(r)),'sha256':sha(p),'payloads':len(manifest),'bytes':p.stat().st_size};(o/'this-boundary-rebase-archive-result.json').write_text(json.dumps(result,indent=2)+'\n');print(result)
(o/'this-boundary-source-freeze.json').write_text(json.dumps(new,indent=2)+'\n')
p=r/'docs/docs/TS_LOCAL_REPLACEMENT.md';s=p.read_text();s+=f'''
Before the final push, origin/main advanced by two more commits through
`{report['target'][:9]}` covering basic filesystem, time and INI helpers. Rebase
was conflict-free. Checker, driver, Program and production build checks remain
cache-valid, and the compiler hash is unchanged. Fresh table positive and
negative controls pass with all 306 inputs unchanged, peaking at **1,105 MB**.
The rebase changes only the recorded unrelated inputs and adds one source to
the freeze (**{len(new):,} inputs**).

Rebase evidence: `{result['path']}`, **{result['payloads']} verified payloads**,
SHA-256 `{result['sha256']}`.
''';p.write_text(s)
