import { foo } from "./bar";
