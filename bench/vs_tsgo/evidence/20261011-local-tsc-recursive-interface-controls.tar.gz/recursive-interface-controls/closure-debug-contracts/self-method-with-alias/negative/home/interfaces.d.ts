type Label = string;
interface TimerLike { ref(): TimerLike; label: Label; }
