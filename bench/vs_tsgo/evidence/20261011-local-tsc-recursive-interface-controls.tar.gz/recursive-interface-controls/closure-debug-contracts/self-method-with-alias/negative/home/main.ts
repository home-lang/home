declare const timer: TimerLike;
const label: string = timer.ref().ref().label;
const wrong: number = timer.ref().ref().label;
