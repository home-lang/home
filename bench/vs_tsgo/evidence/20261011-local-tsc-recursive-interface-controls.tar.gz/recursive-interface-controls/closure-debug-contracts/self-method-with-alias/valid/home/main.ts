declare const timer: TimerLike;
const label: string = timer.ref().ref().label;
