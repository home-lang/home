declare const peer: Peer;
const value: number = peer.other.other.value;
