declare const peer: Peer;
const value: number = peer.other.other.value;
const wrong: string = peer.other.other.value;
