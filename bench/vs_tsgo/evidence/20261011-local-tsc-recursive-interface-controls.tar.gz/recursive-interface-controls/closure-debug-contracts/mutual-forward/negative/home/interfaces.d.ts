interface Peer { other: Partner; value: number; }
interface Partner { other: Peer; label: string; }
