interface Link { next: Link; value: number; }
