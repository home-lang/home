interface TimerLike { ref(): TimerLike; label: string; }
