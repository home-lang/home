interface Tag { (strings: TemplateStringsArray, ...rest: number[]): Tag; member: { new (s: string): { new (n: number): { new (): boolean } } }; }
