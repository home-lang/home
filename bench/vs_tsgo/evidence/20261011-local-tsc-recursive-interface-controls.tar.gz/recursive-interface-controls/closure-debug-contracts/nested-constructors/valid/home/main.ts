declare const tag: Tag;
const value: boolean = new new new tag `head ${0}`.member("value")(42);
