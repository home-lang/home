interface Partner { other: Peer; label: string; }
interface Peer { other: Partner; value: number; }
