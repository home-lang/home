declare const link: Link;
const value: number = link.next.next.value;
const wrong: string = link.next.next.value;
