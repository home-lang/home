interface Link { next: Link; }
interface Link { value: number; }
