declare const link: Link;
const value: number = link.next.next.value;
