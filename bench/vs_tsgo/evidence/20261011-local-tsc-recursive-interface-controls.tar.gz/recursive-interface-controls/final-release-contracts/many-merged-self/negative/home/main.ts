declare const link: Link;
const value: number = link.next.next.p23;
const wrong: string = link.next.next.p23;
